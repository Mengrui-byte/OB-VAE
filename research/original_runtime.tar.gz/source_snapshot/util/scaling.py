"""Train-only feature scales, including reversible window-anchored prices."""
import numpy as np
from tqdm.auto import tqdm
import json
from pathlib import Path


def scale_cache_metadata(dataset, start, end, price_normalization):
    stat = Path(dataset.index_path).stat()
    return {"asset": dataset.asset, "fit_start": start, "fit_end": end,
            "window_size": dataset.window_size, "stride": dataset.stride,
            "price_normalization": price_normalization, "mask_invalid_levels": True,
            "training_minutes": len(dataset.times), "training_windows": len(dataset),
            "npz_size": stat.st_size, "npz_mtime_ns": stat.st_mtime_ns,
            "first_training_time": int(dataset.times[0]), "last_training_time": int(dataset.times[-1])}


def load_feature_scales(path, dataset, start, end, price_normalization):
    cached = json.loads(Path(path).read_text())
    for key, expected in scale_cache_metadata(dataset, start, end, price_normalization).items():
        if cached.get(key) != expected:
            raise ValueError(f"Cached feature scale mismatch for {key}")
    scales = (cached["price_scale"], cached["quantity_scale"])
    if any(not np.isfinite(v) or v <= 0 for v in scales):
        raise ValueError("Cached scales must be finite and positive")
    return tuple(float(v) for v in scales)


def fit_feature_scales(dataset, chunk_rows=1440, *, mask_invalid=False, price_normalization="absolute"):
    """Fit only training data; anchored prices use all eligible training windows.

    Quantities count each selected minute once. Anchored prices depend on the
    window reference, so they count valid elements of every eligible window.
    Local centered prefix moments avoid rereading all overlapping windows.
    """
    if price_normalization not in ("absolute", "window-anchor"):
        raise ValueError("Unknown price normalization")
    if price_normalization == "window-anchor" and not mask_invalid:
        raise ValueError("Window-anchor normalization requires valid-level masks")
    if len(dataset.times) == 0:
        raise ValueError("Cannot fit feature scales without training snapshots")
    mapped = np.memmap(dataset.index_path, dtype=np.float32, mode="r",
                       offset=dataset._data_offset, shape=dataset._shape)
    squares = np.zeros(2, dtype=np.float64)
    counts = np.zeros(2, dtype=np.int64)
    levels = np.arange(dataset._shape[-2])[None, None, :]
    for offset in tqdm(range(0, len(dataset.times), chunk_rows), desc=f"拟合 {price_normalization} 尺度",
                       unit="chunk", mininterval=5, disable=not mask_invalid):
        stop = min(offset + chunk_rows, len(dataset.times))
        finish = min(len(dataset.times), stop + dataset.window_size - 1) if price_normalization == "window-anchor" else stop
        block = mapped[dataset._source_start + offset:dataset._source_start + finish]
        if not np.isfinite(block).all():
            raise ValueError("Cannot fit feature scales on nonfinite training data")
        mask = levels < dataset.level_counts[offset:finish, :, None] if mask_invalid else np.ones(block.shape[:-1], dtype=bool)
        main = stop - offset
        squares[1] += np.square(block[:main, ..., 1], dtype=np.float64).sum(where=mask[:main])
        counts[1] += mask[:main].sum()
        if price_normalization == "absolute":
            squares[0] += np.square(block[:main, ..., 0], dtype=np.float64).sum(where=mask[:main])
            counts[0] += mask[:main].sum()
            continue
        starts = dataset.starts[(dataset.starts >= offset) & (dataset.starts < stop)] - offset
        if not len(starts):
            continue
        anchors = (block[starts, 0, 0, 0].astype(np.float64) + block[starts, 1, 0, 0].astype(np.float64)) / 2
        if (anchors <= 0).any() or not mask[starts, :, 0].all():
            raise ValueError("Each window anchor needs valid best bid and ask")
        reference = float(anchors[0])
        centered = block[..., 0].astype(np.float64) - reference
        centered[~mask] = 0
        row_sum = centered.sum(axis=(1, 2))
        row_square = np.square(centered).sum(axis=(1, 2))
        row_count = mask.sum(axis=(1, 2))
        prefix = [np.concatenate(([0], np.cumsum(v, dtype=np.float64))) for v in (row_sum, row_square, row_count)]
        sums, sums_sq, valid = [v[starts + dataset.window_size] - v[starts] for v in prefix]
        delta = anchors - reference
        residual_sq = sums_sq - 2 * delta * sums + delta * delta * valid
        tolerance = 1e-10 * (np.abs(sums_sq) + delta * delta * valid + 1)
        if np.any(residual_sq < -tolerance):
            raise FloatingPointError("Unstable anchored price scale moments")
        squares[0] += (np.maximum(residual_sq, 0) * (10000 / anchors) ** 2).sum()
        counts[0] += int(valid.sum())
    if (counts <= 0).any():
        raise ValueError("Cannot fit scales without valid training elements")
    scales = np.sqrt(squares / counts)
    if not np.isfinite(scales).all() or (scales <= 0).any():
        raise ValueError("Training feature RMS must be finite and positive")
    return float(scales[0]), float(scales[1])
