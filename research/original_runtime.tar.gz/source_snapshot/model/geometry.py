"""Compatibility import; implement model changes in model.autoencoder.geometry."""

import sys
from importlib import import_module

_implementation = import_module("model.autoencoder.geometry")
sys.modules[__name__] = _implementation
