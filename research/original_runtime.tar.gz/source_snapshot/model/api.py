"""Canonical order-book models. Example: ``build_model('mlp_thick')``."""

from .config import MLPConfig, MLP_STANDARD, MLP_THICK
from .factory import build_model

__all__ = [
    "AE",
    "BackboneModel",
    "MLPConfig",
    "MLP_STANDARD",
    "MLP_THICK",
    "build_model",
]


def __getattr__(name):
    # Keep configuration and snapshot utilities usable without importing torch.
    if name == "AE":
        from .autoencoder.ae import AE

        return AE
    if name == "BackboneModel":
        from .backbone import BackboneModel

        return BackboneModel
    raise AttributeError(name)
