"""Learned compression, preserving all flattened inputs until the MLP."""

from torch import nn


def bottleneck_mlp(in_features, hidden, out_features=64):
    widths = [in_features, *hidden, out_features]
    layers = []
    for index, (a, b) in enumerate(zip(widths[:-1], widths[1:])):
        layers.append(nn.Linear(a, b))
        if index < len(widths) - 2:
            layers.append(nn.GELU())
    return nn.Sequential(*layers)
