"""Fixed, same-frame/side one-level Laplacian correction after decoding."""
import math

import torch
from torch.nn import functional as F


def sharpen_quantity(quantity, mask, coefficient):
    if quantity.shape != mask.shape or quantity.ndim != 4:
        raise ValueError('Expected matching [B,T,2,L] quantity and mask')
    if not math.isfinite(coefficient) or coefficient < 0:
        raise ValueError('Need a finite nonnegative coefficient')
    q = quantity.masked_fill(~mask, 0)
    if coefficient == 0:
        return q
    valid = F.pad(mask[..., :-2] & mask[..., 1:-1] & mask[..., 2:], (1, 1))
    curvature = F.pad(2 * q[..., 1:-1] - q[..., :-2] - q[..., 2:], (1, 1))
    return (q + coefficient * curvature.masked_fill(~valid, 0)).clamp_min(0).masked_fill(~mask, 0)
