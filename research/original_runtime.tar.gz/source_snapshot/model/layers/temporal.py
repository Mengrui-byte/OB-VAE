"""Residual causal depthwise convolutions at multiple time scales."""

import torch
from torch import nn
from torch.nn import functional as F


class CausalScales(nn.Module):
    def __init__(self, width, multiscale=True):
        super().__init__()
        self.dilations = [1, 4, 16] if multiscale else [1]
        self.convs = nn.ModuleList(
            [
                nn.Conv1d(width, width, 3, dilation=d, groups=width)
                for d in self.dilations
            ]
        )
        self.mix = nn.Linear(width * len(self.dilations), width)
        self.norm = nn.LayerNorm(width)

    def forward(self, x):
        native = self.norm(x).transpose(1, 2)
        features = [
            conv(F.pad(native, (2 * d, 0))).transpose(1, 2)
            for conv, d in zip(self.convs, self.dilations)
        ]
        return x + self.mix(torch.cat(features, -1))
