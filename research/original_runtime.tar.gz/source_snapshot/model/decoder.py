"""Compatibility import; implement model changes in model.autoencoder.decoder."""

import sys
from importlib import import_module

_implementation = import_module("model.autoencoder.decoder")
sys.modules[__name__] = _implementation
