"""Native price/quantity patches and peak features with MLP compression."""

import torch
from torch import nn
from model.layers.mlp import bottleneck_mlp
from model.layers.temporal import CausalScales


class GeometryEncoder(nn.Module):
    """Price-aware native patches -> spatial regions -> causal temporal attention.

    All256 observed minutes are retained until temporal mixing. Only the final
    readout compresses to16 anchors. Each32-level patch contributes background
    statistics and the positions/price/size of its two largest observed levels.
    """

    def __init__(
        self,
        width=192,
        peak_encoder=True,
        temporal_attention=True,
        fourier=True,
        multiscale=True,
        native_patch=True,
        bottleneck="mlp",
        mlp_spatial_hidden=(512,),
        mlp_temporal_hidden=(256,),
    ):
        super().__init__()
        self.peak_encoder, self.temporal_attention = peak_encoder, temporal_attention
        self.fourier, self.multiscale = fourier, multiscale
        if bottleneck not in ["mlp", "attention"]:
            raise ValueError("Unknown bottleneck")
        self.bottleneck = bottleneck
        self.background = nn.Sequential(
            nn.Linear(10, width), nn.GELU(), nn.Linear(width, width)
        )
        self.native_patch = (
            nn.Sequential(
                nn.Linear(64, width * 2), nn.GELU(), nn.Linear(width * 2, width)
            )
            if native_patch
            else None
        )
        self.peaks = (
            nn.Sequential(nn.Linear(8, width), nn.GELU(), nn.Linear(width, width))
            if peak_encoder
            else None
        )
        self.price_fourier = nn.Linear(8, width, bias=False) if fourier else None
        self.position = nn.Embedding(128, width)
        self.spatial = nn.TransformerEncoderLayer(
            width,
            4,
            width * 2,
            dropout=0.0,
            batch_first=True,
            norm_first=True,
            activation="gelu",
        )
        if bottleneck == "mlp":
            self.spatial_mlp = bottleneck_mlp(128 * width, mlp_spatial_hidden)
        else:
            self.region_queries = nn.Parameter(torch.randn(8, 8) * 0.02)
            self.region_attention = nn.MultiheadAttention(
                8, 2, kdim=width, vdim=width, batch_first=True, dropout=0.0
            )
        self.time_scales = CausalScales(64, multiscale)
        self.temporal = (
            nn.TransformerEncoderLayer(
                64,
                4,
                128,
                dropout=0.0,
                batch_first=True,
                norm_first=True,
                activation="gelu",
            )
            if temporal_attention
            else None
        )
        self.anchor_attention = (
            nn.MultiheadAttention(64, 4, batch_first=True, dropout=0.0)
            if temporal_attention and bottleneck == "attention"
            else None
        )
        self.reduce = (
            bottleneck_mlp(16 * 64, mlp_temporal_hidden)
            if bottleneck == "mlp"
            else nn.Sequential(nn.Linear(128, 64), nn.GELU(), nn.Linear(64, 64))
        )

    def forward(self, x):
        b, t, s, l, f = x.shape
        if (s, l, f) != (2, 2048, 2) or t % 16:
            raise ValueError("Expected [B,T,2,2048,2], T divisible by16")
        cells = x.reshape(b, t, 2, 64, 32, 2)
        p, q = cells[..., 0], cells[..., 1].clamp_min(0)
        valid = cells.abs().sum(-1) > 0
        n = valid.sum(-1).clamp_min(1)
        total = q.sum(-1)
        weighted = (p * q).sum(-1) / total.clamp_min(1e-8)
        mean = (p * valid).sum(-1) / n
        pmin = p.masked_fill(~valid, torch.inf).amin(-1)
        pmax = p.masked_fill(~valid, -torch.inf).amax(-1)
        pmin = torch.where(valid.any(-1), pmin, torch.zeros_like(pmin))
        pmax = torch.where(valid.any(-1), pmax, torch.zeros_like(pmax))
        stats = torch.stack(
            [
                mean.asinh(),
                weighted.asinh(),
                pmin.asinh(),
                pmax.asinh(),
                (pmax - pmin).asinh(),
                (total / n).asinh(),
                q.amax(-1).asinh(),
                (q.square().mean(-1) + 1e-12).sqrt().asinh(),
                total.asinh(),
                n / 32.0,
            ],
            -1,
        )
        tokens = self.background(stats)
        if self.native_patch is not None:
            # Every native price/quantity pair reaches a trainable projection;
            # the model is not restricted to manually selected summaries/top-k.
            tokens = tokens + self.native_patch(cells.asinh().flatten(-2))
        if self.peaks is not None:
            heights, indices = q.topk(2, dim=-1)
            prices = p.gather(-1, indices)
            desc = torch.stack(
                [
                    prices.asinh(),
                    heights.asinh(),
                    indices / 31.0,
                    (prices - mean[..., None]).asinh(),
                ],
                -1,
            ).flatten(-2)
            tokens = tokens + self.peaks(desc)
        if self.price_fourier is not None:
            phase = mean.asinh()[..., None] * torch.tensor(
                [1.0, 2.0, 4.0, 8.0], device=x.device
            )
            tokens = tokens + self.price_fourier(
                torch.cat([phase.sin(), phase.cos()], -1)
            )
        tokens = tokens.reshape(b * t, 128, -1) + self.position.weight[None]
        tokens = self.spatial(tokens)
        if self.bottleneck == "mlp":
            compact = self.spatial_mlp(tokens.reshape(b, t, -1))
        else:
            regions = torch.arange(128, device=x.device) // 16
            mask = torch.arange(8, device=x.device)[:, None] != regions[None, :]
            query = self.region_queries[None].expand(b * t, -1, -1)
            pooled, _ = self.region_attention(
                query, tokens, tokens, attn_mask=mask, need_weights=False
            )
            compact = pooled.reshape(b, t, 64)
        fine = self.time_scales(compact)
        if self.temporal is not None:
            causal = torch.ones(t, t, device=x.device, dtype=torch.bool).triu(1)
            fine = self.temporal(fine, src_mask=causal)
        blocked = fine.reshape(b, t // 16, 16, 64)
        coarse = self.reduce(
            blocked.flatten(-2)
            if self.bottleneck == "mlp"
            else torch.cat([blocked.mean(2), blocked.amax(2)], -1)
        )
        if self.anchor_attention is not None:
            anchors = torch.arange(t // 16, device=x.device) * 16 + 15
            mask = torch.arange(t, device=x.device)[None, :] > anchors[:, None]
            attended, _ = self.anchor_attention(
                coarse, fine, fine, attn_mask=mask, need_weights=False
            )
            coarse = coarse + attended
        return coarse
