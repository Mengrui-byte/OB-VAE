"""Compatibility import; implement model changes in model.autoencoder.ae."""

import sys
from importlib import import_module

_implementation = import_module("model.autoencoder.ae")
sys.modules[__name__] = _implementation
