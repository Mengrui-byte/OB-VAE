import torch
import torch.nn as nn
from torch.utils.checkpoint import checkpoint

from model.autoencoder.encoder import OrderBookEncoder
from model.autoencoder.decoder import OrderBookDecoder


class AE(nn.Module):
    def __init__(
        self,
        in_features=2,
        d_model=128,
        out_features=2,
        latent_dim=64,
        num_spatial_queries=8,
        quantity_mode="direct",
        conv_order="alternating",
        peak_mode="none",
        peak_per_region=8,
        peak_candidates=32,
        peak_radius_bps=0.5,
        peak_sigma=0.5,
        peak_price_scale=100000.0,
        peak_price_normalization="absolute",
        book_structure="legacy",
        local_peak_slots=4,
    ):
        super().__init__()
        self.activation_checkpointing = False

        self.latent_dim = latent_dim
        self.conv_order = conv_order
        self.encoder = OrderBookEncoder(
            in_features=in_features,
            d_model=d_model,
            num_heads=4,
            latent_dim=latent_dim,
            num_spatial_queries=num_spatial_queries,
            conv_order=conv_order,
            peak_mode=peak_mode,
            peak_per_region=peak_per_region,
            peak_candidates=peak_candidates,
            peak_radius_bps=peak_radius_bps,
            peak_sigma=peak_sigma,
            peak_price_scale=peak_price_scale,
            peak_price_normalization=peak_price_normalization,
            book_structure=book_structure,
            local_peak_slots=local_peak_slots,
        )
        self.decoder = OrderBookDecoder(
            d_model=d_model,
            out_features=out_features,
            latent_dim=latent_dim,
            num_spatial_queries=num_spatial_queries,
            quantity_mode=quantity_mode,
            conv_order=conv_order,
            structured_latent=book_structure != "legacy",
        )

    def forward(self, x):
        if self.activation_checkpointing and self.training and torch.is_grad_enabled():
            x = checkpoint(self.encoder, x, use_reentrant=False)
            return checkpoint(self.decoder, x, use_reentrant=False)
        x = self.encoder(x)
        x = self.decoder(x)
        return x


if __name__ == "__main__":
    input = torch.randn(1, 256, 2, 2048, 2)

    model = AE(in_features=2, d_model=128, out_features=2)

    with torch.no_grad():
        output = model(input)

    print(output.size())
