"""Order-book autoencoder modules."""
