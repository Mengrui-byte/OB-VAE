"""A single fixed continuous PCA vector for the complete Global/Local window."""
import torch
from torch import nn


class JointPCACodec(nn.Module):
    def __init__(self, *, state_dim, window_size=16, levels=2048, global_dim=64, local_dim=16):
        super().__init__()
        self.state_dim,self.window_size,self.levels=state_dim,window_size,levels
        self.global_dim,self.local_dim=global_dim,local_dim
        self.global_length=window_size*global_dim
        self.local_shape=(window_size,2,levels//16,local_dim)
        self.length=self.global_length+window_size*2*(levels//16)*local_dim
        if levels%16 or not 0<state_dim<=self.length:raise ValueError('Invalid joint PCA shape')
        self.register_buffer('mean',torch.zeros(self.length))
        self.register_buffer('basis',torch.empty(0,self.length))

    def load_basis(self,data):
        mean,basis=data['mean'],data['basis']
        if tuple(mean.shape)!=(self.length,) or tuple(basis.shape)!=(self.state_dim,self.length):raise ValueError('Joint PCA basis dimensions differ')
        if mean.dtype!=torch.float32 or basis.dtype!=torch.float32:raise ValueError('Joint PCA deployment basis must be float32')
        self.mean=mean.detach();self.basis=basis.detach()

    def _ready(self):
        if tuple(self.basis.shape)!=(self.state_dim,self.length):raise RuntimeError('Load a fitted training-only joint PCA basis first')

    def encode(self,global_latent,local_latent):
        self._ready()
        if tuple(global_latent.shape[1:])!=(self.window_size,self.global_dim) or tuple(local_latent.shape[1:])!=self.local_shape:raise ValueError('Complete window latent shape differs')
        with torch.autocast(device_type=global_latent.device.type,enabled=False):
            flat=torch.cat([global_latent.float().flatten(1),local_latent.float().flatten(1)],1)
            return (flat-self.mean)@self.basis.T

    def decode(self,state,latent_mask=None):
        self._ready()
        if state.ndim!=2 or state.shape[-1]!=self.state_dim:raise ValueError(f'Expected [B,{self.state_dim}] continuous state')
        with torch.autocast(device_type=state.device.type,enabled=False):
            flat=state.float()@self.basis+self.mean
            g=flat[:,:self.global_length].reshape(-1,self.window_size,self.global_dim)
            l=flat[:,self.global_length:].reshape(-1,*self.local_shape)
            if latent_mask is not None:l=l*latent_mask[...,None]
            return g,l
