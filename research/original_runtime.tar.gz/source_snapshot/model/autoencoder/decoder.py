import torch
from torch import nn
from torch.nn import functional as F
from torch.utils.checkpoint import checkpoint

from model.autoencoder.conv import conv_norm_gelu
from model.autoencoder.quantity import PatchQuantityResidual, RegionalQuantityHead


class TemporalDecoder(nn.Module):
    """
    输入：[B,16,2,64,D]
    输出：[B,256,2,64,D]
    """

    def __init__(self, d_model=128, stage_channels=None):
        super().__init__()
        self.activation_checkpointing = False
        channels = [d_model] * 4 if stage_channels is None else list(stage_channels)
        if len(channels) != 4:
            raise ValueError("Temporal decoder requires four stage widths")

        # 时间长度：16 -> 32 -> 64 -> 128 -> 256
        self.convs = nn.ModuleList(
            [
                nn.ConvTranspose1d(
                    width,
                    width,
                    kernel_size=4,
                    stride=2,
                    padding=1,
                )
                for width in channels
            ]
        )

        self.norms = nn.ModuleList([nn.LayerNorm(width) for width in channels])

    def forward(self, x):
        for stage in range(len(self.convs)):
            x = self.forward_stage(x, stage)
        return x

    def forward_stage(self, x, stage):
        b, t, s, k, d = x.shape

        # 各空间位置共享同一个时间 Decoder。
        x = x.permute(0, 2, 3, 4, 1)
        x = x.reshape(b * s * k, d, t)

        conv, norm = self.convs[stage], self.norms[stage]
        if self.activation_checkpointing and self.training and torch.is_grad_enabled():
            x = checkpoint(conv_norm_gelu, x, conv, norm, use_reentrant=False)
        else:
            x = conv_norm_gelu(x, conv, norm)

        t_out = x.shape[-1]

        x = x.reshape(b, s, k, d, t_out)
        return x.permute(0, 4, 1, 2, 3).contiguous()


class SpatialDecoder(nn.Module):
    """
    输入：[B,T,2,64,D]
    输出：[B,T,2,2048,out_features]
    """

    def __init__(self, d_model=128, out_features=3):
        super().__init__()
        self.activation_checkpointing = False

        # 空间长度：64 -> 128 -> 256 -> 512 -> 1024 -> 2048
        channels = [
            d_model,
            d_model,
            96,
            64,
            32,
            out_features,
        ]

        self.convs = nn.ModuleList(
            [
                nn.ConvTranspose1d(
                    c_in,
                    c_out,
                    kernel_size=4,
                    stride=2,
                    padding=1,
                )
                for c_in, c_out in zip(channels[:-1], channels[1:])
            ]
        )

        # 最后一层直接输出重建特征。
        self.norms = nn.ModuleList([nn.LayerNorm(c_out) for c_out in channels[1:-1]])

    def forward(self, x):
        for stage in range(len(self.convs)):
            x = self.forward_stage(x, stage)
        return x

    def forward_stage(self, x, stage):
        b, t, s, k, d = x.shape

        # 各时间步、买卖两侧共享同一个空间 Decoder。
        x = x.permute(0, 1, 2, 4, 3)
        x = x.reshape(b * t * s, d, k)

        conv = self.convs[stage]
        if stage < len(self.norms):
            if (
                self.activation_checkpointing
                and self.training
                and torch.is_grad_enabled()
            ):
                x = checkpoint(
                    conv_norm_gelu, x, conv, self.norms[stage], use_reentrant=False
                )
            else:
                x = conv_norm_gelu(x, conv, self.norms[stage])
        else:
            x = conv(x)

        features, levels = x.shape[1:]

        x = x.reshape(b, t, s, features, levels)
        return x.permute(0, 1, 2, 4, 3).contiguous()


class SpatialLatentExpansion(nn.Module):
    """空间位置查询读取8个局部潜变量；不混合时间，不访问原始输入。"""

    def __init__(
        self, latent_dim=64, d_model=128, spatial_tokens=64, num_queries=8, num_heads=4
    ):
        super().__init__()
        if num_queries <= 0 or num_queries % 2 or latent_dim % num_queries:
            raise ValueError("Spatial queries must be even and divide latent_dim")
        if (2 * spatial_tokens) % num_queries:
            raise ValueError("Spatial tokens must divide evenly into query regions")
        self.latent_dim = latent_dim
        self.num_queries = num_queries
        self.query_dim = latent_dim // num_queries
        self.local_projection = nn.Linear(self.query_dim, d_model)
        self.attention = nn.MultiheadAttention(
            embed_dim=d_model,
            num_heads=num_heads,
            kdim=self.query_dim,
            vdim=self.query_dim,
            batch_first=True,
        )
        self.side_query = nn.Embedding(2, d_model)
        self.level_query = nn.Embedding(spatial_tokens, d_model)
        nn.init.normal_(self.side_query.weight, std=0.02)
        nn.init.normal_(self.level_query.weight, std=0.02)
        self.refine = nn.Sequential(
            nn.LayerNorm(d_model),
            nn.Linear(d_model, 4 * d_model),
            nn.GELU(),
            nn.Linear(4 * d_model, d_model),
        )

    def forward(self, latent):
        if latent.ndim != 3 or latent.shape[-1] != self.latent_dim:
            raise ValueError(
                f"Decoder expects [B,T,{self.latent_dim}], got {tuple(latent.shape)}"
            )
        b, t, _ = latent.shape
        memory = latent.reshape(b * t, self.num_queries, self.query_dim)
        queries = (
            self.side_query.weight[:, None, :] + self.level_query.weight[None, :, :]
        )
        n = queries.shape[0] * queries.shape[1]
        regions = torch.arange(n, device=latent.device) // (n // self.num_queries)
        # 确定的区域对应关系提供局部路径，避免初始均匀交叉注意力再次平均所有档位。
        local = self.local_projection(memory)[:, regions]
        queries = queries.reshape(1, n, -1).to(dtype=local.dtype) + local
        attended, _ = self.attention(queries, memory, memory, need_weights=False)
        x = queries + attended
        return (x + self.refine(x)).reshape(
            b, t, 2, self.level_query.num_embeddings, -1
        )


class OrderBookDecoder(nn.Module):
    """
    输入：[B,16,64]，64 为 latent_dim。
    输出：[B,256,2,2048,out_features]

    先用空间查询读取局部潜变量，再交替恢复档位和时间。
    """

    def __init__(
        self,
        d_model=128,
        out_features=2,
        latent_dim=64,
        spatial_tokens=64,
        num_spatial_queries=8,
        quantity_mode="direct",
        conv_order="alternating",
        structured_latent=False,
    ):
        super().__init__()
        if quantity_mode not in ("direct", "mass-share", "patch-residual"):
            raise ValueError("Unknown quantity decoder mode")
        if quantity_mode != "direct" and out_features != 2:
            raise ValueError(
                "Quantity-specific decoding requires price and quantity outputs"
            )
        if conv_order not in ("alternating", "sequential"):
            raise ValueError("Unknown convolution order")
        self.conv_order = conv_order
        self.latent_expansion = SpatialLatentExpansion(
            latent_dim, d_model, spatial_tokens, num_spatial_queries
        )

        # 编码 S0,T0,...,S4 的逆序：S4^-1,T3^-1,...,T0^-1,S0^-1。
        widths = [d_model, 96, 64, 32]
        self.temporal_decoder = TemporalDecoder(
            d_model, stage_channels=widths if conv_order == "alternating" else None
        )
        self.spatial_decoder = SpatialDecoder(
            d_model=d_model, out_features=out_features
        )
        quantity_width = widths[-1] if conv_order == "alternating" else d_model
        self.quantity_head = (
            RegionalQuantityHead(quantity_width)
            if quantity_mode == "mass-share"
            else None
        )
        self.patch_quantity_head = (
            PatchQuantityResidual(d_model, canonical_grad_layout=structured_latent)
            if quantity_mode == "patch-residual"
            else None
        )
        self.peak_latent_expansion = None
        self.num_spatial_queries = num_spatial_queries
        if structured_latent and self.patch_quantity_head is not None:
            if latent_dim % (2 * num_spatial_queries):
                raise ValueError(
                    "Structured latent must have equal background and peak codes"
                )
            self.peak_latent_expansion = SpatialLatentExpansion(
                latent_dim // 2, d_model, spatial_tokens, num_spatial_queries
            )

    def forward(self, latent):
        x = self.latent_expansion(latent)
        peak_features = x
        if self.peak_latent_expansion is not None:
            b, t, width = latent.shape
            regional = latent.reshape(
                b, t, self.num_spatial_queries, width // self.num_spatial_queries
            )
            peak_code = regional[..., regional.shape[-1] // 2 :].reshape(
                b, t, width // 2
            )
            peak_features = self.peak_latent_expansion(peak_code)
        correction = (
            self.patch_quantity_head(peak_features)
            if self.patch_quantity_head is not None
            else None
        )
        if self.conv_order == "alternating":
            for stage in range(len(self.spatial_decoder.convs)):
                if stage == len(self.spatial_decoder.convs) - 1:
                    quantity_features = x
                x = self.spatial_decoder.forward_stage(x, stage)
                if stage < len(self.temporal_decoder.convs):
                    x = self.temporal_decoder.forward_stage(x, stage)
            output = x
        else:
            quantity_features = self.temporal_decoder(x)
            output = self.spatial_decoder(quantity_features)
        if self.quantity_head is None:
            if correction is not None:
                return torch.stack(
                    (
                        output[..., 0].float(),
                        output[..., 1].float() + correction.float(),
                    ),
                    dim=-1,
                )
            return output
        quantity = self.quantity_head(quantity_features, output[..., 1])
        return torch.stack((output[..., 0].float(), quantity), dim=-1)


if __name__ == "__main__":
    latent = torch.randn(1, 16, 64)

    decoder = OrderBookDecoder(
        d_model=128,
        out_features=2,
    )

    with torch.no_grad():
        output = decoder(latent)

    print(output.size())
    # torch.Size([1, 256, 2, 2048, 2])
