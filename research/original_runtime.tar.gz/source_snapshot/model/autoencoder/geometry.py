"""Encoder-only book geometry; no raw-book side channel reaches the decoder.

Peaks are native-grid local maxima, selected separately on each side. Coordinates
use the existing linear price transform, so nearest-price comparisons need no
additional fitted scale. Selection is discrete; learned embeddings remain trained
by the reconstruction loss.
"""

import torch
from torch import nn
from torch.nn import functional as F
from model.autoencoder.quantity import canonical_gradient_layout


@torch.no_grad()
def book_geometry(x):
    p, q = x[..., 0].float(), x[..., 1].float()
    valid = (q > 0) & torch.isfinite(p) & torch.isfinite(q)
    p = torch.where(valid, p, 0.0)
    q = torch.where(valid, q, 0.0)
    left = F.pad(q[..., :-1], (1, 0))
    right = F.pad(q[..., 1:], (0, 1))
    peak = valid & (q >= left) & (q > right)
    rank = torch.arange(q.shape[-1], device=x.device).expand_as(q).float()
    return dict(
        price=torch.where(valid, p, 0.0),
        count=valid.float(),
        total=q,
        low=torch.where(valid, p, torch.inf),
        high=torch.where(valid, p, -torch.inf),
        peak_q=torch.where(peak, q, 0.0)[..., None],
        peak_p=p[..., None],
        peak_rank=rank[..., None],
    )


@torch.no_grad()
def merge_geometry(state, slots):
    """Merge adjacent spatial cells, keeping original amplitudes and positions."""
    n = state["count"].shape[-1]
    if n % 2:
        raise ValueError("Geometry requires an even number of spatial cells")
    pair = lambda v: v.reshape(*v.shape[:-1], n // 2, 2)
    count = pair(state["count"]).sum(-1)
    price = pair(state["price"] * state["count"]).sum(-1) / count.clamp_min(1)
    candidates = {}
    for key in ("peak_q", "peak_p", "peak_rank"):
        v = state[key]
        candidates[key] = v.reshape(*v.shape[:-2], n // 2, 2 * v.shape[-1])
    peak_q, indices = candidates["peak_q"].topk(
        min(slots, candidates["peak_q"].shape[-1]), -1
    )
    result = dict(
        price=price,
        count=count,
        total=pair(state["total"]).sum(-1),
        low=pair(state["low"]).amin(-1),
        high=pair(state["high"]).amax(-1),
        peak_q=peak_q,
    )
    for key in ("peak_p", "peak_rank"):
        result[key] = candidates[key].gather(-1, indices)
    return result


def anchor_geometry(state):
    # Same causal anchor as stride-2 temporal convolution: t = 2*j+1.
    return {name: value[:, 1::2] for name, value in state.items()}


def geometry_descriptors(state, block_width, slots):
    count, total = state["count"], state["total"]
    present = state["peak_q"] > 0
    center = state["price"]
    region = torch.arange(count.shape[-1], device=count.device)
    offset = (state["peak_rank"] + 0.5) / block_width - region[..., None] - 0.5
    peak = (
        torch.stack(
            (
                state["peak_p"] - center[..., None],
                state["peak_q"],
                offset,
                present.float(),
            ),
            -1,
        )
        * present[..., None]
    )
    # Pack semantic peak tuples, never flatten the raw spatial feature matrix.
    peak = F.pad(peak, (0, 0, 0, slots - peak.shape[-2])).flatten(-2)
    background = torch.stack(
        (
            center,
            total / count.clamp_min(1),
            (total - state["peak_q"].sum(-1)).clamp_min(0) / count.clamp_min(1),
            count / block_width,
        ),
        -1,
    )
    return background, peak


class GeometryEmbedding(nn.Module):
    def __init__(self, width, slots):
        super().__init__()
        self.background = nn.Linear(4, width)
        self.peaks = nn.Linear(4 * slots, width)
        # Learnable residual gains, not fitted price/quantity normalization.
        self.gain = nn.Parameter(torch.full((2,), 0.1))

    def forward(self, state, block_width, slots):
        bg, peaks = geometry_descriptors(state, block_width, slots)
        valid = (state["count"] > 0)[..., None]
        return self.background(bg) * valid * self.gain[0], self.peaks(
            peaks
        ) * valid * self.gain[1]


def align_price_features(features, source, target):
    """Nearest past cell on the same side, zero beyond its observed price range.

    Coordinates/assignments are encoder metadata, while gathered features remain
    differentiable. This aligns finite-width feature cells, not individual orders.
    """
    price, valid = source["price"], source["count"] > 0
    sign = price.new_tensor((-1.0, 1.0)).reshape(1, 1, 2, 1)
    keys = torch.where(valid, price * sign, torch.inf)
    # Sort valid cells before empty ones, including an empty cell inside a side.
    keys, order = keys.sort(dim=-1, stable=True)
    queries = (target["price"] * sign).contiguous()
    index = torch.searchsorted(keys, queries).clamp_max(keys.shape[-1] - 1)
    lower = (index - 1).clamp_min(0)
    upper_distance = (keys.gather(-1, index) - queries).abs()
    lower_distance = (keys.gather(-1, lower) - queries).abs()
    index = torch.where(lower_distance <= upper_distance, lower, index)
    index = order.gather(-1, index)
    aligned = features.gather(
        -2, index[..., None].expand(*index.shape, features.shape[-1])
    )
    low = source["low"].amin(-1, keepdim=True)
    high = source["high"].amax(-1, keepdim=True)
    supported = (
        (target["count"] > 0)
        & (target["price"] >= low)
        & (target["price"] <= high)
        & valid.gather(-1, index)
    )
    return aligned * supported[..., None]


def price_aligned_temporal(x, state, conv, norm, dilation):
    target = anchor_geometry(state)
    anchors = torch.arange(1, x.shape[1], 2, device=x.device)
    y = x[:, 1::2]
    for tap in range(conv.kernel_size[0]):
        times = anchors - (conv.kernel_size[0] - 1 - tap) * dilation
        indices = times.clamp_min(0)
        source = {
            name: state[name].index_select(1, indices)
            for name in ("price", "count", "low", "high")
        }
        features = align_price_features(x.index_select(1, indices), source, target)
        features = features * (times >= 0)[None, :, None, None, None]
        y = y + F.linear(
            features, conv.weight[:, :, tap], conv.bias if tap == 0 else None
        )
    return F.gelu(norm(y))


class StructuredSpatialPool(nn.Module):
    """8 local regions × (4 background + 4 peak features) = 64, per time."""

    def __init__(self, d_model=128, latent_dim=64, num_queries=8):
        super().__init__()
        if num_queries <= 0 or num_queries % 2 or latent_dim % (2 * num_queries):
            raise ValueError(
                "Structured latent requires equal background/peak codes per region"
            )
        self.num_queries = num_queries
        self.branch_dim = latent_dim // (2 * num_queries)
        for branch in ("background", "peak"):
            query = nn.Parameter(torch.empty(1, num_queries, self.branch_dim))
            nn.init.normal_(query, std=0.02)
            query.register_hook(canonical_gradient_layout)
            setattr(self, branch + "_query", query)
            setattr(
                self,
                branch + "_attention",
                nn.MultiheadAttention(
                    self.branch_dim, 1, kdim=d_model, vdim=d_model, batch_first=True
                ),
            )
            setattr(self, branch + "_projection", nn.Linear(d_model, self.branch_dim))
        self.norm = nn.LayerNorm(latent_dim)

    def forward(self, x, background, peaks):
        b, t, n, d = x.shape
        if n % self.num_queries:
            raise ValueError("Spatial tokens must divide evenly into query regions")
        regions = torch.arange(n, device=x.device) // (n // self.num_queries)
        mask = (
            torch.arange(self.num_queries, device=x.device)[:, None] != regions[None, :]
        )
        codes = []
        for branch, descriptors in (("background", background), ("peak", peaks)):
            tokens = (x + descriptors).reshape(b * t, n, d)
            query = (
                getattr(self, branch + "_query").expand(b * t, -1, -1).to(tokens.dtype)
            )
            attended, _ = getattr(self, branch + "_attention")(
                query, tokens, tokens, attn_mask=mask, need_weights=False
            )
            local = tokens.reshape(b * t, self.num_queries, n // self.num_queries, d)
            reduced = local.mean(-2) if branch == "background" else local.amax(-2)
            codes.append(attended + getattr(self, branch + "_projection")(reduced))
        return self.norm(torch.cat(codes, -1).reshape(b, t, -1))
