"""Fixed one-dimensional peak proposals before any learned downsampling.

Soft-NMS here adapts Gaussian score decay to overlap in a price-distance
neighborhood. This is not the box-IoU operator in the original paper.
Only proposal ranking scores decay; quantities and input books are untouched.
"""

import math

import torch
from torch import nn
from torch.nn import functional as F


class PeakFeatures(nn.Module):
    channels = 4

    def __init__(
        self,
        mode="zero",
        per_region=8,
        candidates=32,
        regions=4,
        radius_bps=0.5,
        sigma=0.5,
        price_scale=100000.0,
        price_normalization="absolute",
    ):
        super().__init__()
        if mode not in ("zero", "topk", "soft-nms"):
            raise ValueError("Unknown peak proposal mode")
        if not 0 < per_region <= candidates or regions <= 0:
            raise ValueError(
                "Require 0 < peaks per region <= candidates and positive regions"
            )
        if any(
            not math.isfinite(v) or v <= 0 for v in (radius_bps, sigma, price_scale)
        ):
            raise ValueError(
                "Peak distance and normalization scales must be positive and finite"
            )
        if price_normalization not in ("absolute", "window-anchor"):
            raise ValueError("Unknown peak price normalization")
        self.mode, self.per_region, self.candidates, self.regions = (
            mode,
            per_region,
            candidates,
            regions,
        )
        self.radius_bps, self.sigma = radius_bps, sigma
        self.price_scale, self.price_normalization = price_scale, price_normalization

    @torch.no_grad()
    def forward(self, x):
        b, t, sides, levels, features = x.shape
        if sides != 2 or features != 2 or levels % self.regions:
            raise ValueError(
                "Peaks require two price/quantity sides and equal depth regions"
            )
        extra = x.new_zeros(b * t * sides, levels, self.channels)
        if self.mode == "zero":
            return extra.reshape(b, t, sides, levels, self.channels)
        # Native precision is FP32 even under autocast; no trainable ranking or
        # differentiation through discrete selection is claimed.
        price = x[..., 0].float().reshape(-1, levels)
        quantity = x[..., 1].float().reshape(-1, levels)
        valid = torch.isfinite(price) & torch.isfinite(quantity) & (quantity > 0)
        price = price.masked_fill(~valid, 0)
        q = quantity.masked_fill(~valid, 0)
        left = F.pad(q[:, :-1], (1, 0))
        right = F.pad(q[:, 1:], (0, 1))
        # Rightmost point of a flat summit wins; no temporal comparisons.
        candidate = valid & (q >= left) & (q > right)
        size = levels // self.regions
        score = q.masked_fill(~candidate, 0).reshape(-1, size)
        m = min(self.candidates, size)
        score, local = score.topk(m, dim=-1, sorted=True)
        indices = (
            local.reshape(-1, self.regions, m)
            + torch.arange(self.regions, device=x.device)[None, :, None] * size
        )
        flat_indices = indices.reshape(-1, self.regions * m)
        candidate_price = price.gather(1, flat_indices).reshape(-1, m)
        midpoint = x[:, :, :, 0, 0].float().mean(-1).reshape(-1, 1, 1)
        if self.price_normalization == "window-anchor":
            conversion = self.price_scale / (1 + midpoint * self.price_scale / 10000.0)
        else:
            conversion = 10000.0 / midpoint.clamp_min(1e-12)
        conversion = conversion.expand(-1, sides, self.regions).reshape(-1, 1)
        positions, active = [], []
        work = score.clone()
        for _ in range(min(self.per_region, m)):
            maximum, selected = work.max(dim=-1)
            positions.append(selected)
            active.append(maximum > 0)
            if self.mode == "soft-nms":
                center = candidate_price.gather(1, selected[:, None])
                distance = (candidate_price - center).abs() * conversion
                overlap = (1 - distance / self.radius_bps).clamp_min(0)
                work *= torch.exp(-overlap.square() / self.sigma)
            work.scatter_(1, selected[:, None], 0)
        positions = torch.stack(positions, dim=-1)
        active = torch.stack(active, dim=-1).reshape(price.shape[0], -1)
        selected = (
            indices.reshape(-1, m).gather(1, positions).reshape(price.shape[0], -1)
        )
        amounts = q.gather(1, selected)
        selected_prices = price.gather(1, selected)
        # Local half-height width, clipped at four adjacent levels per side.
        width = torch.ones_like(amounts)
        for direction in (-1, 1):
            connected = active.clone()
            for step in range(1, 5):
                neighbor = selected + direction * step
                inside = (neighbor >= 0) & (neighbor < levels)
                values = q.gather(1, neighbor.clamp(0, levels - 1))
                connected &= inside & (values >= amounts * 0.5)
                width += connected
        values = torch.stack(
            (active.float(), amounts, selected_prices, width / 9.0), dim=-1
        )
        values = values.masked_fill(~active[..., None], 0).to(dtype=x.dtype)
        # Inactive proposals have index zero; scatter_add keeps them from
        # overwriting an actual selected peak at level zero.
        extra.scatter_add_(1, selected[..., None].expand(-1, -1, self.channels), values)
        return extra.reshape(b, t, sides, levels, self.channels)


def add_peak_input_channels(conv):
    """Zero extra weights preserve every common parameter and initial output."""
    with torch.random.fork_rng(devices=[]):
        extended = nn.Conv1d(
            conv.in_channels + PeakFeatures.channels,
            conv.out_channels,
            conv.kernel_size,
            stride=conv.stride,
            padding=conv.padding,
            dilation=conv.dilation,
            bias=conv.bias is not None,
        )
    with torch.no_grad():
        extended.weight.zero_()
        extended.weight[:, : conv.in_channels].copy_(conv.weight)
        if conv.bias is not None:
            extended.bias.copy_(conv.bias)
    return extended
