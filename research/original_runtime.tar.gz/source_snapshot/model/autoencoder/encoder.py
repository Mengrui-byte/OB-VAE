"""Order-book encoder: convolutions, learned positions, spatial attention."""

import torch
from torch import nn

from model.autoencoder.conv import SpatialConv, TemporalConv
from model.autoencoder.peaks import PeakFeatures, add_peak_input_channels
from model.autoencoder.geometry import (
    book_geometry,
    merge_geometry,
    anchor_geometry,
    GeometryEmbedding,
    StructuredSpatialPool,
)


class PositionalEmbedding(nn.Module):
    """为 [B,T,S,K,D] 加上可学习的时间、买卖侧及空间位置编码。"""

    def __init__(self, d_model=128, max_time=16, max_spatial=64):
        super().__init__()
        self.time_embedding = nn.Embedding(max_time, d_model)
        self.side_embedding = nn.Embedding(2, d_model)
        self.spatial_embedding = nn.Embedding(max_spatial, d_model)

        for embedding in (
            self.time_embedding,
            self.side_embedding,
            self.spatial_embedding,
        ):
            nn.init.normal_(embedding.weight, mean=0.0, std=0.02)

    def forward(self, x):
        # x: [B,T,S,K,D]；S=2，K 为每侧的空间 token 数。
        _, t, s, k, _ = x.shape
        time = self.time_embedding(torch.arange(t, device=x.device))
        side = self.side_embedding(torch.arange(s, device=x.device))
        spatial = self.spatial_embedding(torch.arange(k, device=x.device))

        position = (
            time[None, :, None, None, :]
            + side[None, None, :, None, :]
            + spatial[None, None, None, :, :]
        )
        return x + position.to(dtype=x.dtype)


class SpatialAttentionPool(nn.Module):
    """每侧按深度分区，各查询只聚合本区；时间位置保持独立。"""

    def __init__(self, d_model=128, latent_dim=64, num_heads=4, num_queries=8):
        super().__init__()
        if num_queries <= 0 or num_queries % 2 or latent_dim % num_queries:
            raise ValueError("Spatial queries must be even and divide latent_dim")
        self.num_queries = num_queries
        self.query_dim = latent_dim // num_queries
        if self.query_dim % num_heads:
            raise ValueError(
                "Features per spatial query must be divisible by num_heads"
            )
        self.query = nn.Parameter(torch.empty(1, num_queries, self.query_dim))
        nn.init.normal_(self.query, mean=0.0, std=0.02)
        self.attention = nn.MultiheadAttention(
            embed_dim=self.query_dim,
            num_heads=num_heads,
            kdim=d_model,
            vdim=d_model,
            batch_first=True,
        )
        self.norm = nn.LayerNorm(latent_dim)

    def forward(self, x):
        if x.ndim != 4 or x.shape[-1] != self.attention.kdim:
            raise ValueError("Spatial pool expects [B,T,spatial_tokens,d_model]")
        b, t, n, d = x.shape
        if n % self.num_queries:
            raise ValueError("Spatial tokens must divide evenly into query regions")
        # B*T 是独立样本轴；注意力序列始终只有当前时刻的空间 token。
        tokens = x.reshape(b * t, n, d)
        query = self.query.expand(b * t, -1, -1).to(dtype=x.dtype)
        # 原有 token 顺序为 bid[0:64], ask[64:128]；默认每侧四区、每区16个。
        regions = torch.arange(n, device=x.device) // (n // self.num_queries)
        mask = (
            torch.arange(self.num_queries, device=x.device)[:, None] != regions[None, :]
        )
        pooled, _ = self.attention(
            query, tokens, tokens, attn_mask=mask, need_weights=False
        )
        # 已由局部注意力压缩为8×8，此处只打包存储；没有展平输入的 N×D。
        # 在完整64维上归一化，保留不同分区之间的相对幅度。
        return self.norm(pooled.reshape(b, t, -1))


class OrderBookEncoder(nn.Module):
    """订单簿 -> 交替空间/因果时间卷积 -> 位置编码 -> 空间注意力。

    默认输入：[B,256,2,2048,2]，两侧均按最优报价到远端排序。
    默认输出：[B,16,64]，每个时间位置包含8个局部查询、各8维。
    时间长度必须是 16 的倍数；压缩后长度不超过 max_time。
    注意力后只聚合空间 token，16 个压缩时间位置保持独立。
    """

    def __init__(
        self,
        in_features=2,
        d_model=128,
        num_heads=4,
        dropout=0.1,
        max_time=16,
        max_spatial=64,
        latent_dim=64,
        num_spatial_queries=8,
        conv_order="alternating",
        peak_mode="none",
        peak_per_region=8,
        peak_candidates=32,
        peak_radius_bps=0.5,
        peak_sigma=0.5,
        peak_price_scale=100000.0,
        peak_price_normalization="absolute",
        book_structure="legacy",
        local_peak_slots=4,
    ):
        super().__init__()
        if conv_order not in ("alternating", "sequential"):
            raise ValueError("Unknown convolution order")
        self.conv_order = conv_order
        if book_structure not in ("legacy", "multipeak", "price-aligned"):
            raise ValueError("Unknown book structure")
        if local_peak_slots not in (2, 4):
            raise ValueError("Local peak slots must be 2 or 4")
        if book_structure != "legacy" and (
            conv_order != "alternating" or in_features != 2 or peak_mode != "none"
        ):
            raise ValueError(
                "Structured books require alternating price/quantity convolutions and peak-mode none"
            )
        self.book_structure = book_structure
        self.local_peak_slots = local_peak_slots
        self.spatial_conv = SpatialConv(in_features, d_model)
        widths = [layer.out_channels for layer in self.spatial_conv.convs[:-1]]
        self.temporal_conv = TemporalConv(
            d_model, stage_channels=widths if conv_order == "alternating" else None
        )
        self.position = PositionalEmbedding(d_model, max_time, max_spatial)

        # 每个压缩时间位置内，买卖两侧的全部空间 token 共同参与注意力。
        self.spatial_attention = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=num_heads,
            dim_feedforward=4 * d_model,
            dropout=dropout,
            activation="gelu",
            batch_first=True,
            norm_first=True,
        )
        self.output_norm = nn.LayerNorm(d_model)
        self.spatial_pool = SpatialAttentionPool(
            d_model, latent_dim, num_heads, num_spatial_queries
        )
        if peak_mode not in ("none", "zero", "topk", "soft-nms"):
            raise ValueError("Unknown peak mode")
        self.peak_features = None
        if peak_mode != "none":
            if in_features != 2:
                raise ValueError("Peak features require price and quantity inputs")
            self.peak_features = PeakFeatures(
                peak_mode,
                peak_per_region,
                peak_candidates,
                radius_bps=peak_radius_bps,
                sigma=peak_sigma,
                price_scale=peak_price_scale,
                price_normalization=peak_price_normalization,
            )
            self.spatial_conv.convs[0] = add_peak_input_channels(
                self.spatial_conv.convs[0]
            )
        # Legacy construction and RNG order remain unchanged for frozen checkpoints.
        if book_structure != "legacy":
            self.geometry_embeddings = nn.ModuleList(
                [
                    GeometryEmbedding(layer.out_channels, local_peak_slots)
                    for layer in self.spatial_conv.convs
                ]
            )
            self.spatial_pool = StructuredSpatialPool(
                d_model, latent_dim, num_spatial_queries
            )

    def forward(self, x):
        if x.ndim != 5 or x.shape[1] < 16 or x.shape[1] % 16:
            raise ValueError(
                "Encoder expects [B,T,S,L,F] with T a positive multiple of16"
            )
        if self.peak_features is not None:
            x = torch.cat((x, self.peak_features(x)), dim=-1)
        geometry = book_geometry(x) if self.book_structure != "legacy" else None
        if self.conv_order == "alternating":
            # S0,T0,S1,T1,S2,T2,S3,T3,S4；四次时间下采样仍对齐16*j+15。
            for stage in range(len(self.spatial_conv.convs)):
                x = self.spatial_conv.forward_stage(x, stage)
                if geometry is not None:
                    geometry = merge_geometry(geometry, self.local_peak_slots)
                    background, peaks = self.geometry_embeddings[stage](
                        geometry, 2 ** (stage + 1), self.local_peak_slots
                    )
                    x = x + background.to(x.dtype) + peaks.to(x.dtype)
                if stage < len(self.temporal_conv.convs):
                    x = self.temporal_conv.forward_stage(
                        x,
                        stage,
                        geometry if self.book_structure == "price-aligned" else None,
                    )
                    if geometry is not None:
                        geometry = anchor_geometry(geometry)
        else:
            x = self.temporal_conv(self.spatial_conv(x))
        x = self.position(x)  # [B,16,2,64,128]

        b, t, s, k, d = x.shape
        # 时间合并到 batch，注意力只在同一时间位置内计算。
        # 前 k 个空间 token 为 bid，后 k 个为 ask。
        x = x.reshape(b * t, s * k, d)
        x = self.spatial_attention(x)
        x = self.output_norm(x)
        if geometry is not None:
            return self.spatial_pool(
                x.reshape(b, t, s * k, d),
                background.reshape(b, t, s * k, d),
                peaks.reshape(b, t, s * k, d),
            )
        return self.spatial_pool(x.reshape(b, t, s * k, d))


if __name__ == "__main__":
    x = torch.randn(1, 256, 2, 2048, 2)

    model = OrderBookEncoder(
        in_features=2,
        d_model=128,
        num_heads=4,
    )

    with torch.no_grad():
        output = model(x)

    print(output.size())  # [1, 16, 64]
