"""Nonnegative regional quantity reconstruction without extra input information."""

import math

import torch
from torch import nn
from torch.nn import functional as F


def canonical_gradient_layout(gradient):
    # ConvTranspose2d can give a singleton channel stride of 1 rather than H*W.
    # Values are identical, but DDP otherwise warns about bucket-layout mismatch.
    stride, expected = 1, []
    for size in reversed(gradient.shape):
        expected.insert(0, stride)
        stride *= size
    return (
        gradient
        if gradient.stride() == tuple(expected)
        else gradient.clone(memory_format=torch.contiguous_format)
    )


class PatchQuantityResidual(nn.Module):
    """Short learned upsampling path from latent-expanded spatial features.

    Each compressed time/space position generates a16-minute x32-level patch.
    This is a transposed convolution, without flattening input tokens/channels
    or bypassing the compact latent. Zero initialization preserves baseline output.
    """

    def __init__(self, d_model=128, canonical_grad_layout=False):
        super().__init__()
        self.features = nn.Conv2d(d_model, 2 * d_model, kernel_size=1)
        self.output = nn.ConvTranspose2d(
            2 * d_model, 1, kernel_size=(16, 32), stride=(16, 32)
        )
        nn.init.zeros_(self.output.weight)
        nn.init.zeros_(self.output.bias)
        if canonical_grad_layout:
            self.output.weight.register_hook(canonical_gradient_layout)

    def forward(self, x):
        b, t, s, k, d = x.shape
        features = x.permute(0, 2, 4, 1, 3).reshape(b * s, d, t, k)
        output = self.output(F.gelu(self.features(features)))
        return output.reshape(b, s, t * 16, k * 32).permute(0, 2, 1, 3).contiguous()


class RegionalQuantityHead(nn.Module):
    """Predict regional mass and level shares from decoded latent features only.

    For each time/side/depth region: quantity = predicted mass * softmax(scores).
    Prices and dataset linear scaling are unaffected. No true volumes or counts
    are provided to the decoder; all nominal output levels participate in softmax.
    """

    def __init__(self, d_model=128, regions_per_side=4):
        super().__init__()
        if regions_per_side <= 0:
            raise ValueError("regions_per_side must be positive")
        self.regions_per_side = regions_per_side
        self.mass_projection = nn.Linear(d_model, 1)
        nn.init.zeros_(self.mass_projection.weight)
        # Initial normalized quantity mean0.1; this is head initialization, not a data scale.
        nn.init.constant_(self.mass_projection.bias, math.log(math.expm1(0.1)))

    def forward(self, features, scores):
        # features[B,T,2,64,D], scores[B,T,2,2048]; regions do not mix time or sides.
        if (
            features.ndim != 5
            or scores.ndim != 4
            or features.shape[:3] != scores.shape[:3]
        ):
            raise ValueError(
                "Expected matching [B,T,S,K,D] features and [B,T,S,L] scores"
            )
        b, t, s, k, d = features.shape
        levels = scores.shape[-1]
        r = self.regions_per_side
        if k % r or levels % r:
            raise ValueError(
                "Feature tokens and levels must divide evenly into regions"
            )
        regional_features = features.reshape(b, t, s, r, k // r, d).mean(dim=-2)
        mean_quantity = F.softplus(
            self.mass_projection(regional_features).float().squeeze(-1)
        )
        mass = mean_quantity * (levels // r)
        shares = F.softmax(scores.float().reshape(b, t, s, r, levels // r), dim=-1)
        return (mass[..., None] * shares).reshape_as(scores)


def regional_quantity_losses(prediction, target, mask, regions_per_side=4):
    """Auxiliary regional mean-quantity MSE and volume-share KL in scaled units.

    Padding has zero target mass/share; prediction is normalized over nominal
    output levels, so this objective also discourages mass placed on padding.
    Regions with zero true mass have no share-distribution target and skip KL.
    """
    if prediction.shape != target.shape or mask.shape != target.shape:
        raise ValueError("Prediction, target and mask shapes must match")
    if target.shape[-1] % regions_per_side:
        raise ValueError("Levels must divide evenly into regions")
    r = regions_per_side
    n = target.shape[-1] // r
    shape = (*target.shape[:-1], r, n)
    p = prediction.float().reshape(shape)
    y = target.float().masked_fill(~mask, 0).reshape(shape)
    p_mass, y_mass = p.sum(-1), y.sum(-1)
    mean_mse = ((p_mass - y_mass) / n).square().mean()
    active = y_mass > 0
    shares = y / y_mass.clamp_min(1e-12)[..., None]
    log_shares = p.clamp_min(1e-12).log() - p_mass.clamp_min(1e-12).log()[..., None]
    kl = F.kl_div(log_shares, shares, reduction="none").sum(-1)
    distribution_kl = kl.masked_fill(~active, 0).sum() / active.sum().clamp_min(1)
    return mean_mse, distribution_kl
