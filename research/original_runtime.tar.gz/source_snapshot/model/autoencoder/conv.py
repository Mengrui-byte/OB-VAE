"""Spatial and causal temporal convolutions for limit order books."""

import torch
from torch import nn
from torch.nn import functional as F
from torch.utils.checkpoint import checkpoint
from model.autoencoder.geometry import price_aligned_temporal


def conv_norm_gelu(x, conv, norm):
    x = conv(x)
    x = norm(x.transpose(1, 2)).transpose(1, 2)
    return F.gelu(x)


def temporal_norm_gelu(x, conv, norm, dilation):
    # 左侧补零；每次下采样的输出 j 对齐到输入 2*j+1。
    y = conv(F.pad(x, (4 * dilation - 1, 0))) + x[..., 1::2]
    return F.gelu(norm(y.transpose(1, 2)).transpose(1, 2))


class SpatialConv(nn.Module):
    """沿订单簿档位轴卷积，两侧和所有时间步共享参数。

    输入：[B, T, S, L, in_features]，S=2，两侧均从最优报价向外排列。
    输出：[B, T, S, K, d_model]，L=2048 时 K=64。
    """

    def __init__(self, in_features=2, d_model=128):
        super().__init__()
        self.activation_checkpointing = False
        channels = [in_features, 32, 64, 96, d_model, d_model]
        self.convs = nn.ModuleList(
            [
                nn.Conv1d(c_in, c_out, kernel_size=5, stride=2, padding=2)
                for c_in, c_out in zip(channels[:-1], channels[1:])
            ]
        )
        self.norms = nn.ModuleList([nn.LayerNorm(c_out) for c_out in channels[1:]])

    def forward(self, x):
        for stage in range(len(self.convs)):
            x = self.forward_stage(x, stage)
        return x

    def forward_stage(self, x, stage):
        """只执行一层空间卷积，供时空交替调度使用。"""
        b, t, s, levels, features = x.shape
        # 每个快照的每一侧作为一个样本，沿 L 卷积。
        x = x.permute(0, 1, 2, 4, 3).reshape(b * t * s, features, levels)

        conv, norm = self.convs[stage], self.norms[stage]
        if self.activation_checkpointing and self.training and torch.is_grad_enabled():
            x = checkpoint(conv_norm_gelu, x, conv, norm, use_reentrant=False)
        else:
            x = conv_norm_gelu(x, conv, norm)

        d, k = x.shape[1:]
        x = x.reshape(b, t, s, d, k)
        return x.permute(0, 1, 2, 4, 3).contiguous()


class TemporalConv(nn.Module):
    """各空间位置共享的因果时间卷积，时间压缩 16 倍。

    输入：[B, T, S, K, d_model]，T 必须是 16 的倍数。
    输出：[B, T//16, S, K, d_model]。
    输出时间位置 j 对应原输入索引 16*j+15，仅依赖该时刻及之前。
    """

    def __init__(self, d_model=128, stage_channels=None):
        super().__init__()
        self.activation_checkpointing = False
        self.dilations = (1, 2, 4, 8)
        channels = [d_model] * 4 if stage_channels is None else list(stage_channels)
        if len(channels) != 4:
            raise ValueError("Temporal convolution requires four stage widths")
        self.convs = nn.ModuleList(
            [
                nn.Conv1d(
                    width,
                    width,
                    kernel_size=5,
                    stride=2,
                    dilation=dilation,
                    padding=0,
                )
                for width, dilation in zip(channels, self.dilations)
            ]
        )
        self.norms = nn.ModuleList([nn.LayerNorm(width) for width in channels])

    def forward(self, x):
        for stage in range(len(self.convs)):
            x = self.forward_stage(x, stage)
        return x

    def forward_stage(self, x, stage, geometry=None):
        """执行一层因果时间卷积；可先按价格对齐历史空间特征。"""
        if geometry is not None:
            args = (
                x,
                geometry,
                self.convs[stage],
                self.norms[stage],
                self.dilations[stage],
            )
            if (
                self.activation_checkpointing
                and self.training
                and torch.is_grad_enabled()
            ):
                return checkpoint(price_aligned_temporal, *args, use_reentrant=False)
            return price_aligned_temporal(*args)
        b, t, s, k, d = x.shape
        # 每个空间位置作为一个样本，沿 T 卷积。
        x = x.permute(0, 2, 3, 4, 1).reshape(b * s * k, d, t)

        conv, norm, dilation = (
            self.convs[stage],
            self.norms[stage],
            self.dilations[stage],
        )
        if self.activation_checkpointing and self.training and torch.is_grad_enabled():
            x = checkpoint(
                temporal_norm_gelu, x, conv, norm, dilation, use_reentrant=False
            )
        else:
            x = temporal_norm_gelu(x, conv, norm, dilation)

        t_out = x.shape[-1]
        x = x.reshape(b, s, k, d, t_out)
        return x.permute(0, 4, 1, 2, 3).contiguous()


if __name__ == "__main__":
    x = torch.randn(1, 256, 2, 2048, 2)

    spatial = SpatialConv(in_features=2, d_model=128)
    temporal = TemporalConv(d_model=128)

    with torch.no_grad():
        spatial_output = spatial(x)
        output = temporal(spatial_output)

    print(spatial_output.size())  # [1, 256, 2, 64, 128]
    print(output.size())  # [1, 16, 2, 64, 128]
