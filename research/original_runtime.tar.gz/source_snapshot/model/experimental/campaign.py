"""Catalog and common initialization for all weekly-report order-book ideas."""

import torch
from torch import nn
from torch.nn import functional as F
from model.experimental.variants import make_base
from model.experimental.keypoint_fusion import NativeKeypoints, keypoint_losses
from model.experimental.latent_keypoints import LatentKeypoints, latent_price_loss
from model.losses.peaks import main_peak_loss
from model.experimental.pair_refine import (
    PairRefiner,
    proposal_features,
    reconstruct,
    pair_labels,
    paired_losses,
    assignment,
)
from model.experimental.operators import (
    TemporalOperator,
    SpatialOperator,
    SliceAttention,
    SnakeOperator,
    PoolBranch,
)


def catalog():
    variants = {"baseline": {}}
    for n in [4, 8, 16, 32]:
        variants[f"slice_{n}"] = dict(slices=[n])
    temporal = ["exp", "gamma", "s4d", "ckconv", "hyena", "wavelet"]
    spatial = [
        "multiscale",
        "gaussian",
        "bilateral",
        "coordinate",
        "wavelet",
        "queue_prior",
    ]
    for kind in temporal:
        variants["time_" + kind] = dict(temporal=[kind])
    for kind in spatial:
        variants["space_" + kind] = dict(spatial=[kind])
    variants.update(
        snake_causal=dict(snake=True), snake_reconstruction=dict(snake=False)
    )
    for kind in ["linear", "mlp", "kan"]:
        variants["pool_" + kind] = dict(pools=[kind])
    variants.update(
        keypoint_fusion=dict(keypoints=True),
        latent_peak=dict(latent=True),
        window_balanced=dict(window_balanced=True),
        hard_background=dict(hard_background=True),
        peak_price=dict(peak_price=True),
    )
    for kind in ["book", "rank", "hungarian", "no_background"]:
        variants["pair_" + kind] = dict(pair=kind)
    full = dict(
        temporal=temporal,
        spatial=spatial,
        slices=[4, 8, 16, 32],
        pools=["linear", "mlp", "kan"],
        snake=True,
        keypoints=True,
        latent=True,
        window_balanced=True,
        hard_background=True,
        peak_price=True,
        pair="hungarian",
    )
    variants["combined_all_causal"] = full
    variants["combined_all_reconstruction"] = {**full, "snake": False}
    variants["combined_compact"] = dict(
        temporal=["exp"],
        spatial=["multiscale"],
        slices=[8],
        pools=["kan"],
        keypoints=True,
        window_balanced=True,
        pair="hungarian",
    )
    return variants


class ResearchModel(nn.Module):
    def __init__(self, initial, warm, config, quantity_scale, slots):
        super().__init__()
        self.config = config
        self.slots = slots
        self.coordinates = None
        self.base = make_base(initial)
        self.base.load_state_dict(
            {
                k.removeprefix("base."): v
                for k, v in warm["model_state_dict"].items()
                if k.startswith("base.")
            },
            strict=True,
        )
        self.early_operators = nn.ModuleList(
            [TemporalOperator(k, 96) for k in config.get("temporal", [])]
            + ([SnakeOperator(config["snake"], 96)] if "snake" in config else [])
        )
        self.operators = nn.ModuleList(
            [SpatialOperator(k) for k in config.get("spatial", [])]
            + [SliceAttention(n) for n in config.get("slices", [])]
        )
        self.pools = nn.ModuleList([PoolBranch(k) for k in config.get("pools", [])])
        self.keypoints = NativeKeypoints() if config.get("keypoints") else None
        self.latent_head = LatentKeypoints() if config.get("latent") else None
        self.pair_head = PairRefiner(quantity_scale) if config.get("pair") else None
        self.base.encoder.position.register_forward_hook(self.apply_operators)
        self.base.encoder.spatial_conv.norms[2].register_forward_hook(self.apply_early)
        self.base.encoder.spatial_pool.register_forward_hook(self.apply_pools)
        if self.keypoints is not None:
            self.base.encoder.spatial_conv.norms[0].register_forward_hook(
                self.inject_keypoints
            )
        self.keypoint_output = None
        self.latent_output = None
        self.point_output = None
        self.point_indices = None

    def apply_operators(self, module, args, output):
        for operator in self.operators:
            output = operator(output, self.coordinates)
        return output

    def apply_early(self, module, args, output):
        # After two temporal reductions:64 time positions,256 native-rank cells.
        # Kernels therefore operate before the remaining time compression.
        if not self.early_operators:
            return output
        n, l, d = output.shape
        y = output.reshape(self.input_batch, n // (2 * self.input_batch), 2, l, d)
        for operator in self.early_operators:
            y = operator(y)
        return y.reshape_as(output)

    def apply_pools(self, module, args, output):
        for pool in self.pools:
            output = output + pool(args[0])
        return output

    def inject_keypoints(self, module, args, output):
        return output + self.keypoint_output["fusion"].to(output.dtype)

    def forward(self, x):
        self.input_batch = x.shape[0]
        if "coordinate" in self.config.get("spatial", []):
            anchor = x[:, 15::16]
            valid = (anchor[..., 1] > 0).reshape(*anchor.shape[:3], 64, 32)
            p = anchor[..., 0].reshape_as(valid)
            self.coordinates = (p * valid).sum(-1) / valid.sum(-1).clamp_min(1)
        if self.keypoints is not None:
            self.keypoint_output = self.keypoints(x)
        z = self.base.encoder(x)
        self.last_latent = z
        self.latent_output = (
            self.latent_head(z) if self.latent_head is not None else None
        )
        book = self.base.decoder(z)
        if self.pair_head is not None:
            indices, points, features = proposal_features(z, book, self.slots)
            self.point_output = self.pair_head(features, points)
            self.point_indices = indices
            book = reconstruct(dict(base=book, indices=indices), self.point_output)
        return book


def objective(model, prediction, x, context, target, scale, normalizer):
    config = model.config
    book = normalizer.loss_sum(prediction, x, context) / context["mask"].sum()
    if config.get("window_balanced"):
        positive = target["centers"] & context["mask"]
        n = positive.flatten(1).sum(1)
        e = F.smooth_l1_loss(
            prediction[..., 1], x[..., 1], reduction="none"
        ).masked_fill(~positive, 0).flatten(1).sum(1) / n.clamp_min(1)
        peak = e[n > 0].mean() if bool((n > 0).any()) else e.sum() * 0
    else:
        peak = main_peak_loss(prediction, x, target["centers"], context["mask"])
    loss = book + 0.1 * peak
    pieces = dict(book=book, peak=peak)
    if config.get("hard_background"):
        valid = context["mask"] & ~target["centers"]
        error = (
            (prediction[..., 1] - x[..., 1]).square().masked_fill(~valid, 0).flatten()
        )
        hard = error.topk(min(4096, len(error))).values.mean()
        loss = loss + 0.01 * hard
        pieces["hard_background"] = hard
    if config.get("peak_price"):
        error = (prediction[..., 0] - x[..., 0]) * scale
        p = F.smooth_l1_loss(
            error, torch.zeros_like(error), reduction="none"
        ).masked_fill(~target["centers"], 0).sum() / target["centers"].sum().clamp_min(
            1
        )
        loss = loss + 0.001 * p
        pieces["peak_price"] = p
    for kind, output in [
        ("input", model.keypoint_output),
        ("latent", model.latent_output),
    ]:
        if output is not None:
            for key, value in keypoint_losses(output, target).items():
                loss = loss + (0.1 if key == "detection" else 0.01) * value
                pieces[kind + "_" + key] = value
            if kind == "latent":
                p = latent_price_loss(output, x, target["centers"], scale)
                loss = loss + 0.001 * p
                pieces["latent_price"] = p
    if model.pair_head is not None and config["pair"] != "book":
        labels = pair_labels(
            model.point_indices, x, context["mask"], target["centers"], scale
        )
        kind = "rank" if config["pair"] == "rank" else "hungarian"
        if kind == "rank":
            labels["rank_assignment"] = assignment(labels, None, "rank")
        for key, value in paired_losses(
            labels,
            model.point_output,
            kind,
            0.0 if config["pair"] == "no_background" else 0.1,
        ).items():
            loss = (
                loss + dict(price=0.01, quantity=0.1, classification=1.0)[key] * value
            )
            pieces["pair_" + key] = value
    return loss, pieces
