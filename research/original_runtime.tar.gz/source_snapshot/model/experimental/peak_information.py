"""Controlled pooling and minute-coordinate interventions; decoder sees only z."""

import copy
import math
import torch
from torch import nn
from torch.nn import functional as F
from model.experimental.variants import make_base
from model.experimental.pair_refine import PairRefiner, proposal_features, reconstruct


ARMS = {
    "A_reference": dict(coherent=False, minute=False),
    "B_coherent_pool": dict(coherent=True, minute=False),
    "C_minute": dict(coherent=False, minute=True),
    "D_pool_minute": dict(coherent=True, minute=True),
}


class CoherentPool(nn.Module):
    """Replace channelwise max by gathering ONE complete spatial-cell vector.

    Selection uses the largest input local peak in each region, without a label
    threshold. All learned weights and the attention path match the reference.
    A cell contains up to four encoded peak tuples: this is not lossless top-K
    serialization. Input geometry is encoder-only and is never sent to decoder.
    """

    def __init__(self, original):
        super().__init__()
        self.inner = original
        self.score = None

    def forward(self, x, background, peaks):
        b, t, n, d = x.shape
        pool = self.inner
        q = pool.num_queries
        if self.score is None or self.score.shape != (b, t, n):
            raise ValueError("Geometry context must be refreshed for this batch")
        regions = torch.arange(n, device=x.device) // (n // q)
        mask = torch.arange(q, device=x.device)[:, None] != regions[None, :]
        codes = []
        for branch, descriptors in [("background", background), ("peak", peaks)]:
            tokens = (x + descriptors).reshape(b * t, n, d)
            query = (
                getattr(pool, branch + "_query").expand(b * t, -1, -1).to(tokens.dtype)
            )
            attended, _ = getattr(pool, branch + "_attention")(
                query, tokens, tokens, attn_mask=mask, need_weights=False
            )
            local = tokens.reshape(b * t, q, n // q, d)
            if branch == "background":
                reduced = local.mean(-2)
            else:
                chosen = self.score.reshape(b * t, q, n // q).argmax(-1)
                reduced = local.gather(
                    -2, chosen[..., None, None].expand(-1, -1, 1, d)
                ).squeeze(-2)
            codes.append(attended + getattr(pool, branch + "_projection")(reduced))
        return pool.norm(torch.cat(codes, -1).reshape(b, t, -1))


def minute_coordinates(length, factor, device, dtype):
    u = (torch.arange(length, device=device) % factor).to(dtype) / factor
    return torch.stack(
        (
            torch.sin(2 * math.pi * u),
            torch.cos(2 * math.pi * u),
            torch.sin(4 * math.pi * u),
            torch.cos(4 * math.pi * u),
        ),
        -1,
    )


class TimedRefiner(PairRefiner):
    """All arms allocate/train the same extra MLP; controls receive zero coords."""

    def __init__(self, quantity_scale):
        super().__init__(quantity_scale)
        self.time_network = nn.Sequential(
            nn.Linear(72, 64), nn.GELU(), nn.Linear(64, 3)
        )
        nn.init.zeros_(self.time_network[-1].weight)
        nn.init.zeros_(self.time_network[-1].bias)

    def forward(self, features, base_points, coordinates):
        raw = self.network(features).float()
        raw = raw + self.time_network(torch.cat((features, coordinates), -1)).float()
        initial = base_points[..., 1].clamp_min(0.001)
        peak_quantity = F.softplus(
            initial + torch.log(-torch.expm1(-initial)) + raw[..., 1]
        )
        logits = raw[..., 2] + 8.0
        background = base_points[..., 1].clamp(0, 10.0 / self.quantity_scale)
        quantity = background + logits.sigmoid() * (peak_quantity - background)
        return dict(
            price=base_points[..., 0] + raw[..., 0], quantity=quantity, logits=logits
        )


class InformationModel(nn.Module):
    def __init__(self, initial, quantity_scale, arm):
        super().__init__()
        self.config = ARMS[arm]
        self.base = make_base(initial)
        self.slots = 64
        # fork_rng keeps the refiner initialization independent of pool changes.
        with torch.random.fork_rng():
            torch.manual_seed(torch.initial_seed() + 9000)
            self.refiner = TimedRefiner(quantity_scale)
        if self.config["coherent"]:
            self.base.encoder.spatial_pool = CoherentPool(
                self.base.encoder.spatial_pool
            )
            self.base.encoder.geometry_embeddings[-1].register_forward_pre_hook(
                self.capture_geometry
            )
        self.z = self.points = self.indices = None

    def capture_geometry(self, module, args):
        state = args[0]
        score = state["peak_q"].amax(-1)
        self.base.encoder.spatial_pool.score = score.reshape(*score.shape[:2], -1)

    def encode(self, x):
        return self.base.encoder(x)

    def forward(self, x):
        self.z = self.encode(x)
        self.base_book = self.base.decoder(self.z)
        self.indices, base_points, features = proposal_features(
            self.z, self.base_book, self.slots
        )
        b, t, s = x.shape[:3]
        coords = minute_coordinates(t, t // self.z.shape[1], x.device, features.dtype)
        coords = (
            coords[None, :, None, None]
            .expand(b, t, s, self.slots, 4)
            .reshape(-1, self.slots, 4)
        )
        if not self.config["minute"]:
            coords = torch.zeros_like(coords)
        self.points = self.refiner(features, base_points, coords)
        return reconstruct(dict(base=self.base_book, indices=self.indices), self.points)


def losses(model, prediction, x, context, normalizer, plan):
    from model.experimental.keypoint_fusion import make_keypoint_targets
    from model.losses.peaks import main_peak_loss
    from model.experimental.pair_refine import pair_labels, paired_losses

    target = make_keypoint_targets(x, context["mask"], plan["quantity_scale"])
    mid = (
        context["anchor"][:, None]
        + x[:, :, :, 0, 0].mean(2) * context["price_factor"][:, None]
    )
    scale = context["price_factor"][:, None, None, None] / (
        mid[:, :, None, None] * 1e-5
    )
    labels = pair_labels(model.indices, x, context["mask"], target["centers"], scale)
    parts = paired_losses(labels, model.points, "hungarian", negative_weight=0.1)
    center = main_peak_loss(prediction, x, target["centers"], context["mask"])
    book = normalizer.loss_sum(prediction, x, context) / context["mask"].sum()
    # Identical explicit objective in all four arms. Keep background/negative
    # penalties; no post-hoc threshold or final-rendering changes.
    total = (
        book
        + 0.1 * center
        + 0.01 * parts["price"]
        + 0.1 * parts["quantity"]
        + parts["classification"]
    )
    return total, dict(book=book, center=center, **parts)
