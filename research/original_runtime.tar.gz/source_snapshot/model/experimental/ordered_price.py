"""Independent price adapters over a frozen, executable reconstruction model.

Both adapters have identical parameters. Only rendering differs: an additive
price residual, or a midpoint, positive spread and cumulative positive gaps.
No input price/count/target enters either adapter. Frozen-feature caching is
restricted to the immutable fixture tensors used in these bounded experiments.
"""

import torch
from torch import nn
from torch.nn import functional as F
from model.experimental.variants import make_base


def inverse_softplus(x):
    return x + torch.log(-torch.expm1(-x))


class PriceAdapter(nn.Module):
    def __init__(self, ordered):
        super().__init__()
        self.ordered = ordered
        self.local = nn.Sequential(
            nn.Conv1d(32, 32, 3, padding=1),
            nn.GELU(),
            nn.ConvTranspose1d(32, 1, 4, stride=2, padding=1),
        )
        self.global_parameters = nn.Linear(64, 4)
        nn.init.zeros_(self.local[-1].weight)
        nn.init.zeros_(self.local[-1].bias)
        nn.init.zeros_(self.global_parameters.weight)
        nn.init.zeros_(self.global_parameters.bias)

    def forward(self, features, base_price):
        b, t, s, levels = base_price.shape
        residual = self.local(features).reshape(b, t, s, levels).float()
        pooled = features.mean(-1).reshape(b, t, s * 32)
        global_values = self.global_parameters(pooled).float()
        best = base_price[..., 0]
        reference_mid = best.mean(-1)
        reference_spread = (best[..., 1] - best[..., 0]).abs().clamp_min(1e-4)
        reference_extent = (base_price[..., -1] - best).abs().clamp_min(0.01)
        spread = F.softplus(inverse_softplus(reference_spread) + global_values[..., 1])
        extent = F.softplus(inverse_softplus(reference_extent) + global_values[..., 2:])
        signs = base_price.new_tensor([-1.0, 1.0]).reshape(1, 1, 2, 1)
        if self.ordered:
            gaps = residual[..., 1:].softmax(-1) * extent[..., None] + 1e-6
            distance = F.pad(gaps.cumsum(-1), (1, 0))
            return (reference_mid + global_values[..., 0])[..., None, None] + signs * (
                spread[..., None, None] * 0.5 + distance
            )
        rank = torch.linspace(0.0, 1.0, levels, device=base_price.device)
        correction = (spread - reference_spread)[..., None, None] * 0.5 + (
            extent - reference_extent
        )[..., None] * rank
        return (
            base_price
            + residual
            + global_values[..., 0, None, None]
            + signs * correction
        )


class FrozenPriceModel(nn.Module):
    def __init__(self, state, backbone_state, ordered, cache_features=True):
        super().__init__()
        self.base = make_base(state)
        weights = {
            name.removeprefix("base."): value
            for name, value in backbone_state["model_state_dict"].items()
        }
        self.base.load_state_dict(weights, strict=True)
        self.base.requires_grad_(False)
        self.price_adapter = PriceAdapter(ordered)
        self.cache_features = cache_features
        self.cache = {}
        self.features = None
        self.base.decoder.spatial_decoder.convs[-1].register_forward_pre_hook(
            self.capture
        )

    def capture(self, module, arguments):
        self.features = arguments[0].detach()

    def forward(self, x, latent=None):
        if latent is not None:
            raise ValueError("Frozen-price experiment does not accept oracle latents")
        if x in self.cache:
            output, features = self.cache[x]
        else:
            self.base.eval()
            with torch.no_grad():
                output = self.base(x).detach()
            features = self.features
            if self.cache_features:
                self.cache[x] = (output, features)
        price = self.price_adapter(features, output[..., 0].float())
        return torch.stack((price, output[..., 1].float()), -1), None
