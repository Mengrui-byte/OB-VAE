"""Inference feature ablation for the dual VAE; model parameters stay intact."""

from contextlib import contextmanager


@contextmanager
def dual_feature_ablation(model, *, peaks=True, log=True):
    """Gate the six difference-peak / six LoG channels at the input projection.

    This measures dependence of an already-trained model. It is not a replacement
    for training matched models with and without the feature families.
    """
    if peaks and log:
        yield
        return

    def gate(module, inputs):
        values = inputs[0]
        if values.ndim != 3 or values.shape[1] != 16:
            raise ValueError("Dual encoder feature layout must be [N,16,L]")
        values = values.clone()
        if not peaks:
            values[:,4:10] = 0
        if not log:
            values[:,10:16] = 0
        return (values, *inputs[1:])

    handle = model.encoder.input_proj.register_forward_pre_hook(gate)
    try:
        yield
    finally:
        handle.remove()
