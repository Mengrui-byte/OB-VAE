"""Small spatial-only decoder probes, not the256frame8192 model."""
import math
import torch
from torch import nn
from torch.nn import functional as F
from model.dual.book_layers import Residual1d


class SpatialUpsamplingProbe(nn.Module):
    """Fixed coarse input128x32; compare only4factor-two expansion operators."""
    def __init__(self, mode, channels=32):
        super().__init__()
        if mode not in ('nearest','linear','transpose','shuffle'):
            raise ValueError(mode)
        self.mode=mode
        self.up=nn.ModuleList()
        self.refine=nn.ModuleList()
        for _ in range(4):
            if mode=='transpose':layer=nn.ConvTranspose1d(channels,channels,4,stride=2,padding=1)
            else:layer=nn.Conv1d(channels,channels*(2 if mode=='shuffle' else 1),3,padding=1)
            self.up.append(layer)
            self.refine.append(Residual1d(channels))
        self.head=nn.Conv1d(channels,1,1)
        nn.init.normal_(self.head.weight,std=.01)
        nn.init.constant_(self.head.bias,math.log(math.expm1(.04)))

    def forward(self,x):
        for up,res in zip(self.up,self.refine):
            if self.mode=='nearest':x=up(F.interpolate(x,scale_factor=2,mode='nearest'))
            elif self.mode=='linear':x=up(F.interpolate(x,scale_factor=2,mode='linear',align_corners=False))
            elif self.mode=='shuffle':
                x=up(x);N,C,K=x.shape;x=x.reshape(N,C//2,2,K).permute(0,1,3,2).reshape(N,C//2,2*K)
            else:x=up(x)
            x=res(x,x.new_ones(x.shape[0],1,x.shape[-1]))
        return F.softplus(self.head(x))
