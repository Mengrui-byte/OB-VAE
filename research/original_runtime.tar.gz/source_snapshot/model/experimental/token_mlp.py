"""Unpooled spatial-token MLP, retained as an independent model family."""

import torch
from torch import nn
from torch.nn import functional as F
from model.losses.token_mlp import objective


class TokenMLP(nn.Module):
    def __init__(self, quantity_scale, hidden=128):
        super().__init__()
        self.quantity_scale = quantity_scale
        self.net = nn.Sequential(
            nn.Linear(132, hidden),
            nn.GELU(),
            nn.Linear(hidden, hidden),
            nn.GELU(),
            nn.Linear(hidden, 16 * 32 * 3),
        )
        nn.init.normal_(self.net[-1].weight, std=0.001)
        with torch.no_grad():
            bias = self.net[-1].bias.reshape(16, 32, 3)
            bias.zero_()
            q = torch.tensor(1.0 / quantity_scale)
            bias[..., 1] = q + torch.log(-torch.expm1(-q))
            bias[..., 2] = -4.0

    def forward(self, features):
        b, t, s, k, d = features.shape
        if (t, s, k, d) != (16, 2, 64, 128):
            raise ValueError("Expected unpooled[B,16,2,64,128]")
        token = torch.arange(128, device=features.device)
        rank = (token % 64).float() / 63 * 2 - 1
        side = (token // 64).float() * 2 - 1
        local = (token % 16).float() / 15 * 2 - 1
        coordinates = torch.stack((rank, local, side), -1)[None, None].expand(
            b, t, 128, 3
        )
        clock = torch.linspace(-1, 1, t, device=features.device)[
            None, :, None, None
        ].expand(b, t, 128, 1)
        inp = torch.cat((features.reshape(b, t, 128, 128), coordinates, clock), -1)
        raw = self.net(inp).reshape(b, 16, 2, 64, 16, 32, 3)
        raw = raw.permute(0, 1, 4, 2, 3, 5, 6).reshape(b, 256, 2, 2048, 3).float()
        book = torch.stack((raw[..., 0], F.softplus(raw[..., 1])), -1)
        return book, raw[..., 2]
