"""Order-book adaptations of the operator families listed in the weekly report.

All operators act on [B,T,2,L,D] encoder features before pooling. These are
controlled adaptations, not reproductions of the complete published networks.
"""

import math
import torch
from torch import nn
from torch.nn import functional as F


def causal_filter(x, kernel):
    return F.conv1d(
        F.pad(x, (kernel.shape[-1] - 1, 0)), kernel.flip(-1)[:, None], groups=x.shape[1]
    )


class Sine(nn.Module):
    def forward(self, x):
        return torch.sin(x)


class TemporalOperator(nn.Module):
    def __init__(self, kind, width=128):
        super().__init__()
        self.kind = kind
        self.width = width
        self.log_tau = nn.Parameter(
            torch.log(torch.tensor([0.5, 2.0, 8.0, 32.0])).repeat(width, 1)
        )
        self.mix = nn.Parameter(torch.zeros(width, 4))
        self.shape = nn.Parameter(torch.ones(width, 4))
        self.implicit = nn.Sequential(
            nn.Linear(3, 32),
            Sine(),
            nn.Linear(32, width * (2 if kind == "hyena" else 1)),
        )
        if kind == "s4d":
            self.log_dt = nn.Parameter(
                torch.linspace(math.log(0.01), math.log(0.1), width)
            )
            self.log_real = nn.Parameter(torch.full((width, 8), math.log(0.5)))
            self.frequency = nn.Parameter(
                torch.arange(8).float().repeat(width, 1) * math.pi
            )
            self.coefficient = nn.Parameter(torch.randn(width, 8, 2) * 0.1)
        if kind == "hyena":
            self.projection = nn.Conv1d(width, 3 * width, 1)
            self.short = nn.Conv1d(3 * width, 3 * width, 3, groups=3 * width)
        self.output = nn.Linear(width, width)
        self.gain = nn.Parameter(torch.zeros(width))

    def kernel(self, length, device):
        t = torch.arange(length, device=device, dtype=torch.float32)
        tau = self.log_tau.exp().clamp_min(0.01)
        if self.kind in ["exp", "gamma"]:
            log_weight = -t[None, None, :] / tau[..., None]
            if self.kind == "gamma":
                log_weight = (
                    log_weight + F.softplus(self.shape)[..., None] * (t + 0.05).log()
                )
            return (log_weight.softmax(-1) * self.mix.softmax(-1)[..., None]).sum(1)
        if self.kind == "s4d":
            a = torch.complex(-self.log_real.exp(), self.frequency)
            dt = self.log_dt.exp()[:, None]
            c = torch.view_as_complex(self.coefficient.contiguous())
            response = c * torch.expm1(dt * a) / a
            return 2 * (
                response[..., None] * torch.exp(dt[..., None] * a[..., None] * t)
            ).real.sum(1)
        if self.kind in ["ckconv", "hyena"]:
            normalized = t / max(length - 1, 1)
            coordinate = torch.stack(
                (
                    normalized,
                    torch.sin(math.pi * normalized),
                    torch.cos(math.pi * normalized),
                ),
                -1,
            )
            k = self.implicit(coordinate).T
            if self.kind == "hyena":
                k = k * torch.exp(-normalized[None, :] * 2.0)
            return k / k.abs().sum(-1, keepdim=True).clamp_min(1e-5)
        if self.kind == "wavelet":
            kernels = []
            for support in [2, 4, 8, 16]:
                k = (
                    torch.where(
                        t < support / 2, 1.0, torch.where(t < support, -1.0, 0.0)
                    )
                    / support
                )
                kernels.append(k)
            return self.mix.softmax(-1) @ torch.stack(kernels)
        raise ValueError(self.kind)

    def forward(self, x, coordinates=None):
        b, t, s, l, d = x.shape
        y = x.permute(0, 2, 3, 4, 1).reshape(b * s * l, d, t)
        k = self.kernel(t, x.device)
        if self.kind == "hyena":
            q, key, value = self.short(F.pad(self.projection(y), (2, 0))).chunk(3, 1)
            first, second = k.chunk(2, 0)
            y = q.tanh() * causal_filter(
                key.tanh() * causal_filter(value, first), second
            )
        else:
            y = causal_filter(y, k)
        y = y.reshape(b, s, l, d, t).permute(0, 4, 1, 2, 3)
        return x + self.gain.tanh() * self.output(F.layer_norm(y, (d,)))


class SliceAttention(nn.Module):
    def __init__(self, slices, width=128, heads=4):
        super().__init__()
        self.slices = slices
        self.heads = heads
        self.d = width // heads
        self.assignment = nn.Linear(self.d, slices)
        self.input = nn.Linear(width, width)
        self.value = nn.Linear(width, width)
        self.qkv = nn.Linear(self.d, 3 * self.d, bias=False)
        self.output = nn.Linear(width, width)
        self.temperature = nn.Parameter(torch.zeros(heads, 1, 1))
        self.gain = nn.Parameter(torch.zeros(width))

    def forward(self, x, coordinates=None):
        b, t, s, l, d = x.shape
        tokens = x.reshape(b * t, s * l, d)

        def split(v):
            return v.reshape(b * t, s * l, self.heads, self.d).transpose(1, 2)

        weight = (
            self.assignment(split(self.input(tokens)))
            / (F.softplus(self.temperature) + 0.1)
        ).softmax(-1)
        slice_tokens = torch.einsum(
            "bhng,bhnd->bhgd", weight, split(self.value(tokens))
        ) / weight.sum(2)[..., None].clamp_min(1e-5)
        q, k, v = self.qkv(slice_tokens).chunk(3, -1)
        attended = (q @ k.transpose(-1, -2) / math.sqrt(self.d)).softmax(-1) @ v
        restored = (
            torch.einsum("bhng,bhgd->bhnd", weight, attended)
            .transpose(1, 2)
            .reshape(b, t, s, l, d)
        )
        return x + self.gain.tanh() * self.output(restored)


class SpatialOperator(nn.Module):
    def __init__(self, kind, width=128):
        super().__init__()
        self.kind = kind
        self.width = width
        self.gain = nn.Parameter(torch.zeros(width))
        self.output = nn.Linear(width, width)
        self.log_scale = nn.Parameter(
            torch.log(torch.tensor([0.5, 1.5, 4.0])).repeat(width, 1)
        )
        self.mix = nn.Parameter(torch.zeros(width, 3))
        self.sided_scale = nn.Parameter(torch.zeros(2, 2))
        self.multiscale = nn.ModuleList(
            [
                nn.Conv1d(width, width, k, padding=k // 2, groups=width)
                for k in [3, 5, 9]
            ]
        )
        self.coordinate_kernel = nn.Sequential(
            nn.Linear(2, 16), nn.GELU(), nn.Linear(16, 1)
        )

    def forward(self, x, coordinates=None):
        b, t, s, l, d = x.shape
        y = x.reshape(b * t * s, l, d).transpose(1, 2)
        offset = torch.arange(-4, 5, device=x.device, dtype=torch.float32)
        if self.kind == "multiscale":
            y = sum(
                layer(y) * self.mix.softmax(-1)[:, i][None, :, None]
                for i, layer in enumerate(self.multiscale)
            )
        elif self.kind in ["gaussian", "wavelet"]:
            sigma = self.log_scale.exp().clamp_min(0.05)
            z = offset[None, None, :] / sigma[..., None]
            k = torch.exp(-0.5 * z.square())
            if self.kind == "wavelet":
                k = (1 - z.square()) * k
                k = k - k.mean(-1, keepdim=True)
            k = k / k.abs().sum(-1, keepdim=True).clamp_min(1e-5)
            k = (k * self.mix.softmax(-1)[..., None]).sum(1)
            y = F.conv1d(F.pad(y, (4, 4)), k[:, None], groups=d)
        elif self.kind in ["bilateral", "queue_prior"]:
            outputs = []
            for side in range(s):
                tau = F.softplus(self.sided_scale[side]) + 1.0
                k = torch.exp(-offset.abs() / torch.where(offset < 0, tau[0], tau[1]))
                if self.kind == "queue_prior":
                    k = k * (offset <= 0)
                k = k / k.sum()
                part = x[:, :, side].reshape(b * t, l, d).transpose(1, 2)
                part = F.conv1d(
                    F.pad(part, (4, 4)), k[None, None, :].expand(d, 1, -1), groups=d
                )
                outputs.append(part.transpose(1, 2).reshape(b, t, l, d))
            return x + self.gain.tanh() * self.output(torch.stack(outputs, 2))
        elif self.kind == "coordinate":
            if coordinates is None:
                raise ValueError(
                    "Continuous coordinate kernel needs encoder input coordinates"
                )
            rank = torch.arange(l, device=x.device)
            near = (rank[:, None] + offset.long()).clamp(0, l - 1)
            p = coordinates.reshape(b * t * s, l)
            delta = p[:, near] - p[:, :, None]
            relative = offset[None, None, :].expand(b * t * s, l, -1) / 4.0
            weights = (
                self.coordinate_kernel(torch.stack((delta, relative), -1)).squeeze(-1)
                - delta.abs()
            )
            weight = weights.softmax(-1)
            y = (
                (x.reshape(b * t * s, l, d)[:, near, :] * weight[..., None])
                .sum(2)
                .transpose(1, 2)
            )
        else:
            raise ValueError(self.kind)
        y = y.transpose(1, 2).reshape(b, t, s, l, d)
        return x + self.gain.tanh() * self.output(F.layer_norm(y, (d,)))


class SnakeOperator(nn.Module):
    """Cumulative rank offsets along five temporal taps; explicit future ablation."""

    def __init__(self, causal=True, width=128):
        super().__init__()
        self.causal = causal
        self.offset = nn.Conv1d(width, 5, 3, padding=1)
        self.mix = nn.Parameter(torch.zeros(5))
        self.output = nn.Linear(width, width)
        self.gain = nn.Parameter(torch.zeros(width))

    def forward(self, x, coordinates=None):
        b, t, s, l, d = x.shape
        offsets = (
            self.offset(x.reshape(b * t * s, l, d).transpose(1, 2))
            .transpose(1, 2)
            .reshape(b, t, s, l, 5)
            .tanh()
            .cumsum(-1)
            * 0.5
        )
        offsets = (
            offsets - offsets[..., -1:] if self.causal else offsets - offsets[..., 2:3]
        )
        rank = torch.arange(l, device=x.device)[None, None, None, :]
        result = torch.zeros_like(x)
        for tap, lag in enumerate(range(-4, 1) if self.causal else range(-2, 3)):
            times = torch.arange(t, device=x.device) + lag
            valid = (times >= 0) & (times < t)
            source = x.index_select(1, times.clamp(0, t - 1))
            position = (rank + offsets[..., tap]).clamp(0, l - 1)
            lower = position.floor().long()
            upper = (lower + 1).clamp_max(l - 1)
            a = source.gather(3, lower[..., None].expand(-1, -1, -1, -1, d))
            c = source.gather(3, upper[..., None].expand(-1, -1, -1, -1, d))
            sample = a + (c - a) * (position - lower)[..., None]
            result = (
                result
                + sample * valid[None, :, None, None, None] * self.mix.softmax(0)[tap]
            )
        return x + self.gain.tanh() * self.output(result)


class PoolBranch(nn.Module):
    def __init__(self, kind, input_width=16384, output_width=64):
        super().__init__()
        self.kind = kind
        self.gain = nn.Parameter(torch.zeros(output_width))
        self.norm = nn.LayerNorm(output_width)
        if kind == "linear":
            self.map = nn.Linear(input_width, output_width)
        elif kind == "mlp":
            self.map = nn.Sequential(
                nn.Linear(input_width, 512), nn.GELU(), nn.Linear(512, output_width)
            )
        elif kind == "kan":
            self.map = nn.Linear(input_width * 8, output_width, bias=False)
            self.base = nn.Linear(input_width, output_width, bias=False)
            self.register_buffer("centers", torch.linspace(-1.25, 1.25, 8))
        else:
            raise ValueError(kind)

    def forward(self, tokens):
        b, t, n, d = tokens.shape
        x = tokens.reshape(b, t, n * d)
        if self.kind == "kan":
            u = (
                (x.tanh()[..., None] - self.centers)
                / (self.centers[1] - self.centers[0])
            ).abs()
            spline = torch.where(
                u < 1,
                2 / 3 - u.square() + 0.5 * u.pow(3),
                torch.where(u < 2, (2 - u).pow(3) / 6, 0.0),
            )
            y = self.base(F.silu(x)) + self.map(spline.flatten(-2))
        else:
            y = self.map(x)
        return self.gain.tanh() * self.norm(y)
