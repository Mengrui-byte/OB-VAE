"""Matched controls for price bins, confidence and soft large-peak counts."""

import torch
from torch import nn
from model.experimental.peak_ablation import AblationModel, Refiner, architectures


def variants():
    return {
        "R0_reference": {},
        "P1_price_bins": {"price_bins": True},
        "N0_positive_only": {"classifier": "balanced", "negative_weight": 0.0},
        "N1_negative_001": {"classifier": "balanced", "negative_weight": 0.01},
        "N2_negative_01": {"classifier": "balanced", "negative_weight": 0.1},
        "N3_negative_1": {"classifier": "balanced", "negative_weight": 1.0},
        "N4_hard_negative": {"classifier": "hard", "negative_weight": 0.1},
        "C1_count_001": {"count_weight": 0.01},
        "C2_count_01": {"count_weight": 0.1},
        "A1_combined": {
            "price_bins": True,
            "classifier": "balanced",
            "negative_weight": 0.1,
            "count_weight": 0.1,
            "log_quantity": 0.1,
        },
    }


class PriceRefiner(Refiner):
    def __init__(self, quantity_scale, price_scale, enabled):
        super().__init__(64, quantity_scale, "absolute")
        self.enabled = enabled
        self.price_scale = price_scale
        # Centers -64,-62,...,64 in bps relative to the first-minute anchor.
        # Every arm allocates this head; disabled arms get no head gradients.
        self.register_buffer("centers_bps", torch.arange(-32, 33).float() * 2.0)
        self.price_head = nn.Sequential(
            nn.LayerNorm(68), nn.Linear(68, 64), nn.GELU(), nn.Linear(64, 130)
        )
        nn.init.zeros_(self.price_head[-1].weight)
        nn.init.zeros_(self.price_head[-1].bias)
        with torch.no_grad():
            self.price_head[-1].bias[32] = 2.0

    def forward(self, features, base):
        result = super().forward(features, base)
        result["base_price"] = base[..., 0]
        background = base[..., 1].clamp(0, 10.0 / self.quantity_scale)
        # Recover the ungated amplitude without dividing by confidence.
        raw = self.network(features).float()
        initial = torch.full_like(base[..., 1], 10.0 / self.quantity_scale)
        result["amplitude"] = torch.nn.functional.softplus(
            initial + torch.log(-torch.expm1(-initial)) + raw[..., 1]
        )
        if self.enabled:
            logits, offsets = self.price_head(features).float().split(65, -1)
            chosen = logits.argmax(-1)
            offset = offsets.gather(-1, chosen[..., None]).squeeze(-1)
            # Offsets are unbounded, so the edge bins can recover outliers.
            result.update(bin_logits=logits, bin_offsets=offsets)
            result["price"] = (
                base[..., 0] + (self.centers_bps[chosen] + offset) / self.price_scale
            )
        return result


class RefinementModel(AblationModel):
    def __init__(self, initial, quantity_scale, state_dim, config, price_scale):
        super().__init__(
            initial,
            quantity_scale,
            state_dim,
            architectures()["M3_absolute_amplitude"],
            {"classification": 0.0, "log_quantity": config.get("log_quantity", 0.0)},
        )
        old = self.refiner
        replacement = PriceRefiner(
            quantity_scale, price_scale, config.get("price_bins", False)
        )
        replacement.network.load_state_dict(old.network.state_dict())
        self.refiner = replacement
        self.variant = config
