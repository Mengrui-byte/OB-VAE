"""Prediction-only point proposals, integrated pair refinement and assignment loss."""

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from scipy.optimize import linear_sum_assignment


@torch.no_grad()
def propose(book, slots):
    """Prefer local quantity maxima, without a100 BTC prediction threshold.

    No input prices, counts or labels are consulted. Fill with other nominal
    output ranks when fewer than K local maxima exist; indices remain unique.
    """
    quantity = book[..., 1]
    left = F.pad(quantity[..., :-1], (1, 0), value=-torch.inf)
    right = F.pad(quantity[..., 1:], (0, 1), value=-torch.inf)
    peak = (quantity >= left) & (quantity > right)
    fallback = quantity.amin(-1, keepdim=True) - 1 - quantity.abs()
    return torch.where(peak, quantity, fallback).topk(slots, -1).indices


class PairRefiner(nn.Module):
    """Only model-derived features; modified pairs are scattered into main book."""

    def __init__(self, quantity_scale):
        super().__init__()
        self.quantity_scale = quantity_scale
        self.network = nn.Sequential(
            nn.LayerNorm(68),
            nn.Linear(68, 64),
            nn.GELU(),
            nn.Linear(64, 64),
            nn.GELU(),
            nn.Linear(64, 3),
        )
        nn.init.zeros_(self.network[-1].weight)
        nn.init.zeros_(self.network[-1].bias)

    def forward(self, features, base_points):
        raw = self.network(features).float()
        initial = base_points[..., 1].clamp_min(0.001)
        inverse_softplus = initial + torch.log(-torch.expm1(-initial))
        peak_quantity = F.softplus(inverse_softplus + raw[..., 1])
        logits = raw[..., 2] + 8.0
        background = base_points[..., 1].clamp(0, 10.0 / self.quantity_scale)
        quantity = background + logits.sigmoid() * (peak_quantity - background)
        return dict(
            price=base_points[..., 0] + raw[..., 0], quantity=quantity, logits=logits
        )


def proposal_features(z, book, slots):
    b, t, s, levels, _ = book.shape
    indices = propose(book, slots).reshape(-1, slots)
    points = book.reshape(-1, levels, 2).gather(1, indices[..., None].expand(-1, -1, 2))
    latent = (
        z.repeat_interleave(t // z.shape[1], 1)[:, :, None, None, :]
        .expand(b, t, s, slots, 64)
        .reshape(-1, slots, 64)
    )
    side = (
        torch.arange(s, device=book.device)
        .reshape(1, 1, s, 1)
        .expand(b, t, s, slots)
        .reshape(-1, slots)
        * 2.0
        - 1
    )
    features = torch.cat(
        (
            latent,
            points[..., :1],
            points[..., 1:].clamp_min(0).log1p(),
            (indices.float() / (levels - 1) * 2 - 1)[..., None],
            side[..., None],
        ),
        -1,
    )
    return indices, points, features


@torch.no_grad()
def pair_labels(indices, x, mask, centers, scale):
    b, t, s, levels, _ = x.shape
    slots = indices.shape[-1]
    flat = x.reshape(-1, levels, 2)
    valid = mask.reshape(-1, levels).gather(1, indices)
    centers = centers.reshape(-1, levels)
    lengths = centers.sum(-1).cpu().numpy()
    nmax = max(int(lengths.max()), 1)
    if np.any(lengths > valid.sum(-1).cpu().numpy()):
        raise ValueError(
            "Target overflow: increase fixed proposal capacity, never truncate labels"
        )
    padded = np.zeros((len(lengths), nmax), dtype=np.int64)
    f, r = centers.nonzero(as_tuple=True)
    f = f.cpu().numpy()
    r = r.cpu().numpy()
    for frame in np.flatnonzero(lengths):
        padded[frame, : lengths[frame]] = r[f == frame]
    rank = torch.as_tensor(padded, device=x.device)
    values = flat.gather(1, rank[..., None].expand(-1, -1, 2))
    return dict(
        indices=indices,
        candidate_valid=valid,
        target_rank=rank,
        target_price=values[..., 0],
        target_quantity=values[..., 1],
        target_lengths=lengths,
        scale=scale.expand(b, t, s, 1).reshape(-1),
    )


def reconstruct(cache, points):
    values = torch.stack((points["price"], points["quantity"]), -1)
    book = cache["base"].reshape(-1, cache["base"].shape[-2], 2)
    return book.scatter(
        1, cache["indices"][..., None].expand(-1, -1, 2), values
    ).reshape_as(cache["base"])


def book_loss(cache, points):
    """Exact full-book MSE, reusing unchanged frozen-background error."""
    prediction = torch.stack((points["price"], points["quantity"]), -1)
    changed = (prediction - cache["target_at_candidates"]).square().sum(-1)
    original = (cache["base_points"] - cache["target_at_candidates"]).square().sum(-1)
    delta = (changed - original).masked_fill(~cache["candidate_valid"], 0).sum() * 0.5
    return (
        cache["base_book_sum"] / cache["valid_levels"] + delta / cache["valid_levels"]
    )


@torch.no_grad()
def make_cache(base, x, context, target, scale, slots):
    z = base.encoder(x)
    book = base.decoder(z).float()
    b, t, s, levels, _ = book.shape
    indices = propose(book, slots).reshape(-1, slots)
    flat = book.reshape(-1, levels, 2)
    points = flat.gather(1, indices[..., None].expand(-1, -1, 2))
    latent = (
        z.repeat_interleave(t // z.shape[1], 1)[:, :, None, None, :]
        .expand(b, t, s, slots, 64)
        .reshape(-1, slots, 64)
    )
    side = (
        torch.arange(s, device=x.device)
        .reshape(1, 1, s, 1)
        .expand(b, t, s, slots)
        .reshape(-1, slots)
        * 2.0
        - 1
    )
    features = torch.cat(
        (
            latent,
            points[..., :1],
            points[..., 1:].clamp_min(0).log1p(),
            (indices.float() / (levels - 1) * 2 - 1)[..., None],
            side[..., None],
        ),
        -1,
    )
    mask = context["mask"].reshape(-1, levels)
    candidate_valid = mask.gather(1, indices)
    centers = target["centers"].reshape(-1, levels)
    lengths = centers.sum(-1).cpu().numpy()
    max_points = max(int(lengths.max()), 1)
    if np.any(lengths > candidate_valid.sum(-1).cpu().numpy()):
        raise ValueError(
            "More true peaks than valid prediction candidates: no targets may be truncated"
        )
    padded = np.zeros((len(lengths), max_points), dtype=np.int64)
    f, r = centers.nonzero(as_tuple=True)
    f = f.cpu().numpy()
    r = r.cpu().numpy()
    for frame in np.flatnonzero(lengths):
        padded[frame, : lengths[frame]] = r[f == frame]
    ranks = torch.as_tensor(padded, device=x.device)
    flat_target = x.reshape(-1, levels, 2)
    packed = flat_target.gather(1, ranks[..., None].expand(-1, -1, 2))
    target_at_candidates = flat_target.gather(1, indices[..., None].expand(-1, -1, 2))
    cache = dict(
        base=book,
        indices=indices,
        features=features,
        base_points=points,
        candidate_valid=candidate_valid,
        target_at_candidates=target_at_candidates,
        target_price=packed[..., 0],
        target_quantity=packed[..., 1],
        target_rank=ranks,
        target_lengths=lengths,
        scale=scale.expand(b, t, s, 1).reshape(-1),
        base_book_sum=(book - x)
        .square()
        .masked_fill(~context["mask"][..., None], 0)
        .sum()
        * 0.5,
        valid_levels=context["mask"].sum(),
        context=context,
        target_centers=int(lengths.sum()),
        exact_candidate_centers=int(centers.gather(1, indices).sum()),
    )
    cache["rank_assignment"] = assignment(cache, None, "rank")
    return cache


@torch.no_grad()
def assignment(cache, points, mode):
    frames, slots = cache["indices"].shape
    targets = cache["target_rank"].shape[-1]
    if mode == "rank":
        cost = (
            (cache["indices"][..., None] - cache["target_rank"][:, None, :])
            .abs()
            .float()
        )
    elif mode == "hungarian":
        price = (
            (points["price"][..., None] - cache["target_price"][:, None, :]).abs()
            * cache["scale"][:, None, None]
            * 0.1
        )
        quantity = (
            points["quantity"].clamp_min(0).log1p()[..., None]
            - cache["target_quantity"].clamp_min(0).log1p()[:, None, :]
        ).abs()
        cost = price + 4.0 * quantity - points["logits"].sigmoid()[..., None]
    else:
        raise ValueError(mode)
    cost = cost.masked_fill(~cache["candidate_valid"][..., None], 1e12).cpu().numpy()
    source = []
    destination = []
    for frame, n in enumerate(cache["target_lengths"]):
        if n:
            i, j = linear_sum_assignment(cost[frame, :, :n])
            if len(i) != n:
                raise AssertionError("A true peak was dropped during assignment")
            source.extend((frame * slots + i).tolist())
            destination.extend((frame * targets + j).tolist())
    device = cache["indices"].device
    return torch.tensor(source, device=device, dtype=torch.long), torch.tensor(
        destination, device=device, dtype=torch.long
    )


def paired_losses(cache, points, mode, negative_weight=0.1):
    source, destination = (
        cache["rank_assignment"] if mode == "rank" else assignment(cache, points, mode)
    )
    n = max(len(source), 1)
    frames, slots = cache["indices"].shape
    pred_price = points["price"].flatten()[source]
    true_price = cache["target_price"].flatten()[destination]
    pred_quantity = points["quantity"].flatten()[source]
    true_quantity = cache["target_quantity"].flatten()[destination]
    price_error = (pred_price - true_price) * cache["scale"][source // slots]
    price = (
        F.smooth_l1_loss(price_error, torch.zeros_like(price_error), reduction="sum")
        / n
    )
    quantity = F.smooth_l1_loss(pred_quantity, true_quantity, reduction="sum") / n
    positive = torch.zeros_like(points["logits"]).flatten()
    positive[source] = 1
    positive = positive.reshape_as(points["logits"])
    classification = F.binary_cross_entropy_with_logits(
        points["logits"], positive, reduction="none"
    )
    weight = (
        torch.where(positive.bool(), 1.0, negative_weight) * cache["candidate_valid"]
    )
    classification = (classification * weight).sum() / cache[
        "candidate_valid"
    ].sum().clamp_min(1)
    return dict(price=price, quantity=quantity, classification=classification)
