"""Encoder-side keypoint detection and gated fusion experiments."""

import torch
from torch import nn
from torch.nn import functional as F
from model.experimental.variants import make_base
from model.losses.keypoints import (
    make_keypoint_targets,
    keypoint_losses,
    keypoint_statistics,
)


class NativeKeypoints(nn.Module):
    def __init__(self, width=16, fusion_width=32):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv1d(2, width, 3, padding=1),
            nn.GELU(),
            nn.Conv1d(width, width, 3, padding=1),
            nn.GELU(),
        )
        self.heatmap = nn.Conv1d(width, 1, 1)
        self.height = nn.Conv1d(width, 1, 1)
        self.fusion = nn.Conv1d(width + 3, fusion_width, 1)
        self.gain = nn.Parameter(torch.zeros(fusion_width))
        nn.init.constant_(self.heatmap.bias, -4.0)

    def forward(self, x):
        b, t, s, levels, _ = x.shape
        native = x.permute(0, 1, 2, 4, 3).reshape(b * t * s, 2, levels)
        features = self.features(native)
        logits = self.heatmap(features)
        height = F.softplus(self.height(features))
        rank = torch.linspace(
            -1.0, 1.0, levels, device=x.device, dtype=features.dtype
        ).reshape(1, 1, levels)
        descriptor = torch.cat(
            (features, native[:, :1], rank.expand(len(native), -1, -1), height), 1
        )
        pooled = F.max_pool1d(descriptor * logits.sigmoid(), 2, 2)
        fused = self.fusion(pooled).transpose(1, 2) * self.gain.tanh()
        return dict(
            logits=logits.reshape(b, t, s, levels),
            height=height.reshape(b, t, s, levels),
            fusion=fused,
        )


class KeypointFusionModel(nn.Module):
    def __init__(self, state, fuse):
        super().__init__()
        self.base = make_base(state)
        self.keypoints = NativeKeypoints()
        self.fuse = fuse
        self.keypoint_output = None
        self.latest_fusion_ratio = 0.0
        # LayerNorm output is[N,L/2,32], before GELU and the first time reduction.
        self.base.encoder.spatial_conv.norms[0].register_forward_hook(self.inject)

    def inject(self, module, arguments, output):
        if not self.fuse:
            return output
        fusion = self.keypoint_output["fusion"]
        if output.shape != fusion.shape:
            raise ValueError(
                f"Keypoint/main feature mismatch:{output.shape}/{fusion.shape}"
            )
        if not self.training:
            self.latest_fusion_ratio = float(
                fusion.float().norm() / output.float().norm().clamp_min(1e-12)
            )
        return output + fusion.to(output.dtype)

    def forward(self, x, latent=None):
        if latent is not None:
            raise ValueError("Keypoint fusion does not accept oracle latents")
        self.keypoint_output = self.keypoints(x)
        return self.base(x), None
