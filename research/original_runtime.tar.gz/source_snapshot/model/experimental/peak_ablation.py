"""Causal-factor controls for candidate source, amplitude parameterization and latent width."""

import torch
from types import MethodType
from torch import nn
from torch.nn import functional as F
from model.autoencoder.ae import AE
from model.autoencoder.decoder import SpatialLatentExpansion
from model.experimental.pair_refine import propose, reconstruct
from model.autoencoder.geometry import book_geometry, merge_geometry, anchor_geometry


def architectures():
    baseline = dict(
        width=64,
        time_factor=16,
        source="quantity",
        amplitude="relative",
        heatmap=False,
        reset_bridge=False,
    )
    return {
        "M0_reference": baseline,
        "M1_auxiliary": {**baseline, "heatmap": True},
        "M2_independent_candidates": {**baseline, "heatmap": True, "source": "heatmap"},
        "M3_absolute_amplitude": {
            **baseline,
            "heatmap": True,
            "source": "heatmap",
            "amplitude": "absolute",
        },
        "M4_reset64_control": {
            **baseline,
            "heatmap": True,
            "source": "heatmap",
            "amplitude": "absolute",
            "reset_bridge": True,
        },
        "M5_width128": {
            **baseline,
            "width": 128,
            "heatmap": True,
            "source": "heatmap",
            "amplitude": "absolute",
            "reset_bridge": True,
        },
        "M6_time32": {
            **baseline,
            "time_factor": 8,
            "heatmap": True,
            "source": "heatmap",
            "amplitude": "absolute",
        },
    }


def encode_time8(self, x):
    # Same spatial stages; omit final time reduction. Anchors are8*j+7.
    geometry = book_geometry(x) if self.book_structure != "legacy" else None
    for stage in range(len(self.spatial_conv.convs)):
        x = self.spatial_conv.forward_stage(x, stage)
        if geometry is not None:
            geometry = merge_geometry(geometry, self.local_peak_slots)
            background, peaks = self.geometry_embeddings[stage](
                geometry, 2 ** (stage + 1), self.local_peak_slots
            )
            x = x + background.to(x.dtype) + peaks.to(x.dtype)
        if stage < 3:
            x = self.temporal_conv.forward_stage(
                x, stage, geometry if self.book_structure == "price-aligned" else None
            )
            if geometry is not None:
                geometry = anchor_geometry(geometry)
    x = self.position(x)
    b, t, s, k, d = x.shape
    x = self.output_norm(self.spatial_attention(x.reshape(b * t, s * k, d))).reshape(
        b, t, s * k, d
    )
    if geometry is not None:
        return self.spatial_pool(
            x, background.reshape(b, t, s * k, d), peaks.reshape(b, t, s * k, d)
        )
    return self.spatial_pool(x)


def decode_time8(self, latent):
    x = self.latent_expansion(latent)
    peak = x
    if self.peak_latent_expansion is not None:
        b, t, width = latent.shape
        regional = latent.reshape(
            b, t, self.num_spatial_queries, width // self.num_spatial_queries
        )
        peak = self.peak_latent_expansion(
            regional[..., regional.shape[-1] // 2 :].reshape(b, t, width // 2)
        )
    correction = (
        self.patch_quantity_head(peak) if self.patch_quantity_head is not None else None
    )
    for stage in range(len(self.spatial_decoder.convs)):
        if stage == len(self.spatial_decoder.convs) - 1:
            quantity_features = x
        x = self.spatial_decoder.forward_stage(x, stage)
        if 0 < stage < len(self.temporal_decoder.convs):
            x = self.temporal_decoder.forward_stage(x, stage)
    if self.quantity_head is not None:
        q = self.quantity_head(quantity_features, x[..., 1])
    else:
        q = x[..., 1].float() + (correction.float() if correction is not None else 0.0)
    return torch.stack((x[..., 0].float(), q), -1)


def objectives():
    return {
        "L0_default": {},
        "L1_no_pair_price": dict(price=0.0),
        "L2_no_pair_quantity": dict(quantity=0.0),
        "L3_no_pair_classification": dict(classification=0.0),
        "L4_no_center_huber": dict(center=0.0),
        "L5_linear_plus_log_quantity": dict(log_quantity=0.1),
        "L6_balanced_focal": dict(classifier="balanced_focal"),
        "L7_peak_weight_low": dict(peak_weight=0.3),
        "L8_peak_weight_high": dict(peak_weight=3.0),
        "L9_joint_market_state": dict(state=True),
        "L10_center_only": dict(price=0.0, quantity=0.0, classification=0.0),
        "L11_book_and_proposal_only": dict(peak=False),
    }


class Heatmap(nn.Module):
    def __init__(self, width, factor=16):
        super().__init__()
        self.expand = SpatialLatentExpansion(
            latent_dim=width, d_model=32, spatial_tokens=64, num_queries=8, num_heads=4
        )
        self.factor = factor
        self.output = nn.ConvTranspose2d(
            32, 1, kernel_size=(factor, 32), stride=(factor, 32)
        )
        nn.init.constant_(self.output.bias, -4.0)

    def forward(self, z):
        v = self.expand(z)
        b, t, s, k, d = v.shape
        v = v.permute(0, 2, 4, 1, 3).reshape(b * s, d, t, k)
        return (
            self.output(v)
            .reshape(b, s, t * self.factor, k * 32)
            .permute(0, 2, 1, 3)
            .contiguous()
            .float()
        )


class Refiner(nn.Module):
    def __init__(self, width, quantity_scale, amplitude):
        super().__init__()
        self.quantity_scale = quantity_scale
        self.amplitude = amplitude
        self.network = nn.Sequential(
            nn.LayerNorm(width + 4),
            nn.Linear(width + 4, 64),
            nn.GELU(),
            nn.Linear(64, 64),
            nn.GELU(),
            nn.Linear(64, 3),
        )
        nn.init.zeros_(self.network[-1].weight)
        nn.init.zeros_(self.network[-1].bias)

    def forward(self, features, base):
        v = self.network(features).float()
        initial = (
            base[..., 1].clamp_min(0.001)
            if self.amplitude == "relative"
            else torch.full_like(base[..., 1], 10.0 / self.quantity_scale)
        )
        amplitude = F.softplus(initial + torch.log(-torch.expm1(-initial)) + v[..., 1])
        logits = v[..., 2] + 8.0
        bg = base[..., 1].clamp(0, 10.0 / self.quantity_scale)
        return dict(
            price=base[..., 0] + v[..., 0],
            quantity=bg + logits.sigmoid() * (amplitude - bg),
            logits=logits,
        )


class AblationModel(nn.Module):
    def __init__(
        self, initial, quantity_scale, state_dim, architecture, loss_config=None
    ):
        super().__init__()
        self.config = architecture
        self.loss_config = loss_config or {}
        a = initial["args"]
        width = architecture["width"]
        self.slots = 64
        self.base = AE(
            latent_dim=width,
            quantity_mode=a["quantity_mode"],
            conv_order=a["conv_order"],
            book_structure=a["book_structure"],
            local_peak_slots=a["local_peak_slots"],
            peak_mode=a["peak_mode"],
            peak_price_scale=a["price_scale"],
            peak_price_normalization=a["price_normalization"],
        )
        prefixes = (
            "encoder.spatial_pool.",
            "decoder.latent_expansion.",
            "decoder.peak_latent_expansion.",
        )
        state = self.base.state_dict()
        copied = {}
        skipped = []
        for name, value in initial["model_state_dict"].items():
            if (
                name in state
                and value.shape == state[name].shape
                and not (architecture["reset_bridge"] and name.startswith(prefixes))
            ):
                copied[name] = value
            else:
                skipped.append(name)
        self.base.load_state_dict(copied, strict=False)
        self.initialization = dict(
            copied_parameter_tensors=len(copied), reset_or_shape_mismatch=skipped
        )
        if architecture["time_factor"] == 8:
            old_position = self.base.encoder.position.time_embedding
            position = nn.Embedding(32, old_position.embedding_dim)
            with torch.no_grad():
                coordinate = ((torch.arange(32, dtype=torch.float32) - 1) / 2).clamp(
                    0, 15
                )
                lo = coordinate.floor().long()
                hi = (lo + 1).clamp_max(15)
                position.weight.copy_(
                    old_position.weight[lo]
                    + (old_position.weight[hi] - old_position.weight[lo])
                    * (coordinate - lo)[:, None]
                )
            self.base.encoder.position.time_embedding = position
            self.base.encoder.forward = MethodType(encode_time8, self.base.encoder)
            self.base.decoder.forward = MethodType(decode_time8, self.base.decoder)
            if self.base.decoder.patch_quantity_head is not None:
                old = self.base.decoder.patch_quantity_head.output
                new = nn.ConvTranspose2d(
                    old.in_channels,
                    old.out_channels,
                    kernel_size=(8, 32),
                    stride=(8, 32),
                )
                with torch.no_grad():
                    new.weight.copy_(
                        old.weight.reshape(
                            old.in_channels, old.out_channels, 8, 2, 32
                        ).mean(3)
                    )
                    new.bias.copy_(old.bias)
                self.base.decoder.patch_quantity_head.output = new
                self.base.decoder.patch_quantity_head.forward = MethodType(
                    patch_time8, self.base.decoder.patch_quantity_head
                )
            self.initialization["time8"] = (
                "Skip encoderT3 and decoderT3 inverse; interpolate16->32 time positions preserving old15/31/... anchors; average pretrained residual kernel pairs16->8; no new input skip"
            )
        for module in self.base.modules():
            if isinstance(module, nn.Dropout):
                module.p = 0.0
            if isinstance(module, nn.MultiheadAttention):
                module.dropout = 0.0
            if hasattr(module, "activation_checkpointing"):
                module.activation_checkpointing = False
        self.refiner = Refiner(width, quantity_scale, architecture["amplitude"])
        self.heatmap_head = Heatmap(width, architecture["time_factor"])
        self.state_head = nn.Sequential(
            nn.LayerNorm(width),
            nn.Linear(width, 128),
            nn.GELU(),
            nn.Linear(128, state_dim),
        )

    def forward(self, x):
        z = self.base.encoder(x)
        book = self.base.decoder(z)
        self.z = z
        self.state = self.state_head(
            z[:, 1::2] if self.config["time_factor"] == 8 else z
        )
        self.heatmap = self.heatmap_head(z)
        ranking = (
            book
            if self.config["source"] == "quantity"
            else torch.stack((torch.zeros_like(self.heatmap), self.heatmap), -1)
        )
        indices = propose(ranking, self.slots).reshape(-1, self.slots).contiguous()
        b, t, s, levels, _ = book.shape
        if (
            indices.shape != (b * t * s, self.slots)
            or int(indices.min()) < 0
            or int(indices.max()) >= levels
        ):
            raise ValueError(
                f"Candidate bounds/shape invalid: {indices.shape}, book={book.shape}, heatmap={self.heatmap.shape}"
            )
        points = book.reshape(-1, levels, 2).gather(
            1, indices[..., None].expand(-1, -1, 2)
        )
        latent = (
            z.repeat_interleave(t // z.shape[1], 1)[:, :, None, None, :]
            .expand(b, t, s, self.slots, z.shape[-1])
            .reshape(-1, self.slots, z.shape[-1])
        )
        side = (
            torch.arange(s, device=x.device)
            .reshape(1, 1, s, 1)
            .expand(b, t, s, self.slots)
            .reshape(-1, self.slots)
            * 2.0
            - 1
        )
        features = torch.cat(
            (
                latent,
                points[..., :1],
                points[..., 1:].clamp_min(0).log1p(),
                (indices.float() / (levels - 1) * 2 - 1)[..., None],
                side[..., None],
            ),
            -1,
        )
        self.indices = indices
        self.points = self.refiner(features, points)
        return reconstruct(dict(base=book, indices=indices), self.points)


def patch_time8(self, x):
    b, t, s, k, d = x.shape
    v = x.permute(0, 2, 4, 1, 3).reshape(b * s, d, t, k)
    return (
        self.output(F.gelu(self.features(v)))
        .reshape(b, s, t * 8, k * 32)
        .permute(0, 2, 1, 3)
        .contiguous()
    )
