"""Matched original-checkpoint controls for the user's structural idea bundle."""

import torch
from torch import nn
from model.experimental.campaign import ResearchModel
from model.experimental.pair_refine import PairRefiner

COMPONENTS = ["exp", "multiscale", "slice8", "kan", "keypoints"]


def variants():
    values = {
        "B0_original": dict(structure=False, peak=False, decompose=False),
        "B1_pair_only": dict(structure=False, peak=True, decompose=False),
        "B2_structure_only": dict(structure=True, peak=False, decompose=False),
        "B3_structure_plus_pair": dict(structure=True, peak=True, decompose=False),
        "B4_structure_pair_decoupled": dict(structure=True, peak=True, decompose=True),
    }
    # Empty/all masks already exist as B0/B1 and B2/B3; add the other60.
    for mask in range(1, 31):
        components = [name for bit, name in enumerate(COMPONENTS) if mask & (1 << bit)]
        for peak in [False, True]:
            values[f"G{mask:02d}_" + ("pair" if peak else "book")] = dict(
                structure=True, components=components, peak=peak, decompose=False
            )
    return values


class CombinationModel(ResearchModel):
    def __init__(self, initial, quantity_scale, state_dim, variant, price_scale=None):
        components = variant.get(
            "components", COMPONENTS if variant["structure"] else []
        )
        config = {}
        if "exp" in components:
            config["temporal"] = ["exp"]
        if "multiscale" in components:
            config["spatial"] = ["multiscale"]
        if "slice8" in components:
            config["slices"] = [8]
        if "kan" in components:
            config["pools"] = ["kan"]
        if "keypoints" in components:
            config["keypoints"] = True
        if variant["peak"]:
            config["pair"] = "no_background"
        # All five arms start from the ORIGINAL epoch6, never the four-window C.
        warm = dict(
            model_state_dict={
                "base." + k: v for k, v in initial["model_state_dict"].items()
            }
        )
        super().__init__(initial, warm, config, quantity_scale, 64)
        if variant["peak"]:
            # Structural modules consume different RNG draws; keep the comparison
            # head's initial weights identical across B1/B3/B4 for a given seed.
            with torch.random.fork_rng():
                torch.manual_seed(9000 + torch.initial_seed())
                self.pair_head = PairRefiner(quantity_scale)
        self.variant = variant
        self.initialization = dict(
            warmstart="original epoch6",
            components=components,
            pair_head_seed=9000 + torch.initial_seed() if variant["peak"] else None,
        )
        self.state_head = nn.Sequential(
            nn.LayerNorm(64), nn.Linear(64, 128), nn.GELU(), nn.Linear(128, state_dim)
        )
        self.base.decoder.register_forward_hook(self.capture_base)

    def capture_base(self, module, args, output):
        self.base_book = output

    def forward(self, x):
        output = super().forward(x)
        self.z = self.last_latent
        self.state = self.state_head(self.z)
        return output

    def encode(self, x):
        # Frozen probes must refresh hook context for THIS batch, including a
        # different-sized tail batch; bypassing ResearchModel.forward is unsafe.
        self.input_batch = x.shape[0]
        if self.keypoints is not None:
            self.keypoint_output = self.keypoints(x)
        return self.base.encoder(x)
