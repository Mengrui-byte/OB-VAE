"""Read native-rank keypoints from the compact latent, without input skips."""

import torch
from torch import nn
from torch.nn import functional as F
from model.autoencoder.decoder import SpatialLatentExpansion
from model.experimental.keypoint_fusion import KeypointFusionModel


class LatentKeypoints(nn.Module):
    def __init__(self):
        super().__init__()
        self.expansion = SpatialLatentExpansion(
            latent_dim=64, d_model=32, spatial_tokens=64, num_queries=8, num_heads=4
        )
        self.features = nn.Conv2d(32, 32, 1)
        self.output = nn.ConvTranspose2d(32, 3, kernel_size=(16, 32), stride=(16, 32))
        with torch.no_grad():
            self.output.bias[0] = -4.0

    def forward(self, z):
        features = self.expansion(z)
        b, t, s, k, d = features.shape
        features = features.permute(0, 2, 4, 1, 3).reshape(b * s, d, t, k)
        output = self.output(F.gelu(self.features(features))).reshape(
            b, s, 3, t * 16, k * 32
        )
        output = output.permute(0, 3, 1, 4, 2).contiguous().float()
        return dict(
            logits=output[..., 0],
            height=F.softplus(output[..., 1]),
            price=output[..., 2],
        )


class MultiWindowModel(KeypointFusionModel):
    def __init__(self, state, fuse, latent_supervision):
        super().__init__(state, fuse)
        self.latent_keypoints = LatentKeypoints()
        self.latent_supervision = latent_supervision
        self.latent_output = None
        self.last_latent = None

    def forward(self, x, latent=None):
        if latent is not None:
            raise ValueError("No oracle latents in multi-window experiment")
        self.keypoint_output = self.keypoints(x)
        z = self.base.encoder(x)
        self.last_latent = z
        # A/B allocate the same head but do not use it to train or reconstruct.
        self.latent_output = (
            self.latent_keypoints(z)
            if self.latent_supervision or not self.training
            else None
        )
        return self.base.decoder(z), None


def latent_price_loss(prediction, target, centers, tolerance_scale):
    error = (prediction["price"] - target[..., 0]) * tolerance_scale
    loss = F.smooth_l1_loss(error, torch.zeros_like(error), reduction="none")
    return loss.masked_fill(~centers, 0).sum() / centers.sum().clamp_min(1)
