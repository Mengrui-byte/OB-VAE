"""Peak experiments: all decoder branches receive only the compact latent."""

import torch
from torch import nn
from torch.nn import functional as F
from model.autoencoder.ae import AE


def make_base(state):
    a = state["args"]
    model = AE(
        quantity_mode=a["quantity_mode"],
        conv_order=a["conv_order"],
        book_structure=a["book_structure"],
        local_peak_slots=a["local_peak_slots"],
        peak_mode=a["peak_mode"],
        peak_price_scale=a["price_scale"],
        peak_price_normalization=a["price_normalization"],
    )
    model.load_state_dict(state["model_state_dict"], strict=True)
    for module in model.modules():
        if isinstance(module, nn.Dropout):
            module.p = 0.0
        if isinstance(module, nn.MultiheadAttention):
            module.dropout = 0.0
        if hasattr(module, "activation_checkpointing"):
            module.activation_checkpointing = False
    return model


class SparsePeaks(nn.Module):
    """Two positive peaks per32-level cell and original minute, plus background.

    Coordinates are output ranks, not true prices or true peak positions.
    Finite-width Gaussian rendering supplies gradients for position and width.
    """

    def __init__(self, width=128, slots=2):
        super().__init__()
        self.slots = slots
        self.parameters_head = nn.Linear(width, 16 * slots * 3)
        nn.init.zeros_(self.parameters_head.weight)
        with torch.no_grad():
            bias = self.parameters_head.bias.view(16, slots, 3)
            bias[..., 0] = -3.0  # softplus height ~0.049 in training-scaled units
            centers = torch.linspace(0.25, 0.75, slots)
            bias[..., 1] = torch.logit(centers)
            bias[..., 2] = 0.0  # initial width4.25 native ranks

    def forward(self, features):
        b, t, s, cells, _ = features.shape
        raw = self.parameters_head(features).reshape(b, t, s, cells, 16, self.slots, 3)
        raw = (
            raw.permute(0, 1, 4, 2, 3, 5, 6)
            .reshape(b, t * 16, s, cells, self.slots, 3)
            .float()
        )
        height = F.softplus(raw[..., 0])
        center = 31.0 * raw[..., 1].sigmoid()
        sigma = 0.5 + 7.5 * raw[..., 2].sigmoid()
        ranks = torch.arange(32, device=raw.device, dtype=raw.dtype)
        peak = height[..., None] * torch.exp(
            -0.5 * ((ranks - center[..., None]) / sigma[..., None]).square()
        )
        return peak.sum(-2).flatten(-2)


class ExperimentModel(nn.Module):
    def __init__(self, state, arm):
        super().__init__()
        self.base = make_base(state)
        self.arm = arm
        self.features = None
        self.peak_features = None
        if arm == "focal":
            self.peak_logits = nn.ConvTranspose1d(32, 1, 4, stride=2, padding=1)
            nn.init.zeros_(self.peak_logits.weight)
            nn.init.constant_(self.peak_logits.bias, -4.0)
            self.base.decoder.spatial_decoder.convs[-1].register_forward_pre_hook(
                self.capture_features
            )
        if arm == "sparse":
            self.sparse = SparsePeaks()
            self.base.decoder.peak_latent_expansion.register_forward_hook(
                self.capture_peaks
            )

    def capture_features(self, module, arguments):
        self.features = arguments[0]

    def capture_peaks(self, module, arguments, output):
        self.peak_features = output

    def forward(self, x, latent=None):
        z = self.base.encoder(x) if latent is None else latent
        output = self.base.decoder(z)
        logits = None
        if self.arm == "focal":
            logits = self.peak_logits(self.features).reshape(*output.shape[:-1]).float()
        if self.arm == "sparse":
            quantity = output[..., 1].float().clamp_min(0) + self.sparse(
                self.peak_features
            )
            output = torch.stack((output[..., 0].float(), quantity), -1)
        return output, logits


def peak_target(quantity, mask, threshold_scaled):
    left = F.pad(quantity[..., :-1], (1, 0))
    right = F.pad(quantity[..., 1:], (0, 1))
    peaks = (
        mask & (quantity >= threshold_scaled) & (quantity >= left) & (quantity > right)
    )
    # Small spatial tolerance belongs to the training label only; evaluation stays unchanged.
    return (
        F.max_pool1d(peaks.float().reshape(-1, 1, peaks.shape[-1]), 3, 1, 1).reshape_as(
            quantity
        )
        > 0
    )


def balanced_focal(logits, target, mask, gamma=2.0):
    bce = F.binary_cross_entropy_with_logits(
        logits.float(), target.float(), reduction="none"
    )
    probability = torch.where(target, logits.sigmoid(), (-logits).sigmoid())
    loss = (1 - probability).pow(gamma) * bce
    positive, negative = mask & target, mask & ~target
    return 0.5 * (
        (loss * positive).sum() / positive.sum().clamp_min(1)
        + (loss * negative).sum() / negative.sum().clamp_min(1)
    )
