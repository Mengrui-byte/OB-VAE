"""Identical main-book refiner and latent-only state head for every loss ablation."""

import torch
from torch import nn
from torch.nn import functional as F
from model.experimental.variants import make_base
from model.experimental.pair_refine import (
    PairRefiner,
    proposal_features,
    reconstruct,
    pair_labels,
    paired_losses,
)
from model.experimental.keypoint_fusion import make_keypoint_targets
from model.losses.peaks import main_peak_loss


class StateModel(nn.Module):
    def __init__(self, initial, quantity_scale, state_dim):
        super().__init__()
        self.base = make_base(initial)
        self.slots = 64
        self.refiner = PairRefiner(quantity_scale)
        self.state_head = nn.Sequential(
            nn.LayerNorm(64), nn.Linear(64, 128), nn.GELU(), nn.Linear(128, state_dim)
        )

    def forward(self, x):
        z = self.base.encoder(x)
        book = self.base.decoder(z)
        indices, points, features = proposal_features(z, book, self.slots)
        self.indices = indices
        self.points = self.refiner(features, points)
        self.z = z
        self.state = self.state_head(z)
        return reconstruct(dict(base=book, indices=indices), self.points)


def tasks(
    model, prediction, x, context, core_target, normalizer, plan, peak=True, state=True
):
    values = dict(
        book=normalizer.loss_sum(prediction, x, context) / context["mask"].sum()
    )
    details = {}
    if peak:
        labels = make_keypoint_targets(x, context["mask"], plan["quantity_scale"])
        mid_normalized = x[:, :, :, 0, 0].mean(2)
        mid = (
            context["anchor"][:, None]
            + mid_normalized * context["price_factor"][:, None]
        )
        scale = context["price_factor"][:, None, None, None] / (
            mid[:, :, None, None] * 1e-5
        )
        packed = pair_labels(
            model.indices, x, context["mask"], labels["centers"], scale
        )
        parts = paired_losses(packed, model.points, "hungarian", negative_weight=0.1)
        center = main_peak_loss(prediction, x, labels["centers"], context["mask"])
        values["peak"] = (
            0.1 * center
            + 0.01 * parts["price"]
            + 0.1 * parts["quantity"]
            + parts["classification"]
        )
        details.update(peak_center=center, **{"pair_" + k: v for k, v in parts.items()})
    if state:
        mean = x.new_tensor(plan["core_scale"]["mean"])
        std = x.new_tensor(plan["core_scale"]["std"])
        values["state"] = F.smooth_l1_loss(model.state, (core_target - mean) / std)
    return values, details
