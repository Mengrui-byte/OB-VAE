"""Balanced posterior expansion for a controlled latent-capacity diagnosis."""
import torch


def load_balanced_double_latent(model, narrow_state, seed=42, perturbation=.01):
    """Keep shared weights, balance+/-posterior perturbations and halve input weights.

    In real arithmetic, the first decoder affine input is unchanged at init.
    Perturbations break duplicated-unit symmetry; numerical replay is audited.
    """
    if model.latent_channels != 256:
        raise ValueError('This diagnostic expands128to256 channels only')
    state=model.state_dict();generator=torch.Generator().manual_seed(seed)
    for name,value in state.items():
        old=narrow_state[name]
        if name=='encoder.mu.weight':
            delta=torch.randn(old.shape,generator=generator,dtype=old.dtype)*perturbation
            state[name]=torch.cat((old+delta,old-delta),0)
        elif name in ('encoder.mu.bias','encoder.logvar.bias','encoder.logvar.weight'):
            state[name]=torch.cat((old,old),0)
        elif name in ('price_decoder.temporal.mlp.0.weight','volume_decoder.temporal.mlp.0.weight'):
            state[name]=torch.cat((old*.5,old*.5),1)
        else:
            if value.shape!=old.shape:raise ValueError(f'Unexpected changed parameter:{name}')
            state[name]=old
    model.load_state_dict(state,strict=True)
