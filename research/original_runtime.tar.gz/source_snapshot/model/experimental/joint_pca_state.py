"""Fixed joint continuous window bottleneck with trainable original decoders."""
import torch
from torch.nn import functional as F

from model.autoencoder.joint_pca_codec import JointPCACodec
from model.experimental.dual_fusion import FusedOrderBookVAE


class JointPCAWindowVAE(FusedOrderBookVAE):
    def __init__(self,*,state_dim=4096,window_size=16,**core):
        super().__init__(fusion_variant='cross',fusion_seed=42,**core)
        self.joint_pca_config=dict(state_dim=state_dim,window_size=window_size)
        self.state_codec=JointPCACodec(state_dim=state_dim,window_size=window_size,levels=core.get('levels',2048),
            global_dim=core.get('global_dim',64),local_dim=core.get('local_dim',16))
        self.freeze_source()

    def freeze_source(self):
        self.encoder.requires_grad_(False);self.fusion.requires_grad_(False)
        self.encoder.eval();self.fusion.eval()

    def load_cross_initial(self,state):
        missing,unexpected=self.load_state_dict(state,strict=False)
        if unexpected or set(missing)!={'state_codec.mean','state_codec.basis'}:raise ValueError(f'Source architecture differs: {missing}, {unexpected}')

    def extract_market_state(self,price,volume,mask,tick_norm,times=None):
        self.freeze_source()
        with torch.no_grad():
            p=self.encoder(price,volume,mask,tick_norm,times=times,sample=False)
            f=self.fusion([(p['z_global'],p['z_local'])],p['latent_mask'],times)
            return self.state_codec.encode(f['global_latent'],f['local_latent'])

    def decode_state(self,state,mask,tick_norm,times=None):
        b,t,_,levels=mask.shape
        if t!=self.state_codec.window_size:raise ValueError('Decoder metadata must cover the complete window')
        lm=F.adaptive_max_pool1d(mask.reshape(b*t*2,1,levels).float(),levels//16).reshape(b,t,2,levels//16).bool()
        g,l=self.state_codec.decode(state,lm)
        geo=self.price_decoder(g,l,mask,tick_norm,times=times)
        quantity=self.volume_decoder(g,l,geo,mask,tick_norm,times=times)
        quantity=self.volume_refinement(g,l,quantity,geo,mask,tick_norm,times)
        return dict(geo,volume=quantity,market_state=state)

    def forward(self,price,volume,mask,tick_norm,times=None,sample=None):
        state=self.extract_market_state(price,volume,mask,tick_norm,times)
        return self.decode_state(state,mask,tick_norm,times)
