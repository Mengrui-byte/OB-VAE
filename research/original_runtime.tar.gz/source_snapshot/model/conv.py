"""Compatibility import; implement model changes in model.autoencoder.conv."""

import sys
from importlib import import_module

_implementation = import_module("model.autoencoder.conv")
sys.modules[__name__] = _implementation
