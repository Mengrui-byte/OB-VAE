"""Direct peak supervision of the final reconstructed book, in train-only units."""

import torch
from torch.nn import functional as F


def main_peak_loss(prediction, target, centers, mask, kind="huber"):
    """Keep the full-book loss separately; this term averages only true centers.

    No artificial zero targets for background orders, no label-dependent forward
    path, and no replacement of the reconstructed quantity by an auxiliary head.
    A peak-free batch has a differentiable zero loss.
    """
    selected = centers & mask
    if kind == "huber":
        error = F.smooth_l1_loss(
            prediction[..., 1].float(), target[..., 1], reduction="none"
        )
    elif kind == "mse":
        error = (prediction[..., 1].float() - target[..., 1]).square()
    else:
        raise ValueError(f"Unknown main peak loss: {kind}")
    return error.masked_fill(~selected, 0).sum() / selected.sum().clamp_min(1)


@torch.no_grad()
def batch_peak_diagnostics(prediction, target, centers, mask, quantity_scale):
    selected = centers & mask
    count = selected.sum().clamp_min(1)
    quantity = prediction[..., 1].float() * quantity_scale
    difference = (prediction[..., 1].float() - target[..., 1]) * quantity_scale
    return dict(
        true_peak_centers=int(selected.sum()),
        center_prediction_mean_btc=float(
            quantity.masked_fill(~selected, 0).sum() / count
        ),
        center_rmse_btc=float(
            (difference.square().masked_fill(~selected, 0).sum() / count).sqrt()
        ),
        max_prediction_btc=float(quantity.masked_fill(~mask, -torch.inf).max()),
    )
