"""Dense or Hungarian-paired supervision for the independent token MLP."""


def objective(book, logits, x, context, norm, slots, hungarian):
    dense = norm.loss_sum(book, x, context) / context["mask"].sum()
    if not hungarian:
        return dense, dict(book=dense)
    from model.experimental.keypoint_fusion import make_keypoint_targets
    from model.experimental.pair_refine import propose, pair_labels, paired_losses

    target = make_keypoint_targets(x, context["mask"], norm.quantity_scale)
    indices = propose(book, slots).reshape(-1, slots)
    values = book.reshape(-1, 2048, 2).gather(1, indices[..., None].expand(-1, -1, 2))
    points = dict(
        price=values[..., 0],
        quantity=values[..., 1],
        logits=logits.reshape(-1, 2048).gather(1, indices),
    )
    mid = (
        context["anchor"][:, None]
        + x[:, :, :, 0, 0].mean(2) * context["price_factor"][:, None]
    )
    scale = context["price_factor"][:, None, None, None] / (
        mid[:, :, None, None] * 1e-5
    )
    labels = pair_labels(indices, x, context["mask"], target["centers"], scale)
    parts = paired_losses(labels, points, "hungarian", negative_weight=0.1)
    return dense + 0.01 * parts["price"] + 0.1 * parts["quantity"] + parts[
        "classification"
    ], dict(book=dense, **parts)
