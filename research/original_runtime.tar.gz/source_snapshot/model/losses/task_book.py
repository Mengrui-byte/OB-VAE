"""Ablate only explicit price supervision; retain quantity geometry gradients."""
import torch
from torch.nn import functional as F
from model.losses.probability_book import ProbabilityBookLoss


class TaskBookLoss(ProbabilityBookLoss):
    def __init__(self, quantity_scale, joint=True, **kwargs):
        super().__init__(quantity_scale,**kwargs)
        self.joint = joint

    def forward(self, out, batch, beta=0.):
        values = super().forward(out,batch,beta)
        mask = batch['mask']
        idx = batch['volume'].masked_fill(~mask,-torch.inf).topk(min(self.topk,mask.shape[-1]),-1).indices
        chosen = mask.gather(-1,idx)
        dq = (out['volume'].float()-batch['volume'].float())/self.quantity_scale
        q = F.huber_loss(dq,torch.zeros_like(dq),reduction='none')
        q_pair = (q.gather(-1,idx)*chosen).sum()/chosen.sum().clamp_min(1)
        values['full_joint_loss'] = values['loss']
        values['quantity_pair'] = q_pair
        values['price_pair'] = values['pair']-q_pair
        values['explicit_price_loss'] = self.price_weight*values['price']+self.pair_weight*values['price_pair']
        if not self.joint:
            if self.add_wasserstein or self.add_multiscale:
                raise ValueError('This factorial fixes both additional distribution terms off')
            values['loss'] = (self.quantity_weight*(values['quantity']+self.log_weight*values['quantity_log'])
                              +self.pair_weight*q_pair+self.shape_weight*values['quantity_shape_kl']
                              +self.mass_weight*values['quantity_mass']+beta*values['kl'])
        values['reconstruction'] = values['loss']-beta*values['kl']
        return values
