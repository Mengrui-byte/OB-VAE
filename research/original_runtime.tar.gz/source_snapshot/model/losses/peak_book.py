"""Factorial auxiliary peak location and positive-only quantity supervision."""
import math
import torch
from torch.nn import functional as F

from model.losses.probability_book import ProbabilityBookLoss


def balanced_peak_bce(logits, target, mask, threshold):
    """Per-window class means, then mean over windows with any valid class.

    A missing class contributes neither loss nor a denominator. Thus an all-
    negative window uses its negative mean, rather than arbitrarily half of it.
    """
    positive = mask & (target >= threshold)
    negative = mask & ~positive
    logits = logits.float()
    dims = tuple(range(1, logits.ndim))
    pc, nc = positive.sum(dims), negative.sum(dims)
    pl = (F.softplus(-logits)*positive).sum(dims)/pc.clamp_min(1)
    nl = (F.softplus(logits)*negative).sum(dims)/nc.clamp_min(1)
    classes = (pc>0).to(logits.dtype)+(nc>0).to(logits.dtype)
    per_window = (pl+nl)/classes.clamp_min(1)
    return per_window.sum()/(classes>0).sum().clamp_min(1)


def positive_quantity_huber(prediction, target, mask, threshold, quantity_scale):
    positive = mask & (target >= threshold)
    point = F.huber_loss((prediction.float()-target.float())/quantity_scale,
                         torch.zeros_like(prediction,dtype=torch.float32),reduction='none')
    dims = tuple(range(1, point.ndim))
    count = positive.sum(dims)
    per_window = (point*positive).sum(dims)/count.clamp_min(1)
    return per_window.sum()/(count>0).sum().clamp_min(1)


class PeakAuxBookLoss(ProbabilityBookLoss):
    def __init__(self, quantity_scale, add_location=False, add_amplitude=False,
                 peak_threshold=10., location_weight=1., amplitude_weight=1., **kwargs):
        super().__init__(quantity_scale,**kwargs)
        if not math.isfinite(peak_threshold) or peak_threshold<=0:
            raise ValueError('Positive finite peak threshold required')
        if any(not math.isfinite(w) or w<0 for w in [location_weight,amplitude_weight]):
            raise ValueError('Finite nonnegative peak weights required')
        self.add_location,self.add_amplitude=add_location,add_amplitude
        self.peak_threshold=peak_threshold
        self.location_weight,self.amplitude_weight=location_weight,amplitude_weight

    def forward(self,out,batch,beta=0.):
        values=super().forward(out,batch,beta)
        values['pre_peak_loss']=values['loss']
        values['peak_location_bce']=balanced_peak_bce(out['peak_logits'],batch['volume'],batch['mask'],self.peak_threshold)
        values['peak_amplitude_huber']=positive_quantity_huber(out['volume'],batch['volume'],batch['mask'],self.peak_threshold,self.quantity_scale)
        if self.add_location:
            values['loss']=values['loss']+self.location_weight*values['peak_location_bce']
        if self.add_amplitude:
            values['loss']=values['loss']+self.amplitude_weight*values['peak_amplitude_huber']
        values['reconstruction']=values['loss']-beta*values['kl']
        return values
