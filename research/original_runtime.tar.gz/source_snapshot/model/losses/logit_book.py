"""Replace only quantity Huber coordinates; keep all other losses intact."""
import math
import torch
from torch.nn import functional as F
from model.losses.probability_book import ProbabilityBookLoss


def inverse_softplus(value):
    """Stable for positive values, including values much greater than88."""
    return value+torch.log(-torch.expm1(-value))


class LogitBookLoss(ProbabilityBookLoss):
    def __init__(self,quantity_scale,use_logit=False,quantity_floor=1e-4,**kwargs):
        super().__init__(quantity_scale,**kwargs)
        if not math.isfinite(quantity_floor) or quantity_floor<=0:raise ValueError('Positive normalized quantity floor required')
        self.use_logit=use_logit;self.quantity_floor=quantity_floor

    def forward(self,out,batch,beta=0.):
        values=super().forward(out,batch,beta);values['pre_logit_loss']=values['loss']
        mask=batch['mask'];r=out['quantity_logit'].float()
        target=inverse_softplus((batch['volume'].float()/self.quantity_scale).clamp_min(self.quantity_floor))
        point=F.huber_loss(r,target,reduction='none')
        new=(point*mask).sum()/mask.sum().clamp_min(1)
        values['quantity_linear_huber']=values['quantity'];values['quantity_logit_huber']=new
        if self.use_logit:
            error=(out['volume'].float()-batch['volume'].float())/self.quantity_scale
            old=F.huber_loss(error,torch.zeros_like(error),reduction='none')
            idx=batch['volume'].masked_fill(~mask,-torch.inf).topk(min(self.topk,r.shape[-1]),-1).indices;chosen=mask.gather(-1,idx)
            delta=((point-old).gather(-1,idx)*chosen).sum()/chosen.sum().clamp_min(1)
            values['loss']=values['loss']+self.quantity_weight*(new-values['quantity'])+self.pair_weight*delta
            values['quantity']=new;values['pair']=values['pair']+delta
        values['reconstruction']=values['loss']-beta*values['kl']
        return values
