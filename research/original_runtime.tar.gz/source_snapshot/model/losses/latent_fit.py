"""Training-only, source-normalized objective for a free-code capacity probe."""
import torch
from torch import nn
from torch.nn import functional as F

from model.losses.local_peak import peak_neighborhood_kl


def _mean(value, mask):
    return value.masked_select(mask).sum() / mask.sum().clamp_min(1)


class LatentFitObjective(nn.Module):
    """Fixed per-window scales; this diagnostic does not train a model."""

    def __init__(self, quantity_scale):
        super().__init__()
        if quantity_scale <= 0:
            raise ValueError('quantity_scale must be positive')
        self.quantity_scale = float(quantity_scale)

    def components(self, out, batch):
        mask = batch['mask'].bool()
        p = out['price_norm'].float()
        q = out['volume'].float()
        target_p, target_q = batch['price'].float(), batch['volume'].float()
        # Replace invalid entries before nonlinear operations, including NaNs.
        p, target_p = (torch.where(mask, v, 0.) for v in (p, target_p))
        q, target_q = (torch.where(mask, v, 0.) for v in (q, target_q))
        frame_mask = mask[..., 0].all(-1)
        mid, target_mid = p[..., 0].mean(-1), target_p[..., 0].mean(-1)
        frame_pairs = frame_mask[:, 1:] & frame_mask[:, :-1]
        scale = self.quantity_scale
        positive = mask & (target_q >= 100.)
        negative = mask & ~positive
        linear = F.huber_loss(q / scale, target_q / scale, reduction='none')
        log = F.huber_loss(torch.log1p(q / scale), torch.log1p(target_q / scale), reduction='none')
        excess = F.relu((q - 100. + min(scale, 100.)) / scale)
        fp = F.huber_loss(excess, torch.zeros_like(excess), reduction='none')
        return dict(
            price=_mean((p - target_p).square(), mask),
            mid_delta=_mean((mid.diff(dim=1) - target_mid.diff(dim=1)).square(), frame_pairs),
            quantity=_mean(linear, mask),
            log_quantity=_mean(log, mask),
            positive=_mean(linear, positive),
            false_positive=_mean(fp, negative),
            local_peak=peak_neighborhood_kl(q, target_q, mask, quantity_scale=scale),
        )

    @staticmethod
    def calibration(components):
        # Training targets only, frozen once before the first optimizer update.
        return {name: max(float(value.detach()), 1e-4) for name, value in components.items()}

    def forward(self, out, batch, scales):
        values = self.components(out, batch)
        if set(scales) != set(values) or any(not (float(v) > 0) for v in scales.values()):
            raise ValueError('Need fixed positive scales for all seven components')
        return sum(value / scales[name] for name, value in values.items()), values
