"""Multiscale depth-axis morphological-gradient supervision of quantities."""
import math

import torch
from torch.nn import functional as F

from model.losses.quantity_dice import DiceOrderBookLoss


def quantity_morphology_loss(prediction,target,mask,*,scales=(3,9,33),quantity_scale=1.,huber_beta=1.):
    """Compare dilation-minus-erosion of log1p quantity profiles.

    Each minute and each side is processed independently along ranked depth.
    Only complete, valid structuring-element neighborhoods contribute.
    """
    if prediction.shape!=target.shape or prediction.shape!=mask.shape or prediction.ndim!=4:raise ValueError('Expected matched [B,T,2,L] arrays')
    if not math.isfinite(quantity_scale) or quantity_scale<=0 or not math.isfinite(huber_beta) or huber_beta<=0:raise ValueError('Positive finite morphology scale and beta required')
    if not scales or any(not isinstance(k,int) or k<3 or k%2==0 for k in scales):raise ValueError('Use odd structuring elements of size at least3')
    length=prediction.shape[-1]
    p=torch.log1p(prediction.float().masked_fill(~mask,0)/quantity_scale).reshape(-1,1,length)
    q=torch.log1p(target.float().masked_fill(~mask,0)/quantity_scale).reshape(-1,1,length)
    valid=mask.reshape(-1,1,length).float();terms={}
    for k in scales:
        if k>length:continue
        support=F.avg_pool1d(valid,k,stride=1,padding=k//2,count_include_pad=True)>=1.-1e-6
        pg=F.max_pool1d(p,k,stride=1,padding=k//2)+F.max_pool1d(-p,k,stride=1,padding=k//2)
        qg=F.max_pool1d(q,k,stride=1,padding=k//2)+F.max_pool1d(-q,k,stride=1,padding=k//2)
        error=F.smooth_l1_loss(pg,qg,reduction='none',beta=huber_beta).masked_fill(~support,0)
        row=error.sum(-1)/support.sum(-1).clamp_min(1);rows=support.any(-1)
        terms[str(k)]=row.masked_fill(~rows,0).sum()/rows.sum().clamp_min(1)
    if not terms:raise ValueError('All morphology neighborhoods exceed the available depth')
    return torch.stack(list(terms.values())).mean(),terms


class MorphologyDiceOrderBookLoss(DiceOrderBookLoss):
    """Keep approved Dice/price objective and add one morphology-gradient term."""
    def __init__(self,quantity_scale=1.,config=None,*,dice_weight=1.,epsilon=1e-6,morphology_weight=1.,scales=(3,9,33),huber_beta=1.):
        super().__init__(quantity_scale,config,dice_weight=dice_weight,epsilon=epsilon)
        if not math.isfinite(morphology_weight) or morphology_weight<=0:raise ValueError('Morphology weight must be positive and finite')
        self.morphology_weight,self.scales,self.huber_beta=morphology_weight,tuple(scales),huber_beta

    def forward(self,output,batch,kl_factor=1.):
        terms=super().forward(output,batch,kl_factor)
        morphology,scales=quantity_morphology_loss(output['volume'],batch['volume'],batch['mask'],scales=self.scales,
            quantity_scale=self.quantity_scale,huber_beta=self.huber_beta)
        return dict(terms,loss=terms['loss']+self.morphology_weight*morphology,quantity_morphology=morphology,
            **{'morphology_k'+k:v for k,v in scales.items()})
