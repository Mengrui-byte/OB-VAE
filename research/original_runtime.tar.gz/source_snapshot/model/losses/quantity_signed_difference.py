"""Oriented multiscale quantity differences with the approved Dice/price loss."""
import math

import torch
from torch.nn import functional as F

from model.losses.quantity_dice import DiceOrderBookLoss


def signed_quantity_difference_loss(prediction,target,mask,*,lags=(1,4,16),quantity_scale=1.,huber_beta=1.):
    """Compare signed log1p differences across ranked depth, independently per row.

    Differences are not divided by lag. The original morphology neighborhoods
    had widths3/9/33; these lags use their corresponding radii1/4/16.
    """
    if prediction.shape!=target.shape or prediction.shape!=mask.shape or prediction.ndim!=4:raise ValueError('Expected matched [B,T,2,L] arrays')
    if not lags or any(not isinstance(r,int) or r<1 for r in lags):raise ValueError('Positive integer difference lags required')
    if not math.isfinite(quantity_scale) or quantity_scale<=0 or not math.isfinite(huber_beta) or huber_beta<=0:raise ValueError('Positive finite scale and beta required')
    length=prediction.shape[-1]
    p=torch.log1p(prediction.float().masked_fill(~mask,0)/quantity_scale).reshape(-1,1,length)
    q=torch.log1p(target.float().masked_fill(~mask,0)/quantity_scale).reshape(-1,1,length)
    valid=mask.reshape(-1,1,length).float();terms={}
    for lag in lags:
        if lag>=length:continue
        support=F.avg_pool1d(valid,lag+1,stride=1)>=1.-1e-6
        pd=p[...,lag:]-p[...,:-lag];qd=q[...,lag:]-q[...,:-lag]
        error=F.smooth_l1_loss(pd,qd,reduction='none',beta=huber_beta).masked_fill(~support,0)
        row=error.sum(-1)/support.sum(-1).clamp_min(1);rows=support.any(-1)
        terms[str(lag)]=row.masked_fill(~rows,0).sum()/rows.sum().clamp_min(1)
    if not terms:raise ValueError('Difference lags exceed available depth')
    return torch.stack(list(terms.values())).mean(),terms


class SignedDifferenceDiceOrderBookLoss(DiceOrderBookLoss):
    def __init__(self,quantity_scale=1.,config=None,*,dice_weight=1.,epsilon=1e-6,difference_weight=1.,lags=(1,4,16),huber_beta=1.):
        super().__init__(quantity_scale,config,dice_weight=dice_weight,epsilon=epsilon)
        if not math.isfinite(difference_weight) or difference_weight<=0:raise ValueError('Positive finite difference weight required')
        self.difference_weight,self.lags,self.huber_beta=difference_weight,tuple(lags),huber_beta

    def forward(self,output,batch,kl_factor=1.):
        terms=super().forward(output,batch,kl_factor)
        difference,scales=signed_quantity_difference_loss(output['volume'],batch['volume'],batch['mask'],lags=self.lags,
            quantity_scale=self.quantity_scale,huber_beta=self.huber_beta)
        return dict(terms,loss=terms['loss']+self.difference_weight*difference,quantity_signed_difference=difference,
            **{'signed_difference_lag'+k:v for k,v in scales.items()})
