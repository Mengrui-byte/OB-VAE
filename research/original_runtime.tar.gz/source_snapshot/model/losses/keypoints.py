"""Native-rank peak targets, auxiliary losses and diagnostics."""

import math
import torch
from torch.nn import functional as F


@torch.no_grad()
def make_keypoint_targets(
    x, mask, quantity_scale, threshold=100.0, radius=2, sigma=1.0
):
    quantity = x[..., 1].masked_fill(~mask, -torch.inf)
    left = F.pad(quantity[..., :-1], (1, 0), value=-torch.inf)
    right = F.pad(quantity[..., 1:], (0, 1), value=-torch.inf)
    centers = (
        mask
        & (quantity >= threshold / quantity_scale)
        & (quantity >= left)
        & (quantity > right)
    )
    heatmap = centers.float()
    for distance in range(1, radius + 1):
        weight = math.exp(-0.5 * (distance / sigma) ** 2)
        heatmap = torch.maximum(
            heatmap, F.pad(centers[..., :-distance].float(), (distance, 0)) * weight
        )
        heatmap = torch.maximum(
            heatmap, F.pad(centers[..., distance:].float(), (0, distance)) * weight
        )
    return dict(
        centers=centers,
        heatmap=heatmap.masked_fill(~mask, 0),
        mask=mask,
        height=x[..., 1].detach(),
    )


def keypoint_losses(prediction, target):
    """Balanced Gaussian-weighted focal loss + positive-center height Huber.

    Gaussian shoulders discount nearby negative penalties; the only positive
    centers have target1. This is a balanced adaptation, not the original
    CenterNet normalizer. Radius is in native ranks, not physical-price bps.
    """
    logits = prediction["logits"].float()
    probability = logits.sigmoid()
    positive = target["centers"]
    negative = target["mask"] & ~positive
    positive_loss = -F.logsigmoid(logits) * (1 - probability).square()
    negative_loss = (
        -F.logsigmoid(-logits) * probability.square() * (1 - target["heatmap"]).pow(4)
    )
    detection = 0.5 * (
        positive_loss.masked_fill(~positive, 0).sum() / positive.sum().clamp_min(1)
        + negative_loss.masked_fill(~negative, 0).sum() / negative.sum().clamp_min(1)
    )
    height = F.smooth_l1_loss(
        prediction["height"].float(), target["height"], reduction="none"
    )
    height = height.masked_fill(~positive, 0).sum() / positive.sum().clamp_min(1)
    return dict(detection=detection, height=height)


@torch.no_grad()
def keypoint_statistics(prediction, target, quantity_scale):
    logits = prediction["logits"]
    left = F.pad(logits[..., :-1], (1, 0), value=-torch.inf)
    right = F.pad(logits[..., 1:], (0, 1), value=-torch.inf)
    selected = target["mask"] & (logits >= 0) & (logits >= left) & (logits > right)
    truth = target["centers"]
    error = (prediction["height"].float() - target["height"]) * quantity_scale
    return dict(
        true_peaks=int(truth.sum()),
        predicted_peaks=int(selected.sum()),
        exact_rank_matches=int((selected & truth).sum()),
        squared_height_error_btc=float(error.square().masked_fill(~truth, 0).sum()),
    )
