"""Threshold supervision tied to reconstructed physical quantity itself."""
import math

import torch
from torch.nn import functional as F

from model.losses.recall_guard import RecallGuardBookLoss


def positive_quantity_logit(prediction,target,mask,threshold=100.,temperature=1.,floor=1e-6):
    if prediction.shape!=target.shape or prediction.shape!=mask.shape:raise ValueError('Mismatching quantities/mask')
    if any(not math.isfinite(v) or v<=0 for v in [threshold,temperature,floor]):raise ValueError('Positive finite logit parameters required')
    positive=mask&(target>=threshold)
    quantity=prediction.float().masked_fill(~mask,0)
    score=(quantity.clamp_min(floor).log()-math.log(threshold))/temperature
    point=F.softplus(-score) # BCEWithLogits(score, target=1), positives only.
    return (point*positive).sum()/positive.sum().clamp_min(1)


class LargeLogitBookLoss(RecallGuardBookLoss):
    def __init__(self,quantity_scale,*,positive_logit_weight=0.,logit_temperature=1.,quantity_floor=1e-6,**kwargs):
        super().__init__(quantity_scale,**kwargs)
        if not math.isfinite(positive_logit_weight) or positive_logit_weight<0:raise ValueError('Invalid positive logit weight')
        if any(not math.isfinite(v) or v<=0 for v in [logit_temperature,quantity_floor]):raise ValueError('Invalid logit temperature/floor')
        self.positive_logit_weight=positive_logit_weight;self.logit_temperature=logit_temperature;self.quantity_floor=quantity_floor

    def forward(self,out,batch,beta=0.,teacher_local=None):
        values=super().forward(out,batch,beta,teacher_local);values['pre_positive_logit_loss']=values['loss']
        extra=positive_quantity_logit(out['volume'],batch['volume'],batch['mask'],self.large_threshold,self.logit_temperature,self.quantity_floor)
        values['positive_quantity_logit']=extra
        if self.positive_logit_weight:values['loss']=values['loss']+self.positive_logit_weight*extra
        values['reconstruction']=values['loss']-beta*values['kl']
        return values
