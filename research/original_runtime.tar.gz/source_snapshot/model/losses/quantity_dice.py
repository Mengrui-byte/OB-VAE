"""Squared continuous Dice for sparse quantities; preserve price supervision."""
from dataclasses import replace
import math

import torch
from torch import nn

from model.losses.dual import DualLossConfig,DualVAELoss


def continuous_quantity_dice(prediction,target,mask,*,quantity_scale=1.,epsilon=1e-6):
    """Average Dice over valid [batch,time,side] rows, reducing the depth axis.

    Quantities are nonnegative continuous amounts, not binary occupancy labels.
    Squared norms keep the score bounded even when quantities exceed one.
    """
    if prediction.shape!=target.shape or prediction.shape!=mask.shape or prediction.ndim!=4:raise ValueError('Expected matched [B,T,2,L] quantities and mask')
    if not math.isfinite(quantity_scale) or quantity_scale<=0 or not math.isfinite(epsilon) or epsilon<=0:raise ValueError('Dice scale and epsilon must be positive and finite')
    p=prediction.float().masked_fill(~mask,0)/quantity_scale
    q=target.float().masked_fill(~mask,0)/quantity_scale
    numerator=2*(p*q).sum(-1)+epsilon
    denominator=p.square().sum(-1)+q.square().sum(-1)+epsilon
    loss=1-numerator/denominator
    valid=mask.any(-1)
    return loss.masked_fill(~valid,0).sum()/valid.sum().clamp_min(1)


class DiceOrderBookLoss(nn.Module):
    """Replace all quantity terms with Dice while keeping price weights exact."""
    def __init__(self,quantity_scale=1.,config=None,*,dice_weight=1.,epsilon=1e-6):
        super().__init__()
        if not math.isfinite(dice_weight) or dice_weight<=0:raise ValueError('Dice weight must be positive and finite')
        self.quantity_scale,self.dice_weight,self.epsilon=quantity_scale,dice_weight,epsilon
        self.price_config=replace(config or DualLossConfig(),volume_log=0.,volume_linear=0.,volume_tail=0.)
        self.price_objective=DualVAELoss(quantity_scale,self.price_config)

    def forward(self,output,batch,kl_factor=1.):
        terms=self.price_objective(output,batch,kl_factor)
        dice=continuous_quantity_dice(output['volume'],batch['volume'],batch['mask'],quantity_scale=self.quantity_scale,epsilon=self.epsilon)
        return dict(terms,loss=terms['loss']+self.dice_weight*dice,quantity_dice=dice,price_objective=terms['loss'])
