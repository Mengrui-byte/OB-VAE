"""Identical predeclared reconstruction objective in every structural arm."""

from model.losses.keypoints import make_keypoint_targets
from model.losses.peaks import main_peak_loss


def objective(prediction, target, context, normalizer, quantity_scale):
    book = normalizer.loss_sum(prediction, target, context) / context["mask"].sum()
    centers = make_keypoint_targets(target, context["mask"], quantity_scale)["centers"]
    peak = main_peak_loss(prediction, target, centers, context["mask"])
    return book + 0.1 * peak, dict(book=book, peak=peak)
