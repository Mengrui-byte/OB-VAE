"""Order-book losses modules."""
