"""Reconstruction-only quantization objective, including observed time changes."""

import torch
from torch import nn

from model.losses.dual import DualLossConfig,DualVAELoss,window_mean


class QuantizedBookLoss(nn.Module):
    def __init__(self,quantity_scale=1.):
        super().__init__();self.quantity_scale=quantity_scale
        self.base=DualVAELoss(quantity_scale,DualLossConfig(price=1.,volume_log=1.,volume_linear=.05,
            gap_log=.05,spread_log=.05,mid=.1,volume_tail=.25,beta_global=0.,beta_local=0.))

    def forward(self,out,batch):
        value=self.base(out,batch);mask=batch['mask'][:,1:]&batch['mask'][:,:-1]
        target=torch.log1p(batch['volume']/self.quantity_scale)
        estimate=torch.log1p(out['volume']/self.quantity_scale)
        dq=window_mean(((estimate[:,1:]-estimate[:,:-1])-(target[:,1:]-target[:,:-1])).square(),mask).mean()
        dp=window_mean(((out['price_norm'][:,1:]-out['price_norm'][:,:-1])
                       -(batch['price'][:,1:]-batch['price'][:,:-1])).square(),mask).mean()
        loss=value['loss']+.5*dq+.1*dp+.01*out['latent_mse']
        return dict(value,loss=loss,temporal_quantity=dq,temporal_price=dp,latent_mse=out['latent_mse'])
