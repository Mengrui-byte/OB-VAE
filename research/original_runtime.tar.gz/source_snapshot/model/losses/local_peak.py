"""Conditional quantity-shape KL around true large levels, at fixed ranks."""
import math

import torch

from model.losses.recall_guard import RecallGuardBookLoss


def peak_neighborhood_kl(prediction,target,mask,quantity_scale=1.,threshold=100.,radius=8,floor=1e-6,kernel='gather'):
    if prediction.shape!=target.shape or prediction.shape!=mask.shape or prediction.ndim!=4:raise ValueError('Expected matching[B,T,2,L] quantities/mask')
    if type(radius) is not int or radius<1:raise ValueError('Positive integer radius required')
    if any(not math.isfinite(v) or v<=0 for v in [quantity_scale,threshold,floor]):raise ValueError('Positive finite normalization required')
    if kernel not in ['gather','unfold']:raise ValueError('Unknown peak neighborhood kernel')
    # The center is always a real valid large level; no assignment/reordering.
    centers=(mask&(target>=threshold)).nonzero(as_tuple=True)
    if centers[0].numel()==0:return prediction.float().masked_fill(~mask,0).sum()*0
    if kernel=='unfold':
        # Unique center selection followed by unfold's ordered overlap reduction;
        # avoid repeated scatter-adds into the same input level in index backward.
        positive=mask&(target>=threshold)
        def windows(value):return torch.nn.functional.pad(value,(radius,radius)).unfold(-1,2*radius+1,1)[positive]
        valid=windows(mask)
        q=windows(target.float().masked_fill(~mask,0))/quantity_scale
        h=windows(prediction.float().masked_fill(~mask,0))/quantity_scale
    else:
        b,t,s,level=centers;offset=torch.arange(-radius,radius+1,device=prediction.device)
        idx=level[:,None]+offset[None,:];in_range=(idx>=0)&(idx<prediction.shape[-1]);idx=idx.clamp(0,prediction.shape[-1]-1)
        valid=in_range&mask[b[:,None],t[:,None],s[:,None],idx]
        q=target.float()[b[:,None],t[:,None],s[:,None],idx].masked_fill(~valid,0)/quantity_scale
        h=prediction.float()[b[:,None],t[:,None],s[:,None],idx].masked_fill(~valid,0)/quantity_scale
    p=q/q.sum(-1,keepdim=True).clamp_min(1e-12)
    stable=h+floor*valid;ph=stable/stable.sum(-1,keepdim=True).clamp_min(1e-12)
    return (p*(p.clamp_min(1e-12).log()-ph.clamp_min(1e-12).log())).sum(-1).mean()


class LocalPeakBookLoss(RecallGuardBookLoss):
    def __init__(self,quantity_scale,*,local_peak_weight=0.,local_peak_radius=8,local_peak_kernel='gather',**kwargs):
        super().__init__(quantity_scale,**kwargs)
        if not math.isfinite(local_peak_weight) or local_peak_weight<0:raise ValueError('Nonnegative finite local peak weight required')
        if type(local_peak_radius) is not int or local_peak_radius<1:raise ValueError('Positive integer radius required')
        if local_peak_kernel not in ['gather','unfold']:raise ValueError('Unknown peak neighborhood kernel')
        self.local_peak_weight=local_peak_weight;self.local_peak_radius=local_peak_radius
        self.local_peak_kernel=local_peak_kernel

    def forward(self,out,batch,beta=0.,teacher_local=None):
        values=super().forward(out,batch,beta,teacher_local);values['pre_local_peak_loss']=values['loss']
        extra=peak_neighborhood_kl(out['volume'],batch['volume'],batch['mask'],self.quantity_scale,self.large_threshold,self.local_peak_radius,kernel=self.local_peak_kernel)
        values['local_peak_kl']=extra
        if self.local_peak_weight:values['loss']=values['loss']+self.local_peak_weight*extra
        values['reconstruction']=values['loss']-beta*values['kl']
        return values
