"""Independently allocate global and Top-k quantity gradients.

The price objective, log-quantity term, distribution KL and mass term keep
their original weights. No model parameters or forward predictions change.
"""
import math

import torch
from torch.nn import functional as F

from model.losses.controlled_book import ControlledBookLoss


class AllocationBookLoss(ControlledBookLoss):
    def __init__(self, quantity_scale, global_quantity_weight=1.,
                 top_quantity_weight=.25, **kwargs):
        super().__init__(quantity_scale, **kwargs)
        if self.mode not in ('baseline', 'shape_kl', 'mass', 'shape_mass'):
            raise ValueError('Allocation control requires the original Huber terms')
        for weight in (global_quantity_weight, top_quantity_weight):
            if not math.isfinite(weight) or weight < 0:
                raise ValueError('Quantity weights must be finite and nonnegative')
        self.global_quantity_weight = global_quantity_weight
        self.top_quantity_weight = top_quantity_weight

    def forward(self, out, batch, beta=0.):
        values = super().forward(out, batch, beta)
        mask = batch['mask']
        idx = batch['volume'].masked_fill(~mask, -torch.inf).topk(
            min(self.topk, mask.shape[-1]), dim=-1).indices
        chosen = mask.gather(-1, idx)
        count = chosen.sum().clamp_min(1)
        dq = (out['volume'].float() - batch['volume'].float()) / self.quantity_scale
        dp = out['price_norm'].float() - batch['price'].float()
        top_q = (F.huber_loss(dq, torch.zeros_like(dq), reduction='none')
                 .gather(-1, idx) * chosen).sum() / count
        top_p = (F.huber_loss(dp, torch.zeros_like(dp), reduction='none')
                 .gather(-1, idx) * chosen).sum() / count
        # Preserve the baseline expression exactly when weights are unchanged.
        values['loss'] = (values['loss']
                          + (self.global_quantity_weight - self.quantity_weight)
                          * values['quantity']
                          + (self.top_quantity_weight - self.pair_weight) * top_q)
        # Pure task objectives for gradient audits; do not subtract nearly equal
        # full losses, which can introduce price-gradient cancellation artifacts.
        values['price_objective'] = self.price_weight * values['price'] + self.pair_weight * top_p
        values['quantity_objective'] = (
            self.global_quantity_weight * values['quantity']
            + self.quantity_weight * self.log_weight * values['quantity_log']
            + self.top_quantity_weight * top_q
            + self.shape_weight * values['quantity_shape_kl']
            + self.mass_weight * values['quantity_mass'])
        values['pair_price'] = top_p
        values['pair_quantity'] = top_q
        values['reconstruction'] = values['loss'] - beta * values['kl']
        return values
