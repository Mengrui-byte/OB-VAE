"""Named, immutable configurations for the current MLP model family."""

from dataclasses import dataclass


@dataclass(frozen=True)
class MLPConfig:
    width: int = 192
    spatial_hidden: tuple[int, ...] = (512,)
    temporal_hidden: tuple[int, ...] = (256,)

    def variant(self):
        """Return the existing experiment/checkpoint configuration contract."""
        return dict(
            new_encoder=True,
            new_decoder=False,
            bottleneck="mlp",
            width=self.width,
            mlp_spatial_hidden=list(self.spatial_hidden),
            mlp_temporal_hidden=list(self.temporal_hidden),
        )


MLP_STANDARD = MLPConfig()
MLP_THICK = MLPConfig(width=256, spatial_hidden=(1024, 512), temporal_hidden=(512, 256))
MLP_CONFIGS = {"mlp_standard": MLP_STANDARD, "mlp_thick": MLP_THICK}

# Architecture arguments from the completed 2022–2024 MLP experiments.
# These constants define the model; callers must use their own training-fitted
# normalizer when the dataset changes. No checkpoint weights are loaded here.
DEFAULT_AE_ARGS = dict(
    quantity_mode="patch-residual",
    conv_order="alternating",
    book_structure="price-aligned",
    local_peak_slots=4,
    peak_mode="none",
    price_scale=96.22974480220505,
    price_normalization="window-anchor",
)
