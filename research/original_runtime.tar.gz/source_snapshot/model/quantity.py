"""Compatibility import; implement model changes in model.autoencoder.quantity."""

import sys
from importlib import import_module

_implementation = import_module("model.autoencoder.quantity")
sys.modules[__name__] = _implementation
