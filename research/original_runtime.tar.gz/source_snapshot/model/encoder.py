"""Compatibility import; implement model changes in model.autoencoder.encoder."""

import sys
from importlib import import_module

_implementation = import_module("model.autoencoder.encoder")
sys.modules[__name__] = _implementation
