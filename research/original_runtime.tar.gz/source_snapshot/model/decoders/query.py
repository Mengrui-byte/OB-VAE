"""Alternative latent-only coordinate-query decoder; opt-in, not the MLP default."""

import math
import torch
from torch import nn
from torch.nn import functional as F


class QueryDecoder(nn.Module):
    """Coordinate queries read only the compact code; output ordered price/size.

    Predicts all32 native outputs within each cell. A separate compact-code-only
    mixture branch can add two narrow, continuous-position peaks per cell.
    Positive normalized gaps enforce monotonicity, but final physical rounding
    ties are explicitly measured rather than claimed impossible.
    """

    def __init__(
        self,
        width=192,
        peak_decoder=True,
        ordered_price=True,
        fourier=True,
        quantity_scale=8.275,
    ):
        super().__init__()
        self.peak_decoder, self.ordered_price = peak_decoder, ordered_price
        self.width = width
        self.memory_projection = nn.Linear(8, width)
        self.memory_time = nn.Embedding(16, width)
        self.memory_region = nn.Embedding(8, width)
        self.time = nn.Embedding(256, width)
        self.side = nn.Embedding(2, width)
        self.level = nn.Embedding(64, width)
        self.fourier = nn.Linear(8, width, bias=False) if fourier else None
        self.attention = nn.MultiheadAttention(width, 4, batch_first=True, dropout=0.0)
        self.refine = nn.Sequential(
            nn.LayerNorm(width),
            nn.Linear(width, 2 * width),
            nn.GELU(),
            nn.Linear(2 * width, width),
        )
        self.quantity = nn.Linear(width, 32)
        self.price = nn.Linear(width, 32)
        self.best = nn.Linear(width, 2)
        self.peak = nn.Linear(width, 8) if peak_decoder else None
        nn.init.constant_(self.quantity.bias, -4.0)
        nn.init.normal_(self.price.weight, std=0.001)
        nn.init.constant_(self.price.bias, -10.0 if ordered_price else 0.0)
        nn.init.normal_(self.best.weight, std=0.001)
        with torch.no_grad():
            self.best.bias.copy_(torch.tensor([0.0, -12.0]))
            if self.peak is not None:
                nn.init.normal_(self.peak.weight, std=0.001)
                bias = self.peak.bias.reshape(2, 4)
                height = 10.0 / quantity_scale
                bias[:, 0] = math.log(math.expm1(height))
                bias[:, 1] = torch.logit(torch.tensor([0.25, 0.75]))
                bias[:, 2] = -2.0
                bias[:, 3] = -4.0

    def forward(self, z):
        b, n, d = z.shape
        t = n * 16
        if d != 64 or n > 16:
            raise ValueError("Expected [B,T/16,64] with T<=256")
        memory = self.memory_projection(z.reshape(b, n, 8, 8))
        memory = (
            memory
            + self.memory_time.weight[:n][None, :, None]
            + self.memory_region.weight[None, None]
        )
        memory = memory.flatten(1, 2)
        query = (
            self.time.weight[:t, None, None]
            + self.side.weight[None, :, None]
            + self.level.weight[None, None]
        )
        if self.fourier is not None:
            rank = (
                torch.linspace(0.0, 1.0, 64, device=z.device)[:, None]
                * torch.tensor([1.0, 2.0, 4.0, 8.0], device=z.device)
                * math.pi
            )
            query = (
                query
                + self.fourier(torch.cat([rank.sin(), rank.cos()], -1))[None, None]
            )
        query = query.reshape(1, t * 128, self.width).expand(b, -1, -1)
        value, _ = self.attention(query, memory, memory, need_weights=False)
        value = query + value
        value = (value + self.refine(value)).reshape(b, t, 2, 64, self.width)
        q = F.softplus(self.quantity(value)).float()
        if self.peak is not None:
            raw = self.peak(value).reshape(b, t, 2, 64, 2, 4).float()
            height = F.softplus(raw[..., 0]) * raw[..., 3].sigmoid()
            center = 31.0 * raw[..., 1].sigmoid()
            sigma = 0.15 + 3.0 * raw[..., 2].sigmoid()
            ranks = torch.arange(32, device=z.device, dtype=raw.dtype)
            peaks = height[..., None] * torch.exp(
                -0.5 * ((ranks - center[..., None]) / sigma[..., None]).square()
            )
            q = q + peaks.sum(-2)
        q = q.flatten(-2)
        p = self.price(value).float().flatten(-2)
        if self.ordered_price:
            mid_spread = self.best(value[:, :, :, 0].mean(2)).float()
            mid, spread = mid_spread[..., 0], F.softplus(mid_spread[..., 1])
            distance = F.softplus(p).cumsum(-1)
            signs = torch.tensor([-1.0, 1.0], device=z.device)[None, None, :, None]
            p = mid[:, :, None, None] + signs * (
                0.5 * spread[:, :, None, None] + distance
            )
        return torch.stack([p, q], -1)
