"""Price-decoder experiment: anchor the whole raw mid curve to its first value."""
import torch
from torch.nn import functional as F
from model.decoders.unified_book import PriceDecoder


def anchor_mid_curve(raw_mid,mode='absolute'):
    if raw_mid.ndim!=2 or raw_mid.shape[1]<1:raise ValueError('Expected [batch,time] raw midpoint')
    if mode=='absolute':return torch.cat((torch.zeros_like(raw_mid[:,:1]),raw_mid[:,1:]),1)
    if mode=='relative':return raw_mid-raw_mid[:,:1]
    raise ValueError('Unknown midpoint anchoring mode')


class RelativeMidPriceDecoder(PriceDecoder):
    def __init__(self,*args,anchor_mode='absolute',**kwargs):
        if anchor_mode not in ['absolute','relative']:raise ValueError('Unknown midpoint anchoring mode')
        super().__init__(*args,**kwargs);self.anchor_mode=anchor_mode

    def forward(self,z,mask,tick_norm,times):
        B,T,_,L=mask.shape
        frame=self.temporal(z,times);feature=self.spatial(frame,mask,times)
        raw_gap=self.gap(feature).reshape(B,T,2,L)[...,1:].float()
        ms=self.mid_spread(frame).float();tick=tick_norm.float()[:,None,None,None]
        mid=anchor_mid_curve(ms[...,0],self.anchor_mode)
        spread=tick_norm.float()[:,None]*(1+F.softplus(ms[...,1]))
        gap=tick*(1+F.softplus(raw_gap));distance=F.pad(gap.cumsum(-1,dtype=torch.float32),(1,0))
        sign=z.new_tensor([-1,1]).float()[None,None,:,None]
        price=mid[:,:,None,None]+sign*(spread[:,:,None,None]/2+distance)
        return dict(price_norm=price.masked_fill(~mask,0),mid_norm=mid,spread_norm=spread,gap_norm=gap,raw_mid_norm=ms[...,0])


def copy_with_mid_anchor(original,mode='absolute'):
    """Same parameter names/order/weights and temporal layout; no added parameters.

    Construction is RNG-isolated. The temporal module is shared with the original
    while other components copy its exact state; callers may discard the old
    decoder or restore it for a read-only paired probe.
    """
    device=next(original.parameters()).device
    with torch.random.fork_rng(devices=[]):
        new=RelativeMidPriceDecoder(levels=original.spatial.levels,
            activation_checkpointing=original.spatial.activation_checkpointing,anchor_mode=mode)
    new=new.to(device);new.temporal=original.temporal
    new.load_state_dict(original.state_dict(),strict=True);new.train(original.training)
    if [n for n,p in new.named_parameters()]!=[n for n,p in original.named_parameters()]:
        raise ValueError('Original price parameter mapping changed')
    return new
