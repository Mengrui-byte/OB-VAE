"""Small public construction API; training and dataset code stay outside model."""

from .config import DEFAULT_AE_ARGS, MLP_CONFIGS


def build_model(
    name="mlp_standard", *, seed=42, quantity_scale=8.275036238096039, ae_args=None
):
    """Build fresh weights for a named MLP configuration.

    For exact experiment replay, pass the recorded ``ae_args`` and scale, then
    load the checkpoint's ``model`` state with ``strict=True``.
    """
    from .backbone import BackboneModel

    if name not in MLP_CONFIGS:
        raise ValueError(f"Unknown model {name!r}; choose from {tuple(MLP_CONFIGS)}")
    args = dict(DEFAULT_AE_ARGS if ae_args is None else ae_args)
    return BackboneModel(args, MLP_CONFIGS[name].variant(), seed, quantity_scale)
