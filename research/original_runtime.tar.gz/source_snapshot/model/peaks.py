"""Compatibility import; implement model changes in model.autoencoder.peaks."""

import sys
from importlib import import_module

_implementation = import_module("model.autoencoder.peaks")
sys.modules[__name__] = _implementation
