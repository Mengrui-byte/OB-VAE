"""Compose independently selected encoders and decoders without changing state keys."""

import torch
from torch import nn
from model.autoencoder.ae import AE
from model.encoders.geometry import GeometryEncoder
from model.decoders.query import QueryDecoder
from model.layers.mlp import bottleneck_mlp
from model.layers.temporal import CausalScales


def variants():
    arms = {
        "A_old_encoder_old_decoder": dict(new_encoder=False, new_decoder=False),
        "B_new_encoder_old_decoder": dict(new_encoder=True, new_decoder=False),
        "C_old_encoder_new_decoder": dict(new_encoder=False, new_decoder=True),
        "D_new_encoder_new_decoder": dict(new_encoder=True, new_decoder=True),
    }
    for feature in [
        "peak_encoder",
        "temporal_attention",
        "fourier",
        "peak_decoder",
        "multiscale",
        "ordered_price",
        "native_patch",
    ]:
        arms["D_without_" + feature] = dict(
            new_encoder=True, new_decoder=True, **{feature: False}
        )
    arms["D_width256"] = dict(new_encoder=True, new_decoder=True, width=256)
    return arms


class BackboneModel(nn.Module):
    def __init__(self, args, variant, seed, quantity_scale):
        super().__init__()
        self.variant = variant
        # All core components start fresh. Shared old/new components have exactly
        # identical initialization across their factorial counterparts per seed.
        with torch.random.fork_rng():
            torch.manual_seed(seed + 100)
            original = AE(
                quantity_mode=args["quantity_mode"],
                conv_order=args["conv_order"],
                book_structure=args["book_structure"],
                local_peak_slots=args["local_peak_slots"],
                peak_mode=args["peak_mode"],
                peak_price_scale=args["price_scale"],
                peak_price_normalization=args["price_normalization"],
            )
        options = {
            k: variant.get(k, True)
            for k in [
                "peak_encoder",
                "temporal_attention",
                "fourier",
                "multiscale",
                "native_patch",
            ]
        }
        if variant["new_encoder"]:
            with torch.random.fork_rng():
                torch.manual_seed(seed + 200)
                self.encoder = GeometryEncoder(
                    width=variant.get("width", 192),
                    bottleneck=variant.get("bottleneck", "mlp"),
                    mlp_spatial_hidden=variant.get("mlp_spatial_hidden", (512,)),
                    mlp_temporal_hidden=variant.get("mlp_temporal_hidden", (256,)),
                    **options,
                )
        else:
            self.encoder = original.encoder
        if variant["new_decoder"]:
            with torch.random.fork_rng():
                torch.manual_seed(seed + 300)
                self.decoder = QueryDecoder(
                    width=variant.get("width", 192),
                    peak_decoder=variant.get("peak_decoder", True),
                    ordered_price=variant.get("ordered_price", True),
                    fourier=variant.get("fourier", True),
                    quantity_scale=quantity_scale,
                )
        else:
            self.decoder = original.decoder
        for module in self.modules():
            if isinstance(module, nn.Dropout):
                module.p = 0.0
            if isinstance(module, nn.MultiheadAttention):
                module.dropout = 0.0
        self.z = None

    def encode(self, x):
        return self.encoder(x)

    def forward(self, x):
        self.z = self.encode(x)
        return self.decoder(self.z)
