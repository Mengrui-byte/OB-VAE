"""CLI and experiment orchestration: python -m train_dual --help."""

import argparse
from dataclasses import asdict
from datetime import date, datetime, timezone
import json
import math
import os
from pathlib import Path
import platform
import time

import torch
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel
from torch.utils.data import DataLoader, DistributedSampler

from model.dual import OrderBookVAE
from model.losses.dual import DualLossConfig, DualVAELoss
from train_dual.train.engine import run_epoch
from train_dual.util.checkpoint import (
    atomic_save, freeze_sources, random_state, restore_random_state,
    seed_everything, seed_worker, source_hashes, load_initial_weights,
)
from train_dual.util.data import DualNormalizer, DualWindowDataset
from train_dual.util.distributed import initialize, rank, unwrap, ValidationShard, world_size
from util.scaling import fit_feature_scales, load_feature_scales


def parse_args(argv=None):
    parser = argparse.ArgumentParser(description="共享 posterior 的双解码器订单簿 VAE 训练")
    parser.add_argument("--asset", default="binance-futures/BTCUSDT")
    parser.add_argument("--npz-dir", default="/mnt/Data/mengrui/2048_snapshot_dataset")
    parser.add_argument("--start", help="训练起始 UTC 日期 YYYY-MM-DD")
    parser.add_argument("--end", help="训练结束 UTC 日期，不含当天")
    parser.add_argument("--val-start", help="默认等于 --end")
    parser.add_argument("--val-end", help="验证结束 UTC 日期，不含当天")
    parser.add_argument("--tick-size", type=float, help="原始价格单位的 tick，必须明确指定")
    parser.add_argument("--levels", type=int, default=2048)
    parser.add_argument("--window-size", type=int, default=16)
    parser.add_argument("--stride", type=int, default=16)
    parser.add_argument("--time-unit-seconds", type=float, default=60.0)
    parser.add_argument("--price-scale", type=float, default=50.0, help="anchor 价格残差的 bps 缩放除数")
    parser.add_argument("--quantity-scale", type=float, default=1.0, help="模型内部 q0；输入数量保持原始单位")
    scales = parser.add_mutually_exclusive_group()
    scales.add_argument("--fit-feature-scales", action="store_true", help="仅用训练数据拟合价量 RMS，要求 levels=2048")
    scales.add_argument("--feature-scales-file", help="读取现有、通过数据身份校验的 window-anchor 尺度缓存")
    parser.add_argument("--global-dim", type=int, default=64)
    parser.add_argument("--local-dim", type=int, default=16)
    parser.add_argument("--causal", action="store_true", help="encoder 时间 TCN 使用因果卷积")
    parser.add_argument("--gap-activation", choices=("softplus", "relu"), default="softplus")
    parser.add_argument("--detach-price", action="store_true")
    parser.add_argument("--fix-first-mid", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--batch-size", type=int, default=1, help="每次前向的全局窗口数，必须能被 DDP GPU 数整除")
    parser.add_argument("--accumulation-steps", type=int, default=1)
    parser.add_argument("--epochs", type=int, default=20, help="包含已恢复 epoch 的总训练轮数")
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-2)
    parser.add_argument("--grad-clip", type=float, default=1.0, help="0 关闭裁剪；仍检查梯度是否有限")
    parser.add_argument("--precision", choices=("fp32", "bf16"), default="fp32")
    parser.add_argument("--kl-warmup-steps", type=int, default=1000, help="按 optimizer step 线性 warmup；0 关闭")
    parser.add_argument("--checkpoint-every-steps", type=int, default=0, help="每 N 次更新保存 preview.pt 供重建诊断；0 关闭")
    for name, default in asdict(DualLossConfig()).items():
        option = name.replace("_", "-")
        parser.add_argument("--" + (option if name.startswith("beta") else option + "-weight"),
                            dest="loss_" + name, type=float, default=default)
    parser.add_argument("--num-workers", type=int, default=0)
    parser.add_argument("--preload", action="store_true")
    parser.add_argument("--device", default="auto")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--save-dir", help="新实验目录；必须尚不存在")
    parser.add_argument("--resume", help="恢复本训练器生成的可信 last.pt；其参数作为默认值")
    parser.add_argument("--initial-weights", help="从已有权重开始一个新实验，不恢复优化器或随机状态")
    parser.add_argument("--quiet", action="store_true", help="关闭 batch 进度条，保留 epoch JSON")
    args = parser.parse_args(argv)
    checkpoint = None
    if args.resume:
        if Path(args.resume).name != "last.pt":
            parser.error("--resume 必须指定 last.pt；best.pt 用于推理")
        # Full local training state includes Python/NumPy RNG objects.
        checkpoint = torch.load(args.resume, map_location="cpu", weights_only=False)
        if checkpoint.get("format_version") != 1:
            parser.error("不支持的 checkpoint 格式")
        parser.set_defaults(**checkpoint["config"]["arguments"])
        args = parser.parse_args(argv)
    args.val_start = args.val_start or args.end
    try:
        for value in (args.start, args.end, args.val_start, args.val_end):
            if not value or date.fromisoformat(value).isoformat() != value:
                raise ValueError
        if not args.start < args.end <= args.val_start < args.val_end:
            raise ValueError
    except ValueError:
        parser.error("日期必须满足 start < end <= val-start < val-end，均为 YYYY-MM-DD")
    positive = (args.tick_size, args.price_scale, args.quantity_scale, args.lr, args.time_unit_seconds)
    if any(v is None or not math.isfinite(v) or v <= 0 for v in positive):
        parser.error("tick-size、price-scale、quantity-scale、lr、time-unit-seconds 必须是有限正数")
    if any(v <= 0 for v in (args.window_size, args.stride, args.global_dim, args.local_dim,
                            args.batch_size, args.accumulation_steps, args.epochs)):
        parser.error("窗口、stride、latent 维度、batch、累积步数和 epochs 必须为正数")
    if not 16 <= args.levels <= 2048 or args.levels % 16:
        parser.error("levels 必须为 [16,2048] 内的 16 的倍数")
    if (args.fit_feature_scales or args.feature_scales_file) and args.levels != 2048:
        parser.error("现有尺度拟合/缓存面向完整 2048 档；截断档位请显式传入尺度")
    if args.num_workers < 0 or args.kl_warmup_steps < 0 or args.checkpoint_every_steps < 0 or not 0 <= args.seed < 2**32:
        parser.error("workers、warmup 不能为负数；seed 必须在 [0,2**32) 内")
    if any(not math.isfinite(v) or v < 0 for v in (args.weight_decay, args.grad_clip)):
        parser.error("weight-decay、grad-clip 必须为有限非负数")
    try:
        DualLossConfig(**{name: getattr(args, "loss_" + name) for name in asdict(DualLossConfig())})
    except ValueError as error:
        parser.error(str(error))
    count = int(os.environ.get("WORLD_SIZE", "1"))
    if args.batch_size % count:
        parser.error("batch-size 必须能被 WORLD_SIZE 整除")
    if checkpoint:
        allowed = {"resume", "epochs", "device", "num_workers", "quiet", "checkpoint_every_steps"}
        for name, expected in checkpoint["config"]["arguments"].items():
            if name not in allowed and getattr(args, name) != expected:
                parser.error(f"续训参数不能改变: {name}")
        if args.epochs <= checkpoint["epoch"]:
            parser.error("epochs 必须大于 checkpoint 已完成轮数")
        if checkpoint.get("world_size", 1) != count:
            parser.error("续训必须使用与 checkpoint 相同的 WORLD_SIZE")
    return args, checkpoint


def dataset_identity(dataset):
    base = dataset.base
    path = Path(base.index_path)
    stat = path.stat()
    return {"path": str(path), "size": stat.st_size, "mtime_ns": stat.st_mtime_ns,
            "asset": base.asset, "minutes": len(base.times), "windows": len(dataset),
            "first_time_us": int(base.times[0]), "last_time_us": int(base.times[-1])}


def resolve_device(name):
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu") if name == "auto" else torch.device(name)
    if device.type not in ("cpu", "cuda"):
        raise ValueError("Only CPU and CUDA devices are supported")
    if device.type == "cuda":
        if not torch.cuda.is_available():
            raise ValueError("CUDA was requested but is unavailable")
        if device.index is None:
            device = torch.device("cuda:0")
    return device


def main(argv=None):
    args, checkpoint = parse_args(argv)
    device = initialize(args.device)
    try:
        return run_training(args, checkpoint, device)
    finally:
        if dist.is_initialized():
            dist.destroy_process_group()


def run_training(args, checkpoint, device):
    if device.type == "cuda" and args.precision == "bf16" and not torch.cuda.is_bf16_supported():
        raise ValueError("Selected CUDA device does not support BF16")
    seed_everything(args.seed)
    datasets = {}
    for split, start, end in (("train", args.start, args.end), ("val", args.val_start, args.val_end)):
        datasets[split] = DualWindowDataset(
            asset=args.asset, start=start, end=end, npz_dir=args.npz_dir,
            window_size=args.window_size, stride=args.stride, preload=args.preload,
            levels=args.levels, time_unit_seconds=args.time_unit_seconds)
        if len(datasets[split]) == 0:
            raise ValueError(f"{split} 区间没有完整、连续的分钟窗口")
    if checkpoint:
        args.price_scale = checkpoint["config"]["normalization"]["price_scale"]
        args.quantity_scale = checkpoint["model_config"]["quantity_scale"]
    elif rank() == 0:
        if args.feature_scales_file:
            args.price_scale, args.quantity_scale = load_feature_scales(
                args.feature_scales_file, datasets["train"].base, args.start, args.end, "window-anchor")
        elif args.fit_feature_scales:
            args.price_scale, args.quantity_scale = fit_feature_scales(
                datasets["train"].base, mask_invalid=True, price_normalization="window-anchor")
    if dist.is_initialized():
        scales = [args.price_scale, args.quantity_scale]
        dist.broadcast_object_list(scales, src=0)
        args.price_scale, args.quantity_scale = scales
    model_config = {name: getattr(args, name) for name in (
        "levels", "quantity_scale", "global_dim", "local_dim", "causal",
        "gap_activation", "detach_price", "fix_first_mid")}
    loss_config = DualLossConfig(**{name: getattr(args, "loss_" + name) for name in asdict(DualLossConfig())})
    normalizer = DualNormalizer(tick_size=args.tick_size, price_scale=args.price_scale)
    # Check both input contracts before creating a run or starting expensive training.
    for dataset in datasets.values():
        normalizer.prepare(next(iter(DataLoader(dataset, batch_size=1))), "cpu")
    model = OrderBookVAE(**model_config).to(device)
    initial_source = None
    if args.initial_weights and checkpoint is None:
        initial_source = load_initial_weights(model, args.initial_weights, model_config)
        args.initial_weights = initial_source["path"]
    if world_size() > 1:
        model = DistributedDataParallel(model, device_ids=[device.index] if device.type == "cuda" else None,
                                        broadcast_buffers=False)
        # Identical initialization, independent posterior samples across ranks.
        seed_everything(args.seed + rank())
    criterion = DualVAELoss(args.quantity_scale, loss_config).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
    generator = torch.Generator().manual_seed(args.seed + rank())
    samplers = {
        name: (DistributedSampler(dataset, seed=args.seed, shuffle=True, drop_last=True)
               if name == "train" else ValidationShard(dataset)) if world_size() > 1 else None
        for name, dataset in datasets.items()}
    loaders = {name: DataLoader(
        dataset, batch_size=args.batch_size // world_size(), shuffle=name == "train" and samplers[name] is None,
        sampler=samplers[name], drop_last=False,
        num_workers=args.num_workers, pin_memory=device.type == "cuda",
        generator=generator, worker_init_fn=seed_worker,
    ) for name, dataset in datasets.items()}
    identities = {name: dataset_identity(ds) for name, ds in datasets.items()}
    current_hashes = source_hashes()
    first_epoch, global_step, best_loss = 1, 0, math.inf
    if checkpoint:
        output_dir = Path(args.save_dir).expanduser().resolve()
        if Path(args.resume).resolve().parent != output_dir:
            raise ValueError("Resume checkpoint must be in its original run directory")
        if identities != checkpoint["config"]["data"]:
            raise ValueError("NPZ data identity has changed since the checkpoint")
        if current_hashes != checkpoint["source_hashes"]:
            raise ValueError("Model/trainer sources changed; resume from the frozen source_snapshot")
        history_path = output_dir / "history.jsonl"
        history = [json.loads(line) for line in history_path.read_text().splitlines() if line]
        if not history or history[-1]["epoch"] != checkpoint["epoch"]:
            raise ValueError("History/checkpoint epoch mismatch; preserve artifacts and resolve before resume")
        unwrap(model).load_state_dict(checkpoint["model"], strict=True)
        optimizer.load_state_dict(checkpoint["optimizer"])
        # Adam states loaded from CPU must follow the parameters onto CUDA.
        for state in optimizer.state.values():
            for name in ("exp_avg", "exp_avg_sq", "max_exp_avg_sq"):
                if name in state:
                    state[name] = state[name].to(device)
        first_epoch = checkpoint["epoch"] + 1
        global_step, best_loss = checkpoint["global_step"], checkpoint["best_loss"]
        states = checkpoint.get("rng_by_rank", [checkpoint["rng"]])
        restore_random_state(states[rank()], generator)
        config = checkpoint["config"]
        if rank() == 0:
            with (output_dir / "resume_events.jsonl").open("a") as stream:
                stream.write(json.dumps({"utc": datetime.now(timezone.utc).isoformat(),
                                         "from_epoch": checkpoint["epoch"], "arguments": vars(args)}) + "\n")
    else:
        output_name = args.save_dir or ("checkpoints/dual_" + datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S_%f"))
        if dist.is_initialized():
            names = [output_name]
            dist.broadcast_object_list(names, src=0)
            output_name = names[0]
        output_dir = Path(output_name).expanduser().resolve()
        if rank() == 0:
            output_dir.mkdir(parents=True, exist_ok=False)
        args.save_dir = str(output_dir)
        config = {"arguments": vars(args).copy(), "model": model_config, "loss": asdict(loss_config),
                  "initial_weights": initial_source,
                  "normalization": {"tick_size": args.tick_size, "price_scale": args.price_scale,
                                    "quantity_scale": args.quantity_scale, "anchor": "first-frame midpoint"},
                  "data": identities, "source_hashes": current_hashes,
                  "environment": {"python": platform.python_version(), "torch": str(torch.__version__),
                                  "device": str(device), "world_size": world_size()},
                  "batch_size_per_rank": args.batch_size // world_size(),
                  "effective_batch_size": args.batch_size * args.accumulation_steps,
                  "train_sampler": "drop up to world_size-1 windows per epoch; shuffle with epoch seed" if world_size() > 1 else "shuffle",
                  "parameters": sum(p.numel() for p in model.parameters())}
        if rank() == 0:
            freeze_sources(output_dir / "source_snapshot")
            (output_dir / "run_config.json").write_text(json.dumps(config, indent=2, ensure_ascii=False) + "\n")
    if dist.is_initialized():
        dist.barrier()
    if rank() == 0:
        print(json.dumps({"save_dir": str(output_dir), "device": str(device), "world_size": world_size(),
                          "train_windows": len(datasets["train"]), "val_windows": len(datasets["val"])}, ensure_ascii=False), flush=True)
    for epoch in range(first_epoch, args.epochs + 1):
        started = time.monotonic()
        if samplers["train"] is not None:
            samplers["train"].set_epoch(epoch)

        def save_preview(step):
            if rank() != 0 or not args.checkpoint_every_steps or step % args.checkpoint_every_steps:
                return
            preview = {"format_version": 1, "epoch": epoch, "epoch_completed": False,
                       "global_step": step, "model": unwrap(model).state_dict(),
                       "model_config": model_config, "config": config, "source_hashes": current_hashes,
                       "world_size": world_size(), "inference_only": True}
            atomic_save(preview, output_dir / "preview.pt")
            (output_dir / "progress.json").write_text(json.dumps({"epoch": epoch, "global_step": step,
                "epoch_completed": False, "world_size": world_size(),
                "effective_batch_size": args.batch_size * args.accumulation_steps,
                "cuda_peak_allocated_gib": torch.cuda.max_memory_allocated(device) / 2**30 if device.type == "cuda" else None,
                "utc": datetime.now(timezone.utc).isoformat()}) + "\n")

        train_metrics, global_step = run_epoch(
            model, loaders["train"], normalizer, criterion, device, optimizer=optimizer,
            global_step=global_step, kl_warmup_steps=args.kl_warmup_steps,
            accumulation_steps=args.accumulation_steps, grad_clip=args.grad_clip,
            precision=args.precision, progress=not args.quiet, step_callback=save_preview)
        val_metrics, _ = run_epoch(model, loaders["val"], normalizer, criterion, device,
                                   precision=args.precision, progress=not args.quiet)
        improved = val_metrics["loss"] < best_loss
        best_loss = min(best_loss, val_metrics["loss"])
        row = {"epoch": epoch, "global_step": global_step, "seconds": time.monotonic() - started,
               "train": train_metrics, "val": val_metrics, "best_val_loss": best_loss}
        state = random_state(generator)
        states = [None] * world_size()
        if dist.is_initialized():
            dist.all_gather_object(states, state)
        else:
            states = [state]
        payload = {"format_version": 1, "epoch": epoch, "global_step": global_step,
                   "best_loss": best_loss, "model": unwrap(model).state_dict(),
                   "optimizer": optimizer.state_dict(), "rng": states[0], "rng_by_rank": states,
                   "world_size": world_size(),
                   "config": config, "model_config": model_config,
                   "source_hashes": current_hashes, "metrics": row}
        if rank() == 0:
            if improved:
                atomic_save(payload, output_dir / "best.pt")
            atomic_save(payload, output_dir / "last.pt")
            with (output_dir / "history.jsonl").open("a") as stream:
                stream.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
            print(json.dumps(row, ensure_ascii=False, allow_nan=False), flush=True)
    return output_dir


if __name__ == "__main__":
    main()
