"""FP32/BF16 and DDP training with exact tail accumulation."""

from contextlib import nullcontext
import math

import torch
import torch.distributed as dist
from tqdm.auto import tqdm

from train_dual.util.metrics import DualMetrics
from train_dual.util.distributed import rank, unwrap, world_size


def kl_warmup(global_step, warmup_steps):
    return min(1.0, global_step / warmup_steps) if warmup_steps else 1.0


def forward(model, batch, *, sample):
    return model(batch["price"], batch["volume"], batch["mask"], batch["tick_norm"],
                 times=batch["times"], sample=sample)


def run_epoch(model, loader, normalizer, criterion, device, *, optimizer=None,
              global_step=0, kl_warmup_steps=1000, accumulation_steps=1,
              grad_clip=1.0, precision="fp32", progress=True, step_callback=None):
    """Return (metrics, optimizer_steps). Validation always uses posterior means.

    Reconstruction and KL are averaged within each window, then over windows.
    Accumulated gradients divide by the actual window count, including the tail.
    Validation uses full configured KL weights so checkpoint scores stay comparable.
    """
    if accumulation_steps <= 0 or kl_warmup_steps < 0 or global_step < 0:
        raise ValueError("Invalid accumulation or KL schedule")
    if precision not in ("fp32", "bf16") or not math.isfinite(grad_clip) or grad_clip < 0:
        raise ValueError("Invalid precision or gradient clip")
    training = optimizer is not None
    if len(loader) == 0 and training:
        raise ValueError("DataLoader has no batches")
    device = torch.device(device)
    model.train(training)
    active_model = model if training else unwrap(model)
    metrics = DualMetrics()
    group_samples = 0
    if training:
        optimizer.zero_grad(set_to_none=True)
    show_progress = progress and rank() == 0
    iterator = tqdm(loader, desc="Train" if training else "Valid", unit="batch", disable=not show_progress)
    factor = kl_warmup(global_step, kl_warmup_steps) if training else 1.0
    with torch.set_grad_enabled(training):
        for index, raw in enumerate(iterator):
            batch = normalizer.prepare(raw, device)
            factor = kl_warmup(global_step, kl_warmup_steps) if training else 1.0
            update = (index + 1) % accumulation_steps == 0 or index + 1 == len(loader)
            sync = model.no_sync() if training and hasattr(model, "no_sync") and not update else nullcontext()
            # DDP no_sync must wrap both forward and backward.
            with sync:
                with torch.autocast(device_type=device.type, dtype=torch.bfloat16, enabled=precision == "bf16"):
                    output = forward(active_model, batch, sample=training)
                losses = criterion(output, batch, kl_factor=factor)
                if not bool(torch.stack([v.detach() for v in losses.values()]).isfinite().all()):
                    raise FloatingPointError("Nonfinite dual VAE loss")
                if training:
                    size = len(batch["price"])
                    (losses["loss"] * size).backward()
            if training:
                group_samples += size
                if update:
                    count = torch.tensor(group_samples, device=device, dtype=torch.float64)
                    if dist.is_initialized():
                        dist.all_reduce(count)
                    gradient_factor = world_size() / count.item()
                    for parameter in model.parameters():
                        if parameter.grad is not None:
                            parameter.grad.mul_(gradient_factor)
                    torch.nn.utils.clip_grad_norm_(
                        model.parameters(), grad_clip if grad_clip else float("inf"), error_if_nonfinite=True)
                    optimizer.step()
                    optimizer.zero_grad(set_to_none=True)
                    group_samples = 0
                    global_step += 1
                    if step_callback is not None:
                        step_callback(global_step)
            metrics.update(output, batch, losses)
            if show_progress:
                iterator.set_postfix(loss=f'{losses["loss"].item():.5g}', kl=f'{factor:.3f}')
    result = metrics.compute(device=device)
    result["kl_factor"] = factor
    return result, global_step
