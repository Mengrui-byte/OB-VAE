"""Optimistic, label-dependent bounds for fixed regional quantity mass."""
import math

import torch


def fixed_region_mass_bound(prediction,target,mask,*,region_width=16,threshold=100.,relative_mass_tolerance=0.,absolute_mass_tolerance=0.):
    """Arbitrary oracle redistribution within each region; never a model score.

    If region mass is M and there are K true threshold events, no more than
    min(K,floor(M/threshold)) can be positive while keeping that mass. This
    ignores all model restrictions and amplitude fidelity, so it is optimistic.
    Tolerances optionally loosen the bound to allow floating-point mass drift.
    """
    if prediction.shape!=target.shape or prediction.shape!=mask.shape or mask.dtype!=torch.bool:
        raise ValueError('Expected matching quantity/target and boolean mask')
    if not isinstance(region_width,int) or region_width<1 or prediction.shape[-1]%region_width:
        raise ValueError('Invalid regional grid')
    if not math.isfinite(threshold) or threshold<=0 or any(not math.isfinite(v) or v<0 for v in [relative_mass_tolerance,absolute_mass_tolerance]):
        raise ValueError('Invalid threshold or mass tolerance')
    for value in [prediction,target]:
        valid=value[mask]
        if not bool(torch.isfinite(valid).all() and (valid>=0).all()):raise ValueError('Finite nonnegative valid quantities required')
    q=prediction.double().masked_fill(~mask,0)
    mass=q.reshape(*q.shape[:-1],-1,region_width).sum(-1)
    counts=((target>=threshold)&mask).reshape(*q.shape[:-1],-1,region_width).sum(-1)
    capacity=((mass*(1+relative_mass_tolerance)+absolute_mass_tolerance)/threshold).floor().long()
    feasible=torch.minimum(counts,capacity)
    total=int(counts.sum());maximum=int(feasible.sum())
    return dict(true_events=total,max_feasible_events=maximum,recall_upper_bound=maximum/total if total else None,
                unavoidable_misses=total-maximum,deficit_region_count=int((feasible<counts).sum()),
                region_width=region_width,threshold=threshold,relative_mass_tolerance=relative_mass_tolerance,absolute_mass_tolerance=absolute_mass_tolerance,
                scope='Oracle feasibility upper bound conditional on fixed region masses. Uses true event locations/counts, allows arbitrary redistribution, ignores amplitude fidelity, is not a prediction or relaxed recall and cannot satisfy a reconstruction goal.')
