"""Training-only moving-peak positive control, never mixed into real training."""
import torch
from torch.utils.data import Dataset


def moving_peak_window(raw,offset):
    values={k:v.clone() for k,v in raw.items()}
    data=values['data'];counts=values['level_counts'];T,S,L,_=data.shape
    if T!=256 or S!=2:raise ValueError('Complete256-frame two-sided input required')
    mask=torch.arange(L)[None,None,:]<counts[...,None]
    data[...,1]=torch.where(mask,torch.full_like(data[...,1],.02),torch.zeros_like(data[...,1]))
    t=torch.arange(T)
    for side in range(2):
        room=int(counts[:,side].min())-2
        if room<2:raise ValueError('Too few valid levels for moving-peak control')
        level=(offset*37+side*19+t*(side+1))%room+1
        present=((t+offset*4)//16)%2==0
        amplitude=torch.where((t//64)%2==0,torch.full((T,),200.),torch.full((T,),400.))
        data[t[present],side,level[present],1]+=amplitude[present]
    return values


class MovingPeakWindows(Dataset):
    def __init__(self,path):
        payload=torch.load(path,map_location='cpu',weights_only=False)
        self.windows=payload['windows'];self.indices=payload['source_indices'];self.absolute_times=payload['absolute_times']
    def __len__(self):return len(self.windows)
    def __getitem__(self,index):return dict(self.windows[index],cache_position=torch.tensor(index))
