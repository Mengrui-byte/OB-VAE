"""Resume epoch-boundary sampling without advancing its RNG for worker seeds."""

import torch
from torch.utils.data import DataLoader,RandomSampler


def epoch_resume_loader(dataset,sampler_state,*,batch_size,workers=2,pin_memory=True):
    sampler_generator=torch.Generator();sampler_generator.set_state(sampler_state.cpu())
    worker_generator=torch.Generator().manual_seed(42)
    sampler=RandomSampler(dataset,generator=sampler_generator)
    loader=DataLoader(dataset,batch_size=batch_size,sampler=sampler,num_workers=workers,
        persistent_workers=workers>0,pin_memory=pin_memory,generator=worker_generator)
    return loader,sampler_generator
