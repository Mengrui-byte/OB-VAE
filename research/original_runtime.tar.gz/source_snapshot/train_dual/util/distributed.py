"""torchrun setup and validation sharding without padded duplicates."""

import os

import torch
import torch.distributed as dist
from torch.utils.data import Sampler


def world_size():
    return dist.get_world_size() if dist.is_initialized() else 1


def rank():
    return dist.get_rank() if dist.is_initialized() else 0


def unwrap(model):
    return model.module if isinstance(model, torch.nn.parallel.DistributedDataParallel) else model


def initialize(device_name):
    count = int(os.environ.get("WORLD_SIZE", "1"))
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    if count > 1 and device_name != "cpu":
        device = torch.device("cuda", local_rank)
    else:
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu") if device_name == "auto" else torch.device(device_name)
        if device.type == "cuda" and device.index is None:
            device = torch.device("cuda:0")
    if device.type not in ("cpu", "cuda"):
        raise ValueError("Only CPU and CUDA devices are supported")
    if device.type == "cuda":
        if not torch.cuda.is_available():
            raise ValueError("CUDA was requested but is unavailable")
        torch.cuda.set_device(device)
    if count > 1:
        dist.init_process_group(backend="nccl" if device.type == "cuda" else "gloo")
    return device


class ValidationShard(Sampler):
    def __init__(self, dataset, *, rank_id=None, replicas=None):
        self.size = len(dataset)
        self.rank = rank() if rank_id is None else rank_id
        self.replicas = world_size() if replicas is None else replicas

    def __iter__(self):
        return iter(range(self.rank, self.size, self.replicas))

    def __len__(self):
        return max(0, (self.size - self.rank + self.replicas - 1) // self.replicas)
