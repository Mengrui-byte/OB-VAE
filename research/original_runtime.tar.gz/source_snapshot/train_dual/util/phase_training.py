"""Verified optimizer migration and frozen-module checks for decoder controls."""
import hashlib
import torch


def tensor_digest(module):
    digest = hashlib.sha256()
    for name, value in module.state_dict().items():
        digest.update(name.encode())
        digest.update(value.detach().cpu().contiguous().numpy().tobytes())
    return digest.hexdigest()


def freeze_for_quantity_training(model, *, train_encoder=False):
    model.encoder.requires_grad_(train_encoder)
    if not train_encoder:
        model.encoder.eval()
    model.price_decoder.requires_grad_(False).eval()
    model.volume_decoder.requires_grad_(True)
    if model.volume_decoder.detail_mode == 'off':
        model.volume_decoder.phase_head.requires_grad_(False)


def restore_original_adam(model, saved, original_names, lr, weight_decay,
                          head_prefix='volume_decoder.phase_head.'):
    """Restore the original single-group Adam, then append the two new tensors.

    This source family has exactly one original group in model parameter order.
    Reject other layouts; never reinterpret original indices after insertion.
    """
    names = list(model.named_parameters())
    old = [(name, p) for name, p in names if not name.startswith(head_prefix)]
    new = [(name, p) for name, p in names if name.startswith(head_prefix)]
    if [name for name, _ in old] != list(original_names):
        raise ValueError('Original parameter names/order changed')
    if len(saved['param_groups']) != 1 or len(saved['param_groups'][0]['params']) != len(old):
        raise ValueError('Unsupported original Adam parameter-group layout')
    if [name for name, _ in new] != [head_prefix+'weight',head_prefix+'bias']:
        raise ValueError('Expected exactly the appended detail head')
    for index, (_, p) in zip(saved['param_groups'][0]['params'], old):
        state = saved['state'].get(index, {})
        for key in ['exp_avg', 'exp_avg_sq']:
            if key in state and state[key].shape != p.shape:
                raise ValueError('Original Adam moment shape mismatch')
    opt = torch.optim.AdamW([p for _, p in old], lr=lr, weight_decay=weight_decay)
    opt.load_state_dict(saved)
    for group in opt.param_groups:
        group.update(lr=lr, weight_decay=weight_decay)
    settings = {k: v for k, v in opt.param_groups[0].items() if k != 'params'}
    opt.add_param_group(dict(settings, params=[p for _, p in new]))
    return opt, [[name for name, _ in old], [name for name, _ in new]]
