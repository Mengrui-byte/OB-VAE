"""Accumulate sufficient statistics; never average per-batch RMSE values."""

import math

import torch
import torch.distributed as dist


class DualMetrics:
    def __init__(self):
        self.sums = {}
        self.samples = 0

    def add(self, key, value):
        value = value.detach().double()
        self.sums[key] = self.sums.get(key, 0) + value

    @torch.no_grad()
    def update(self, output, batch, losses):
        size = len(batch["price"])
        self.samples += size
        for name, value in losses.items():
            self.add("objective/" + name, value * size)
        mask = batch["mask"]
        error = (output["price_norm"].double() - batch["price"].double()).masked_fill(~mask, 0)
        raw_error = error * batch["price_factor"][:, None, None, None]
        volume_error = (output["volume"].double() - batch["volume"].double()).masked_fill(~mask, 0)
        self.add("levels", mask.sum())
        self.add("price_sq", raw_error.square().sum())
        self.add("price_abs", raw_error.abs().sum())
        self.add("price_bps_sq", (error * batch["price_factor"][:, None, None, None]
                                 / batch["anchor"][:, None, None, None] * 10000).square().sum())
        self.add("volume_sq", volume_error.square().sum())
        self.add("volume_abs", volume_error.abs().sum())
        near = mask[..., :10]
        self.add("near_levels", near.sum())
        self.add("near_price_sq", raw_error[..., :10].square().sum())
        spread_error = raw_error[:, :, 1, 0] - raw_error[:, :, 0, 0]
        self.add("frames", spread_error.numel() * torch.ones((), device=error.device))
        self.add("spread_sq", spread_error.square().sum())
        adjacent = mask[..., 1:] & mask[..., :-1]
        gap_error = (raw_error[..., 1:] - raw_error[..., :-1]).masked_fill(~adjacent, 0)
        self.add("gaps", adjacent.sum())
        self.add("gap_sq", gap_error.square().sum())

    def compute(self, device="cpu"):
        samples = self.samples
        if dist.is_initialized():
            # Some validation ranks may have no windows. Agree on statistic keys
            # before reducing so empty ranks still participate exactly once.
            key_sets = [None] * dist.get_world_size()
            dist.all_gather_object(key_sets, list(self.sums))
            keys = sorted({key for group in key_sets for key in group})
            totals = torch.zeros(1 + len(keys), device=device, dtype=torch.float64)
            totals[0] = samples
            for index, key in enumerate(keys, 1):
                if key in self.sums:
                    totals[index] = self.sums[key]
            dist.all_reduce(totals)
            values = totals.tolist()
            samples = int(values[0])
            sums = dict(zip(keys, values[1:]))
        else:
            sums = {key: value.item() for key, value in self.sums.items()}
        if samples == 0:
            raise ValueError("DataLoaders yielded no windows")
        result = {key.removeprefix("objective/"): value / samples
                  for key, value in sums.items() if key.startswith("objective/")}
        for name, numerator, denominator in (
            ("price_rmse", "price_sq", "levels"),
            ("price_rmse_bps", "price_bps_sq", "levels"),
            ("volume_rmse", "volume_sq", "levels"),
            ("near10_price_rmse", "near_price_sq", "near_levels"),
            ("spread_rmse", "spread_sq", "frames"),
            ("gap_rmse", "gap_sq", "gaps"),
        ):
            result[name] = math.sqrt(sums[numerator] / sums[denominator]) if sums[denominator] else None
        result.update(price_mae=sums["price_abs"] / sums["levels"],
                      volume_mae=sums["volume_abs"] / sums["levels"],
                      samples=samples, valid_levels=int(sums["levels"]))
        return result
