"""Read-only event localization diagnostics; exact-rank goal metrics stay fixed."""
import numpy as np


def ordered_match_count(truth, prediction, radius):
    """Maximum one-to-one cardinality on sorted1D coordinates, not minimum cost."""
    if isinstance(radius, bool) or not isinstance(radius, int) or radius < 0:
        raise ValueError('Nonnegative integer radius required')
    truth, prediction = np.asarray(truth), np.asarray(prediction)
    for values in [truth, prediction]:
        if values.ndim != 1 or (values.size and (values.dtype.kind not in 'iu' or (values < 0).any() or (values[1:] <= values[:-1]).any())):
            raise ValueError('Sorted unique nonnegative integer positions required')
    i = j = matches = 0
    while i < len(truth) and j < len(prediction):
        t, p = int(truth[i]), int(prediction[j])
        if p < t - radius:
            j += 1
        elif t < p - radius:
            i += 1
        else:
            matches += 1; i += 1; j += 1
    return matches


def nearest_distance(query, positions):
    if not len(positions): return np.full(len(query), np.inf)
    insertion = np.searchsorted(positions, query)
    left = positions[np.maximum(insertion - 1, 0)]
    right = positions[np.minimum(insertion, len(positions) - 1)]
    return np.minimum(abs(query - left), abs(query - right))


def peak_localization(target, prediction, mask, *, threshold=100., radii=(0, 1, 2, 4, 8, 16)):
    target, prediction, mask = np.asarray(target), np.asarray(prediction), np.asarray(mask)
    if target.ndim < 2 or target.shape != prediction.shape or target.shape != mask.shape or mask.dtype != bool:
        raise ValueError('Matching profile arrays and boolean masks required')
    if not np.isfinite(threshold) or threshold <= 0:
        raise ValueError('Positive finite threshold required')
    if not np.isfinite(target[mask]).all() or not np.isfinite(prediction[mask]).all() or (target[mask] < 0).any() or (prediction[mask] < 0).any():
        raise ValueError('Valid quantities must be finite and nonnegative')
    if not radii or any(isinstance(r, bool) or not isinstance(r, int) or r < 0 for r in radii) or tuple(sorted(set(radii))) != tuple(radii):
        raise ValueError('Increasing unique integer radii required')
    totals = dict(truth_events=0, predicted_events=0, exact_TP=0, exact_FP=0, exact_FN=0)
    rows = {r: dict(radius_levels=r, one_to_one_TP=0, FP_near_exact_recalled_truth=0,
                    FP_near_only_missed_truth=0, FP_far_from_any_truth=0) for r in radii}
    length = target.shape[-1]
    for t, p, valid in zip(target.reshape(-1, length), prediction.reshape(-1, length), mask.reshape(-1, length)):
        true = np.flatnonzero((t >= threshold) & valid)
        pred = np.flatnonzero((p >= threshold) & valid)
        exact = np.intersect1d(true, pred)
        false = np.setdiff1d(pred, true)
        distance_truth, distance_exact = nearest_distance(false, true), nearest_distance(false, exact)
        totals['truth_events'] += len(true); totals['predicted_events'] += len(pred)
        totals['exact_TP'] += len(exact); totals['exact_FP'] += len(false); totals['exact_FN'] += len(true) - len(exact)
        for radius, row in rows.items():
            row['one_to_one_TP'] += ordered_match_count(true, pred, radius)
            near_exact = distance_exact <= radius
            near_truth = distance_truth <= radius
            row['FP_near_exact_recalled_truth'] += int(near_exact.sum())
            row['FP_near_only_missed_truth'] += int((near_truth & ~near_exact).sum())
            row['FP_far_from_any_truth'] += int((~near_truth).sum())
    for row in rows.values():
        matches = row['one_to_one_TP']
        row.update(one_to_one_recall=matches / totals['truth_events'] if totals['truth_events'] else None,
                   one_to_one_precision=matches / totals['predicted_events'] if totals['predicted_events'] else None,
                   additional_TP_over_exact=matches - totals['exact_TP'])
        assert sum(row[k] for k in ['FP_near_exact_recalled_truth', 'FP_near_only_missed_truth', 'FP_far_from_any_truth']) == totals['exact_FP']
    assert all(a['one_to_one_TP'] <= b['one_to_one_TP'] for a, b in zip(list(rows.values()), list(rows.values())[1:]))
    return dict(**totals, radii=list(rows.values()), scope='Same-frame/side profiles only. Tolerant matching is diagnostic, not goal evaluation. '
                'An FP near recalled truth is not automatically removable: nearby missed events may permit reassignment.')
