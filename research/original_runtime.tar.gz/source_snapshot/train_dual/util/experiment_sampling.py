"""Nested month-stratified training subsets, independent of model metrics."""
import numpy as np


def nested_month_subsets(months, base_indices, sizes, seed=42):
    months = np.asarray(months)
    base = np.asarray(base_indices, dtype=np.int64)
    sizes = list(sizes)
    if months.ndim != 1 or len(months) == 0:
        raise ValueError('Expected a nonempty month label for each training window')
    if (base.ndim != 1 or len(np.unique(base)) != len(base)
            or np.any(base < 0) or np.any(base >= len(months))):
        raise ValueError('Invalid initial training indices')
    if sizes != sorted(set(sizes)) or any(n < len(base) or n > len(months) for n in sizes):
        raise ValueError('Sizes must increase uniquely from the base size to at most the training pool')
    rng = np.random.default_rng(seed)
    groups = [np.flatnonzero(months == month) for month in np.unique(months)]
    selected = np.zeros(len(months), dtype=bool)
    selected[base] = True
    counts = np.array([selected[group].sum() for group in groups])
    capacities = np.array([len(group) for group in groups])
    remaining = [rng.permutation(group[~selected[group]]).tolist() for group in groups]
    result = {}
    for n in sizes:
        for _ in range(n - int(selected.sum())):
            # Balance the selected fraction of each month. Existing base indices
            # are always kept; quantities and development errors are never read.
            fractions = np.where(counts < capacities, counts / capacities, np.inf)
            k = int(np.argmin(fractions))
            index = remaining[k].pop()
            selected[index] = True
            counts[k] += 1
        result[n] = np.flatnonzero(selected)
    return result
