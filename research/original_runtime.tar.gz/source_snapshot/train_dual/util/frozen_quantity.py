"""Training-only cached-Z paths and exact frozen-state checks for native VAE."""
from copy import deepcopy

import torch

from train_dual.util.hint_training import restore_hint_adam


def configure_quantity_training(model,*,temporal=False,spatial=False):
    if type(temporal) is not bool or type(spatial) is not bool:raise ValueError('Explicit Boolean training flags required')
    model.eval().requires_grad_(False);model.zero_grad(set_to_none=True)
    for name,param in model.named_parameters():
        if name.startswith('volume_decoder.'):
            param.requires_grad_(temporal if name.startswith('volume_decoder.temporal.') else spatial)
    # No BatchNorm/dropout in this decoder; activation checkpointing is training-only.
    model.volume_decoder.train()
    return [name for name,p in model.named_parameters() if p.requires_grad]


def decode_cached_quantity(model,row):
    b=row['batch'];posterior=row['posterior'];price=row['price_output']
    quantity=model.volume_decoder(posterior['z'],price,b['mask'],b['tick_norm'],b['times'])
    return dict(**price,**quantity,**posterior)


def restore_original_optimizer(model,saved,original_names):
    groups=saved['param_groups']
    if len(groups)!=2:raise ValueError('Expected original body/hint Adam groups')
    ordered=[[p for n,p in model.named_parameters() if not n.startswith('hint_adapter.')],list(model.hint_adapter.parameters())]
    for group,params in zip(groups,ordered):
        if len(group['params'])!=len(params):raise ValueError('Original optimizer order changed')
        for index,p in zip(group['params'],params):
            for key in ['exp_avg','exp_avg_sq','max_exp_avg_sq']:
                if key in saved['state'].get(index,{}) and saved['state'][index][key].shape!=p.shape:raise ValueError('Adam moment shape changed')
    return restore_hint_adam(model,deepcopy(saved),original_names)


def audit_frozen_state(model,optimizer,source_model,source_optimizer):
    state=model.state_dict();trainable={n for n,p in model.named_parameters() if p.requires_grad}
    if state.keys()!=source_model.keys():raise ValueError('Native model state layout changed')
    frozen=[]
    for name,value in state.items():
        if name not in trainable:
            if not torch.equal(value.detach().cpu(),source_model[name].cpu()):raise AssertionError('Frozen model value changed: '+name)
            frozen.append(name)
    current=optimizer.state_dict();names=[[n for n,p in model.named_parameters() if not n.startswith('hint_adapter.')],[n for n,p in model.named_parameters() if n.startswith('hint_adapter.')]]
    if len(current['param_groups'])!=2:raise ValueError('Unexpected optimizer group added')
    frozen_moments=0
    for group,source_group,group_names in zip(current['param_groups'],source_optimizer['param_groups'],names):
        if group['params']!=source_group['params']:raise ValueError('Adam state indices changed')
        for name,index in zip(group_names,group['params']):
            if name in trainable:continue
            a=current['state'].get(index,{});b=source_optimizer['state'].get(index,{})
            if a.keys()!=b.keys():raise AssertionError('Frozen Adam state created/removed: '+name)
            for key,value in b.items():
                other=a[key]
                same=torch.equal(value.cpu(),other.cpu()) if torch.is_tensor(value) else value==other
                if not same:raise AssertionError('Frozen Adam moment changed: '+name+'/'+key)
                frozen_moments+=1
    for n,p in model.named_parameters():
        if n not in trainable and p.grad is not None:raise AssertionError('Frozen parameter received a gradient: '+n)
    return dict(passed=True,frozen_model_values=len(frozen),frozen_Adam_values=frozen_moments,trainable_parameters=sorted(trainable),encoder_price_and_hint_unchanged=True)


def decoder_gradient_norms(model):
    sums=dict(temporal=0.,spatial=0.,frozen=0.)
    for name,p in model.named_parameters():
        if p.grad is None:continue
        key='temporal' if name.startswith('volume_decoder.temporal.') else 'spatial' if name.startswith('volume_decoder.') else 'frozen'
        sums[key]+=float(p.grad.detach().float().square().sum())
    return {k:v**.5 for k,v in sums.items()}
