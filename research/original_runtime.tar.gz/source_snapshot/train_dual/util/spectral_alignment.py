"""Separate spatial-detail amplitude from alignment using orthonormal DCT-II.

The best-scalar values use truth and are diagnostics, never deployable corrections.
"""
import numpy as np
from scipy.fft import dct


def spatial_band_alignment(target, prediction, bands):
    target = np.asarray(target, dtype=np.float64)
    prediction = np.asarray(prediction, dtype=np.float64)
    if target.ndim != 2 or target.shape != prediction.shape or not target.size:
        raise ValueError('Matching nonempty profile-by-level matrices required')
    if not np.isfinite(target).all() or not np.isfinite(prediction).all():
        raise ValueError('Finite profiles required')
    length = target.shape[-1]
    ranges = []
    previous = 1
    for lower, upper in bands:
        if not isinstance(lower, int) or not isinstance(upper, int) or not previous <= lower < upper <= length:
            raise ValueError('Ordered nonoverlapping non-DC coefficient ranges required')
        ranges.append((lower, upper))
        previous = upper
    if not ranges:
        raise ValueError('At least one frequency band required')
    tc = dct(target, type=2, norm='ortho', axis=-1)
    pc = dct(prediction, type=2, norm='ortho', axis=-1)
    assert np.isclose(np.square(tc).sum(), np.square(target).sum(), rtol=1e-10, atol=1e-10)
    assert np.isclose(np.square(pc).sum(), np.square(prediction).sum(), rtol=1e-10, atol=1e-10)
    rows = []
    for lower, upper in ranges:
        t = tc[:, lower:upper]
        p = pc[:, lower:upper]
        et = float(np.square(t).sum())
        ep = float(np.square(p).sum())
        cross = float((t * p).sum())
        cosine = float(np.clip(cross / np.sqrt(et * ep), -1, 1)) if et and ep else None
        rows.append(dict(coefficient_start=lower, coefficient_stop_exclusive=upper,
            target_energy=et, prediction_energy=ep,
            target_fraction_of_nonDC_energy=et / float(np.square(tc[:, 1:]).sum()) if et else None,
            prediction_to_target_energy_ratio=ep / et if et else None,
            coefficient_alignment_cosine=cosine,
            best_scalar_gain=cross / ep if ep else 0.,
            best_scalar_residual_fraction=max(0., 1 - cosine ** 2) if cosine is not None else (1. if et else None),
            energy_matched_residual_fraction=2 - 2 * cosine if cosine is not None else None))
    return dict(profiles=target.shape[0], levels=length, bands=rows,
                definition='Pooled real DCT coefficient cosine, not Pearson correlation or Fourier coherence.',
                scalar_scope='Truth-fitted single signed gain per band. Diagnostic only; not learned reconstruction or a deployable method.')
