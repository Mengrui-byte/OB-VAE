"""Append an auxiliary Adam group without reinterpreting old state indices."""
import torch
from copy import deepcopy


def restore_hint_adam(model,saved,original_names,*,ignored_prefixes=()):
    original=[(n,p) for n,p in model.named_parameters() if not n.startswith(('hint_adapter.',)+tuple(ignored_prefixes))]
    auxiliary=[(n,p) for n,p in model.named_parameters() if n.startswith('hint_adapter.')]
    if [n for n,p in original]!=list(original_names):raise ValueError('Original parameter names/order changed')
    if len(saved['param_groups']) not in [1,2] or len(saved['param_groups'][0]['params'])!=len(original):raise ValueError('Unexpected original optimizer layout')
    if len(saved['param_groups'])==2:
        if len(saved['param_groups'][1]['params'])!=len(auxiliary):raise ValueError('Auxiliary optimizer layout changed')
        for index,(_,p) in zip(saved['param_groups'][1]['params'],auxiliary):
            for key in ['exp_avg','exp_avg_sq']:
                if key in saved['state'].get(index,{}) and saved['state'][index][key].shape!=p.shape:raise ValueError('Auxiliary Adam shape mismatch')
        optimizer=torch.optim.AdamW([dict(params=[p for n,p in original]),dict(params=[p for n,p in auxiliary])])
        optimizer.load_state_dict(saved)
        return optimizer
    for index,(_,p) in zip(saved['param_groups'][0]['params'],original):
        for key in ['exp_avg','exp_avg_sq']:
            if key in saved['state'].get(index,{}) and saved['state'][index][key].shape!=p.shape:raise ValueError('Adam moment shape mismatch')
    optimizer=torch.optim.AdamW([p for n,p in original])
    optimizer.load_state_dict(saved)
    settings={k:v for k,v in optimizer.param_groups[0].items() if k!='params'}
    optimizer.add_param_group(dict(settings,params=[p for n,p in auxiliary]))
    return optimizer


def restore_shape_mass_adam(model,saved,original_names):
    """Keep both source Adam groups intact; append only the new zero heads."""
    prefixes=('shape_head.','mass_head.')
    new=[(n,p) for n,p in model.named_parameters() if n.startswith(prefixes)]
    if [n for n,p in new]!=['shape_head.weight','mass_head.weight','mass_head.bias']:
        raise ValueError('Unexpected shape/mass parameters')
    optimizer=restore_hint_adam(model,saved,original_names,ignored_prefixes=prefixes)
    settings={k:v for k,v in optimizer.param_groups[0].items() if k!='params'}
    optimizer.add_param_group(dict(settings,params=[p for n,p in new]))
    return optimizer


def restore_local_phase_adam(model,saved,original_names):
    """Append four zero-head tensors, or resume their saved third Adam group."""
    return _restore_readout_adam(model,saved,original_names,
        ['local_readout.shape.weight','local_readout.shape.bias','local_readout.mass.weight','local_readout.mass.bias'])


def restore_regional_phase_adam(model,saved,original_names):
    """Same original two Adam groups, with four regional tensors appended."""
    return _restore_readout_adam(model,saved,original_names,
        ['local_readout.shape_weight','local_readout.shape_bias','local_readout.mass_weight','local_readout.mass_bias'])


def restore_logit_readout_adam(model,saved,original_names):
    return _restore_readout_adam(model,saved,original_names,['local_readout.weight','local_readout.bias'])


def restore_fine_phase_adam(model,saved,original_names):
    """Preserve original source/hint state indices; append six Encoder tensors.

    The new Encoder parameters occur before the Decoders in named_parameters.
    Explicitly filter them out when restoring source groups; positional loading
    of the unfiltered model would incorrectly remap original Adam moments.
    """
    named=list(model.named_parameters());prefix='encoder.fine_phase.'
    original=[(n,p) for n,p in named if not n.startswith(('hint_adapter.',prefix))]
    hint=[(n,p) for n,p in named if n.startswith('hint_adapter.')]
    added=[(n,p) for n,p in named if n.startswith(prefix)]
    expected=[prefix+n for n in ['norm.weight','norm.bias','input.weight','input.bias','output.weight','output.bias']]
    if [n for n,p in original]!=list(original_names) or [n for n,p in added]!=expected:
        raise ValueError('Unexpected fine Encoder parameter mapping')
    groups=saved['param_groups'];parameters=[[p for n,p in original],[p for n,p in hint],[p for n,p in added]]
    if len(groups) not in [2,3]:raise ValueError('Need source two groups or resumed three groups')
    for group,params in zip(groups,parameters):
        if len(group['params'])!=len(params):raise ValueError('Fine Encoder Adam group size changed')
        for index,p in zip(group['params'],params):
            for key in ['exp_avg','exp_avg_sq','max_exp_avg_sq']:
                value=saved['state'].get(index,{}).get(key)
                if value is not None and value.shape!=p.shape:raise ValueError('Fine Encoder Adam shape mismatch')
    optimizer=torch.optim.AdamW([dict(params=params) for params in parameters[:len(groups)]])
    optimizer.load_state_dict(deepcopy(saved))
    if len(groups)==2:
        settings={k:v for k,v in optimizer.param_groups[0].items() if k!='params'}
        optimizer.add_param_group(dict(settings,params=parameters[2]))
    return optimizer


def restore_quantity_context_adam(model,saved,original_names):
    """Preserve source/hint moments despite six tensors inserted in a Decoder."""
    prefix='volume_decoder.temporal.context_attention.'
    named=list(model.named_parameters())
    original=[(n,p) for n,p in named if not n.startswith(('hint_adapter.',prefix))]
    hint=[(n,p) for n,p in named if n.startswith('hint_adapter.')]
    added=[(n,p) for n,p in named if n.startswith(prefix)]
    expected=[prefix+n for n in ['q_proj_weight','k_proj_weight','v_proj_weight','in_proj_bias','out_proj.weight','out_proj.bias']]
    if [n for n,p in original]!=list(original_names) or [n for n,p in added]!=expected:
        raise ValueError('Unexpected quantity context parameter mapping')
    groups=saved['param_groups'];parameters=[[p for n,p in original],[p for n,p in hint],[p for n,p in added]]
    if len(groups) not in [2,3]:raise ValueError('Need source two groups or resumed three groups')
    for group,params in zip(groups,parameters):
        if len(group['params'])!=len(params):raise ValueError('Context Adam group size changed')
        for index,p in zip(group['params'],params):
            for key in ['exp_avg','exp_avg_sq','max_exp_avg_sq']:
                value=saved['state'].get(index,{}).get(key)
                if value is not None and value.shape!=p.shape:raise ValueError('Context Adam shape mismatch')
    optimizer=torch.optim.AdamW([dict(params=params) for params in parameters[:len(groups)]])
    optimizer.load_state_dict(deepcopy(saved))
    if len(groups)==2:
        settings={k:v for k,v in optimizer.param_groups[0].items() if k!='params'}
        optimizer.add_param_group(dict(settings,params=parameters[2]))
    return optimizer


def _restore_readout_adam(model,saved,original_names,expected_extra):
    named=list(model.named_parameters())
    original=[(n,p) for n,p in named if not n.startswith(('hint_adapter.','local_readout.'))]
    hint=[(n,p) for n,p in named if n.startswith('hint_adapter.')]
    extra=[(n,p) for n,p in named if n.startswith('local_readout.')]
    if [n for n,p in original]!=list(original_names):raise ValueError('Original parameter names/order changed')
    if [n for n,p in extra]!=expected_extra:raise ValueError('Unexpected local phase parameters')
    groups=saved['param_groups']
    if len(groups) not in [2,3]:raise ValueError('Expected source hint groups or resumed local readout groups')
    parameters=[[p for n,p in original],[p for n,p in hint],[p for n,p in extra]]
    for group,params in zip(groups,parameters):
        if len(group['params'])!=len(params):raise ValueError('Adam parameter group size changed')
        for index,p in zip(group['params'],params):
            for key in ['exp_avg','exp_avg_sq','max_exp_avg_sq']:
                value=saved['state'].get(index,{}).get(key)
                if value is not None and value.shape!=p.shape:raise ValueError('Adam moment shape mismatch')
    optimizer=torch.optim.AdamW([dict(params=p) for p in parameters[:len(groups)]])
    optimizer.load_state_dict(deepcopy(saved))
    if len(groups)==2:
        settings={k:v for k,v in optimizer.param_groups[0].items() if k!='params'}
        optimizer.add_param_group(dict(settings,params=parameters[2]))
    return optimizer
