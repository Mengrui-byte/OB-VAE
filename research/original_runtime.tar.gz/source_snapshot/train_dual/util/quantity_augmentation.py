"""Seeded training-only quantity edits; identical edited inputs and targets."""
import math
import torch


def augment_quantity(raw,generator,*,probability=.5,amplitude_bounds=(100.,400.),events=2):
    if not 0<=probability<=1:raise ValueError('Probability outside[0,1]')
    low,high=amplitude_bounds
    if not (0<low<=high and math.isfinite(high)):raise ValueError('Positive finite amplitude range required')
    result={k:v.clone() for k,v in raw.items()}
    if float(torch.rand((),generator=generator))>=probability:return result,dict(applied=False,events=[])
    data=result['data'];counts=result['level_counts']
    if data.ndim!=4 or data.shape[:2]!=(256,2):raise ValueError('Expected complete256-frame two-sided raw window')
    records=[]
    for _ in range(events):
        side=int(torch.randint(2,(),generator=generator));start=int(torch.randint(256,(),generator=generator))
        duration=[1,4,16,32][int(torch.randint(4,(),generator=generator))];end=min(256,start+duration)
        n=int(counts[start:end,side].min())
        if n<2:continue
        top=data[start,side,:n,1].topk(min(16,n)).indices
        source=int(top[int(torch.randint(len(top),(),generator=generator))])
        destination=int(torch.randint(n-1,(),generator=generator))
        if destination>=source:destination+=1
        mode=int(torch.randint(3,(),generator=generator))
        amplitude=math.exp(math.log(low)+float(torch.rand((),generator=generator))*math.log(high/low))
        if mode==0:
            a=data[start:end,side,source,1].clone()
            data[start:end,side,source,1]=data[start:end,side,destination,1]
            data[start:end,side,destination,1]=a
        elif mode==1:data[start:end,side,destination,1]+=amplitude
        else:data[start:end,side,source,1]=0
        records.append(dict(mode=['swap','insert','erase'][mode],side=side,start=start,end=end,source=source,destination=destination,amplitude=amplitude))
    return result,dict(applied=bool(records),events=records)
