"""Full-shape CPU preflight for a proposed quantity-only context control."""
import argparse
import os
from pathlib import Path
import time

import numpy as np
import torch

from model.autoencoder.quantity_context_vae import QuantityContextOrderBookVAE
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read, STYLE
from train_dual.experiments.price_safe_readout import file_hash
from train_dual.experiments.recall_goal_run import record
from train_dual.experiments.unified_8192_run import call
from train_dual.util.checkpoint import atomic_save, freeze_sources, load_for_inference
from train_dual.util.hint_training import restore_quantity_context_adam
from train_dual.util.phase_training import tensor_digest


CONTEXTS = dict(control=0, local5=5, local17=17, global256=256)
PREFIX = 'volume_decoder.temporal.context_attention.'


def prepare(goal):
    root = goal / 'quantity_context_preflight'
    root.mkdir()
    (root/'logs').mkdir(); (root/'data').mkdir()
    parent = goal/'round_004_local_phase'
    os.link(parent/'source.pt',root/'source.pt')
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    np.save(root/'train_indices.npy',np.load(parent/'train_indices.npy')[:1])
    plan = read(parent/'plan.json')
    plan.update(experiment='Proposed quantity Decoder context: CPU implementation preflight',
        source_sha256=file_hash(root/'source.pt'), contexts=CONTEXTS,
        source_control='Unchanged original round004/source.pt, same as fine Encoder study; not a selected trained endpoint.',
        hypothesis='The existing quantity TemporalExpander directly reads only five serialized Z frames. Whole-window Decoder attention may reuse persistent book information across frames; Encoder already sees all256frames, so locality alone is not proof of an error.',
        architecture='Unchanged unique64x128Gaussian. Quantity-only residual8head attention: queries original256dim frame features, keys frame32Z plus time positions, values same frame32Z. Zero output projection;148480 static parameters. No Encoder skip.',
        intended_control='Disabled/local5/local17/full256 context; same new parameters, source weights/Adam/RNG/data/augmentation/teacher/loss and2048updates. Local5 adds attention capacity without widening original direct Z reach. Control must replay original source training.',
        scope='Implementation preflight only: one existing training window, zero updates, no development or independent data, no claimed quality gain. Training must wait current fine Encoder cohort and prioritize any qualified candidate.')
    atomic_json(root/'plan.json',plan)
    atomic_json(root/'status.json',dict(state='prepared'))
    freeze_sources(root/'source_snapshot')
    print(root.resolve(),flush=True)


def run(root):
    torch.set_num_threads(4); started=time.monotonic(); plan=read(root/'plan.json')
    atomic_json(root/'status.json',dict(state='CPU_preflight',pid=os.getpid()))
    assert file_hash(root/'source.pt')==plan['source_sha256']
    payload=torch.load(root/'source.pt',map_location='cpu',weights_only=False)
    original,norm=load_for_inference(root/'source.pt','cpu'); original.eval()
    data=dataset(root,'train'); index=int(np.load(root/'train_indices.npy')[0])
    raw={k:v.unsqueeze(0) for k,v in data[index].items()}
    start=int(data.base.starts[index]); absolute=data.base.times[start:start+256]
    assert list(raw['data'].shape)==[1,256,2,2048,2] and np.all(np.diff(absolute//60_000_000)==1)
    batch=norm.prepare(raw,'cpu')
    with torch.no_grad(): reference=call(original,batch,False)
    names=[n for n,p in original.named_parameters()]
    z=reference['z']; perturbed=z.clone().reshape(1,256,32); perturbed[:,128,0]+=.2; perturbed=perturbed.reshape(1,64,128)
    with torch.no_grad():
        local_delta=(original.volume_decoder.temporal(z,batch['times'])-original.volume_decoder.temporal(perturbed,batch['times'])).abs().amax(-1)[0]
    baseline_changed=torch.where(local_delta>0)[0].tolist()
    assert baseline_changed and all(abs(i-128)<=2 for i in baseline_changed)
    common=None; audits=[]
    for lane,span in CONTEXTS.items():
        config=dict(payload['local_hint_config'],context_frames=span)
        model=QuantityContextOrderBookVAE(**config,**payload['unified_vae_config']).eval()
        missing,extra=model.load_state_dict(payload['model'],strict=False)
        assert len(missing)==6 and all(n.startswith(PREFIX) for n in missing) and not extra
        assert [n for n,p in model.named_parameters() if not n.startswith(PREFIX)]==names
        for name,value in payload['model'].items():torch.testing.assert_close(model.state_dict()[name],value,rtol=0,atol=0)
        digest=tensor_digest(model); common=digest if common is None else common; assert digest==common
        seen=[]; hooks=[m.register_forward_pre_hook(lambda m,a:seen.append(a[0])) for m in [model.price_decoder,model.volume_decoder]]
        with torch.no_grad(): output=call(model,batch,False)
        for h in hooks:h.remove()
        assert seen[0] is seen[1] is output['z']
        assert list(output['z'].shape)==[1,64,128] and list(output['volume'].shape)==[1,256,2,2048]
        for key in ['mu','logvar','z','price_norm','volume','quantity_seed']:
            torch.testing.assert_close(output[key],reference[key],rtol=0,atol=0)
        if span==256:
            optimizer=restore_quantity_context_adam(model,payload['optimizer'],plan['original_parameter_names'])
            saved=optimizer.state_dict(); assert saved['param_groups'][:2]==payload['optimizer']['param_groups']
            for i,state in payload['optimizer']['state'].items():
                for key,value in state.items():
                    if torch.is_tensor(value):torch.testing.assert_close(saved['state'][i][key],value,rtol=0,atol=0)
                    else:assert saved['state'][i][key]==value
            attention=model.volume_decoder.temporal.context_attention
            assert all(p not in optimizer.state for p in attention.parameters())
            assert sum(p.numel() for p in attention.parameters())==148480
            with torch.random.fork_rng(devices=[]),torch.no_grad():
                torch.manual_seed(42); attention.out_proj.weight.normal_(0,.001)
                changed=call(model,batch,False)
                global_delta=(model.volume_decoder.temporal(z,batch['times'])-model.volume_decoder.temporal(perturbed,batch['times'])).abs().amax(-1)[0]
            assert torch.equal(changed['mu'],reference['mu']) and torch.equal(changed['price_norm'],reference['price_norm'])
            assert not torch.equal(changed['volume'],reference['volume']) and float(global_delta[0])>0
            checkpoint=dict(format_version=1,model=model.state_dict(),quantity_context_config=config,
                local_hint_config=payload['local_hint_config'],unified_vae_config=payload['unified_vae_config'],
                config=payload['config'],diagnostic_only=True)
            atomic_save(checkpoint,root/'nonzero_route_replay.pt')
            fresh,_=load_for_inference(root/'nonzero_route_replay.pt','cpu'); fresh.eval()
            def forbidden(*args):raise AssertionError('Fresh decode accessed Encoder')
            hook=fresh.encoder.register_forward_pre_hook(forbidden)
            with torch.no_grad(): decoded=fresh.decode(changed['z'],batch['mask'],batch['tick_norm'],batch['times'])
            hook.remove()
            for key in ['price_norm','volume']:torch.testing.assert_close(decoded[key],changed[key],rtol=0,atol=0)
            global_changed=torch.where(global_delta>0)[0].tolist()
            del fresh,optimizer,checkpoint,changed,decoded
        audits.append(dict(lane=lane,context_frames=span,source_values_and_relative_parameter_order_exact=True,
            shared_single_Z=True,full_outputs_exact=True))
        atomic_json(root/'progress.json',dict(lanes_completed=len(audits),total=4,elapsed_seconds=time.monotonic()-started))
        del model,output
    assert file_hash(root/'source.pt')==plan['source_sha256']
    audit=dict(passed=True,raw_shape=[1,256,2,2048,2],posterior_shape=[1,64,128],output_shape=[1,256,2,2048],
        source_controls=audits,new_parameters=148480,source_Adam_exact=True,new_Adam_empty=True,
        source_model_sha256=common,fresh_nonzero_Z_only_exact=True,baseline_temporal_changed_frames=baseline_changed,
        global_temporal_changed_frames=global_changed,optimizer_updates=0,independent_data_read=False,
        scope=plan['scope'])
    atomic_json(root/'audit.json',audit)
    atomic_json(root/'status.json',dict(state='complete',pid=os.getpid(),elapsed_seconds=time.monotonic()-started))
    text='<h1>数量Decoder：局部与全窗Z读取预检</h1><p>完整256分钟、唯一64×128Gaussian不变。仅数量时间展开模块增加148480参数的残差注意力，零初始化。控制0、局部5帧、局部17帧、全窗256帧。原Encoder、价格Decoder、空间上采样与损失不变。</p><p>只用一个既有训练窗口、0优化器更新，无开发/独立数据；不宣称重建改善。GPU BF16反向与正式训练审计仍须执行。</p><p><a href="audit.json">实际形状、来源重放与读取范围检查</a> · <a href="plan.json">假设与控制协议</a></p>'
    (root/'index.html').write_text('<!doctype html><meta charset="utf-8"><style>'+STYLE+'</style><main>'+text+'</main>')
    record(root.parent,'quantity_context_CPU_preflight_complete',root=root.name,passed=True,new_parameters=148480,
        optimizer_updates=0,independent_data_read=False,GPU_training_not_run=True)
    print(root.resolve(),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__); parser.add_argument('root',type=Path)
    parser.add_argument('--prepare',action='store_true'); parser.add_argument('--worker',action='store_true')
    args=parser.parse_args(); root=args.root.resolve()
    try:
        if args.prepare:prepare(root)
        elif args.worker:run(root)
    except BaseException as error:
        if not args.prepare:atomic_json(root/'status.json',dict(state='failed',pid=os.getpid(),error=repr(error)))
        raise
