"""Separate decoder-control development scores from target-fitted latent codes."""
import html
from pathlib import Path

from train_dual.experiments.phase_detail_report import render as render_controls,read,fmt


def render(root):
    render_controls(root)
    plan=read(root/'plan.json');folder=root/'latent_fit';spec=plan['latent_diagnostic']
    state=read(folder/'status.json',{});progress=read(folder/'progress.json',{})
    blocks=['<h2>独立诊断：固定Decoder，直接优化每窗Z</h2>',
        '<div class="note">以下仅为4个预先选定训练窗口的拟合诊断。真实目标参与了Z优化；结果不代表Encoder正常推理，更不是开发集或样本外成绩。不能与上面的16窗开发指标横向比较。</div>',
        f'<p>状态：{html.escape(state.get("state","等待启动"))}；更新{progress.get("step",0)}/{spec["steps"]}，耗时{fmt(progress.get("elapsed_seconds",0)/60)}分钟。每窗仍只有64×128=8192个可训练标量，所有模型参数及缓冲区冻结。目标同时保留价格与数量重建项，使用FP32。</p>',
        '<div class="wrap"><table><tr><th>更新</th><th>价格RMSE / USDT</th><th>数量RMSE / BTC</th><th>100BTC召回</th><th>100BTC精确率</th><th>100BTC误报</th><th>Z相对偏移均值</th><th>各窗价格保护</th><th>重建图</th></tr>']
    latest=None
    for step in [0,*spec['checkpoints']]:
        value=read(folder/f'step{step}_fit_evaluation.json')
        if not value:continue
        latest=(step,value);r=value['result'];m=r['metrics'];t=r['thresholds']['100']
        drift=sum(v['delta_over_source_norm'] for v in value['per_window'])/len(value['per_window'])
        guards=sum(v.get('price_guard_passed',True) for v in value['per_window'])
        link=f'<a href="latent_fit/step{step}_preview.html">训练拟合图</a>' if (folder/f'step{step}_preview.html').exists() else '生成中'
        blocks.append(f'<tr><td>{step}</td><td>{fmt(m["price_usdt"]["rmse"])}</td><td>{fmt(m["quantity_btc"]["rmse"])}</td><td>{fmt(t["recall"])}</td><td>{fmt(t["precision"])}</td><td>{t["fp"]}</td><td>{fmt(drift)}</td><td>{guards}/4</td><td>{link}</td></tr>')
    blocks+=['</table></div><p class="small">价格保护：每个窗口价格RMSE不超过该窗口初始误差的1.10倍。这是结果判断条件，不是优化器的硬投影约束。Z相对偏移为||Z−Z₀||₂/||Z₀||₂。大幅离开Encoder原表示或牺牲价格的收益，需要单独解释。</p>']
    if latest:
        step,value=latest;blocks+=[f'<h3>第{step}步：四个训练窗口分别查看</h3><div class="wrap"><table><tr><th>训练窗口</th><th>价格RMSE</th><th>数量RMSE</th><th>初始Z范数</th><th>当前Z范数</th><th>Z偏移范数</th></tr>']
        for v in value['per_window']:
            blocks.append(f'<tr><td>{v["training_index"]}</td><td>{fmt(v["price_rmse_usdt"])}</td><td>{fmt(v["quantity_rmse_btc"])}</td><td>{fmt(v["source_z_norm"])}</td><td>{fmt(v["z_norm"])}</td><td>{fmt(v["delta_z_norm"])}</td></tr>')
        blocks+=['</table></div>']
    blocks+=['<p>如果固定Decoder能够通过优化Z同时恢复价量，说明存在更可解码的表示，但不保证Encoder能从输入稳定获得它。拟合失败仍可能来自优化问题，不能直接证明Decoder结构无表达能力。</p>',
        '<p><a href="startup_control_audit.json">启动对照核验</a> · <a href="design.md">完整结构与实验设计</a></p>']
    index=root/'index.html';page=index.read_text().replace('</main>',''.join(blocks)+'</main>')
    temp=root/'isolation_report.tmp';temp.write_text(page);temp.replace(index)
