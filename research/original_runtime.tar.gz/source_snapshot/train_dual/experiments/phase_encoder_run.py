"""2x2: train/freeze Encoder x original/per-offset quantity Decoder."""
import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path

import numpy as np

from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_run import campaign, read
from train_dual.experiments.phase_detail_report import render
from train_dual.util.checkpoint import freeze_sources


def prepare(parent):
    parent=parent.resolve();project=Path(__file__).resolve().parents[2]
    root=project/'recons'/('phase_encoder_'+datetime.now().strftime('%Y%m%d_%H%M%S'));root.mkdir()
    for name in ['data','logs']:(root/name).mkdir()
    for name in ['initial.pt','initial_expected.json','train_indices.npy','val_indices.npy','seen_indices.npy','plotly.min.js']:
        os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    old=read(parent/'plan.json')
    plan={key:old[key] for key in ['train','development','independent_test_untouched','normalization','model_config','objective','window_size','stride','input_shape','latent_shape','output_shape','fit_windows','seen_windows','evaluation_windows','batch_size','accumulation','steps','checkpoints','max_seconds','lr','weight_decay','clip_grad','beta','sample','loss_mode','add_wasserstein','add_multiscale','precision','primary','selection']}
    labels={'frozen_off':'冻结Encoder·原Decoder','frozen_independent':'冻结Encoder·逐档修正',
            'joint_off':'解冻Encoder·原Decoder','joint_independent':'解冻Encoder·逐档修正'}
    lanes={lane:dict(detail_mode='independent' if lane.endswith('independent') else 'off',
        train_encoder=lane.startswith('joint'),freeze=['price_decoder'] if lane.startswith('joint') else ['encoder','price_decoder']) for lane in labels}
    plan.update(parent=str(parent),experiment='2x2 Encoder training x within-region direct quantity readout',seed=42,
        labels=labels,lanes=lanes,freeze=['price_decoder'],inline_evaluation=True,
        gpu_workers=[[gpu,lane] for gpu,lane in zip([2,3,4,5],labels)],
        source_checkpoint=old['source_checkpoint'],
        initialization='All4 restart the SAME predeclared original checkpoint, identical originalAdam states and sampler seed42. Do not start from the previous2048 endpoints. New detail head zero with freshAdam state. Frozen controls are rerun with this exact source and evaluation pipeline.',
        factors=['Encoder trainable vs frozen','quantity detail_mode off vs independent'],
        control_contract='Within each pair change one factor; all4 share original source weights+Adam, indices/order, seed42,2048updates,batch1accum4,AdamW1e-4,clip1,oldshape_mass objective andnormalization. PriceDecoder weights/buffers fixed, but gradients through it toZ retained. No geometry detach andno true-price condition.',
        price_preservation='Frozen PriceDecoder weights do NOT imply fixed price outputs when Encoder changes Z. Price reconstruction andTop16price remain inobjective; report priceRMSE against BOTH source andmatched off group. Do not label quantity gains as unqualified improvements if price degrades.',
        comparison='Primary: joint_independent vs joint_off. Encoder effect: joint_off vs frozen_off and joint_independent vs frozen_independent. Interaction: detail benefit underjoint minusdetail benefit underfrozen. Fixed2048endpoint, allcheckpoints retained; seed42 only, no cross-seedvariance.',
        next_stage='If no useful improvement, separately investigate synthetic moving peaks andfixedDecoder/per-window latent optimization; do not infer irreversible information loss from a null readout result.',
        authorization='User continued after proposed paired Encoder-unfreeze experiment. Bounded2048updates percase,4hoursmax,GPUs2–5 only.',
        report=dict(title='Encoder冻结/解冻 × 原Decoder/逐档修正',
            scope='四组2×2对照；价格Decoder参数始终冻结。',
            introduction='四组从与上一轮相同的原始起点重新训练。Encoder冻结/解冻，与数量原路径/逐档修正组成2×2。相同1024训练窗、seed42、有效batch4、2048更新和shape_mass损失。没有从上轮各组终点续训。',
            hardware='GPU2–5各训练一组；各卡使用相同FP32评估代码生成指标和逐档挂单图。',
            future='Encoder解冻会改变Z，尽管价格Decoder参数固定，价格输出仍可能变化。保留原价格损失，联合报告价量取舍。合成峰与直接优化窗口latent属于后续独立实验。'))
    ti=np.load(root/'train_indices.npy');si=np.load(root/'seen_indices.npy');vi=np.load(root/'val_indices.npy')
    assert len(ti)==1024 and len(si)==8 and len(vi)==16 and np.isin(si,ti).all()
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'))
    atomic_json(root/'data_contract.json',dict(input_shape=plan['input_shape'],latent_shape=plan['latent_shape'],output_shape=plan['output_shape'],
        train_indices=ti.tolist(),seen_indices=si.tolist(),development_indices=vi.tolist(),
        train_indices_sha256=hashlib.sha256((root/'train_indices.npy').read_bytes()).hexdigest(),
        identical_to_previous_training_indices=True,all_cases_share_source_sha256=hashlib.sha256((root/'initial.pt').read_bytes()).hexdigest()))
    (root/'README.md').write_text('# Encoder冻结/解冻 × 数量细节读出2×2\n\n'
        '四组从上一轮共同的原始起点重新训练，不从各组2048终点续训；复用相同训练/开发索引与原Adam状态。\n'
        'Encoder冻结/解冻 × 数量原路径/逐档修正；每组2048更新、有效batch4、seed42、shape_mass损失。\n'
        '价格Decoder参数冻结但对Z保留梯度，Encoder改变Z会改变价格输出，须报告价量取舍。\n'
        '完整256分钟、每侧2048档、唯一64×128瓶颈，无Encoder特征旁路。GPU2–5各一组，各卡统一FP32评估。\n')
    freeze_sources(root/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'
        f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\n'
        f'cd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.phase_encoder_run "{remote}"\n')
    render(root);Path('/tmp/phase_encoder_path').write_text(str(root));print(root,flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('root',type=Path);parser.add_argument('--prepare',action='store_true');args=parser.parse_args()
    if args.prepare:prepare(args.root)
    else:campaign(args.root.resolve())
