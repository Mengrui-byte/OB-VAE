"""Matched one-factor loss ablations, full256minute input; all results in recons."""
import argparse
from datetime import datetime
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import numpy as np
import torch
from torch.utils.data import DataLoader
from model.losses.controlled_book import ControlledBookLoss
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.local_quant_reconstruction import CacheWindows
from train_dual.experiments.long_worker import atomic_json,evaluate
from train_dual.experiments.unified_8192_run import call,detailed_evaluate,group_gradients,write_profiles
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import atomic_save,freeze_sources,load_for_inference,seed_everything,source_hashes

LABELS={'baseline':'原损失匹配对照','quantity_mse':'仅数量二次损失','spatial_difference':'仅加空间数量差分','temporal_difference':'仅加时间数量差分'}


def prepare(parent):
 parent=parent.resolve();project=Path(__file__).resolve().parents[2];root=project/'recons'/('loss_control_'+datetime.now().strftime('%Y%m%d_%H%M%S'));root.mkdir();(root/'logs').mkdir();(root/'data').mkdir()
 for name in ['train_indices.npy','val_indices.npy','source_profiles.npz']:os.link(parent/name,root/name)
 os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz');os.link(parent/'ae/step512.pt',root/'initial.pt');os.link(parent/'ae/step512_evaluation.json',root/'initial_expected.json')
 plan=json.loads((parent/'plan.json').read_text())
 plan.update(parent=str(parent),wait_for_relative=str(parent.relative_to(project)),experiment='Single-factor loss controls; spatial upsampler fixed',labels=LABELS,lanes={k:dict(mode=k) for k in LABELS},
  steps=1024,checkpoints=[32,128,512,1024],max_seconds=14400,queue_max_seconds=21600,beta=0.,sample=False,
  initialization='Same AE512 model andAdamW moments for all4lanes. Shared512pretraining cost. Restart sampler with seed42 identically in each lane; not an exact continuation of the old sampling trajectory.',
  objective=dict(price_weight=1.,quantity_weight=1.,log_weight=1.,pair_weight=.25,topk=16,spatial_weight=1.,temporal_weight=1.),
  control_contract=dict(fixed=['256frame input','same64training and16development indices','same8192 architecture and nearest-conv upsampler','sameAE512weights andoptimizer moments','seed42','deterministicZ=mu,beta0','AdamW1e-4,clip1,batch1accum4','1024additionalupdates','sameFP32evaluation'],variable='One quantity loss component per candidate; no upsampling or price-loss change',
   quantity_mse='Replace normalized quantity Huber by0.5e^2 both in all-valid andTop16quantity terms; same small-error curvature. Price andlog-quantity terms unchanged.',
   spatial_difference='Base +mean of maskedHuber quantity difference errors across rank lags1,4,16 divided byq0; weight1 fixed a priori.',
   temporal_difference='Base +mean of maskedHuber quantity difference errors across time lags1,4,16minutes divided byq0; weight1 fixed a priori. Same ordinal rank, not order identity tracking.',
   combination='None in this cohort. Any later combined candidate requires its own matched ablations.'),
  metrics='All declared endpoints on16development windows, plus8seen training diagnostics. Compare quantityRMSE, minute log-quantity change correlation andlarge10/100recall, with priceRMSE<=1.10xmatched baseline as price-preservation guard. Report tradeoffs, no posthoc metric switching.',
  hypothesis='Distinguish amplitude-gradient saturation, lack of spatial edge supervision, and lack of temporal-change supervision while architecture is held fixed.',
  reference='The actual matched control is baseline lane, with sameAE512initialization and1024additionalupdates. Old large-latent reference is a disclosed externalqualityruler only.',
  viewer_route='loss_control',viewer_default_model=2,default_variant='baseline',viewer_source_label='旧大latent参考·非匹配对照',
  viewer_description='完整256分钟单因素损失对照，所有组唯一64×128瓶颈、相同最近邻上采样、相同AE512权重与AdamW状态，额外训练1024步。原损失基线是匹配对照，三个候选分别仅替换数量二次项、增加空间差分、增加时间差分。价格损失和结构不变，beta0、Z=μ。2025Q1为反复使用的开发期；2026与独立测试未参与。',
  viewer_step_note='显示额外训练步数；共同AE512起点，8192维、结构与上采样不变。',
  queue='Wait for previous4GPUcampaign to finish and owned workers toexit; preserve current runs. GPU2–5 only, noGPU0/1.')
 for k in ['kl_warmup_steps','loss_delta']:plan.pop(k,None)
 atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='queued',waiting_for=plan['wait_for_relative']));freeze_sources(root/'source_snapshot')
 remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
 (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.loss_control_run "{remote}"\n')
 Path('/tmp/loss_control_path').write_text(str(root));print(root,flush=True)


def worker(root,lane):
 torch.set_num_threads(4);seed_everything(42);strict_precision();plan=json.loads((root/'plan.json').read_text());folder=root/lane;folder.mkdir(exist_ok=True);started=time.monotonic()
 initial=torch.load(root/'initial.pt',map_location='cpu',weights_only=False);model,norm=load_for_inference(root/'initial.pt','cuda:0');train_original=dataset(root,'train');val_original=dataset(root,'val');ti=np.load(root/plan.get('training_indices_files',{}).get(lane,'train_indices.npy'));vi=np.load(root/'val_indices.npy');train=CacheWindows(train_original,ti);val=CacheWindows(val_original,vi)
 seen_train=CacheWindows(train_original,np.load(root/plan['seen_indices_file'])) if plan.get('seen_indices_file') else train
 exposures=np.zeros(len(train),dtype=np.int64) if plan.get('track_data_exposures') else None
 if plan.get('seen_indices_file') and not np.isin(seen_train.indices,ti).all():raise ValueError('Common seen diagnostics must belong to every training subset')
 if 'gradient_routes' in plan:
  from model.experimental.gradient_route import GradientRouteOrderBookVAE
  routed=GradientRouteOrderBookVAE(**plan['gradient_routes'][lane],**plan['model_config']);routed.load_state_dict(initial['model'],strict=True);model=routed.to('cuda:0')
 loss_class=ControlledBookLoss
 if plan.get('loss_family')=='allocation':
  from model.losses.allocation_book import AllocationBookLoss
  loss_class=AllocationBookLoss
 if plan.get('loss_family')=='probability':
  from model.losses.probability_book import ProbabilityBookLoss
  loss_class=ProbabilityBookLoss
 criterion=loss_class(plan['normalization']['quantity_scale'],**plan['lanes'][lane],**plan['objective']);opt=torch.optim.AdamW(model.parameters(),lr=plan['lr'],weight_decay=plan['weight_decay']);opt.load_state_dict(initial['optimizer'])
 for group in opt.param_groups:group['lr']=plan['lr'];group['weight_decay']=plan['weight_decay']
 loader=DataLoader(train,batch_size=1,shuffle=True,num_workers=2,persistent_workers=True,pin_memory=True,generator=torch.Generator().manual_seed(42));iterator=iter(loader);hashes=source_hashes()
 audit_batch=None
 if 'gradient_routes' in plan:
  audit_raw=torch.load(root/'audit_train.pt',map_location='cpu',weights_only=False)
  audit_batch=norm.prepare({k:v[:1] for k,v in audit_raw.items()},'cuda:0');del audit_raw
 def save(path,step):
  config=dict(initial['config']);config['loss']=dict(plan['objective'],**plan['lanes'][lane]);config['loss_family']=plan.get('loss_family','controlled')
  value=dict(format_version=1,model=model.state_dict(),unified_vae_config=plan['model_config'],config=config,step=step,pretraining_steps=plan.get('pretraining_steps',512),lane=lane,beta=0.,optimizer=opt.state_dict(),source_hashes=hashes,torch_rng_state=torch.get_rng_state(),cuda_rng_state=torch.cuda.get_rng_state_all(),sampler_generator_state=loader.generator.get_state(),epoch_boundary=step*plan['accumulation']%len(train)==0)
  if exposures is not None:
   value['training_data']=dict(indices_file=plan['training_indices_files'][lane],windows=len(train),seen_indices_file=plan['seen_indices_file'],exposure_counts=exposures.copy(),epochs_equivalent=step*plan['accumulation']/len(train))
  if hasattr(model,'gradient_route_config'):value['gradient_route_config']=model.gradient_route_config
  atomic_save(value,path)
 try:
  atomic_json(folder/'status.json',dict(state='initial_validation'));initial_result=detailed_evaluate(model,norm,val,len(val),'cuda:0');expected=json.loads((root/'initial_expected.json').read_text())['result'];delta={k:abs(initial_result['metrics'][k]['rmse']-expected['metrics'][k]['rmse']) for k in ['price_usdt','quantity_btc']};atomic_json(folder/'initial_replay.json',delta)
  if max(delta.values())>1e-3:raise RuntimeError(f'Commoninitialcheckpoint replay differs:{delta}')
  atomic_json(folder/'initial_evaluation.json',dict(result=initial_result))
  if plan.get('initial_seen_evaluation'):atomic_json(folder/'initial_seen_evaluation.json',dict(result=evaluate(model,norm,seen_train,plan['seen_windows'],'cuda:0')))
  if plan.get('probability_evaluation'):
   from train_dual.experiments.probability_eval import evaluate_probability
   atomic_json(folder/'initial_probability.json',dict(development=evaluate_probability(model,norm,val,len(val),'cuda:0',criterion),seen=evaluate_probability(model,norm,seen_train,plan['seen_windows'],'cuda:0',criterion)))
  atomic_json(folder/'status.json',dict(state='training'));atomic_json(folder/'trainable_modules.json',{k:sum(p.numel() for p in m.parameters() if p.requires_grad) for k,m in [('encoder',model.encoder),('price_decoder',model.price_decoder),('volume_decoder',model.volume_decoder)]})
  for step in range(1,plan['steps']+1):
   if time.monotonic()-started>plan['max_seconds']:raise TimeoutError('4hour lane ceiling')
   model.train();opt.zero_grad(set_to_none=True);record={}
   for micro in range(plan['accumulation']):
    try:raw=next(iterator)
    except StopIteration:iterator=iter(loader);raw=next(iterator)
    if exposures is not None:exposures[int(raw['cache_position'][0])]+=1
    assert list(raw['data'].shape)==[1,256,2,2048,2];b=norm.prepare(raw,'cuda:0')
    with torch.autocast('cuda',dtype=torch.bfloat16):out=call(model,b,False)
    values=criterion(out,b,beta=0.)
    if not bool(torch.isfinite(values['loss'])):raise FloatingPointError('Nonfinite loss')
    (values['loss']/plan['accumulation']).backward()
    for k,v in values.items():record[k]=record.get(k,0.)+float(v.detach())/plan['accumulation']
    if step==1 and micro==0:atomic_json(folder/'actual_shape_contract.json',dict(raw_input=list(raw['data'].shape),matrix=list(out['z'].shape),price_output=list(out['price_norm'].shape),quantity_output=list(out['volume'].shape),mode=lane,posterior_count=1,training_sample=False,upsampling='unchanged nearest+conv',common_initial_step=plan.get('pretraining_steps',512)))
   if step==1:
    g=group_gradients(model);atomic_json(folder/'first_step_gradient_norms.json',g)
    if any(not np.isfinite(v) or v<=0 for k,v in g.items() if k!='posterior_logvar'):raise RuntimeError(f'Missing module gradients:{g}')
   gradient=torch.nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True);opt.step()
   if step==1 or step%8==0:
    record['objective_loss']=record.pop('loss');record['loss']=record['base_loss']
    row=dict(phase='end_to_end',step=step,total=plan['steps'],elapsed_seconds=time.monotonic()-started,reserved_gib=torch.cuda.memory_reserved()/2**30,gradient_norm=float(gradient),**record);atomic_json(folder/'progress.json',row)
    if exposures is not None:
     exposure_row=dict(step=step,training_windows=len(train),presentations=int(exposures.sum()),unique_windows_seen=int((exposures>0).sum()),epochs_equivalent=float(exposures.mean()),min_presentations=int(exposures.min()),max_presentations=int(exposures.max()))
     atomic_json(folder/'data_exposures.json',exposure_row)
    with (folder/'progress.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
    print(json.dumps(row),flush=True)
   if audit_batch is not None and (step==1 or step in plan['checkpoints']):
    from train_dual.experiments.gradient_route_audit import inspect_routes
    route_audit=inspect_routes(model,audit_batch,criterion);route_audit['after_optimizer_update']=step
    atomic_json(folder/f'step{step}_route_audit.json',route_audit)
   if step in plan['checkpoints']:
    save(folder/f'step{step}.pt',step);save(folder/'latest.pt',step)
    if exposures is not None:np.save(folder/f'step{step}_exposure_counts.npy',exposures)
    dev=detailed_evaluate(model,norm,val,len(val),'cuda:0');atomic_json(folder/f'step{step}_evaluation.json',dict(result=dev));seen=evaluate(model,norm,seen_train,plan['seen_windows'],'cuda:0');atomic_json(folder/f'step{step}_seen_evaluation.json',dict(result=seen));write_profiles(root,folder,step,model,norm,val_original,vi)
    if plan.get('probability_evaluation'):
     atomic_json(folder/f'step{step}_probability.json',dict(development=evaluate_probability(model,norm,val,len(val),'cuda:0',criterion),seen=evaluate_probability(model,norm,seen_train,plan['seen_windows'],'cuda:0',criterion)))
  save(folder/'final.pt',step);atomic_json(folder/'final_evaluation.json',dict(result=dev));atomic_json(folder/'status.json',dict(state='complete',step=step,elapsed_seconds=time.monotonic()-started))
 except BaseException as e:atomic_json(folder/'status.json',dict(state='failed',error=repr(e)));raise


def campaign(root):
 plan=json.loads((root/'plan.json').read_text());children=[];start=time.monotonic();parents=[root.parents[1]/p for p in plan.get('wait_for_relatives',[plan['wait_for_relative']])]
 def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
 signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
 try:
  while True:
   states=[];alive=[]
   for parent in parents:
    old=json.loads((parent/'status.json').read_text());states.append(old['state'])
    for child in old.get('children',[]):
     try:os.kill(child['pid'],0);alive.append(child['pid'])
     except ProcessLookupError:pass
   if all(s in ['complete','partial_failure','failed','stopped_by_user'] for s in states) and not alive:break
   if time.monotonic()-start>plan['queue_max_seconds']:raise TimeoutError('Queue ceiling6hours')
   atomic_json(root/'status.json',dict(state='queued',waiting_for=[str(p) for p in parents],parent_states=states,alive_owned_children=alive));time.sleep(10)
  # Recheck actual free memory after parent workers exit; do not displace other jobs.
  while True:
   rows=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.free','--format=csv,noheader,nounits'],text=True).splitlines();free={int(r.split(',')[0]):int(r.split(',')[1]) for r in rows}
   if all(free.get(g,0)>30000 for g in [2,3,4,5]):break
   if time.monotonic()-start>plan['queue_max_seconds']:raise TimeoutError('Waiting for4free GPUs exceeded ceiling')
   atomic_json(root/'status.json',dict(state='waiting_for_gpus',free_mib=free));time.sleep(10)
  for gpu,lane in zip([2,3,4,5],plan['lanes']):
   env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),CUDA_DEVICE_ORDER='PCI_BUS_ID',PYTHONPATH=str(root/'source_snapshot'))
   with (root/'logs'/f'{lane}.log').open('ab',buffering=0) as log:p=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.loss_control_run',str(root),'--lane',lane],cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   children.append((lane,gpu,p))
  training_start=time.monotonic();atomic_json(root/'status.json',dict(state='running',queued_seconds=training_start-start,children=[dict(lane=l,gpu=g,pid=p.pid) for l,g,p in children]))
  while any(p.poll() is None for _,_,p in children):
   if time.monotonic()-training_start>plan['max_seconds']:raise TimeoutError('4hour cohort ceiling')
   time.sleep(5)
  failures={l:p.returncode for l,_,p in children if p.returncode!=0};atomic_json(root/'status.json',dict(state='partial_failure' if failures else 'complete',failures=failures,elapsed_seconds=time.monotonic()-start))
 except BaseException as e:atomic_json(root/'status.json',dict(state='failed',error=repr(e)));raise
 finally:
  for _,_,p in children:
   if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)


if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--lane');a=p.parse_args()
 if a.prepare:prepare(a.root)
 elif a.lane:worker(a.root,a.lane)
 else:campaign(a.root)
