"""Continue matched8192 students: frozen teacher Local hints x quantity edits."""
import argparse
from datetime import datetime
import json
import math
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

import numpy as np
import torch
from torch.nn import functional as F

from model.autoencoder.local_hint_vae import LocalHintOrderBookVAE
from model.losses.local_hint import LocalHintBookLoss
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.local_quant_reconstruction import CacheWindows
from train_dual.experiments.long_worker import atomic_json,evaluate
from train_dual.experiments.phase_detail_report import read
from train_dual.experiments.probability_eval import evaluate_probability
from train_dual.experiments.region_task_run import safe_preview,gpu_free
from train_dual.experiments.time_logit_run import write_profiles
from train_dual.experiments.unified_8192_run import call,group_gradients
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import atomic_save,freeze_sources,load_for_inference,seed_everything,source_hashes,random_state,restore_random_state
from train_dual.util.hint_training import restore_hint_adam
from train_dual.util.moving_peak import MovingPeakWindows
from train_dual.util.phase_training import tensor_digest
from train_dual.util.quantity_augmentation import augment_quantity
from train_dual.util.resume_data import boundary_loader


LABELS={'control':'原模型长训练','hint':'Local蒸馏','augmentation':'随机挂量增强','both':'蒸馏＋增强'}


def refresh(root):
    try:
        from train_dual.experiments.local_hint_report import render
        render(root);atomic_json(root/'report_status.json',dict(state='complete'));return True
    except Exception as error:
        import traceback
        atomic_json(root/'report_status.json',dict(state='failed_retry_pending',error=repr(error)))
        with (root/'logs/report_errors.log').open('a') as f:f.write(traceback.format_exc()+'\n')
        return False


def prepare(parent):
    torch.set_num_threads(4);parent=parent.resolve();project=Path(__file__).resolve().parents[2]
    root=project/'recons'/('local_hint_'+datetime.now().strftime('%Y%m%d_%H%M%S'));root.mkdir()
    for name in ['data','logs','seen','unseen',*LABELS]:(root/name).mkdir()
    for split in ['seen','unseen']:
        for lane in LABELS:(root/split/lane).mkdir()
    for name in ['train_indices.npy','val_indices.npy','seen_indices.npy','plotly.min.js']:
        os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    os.link(parent/'frame_huber/step4096.pt',root/'source.pt')
    teacher=project/'checkpoints/dual256_20261026_090533/reference/final.pt'
    os.link(teacher,root/'teacher.pt')
    fit=project/'recons/region_task_20261027_145807'
    os.link(fit/'real/frame_joint/step2048.pt',root/'fitted4.pt')
    os.link(fit/'data/real_fit_windows.pt',root/'data/real_fit_windows.pt')
    old=read(parent/'plan.json')
    plan={k:old[k] for k in ['train','development','independent_test_untouched','normalization','model_config','objective','window_size','stride','input_shape','latent_shape','output_shape','batch_size','accumulation','lr','weight_decay','clip_grad']}
    plan.update(experiment='Frozen Local teacher hints x online quantity augmentation2x2',labels=LABELS,
        lanes={lane:dict(hint=lane in ['hint','both'],augmentation=lane in ['augmentation','both']) for lane in LABELS},
        source=str(parent/'frame_huber/step4096.pt'),teacher_source=str(teacher),source_steps=4096,fit_windows=1024,
        steps=8192,checkpoints=[1024,2048,4096,8192],seen_windows=8,unseen_windows=32,evaluation_windows=16,
        max_seconds=43200,setup_max_seconds=3600,gpu_workers=[[g,l] for g,l in zip([2,3,4,5],LABELS)],seed=42,beta=0.,sample=False,
        local_hint_config=dict(layout='frame1',frame_ffn=1536),
        hint_calibration=dict(windows=8,encoder_mu_gradient_ratio=.25,channel_std_floor=.001),
        augmentation=dict(probability=.5,events=2,durations=[1,4,16,32],seed=42,amplitude_quantiles=[.1,.9]),
        controls='Same full256minute raw windows, unique64x128Gaussian/noEncoderbypass, allstudentmodules train, same originalshape_mass loss/coefficients, lr1e-4clip1batch1accum4,beta0Z=mu,BF16neuralFP32loss/evaluationTF32off. New272parameterhinthead inallarms doesnotaffectgeneration. OriginalAdamstates and savedsourceTorch/CUDARandom/sampler states restored; separateaugmentation generator42 persisted. Same rawsample orderwithinallarms andsameaugmentedinputswithinhintaugmentationpair.',
        teacher_rules='Teacherfrozen/no_grad/ownnormalizer. Localtargetshape[B,256,2,128,16], read onlyfortrainingobjective. Teacheronaugmentedinput isrecomputed, neverreuseoriginaltargetcache. Hintheadreadsstudentpost-Zquantityseed, not Encoder pre-Z features. No teacher atstudentinference.',
        budget='Additional8192updates (32epochs on1024windows, cumulative48), eachworker12hourtraining ceiling. If reachedsaveactualstep andevaluate; do notclaim8192endpoint. SameupdatesnotFLOPs; teacherseconds andthroughputseparate. All declaredcheckpoints retained, noseed sweeps/noautomaticexpansion.',
        primary='Same-rank100BTCprecisionANDrecall/FP,quantityRMSE and1minlogquantitydynamics. Jointprice guard<=1.10BOTH sharedinitial andsamebudgetcontrol. Report seen8,student-training-unseen32 anddev16 separately.2025Q2/2026 untouched. Teacherhistoricaltrainmayincludestudent-unseen32; thisisnot anindependenttest.',
        preview_descriptions={lane:'固定16个2025Q1开发窗口，未参与本轮梯度更新但已反复用于研究；不是最终独立测试。完整256分钟，逐档挂量。' for lane in LABELS})
    atomic_json(root/'plan.json',plan)
    original=dataset(root,'train');train_indices=np.load(root/'train_indices.npy')
    remaining=np.setdiff1d(np.arange(len(original)),train_indices)
    unseen=remaining[np.unique(np.linspace(0,len(remaining)-1,32,dtype=int))]
    assert len(unseen)==32 and not np.intersect1d(unseen,train_indices).size
    np.save(root/'unseen_indices.npy',unseen)
    chosen=train_indices[np.unique(np.linspace(0,len(train_indices)-1,8,dtype=int))]
    np.save(root/'calibration_indices.npy',chosen)
    raw=original[int(train_indices[0])];start=int(original.base.starts[int(train_indices[0])]);absolute=original.base.times[start:start+256]
    assert list(raw['data'].shape)==[256,2,2048,2] and (np.diff(absolute//60_000_000)==1).all()
    source=torch.load(root/'source.pt',map_location='cpu',weights_only=False)
    assert source['epoch_boundary'] and source['step']==4096
    base,_=load_for_inference(root/'source.pt','cpu')
    names=[n for n,p in base.named_parameters()]
    seed_everything(42);student=LocalHintOrderBookVAE(**plan['local_hint_config'],**plan['model_config'])
    missing,extra=student.load_state_dict(source['model'],strict=False)
    assert missing==['hint_adapter.weight','hint_adapter.bias'] and not extra
    assert [n for n,p in student.named_parameters() if not n.startswith('hint_adapter.')]==names
    plan['original_parameter_names']=names;plan['initial_model_sha256']=tensor_digest(student)
    plan['student_parameters']=sum(p.numel() for p in student.parameters());plan['auxiliary_parameters']=272
    atomic_json(root/'plan.json',plan)
    atomic_save(dict(format_version=1,model=student.state_dict(),unified_vae_config=plan['model_config'],local_hint_config=plan['local_hint_config'],config=source['config'],step=0),root/'initial.pt')
    for split in ['seen','unseen']:
        desc='8个实际参与学生训练的窗口；不是样本外。' if split=='seen' else '32个2022–2024窗口，已排除当前学生1024训练索引；教师历史训练可能见过，并非独立测试。'
        atomic_json(root/split/'plan.json',dict(plan,preview_descriptions={lane:desc for lane in LABELS}))
        os.link(root/'plotly.min.js',root/split/'plotly.min.js')
    atomic_json(root/'data_contract.json',dict(raw_input=plan['input_shape'],latent=plan['latent_shape'],output=plan['output_shape'],posterior_count=1,encoder_skip=False,teacher_at_student_inference=False,train_indices=train_indices.tolist(),seen_indices=np.load(root/'seen_indices.npy').tolist(),unseen_indices=unseen.tolist(),development_indices=np.load(root/'val_indices.npy').tolist(),calibration_indices=chosen.tolist(),first_window_utc=[str(np.datetime64(int(absolute[0]),'us')),str(np.datetime64(int(absolute[-1]),'us'))]))
    shutil.copy2(project/'docs/models/LOCAL_HINT_TRAINING.md',root/'design.md')
    atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'
        f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\n'
        f'cd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.local_hint_run "{remote}"\n')
    refresh(root);Path('/tmp/local_hint_path').write_text(str(root));print(root,flush=True)


def teacher_local(teacher,normalizer,raw):
    batch=normalizer.prepare(raw,'cuda:0')
    with torch.no_grad():
        _,target=teacher.encode_fused(batch['price'],batch['volume'],batch['mask'],batch['tick_norm'],batch['times'])
    return target


def criterion_for(root,lane):
    plan=read(root/'plan.json');cal=read(root/'calibration.json')
    return LocalHintBookLoss(plan['normalization']['quantity_scale'],mode='shape_mass',use_hint=plan['lanes'][lane]['hint'],hint_weight=cal['hint_weight'],hint_mean=cal['channel_mean'],hint_scale=cal['channel_scale'],add_wasserstein=False,add_multiscale=False,**plan['objective']).to('cuda:0')


def counterfactual(root):
    data=MovingPeakWindows(root/'data/real_fit_windows.pt');records=[]
    for source,label in [('fitted4.pt','4窗已拟合逐帧联合'),('source.pt','1024窗逐帧共同起点')]:
        model,norm=load_for_inference(root/source,'cuda:0')
        for i in range(len(data)):
            item=data[i];raw={k:v.unsqueeze(0) for k,v in item.items()}
            with torch.inference_mode():base=call(model,norm.prepare(raw,'cuda:0'),False)['volume'][0].cpu()
            q=item['data'][...,1];valid=torch.arange(q.shape[-1])<item['level_counts'][...,None]
            index=int(q.masked_fill(~valid,-torch.inf).argmax());t,side,rank=np.unravel_index(index,q.shape)
            n=int(item['level_counts'][t,side]);other=(int(rank)+17)%n
            if other==rank:other=(other+1)%n
            for mode in ['swap','double','erase']:
                changed={k:v.clone() for k,v in item.items()};d=changed['data']
                if mode=='swap':d[t,side,rank,1],d[t,side,other,1]=q[t,side,other].clone(),q[t,side,rank].clone()
                elif mode=='double':d[t,side,rank,1]*=2
                else:d[t,side,rank,1]=0
                batch={k:v.unsqueeze(0) for k,v in changed.items()}
                with torch.inference_mode():prediction=call(model,norm.prepare(batch,'cuda:0'),False)['volume'][0].cpu()
                delta=prediction-base;truth=d[...,1]-q
                points=[]
                for level in [int(rank),int(other)]:
                    target_delta=float(truth[t,side,level]);pred_delta=float(delta[t,side,level])
                    points.append(dict(level=level,target_delta=target_delta,predicted_delta=pred_delta,gain=pred_delta/target_delta if target_delta else None,baseline_prediction=float(base[t,side,level]),changed_prediction=float(prediction[t,side,level])))
                records.append(dict(model=label,training_source_index=int(data.indices[i]),time=int(t),side=int(side),mode=mode,positions=points,output_delta_l1=float(delta.abs().sum()),target_delta_l1=float(truth.abs().sum())))
                atomic_json(root/'counterfactual.json',dict(scope='Read-only known-input intervention ontrainingtemplates; not OOS orfutureprediction.',records=records))
        del model;torch.cuda.empty_cache()


def setup_gpu(root):
    torch.set_num_threads(4);strict_precision();plan=read(root/'plan.json')
    atomic_json(root/'setup_status.json',dict(state='counterfactual_gpu'))
    counterfactual(root)
    atomic_json(root/'setup_status.json',dict(state='teacher_training_statistics_gpu'))
    teacher,tn=load_for_inference(root/'teacher.pt','cuda:0');teacher.eval().requires_grad_(False)
    teacher_hash=tensor_digest(teacher)
    data=dataset(root,'train');indices=np.load(root/'calibration_indices.npy')
    sums=torch.zeros(16,device='cuda:0',dtype=torch.float64);squares=sums.clone();count=0;peaks=[]
    for index in indices:
        item=data[int(index)];raw={k:v.unsqueeze(0) for k,v in item.items()}
        target=teacher_local(teacher,tn,raw).double();b=tn.prepare(raw,'cuda:0');valid=F.max_pool1d(b['mask'].reshape(-1,1,2048).float(),16).reshape(1,256,2,128).bool()
        values=target[valid];sums+=values.sum(0);squares+=values.square().sum(0);count+=len(values)
        q=item['data'][...,1];v=q[q>=100];peaks.append(v)
    mean=sums/count;scale=(squares/count-mean.square()).clamp_min(0).sqrt().clamp_min(plan['hint_calibration']['channel_std_floor'])
    peak=torch.cat(peaks)
    if not len(peak):raise RuntimeError('No training peaks foraugmentation range')
    bounds=torch.quantile(peak.float(),torch.tensor([.1,.9])).tolist()
    atomic_json(root/'calibration.json',dict(state='gradient_calibration',channel_mean=mean.float().cpu().tolist(),channel_scale=scale.float().cpu().tolist(),amplitude_bounds=bounds,hint_weight=1.,teacher_sha256=teacher_hash,training_indices=indices.tolist()))
    student,norm=load_for_inference(root/'initial.pt','cuda:0');student.train()
    objective=criterion_for(root,'hint');parameters=list(student.encoder.mu.parameters());base2=[];hint2=[]
    for index in indices:
        raw={k:v.unsqueeze(0) for k,v in data[int(index)].items()};target=teacher_local(teacher,tn,raw)
        with torch.autocast('cuda',dtype=torch.bfloat16):out=call(student,norm.prepare(raw,'cuda:0'),False)
        values=objective(out,norm.prepare(raw,'cuda:0'),teacher_local=target)
        base_grad=torch.autograd.grad(values['pre_hint_loss'],parameters,retain_graph=True)
        hint_grad=torch.autograd.grad(values['local_hint_mse'],parameters)
        base2.append(sum(float(v.float().square().sum()) for v in base_grad));hint2.append(sum(float(v.float().square().sum()) for v in hint_grad))
    base_rms=math.sqrt(float(np.mean(base2)));hint_rms=math.sqrt(float(np.mean(hint2)))
    if not (base_rms>0 and hint_rms>0 and math.isfinite(base_rms+hint_rms)):raise RuntimeError('Invalid training-only hintgradientcalibration')
    coefficient=plan['hint_calibration']['encoder_mu_gradient_ratio']*base_rms/hint_rms
    assert tensor_digest(teacher)==teacher_hash
    cal=read(root/'calibration.json');cal.update(state='complete',hint_weight=coefficient,base_mu_gradient_rms=base_rms,raw_hint_mu_gradient_rms=hint_rms,ratio=plan['hint_calibration']['encoder_mu_gradient_ratio'],teacher_hash_unchanged=True,scope='8 preselected trainingwindows only, nooptimizerupdates/nodevelopmentcalibration; teacherownnormalizer, FP32teacher/BF16student.')
    atomic_json(root/'calibration.json',cal)
    atomic_json(root/'setup_status.json',dict(state='complete'))


def assess(root,lane,step,model,norm,criterion,sets,originals,teacher_seconds):
    atomic_json(root/lane/'evaluation_status.json',dict(state='evaluating',step=step))
    # Hints do not affect reconstruction; evaluation uses no teacher targets.
    from model.losses.probability_book import ProbabilityBookLoss
    plan=read(root/'plan.json')
    plain=ProbabilityBookLoss(plan['normalization']['quantity_scale'],mode='shape_mass',add_wasserstein=False,add_multiscale=False,**plan['objective'])
    for split,data in sets.items():
        result=evaluate(model,norm,data,len(data),'cuda:0')
        atomic_json(root/lane/f'step{step}_{split}.json',dict(result=result,additional_steps=step,source_steps=plan.get('source_steps',4096)))
    atomic_json(root/lane/f'step{step}_probability.json',dict(development=evaluate_probability(model,norm,sets['development'],len(sets['development']),'cuda:0',plain)))
    write_profiles(root/lane,step,model,norm,sets['development'],originals['development']);safe_preview(root,lane,step)
    if step in [0,plan['steps']]:
        for split in ['seen','unseen']:
            write_profiles(root/split/lane,step,model,norm,sets[split],originals[split]);safe_preview(root/split,lane,step)
    atomic_json(root/lane/'evaluation_status.json',dict(state='complete',step=step,teacher_seconds=teacher_seconds))


def worker(root,lane,objective_factory=None,optimizer_factory=None):
    torch.set_num_threads(4);seed_everything(42);strict_precision();started=time.monotonic()
    plan=read(root/'plan.json');spec=plan['lanes'][lane];cal=read(root/'calibration.json')
    initial=root/lane/'initial.pt'
    if not initial.exists():initial=root/'initial.pt'
    model,norm=load_for_inference(initial,'cuda:0');model.train().requires_grad_(True)
    frozen_modules=spec.get('frozen_modules',plan.get('frozen_modules',[]))
    for name in frozen_modules:model.get_submodule(name).requires_grad_(False).eval()
    frozen_hashes={name:tensor_digest(model.get_submodule(name)) for name in frozen_modules}
    assert tensor_digest(model)==plan['initial_model_sha256']
    source=torch.load(root/'source.pt',map_location='cpu',weights_only=False)
    opt=(optimizer_factory or restore_hint_adam)(model,source['optimizer'],plan['original_parameter_names'])
    objective=(objective_factory or criterion_for)(root,lane)
    teacher=tn=None
    if spec['hint']:
        teacher,tn=load_for_inference(root/'teacher.pt','cuda:0');teacher.eval().requires_grad_(False)
        assert tensor_digest(teacher)==cal['teacher_sha256']
    original=dataset(root,'train');training=CacheWindows(original,np.load(root/'train_indices.npy'))
    dev=dataset(root,'val');sets=dict(development=CacheWindows(dev,np.load(root/'val_indices.npy')),seen=CacheWindows(original,np.load(root/'seen_indices.npy')),unseen=CacheWindows(original,np.load(root/'unseen_indices.npy')))
    originals=dict(development=dev,seen=original,unseen=original)
    loader,sampler_rng=boundary_loader(training,source['sampler_generator_state'],workers=2)
    augmentation_rng=torch.Generator().manual_seed(plan['augmentation']['seed'])
    if 'rng_state' in source:
        restore_random_state(source['rng_state'],sampler_rng)
        augmentation_rng.set_state(source['augmentation_generator_state'].cpu())
    else:
        torch.set_rng_state(source['torch_rng_state'].cpu());torch.cuda.set_rng_state_all([v.cpu() for v in source['cuda_rng_state']])
    iterator=iter(loader);exposures=source['training_data']['exposure_counts'].copy();teacher_seconds=0.;augmentation_count=0;folder=root/lane
    atomic_json(folder/'restore_audit.json',dict(passed=True,initial_model_sha256=tensor_digest(model),original_adam_states=len(source['optimizer']['state']),restored_groups=len(opt.param_groups),auxiliary_state_empty=all(p not in opt.state or not opt.state[p] for p in model.hint_adapter.parameters()),source_epoch_boundary=source['epoch_boundary'],source_torch_cuda_rng_restored=True,sampler_rng_separated_from_worker_rng=True,all_student_parameters_trainable=not frozen_modules,frozen_modules=frozen_hashes))
    raw={k:v.unsqueeze(0) for k,v in training[0].items()};b=norm.prepare(raw,'cuda:0');seen=[]
    hooks=[d.register_forward_pre_hook(lambda m,a:seen.append(a[0])) for d in [model.price_decoder,model.volume_decoder]]
    model.eval()
    with torch.inference_mode():
        out=call(model,b,False);replay=model.decode(out['z'],b['mask'],b['tick_norm'],b['times'])
        for key in ['price_norm','volume','hint_local']:torch.testing.assert_close(out[key],replay[key],rtol=0,atol=0)
    for h in hooks:h.remove()
    assert seen[0] is seen[1] and seen[0] is out['z']
    assert list(raw['data'].shape)==plan['input_shape'] and list(out['z'].shape)==plan['latent_shape'] and list(out['volume'].shape)==plan['output_shape']
    atomic_json(folder/'actual_shape_contract.json',dict(passed=True,input=list(raw['data'].shape),mu=list(out['mu'].shape),logvar=list(out['logvar'].shape),z=list(out['z'].shape),output=list(out['volume'].shape),quantity_seed=list(out['quantity_seed'].shape),shared_z=True,decode_only_exact=True,posterior_count=1,teacher_not_used=True))
    del out,replay,seen,raw,b
    hashes=source_hashes()
    def save(step):
        if teacher is not None and tensor_digest(teacher)!=cal['teacher_sha256']:raise RuntimeError('Teacher changed')
        for name,digest in frozen_hashes.items():
            if tensor_digest(model.get_submodule(name))!=digest:raise RuntimeError(f'Frozen module changed: {name}')
        atomic_save(dict(format_version=1,model=model.state_dict(),unified_vae_config=plan['model_config'],local_hint_config=plan['local_hint_config'],config=source['config'],step=step,source_steps=plan.get('source_steps',4096),lane=lane,optimizer=opt.state_dict(),rng_state=random_state(sampler_rng),sampler_generator_state=sampler_rng.get_state(),augmentation_generator_state=augmentation_rng.get_state(),epoch_boundary=step*plan['accumulation']%len(training)==0,training_data=dict(exposure_counts=exposures.copy(),windows=len(training),epochs_equivalent=float(exposures.mean())),teacher_seconds=teacher_seconds,teacher_sha256=cal['teacher_sha256'],hint_loss_config=cal,loss_variant=plan.get('loss_variant'),source_hashes=hashes,frozen_module_hashes=frozen_hashes,**plan.get('checkpoint_extras',{}).get(lane,{})),folder/f'step{step}.pt')
    atomic_json(folder/'status.json',dict(state='training',step=0))
    save(0);assess(root,lane,0,model,norm,objective,sets,originals,teacher_seconds)
    completed=0
    for step in range(1,plan['steps']+1):
        if time.monotonic()-started>=plan['max_seconds']:break
        model.train();opt.zero_grad(set_to_none=True);record={};order=[];edits=[]
        for name in frozen_modules:model.get_submodule(name).eval()
        for micro in range(plan['accumulation']):
            try:raw=next(iterator)
            except StopIteration:iterator=iter(loader);raw=next(iterator)
            pos=int(raw['cache_position'][0]);exposures[pos]+=1;order.append(int(training.indices[pos]))
            if spec['augmentation']:
                item={k:v[0] for k,v in raw.items()}
                item,edit=augment_quantity(item,augmentation_rng,probability=plan['augmentation']['probability'],amplitude_bounds=cal['amplitude_bounds'],events=plan['augmentation']['events'])
                raw={k:v.unsqueeze(0) for k,v in item.items()};augmentation_count+=int(edit['applied'])
            else:edit=dict(applied=False,events=[])
            edits.append(edit);target=None
            if teacher is not None:
                torch.cuda.synchronize();begin=time.monotonic();target=teacher_local(teacher,tn,raw);torch.cuda.synchronize();teacher_seconds+=time.monotonic()-begin
                assert not target.requires_grad and list(target.shape)==[1,256,2,128,16]
            b=norm.prepare(raw,'cuda:0')
            with torch.autocast('cuda',dtype=torch.bfloat16):out=call(model,b,False)
            values=objective(out,b,teacher_local=target)
            if not bool(torch.isfinite(values['loss'])):raise FloatingPointError('Nonfinite student loss')
            (values['loss']/plan['accumulation']).backward()
            for key,value in values.items():record[key]=record.get(key,0.)+float(value.detach())/plan['accumulation']
        if step in [1,8]:
            gradients=group_gradients(model);gradients['hint_adapter']=sum(float(p.grad.float().square().sum()) for p in model.hint_adapter.parameters() if p.grad is not None)**.5
            assert all(math.isfinite(v) for v in gradients.values())
            frozen_groups=set(frozen_modules)
            if 'encoder' in frozen_groups:frozen_groups.update(['posterior_mu','posterior_logvar'])
            assert all(v>0 for k,v in gradients.items() if k not in {'posterior_logvar','hint_adapter'}|frozen_groups)
            assert all(gradients[k]==0 for k in frozen_groups if k in gradients)
            for name,enabled in [('shape_head',spec.get('use_shape',False)),('mass_head',spec.get('use_mass',False))]:
                if hasattr(model,name):
                    gradients[name]=sum(float(p.grad.float().square().sum()) for p in model.get_submodule(name).parameters() if p.grad is not None)**.5
                    assert (gradients[name]>0)==enabled
            for name,enabled in spec.get('gradient_module_flags',{}).items():
                gradients[name]=sum(float(p.grad.float().square().sum()) for p in model.get_submodule(name).parameters() if p.grad is not None)**.5
                assert math.isfinite(gradients[name]) and (gradients[name]>0)==enabled
            for name,enabled in spec.get('gradient_parameter_flags',{}).items():
                parameter=model.get_parameter(name)
                gradients[name]=float(parameter.grad.float().norm()) if parameter.grad is not None else 0.
                assert math.isfinite(gradients[name]) and (gradients[name]>0)==enabled
            assert (gradients['hint_adapter']>0)==spec['hint']
            if teacher is not None:assert all(p.grad is None for p in teacher.parameters())
            atomic_json(folder/f'step{step}_gradient_audit.json',dict(passed=True,gradients=gradients,teacher_gradients_absent=True,logvar_zero_expected_beta0=True))
        if step in [1,8]:atomic_json(folder/f'step{step}_data_audit.json',dict(training_indices=order,edits=edits,losses=record))
        grad=torch.nn.utils.clip_grad_norm_(model.parameters(),plan['clip_grad'],error_if_nonfinite=True);opt.step();completed=step
        if step==1 or step%8==0:
            row=dict(step=step,total=plan['steps'],source_steps=plan.get('source_steps',4096),epochs_equivalent=float(exposures.mean()),elapsed_seconds=time.monotonic()-started,gradient_norm=float(grad),reserved_gib=torch.cuda.memory_reserved()/2**30,teacher_seconds=teacher_seconds,augmented_windows=augmentation_count,**record)
            atomic_json(folder/'progress.json',row)
            with (folder/'progress.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
            print(json.dumps(row),flush=True)
        if step in plan['checkpoints']:
            save(step);assess(root,lane,step,model,norm,objective,sets,originals,teacher_seconds)
    if completed not in plan['checkpoints']:
        save(completed);assess(root,lane,completed,model,norm,objective,sets,originals,teacher_seconds)
    atomic_json(folder/'status.json',dict(state='complete' if completed==plan['steps'] else 'budget_complete',step=completed,elapsed_seconds=time.monotonic()-started,teacher_seconds=teacher_seconds))


def startup_audit(root):
    rows={}
    for lane in LABELS:
        data=read(root/lane/'step1_data_audit.json');shape=read(root/lane/'actual_shape_contract.json');grad=read(root/lane/'step8_gradient_audit.json')
        if not all([data,shape,grad]):return False
        rows[lane]=dict(data=data,shape=shape,gradient=grad)
    assert len({tuple(r['data']['training_indices']) for r in rows.values()})==1
    assert rows['augmentation']['data']['edits']==rows['both']['data']['edits']
    for a,b in [('control','hint'),('augmentation','both')]:
        assert rows[a]['data']['losses']['pre_hint_loss']==rows[b]['data']['losses']['pre_hint_loss']
    atomic_json(root/'startup_control_audit.json',dict(passed=True,common_first_sample_order=True,same_augmented_inputs_within_pair=True,initial_reconstruction_losses_exact_within_pairs=True,rows=rows))
    return True


def campaign(root):
    plan=read(root/'plan.json');children=[]
    def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        free=gpu_free()
        if any(free.get(g,0)<47000 for g in [2,3,4,5]):raise RuntimeError('Require idle GPUs2–5; no displacement')
        env=dict(os.environ,CUDA_VISIBLE_DEVICES='2',CUDA_DEVICE_ORDER='PCI_BUS_ID',PYTHONPATH=str(root/'source_snapshot'))
        with (root/'logs/setup.log').open('ab',buffering=0) as log:
            child=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.local_hint_run',str(root),'--setup'],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        children=[('setup',2,child)];begin=time.monotonic();atomic_json(root/'status.json',dict(state='gpu_setup',pid=child.pid))
        while child.poll() is None:
            if time.monotonic()-begin>plan['setup_max_seconds']:raise TimeoutError('GPUsetup1hour ceiling')
            refresh(root);time.sleep(10)
        if child.returncode:raise RuntimeError('GPUsetupfailed; see logs/setup.log')
        children=[];started=time.monotonic()
        for gpu,lane in plan['gpu_workers']:
            env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),CUDA_DEVICE_ORDER='PCI_BUS_ID',PYTHONPATH=str(root/'source_snapshot'))
            with (root/'logs'/f'{lane}.log').open('ab',buffering=0) as log:
                p=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.local_hint_run',str(root),'--lane',lane],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            children.append((lane,gpu,p))
        atomic_json(root/'status.json',dict(state='running',children=[dict(role=l,gpu=g,pid=p.pid) for l,g,p in children]));audited=False
        while any(p.poll() is None for _,_,p in children):
            if time.monotonic()-started>plan['max_seconds']+900:raise TimeoutError('Campaign12hours plus15min evaluation ceiling')
            failed={l:p.returncode for l,_,p in children if p.poll() not in [None,0]}
            if failed:raise RuntimeError(f'Ownedworkerfailed:{failed}')
            if not audited:audited=startup_audit(root)
            refresh(root);time.sleep(10)
        if any(p.returncode for _,_,p in children):raise RuntimeError('Worker failed')
        atomic_json(root/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started,workers={lane:read(root/lane/'status.json') for lane in LABELS}))
    except BaseException as error:
        atomic_json(root/'status.json',dict(state='failed',error=repr(error)));raise
    finally:
        for _,_,p in children:
            if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)
        refresh(root)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--setup',action='store_true');p.add_argument('--lane',choices=list(LABELS))
    args=p.parse_args();root=args.root.resolve()
    try:
        if args.prepare:prepare(root)
        elif args.setup:setup_gpu(root)
        elif args.lane:worker(root,args.lane)
        else:campaign(root)
    except BaseException as error:
        if args.lane:atomic_json(root/args.lane/'status.json',dict(state='failed',error=repr(error)))
        raise
