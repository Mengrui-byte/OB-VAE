"""Conditional continuation: one signed-detail OR low-frequency-mid loss factor."""
import argparse
from copy import deepcopy
import hashlib
import html
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import numpy as np
import torch

from model.losses.local_detail import LocalDetailBookLoss
from model.losses.mid_level import MidLevelBookLoss
from train_dual.experiments import local_hint_run as shared
from train_dual.experiments.confirm_recall_goal import require_matching_replay
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.goal_evaluate import assess_file
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.mid_delta_run import violation_key
from train_dual.experiments.phase_detail_report import read,STYLE
from train_dual.experiments.price_safe_readout import file_hash
from train_dual.experiments.quantity_strata_run import bound_small_order_review
from train_dual.experiments.recall_goal_run import candidates,record,render as render_goal
from train_dual.experiments.region_task_run import gpu_free
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import freeze_sources,load_for_inference,seed_everything
from train_dual.util.hint_training import restore_regional_phase_adam
from train_dual.util.phase_training import tensor_digest
from train_dual.util.quantity_strata import evaluate_with_quantity_strata

MODULE='train_dual.experiments.auxiliary_reconstruction_run'
MULTIPLIERS=dict(control=0.,quarter=.25,unit=1.,four=4.)
LABELS={lane:f'附加损失×{value:g}' for lane,value in MULTIPLIERS.items()}


def predecessor_live(root,pid,proc=Path('/proc')):
    try:args=(proc/str(pid)/'cmdline').read_bytes().split(b'\0')
    except FileNotFoundError:return False
    return b'train_dual.experiments.quantity_factorial_run' in args and str(root).encode() in args and b'--controller' in args


def select_source(rows,lanes=('control','no_aug','strata','no_aug_strata')):
    endpoints=set.intersection(*[{r['step'] for r in rows if r['lane']==lane} for lane in lanes])
    if not endpoints or max(endpoints)==0:raise ValueError('Need a trained common endpoint')
    endpoint=max(endpoints)
    # step0 is one fixed original source, not four distinct candidates/seeds.
    pool=[r for r in rows if r['step']==endpoint or (r['step']==0 and r['lane']=='control')]
    return min(pool,key=lambda r:(*violation_key(r),r['lane'])),endpoint


def choose_kind(selected,parent_price_limit):
    return 'mid_lowpass' if selected['price_rmse']>parent_price_limit else 'local_detail'


def reviewed_candidate_decision(goal,candidate):
    decision=bound_small_order_review(goal,candidate)
    if decision:
        review=read(goal/'small_order_candidate_review.json')
        evidence=read(goal/review['strata_evidence'])
        result=evidence.get('result',evidence)
        if result.get('quantity_strata_schema_version')!=2 or result.get('windows')!=16 or len(result.get('quantity_strata',[]))!=6:
            return None # Corrected full16 strata evidence is required for acceptance.
    return decision


def prepare_queue(goal,pid):
    root=goal/'auxiliary_after_factorial_20261028_v3';root.mkdir();(root/'logs').mkdir()
    current=goal/'round_007_quantity_factorial'
    assert read(current/'startup_control_audit.json')['passed']
    assert read(goal/'local_detail_preparation_20261028/status.json')['state']=='prepared_not_training'
    plan=dict(queue_only=True,parent='round_007_quantity_factorial',parent_pid=pid,wait_seconds=13*3600,
        steps=2048,checkpoints=[256,512,1024,2048],max_seconds=43200,
        source_policy='Among all four largest-common-endpoint candidates and exactly one unchanged step0 source, minimize worst then summed normalized violation of original fixed recall/precision/price/mid/quantity gates. Ties favor recall then lower price. Source0 is a fallback, not a fifth independent trial.',
        kind_policy='If selected price exceeds existing current-parent39.197USDT reporting guard, test mid_lowpass; otherwise test local_detail. This does not reset the original goal contract or modify old scores.',
        candidate_policy='Any original-gate native candidate first needs a checkpoint-bound whole-book review. Acceptance requires corrected schema2 full16 strata evidence. Accepted candidates have confirmation priority; do not automatically consume Q2.',
        controls='One selected source/optimizer/RNG/data/augmentation/teacher/oldloss/LR/budget across4arms. Only one new auxiliary coefficient0/.25/1/4 varies. No architecture or upsampling changes.',
        seed=42,original_goal_contract_unchanged=True,quantity_strata_metrics_schema=2,
        base_scale_policy='Preserve exact inherited legacy RMS and weights so the new auxiliary remains the only changed training factor; corrected future refits use separatev3 capsules.')
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared_not_started'))
    freeze_sources(root/'source_snapshot')
    project=Path(__file__).resolve().parents[2];remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 CUDA_DEVICE_ORDER=PCI_BUS_ID OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m {MODULE} "{remote}" --controller >> "{remote}/logs/controller.log" 2>&1\n')
    render(root);record(goal,'auxiliary_queue_prepared',wave=root.name,parent_pid=pid,source_policy=plan['source_policy']);print(root.resolve(),flush=True)


def criterion(root,lane,device='cuda:0',*,calibrating=False):
    p=read(root/'plan.json');old=read(root/'calibration.json');q=read(root/'quantity_calibration.json');a=read(root/'auxiliary_calibration.json')
    if not calibrating and (a['state']!='complete' or not a['weight_calibration_locked']):raise ValueError('Auxiliary gradient calibration is not locked')
    weight=0. if calibrating else a['base_weight']*MULTIPLIERS[lane]
    kwargs=dict(bin_scales=q['RMS_scales_BTC'],stratified_weight=p['base_stratified_weight'],
        mode='shape_mass',use_hint=True,hint_weight=old['hint_weight'],hint_mean=old['channel_mean'],hint_scale=old['channel_scale'],
        use_tail=True,protect_mid=True,tail_weight=old['tail_weight'],mid_weight=old['mid_weight'],
        mid_delta_weight=p['lanes'][lane]['mid_delta_weight'],add_wasserstein=False,add_multiscale=False,
        **p['source_FP_rule'],**p['objective'])
    if p['auxiliary_kind']=='mid_lowpass':obj=MidLevelBookLoss(p['normalization']['quantity_scale'],mid_lowpass_weight=weight,mid_chunks=(16,64,256),**kwargs)
    elif p['auxiliary_kind']=='local_detail':
        scales=read(root/'detail_calibration.json');obj=LocalDetailBookLoss(p['normalization']['quantity_scale'],detail_scales=scales['RMS_scales'],detail_weight=weight,detail_radii=tuple(scales['radii']),**kwargs)
    else:raise ValueError('Unknown auxiliary objective')
    return obj.to(device)


def auxiliary_fields(kind):
    return ('pre_mid_lowpass_loss','mid_lowpass_mse','mid_lowpass_loss_config') if kind=='mid_lowpass' else ('pre_detail_loss','local_signed_detail','local_detail_loss_config')


def verify_detail_calibration_data(source,detail):
    """Verify actual fitted training values; FUSE may expose path-local inodes.

    This verifies precisely the eight windows used to fit detail scales, not a
    full-archive content hash. The production data link is made from source by
    os.link, independently of whether the remote filesystem preserves inode IDs.
    """
    indices=np.load(source/'quantity_calibration_indices.npy')
    assert np.array_equal(indices,np.load(detail/'quantity_calibration_indices.npy'))
    expected=read(detail/'detail_calibration.json')
    assert indices.tolist()==expected['training_indices'] and len(indices)==8
    a,b=read(source/'plan.json'),read(detail/'plan.json')
    for key in ['train','window_size','stride','normalization']:
        assert a[key]==b[key],key
    assert (source/'data/BTCUSDT.npz').stat().st_size==(detail/'data/BTCUSDT.npz').stat().st_size
    data=dataset(source,'train');digest=hashlib.sha256()
    for index in indices:
        values=data[int(index)]['data']
        assert list(values.shape)==[256,2,2048,2] and values.dtype==torch.float32
        digest.update(values.numpy().tobytes())
    assert digest.hexdigest()==expected['selected_raw_values_sha256'], 'Calibration training values differ'
    return dict(state='passed',training_windows=8,selected_raw_values_sha256=digest.hexdigest(),
        samefile_observed=(source/'data/BTCUSDT.npz').samefile(detail/'data/BTCUSDT.npz'),
        scope='Exact raw values of all calibration windows; not a full archive digest.',
        neural_forward_calls=0,optimizer_updates=0)


def prepare_actual(queue,selected,endpoint):
    goal=queue.parent;study=read(queue/'plan.json');parent=goal/study['parent'];old=read(parent/'plan.json')
    detail=goal/'local_detail_preparation_20261028'
    data_audit=verify_detail_calibration_data(parent,detail)
    root=goal/'round_008_auxiliary';root.mkdir()
    for name in ['data','logs','seen','unseen',*LABELS]:(root/name).mkdir()
    for split in ['seen','unseen']:
        for lane in LABELS:(root/split/lane).mkdir()
    # Use the original source state for step0 fallback, not the post-initialization
    # step0 save whose loader may already have advanced its sampler prefetch.
    source=parent/'source.pt' if selected['step']==0 else parent/selected['lane']/f"step{selected['step']}.pt"
    for name in ['source.pt','initial.pt']:os.link(source,root/name)
    for name in ['teacher.pt','calibration.json','train_indices.npy','val_indices.npy','seen_indices.npy','unseen_indices.npy','quantity_calibration_indices.npy','plotly.min.js']:os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    for name in ['quantity_calibration.json']:shutil_copy(parent/name,root/name)
    assert np.array_equal(np.load(root/'quantity_calibration_indices.npy'),np.load(detail/'quantity_calibration_indices.npy'))
    atomic_json(root/'calibration_data_identity.json',data_audit)
    shutil_copy(detail/'detail_calibration.json',root/'detail_calibration.json')
    payload=torch.load(root/'source.pt',map_location='cpu',weights_only=False,mmap=True)
    assert payload['epoch_boundary'] and len(payload['optimizer']['param_groups'])==3
    assert not any(k in payload for k in ['mid_lowpass_loss_config','local_detail_loss_config'])
    model,_=load_for_inference(root/'source.pt','cpu');opt=restore_regional_phase_adam(model,payload['optimizer'],old['original_parameter_names'])
    assert opt.state_dict()['param_groups']==payload['optimizer']['param_groups']
    keys=['train','development','independent_test_untouched','window_size','stride','normalization','model_config',
          'local_hint_config','original_parameter_names','objective','source_FP_rule','augmentation','lr','weight_decay',
          'clip_grad','batch_size','accumulation','seed','beta','sample','input_shape','latent_shape','output_shape','precision']
    plan={k:deepcopy(old[k]) for k in keys if k in old}
    source_lane='control' if selected['step']==0 else selected['lane'];spec=old['lanes'][source_lane]
    kind=choose_kind(selected,old['parent_price_limit_USDT'])
    base_config=payload.get('stratified_quantity_loss_config',dict(weight=0.))
    extras={lane:dict(regional_phase_config=deepcopy(payload['regional_phase_config']),
        stratified_quantity_loss_config=deepcopy(base_config),
        training_numeric_policy=dict(cudnn_deterministic=True,cudnn_benchmark=False,tf32=False),
        inference_numeric_policy=dict(cudnn_deterministic=True,cudnn_benchmark=False,tf32=False)) for lane in LABELS}
    plan.update(experiment='固定来源新增单一辅助重建目标系数对照',labels=LABELS,
        lanes={lane:deepcopy(spec) for lane in LABELS},source_selection=selected,selection_common_endpoint=endpoint,
        source_sha256=file_hash(root/'source.pt'),source_steps=payload['source_steps']+payload['step'],
        source_evaluation_relative=f"../{parent.name}/{source_lane}/step{selected['step']}_development.json",
        source_checkpoint_relative=str(source.relative_to(goal)),initial_model_sha256=tensor_digest(model),
        auxiliary_kind=kind,base_stratified_weight=base_config['weight'],checkpoint_extras=extras,
        steps=study['steps'],checkpoints=study['checkpoints'],max_seconds=study['max_seconds'],
        gpu_workers=[[gpu,lane] for gpu,lane in zip([2,3,4,5],LABELS)],worker_module=MODULE,
        loss_variant='single_auxiliary_'+kind,new_model_parameters=0,quantity_strata_metrics_schema=2,
        inherited_strata_scale_policy='Original baseline RMS preserved exactly; only diagnostic memberships are corrected to match the unchanged Torch loss.',
        parent_price_rmse_USDT=selected['price_rmse'],parent_price_limit_USDT=1.1*selected['price_rmse'],
        controls=study['controls'],original_goal_contract_unchanged=True,
        preview_descriptions={lane:'完整256分钟、唯一8192Gaussian；固定同一来源，只比较新增辅助损失系数。Q1已用于选型，非独立测试。' for lane in LABELS})
    assert plan['input_shape']==[1,256,2,2048,2] and plan['latent_shape']==[1,64,128] and plan['output_shape']==[1,256,2,2048]
    atomic_json(root/'plan.json',plan)
    atomic_json(root/'auxiliary_calibration.json',dict(state='needs_GPU_training_only_gradient_calibration',weight_calibration_locked=False,
        base_weight=None,kind=kind,training_indices=np.load(root/'quantity_calibration_indices.npy').tolist(),optimizer_updates=0))
    for split in ['seen','unseen']:
        atomic_json(root/split/'plan.json',dict(plan,preview_descriptions={lane:'训练年代诊断，非独立测试；评估时不增强。' for lane in LABELS}));os.link(root/'plotly.min.js',root/split/'plotly.min.js')
    atomic_json(root/'status.json',dict(state='prepared_requires_actual_GPU_calibration'));freeze_sources(root/'source_snapshot');render(root)
    return root


def shutil_copy(source,destination):
    import shutil
    shutil.copy2(source,destination)


def calibrate(root):
    torch.set_num_threads(4);seed_everything(42);strict_precision()
    p=read(root/'plan.json');cal=read(root/'auxiliary_calibration.json');assert not cal['weight_calibration_locked']
    assert file_hash(root/'source.pt')==p['source_sha256']
    model,norm=load_for_inference(root/'source.pt','cuda:0');model.train();before=tensor_digest(model)
    teacher,tn=load_for_inference(root/'teacher.pt','cuda:0');teacher.eval().requires_grad_(False);teacher_hash=tensor_digest(teacher)
    obj=criterion(root,'control',calibrating=True);data=dataset(root,'train');params=list(model.encoder.mu.parameters());base2=[];aux2=[];cosines=[]
    base_key,new_key,config_key=auxiliary_fields(p['auxiliary_kind'])
    indices=np.load(root/'quantity_calibration_indices.npy');assert len(indices)==8 and set(indices.tolist())<=set(np.load(root/'train_indices.npy').tolist())
    for n,index in enumerate(indices):
        raw={k:v.unsqueeze(0) for k,v in data[int(index)].items()};offset=int(data.base.starts[int(index)]);times=data.base.times[offset:offset+256]
        assert list(raw['data'].shape)==[1,256,2,2048,2] and np.all(np.diff(times//60000000)==1)
        target=shared.teacher_local(teacher,tn,raw);b=norm.prepare(raw,'cuda:0');seen=[]
        hooks=[m.register_forward_pre_hook(lambda m,args:seen.append(args[0])) for m in [model.price_decoder,model.volume_decoder]]
        with torch.autocast('cuda',dtype=torch.bfloat16):out=call(model,b,False)
        for h in hooks:h.remove()
        assert seen[0] is seen[1] is out['z'] and list(out['z'].shape)==[1,64,128] and list(out['volume'].shape)==[1,256,2,2048]
        v=obj(out,b,teacher_local=target)
        a=torch.autograd.grad(v[base_key],params,retain_graph=True);c=torch.autograd.grad(v[new_key],params)
        aa=sum(float(x.float().square().sum()) for x in a);cc=sum(float(x.float().square().sum()) for x in c)
        base2.append(aa);aux2.append(cc);dot=sum(float((x.float()*y.float()).sum()) for x,y in zip(a,c));cosines.append(dot/math.sqrt(aa*cc) if aa*cc else None)
        atomic_json(root/'gradient_calibration_progress.json',dict(windows=n+1,total=8,optimizer_updates=0))
    ar,br=math.sqrt(float(np.mean(base2))),math.sqrt(float(np.mean(aux2)))
    assert ar>0 and br>0 and math.isfinite(ar+br)
    assert tensor_digest(model)==before and tensor_digest(teacher)==teacher_hash and all(x.grad is None for x in model.parameters())
    cal.update(state='complete',base_weight=ar/br,weight_calibration_locked=True,base_mu_gradient_RMS=ar,auxiliary_mu_gradient_RMS=br,
        per_window_gradient_cosines=cosines,student_forwards=8,teacher_feature_extractions=8,neural_forward_calls=16,optimizer_updates=0,
        source_model_and_teacher_unchanged=True,actual_raw=[1,256,2,2048,2],posterior=[1,64,128],output=[1,256,2,2048],shared_single_Z=True)
    assert file_hash(root/'source.pt')==p['source_sha256']
    atomic_json(root/'auxiliary_calibration.json',cal)
    settings=dict(chunks=[16,64,256]) if p['auxiliary_kind']=='mid_lowpass' else {k:read(root/'detail_calibration.json')[k] for k in ['radii','RMS_scales']}
    for lane in LABELS:p['checkpoint_extras'][lane][config_key]=dict(weight=cal['base_weight']*MULTIPLIERS[lane],multiplier=MULTIPLIERS[lane],kind=p['auxiliary_kind'],**settings)
    atomic_json(root/'plan.json',p);render(root)


def startup_relation(rows,kind,coefficient):
    base_key,new_key,_=auxiliary_fields(kind);base=rows['control']
    for lane,row in rows.items():
        assert row['training_indices']==base['training_indices'] and row['edits']==base['edits']
        for key in [base_key,new_key]:assert row['losses'][key]==base['losses'][key]
        assert math.isclose(row['losses']['loss'],base['losses']['loss']+coefficient*MULTIPLIERS[lane]*base['losses'][new_key],rel_tol=5e-6,abs_tol=5e-6)


def audit_startup(root):
    rows={lane:read(root/lane/'step1_data_audit.json') for lane in LABELS}
    if not all(rows.values()) or not all((root/lane/'step8_gradient_audit.json').exists() for lane in LABELS):return False
    p=read(root/'plan.json');cal=read(root/'auxiliary_calibration.json');startup_relation(rows,p['auxiliary_kind'],cal['base_weight'])
    old=torch.load(root/'source.pt',map_location='cpu',weights_only=False,mmap=True);source=read(root/p['source_evaluation_relative'])['result']
    for lane in LABELS:
        require_matching_replay(read(root/lane/'step0_development.json')['result'],source)
        assert read(root/lane/'actual_shape_contract.json')['passed'] and read(root/lane/'restore_audit.json')['restored_groups']==3
        new=torch.load(root/lane/'step0.pt',map_location='cpu',weights_only=False,mmap=True)
        assert new['model'].keys()==old['model'].keys()
        for name,v in old['model'].items():torch.testing.assert_close(new['model'][name],v,rtol=0,atol=0)
        assert new['optimizer']['param_groups']==old['optimizer']['param_groups'] and new['optimizer']['state'].keys()==old['optimizer']['state'].keys()
        for index,items in old['optimizer']['state'].items():
            for key,v in items.items():
                if torch.is_tensor(v):torch.testing.assert_close(new['optimizer']['state'][index][key],v,rtol=0,atol=0)
                else:assert new['optimizer']['state'][index][key]==v
    atomic_json(root/'startup_control_audit.json',dict(passed=True,same_source_and_all3Adam_states_exact=True,
        same_raw_order_augmented_inputs_and_unweighted_losses=True,only_auxiliary_coefficient_changes=True,
        actual256frame_unique8192_singleZ_decode_checked=True,published_source_development_replayed=True))
    return True


def checkpoint_analysis(root,step):
    dest=root/f'common{step}_analysis.json'
    if dest.exists():return
    paths={lane:root/lane/f'step{step}_development.json' for lane in LABELS}
    if not all(p.exists() for p in paths.values()):return
    plan=read(root/'plan.json');rows=[]
    for lane,path in paths.items():
        r=read(path)['result'];m=r['metrics'];rows.append(dict(lane=lane,**assess_file(path,root.parent/'reference_evaluation.json'),
            parent_price_guard=m['price_usdt']['rmse']<=plan['parent_price_limit_USDT'],quantity_strata=r['quantity_strata'],
            quantity_temporal_variance_ratio=m['temporal_log_quantity_1_minutes']['centered_amplitude_ratio']**2,
            quantity_temporal_correlation=m['temporal_log_quantity_1_minutes']['correlation'],evaluation_sha256=file_hash(path)))
    atomic_json(dest,dict(step=step,auxiliary_kind=plan['auxiliary_kind'],rows=rows));record(root.parent,'auxiliary_common_checkpoint',wave=root.name,step=step,rows=rows)


def render(root):
    p=read(root/'plan.json');status=read(root/'status.json',{});text='<h1>单一辅助重建目标：四组系数对照</h1>'
    if p.get('queue_only'):
        text+='<p>等待当前增强×分层损失四组正常完成。先检查已有合格候选；否则按联合门槛固定一个来源，比较一个新增损失系数0/.25/1/4。原目标和历史结果不重置。</p>'
    else:
        text+='<p>目标类型：'+html.escape(p['auxiliary_kind'])+'。完整256分钟、双侧2048档、唯一64×128Gaussian，无Encoder跳接。四组同一来源/三组Adam/RNG/数据顺序/增强/teacher/旧损失和训练预算；模型全部训练。只改变新增系数，未改上采样、容量或输入归一化。</p>'
        text+='<table><tr><th>组</th><th>训练步</th><th>评估步</th><th>召回≥100BTC</th><th>精确率</th><th>价格RMSE USDT</th><th>数量RMSE BTC</th></tr>'
        for lane,label in LABELS.items():
            paths=list((root/lane).glob('step*_development.json'));latest=max(paths,key=lambda x:int(x.name.split('_')[0][4:])) if paths else None
            values=[label,read(root/lane/'progress.json',{}).get('step',0)]
            if latest:
                v=assess_file(latest,root.parent/'reference_evaluation.json');values += [int(latest.name.split('_')[0][4:]),f"{v['recall100']:.2%}",f"{v['precision100']:.2%}" if v['precision100'] is not None else '—',f"{v['price_rmse']:.3f}",f"{v['quantity_rmse']:.4f}"]
            else:values+=['待评估']*5
            text+='<tr>'+''.join('<td>'+html.escape(str(x))+'</td>' for x in values)+'</tr>'
        text+='</table><p>所有检查点保留六数量区间误差、幅度准确率，以及局部变化方差和相关性。权重仅用8个既有训练窗口在实际GPU上校准；不由开发/独立数据拟合。Q1重复用于开发，不是独立测试。</p>'
    text+='<p>状态：'+html.escape(str(status))+'</p><p><a href="plan.json">协议</a> · <a href="status.json">状态</a> · <a href="../">目标总览</a></p><p>本执行器不自动消耗Q2或宣布目标完成；稀少大单召回、误报、价格和小中单恢复必须共同审查。</p>'
    (root/'index.html').write_text('<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="30"><style>'+STYLE+'</style><main>'+text+'</main>')


def run_cohort(root):
    p=read(root/'plan.json');children=[];begin=time.monotonic();audited=False
    try:
        for gpu,lane in p['gpu_workers']:
            env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),PYTHONPATH=str(root/'source_snapshot'))
            with (root/'logs'/f'{lane}.log').open('ab',buffering=0) as f:
                child=subprocess.Popen([sys.executable,'-u','-m',MODULE,str(root),'--lane',lane],cwd=root/'source_snapshot',env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
            children.append(child)
        atomic_json(root/'status.json',dict(state='running',controller_pid=os.getpid(),pids=[c.pid for c in children]));render(root)
        while any(c.poll() is None for c in children):
            if any(c.poll() not in [None,0] for c in children):raise RuntimeError('Owned auxiliary worker failed')
            if time.monotonic()-begin>p['max_seconds']+1800:raise TimeoutError('12hour training plus30min evaluation ceiling')
            if not audited:audited=audit_startup(root)
            for step in p['checkpoints']:checkpoint_analysis(root,step)
            render(root);time.sleep(10)
        if any(c.returncode for c in children) or not (audited or audit_startup(root)):raise RuntimeError('Auxiliary startup/worker audit incomplete')
        for step in p['checkpoints']:checkpoint_analysis(root,step)
        atomic_json(root/'status.json',dict(state='complete',controller_pid=os.getpid(),elapsed_seconds=time.monotonic()-begin));render(root)
    finally:
        for child in children:
            if child.poll() is None:os.killpg(child.pid,signal.SIGTERM)


def controller(queue):
    config=read(queue/'plan.json');goal=queue.parent;parent=goal/config['parent'];begin=time.monotonic()
    while True:
        state=read(parent/'status.json',{});live=predecessor_live(parent,config['parent_pid'])
        if state.get('state')=='failed':raise RuntimeError('Predecessor failed; do not start from partial results')
        if not live:
            if state.get('state')=='complete':break
            raise RuntimeError('Verified predecessor handle missing without successful terminal state')
        if time.monotonic()-begin>config['wait_seconds']:raise TimeoutError('13hour predecessor wait ceiling')
        atomic_json(queue/'status.json',dict(state='verified_wait_parent',pid=os.getpid(),parent_pid=config['parent_pid']));render(queue);time.sleep(20)
    assert read(parent/'startup_control_audit.json')['passed']
    assert all(read(parent/lane/'status.json')['state'] in ['complete','budget_complete'] for lane in read(parent/'plan.json')['labels'])
    rows=candidates(parent,goal/'reference_evaluation.json');qualified=[r for r in rows if r['pass']]
    existing=read(goal/'candidate_for_confirmation.json',{})
    if existing:
        evaluation=Path(existing['evaluation'])
        if not evaluation.is_file() or not Path(existing['checkpoint']).is_file():raise ValueError('Existing candidate has missing evidence; review before more training')
        if assess_file(evaluation,goal/'reference_evaluation.json')['pass']:qualified.append(existing)
    if qualified:
        candidate=max(qualified,key=lambda r:(r['recall100'],-r['price_rmse']))
        decision=reviewed_candidate_decision(goal,candidate)
        while decision is None:
            if time.monotonic()-begin>config['wait_seconds']:raise TimeoutError('Whole-book autonomous candidate review pending')
            atomic_json(queue/'status.json',dict(state='waiting_whole_book_review',pid=os.getpid(),candidate=candidate));render(queue);time.sleep(20)
            decision=reviewed_candidate_decision(goal,candidate)
        if decision:
            atomic_json(queue/'status.json',dict(state='not_run_accepted_candidate_requires_confirmation',candidate=candidate));render(queue);return
    selected,endpoint=select_source(rows)
    atomic_json(queue/'source_selection.json',dict(selected=selected,largest_common_endpoint=endpoint,all_rows=rows,
        scope='Only original repeatedly used Q1 development metrics; no independent data. Fixed original contract unchanged.'))
    while any(gpu_free().get(g,0)<47000 for g in [2,3,4,5]):
        if time.monotonic()-begin>config['wait_seconds']:raise TimeoutError('GPU release wait ceiling')
        atomic_json(queue/'status.json',dict(state='verified_wait_GPU_release',pid=os.getpid()));render(queue);time.sleep(10)
    root=prepare_actual(queue,selected,endpoint)
    atomic_json(queue/'status.json',dict(state='training_only_gradient_calibration',pid=os.getpid(),wave=root.name));render(queue)
    env=dict(os.environ,CUDA_VISIBLE_DEVICES='2',PYTHONPATH=str(root/'source_snapshot'))
    with (root/'logs/gradient_calibration.log').open('ab',buffering=0) as f:
        result=subprocess.run([sys.executable,'-u','-m',MODULE,str(root),'--calibrate'],cwd=root/'source_snapshot',env=env,stdout=f,stderr=subprocess.STDOUT,timeout=3600)
    if result.returncode or not read(root/'auxiliary_calibration.json')['weight_calibration_locked']:raise RuntimeError('ActualGPU gradient calibration failed before updates')
    atomic_json(queue/'status.json',dict(state='running',pid=os.getpid(),wave=root.name));render(queue)
    atomic_json(goal/'status.json',dict(state='running_single_auxiliary_controlled_cohort',wave=root.name))
    run_cohort(root)
    new=candidates(root,goal/'reference_evaluation.json');old=read(goal/'candidates.json',{}).get('rows',[])
    atomic_json(goal/'candidates.json',dict(rows=[r for r in old if r.get('experiment')!=root.name]+[dict(r,experiment=root.name) for r in new]))
    atomic_json(goal/'status.json',dict(state='auxiliary_complete_requires_joint_whole_book_review',wave=root.name,goal_achieved=False))
    atomic_json(queue/'status.json',dict(state='complete',wave=root.name,goal_automatically_completed=False));render(queue);render_goal(goal)
    record(goal,'auxiliary_cohort_complete',wave=root.name,next='Review joint goal and six quantity scales; freeze an eligible native candidate before independent confirmation, otherwise continue research. No automatic Q2.')


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--parent-pid',type=int)
    p.add_argument('--controller',action='store_true');p.add_argument('--calibrate',action='store_true');p.add_argument('--lane',choices=list(LABELS));args=p.parse_args();root=args.root.resolve()
    def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        if args.prepare:
            if not args.parent_pid:p.error('--parent-pid required')
            prepare_queue(root,args.parent_pid)
        elif args.controller:controller(root)
        elif args.calibrate:calibrate(root)
        elif args.lane:
            shared.evaluate=evaluate_with_quantity_strata
            shared.worker(root,args.lane,objective_factory=criterion,optimizer_factory=restore_regional_phase_adam)
        else:p.error('Specify a mode')
    except BaseException as error:
        if not args.prepare:atomic_json((root/args.lane if args.lane else root)/'status.json',dict(state='failed',pid=os.getpid(),error=repr(error)))
        raise

if __name__=='__main__':main()
