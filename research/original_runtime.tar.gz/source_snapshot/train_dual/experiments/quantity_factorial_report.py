"""Read-only common-checkpoint quantity/dynamics report; no model imports/inference."""
import argparse
import hashlib
import html
import json
from pathlib import Path

LANES = ['control','no_aug','strata','no_aug_strata']
BINS = ['0–0.01','0.01–0.1','0.1–1','1–10','10–100','≥100']

def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def fmt(v,d=4):return '—' if v is None else f'{v:.{d}g}'
def pct(v):return '—' if v is None else f'{100*v:.2f}%'
def row(values):return '<tr>'+''.join('<td>'+html.escape(str(x))+'</td>' for x in values)+'</tr>'

def render(root):
    plan=read(root/'plan.json')
    lanes=list(plan['labels'])
    sets=[{int(p.name.split('_')[0][4:]) for p in (root/lane).glob('step*_development.json')} for lane in lanes]
    common=sorted(set.intersection(*sets))
    if not common:return dict(state='waiting_common_native_checkpoint')
    step=max(common)
    paths={lane:root/lane/f'step{step}_development.json' for lane in lanes}
    results={lane:read(p)['result'] for lane,p in paths.items()}
    baseline_lane='control' if 'control' in lanes else lanes[0]
    baseline=read(root/baseline_lane/'step0_development.json')['result']
    schemas={r.get('quantity_strata_schema_version',1) for r in [baseline,*results.values()]}
    assert len(schemas)==1, 'Do not compare quantity bins from different membership schemas'
    schema=next(iter(schemas))
    assert all(r['windows']==baseline['windows'] and r['window_indices']==baseline['window_indices'] for r in results.values())
    base_bins=baseline['quantity_strata']
    assert all([q['count'] for q in r['quantity_strata']]==[q['count'] for q in base_bins] for r in results.values())
    if plan.get('relative_aggregation_pilot'):
        design='本轮为释放GPU2/3上的两组短对照：两组均完整FP32、冻结Encoder和价格Decoder，各512更新；只比较原目标与增加按位置平均的物理log相对项。系数仅在8训练窗按挂量Decoder梯度校准一次。同一原强参考参数、三组Adam/RNG、数据和原目标，旧价格参数及原生价格指标逐值核验。该短实验不替代正式2048四组，不是新种子，不能和父实验继续联合训练的模型作单因素比较。'
    elif plan.get('relative_aggregation_ablation'):
        design='本轮为相对log逐点损失聚合对照：来源原目标、等桶权、√计数权、每窗有效位置平均。四组同一冻结来源、完整继承三组Adam/RNG、数据/顺序、增强、teacher及精度策略；三个相对项组共用一个锁定系数。来源已有非零相对项时复用原系数且只替换归约，control/equal_bins成为重复控制；其他情况只在alpha0校准一次。未更改有符号细节项、模型、上采样、输入尺度或瓶颈。'
    elif plan.get('branch_precision_factorial'):
        design='本轮为完整Encoder精度×完整post-Z路径精度的2×2控制：原BF16训练、仅Encoder FP32、仅价格/数量/hint路径FP32、两者FP32。四组同一冻结来源，完整继承三组Adam、原始抽样顺序、增强开关、teacher、原损失及全部系数、seed42和2048追加更新预算。原生评估始终FP32，step0必须精确重放。未更改激活、上采样、输入尺度、瓶颈或模型参数；比较相同更新预算并另报实际耗时。'
    elif plan.get('relative_detail_factorial'):
        design='本轮为两项损失的2×2控制：原目标、只加相对log误差、只加有符号log细节、两项同时加入。四组同一冻结来源，完整继承三组Adam、原始抽样顺序、增强开关、teacher、seed42和2048追加更新预算。未更改激活、精度、上采样、输入尺度或瓶颈。'
    elif 'auxiliary_kind' in plan:
        design=f'本轮新增目标：{html.escape(plan["auxiliary_kind"])}，只改变其系数0/.25/1/4。四组同一冻结来源，完整继承三组Adam、原始抽样顺序、增强开关、teacher、seed42和2048追加更新预算。未更改上采样、输入尺度或瓶颈。'
    else:
        design='A原增强原损失；B关闭增强原损失；C原增强加分层损失；D关闭增强加分层损失。四组同一个control2048来源，全部三组Adam、原始抽样顺序、teacher、seed42和2048追加更新预算一致。未更改上采样或瓶颈。'
    body=['<!doctype html><html lang="zh"><meta charset="utf-8"><meta http-equiv="refresh" content="30"><title>大小挂单与局部方差对照</title><style>body{font:16px/1.65 system-ui;max-width:1280px;margin:32px auto;padding:0 18px;color:#203348}table{border-collapse:collapse;width:100%;background:white;font-size:14px}td,th{padding:8px;border-bottom:1px solid #dce4ec;text-align:left}.note{background:#edf4fc;padding:16px;border-radius:10px}.wrap{overflow:auto}h1,h2{line-height:1.3}a{color:#1664ab}</style>',
        '<h1>完整订单簿：大小挂单与局部变化</h1>',
        f'<p class="note">共同评估点：追加{step}步；全部{len(lanes)}组同一批16个Q1开发窗口、完整256分钟、双侧2048档、唯一8192 latent。下表只比较共同评估点；原始样本、时间和数量分桶完全一致。开发集反复用于选型，非独立测试。</p>',
        '<p>'+design+'</p>',
        '<h2>总体重建与大单</h2><div class="wrap"><table><tr><th>组</th><th>训练进度</th><th>价格RMSE USDT</th><th>相对来源价格保护</th><th>数量RMSE BTC</th><th>≥100召回</th><th>≥100精确率</th><th>TP/FP/FN</th></tr>']
    if schema==1:
        body.insert(3,'<p class="note"><strong>历史分桶勘误（schema1）：</strong>下方六桶沿用本轮冻结评估代码的原始结果，未重新计算。该代码先把数量转为float64再与小数阈值比较，恰好为0.01 BTC的float32原值会被归入最低桶，与训练时的分桶不同。因此最低两桶不能按严格的小数边界解释，也不能和schema2直接比较。价格、整体数量误差、100 BTC召回/精确率以及局部方差指标不受这一分桶问题影响。新评估已统一采用与训练一致的float32边界；本轮历史快照、模型、损失权重和结果JSON均保留。</p>')
    for lane,r in results.items():
        m=r['metrics'];t=r['thresholds']['100'];p=root/lane/'progress.json';progress=read(p)['step'] if p.exists() else 0
        body.append(row([plan['labels'][lane],f'{progress}/{plan["steps"]}',fmt(m['price_usdt']['rmse']),
             '通过' if m['price_usdt']['rmse']<=plan['parent_price_limit_USDT'] else '未通过',
             fmt(m['quantity_btc']['rmse']),pct(t['recall']),pct(t['precision']),f"{t['tp']}/{t['fp']}/{t['fn']}"]))
    body+=['</table></div>',f'<p>来源价格RMSE {plan["parent_price_rmse_USDT"]:.6f} USDT；本轮父模型保护线 {plan["parent_price_limit_USDT"]:.6f} USDT。价格单位是USDT，不是tick数量。</p>',
        '<h2>六个真实数量区间：各区间逐位置恢复</h2><p>归一化RMSE=该区间RMSE/真实数量RMS；质量不能只由所有档位合并后的MSE判断。误差≤20%的比例要求数量幅度在原位置接近真实值，不等同于大单阈值召回。</p>']
    for b,label in enumerate(BINS):
        suffix='（历史分桶，见上方勘误）' if schema==1 and b<2 else ''
        body.append(f'<h3>{label} BTC{suffix} · 真实档位数 {base_bins[b]["count"]:,}</h3><div class="wrap"><table><tr><th>组</th><th>MAE BTC</th><th>RMSE BTC</th><th>归一化RMSE</th><th>RMSE/来源同区间RMSE</th><th>数量误差≤20%</th><th>数量在0.5–2倍内</th><th>预测量/真实量总和</th></tr>')
        for lane,r in results.items():
            v=r['quantity_strata'][b];ratio=v['RMSE_BTC']/base_bins[b]['RMSE_BTC'] if base_bins[b]['RMSE_BTC'] else None
            body.append(row([plan['labels'][lane],fmt(v['MAE_BTC']),fmt(v['RMSE_BTC']),fmt(v['normalized_RMSE']),fmt(ratio),pct(v['within20percent']),pct(v['within_factor2']),fmt(v['quantity_mass_ratio'])]))
        body.append('</table></div>')
    body.append('<h2>局部变化：方差与正确位置的相关性一起看</h2><p>方差比=重建方差/真实方差=标准差比的平方。仅提高方差，不能证明尖峰位置和出现时间恢复。挂量时间变化沿档位编号比较，不能当成同一物理价格的订单流。</p><div class="wrap"><table><tr><th>组</th><th>相邻价格间隔帧内方差比</th><th>对应相关性</th><th>去mid盘口分钟变化方差比</th><th>对应相关性</th><th>log挂量分钟变化方差比</th><th>对应相关性</th></tr>')
    for lane,r in results.items():
        vals=[plan['labels'][lane]]
        for key in ['spatial_slope_1_within_frame_variation','temporal_shape_1_minutes_after_mid_removal','temporal_log_quantity_1_minutes']:
            v=r['metrics'][key];vals += [pct(v['centered_amplitude_ratio']**2),fmt(v['correlation'])]
        body.append(row(vals))
    body.append('</table></div><h2>同一批预览窗的订单簿图</h2><p>每组固定预览窗相同；必须把小量级、虚假大峰和真实峰同时检查。预览只含3窗，不替代上面的完整16窗指标。</p><ul>')
    for lane in lanes:
        p=root/lane/f'step{step}_preview.html'
        if p.exists():body.append(f'<li><a href="{lane}/{p.name}">{html.escape(plan["labels"][lane])}：订单簿预览</a></li>')
    body.append('</ul><p><a href="index.html">运行进度</a> · <a href="plan.json">实验协议</a> · <a href="strata_variance_report.json">本报告数据来源指纹</a></p></html>')
    for name in ['strata_variance_report.html','strata_variance_report.json']:
        previous=root/name
        if previous.exists():
            history=root/'report_history';history.mkdir(exist_ok=True)
            target=history/(previous.stem+'_'+sha(previous)+previous.suffix)
            if not target.exists():target.write_bytes(previous.read_bytes())
    (root/'strata_variance_report.html').write_text(''.join(body))
    source=Path(__file__);digest=sha(source);capsule=root/'observer_sources';capsule.mkdir(exist_ok=True);target=capsule/(digest+'.py')
    if not target.exists():target.write_bytes(source.read_bytes())
    result=dict(state='complete',common_checkpoint=step,common_available=common,windows=baseline['windows'],
                source_evaluations={lane:dict(path=str(p.relative_to(root)),sha256=sha(p)) for lane,p in paths.items()},
                observer_sha256=digest,observer_source=str(target.relative_to(root)),model_forward_calls=0,optimizer_updates=0,
                quantity_strata_schema_version=schema,legacy_boundary_warning=schema==1)
    (root/'strata_variance_report.json').write_text(json.dumps(result,indent=2));return result

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);args=p.parse_args()
    print(json.dumps(render(args.root.resolve())))
