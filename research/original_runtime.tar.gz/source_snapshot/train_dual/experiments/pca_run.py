"""Frozen PCA baseline, then matched generator-only adaptation on four GPUs."""

import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import numpy as np
import torch
from torch.utils.data import Dataset,DataLoader

from model.experimental.dual_fusion import FusedOrderBookVAE
from model.experimental.pca_state import PCAWindowVAE
from model.losses.dual import DualLossConfig,DualVAELoss
from train_dual.experiments.long_worker import atomic_json,datasets,evaluate,score,rng_state
from train_dual.experiments.window_state_pilot import load_base,strict_precision,market_features,FEATURE_NAMES
from train_dual.util.checkpoint import atomic_save,seed_everything,source_hashes


LANES=('reference','d1024','d512','d256')


class CachedWindows(Dataset):
    def __init__(self,data,indices,order):self.data,self.indices,self.order=data,indices,order
    def __len__(self):return len(self.order)
    def __getitem__(self,index):
        pos=int(self.order[index]);raw=self.data[int(self.indices[pos])];raw['cache_position']=torch.tensor(pos)
        return raw


def decode_direct(model,zg,zl,mask,tick,times):
    p=model.price_decoder(zg,zl,mask,tick,times=times)
    q=model.volume_decoder(zg,zl,p,mask,tick,times=times)
    q=model.volume_refinement(zg,zl,q,p,mask,tick,times)
    return {**p,'volume':q}


def examples(root,folder,model,normalizer,initial,plan):
    model.eval();data=datasets(root,initial,'val');predictions,truths,masks,times,vectors=[],[],[],[],[]
    with torch.inference_mode():
        for index in plan['example_indices']:
            raw={k:v.unsqueeze(0) for k,v in data[index].items()};b=normalizer.prepare(raw,'cuda:0')
            out=model(b['price'],b['volume'],b['mask'],b['tick_norm'],times=b['times'],sample=False)
            predictions.append(np.stack([normalizer.inverse_price(out['price_norm'],b)[0].cpu().numpy(),out['volume'][0].cpu().numpy()],-1))
            truths.append(raw['data'][0].numpy());masks.append(b['mask'][0].cpu().numpy())
            start=int(data.base.starts[index]);times.append(data.base.times[start:start+16])
            if 'market_state' in out:vectors.append(out['market_state'][0].cpu().numpy())
    np.savez_compressed(folder/'profiles.npz',prediction=np.stack(predictions),truth=np.stack(truths),mask=np.stack(masks),
        time=np.stack(times),indices=np.array(plan['example_indices']),**({'market_state':np.stack(vectors)} if vectors else {}))


def reference(root):
    initial,norm=load_base(root);plan=json.loads((root/'plan.json').read_text())
    seed_everything(42);strict_precision();torch.set_num_threads(4)
    model=FusedOrderBookVAE(fusion_variant='cross',fusion_seed=42,**initial['model_config']).to('cuda:0')
    model.load_state_dict(initial['model'],strict=True)
    value=evaluate(model,norm,datasets(root,initial,'val'),plan['evaluation_windows'],'cuda:0')
    atomic_json(root/'source_reference.json',dict(result=value,checkpoint=plan['initial_checkpoint']))
    folder=root/'frozen_source';folder.mkdir(exist_ok=True);examples(root,folder,model,norm,initial,plan)
    del model;torch.cuda.empty_cache()


def state_probe(root,folder,model,norm,initial,cached_states,plan):
    train=datasets(root,initial,'train');val=datasets(root,initial,'val');fit_indices=np.load(root/'fit_indices.npy')
    positions=np.unique(np.linspace(0,len(fit_indices)-1,512,dtype=int))
    x=cached_states[positions].numpy().astype(np.float64)
    y=np.stack([market_features({k:v.unsqueeze(0) for k,v in train[int(fit_indices[pos])].items()})[0] for pos in positions])
    xv,yv,ts=[],[],[];model.eval()
    with torch.inference_mode():
        for index in np.unique(np.linspace(0,len(val)-1,plan['evaluation_windows'],dtype=int)):
            raw={k:v.unsqueeze(0) for k,v in val[int(index)].items()};b=norm.prepare(raw,'cuda:0')
            xv.append(model.extract_market_state(b['price'],b['volume'],b['mask'],b['tick_norm'],b['times'])[0].cpu().numpy())
            yv.append(market_features(raw)[0]);ts.append(int(val.base.times[int(val.base.starts[index])+15]))
    xv,yv=np.stack(xv).astype(np.float64),np.stack(yv)
    center,scale=x.mean(0),x.std(0).clip(1e-6);a,b=(x-center)/scale,(xv-center)/scale
    ym,ys=y.mean(0),y.std(0).clip(1e-6)
    weights=np.linalg.solve(a.T@a+100*np.eye(x.shape[1]),a.T@((y-ym)/ys))
    prediction=b@weights*ys+ym;error=np.square(prediction-yv).mean(0);variance=np.square(yv-yv.mean(0)).mean(0)
    rows={name:dict(rmse=float(np.sqrt(error[i])),r2=float(1-error[i]/variance[i]) if variance[i]>1e-12 else None) for i,name in enumerate(FEATURE_NAMES)}
    atomic_json(folder/'state_probe.json',dict(features=rows,fit='512 training windows; train-only scaler and ridge alpha100; 128 development windows',state_dim=x.shape[1]))
    np.savez_compressed(folder/'market_states.npz',train_states=x,development_states=xv,train_targets=y,development_targets=yv,development_predictions=prediction,development_end_time=np.array(ts))


def worker(root,lane):
    torch.set_num_threads(4);seed_everything(42);strict_precision()
    plan=json.loads((root/'plan.json').read_text());fit=json.loads((root/'pca_fit.json').read_text())
    selection=json.loads((root/'basis_selection.json').read_text()) if (root/'basis_selection.json').exists() else {}
    initial,norm=load_base(root);folder=root/lane;folder.mkdir(exist_ok=True);compressed=lane!='reference'
    if compressed:
        model=PCAWindowVAE(state_dim=int(lane[1:]),global_components=fit['global_components'],**initial['model_config'])
        model.load_cross_initial(initial['model']);model.state_codec.load_basis(torch.load(root/selection.get('basis_file','pca_basis.pt'),map_location='cpu',weights_only=False))
        cached=torch.load(root/selection.get('state_pattern','train_states_{dimension}.pt').format(dimension=lane[1:]),map_location='cpu',weights_only=False)['states']
    else:
        model=FusedOrderBookVAE(fusion_variant='cross',fusion_seed=42,**initial['model_config']);model.load_state_dict(initial['model'],strict=True)
        model.encoder.requires_grad_(False);model.fusion.requires_grad_(False)
        cached=torch.load(root/'decoder_latents.pt',map_location='cpu',weights_only=False)
    model.to('cuda:0');val=datasets(root,initial,'val');criterion=DualVAELoss(config=DualLossConfig(**plan['loss']))
    baseline=json.loads((root/'source_reference.json').read_text())['result'];hashes=source_hashes();started=time.monotonic()

    def checkpoint(path,step,optimizer=None):
        payload=dict(format_version=1,model=model.state_dict(),model_config=initial['model_config'],config=dict(initial['config'],loss=plan['loss']),
                     fusion_variant='cross',refinement_seed=42,step=step,source_hashes=hashes,source_checkpoint=plan['initial_checkpoint'],epoch_completed=False,rng=rng_state())
        if compressed:payload['pca_state_config']=model.pca_state_config
        if optimizer is not None:payload['optimizer']=optimizer.state_dict()
        atomic_save(payload,path)

    def validation(stage,step):
        result=evaluate(model,norm,val,plan['evaluation_windows'],'cuda:0')
        row=dict(stage=stage,step=step,result=result,score=score(result,baseline),elapsed_seconds=time.monotonic()-started,
                 evaluation_backend='strict_fp32',state_dim=int(lane[1:]) if compressed else None)
        atomic_json(folder/(stage+'_evaluation.json'),row)
        with (folder/'evaluations.jsonl').open('a') as stream:stream.write(json.dumps(row)+'\n')
        return row

    try:
        atomic_json(folder/'progress.json',dict(state='frozen_generator_evaluation',step=0,lane=lane))
        frozen=validation('frozen',0);checkpoint(folder/'frozen.pt',0)
        best=frozen['score'];os.link(folder/'frozen.pt',folder/'best.pt')
        examples(root,folder,model,norm,initial,plan)
        (folder/'profiles.npz').replace(folder/'frozen_profiles.npz')
        parameters=[p for name,p in model.named_parameters() if name.startswith(('price_decoder.','volume_decoder.','volume_refinement.'))]
        optimizer=torch.optim.AdamW(parameters,lr=plan['decoder_lr'],weight_decay=.01)
        train=datasets(root,initial,'train');indices=np.load(root/'fit_indices.npy');order=np.load(root/'train_cache_order.npy')
        loader=DataLoader(CachedWindows(train,indices,order),batch_size=plan['physical_batch'],shuffle=False,num_workers=2,pin_memory=True,
                          generator=torch.Generator().manual_seed(42))
        accumulation=plan['effective_batch']//plan['physical_batch'];optimizer.zero_grad(set_to_none=True);model.train();loss_sum=0.;step=0
        torch.cuda.reset_peak_memory_stats()
        for micro,raw in enumerate(loader,1):
            positions=raw['cache_position'];batch=norm.prepare(raw,'cuda:0')
            with torch.autocast('cuda',dtype=torch.bfloat16):
                if compressed:out=model.decode_state(cached[positions].to('cuda:0'),batch['mask'],batch['tick_norm'],batch['times'])
                else:out=decode_direct(model,cached['global'][positions].to('cuda:0'),cached['local'][positions].to('cuda:0'),batch['mask'],batch['tick_norm'],batch['times'])
            terms=criterion(out,batch);loss=terms['loss']
            if not torch.isfinite(loss):raise FloatingPointError('Nonfinite decoder adaptation loss')
            (loss/accumulation).backward();loss_sum+=loss.item()/accumulation
            if micro%accumulation:continue
            normg=torch.nn.utils.clip_grad_norm_(parameters,1.,error_if_nonfinite=True);optimizer.step();optimizer.zero_grad(set_to_none=True);step+=1
            if step==1 or step%8==0:
                row=dict(state='decoder_adaptation',lane=lane,step=step,loss=loss_sum,gradient_norm=float(normg),samples_seen=step*plan['effective_batch'],
                    elapsed_seconds=time.monotonic()-started,peak_allocated_gib=torch.cuda.max_memory_allocated()/2**30,reserved_gib=torch.cuda.memory_reserved()/2**30)
                atomic_json(folder/'progress.json',row);print(json.dumps(row),flush=True)
                with (folder/'train.jsonl').open('a') as stream:stream.write(json.dumps(row)+'\n')
            loss_sum=0.
            if step%plan['evaluation_every']==0:
                checkpoint(folder/'last.pt',step,optimizer);row=validation('latest',step)
                if row['score']<best:best=row['score'];checkpoint(folder/'best.pt',step)
            if step==plan['steps']:break
        if step!=plan['steps']:raise RuntimeError('Training sample budget ended early')
        checkpoint(folder/'final.pt',step,optimizer);final=validation('final',step)
        examples(root,folder,model,norm,initial,plan)
        if compressed:state_probe(root,folder,model,norm,initial,cached,plan)
        atomic_json(folder/'status.json',dict(state='complete',step=step,elapsed_seconds=time.monotonic()-started))
    except BaseException as error:
        atomic_json(folder/'status.json',dict(state='failed',error=repr(error)));raise


def campaign(root):
    plan=json.loads((root/'plan.json').read_text());started=time.monotonic();children=[]
    status=dict(state='evaluating_frozen_reference',children=[]);atomic_json(root/'status.json',status)
    try:
        reference(root)
        for gpu,lane in zip((2,3,4,5),LANES):
            env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),CUDA_DEVICE_ORDER='PCI_BUS_ID',PYTHONPATH=str(root/'source_snapshot'),
                     PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4')
            with (root/'logs'/(lane+'.log')).open('ab',buffering=0) as log:
                p=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.pca_run',str(root),'--lane',lane],cwd=root/'source_snapshot',env=env,
                    stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            children.append((lane,p));status['children'].append(dict(lane=lane,gpu=gpu,pid=p.pid))
        status['state']='running';atomic_json(root/'status.json',status)
        while any(p.poll() is None for _,p in children):
            if time.monotonic()-started>plan['training_timeout_seconds']:raise TimeoutError('Decoder comparison timeout')
            if any(p.poll() not in (None,0) for _,p in children):raise RuntimeError('A paired worker failed')
            time.sleep(3)
        codes={lane:p.returncode for lane,p in children}
        if any(code!=0 for code in codes.values()):raise RuntimeError(f'Worker failures: {codes}')
        baseline=json.loads((root/'source_reference.json').read_text())['result'];rows={};qualified={'frozen':[],'final':[]}
        for lane in LANES:
            rows[lane]={stage:json.loads((root/lane/(stage+'_evaluation.json')).read_text()) for stage in ('frozen','final')}
            if lane=='reference':continue
            for stage in ('frozen','final'):
                result=rows[lane][stage]['result'];a,b=result['metrics'],baseline['metrics']
                checks={key:a[key]['rmse']<=factor*b[key]['rmse'] for key,factor in plan['quality_limits'].items()}
                checks['large_recall']=result['thresholds']['100']['recall']>=baseline['thresholds']['100']['recall']-plan['large_recall_tolerance']
                rows[lane][stage]['quality_checks']=checks;rows[lane][stage]['qualified']=all(checks.values())
                if all(checks.values()):qualified[stage].append(int(lane[1:]))
            rows[lane]['probe']=json.loads((root/lane/'state_probe.json').read_text())
        atomic_json(root/'comparison.json',dict(rows=rows,minimum_dimension={k:min(v) if v else None for k,v in qualified.items()},
                    reference=baseline,limitation='Single-seed bounded comparison; no information-theoretic minimum is inferred'))
        status.update(state='complete',elapsed_seconds=time.monotonic()-started)
    except BaseException as error:status.update(state='failed',error=repr(error));raise
    finally:
        for _,p in children:
            if p.poll() is None:
                try:os.killpg(p.pid,signal.SIGTERM)
                except ProcessLookupError:pass
        for _,p in children:
            try:p.wait(timeout=10)
            except subprocess.TimeoutExpired:
                try:os.killpg(p.pid,signal.SIGKILL)
                except ProcessLookupError:pass
        atomic_json(root/'status.json',status)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--lane',choices=LANES);a=p.parse_args()
    if a.lane:worker(a.root,a.lane)
    else:campaign(a.root)
