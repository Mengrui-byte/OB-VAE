"""Live8192-window report and complete256minute order-line previews."""
import argparse
from pathlib import Path
from train_dual.experiments.full_window_report import PAGE,monitor


def main(root):
    page=PAGE.replace('256分钟双分支实验','8192维统一窗口VAE').replace('完整256分钟：双分支与整窗矩阵压缩','完整256分钟：唯一8192维窗口latent')
    begin=page.index('<p>实际输入');end=page.index('<p id=status>',begin)
    text=('<p>输入[B,256,2,2048,2]，整窗唯一Gaussian posterior的μ和logvar均为[B,64,128]；价格和挂单量Decoder共用同一次采样Z，无Encoder跳接。价格有序、数量非负；数量条件来自预测价格。LoG为固定输入特征。</p>'
          '<p>四组完全相同的seed42新初始化，全模型从头训练：确定性AE，以及β=1e−6/1e−5/1e−4的真实采样VAE。每张卡batch1×累积4，计划2048次更新、最长12小时，KL前256步渐增。64个2022–2024抽样训练窗，同16个2025Q1开发窗；开发期已用于研究，不能视为最终独立测试。2026不参与训练选型。</p>'
          '<p>价格使用训练RMS归一化Huber；数量使用线性与log1p Huber，另加同位Top16量价损失，KL对8192坐标求和。推理图均使用μ。旧Cross大latent参考仅为外部质量标尺，其容量、初始化及训练成本不同。归一化参数和输出偏置只拟合64个训练窗；无未来收益。</p>')
    page=page[:begin]+text+page[end:]
    page=page.replace('实际矩阵','实际唯一latent').replace('256分钟初始化样本','训练归一化窗口')
    monitor(root,page)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);main(p.parse_args().root)
