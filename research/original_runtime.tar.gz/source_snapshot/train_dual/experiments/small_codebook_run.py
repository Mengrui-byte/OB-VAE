"""Small unconstrained paired codebooks: one fixed source, distance and seed."""

import argparse
from datetime import datetime
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.paired_matrix_run import worker
from train_dual.util.checkpoint import freeze_sources


def prepare(parent):
    parent=parent.resolve();root=parent.parent/('small_codebook_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
    root.mkdir();(root/'logs').mkdir();(root/'data').mkdir()
    for name in ('initial.pt','expected_reference.json','source_profiles.npz'):
        os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    for name in ('decoder_latents.pt','fit_indices.npy'):
        (root/name).symlink_to(os.path.relpath((parent/name).resolve(),root))
    plan=json.loads((parent/'plan.json').read_text())
    plan.update(parent=str(parent),experiment='Unconstrained small common-index matrix codebooks',
        hypothesis='Smaller codebooks may spread residual assignments beyond a common code and singleton outliers; semantics assessed post-hoc only.',
        no_semantic_constraints=True,no_auxiliary_heads=True,no_future_returns=True,
        features_source=str(parent/'analysis/market_states_20261025_140914'),
        lanes={f'k{k}_l{levels}':dict(mode='joint',metric='l2',size=k,levels=levels,depths=[d for d in (1,2,4,8,16) if d<=levels])
               for k,levels in ((8,8),(16,8),(32,8),(16,16))},
        rate_note='8x8=24bits,8x16=32bits,8x32=40bits;16x16=64bits matches old8x256 index rate but changes depth and codebook cost.',
        method='Only K and, for the equal-rate control, residual depth change. Original random paired-sample initialization, 12 Lloyd iterations, no whitening, no semantic loss, no occupancy regularizer, no zero skip code.',
        primary_evaluation='Natural class occupancy at each level, train-to-development descriptive feature transfer, conditional association beyond previous levels; book metrics retained.')
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'))
    freeze_sources(root/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(parent.parents[1])
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'
        f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\n'
        f'cd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.small_codebook_run "{remote}"\n')
    Path('/tmp/small_codebook_run_path').write_text(str(root));print(root,flush=True)


def campaign(root,worker_module='train_dual.experiments.small_codebook_run'):
    plan=json.loads((root/'plan.json').read_text());children=[];started=time.monotonic()
    try:
        for gpu,lane in zip((2,3,4,5),plan['lanes']):
            env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),CUDA_DEVICE_ORDER='PCI_BUS_ID',PYTHONPATH=str(root/'source_snapshot'),
                     PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4')
            with (root/'logs'/(lane+'.log')).open('ab',buffering=0) as log:
                child=subprocess.Popen([sys.executable,'-u','-m',worker_module,str(root),'--lane',lane],
                    cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
            children.append((lane,child))
        atomic_json(root/'status.json',dict(state='running',children=[dict(lane=l,gpu=g,pid=p.pid) for g,(l,p) in zip((2,3,4,5),children)]))
        while any(p.poll() is None for _,p in children):
            if any(p.poll() not in (None,0) for _,p in children):raise RuntimeError('A small-codebook worker failed')
            if time.monotonic()-started>7200:raise TimeoutError('Two-hour pilot budget exhausted')
            time.sleep(3)
        if any(p.returncode!=0 for _,p in children):raise RuntimeError('Nonzero small-codebook exit')
        atomic_json(root/'comparison.json',dict(rows={lane:json.loads((root/lane/'comparison.json').read_text()) for lane in plan['lanes']},
                    seed=42,no_semantic_constraints=True,independent_test_evaluated=False))
        atomic_json(root/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started))
    except BaseException as error:
        atomic_json(root/'status.json',dict(state='failed',error=repr(error)));raise
    finally:
        for _,p in children:
            if p.poll() is None:
                try:os.killpg(p.pid,signal.SIGTERM)
                except ProcessLookupError:pass
        for _,p in children:
            try:p.wait(timeout=10)
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--lane')
    a=p.parse_args()
    if a.prepare:prepare(a.root)
    elif a.lane:worker(a.root,a.lane)
    else:campaign(a.root)
