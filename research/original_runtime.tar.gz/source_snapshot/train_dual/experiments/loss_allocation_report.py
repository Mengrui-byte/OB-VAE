"""Live fit/development diagnostics for the quantity-allocation factorial."""
import argparse
import json
from pathlib import Path
import threading

from train_dual.experiments.full_window_report import PAGE, monitor
from train_dual.experiments.long_worker import atomic_json


def read(path):
    try:
        return json.loads(path.read_text())
    except (OSError, ValueError):
        return None


def auxiliary(root):
    plan = read(root / 'plan.json')
    rows = {}
    for lane, label in plan['labels'].items():
        folder = root / lane
        seen, audits = {}, {}
        for step in [0, *plan['checkpoints']]:
            path = folder / ('initial_seen_evaluation.json' if step == 0 else f'step{step}_seen_evaluation.json')
            value = read(path)
            if value:
                seen[str(step)] = value['result']
            value = read(folder / f'step{step}_route_audit.json')
            if value:
                audits[str(step)] = value
        history = []
        path = folder / 'progress.jsonl'
        if path.exists():
            for line in path.read_text().splitlines():
                try:
                    history.append(json.loads(line))
                except ValueError:
                    pass
        rows[lane] = dict(label=label, seen=seen, audits=audits,
                          recorded_clip_fraction=(sum(v['gradient_norm'] > 1 for v in history)/len(history)) if history else None)
    result = dict(rows=rows, status=read(root/'status.json'), endpoint=plan['steps'])
    atomic_json(root / 'public/allocation_diagnostics.json', result)
    end = str(plan['steps'])
    if all(end in value['seen'] for value in rows.values()):
        baseline = rows['baseline']['seen'][end]
        base_dev = read(root / f'baseline/step{end}_evaluation.json')['result']
        summary = {}
        for lane, value in rows.items():
            train = value['seen'][end]
            dev = read(root / lane / f'step{end}_evaluation.json')['result']
            ratio = train['metrics']['quantity_btc']['rmse'] / baseline['metrics']['quantity_btc']['rmse']
            corr = train['metrics']['temporal_log_quantity_1_minutes']['correlation']
            price_ratio = dev['metrics']['price_usdt']['rmse'] / base_dev['metrics']['price_usdt']['rmse']
            summary[lane] = dict(train_quantity_rmse_ratio_to_control=ratio,
                                 train_quantity_change_correlation=corr,
                                 development_price_rmse_ratio_to_control=price_ratio,
                                 meaningful_fit_target_met=ratio <= .90 and corr is not None and corr >= .10,
                                 price_guard_met=price_ratio <= 1.10,
                                 train=train, development=dev)
        atomic_json(root / 'endpoint_summary.json', dict(
            endpoint=plan['steps'], rows=summary,
            scope='Single seed42;4training windows;16reused development windows. No independent-test inference.'))


def main(root):
    root = root.resolve()
    page = PAGE.replace('256分钟双分支实验', '8192数量损失分配实验').replace(
        '完整256分钟：双分支与整窗矩阵压缩', '8192瓶颈：全局数量×Top16数量权重对照')
    begin, end = page.index('<p>实际输入'), page.index('<p id=status>')
    text = ('<p>完整256分钟、每侧2048档、唯一64×128latent。四组共同起点为上一轮full匹配对照第512步'
            '（此前累计2816次更新），保留相同AdamW动量；相同4个预选训练窗、16个2025Q1开发窗、'
            'seed42、batch1累积4、学习率1e−4、clip1，追加1024步。Z=μ，beta0。</p>'
            '<p>2×2因素：全局原始数量Huber系数1/8；Top16数量Huber系数0.25/0。'
            '价格和Top16价格、log数量、分布KL、总量、梯度路径与最近邻上采样均固定。'
            '小训练集用于拟合诊断，归一化沿用原64训练窗统计；2025Q1反复用于开发，2026和独立测试未参与。</p>'
            '<p>各组训练曲线显示共同基础损失，实际目标另存objective_loss。'
            '同时比较数量幅度、档位精确率/召回和时间变化；价格误差须不超过匹配对照1.10倍。'
            '全局裁剪强度可能随权重变化，不能把梯度范数直接当作Adam参数更新大小。</p>')
    page = page[:begin] + text + page[end:]
    page = page.replace('实际矩阵', '实际唯一latent').replace("'训练损失'", "'共同基础损失'")
    table = ('<h2>同4个训练窗口的拟合诊断</h2><p>这里直接检查训练样本能否拟合；与开发集分开报告。'
             '大单指同帧同侧同档位聚合挂量。</p><table><thead><tr><th>方案</th><th>步数</th>'
             '<th>价格RMSE USDT</th><th>数量RMSE BTC</th><th>分钟数量变化相关</th>'
             '<th>≥10BTC精确率</th><th>≥10BTC召回</th><th>≥100BTC精确率</th><th>≥100BTC召回</th>'
             '</tr></thead><tbody id=fitRows></tbody></table>'
             '<h2>最新梯度与裁剪记录</h2><table><thead><tr><th>方案</th><th>审计步数</th>'
             '<th>Encoder量价cos</th><th>数量/价格梯度范数比</th><th>非有限梯度数</th>'
             '<th>已记录更新中裁剪比例</th></tr></thead><tbody id=auditRows></tbody></table>')
    page = page.replace('<h2>首步实际梯度范数</h2>', table + '<h2>首步实际梯度范数</h2>')
    js = '''<script>(function(){const fmt=(x,n=4)=>Number.isFinite(x)?x.toFixed(n):'—';
async function aux(){let d=await(await fetch('allocation_diagnostics.json?t='+Date.now())).json(),fit=[],audit=[];
for(let v of Object.values(d.rows)){for(let [step,t] of Object.entries(v.seen)){let m=t.metrics,a=t.thresholds['10'],b=t.thresholds['100'];fit.push(row([v.label,step,fmt(m.price_usdt.rmse,2),fmt(m.quantity_btc.rmse),fmt(m.temporal_log_quantity_1_minutes.correlation),fmt(a.precision===null?null:a.precision*100)+'%',fmt(a.recall*100)+'%',fmt(b.precision===null?null:b.precision*100)+'%',fmt(b.recall*100)+'%']))}
let keys=Object.keys(v.audits).sort((a,b)=>+a-+b),s=keys.at(-1),a=v.audits[s],g=a?.groups.encoder;
audit.push(row([v.label,s??'待审计',fmt(g?.cosine),fmt(g?.quantity_to_price_ratio),a?.nonfinite_gradients??'—',fmt(v.recorded_clip_fraction===null?null:v.recorded_clip_fraction*100,1)+'%']))}
document.getElementById('fitRows').replaceChildren(...fit);document.getElementById('auditRows').replaceChildren(...audit)}
aux().catch(console.error);setInterval(()=>aux().catch(console.error),10000)})()</script>'''
    page = page.replace('</html>', js + '</html>')
    (root / 'public').mkdir(exist_ok=True)
    stop = threading.Event()

    def watch():
        while not stop.is_set():
            auxiliary(root)
            stop.wait(10)

    thread = threading.Thread(target=watch, daemon=True)
    thread.start()
    try:
        monitor(root, page)
    finally:
        stop.set()
        thread.join(timeout=2)
        auxiliary(root)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    main(parser.parse_args().root)
