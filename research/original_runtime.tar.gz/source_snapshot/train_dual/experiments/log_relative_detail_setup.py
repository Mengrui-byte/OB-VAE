"""Fit physical-log detail scales on eight existing train windows; no training."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import time

import numpy as np
import torch

from model.losses.local_detail import signed_spatial_detail
from model.losses.quantity_strata import QUANTITY_LOWER_BOUNDS
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.long_worker import atomic_json
from train_dual.util.checkpoint import freeze_sources
from train_dual.util.data import DualNormalizer

EPSILON=1e-4
RADII=(1,2,4,8)


def prepare(goal):
    torch.set_num_threads(2);begin=time.monotonic();source=goal/'round_008_auxiliary'
    assert json.loads((source/'startup_control_audit.json').read_text())['passed']
    root=goal/'log_relative_detail_preparation_20261028';root.mkdir();(root/'data').mkdir();(root/'logs').mkdir()
    for name in ['train_indices.npy','val_indices.npy','seen_indices.npy','unseen_indices.npy','quantity_calibration_indices.npy']:
        os.link(source/name,root/name)
    os.link(source/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    old=json.loads((source/'plan.json').read_text())
    plan={k:old[k] for k in ['train','development','window_size','stride','normalization','input_shape','latent_shape','output_shape','seed']}
    indices=np.load(root/'quantity_calibration_indices.npy');assert len(indices)==8 and set(indices.tolist())<=set(np.load(root/'train_indices.npy').tolist())
    assert plan['input_shape']==[1,256,2,2048,2] and plan['latent_shape']==[1,64,128]
    plan.update(preparation_only=True,source_checkpoint_not_selected=True,epsilon_BTC=EPSILON,radii=RADII,
        transform='u=log(q in physical BTC+1e-4); signed center minus endpoint average, full-neighborhood validity.',
        training_indices=indices.tolist(),minimum_detail_RMS=1e-3,gradient_norm_fraction_per_auxiliary=.25,
        cohort='control / relative only / signed log detail only / both. Two binary factors with explicit combination ablation; no activation, precision or upsampling change.',
        source_policy='Wait for all matched round008 endpoints and review any joint-goal candidate before selecting a common checkpoint. Preserve every inherited objective and coefficient.',
        calibration_policy='Only these8 existing train windows. Fit RMS here; lock each auxiliary coefficient from actual selected-source mu-head gradient norms on GPU later. No development coefficient fitting.',
        original_contract_unchanged=True,neural_forward_calls=0,optimizer_updates=0)
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='fitting_training_only_scales'))
    data=dataset(root,'train');normalizer=DualNormalizer(tick_size=plan['normalization']['tick_size'],price_scale=plan['normalization']['price_scale'])
    counts=np.zeros((len(RADII),6),np.int64);squares=np.zeros_like(counts,dtype=np.float64);digest=hashlib.sha256()
    for n,index in enumerate(indices):
        raw={k:v.unsqueeze(0) for k,v in data[int(index)].items()};assert list(raw['data'].shape)==[1,256,2,2048,2]
        offset=int(data.base.starts[int(index)]);times=data.base.times[offset:offset+256];assert np.all(np.diff(times//60000000)==1)
        digest.update(raw['data'].numpy().tobytes());batch=normalizer.prepare(raw,'cpu');q=batch['volume'];u=torch.log(q+EPSILON)
        for row,radius in enumerate(RADII):
            detail,valid=signed_spatial_detail(u,batch['mask'],radius)
            for i,lower in enumerate(QUANTITY_LOWER_BOUNDS):
                selected=valid&(q>=lower)
                if i<5:selected &= q<QUANTITY_LOWER_BOUNDS[i+1]
                values=detail[selected].double();counts[row,i]+=values.numel();squares[row,i]+=float(values.square().sum())
        atomic_json(root/'progress.json',dict(windows=n+1,total=8,elapsed_seconds=time.monotonic()-begin,neural_forward_calls=0,optimizer_updates=0))
    assert (counts>0).all();scales=np.maximum(np.sqrt(squares/counts),plan['minimum_detail_RMS'])
    atomic_json(root/'detail_calibration.json',dict(state='train_RMS_fit_requires_actual_source_GPU_gradient_calibration',epsilon_BTC=EPSILON,radii=RADII,
        RMS_scales=scales.tolist(),counts=counts.tolist(),quantity_bins_lower_BTC=QUANTITY_LOWER_BOUNDS,quantity_membership_schema=2,
        training_indices=indices.tolist(),selected_raw_values_sha256=digest.hexdigest(),minimum_RMS=plan['minimum_detail_RMS'],
        neural_forward_calls=0,optimizer_updates=0,weight_calibration_locked=False))
    atomic_json(root/'status.json',dict(state='prepared_not_training',neural_forward_calls=0,optimizer_updates=0,elapsed_seconds=time.monotonic()-begin))
    freeze_sources(root/'source_snapshot');print(root.resolve(),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('goal',type=Path);args=parser.parse_args();prepare(args.goal.resolve())
