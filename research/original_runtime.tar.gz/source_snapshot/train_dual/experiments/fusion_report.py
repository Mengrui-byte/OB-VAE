"""Publish completed paired fusion results and independent per-level book lines."""

import argparse
import html
import json
from pathlib import Path

import numpy as np

from train_dual.experiments.book_stem_viewer import build
from train_dual.util.checkpoint import freeze_sources


LABELS = {"control": "原结构＋数量修正", "cross": "全局/局部 cross-attention", "tower_mean": "价量双塔＋均值融合", "tower_cross": "价量双塔＋cross-attention"}


def report(root, previous):
    result = json.loads((root / "comparison.json").read_text())
    plan = json.loads((root / "plan.json").read_text())
    if json.loads((root / "status.json").read_text())["state"] != "complete":
        raise RuntimeError("Only completed paired results can be published")
    folder = root / "report"
    folder.mkdir(exist_ok=False)
    old = np.load(previous / "profiles.npz")
    arrays = {key: old[key] for key in ("truth", "mask", "time", "indices")}
    for variant in LABELS:
        with np.load(root / variant / "profiles.npz") as data:
            assert np.array_equal(data["truth"], arrays["truth"])
            assert np.array_equal(data["mask"], arrays["mask"])
            arrays[variant] = data["prediction"]
    np.savez_compressed(folder / "profiles.npz", **arrays)
    config = [dict(key="truth", label="真实", color="#2563eb")] + [
        dict(key=key, label=label, color=color)
        for (key, label), color in zip(LABELS.items(), ["#ef4444", "#16a34a", "#f59e0b", "#9333ea"])
    ]
    info = dict(result, seed=plan["seed"], common_step=plan["steps"], viewer_variants=config,
                default_model=2, plan=plan, initialization_steps=1200,
                comparison_label="查看 cross-attention 与双塔的训练前后验证指标",
                notes="Single-seed additional 96-step fine-tuning; global/local and two-tower fusion are separate factors")
    (folder / "comparison.json").write_text(json.dumps(info, ensure_ascii=False, indent=2))

    def cells(value):
        m = value["metrics"]
        hundred = value["thresholds"]["100"]
        recall = "—" if hundred["recall"] is None else f"{hundred['recall']:.1%}"
        precision = "—" if hundred["precision"] is None else f"{hundred['precision']:.1%}"
        values = [f"{m['price_usdt']['rmse']:.3f}", f"{m['quantity_btc']['rmse']:.3f}",
                  f"{m['spatial_slope_64_levels_usdt_per_level']['rmse']:.5f}",
                  f"{m['temporal_mid_1_minutes_usdt_per_minute']['rmse']:.3f}",
                  f"{value['tail_log_rmse']:.3f}", precision, recall]
        return "".join(f"<td>{v}</td>" for v in values)

    tables = []
    for phase in ("initial", "final"):
        rows = []
        for key, label in LABELS.items():
            item = result["variants"][key][phase]
            params = item["parameters"] / 1e6
            rows.append(f"<tr><td>{html.escape(label)}</td>{cells(item['result'])}<td>{params:.3f}M</td></tr>")
        tables.append("<div class=scroll><table><tr><th>方案</th><th>价格 RMSE<br>USDT</th><th>数量 RMSE<br>BTC</th><th>64档斜率 RMSE<br>USDT/档</th><th>分钟中间价变化 RMSE<br>USDT/分</th><th>≥100 BTC 对数数量误差</th><th>≥100 BTC 精确率</th><th>≥100 BTC 召回率</th><th>参数量</th></tr>" + "".join(rows) + "</table></div>")
    page = """<!doctype html><meta charset=utf-8><title>Cross-attention 与双塔对照</title><style>body{font:16px system-ui;max-width:1500px;padding:0 20px;margin:30px auto;color:#162235}p{line-height:1.7}table{border-collapse:collapse;text-align:right;width:100%}th,td{padding:10px;border:1px solid #d8dfe9}.scroll{overflow:auto}a{color:#2563eb}pre{padding:20px;background:#f2f5fa;line-height:1.8}</style>
<h1>Cross-attention 统一 latent 与价量双塔：单种子筛选</h1>
<p><a href=../>打开每档一条竖线的挂单对比图</a> · <a href=../previous/>查看上一轮逐档线图</a> · <a href=comparison.json>下载完整配置和指标</a></p>
<p>四组共用上一轮数量修正模型种子42、1200步的权重，分别继续训练96次更新；有效 batch64、学习率3e-5、损失和训练样本顺序相同。所有组只运行种子42。表中指标来自128个固定开发验证窗口。</p>
<pre>共享编码器 → global / local ──cross-attention──→ 统一 U → 价格生成 → 数量生成
价格几何塔 ─→ global / local ┐
数量形态塔 ─→ global / local ┴─均值 / cross-attention─→ 统一 U → 价格生成 → 数量生成</pre>
<p>统一 U 是保留全局槽和局部档位槽的 token 序列。两个解码器从同一个 U 读取生成条件。双塔分别只看价格/价差特征、数量/高通特征；参数独立，各自保留买卖侧与时间交互。</p>
<h2>继续训练96步后的结果</h2>""" + tables[1] + """
<h2>开始本轮训练前的结果</h2>""" + tables[0] + """
<p>共享编码器的融合输出投影零初始化，起点与对照一致。双塔输入通道分离会改变起点，必须结合初始表理解训练后结果；短训练表现较差不能单独证明双塔方向无效。</p>
<p>这些是训练外的开发验证结果。训练使用 UTC [2022-01-01,2025-01-01)，开发验证使用 [2025-01-01,2025-04-01)，两者没有时间重叠。开发期已用于选型，因此不是最终独立测试集。此处评价非因果输入窗口重建，不能据此推断未来预测能力。</p>
<p>≥100 BTC 指同一价位聚合挂单量，精确率和召回率按同一档位匹配。这里只做单种子短训练筛选，没有再次启动多种子或自动扩展长实验。</p>"""
    if plan.get("evaluation_backend"):
        page += "<p>数值复核：以上指标与线图重新使用严格 FP32 计算，关闭 CUDA matmul 和 cuDNN 的 TF32。只重新评估保存权重，没有追加训练；原始后端结果另行保留。</p>"
    (folder / "index.html").write_text(page)
    viewer = root / "stem_report"
    freeze_sources(viewer / "source_snapshot")
    build(folder, viewer)
    (viewer / "previous").symlink_to(Path(json.loads(Path(".local/dual_viewer/current.json").read_text())["directory"]), target_is_directory=True)
    return viewer


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("previous", type=Path)
    args = parser.parse_args()
    print(report(args.root, args.previous), flush=True)
