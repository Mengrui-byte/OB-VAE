"""Live2x2distribution/mass control report."""
import argparse
from pathlib import Path
from train_dual.experiments.full_window_report import PAGE,monitor

def main(root):
 page=PAGE.replace('256分钟双分支实验','8192挂量分布与总量对照').replace('完整256分钟：双分支与整窗矩阵压缩','8192瓶颈：分布形状×总量损失2×2对照')
 begin=page.index('<p>实际输入');end=page.index('<p id=status>',begin)
 text=('<p>四组均为完整256分钟输入、唯一64×128latent、相同最近邻上采样和价格损失。共同AE2048权重＋AdamW动量，seed42、同64个训练窗/16个开发窗、batch1累积4、学习率1e−4，额外512次更新。确定性Z=μ、beta0。当前主实验与梯度容量诊断完成后自动运行。</p>'
 '<p>2×2因素：是否增加同帧同侧挂量归一化分布KL、是否增加log1p总挂量Huber。包括基线、仅KL、仅总量、组合交互对照；两项权重均预设为1。分布限制挂量分配，总量限制幅度，是否改善大单定位仍由同位精确率/召回和动态指标验证。</p>'
 '<p>训练曲线统一显示原基础损失base_loss，各组实际目标objective_loss另存。追加步数不含共同2048步预训练成本。2025Q1已重复用于开发，独立测试与2026未参与。</p>')
 page=page[:begin]+text+page[end:];page=page.replace('实际矩阵','实际唯一latent').replace("'训练损失'","'共同基础损失'")
 monitor(root,page)
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);main(p.parse_args().root)
