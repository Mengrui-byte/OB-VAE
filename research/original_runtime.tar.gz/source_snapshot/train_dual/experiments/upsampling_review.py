"""Evidence-led upsampling review and loss-control protocol in recons/."""
import argparse
import base64
from datetime import datetime
import hashlib
from html import escape
import json
from pathlib import Path
import shutil

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np
from train_dual.util.checkpoint import freeze_sources


def main(study,failed,loss):
 project=Path(__file__).resolve().parents[2];root=project/'recons'/('upsampling_review_'+datetime.now().strftime('%Y%m%d_%H%M%S'));root.mkdir()
 for name in ['spectral_diagnostics.json','spectra.npz','synthetic_probe.json','probe_predictions.npz']:
  shutil.copy2(study/name,root/name)
 shutil.copy2(failed/'synthetic_probe.json',root/'failed_probe_preserved.json')
 diag=json.loads((study/'spectral_diagnostics.json').read_text());probe=json.loads((study/'synthetic_probe.json').read_text());plan=json.loads((loss/'plan.json').read_text())
 colors={'truth':'#243447','old_reference':'#8a949f','ae':'#366590','vae_1e6':'#337c70','vae_1e5':'#b27c33','vae_1e4':'#ab6173'}
 labels={'truth':'真实挂量','old_reference':'旧大latent参考','ae':'确定性AE','vae_1e6':'VAE β=1e−6','vae_1e5':'VAE β=1e−5','vae_1e4':'VAE β=1e−4'}
 font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc';font_manager.fontManager.addfont(font);plt.rcParams.update({'font.family':font_manager.FontProperties(fname=font).get_name(),'axes.unicode_minus':False,'font.size':10})
 fig,axes=plt.subplots(1,2,figsize=(14,5),layout='constrained')
 with np.load(study/'spectra.npz') as d:
  f=d['frequency']
  for ax,tr,title in zip(axes,['raw','log1p'],['原始数量空间功率谱','log1p数量空间功率谱']):
   for k in colors:ax.loglog(f[1:],np.maximum(d[k+'_'+tr][1:],1e-15),color=colors[k],lw=1.25,label=labels[k])
   ax.axvline(1/32,color='#777',ls='--',lw=.8);ax.set_xlabel('空间频率（cycles / 档位）');ax.set_ylabel('去均值、Hann窗校正后的功率');ax.set_title(title);ax.grid(alpha=.15);ax.legend(fontsize=8)
 fig.suptitle(f'完整256分钟模型 · 第{diag["checkpoint_step"]}步 · 3个固定开发窗口',fontsize=14);fig.savefig(root/'rank_spectra.png',dpi=150);plt.close(fig)
 modes=['nearest','linear','transpose','shuffle'];mc=['#366590','#b27c33','#337c70','#ab6173'];ml=['最近邻 + 卷积','线性插值 + 卷积','转置卷积 k4/s2','子像素展开']
 fig,axes=plt.subplots(1,2,figsize=(14,5),layout='constrained')
 with np.load(study/'probe_predictions.npz') as d:
  target=d['truth'][0,0];x=np.arange(400,445);axes[0].vlines(x,0,target[x],color='#243447',lw=1.,label='目标（含单档尖峰）')
  for k,c,l in zip(modes,mc,ml):
   axes[0].plot(x,d[k][0,0,x],color=c,lw=1.3,label=l)
   h=probe['history'][k];axes[1].semilogy([v['step'] for v in h],[v['rmse'] for v in h],marker='o',color=c,label=l)
 axes[0].set_title('同一合成样本 · 一个单档尖峰局部');axes[0].set_xlabel('目标档位');axes[0].set_ylabel('合成幅度');axes[0].legend(fontsize=8)
 axes[1].set_title('固定512更新 · 4个合成训练样本拟合');axes[1].set_xlabel('更新次数');axes[1].set_ylabel('均方根误差');axes[1].legend(fontsize=8)
 for ax in axes:ax.grid(alpha=.18)
 fig.suptitle('空间解码表达能力诊断｜不是256分钟模型重建实验',fontsize=14);fig.savefig(root/'synthetic_capacity.png',dpi=150);plt.close(fig)
 def img(name):return '<img alt="'+name+'" src="data:image/png;base64,'+base64.b64encode((root/name).read_bytes()).decode()+'">'
 spectral_rows='';t=diag['records']['truth']['spectrum']['raw']['high_frequency_rms']
 for k in colors:
  d=diag['records'][k];v=d['spectrum']['raw'];spectral_rows+=f'<tr><td>{labels[k]}</td><td>{v["high_frequency_rms"]:.6f}</td><td>{v["high_frequency_rms"]/t*100:.3f}%</td><td>{v["high_frequency_energy_fraction"]*100:.3f}%</td><td>{d["within_block_rms"]["16"]:.6f}</td></tr>'
 probe_rows=''
 for k,l in zip(modes,ml):
  d=probe['records'][k];probe_rows+=f'<tr><td>{l}</td><td>{d["parameters"]:,}</td><td>{d["rmse"]:.6f}</td><td>{d["peak_amplitude_ratio"]*100:.2f}%</td><td>{d["elapsed_seconds"]:.1f}s</td></tr>'
 sources=[('Distill 2016','Deconvolution and Checkerboard Artifacts','https://distill.pub/2016/deconv-checkerboard/','解释转置卷积的重叠不均与棋盘格，提出resize-convolution作为替代。它支持保留最近邻作基线，不支持“最近邻必然损失所有尖峰”。'),
 ('NeurIPS 2021','On the Frequency Bias of Generative Models','https://proceedings.neurips.cc/paper/2021/hash/96bf57c6ff19504ff145e2a32991ea96-Abstract.html','独立生成器重建实验发现上采样算子改变频率学习偏置；最近邻倾向先学低频，但最终可以拟合高频。此结论支持检验学习速度，而不是宣称硬性无法表达。'),
 ('CVPR 2016','Efficient Sub-Pixel Convolutional Neural Network','https://www.cv-foundation.org/openaccess/content_cvpr_2016/papers/Shi_Real-Time_Single_Image_CVPR_2016_paper.pdf','在低分辨率特征上学习多个输出相位，再重排为高分辨率。迁移到一维时，将[B,2C,K]重排成[B,C,2K]，使两个子档位拥有不同通道。'),
 ('CVPR 2020','Watch your Up-Convolution','https://arxiv.org/abs/2003.01826','讨论生成模型的频谱失配并引入频谱正则。对订单簿可以借鉴频段诊断，但只匹配幅度谱不能确定大单落在哪一档。'),
 ('ICCV 2019','CARAFE','https://arxiv.org/abs/1905.02188','由内容预测重组核，动态聚合邻域特征。可以研究由Z解码特征生成核；不能把原始订单簿或高分辨率Encoder特征偷偷作为额外生成条件。'),
 ('ICCV 2023','DySample','https://arxiv.org/abs/2308.15085','通过可学习采样点进行上采样，强调轻量实现，并指出部分引导式方法依赖额外高分辨率特征。作为后续候选；重采样仍需配合特征和输出头恢复幅度。'),
 ('CVPR 2021','LIIF','https://arxiv.org/abs/2012.09161','局部特征与查询坐标共同预测输出。对本项目可研究由Z生成的局部特征加档位/预测价格坐标的查询头，维持唯一8192瓶颈。')]
 literature=''.join(f'<tr><td>{year}</td><td><a href="{url}">{title}</a></td><td>{text}</td></tr>' for year,title,url,text in sources)
 css='''body{margin:0;background:#f5f6f8;color:#243447;font:15px/1.85 system-ui,"Noto Sans CJK SC",sans-serif}main{max-width:1320px;margin:30px auto;padding:40px 50px;background:#fff;border:1px solid #e0e5eb}h1{font-size:30px}h2{font-size:22px;margin-top:35px}h3{font-size:17px}a{color:#366590;text-underline-offset:4px}.eyebrow{color:#697586;letter-spacing:.15em;font-size:12px}table{border-collapse:collapse;width:100%;font-size:13px}th,td{text-align:left;border-bottom:1px solid #dce3eb;padding:10px;vertical-align:top}th{background:#f6f8fb;border-top:1px solid #aeb9c7}img{width:100%;height:auto}.note{padding:15px 20px;background:#f5f8fb;border-left:3px solid #7e9ab4;margin:18px 0}.warn{background:#fbf7ef;border-color:#c09b5e}.formula{font:19px/1.9 Georgia,serif;text-align:center;padding:18px;background:#fafbfd;overflow:auto}.grid{display:grid;grid-template-columns:1fr 1fr;gap:25px}code{font:12px monospace;background:#edf2f7;padding:2px 5px}li{margin:8px 0}.wrap{overflow:auto}.small{font-size:12px;color:#697586}@media(max-width:700px){main{margin:8px;padding:22px 16px}.grid{grid-template-columns:1fr}h1{font-size:25px}}@media print{body{background:white}main{margin:0;border:0;padding:0}.note,figure,table{break-inside:avoid}}'''
 url=f'http://172.16.30.28:8875/recons/{loss.name}/public/'
 loss_design=f'''<h2>下一轮：损失的严格单因素实验</h2><p>结果目录：<code>recons/{loss.name}</code>；<a href="{url}">查看队列与实时进度</a>。等待当前四组8192主实验完成后，使用GPU2–5执行；当前训练保持原配置。</p><div class="formula">L₀ = L<sub>price</sub> + L<sub>q,Huber</sub> + L<sub>q,log</sub> + 0.25 L<sub>pair</sub></div><div class="wrap"><table><thead><tr><th>组</th><th>唯一改动</th><th>要检验的问题</th></tr></thead><tbody><tr><td>A · baseline</td><td>原损失L₀</td><td>匹配的训练时长对照</td></tr><tr><td>B · quantity_mse</td><td>仅将全位置和Top16的数量Huber替换成½e²；价格与log数量不变</td><td>大误差进入Huber线性区后，梯度饱和是否限制尖峰幅度</td></tr><tr><td>C · spatial_difference</td><td>L₀ + L<sub>spatial</sub>，权重1</td><td>是否缺少档位之间尖峰边缘的直接约束</td></tr><tr><td>D · temporal_difference</td><td>L₀ + L<sub>temporal</sub>，权重1</td><td>是否缺少挂量出现/消失的时间约束</td></tr></tbody></table></div><div class="formula">L<sub>spatial</sub> = mean<sub>r∈{{1,4,16}}</sub> mean<sub>valid</sub> ρ[(Δ<sub>rank,r</sub>q̂ − Δ<sub>rank,r</sub>q)/q₀]<br>L<sub>temporal</sub> = mean<sub>k∈{{1,4,16}}</sub> mean<sub>valid</sub> ρ[(Δ<sub>time,k</sub>q̂ − Δ<sub>time,k</sub>q)/q₀]</div><p>这里Δ表示两位置/两时刻的差值，不额外除以跨度；每个跨度先按有效交集平均，再对三个跨度平均。时间差分比较同一档位序号，未声称跟踪同一笔订单。</p><div class="note"><strong>四组固定：</strong>同一AE512权重和AdamW动量、相同8192架构、最近邻上采样、价格损失、归一化、seed42、64训练窗/16开发窗、batch1累积4、学习率1e−4、额外1024更新与精度。四组均Z=μ、β=0；只改变数量目标。训练图比较共同基础损失base_loss，实际objective_loss另报，避免把不同定义的总损失直接比较。</div><p>判据预先固定为数量RMSE、分钟log数量变化相关、大单10/100BTC召回，并以价格RMSE不超过匹配基线1.10倍作为价格保持条件。保留全部32/128/512/1024追加步检查点，报告收益和代价；组合损失需要下一轮交叉消融。</p>'''
 html=f'''<!doctype html><html lang=zh-CN><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>上采样研究与损失控制变量实验</title><style>{css}</style><main><div class=eyebrow>RECONSTRUCTION STUDY · 26 OCT 2026</div><h1>上采样会限制订单簿尖峰恢复吗？</h1><p><strong>目前结论：存在低频学习偏置的合理嫌疑，但不能归因为最近邻上采样的硬性表达限制。</strong>实际输出缺少高频，旧参考与校准后的合成拟合都表明最近邻卷积能够生成尖峰。下一步先独立检验损失，再进行完整模型的上采样替换。</p><p><a href="../">全部recons实验</a> · <a href="/unified_8192.html">当前完整结构</a> · <a href="{url}">损失控制实验</a></p><h2>1. 真实输出：高频细节确实没有恢复</h2><p>固定第{diag['checkpoint_step']}步、三个预先选定的2025Q1开发窗口，每窗完整256帧、双侧2048档。对每帧每侧挂量去均值并加Hann窗，按窗能量校正后分析空间频谱。高频定义为f&gt;1/32 cycles/档，即周期短于32档。该阈值是诊断尺度，不代表网络存在硬截止。</p><div class=wrap><table><thead><tr><th>模型</th><th>高频RMS（BTC）</th><th>相对真实高频幅度</th><th>自身总波动中的高频能量</th><th>16档块内起伏RMS</th></tr></thead><tbody>{spectral_rows}</tbody></table></div>{img('rank_spectra.png')}<div class=note>这是输出端的描述性证据，不区分信息在Encoder、8192瓶颈或Decoder哪一处没有被利用。旧参考也使用最近邻+卷积，但latent更大、每级残差块更多，还有数量细化头，不能把它当作等容量单因素消融。</div><h2>2. 原始论文提供了什么证据？</h2><div class=wrap><table><thead><tr><th>来源</th><th>原始论文</th><th>发现及与本任务的联系</th></tr></thead><tbody>{literature}</tbody></table></div><p>上述论文主要研究图像，迁移到一维订单簿的有效性仍需本项目实验。不能从“图像方法更锐利”直接推导它会提高订单簿大单的档位、幅度或时间准确率。</p><h2>3. 小型表达能力对照：最近邻可以生成单档尖峰</h2><p>CPU、seed42、4个固定合成训练样本、相同粗特征[4,32,128]、4级×2展开、512次Adam更新、相同MSE和Softplus输出。没有Encoder、没有时间轴、没有8192窗口压缩。这是空间解码的记忆拟合，不能当作完整模型的样本外成绩。</p><div class=wrap><table><thead><tr><th>算子</th><th>参数数</th><th>训练RMSE</th><th>峰位幅度比</th><th>CPU耗时</th></tr></thead><tbody>{probe_rows}</tbody></table></div>{img('synthetic_capacity.png')}<div class=note><strong>控制解释：</strong>最近邻与线性插值组参数形状完全一致，同seed产生相同初始权重，严格只改变插值规则。转置和子像素组固定宽度、训练条件相同，但算子引起参数数及初始化抽样顺序差异，列为探索性比较，不据此宣称某种算子在完整模型更优。峰位幅度比接近100%只说明拟合的峰高，不单独证明背景和定位质量，需同时看误差与局部图。</div><div class="note warn"><strong>失败记录也保留：</strong>首次未校准Softplus尺度、步长较大的对照中，四种算子都在32步前塌成全零输出。该次结果不能用于比较表达能力。校准输出偏置、使用生产代码的LayerNorm残差并统一降低步长后，所有方法重跑。原始失败目录为<code>{failed.name}</code>，其摘要已保存为failed_probe_preserved.json。</div><h2>4. 完整模型上采样实验的控制方案</h2><p>固定同一8192瓶颈、相同Encoder与价格Decoder、数量损失、训练数据和更新预算；只替换数量Decoder的展开算子，先比较nearest+conv、子像素和k4/s2转置卷积，并报告参数量/吞吐差异。共享模块从同一权重复制，新增算子使用固定seed42初始化。不能接入原始高分辨率Encoder特征绕开唯一瓶颈。</p><p>分两层判断：固定训练Z的decoder-only拟合用于排查解码器能否利用已有表示；随后必须做完整模型端到端匹配训练。前者失败不证明Z无信息，前者成功也不等于整窗模型已成功。频谱幅度之外必须检查同位大单、假峰、时间变化和价格保持。单独的全频复数L2在适当归一化下与空间MSE等价，不能把它包装成新增监督；幅度谱相同也不保证档位一致。</p>{loss_design}<h2>复现资料</h2><p>本页结果与图保存于<code>recons/{root.name}</code>。模型实现仍在model/，训练与指标在train_dual/；全部来源和哈希见provenance.json，完整实现快照见source_snapshot/。本页图片已内嵌，可离线查看。</p><p class=small>本轮只用seed42，不报告跨种子方差。2025Q1为已反复使用的开发期；2026与独立测试期未参与选型。所有结论区分文献、描述性分析、合成探针和完整模型因果消融。</p></main></html>'''
 (root/'index.html').write_text(html)
 (loss/'public/design.html').write_text('<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>损失控制实验设计</title><style>'+css+'</style><main><h1>损失函数的单因素对照设计</h1>'+loss_design+'</main>')
 provenance=dict(calibrated_probe=str(study),failed_probe=str(failed),loss_cohort=str(loss),sources=[dict(year=y,title=t,url=u) for y,t,u,_ in sources],copied_inputs={n:hashlib.sha256((study/n).read_bytes()).hexdigest() for n in ['spectral_diagnostics.json','spectra.npz','synthetic_probe.json','probe_predictions.npz']})
 (root/'provenance.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2));freeze_sources(root/'source_snapshot')
 (project/'recons/index.html').write_text('<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>订单簿重建实验</title><style>'+css+'</style><main><h1>订单簿重建 · 控制变量实验</h1><p>所有新结果保存在recons。历史实验保留原位。seed42、完整256分钟、唯一8192瓶颈。</p><p><a href="'+root.name+'/">上采样研究、频谱诊断与合成对照</a></p><p><a href="'+loss.name+'/public/">损失函数四组匹配对照 · 队列与进度</a></p><p><a href="'+loss.name+'/public/design.html">完整损失实验设计</a></p><p><a href="'+loss.name+'/plan.json">机器可读配置</a></p></main>')
 Path('/tmp/upsampling_review_path').write_text(str(root));print(root,flush=True)

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('study',type=Path);p.add_argument('failed',type=Path);p.add_argument('loss',type=Path);a=p.parse_args();main(a.study,a.failed,a.loss)
