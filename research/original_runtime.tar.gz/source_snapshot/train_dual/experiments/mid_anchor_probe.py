"""Fixed-weight CPU probe of whole-curve relative mid anchoring, on seen train only."""
import argparse
import json
import os
from pathlib import Path
import time

import numpy as np
import torch

from model.decoders.relative_mid import copy_with_mid_anchor
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.price_safe_readout import file_hash
from train_dual.experiments.unified_8192_run import call
from train_dual.util.checkpoint import freeze_sources,load_for_inference
from train_dual.util.phase_training import tensor_digest


def prepare(goal):
    parent=goal/'round_007_quantity_factorial';root=goal/'relative_mid_fixed_weight_probe';root.mkdir();(root/'data').mkdir();(root/'logs').mkdir()
    plan=json.loads((parent/'plan.json').read_text());old={key:plan[key] for key in ['train','development','window_size','stride','input_shape','latent_shape','output_shape']}
    for name in ['source.pt','train_indices.npy']:os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    os.link(parent/'seen/control/step0_profiles.npz',root/'GPU_baseline_seen_profiles.npz')
    with np.load(root/'GPU_baseline_seen_profiles.npz') as z:indices=z['indices'].tolist()
    assert indices==[0,2636,6152] and set(indices)<=set(np.load(root/'train_indices.npy').tolist())
    old.update(source_steps=22528,training_indices=indices,source_sha256=file_hash(root/'source.pt'),
        purpose='Fixed weights and sameZ; compare old first-value override vs subtracting raw first mid. No training, no new learned parameters. Quantities are regenerated using each predicted price geometry.',
        scope='Three already used2022-2024seen training previews only. Not development or independent data. CPU/FP32 diagnostic, not GPU candidate scores.',
        model_forward_calls_planned=3,decode_only_calls_planned=3,optimizer_updates=0,prior_hypothesis='Frame-level common price offset may survive first-frame override; relative anchoring cancels a shared raw-head bias but raw frame0 was not trained as an anchor, so fixed-weight changes can worsen quality.')
    atomic_json(root/'plan.json',old);atomic_json(root/'status.json',dict(state='prepared_CPU_only_not_training'))
    freeze_sources(root/'source_snapshot');print(root.resolve(),flush=True)


def metrics(output,batch,raw,norm):
    mask=batch['mask'].numpy()[0]
    p=norm.inverse_price(output['price_norm'],batch)[0].detach().numpy();q=output['volume'][0].detach().float().numpy()
    truth=raw['data'][0].numpy().astype(np.float64);target_p,target_q=truth[...,0],truth[...,1]
    mid=p[...,0].mean(-1);target_mid=target_p[...,0].mean(-1)
    positive=target_q[mask]>=100;pred=q[mask]>=100;tp=int((positive&pred).sum());fp=int((~positive&pred).sum());fn=int((positive&~pred).sum())
    return dict(price_RMSE_USDT=float(np.sqrt(np.square(p[mask]-target_p[mask]).mean())),
        mid_RMSE_USDT=float(np.sqrt(np.square(mid-target_mid).mean())),
        mid_bias_USDT=float((mid-target_mid).mean()),
        mid_delta_RMSE_USDT=float(np.sqrt(np.square(np.diff(mid)-np.diff(target_mid)).mean())),
        quantity_RMSE_BTC=float(np.sqrt(np.square(q[mask]-target_q[mask]).mean())),
        tp=tp,fp=fp,fn=fn,recall=tp/(tp+fn) if tp+fn else None,precision=tp/(tp+fp) if tp+fp else None)


def run(root):
    torch.set_num_threads(4);begin=time.monotonic();plan=json.loads((root/'plan.json').read_text())
    assert file_hash(root/'source.pt')==plan['source_sha256']
    model,norm=load_for_inference(root/'source.pt','cpu');model.eval().requires_grad_(False)
    before=tensor_digest(model);original=model.price_decoder;model.price_decoder=copy_with_mid_anchor(original,'absolute')
    assert tensor_digest(model)==before
    data=dataset(root,'train');rows=[]
    with np.load(root/'GPU_baseline_seen_profiles.npz') as z:gpu_truth=z['truth'];gpu_pred=z['prediction'];gpu_indices=z['indices']
    atomic_json(root/'status.json',dict(state='running_CPU_probe',pid=os.getpid()))
    for position,index in enumerate(plan['training_indices']):
        start=time.monotonic();raw={k:v.unsqueeze(0) for k,v in data[index].items()};offset=int(data.base.starts[index]);absolute=data.base.times[offset:offset+256]
        assert list(raw['data'].shape)==[1,256,2,2048,2] and bool(np.all(np.diff(absolute//60000000)==1))
        assert np.array_equal(raw['data'][0].numpy(),gpu_truth[position]) and int(gpu_indices[position])==index
        batch=norm.prepare(raw,'cpu');model.price_decoder.anchor_mode='absolute';seen=[]
        hooks=[d.register_forward_pre_hook(lambda module,args:seen.append(args[0])) for d in [model.price_decoder,model.volume_decoder]]
        with torch.inference_mode():base=call(model,batch,False)
        for h in hooks:h.remove()
        assert seen[0] is seen[1] is base['z'] and list(base['z'].shape)==[1,64,128]
        base_values=metrics(base,batch,raw,norm)
        raw_first=float(base['raw_mid_norm'][0,0])*float(batch['price_factor'][0])
        model.price_decoder.anchor_mode='relative';seen=[]
        hooks=[d.register_forward_pre_hook(lambda module,args:seen.append(args[0])) for d in [model.price_decoder,model.volume_decoder]]
        with torch.inference_mode():relative=model.decode(base['z'],batch['mask'],batch['tick_norm'],batch['times'])
        for h in hooks:h.remove()
        assert seen[0] is seen[1] is base['z']
        for key in ['gap_norm','spread_norm']:torch.testing.assert_close(base[key],relative[key],rtol=0,atol=0)
        torch.testing.assert_close(base['price_norm'][:,0],relative['price_norm'][:,0],rtol=0,atol=0)
        assert list(relative['volume'].shape)==[1,256,2,2048]
        rel_values=metrics(relative,batch,raw,norm)
        mask=batch['mask'].numpy()[0];gpu_rmse=float(np.sqrt(np.square(gpu_pred[position,...,0][mask]-gpu_truth[position,...,0][mask]).mean()))
        row=dict(training_index=index,absolute=base_values,relative=rel_values,network_raw_first_mid_USDT=raw_first,
                 CPU_baseline_price_RMSE_minus_saved_GPU=base_values['price_RMSE_USDT']-gpu_rmse,
                 price_delta_USDT=rel_values['price_RMSE_USDT']-base_values['price_RMSE_USDT'],
                 elapsed_seconds=time.monotonic()-start,first_utc=str(np.datetime64(int(absolute[0]),'us')))
        rows.append(row);atomic_json(root/'progress.json',dict(windows=position+1,total=3,rows=rows,optimizer_updates=0,elapsed_seconds=time.monotonic()-begin));print(json.dumps(row),flush=True)
    model.price_decoder=original
    assert tensor_digest(model)==before and file_hash(root/'source.pt')==plan['source_sha256']
    result=dict(state='complete_CPU_diagnostic_only',rows=rows,model_weights_and_source_unchanged=True,
                original_parameter_names_order_and_values_preserved=True,actual_input=[1,256,2,2048,2],
                shared_Z=[1,64,128],output=[1,256,2,2048],new_learned_parameters=0,
                model_forward_calls=3,decode_only_calls=3,encoder_passes=3,optimizer_updates=0,
                source_model_hash_before=before,elapsed_seconds=time.monotonic()-begin,
                scope='Seen training3only; fixed-weight CPU diagnostic, not end-to-end trained candidate or independent confirmation. Raw frame0 was not trained for relative anchoring.')
    atomic_json(root/'result.json',result);atomic_json(root/'status.json',dict(state='complete',pid=os.getpid(),elapsed_seconds=time.monotonic()-begin));print(json.dumps({'state':'complete','windows':3}),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--run',action='store_true');args=p.parse_args();root=args.root.resolve()
    try:
        if args.prepare:prepare(root)
        elif args.run:run(root)
        else:p.error('Need --prepare or --run')
    except BaseException as e:
        if args.run:atomic_json(root/'status.json',dict(state='failed',error=repr(e),pid=os.getpid()))
        raise
