"""Small-data matched decoder readout pilot on idle GPUs2 and4."""
import argparse
import html
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import numpy as np
import torch

from model.autoencoder.shape_mass_vae import ShapeMassOrderBookVAE
from model.losses.recall_guard import RecallGuardBookLoss
from train_dual.experiments import local_hint_run as shared
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.goal_evaluate import assess_file
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read,fmt,STYLE
from train_dual.experiments.recall_goal_run import record
from train_dual.experiments.region_task_run import gpu_free
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import atomic_save,freeze_sources,load_for_inference
from train_dual.util.hint_training import restore_shape_mass_adam
from train_dual.util.phase_training import tensor_digest


LABELS={'control':'原数量读出，价格冻结','quantity':'数量形状＋总量修正，价格冻结','price':'原数量读出＋价格独立微调','both':'数量修正＋价格独立微调'}


def objective(root,lane):
    plan=read(root/'plan.json');cal=read(root/'calibration.json')
    return RecallGuardBookLoss(plan['normalization']['quantity_scale'],mode='shape_mass',use_hint=False,use_tail=False,protect_mid=True,mid_weight=cal['mid_weight'],mid_delta_weight=plan['lanes'][lane].get('mid_delta_weight',1.),add_wasserstein=False,add_multiscale=False,**plan['objective']).to('cuda:0')


def render(root):
    plan=read(root/'plan.json');status=read(root/'status.json',{})
    parts=[f'<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="30"><title>冻结Encoder读出诊断</title><style>{STYLE}</style><main><h1>冻结Encoder：数量修正 × 价格独立微调</h1>',
        f'<div class="note">{html.escape(status.get("state","prepared"))}。这是小数据机制筛选，不是完整1024窗主线实验。GPU2、4各串行两组；GPU3、5的主训练继续。</div>',
        '<p>共同起点为已完成的augmentation/8192。所有组冻结同一个已训练Encoder、保留唯一8192神经Z，数量Decoder均继续训练；只改变是否启用546参数形状/总量头，以及价格Decoder冻结或独立训练。四组均阻断数量损失经预测价格几何回传到价格分支，前向预测值不因此改变；数量条件始终来自预测价格。相同32个训练窗、样本顺序、Adam状态、无在线增强/无教师，mid权重只用训练8窗校准。512步、每组最多10分钟，若预算截断如实报告。</p>',
        '<table><tr><th>组</th><th>进度</th><th>检查点</th><th>100BTC召回</th><th>精确率</th><th>价格RMSE</th><th>分钟mid变化RMSE</th><th>开发门槛</th><th>图</th></tr>']
    for lane,label in LABELS.items():
        progress=read(root/lane/'progress.json',{})
        files=sorted((root/lane).glob('step*_development.json'),key=lambda p:int(p.name.split('_')[0][4:]))
        for f in files:
            step=int(f.name.split('_')[0][4:]);v=assess_file(f,root.parent/'reference_evaluation.json');link=f'{lane}/step{step}_preview.html'
            vals=[label,f'{progress.get("step",0)}/512',step,fmt(v['recall100']),fmt(v['precision100']),fmt(v['price_rmse']),fmt(v['mid_delta_rmse']),v['pass']]
            parts.append('<tr>'+''.join(f'<td>{html.escape(str(x))}</td>' for x in vals)+(f'<td><a href="{link}">完整中间价＋挂量线</a></td>' if (root/link).exists() else '<td>—</td>')+'</tr>')
    parts.append('</table><p>16个2025Q1开发窗已反复使用。seen8是预训练学生已见窗口，只有部分参与当前32窗微调；unseen32排除原1024训练索引。主比较只用四组共同完成的声明检查点，不能把不等更新预算说成匹配终点。本试验不使用Q2，不自动声明目标完成。</p><p><a href="plan.json">配置</a> · <a href="calibration.json">训练校准</a> · <a href="startup_control_audit.json">初始对照核验</a> · <a href="design.md">设计</a> · <a href="../">研究目标</a></p></main>')
    temp=root/'report.tmp';temp.write_text(''.join(parts));temp.replace(root/'index.html')


def prepare(goal):
    torch.set_num_threads(2);parent=goal.parent/read(goal/'contract.json')['predecessor'];root=goal/'decoder_readout_pilot';root.mkdir()
    for name in ['data','logs','seen','unseen',*LABELS]:(root/name).mkdir()
    for split in ['seen','unseen']:
        for lane in LABELS:(root/split/lane).mkdir()
    for name in ['val_indices.npy','seen_indices.npy','unseen_indices.npy','plotly.min.js','teacher.pt']:
        os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    source=parent/'augmentation/step8192.pt';payload=torch.load(source,map_location='cpu',weights_only=False)
    train=np.load(parent/'train_indices.npy');positions=np.unique(np.linspace(0,len(train)-1,32,dtype=int));np.save(root/'train_indices.npy',train[positions]);np.save(root/'calibration_indices.npy',train[positions[np.unique(np.linspace(0,31,8,dtype=int))]])
    # New32-window fine-tuning population: remap per-window exposure accounting.
    payload['training_data']=dict(payload['training_data'],exposure_counts=payload['training_data']['exposure_counts'][positions].copy(),windows=32,source_index_mapping=positions.tolist())
    atomic_save(payload,root/'source.pt')
    plan=dict(read(parent/'plan.json'));plan.update(experiment='FrozenEncoderdecoderreadoutpilot2x2',labels=LABELS,
        lanes={lane:dict(hint=False,augmentation=False,use_shape=lane in ['quantity','both'],use_mass=lane in ['quantity','both'],frozen_modules=['encoder']+([] if lane in ['price','both'] else ['price_decoder'])) for lane in LABELS},
        steps=512,checkpoints=[128,256,512],max_seconds=600,source=str(source),source_steps=payload['source_steps']+payload['step'],fit_windows=32,
        loss_variant='readout_mid_guard',sequences=[[2,['control','price']],[4,['quantity','both']]],checkpoint_extras={},mid_weight_pending=True,
        preview_descriptions={lane:'完整256分钟、唯一8192神经Z。当前只用32训练窗微调Decoder，Encoder冻结。16个2025Q1开发窗已用于研究，不是最终独立测试。' for lane in LABELS},
        budget='Fixed512updatesperarm,batch1accum4,10mintrainingceiling; checkpoints128/256/512. SameoriginalAdam+RNG,new32-windowpopulationatanewepochboundary,accountingremappedtoactualindices. Onlycommoncompleteddeclaredcheckpointsarematchedcomparisons.',
        controls='All4QuantityDecoders train; Encoderfrozen;pricegeometrydetachedinall4;all546newheads existandzero. Quantityheadactivation x PriceDecodertrainability. Samedata/loss/midweight/Adam/RNG/seed42,augmentationoff/teacherabsent. Notasinglefactorcomparisonagainstprevious1024-windowmaintraining.')
    for lane in LABELS:
        enabled=lane in ['quantity','both'];cfg=dict(plan['local_hint_config'],use_shape=enabled,use_mass=enabled,detach_price_geometry=True)
        model=ShapeMassOrderBookVAE(**cfg,**plan['model_config']);missing,extra=model.load_state_dict(payload['model'],strict=False)
        assert missing==['shape_head.weight','mass_head.weight','mass_head.bias'] and not extra
        sha=tensor_digest(model)
        if lane=='control':plan['initial_model_sha256']=sha
        else:assert sha==plan['initial_model_sha256']
        restore_shape_mass_adam(model,payload['optimizer'],plan['original_parameter_names'])
        value=dict(format_version=1,model=model.state_dict(),unified_vae_config=plan['model_config'],shape_mass_config=cfg,config=payload['config'],step=0)
        atomic_save(value,root/lane/'initial.pt')
        if lane=='control':atomic_save(value,root/'initial.pt')
        plan['checkpoint_extras'][lane]=dict(shape_mass_config=cfg)
    atomic_json(root/'plan.json',plan);atomic_json(root/'calibration.json',dict(read(parent/'calibration.json'),mid_weight=1.))
    for split in ['seen','unseen']:
        atomic_json(root/split/'plan.json',dict(plan,preview_descriptions={lane:'训练年代诊断：seen8为预训练1024窗已见，当前微调仅32窗；unseen32排除原1024训练索引。不是最终独立测试。' for lane in LABELS}));os.link(root/'plotly.min.js',root/split/'plotly.min.js')
    (root/'design.md').write_text('已完成augmentation/8192的输入响应诊断发现，在4个student-unseen窗，最大大单移位目的响应中位数0.81、加倍响应0.64；这是少量已知输入干预，不是总体成绩。冻结当前已改善的Z，检验数量乘性读出和价格分支独立学习。所有四组阻断数量损失的价格几何梯度，前向值不变，直接价格+mid监督仍正常回传。此训练日程因素包含价格参数解冻，不能声称仅单独测了MSE。完整主线两轮实验仍按既定顺序运行。\n32窗从原1024训练索引中均匀预选，未按目标表现筛选。保存实际原始输入/latent形状、同Z、仅Z解码、参数/冻结哈希/梯度核验、共同检查点；新来源不是重设原参考，仍对74.704价格和20.0369分钟mid门槛判定。\n')
    atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot');render(root)
    project=Path(__file__).resolve().parents[2];remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 CUDA_DEVICE_ORDER=PCI_BUS_ID OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.decoder_readout_pilot "{remote}"\n')
    print(root,flush=True)


def calibrate(root):
    torch.set_num_threads(4);strict_precision();model,norm=load_for_inference(root/'price/initial.pt','cuda:0');model.train();model.encoder.requires_grad_(False).eval()
    loss=objective(root,'price');params=list(model.price_decoder.mid_spread[-1].parameters());data=dataset(root,'train');squares={k:[] for k in ['pre_guard_loss','mid_protection']}
    for index in np.load(root/'calibration_indices.npy'):
        b=norm.prepare({k:v.unsqueeze(0) for k,v in data[int(index)].items()},'cuda:0')
        with torch.autocast('cuda',dtype=torch.bfloat16):out=call(model,b,False)
        values=loss(out,b)
        for key in squares:
            grads=torch.autograd.grad(values[key],params,retain_graph=key!='mid_protection');squares[key].append(sum(float(g.float().square().sum()) for g in grads))
    norms={k:math.sqrt(float(np.mean(v))) for k,v in squares.items()}
    if any(not math.isfinite(v) or v<=0 for v in norms.values()):raise ValueError(f'Invalidtraininggradients:{norms}')
    cal=read(root/'calibration.json');cal.update(mid_weight=norms['pre_guard_loss']/norms['mid_protection'],mid_gradient_norms=norms,mid_scope='Fixed8trainingwindows,PriceDecodermidheadgradientRMSratio1.0,nooptimizerupdates')
    atomic_json(root/'calibration.json',cal)


def campaign(root):
    plan=read(root/'plan.json');children=[];started=time.monotonic();audited=False
    def spawn(gpu,args,role):
        env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),PYTHONPATH=str(root/'source_snapshot'))
        with (root/'logs'/f'{role}.log').open('ab',buffering=0) as log:
            p=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.decoder_readout_pilot',str(root),*args],cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        children.append(p);return p
    try:
        if any(gpu_free().get(g,0)<47000 for g in [2,4]):raise RuntimeError('Need idle GPUs2and4; no displacement')
        p=spawn(2,['--calibrate'],'calibrate');p.wait(timeout=180)
        if p.returncode:raise RuntimeError('Calibration failed')
        children=[]
        for gpu,lanes in plan['sequences']:spawn(gpu,['--sequence',*lanes],f'gpu{gpu}')
        atomic_json(root/'status.json',dict(state='running',pids=[p.pid for p in children]))
        while any(p.poll() is None for p in children):
            if time.monotonic()-started>1800:raise TimeoutError('30minute wholepilotceiling')
            if any(p.poll() not in [None,0] for p in children):raise RuntimeError('Owned pilot worker failed')
            if not audited:
                first=[read(root/lane/'step1_data_audit.json') for lane in LABELS]
                if all(first):
                    assert all(row['training_indices']==first[0]['training_indices'] and row['losses']['loss']==first[0]['losses']['loss'] for row in first)
                    atomic_json(root/'startup_control_audit.json',dict(passed=True,same_first_inputs_losses=True));audited=True
            render(root);time.sleep(10)
        if any(p.returncode for p in children):raise RuntimeError('Pilot failed')
        common=set.intersection(*[{int(p.stem[4:]) for p in (root/lane).glob('step*.pt') if int(p.stem[4:]) in plan['checkpoints']} for lane in LABELS])
        atomic_json(root/'status.json',dict(state='complete',common_declared_checkpoints=sorted(common),actual_steps={lane:read(root/lane/'status.json')['step'] for lane in LABELS},elapsed_seconds=time.monotonic()-started));render(root)
        record(root.parent,'decoder_readout_pilot_complete',wave=root.name,next='Inspectsamebudgetcommonendpoint;donotreplacefullmaincohortorassumeindependentconfirmation.')
    finally:
        for p in children:
            if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--calibrate',action='store_true');p.add_argument('--sequence',nargs=2,choices=list(LABELS));args=p.parse_args();root=args.root.resolve()
    def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        if args.prepare:prepare(root)
        elif args.calibrate:calibrate(root)
        elif args.sequence:
            for lane in args.sequence:shared.worker(root,lane,objective_factory=objective,optimizer_factory=restore_shape_mass_adam);torch.cuda.empty_cache()
        else:campaign(root)
    except BaseException as error:
        atomic_json(root/'status.json',dict(state='failed',error=repr(error)));raise
