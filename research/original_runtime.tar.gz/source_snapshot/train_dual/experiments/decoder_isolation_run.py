"""Fixed-Encoder full-decoder controls and fixed-Decoder free-latent diagnosis."""
import argparse
from datetime import datetime
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import numpy as np
import torch
from torch.utils.data import DataLoader

from model.decoders.query_volume import QueryVolumeDecoder
from model.decoders.unified_book import VolumeDecoder
from model.losses.probability_book import ProbabilityBookLoss
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.local_quant_reconstruction import CacheWindows
from train_dual.experiments.long_worker import atomic_json,evaluate
from train_dual.experiments.phase_detail_report import preview
from train_dual.experiments.probability_eval import evaluate_probability
from train_dual.experiments.unified_8192_run import call,write_profiles
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import atomic_save,freeze_sources,load_for_inference,seed_everything,source_hashes
from train_dual.util.dynamics import DynamicsMetrics
from train_dual.util.phase_training import tensor_digest
from train_dual.util.resume_data import boundary_loader

LABELS={'original_warm':'原Decoder·预训练参考','original_fresh':'原Decoder·重新初始化','query_fresh':'非线性查询Decoder·重新初始化'}


def read(path,default=None):return json.loads(path.read_text()) if path.exists() else default


def prepare(parent):
    parent=parent.resolve();project=Path(__file__).resolve().parents[2]
    root=project/'recons'/('decoder_isolation_'+datetime.now().strftime('%Y%m%d_%H%M%S'));root.mkdir()
    for name in ['data','logs',*LABELS,'latent_fit']:(root/name).mkdir()
    for name in ['initial.pt','initial_expected.json','train_indices.npy','val_indices.npy','seen_indices.npy','plotly.min.js']:
        os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    old=read(parent/'plan.json')
    plan={key:old[key] for key in ['train','development','independent_test_untouched','normalization','model_config','objective','window_size','stride','input_shape','latent_shape','output_shape','fit_windows','seen_windows','evaluation_windows','batch_size','accumulation','steps','checkpoints','max_seconds','lr','weight_decay','clip_grad','beta','sample']}
    indices=np.load(root/'train_indices.npy');chosen=indices[np.unique(np.linspace(0,len(indices)-1,4,dtype=int))];np.save(root/'latent_fit_indices.npy',chosen)
    plan.update(parent=str(parent),experiment='FixedZ full decoder comparison plus fixedDecoder latent fitting',seed=42,labels=LABELS,
        lanes={k:dict(kind='query' if k=='query_fresh' else 'original',fresh=k!='original_warm') for k in LABELS},
        diagnostic_labels={'latent_fit':'固定Decoder·直接优化Z（训练拟合诊断）'},
        preview_descriptions={'latent_fit':'这4个训练窗口的目标已参与直接优化Z；展示的是固定Decoder的拟合诊断，不是Encoder正常输出，也不是样本外结果。'},
        freeze=['encoder','price_decoder'],inline_evaluation=True,
        source_checkpoint=old['source_checkpoint'],query_config=dict(frame_hidden=1408),
        parameter_counts=dict(original=2804769,query=2787969,relative_difference_percent=-.598979809032401),
        gpu_workers=[[2,'original_warm'],[3,'original_fresh'],[4,'query_fresh'],[5,'latent_fit']],
        precision='Decoder training BF16 neural/FP32 loss; all evaluation FP32. Direct latent optimization uses fullFP32 to avoid BF16 obscuring smallZ updates; TF32off throughout.',
        initialization='All use identical frozen sourceEncoder andPriceDecoder. Matched fresh pair starts seed42 with identical temporal/position/geometry parameters, zero output weights andsame training-only meanquantity bias; freshAdam. Warm original retains sourceQuantityDecoder andoriginalAdam as extra historical reference, notmatched fresh-init control.',
        decoder_contract='Fresh original vs fresh query is primary architecture comparison: samefixedZ,loss,indices/order,seed42,2048updates,effectivebatch4,AdamW1e-4,clip1. Query count is0.60%smaller, notlarger. No old spatial feature orEncoder bypass inquery. Compare against warmreference beforeclaiming useful gain.',
        primary='Fixed2048endpoint quantityRMSE, actual10/100BTCprecision/recall/FP,dynamics on16development+8seen. Retain checkpoints andprice metrics. Query must improve againstfresh original ANDnot merely beat a degradedfresh baseline relative towarm original.',
        latent_diagnostic=dict(steps=1024,checkpoints=[32,128,512,1024],indices_file='latent_fit_indices.npy',training_indices=chosen.tolist(),
            lr=.05,clip_grad=1.,precision='fp32',initialization='Source Encoder posterior means, no random restarts',
            objective='Same original shape_mass price+quantity+Top16+mass objective, beta0; noZpenalty. Only4*8192 freeZscalars receiveupdates; ALL modelparameters/buffers fixed.',
            price_guard_ratio=1.10,
            interpretation='Training-target-assisted expressibility diagnosis, not production/OOS inference. Report eachwindow andpooled priceguard plusZnorm/drift. Improvement withhuge off-manifoldZ orprice degradation isnot a successful full-book reconstruction. Failure tofit isnot proof of structural impossibility.'),
        selection='seed42only; reused2025Q1 development fordecoder controls;2025Q2 and2026 untouched. DirectZ diagnostic usesonly4predeclaredtrainingwindows.',
        authorization='User explicitly requested both decoder-isolation experiments. Three2048update decoder lanes plusone1024cycle four-window latent-fit lane; GPUs2–5;4hour ceiling.',
        report=dict(title='Decoder隔离实验：固定Z读出对照与直接优化Z',scope='上表比较三种固定Encoder/价格Decoder的训练；下方独立展示4个训练窗的直接Z拟合。',
            introduction='主对照为重新初始化的原Decoder与非线性坐标查询Decoder，参数量相差0.60%，初始数量均为同一个训练均值常数。两组采用相同训练预算与新Adam状态；预训练原Decoder保留作额外质量参考。',
            hardware='GPU2原预训练参考、GPU3原Decoder重新初始化、GPU4查询Decoder重新初始化、GPU5固定Decoder直接拟合4个训练窗口的Z。',
            future='直接优化Z使用真实目标，只是可表达性诊断，不能作为正常推理或开发集成绩。原Decoder拟合失败仍可能来自优化不充分；新Decoder未胜出也不能直接证明latent信息丢失。'))
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'))
    atomic_json(root/'data_contract.json',dict(input_shape=plan['input_shape'],latent_shape=plan['latent_shape'],output_shape=plan['output_shape'],train_indices_sha256=hashlib.sha256((root/'train_indices.npy').read_bytes()).hexdigest(),train_indices=indices.tolist(),development_indices=np.load(root/'val_indices.npy').tolist(),seen_indices=np.load(root/'seen_indices.npy').tolist(),latent_fit_indices=chosen.tolist(),latent_selection='Four equally spaced positions ofpreexisting1024train pool; chosenbefore fitting; not chosenbyoutcome',initial_checkpoint_sha256=hashlib.sha256((root/'initial.pt').read_bytes()).hexdigest()))
    (root/'README.md').write_text('# Decoder隔离实验\n\n'+plan['decoder_contract']+'\n\n'+plan['latent_diagnostic']['interpretation']+'\n')
    freeze_sources(root/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'
        f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\n'
        f'cd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.decoder_isolation_run "{remote}"\n')
    from train_dual.experiments.decoder_isolation_report import render
    render(root);Path('/tmp/decoder_isolation_path').write_text(str(root));print(root,flush=True)


def criterion_for(plan):
    return ProbabilityBookLoss(plan['normalization']['quantity_scale'],mode='shape_mass',add_wasserstein=False,add_multiscale=False,**plan['objective'])


def fresh_decoder(config,kind,mean_quantity,query_config):
    with torch.random.fork_rng(devices=[]):
        torch.manual_seed(42)
        original=VolumeDecoder(**config)
        if kind=='query':
            decoder=QueryVolumeDecoder(**query_config,**config)
            for name in ['temporal','position','geometry']:
                getattr(decoder,name).load_state_dict(getattr(original,name).state_dict(),strict=True)
        else:decoder=original
    torch.nn.init.zeros_(decoder.quantity.weight)
    torch.nn.init.constant_(decoder.quantity.bias,math.log(math.expm1(mean_quantity/config['quantity_scale'])))
    return decoder


def assess(root,folder,step,model,norm,dev,seen,original,indices,criterion):
    atomic_json(folder/'evaluation_status.json',dict(state='evaluating',step=step))
    result=evaluate(model,norm,dev,len(dev),'cuda:0')
    atomic_json(folder/f'step{step}_evaluation.json',dict(result=result))
    atomic_json(folder/f'step{step}_seen_evaluation.json',dict(result=evaluate(model,norm,seen,len(seen),'cuda:0')))
    atomic_json(folder/f'step{step}_probability.json',dict(development=evaluate_probability(model,norm,dev,len(dev),'cuda:0',criterion),seen=evaluate_probability(model,norm,seen,len(seen),'cuda:0',criterion)))
    if step==0:
        expected=read(root/'initial_expected.json')['result'];lane=folder.name
        price_delta=abs(result['metrics']['price_usdt']['rmse']-expected['metrics']['price_usdt']['rmse'])
        if price_delta>1e-3:raise RuntimeError('Frozen source price changed')
        if lane=='original_warm' and abs(result['metrics']['quantity_btc']['rmse']-expected['metrics']['quantity_btc']['rmse'])>1e-3:
            raise RuntimeError('Warmreference sourcequantity changed')
        atomic_json(folder/'initial_replay.json',dict(price_rmse_delta_vs_source=price_delta,quantity_rmse=result['metrics']['quantity_btc']['rmse']))
    write_profiles(root,folder,step,model,norm,original,indices);preview(root,folder.name,step)
    atomic_json(folder/'evaluation_status.json',dict(state='complete',step=step))


def decoder_worker(root,lane):
    torch.set_num_threads(4);seed_everything(42);strict_precision();started=time.monotonic();plan=read(root/'plan.json');spec=plan['lanes'][lane]
    folder=root/lane;atomic_json(folder/'status.json',dict(state='initial_validation'))
    resume_step=plan.get('resume_steps',{}).get(lane,0)
    checkpoint=root/lane/f'step{resume_step}.pt' if resume_step else root/'initial.pt'
    initial=torch.load(checkpoint,map_location='cpu',weights_only=False);model,norm=load_for_inference(checkpoint,'cuda:0')
    if resume_step and not initial.get('epoch_boundary'):raise ValueError('Only saved epoch boundaries supported')
    if any(getattr(model,'gradient_route_config',{}).values()):raise ValueError('Require original full routes')
    if spec['fresh'] and not resume_step:
        model.volume_decoder=fresh_decoder(plan['model_config'],spec['kind'],plan['normalization']['mean_quantity'],plan['query_config']).to('cuda:0')
    model.requires_grad_(False);model.volume_decoder.requires_grad_(True);model.eval()
    frozen={name:tensor_digest(getattr(model,name)) for name in plan['freeze']}
    if spec['fresh']:
        opt=torch.optim.AdamW(model.volume_decoder.parameters(),lr=plan['lr'],weight_decay=plan['weight_decay'])
        optimizer_names=[[f'volume_decoder.{n}' for n,_ in model.volume_decoder.named_parameters()]]
        if resume_step:opt.load_state_dict(initial['optimizer'])
    else:
        opt=torch.optim.AdamW(model.parameters(),lr=plan['lr'],weight_decay=plan['weight_decay']);opt.load_state_dict(initial['optimizer'])
        optimizer_names=[[n for n,_ in model.named_parameters()]]
        for group in opt.param_groups:group.update(lr=plan['lr'],weight_decay=plan['weight_decay'])
    source_config=initial['config']
    train_original=dataset(root,'train');dev_original=dataset(root,'val');ti=np.load(root/'train_indices.npy');vi=np.load(root/'val_indices.npy')
    train=CacheWindows(train_original,ti);dev=CacheWindows(dev_original,vi);seen=CacheWindows(train_original,np.load(root/'seen_indices.npy'))
    criterion=criterion_for(plan);hashes=source_hashes();exposures=np.zeros(len(train),dtype=np.int64)
    if resume_step:exposures=np.asarray(initial['training_data']['exposure_counts']).copy()
    raw={k:v.unsqueeze(0) for k,v in train[0].items()};b=norm.prepare(raw,'cuda:0')
    with torch.no_grad():out=call(model,b,False)
    assert list(raw['data'].shape)==plan['input_shape'] and list(out['z'].shape)==plan['latent_shape'] and list(out['volume'].shape)==plan['output_shape']
    if spec['fresh'] and not resume_step:
        expected=torch.full_like(out['volume'],plan['normalization']['mean_quantity']).masked_fill(~b['mask'],0)
        torch.testing.assert_close(out['volume'],expected,rtol=1e-6,atol=1e-6)
    common={name:tensor_digest(getattr(model.volume_decoder,name)) for name in ['temporal','position','geometry']}
    atomic_json(folder/('resume_contract.json' if resume_step else 'initial_contract.json'),dict(passed=True,raw_input=list(raw['data'].shape),latent=list(out['z'].shape),quantity=list(out['volume'].shape),frozen_digests=frozen,common_decoder_digests=common,quantity_decoder_parameters=sum(p.numel() for p in model.volume_decoder.parameters()),fresh_optimizer=spec['fresh'] and not resume_step,zero_quantity_output_weights=spec['fresh'] and not resume_step,encoder_skip=False,resumed_step=resume_step,restored_model_sha256=tensor_digest(model)))
    del raw,b,out
    if resume_step:
        loader,sampler_rng=boundary_loader(train,initial['sampler_generator_state'])
    else:
        loader=DataLoader(train,batch_size=1,shuffle=True,num_workers=2,persistent_workers=True,pin_memory=True,generator=torch.Generator().manual_seed(42));sampler_rng=loader.generator
    iterator=iter(loader)
    atomic_json(folder/'trainable_modules.json',{n:sum(p.numel() for p in getattr(model,n).parameters() if p.requires_grad) for n in ['encoder','price_decoder','volume_decoder']})
    def save(step):
        actual={n:tensor_digest(getattr(model,n)) for n in plan['freeze']}
        if actual!=frozen:raise RuntimeError('Frozen module changed')
        atomic_json(folder/f'step{step}_frozen_audit.json',dict(passed=True,digests=actual))
        value=dict(format_version=1,model=model.state_dict(),unified_vae_config=plan['model_config'],config=dict(source_config,loss_family='probability',loss=dict(plan['objective'],mode='shape_mass',add_wasserstein=False,add_multiscale=False)),step=step,lane=lane,beta=0.,training_sample=False,freeze=plan['freeze'],optimizer=opt.state_dict(),optimizer_parameter_names=optimizer_names,source_hashes=hashes,torch_rng_state=torch.get_rng_state(),cuda_rng_state=torch.cuda.get_rng_state_all(),sampler_generator_state=sampler_rng.get_state(),epoch_boundary=step*plan['accumulation']%len(train)==0,training_data=dict(exposure_counts=exposures.copy(),windows=len(train),epochs_equivalent=step*plan['accumulation']/len(train)),resumed_from_step=resume_step)
        if spec['kind']=='query':value['query_decoder_config']=plan['query_config']
        atomic_save(value,folder/f'step{step}.pt')
    if not resume_step:
        save(0);assess(root,folder,0,model,norm,dev,seen,dev_original,vi,criterion)
    elif not all((folder/f'step{resume_step}_{suffix}').exists() for suffix in ['evaluation.json','seen_evaluation.json','probability.json','profiles.npz','preview.html']):
        assess(root,folder,resume_step,model,norm,dev,seen,dev_original,vi,criterion)
    if resume_step:
        torch.set_rng_state(initial['torch_rng_state'].cpu())
        torch.cuda.set_rng_state_all([v.cpu() for v in initial['cuda_rng_state']])
    del initial
    atomic_json(folder/'status.json',dict(state='training',step=resume_step))
    for step in range(resume_step+1,plan['steps']+1):
        if time.monotonic()-started>plan['max_seconds']:raise TimeoutError('Four-hour decoder ceiling')
        model.train();model.encoder.eval();model.price_decoder.eval();opt.zero_grad(set_to_none=True);record={};order=[]
        for micro in range(plan['accumulation']):
            try:raw=next(iterator)
            except StopIteration:iterator=iter(loader);raw=next(iterator)
            pos=int(raw['cache_position'][0]);exposures[pos]+=1;order.append(int(ti[pos]));b=norm.prepare(raw,'cuda:0')
            assert list(raw['data'].shape)==plan['input_shape']
            with torch.autocast('cuda',dtype=torch.bfloat16):out=call(model,b,False)
            assert list(out['z'].shape)==plan['latent_shape'] and list(out['volume'].shape)==plan['output_shape']
            values=criterion(out,b,beta=0.)
            if not bool(torch.isfinite(values['loss'])):raise FloatingPointError('Nonfinite loss')
            (values['loss']/plan['accumulation']).backward()
            for key,v in values.items():record[key]=record.get(key,0.)+float(v.detach())/plan['accumulation']
        if step==resume_step+1:
            gradients={n:float(p.grad.float().norm()) if p.grad is not None else None for n,p in model.named_parameters()}
            if any(p.grad is not None for n in plan['freeze'] for p in getattr(model,n).parameters()):raise RuntimeError('Frozen gradients found')
            if not gradients['volume_decoder.quantity.weight']>0:raise RuntimeError('Quantity head has no gradient')
            prefix='resume_' if resume_step else ''
            atomic_json(folder/f'{prefix}first_step_gradient_norms.json',gradients);atomic_json(folder/f'{prefix}first_step_data.json',dict(step=step,training_indices=order,losses=record))
        grad=torch.nn.utils.clip_grad_norm_(model.parameters(),plan['clip_grad'],error_if_nonfinite=True);opt.step()
        if step==resume_step+1:
            unchanged={n:tensor_digest(getattr(model,n))==frozen[n] for n in plan['freeze']}
            if not all(unchanged.values()):raise RuntimeError('Frozen module updated')
            atomic_json(folder/('resume_first_update_audit.json' if resume_step else 'first_update_audit.json'),dict(passed=True,step=step,frozen_unchanged=unchanged,quantity_weight_norm=float(model.volume_decoder.quantity.weight.detach().float().norm())))
        old_row=plan.get('resume_reference_rows',{}).get(lane,{}).get(str(step))
        if old_row:
            if order!=old_row['training_indices']:raise RuntimeError('Resumed sampler order differs from interrupted trajectory')
            delta=abs(record['loss']-old_row['loss'])
            if delta>1e-5:raise RuntimeError(f'Resumed objective differs:{delta}')
            atomic_json(folder/'resume_trajectory_replay.json',dict(passed=True,step=step,training_indices_equal=True,objective_abs_delta=delta))
        if step==resume_step+1 or step%8==0:
            row=dict(step=step,total=plan['steps'],elapsed_seconds=time.monotonic()-started,gradient_norm=float(grad),reserved_gib=torch.cuda.memory_reserved()/2**30,epochs_equivalent=float(exposures.mean()),unique_windows_seen=int((exposures>0).sum()),training_indices=order,**record)
            atomic_json(folder/'progress.json',row)
            with (folder/'progress.jsonl').open('a') as stream:stream.write(json.dumps(row)+'\n')
            print(json.dumps(row),flush=True)
        if step in plan['checkpoints']:save(step);assess(root,folder,step,model,norm,dev,seen,dev_original,vi,criterion)
    atomic_json(folder/'status.json',dict(state='complete',step=step,elapsed_seconds=time.monotonic()-started))


def latent_assess(root,folder,step,model,norm,raws,batches,z0,codes,indices,reference=None):
    metrics=DynamicsMetrics(norm.tick_size);counts={t:np.zeros(3,dtype=np.int64) for t in [10,100]};max_pred=0.;per_window=[]
    values={k:[] for k in ['truth','prediction','mask','time']}
    original=dataset(root,'train')
    with torch.inference_mode():
        for i,(raw,b) in enumerate(zip(raws,batches)):
            out=model.decode(codes[i:i+1],b['mask'],b['tick_norm'],b['times'])
            truth=raw['data'][0].numpy().astype(np.float64)
            prediction=np.stack((norm.inverse_price(out['price_norm'],b)[0].cpu().numpy(),out['volume'][0].cpu().numpy()),-1)
            mask=b['mask'][0].cpu().numpy();metrics.update(truth,prediction,mask)
            p_rmse=float(np.sqrt(np.square(prediction[...,0][mask]-truth[...,0][mask]).mean()))
            q_rmse=float(np.sqrt(np.square(prediction[...,1][mask]-truth[...,1][mask]).mean()))
            per_window.append(dict(training_index=int(indices[i]),price_rmse_usdt=p_rmse,quantity_rmse_btc=q_rmse,
                source_z_norm=float(z0[i].norm()),z_norm=float(codes[i].norm()),delta_z_norm=float((codes[i]-z0[i]).norm()),
                delta_over_source_norm=float((codes[i]-z0[i]).norm()/z0[i].norm().clamp_min(1e-12))))
            for threshold in counts:
                a=(truth[...,1]>=threshold)&mask;c=(prediction[...,1]>=threshold)&mask
                counts[threshold]+=[int((a&c).sum()),int((~a&c&mask).sum()),int((a&~c).sum())]
            max_pred=max(max_pred,float(prediction[...,1][mask].max()))
            values['truth'].append(truth);values['prediction'].append(prediction);values['mask'].append(mask)
            start=int(original.base.starts[int(indices[i])]);values['time'].append(original.base.times[start:start+256])
    result=metrics.finish();result.update(prediction_max=max_pred,thresholds={str(t):dict(tp=int(c[0]),fp=int(c[1]),fn=int(c[2]),precision=float(c[0]/(c[0]+c[1])) if c[0]+c[1] else None,recall=float(c[0]/(c[0]+c[2])) if c[0]+c[2] else None) for t,c in counts.items()},evaluation_precision='fp32')
    ratio=read(root/'plan.json')['latent_diagnostic']['price_guard_ratio']
    if reference:
        for item,base in zip(per_window,reference['per_window']):item['price_guard_passed']=item['price_rmse_usdt']<=ratio*base['price_rmse_usdt']
    value=dict(result=result,per_window=per_window,price_guard_ratio=ratio,
        pooled_price_guard_passed=result['metrics']['price_usdt']['rmse']<=ratio*reference['result']['metrics']['price_usdt']['rmse'] if reference else True,
        scope='Four trainingtargets used to directly fitZ. Not Encoder inference, not development orOOS score.')
    atomic_json(folder/f'step{step}_fit_evaluation.json',value)
    temp=folder/f'step{step}_profiles.tmp'
    with temp.open('wb') as stream:np.savez_compressed(stream,**{k:np.stack(v) for k,v in values.items()},indices=indices)
    temp.replace(folder/f'step{step}_profiles.npz');preview(root,'latent_fit',step)
    return value


def latent_worker(root):
    torch.set_num_threads(4);seed_everything(42);strict_precision();started=time.monotonic();plan=read(root/'plan.json');spec=plan['latent_diagnostic'];folder=root/'latent_fit'
    atomic_json(folder/'status.json',dict(state='initial_validation'))
    model,norm=load_for_inference(root/'initial.pt','cuda:0');model.eval().requires_grad_(False);digest=tensor_digest(model)
    original=dataset(root,'train');indices=np.load(root/spec['indices_file'])
    raws=[{k:v.unsqueeze(0) for k,v in original[int(i)].items()} for i in indices]
    batches=[norm.prepare(raw,'cuda:0') for raw in raws];means=[];logvars=[]
    with torch.no_grad():
        for raw,b in zip(raws,batches):
            assert list(raw['data'].shape)==plan['input_shape']
            mu,lv=model.encoder(*[b[k] for k in ['price','volume','mask','tick_norm','times']]);means.append(mu);logvars.append(lv)
    resume_step=plan.get('resume_steps',{}).get('latent_fit',0)
    saved=torch.load(folder/f'step{resume_step}_codes.pt',map_location='cpu',weights_only=False) if resume_step else None
    z0=torch.cat(means).detach();lv0=torch.cat(logvars).detach();codes=torch.nn.Parameter(z0.clone())
    if saved:
        if saved['model_sha256']!=digest or not np.array_equal(saved['training_indices'],indices):raise RuntimeError('Latent resume model/data mismatch')
        torch.testing.assert_close(z0.cpu(),saved['z0'],rtol=0,atol=0)
        with torch.no_grad():codes.copy_(saved['z'].to('cuda:0'))
    assert list(codes.shape)==[4,64,128]
    criterion=criterion_for(plan);opt=torch.optim.Adam([codes],lr=spec['lr'])
    if saved:opt.load_state_dict(saved['optimizer'])
    reference=read(folder/'step0_fit_evaluation.json') if resume_step else latent_assess(root,folder,0,model,norm,raws,batches,z0,codes,indices)
    atomic_json(folder/('resume_contract.json' if resume_step else 'initial_contract.json'),dict(passed=True,model_sha256=digest,indices=indices.tolist(),raw_shape=plan['input_shape'],codes_shape=list(codes.shape),scalars_per_window=8192,trainable_model_parameters=0,trainable_code_scalars=codes.numel(),precision='fp32',source='saved code+Adam' if saved else 'frozen Encoder mean',resumed_step=resume_step))
    initial_codes=codes.detach().clone()
    atomic_json(folder/'status.json',dict(state='training',step=resume_step))
    for step in range(resume_step+1,spec['steps']+1):
        if time.monotonic()-started>plan['max_seconds']:raise TimeoutError('Four-hour latent-fit ceiling')
        opt.zero_grad(set_to_none=True);record={}
        for i,b in enumerate(batches):
            z=codes[i:i+1];out=dict(**model.decode(z,b['mask'],b['tick_norm'],b['times']),mu=z,logvar=lv0[i:i+1],z=z)
            values=criterion(out,b,beta=0.)
            if not bool(torch.isfinite(values['loss'])):raise FloatingPointError('Nonfinite latent objective')
            (values['loss']/len(batches)).backward()
            for key,v in values.items():record[key]=record.get(key,0.)+float(v.detach())/len(batches)
        if step==resume_step+1:
            if any(p.grad is not None for p in model.parameters()):raise RuntimeError('Fixed Decoder got parameter gradients')
            if not bool(torch.isfinite(codes.grad).all()) or codes.grad.norm()==0:raise RuntimeError('No valid code gradient')
        grad=torch.nn.utils.clip_grad_norm_([codes],spec['clip_grad'],error_if_nonfinite=True);opt.step()
        if step==resume_step+1:
            if tensor_digest(model)!=digest:raise RuntimeError('Frozen model changed')
            atomic_json(folder/('resume_first_update_audit.json' if resume_step else 'first_update_audit.json'),dict(passed=True,step=step,all_model_parameters_unchanged=True,code_delta_since_checkpoint=float((codes-initial_codes).detach().norm()),code_delta_norm=float((codes-z0).detach().norm()),code_gradient_norm=float(grad)))
        old_row=plan.get('resume_reference_rows',{}).get('latent_fit',{}).get(str(step))
        if old_row:
            delta=abs(record['loss']-old_row['loss'])
            if delta>1e-5:raise RuntimeError(f'Latent resume trajectory differs:{delta}')
            atomic_json(folder/'resume_trajectory_replay.json',dict(passed=True,step=step,objective_abs_delta=delta))
        if step==resume_step+1 or step%8==0:
            row=dict(step=step,total=spec['steps'],elapsed_seconds=time.monotonic()-started,gradient_norm=float(grad),code_delta_norm=float((codes-z0).detach().norm()),reserved_gib=torch.cuda.memory_reserved()/2**30,**record)
            atomic_json(folder/'progress.json',row)
            with (folder/'progress.jsonl').open('a') as stream:stream.write(json.dumps(row)+'\n')
            print(json.dumps(row),flush=True)
        if step in spec['checkpoints']:
            if tensor_digest(model)!=digest:raise RuntimeError('Frozen model changed')
            atomic_json(folder/f'step{step}_frozen_audit.json',dict(passed=True,model_sha256=digest))
            atomic_save(dict(format='diagnostic_latent_table_v1',training_indices=indices,z0=z0.detach().cpu(),z=codes.detach().cpu(),optimizer=opt.state_dict(),step=step,model_sha256=digest,not_production_inference=True),folder/f'step{step}_codes.pt')
            latent_assess(root,folder,step,model,norm,raws,batches,z0,codes,indices,reference)
    atomic_json(folder/'status.json',dict(state='complete',step=step,elapsed_seconds=time.monotonic()-started))


def refresh_report(root):
    """Keep compute alive on report errors, with explicit error state/logs."""
    from train_dual.experiments.decoder_isolation_report import render
    try:
        render(root)
    except Exception as error:
        import traceback
        atomic_json(root/'report_status.json',dict(state='failed_retry_pending',error=repr(error)))
        with (root/'logs/report_errors.log').open('a') as log:log.write(traceback.format_exc()+'\n')
        return False
    atomic_json(root/'report_status.json',dict(state='complete'))
    return True


def campaign(root):
    plan=read(root/'plan.json');started=time.monotonic();children=[]
    def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        rows=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.free','--format=csv,noheader,nounits'],text=True).splitlines();free={int(r.split(',')[0]):int(r.split(',')[1]) for r in rows}
        if any(free.get(g,0)<47000 for g in [2,3,4,5]):raise RuntimeError(f'Four idle GPUs required:{free}')
        for gpu,lane in plan['gpu_workers']:
            env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),CUDA_DEVICE_ORDER='PCI_BUS_ID',PYTHONPATH=str(root/'source_snapshot'))
            with (root/'logs'/f'{lane}.log').open('ab',buffering=0) as log:
                child=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.decoder_isolation_run',str(root),'--lane',lane],cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            children.append((lane,gpu,child))
        atomic_json(root/'status.json',dict(state='running',children=[dict(role=l,gpu=g,pid=p.pid) for l,g,p in children]))
        while any(p.poll() is None for _,_,p in children):
            if time.monotonic()-started>plan['max_seconds']:raise TimeoutError('Four-hour cohort ceiling')
            failed={l:p.returncode for l,_,p in children if p.poll() not in [None,0]}
            if failed:raise RuntimeError(f'Owned workers failed:{failed}')
            refresh_report(root);time.sleep(10)
        failed={l:p.returncode for l,_,p in children if p.returncode!=0}
        if failed:raise RuntimeError(f'Owned workers failed:{failed}')
        atomic_json(root/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started))
    except BaseException as error:
        atomic_json(root/'status.json',dict(state='failed',error=repr(error)));raise
    finally:
        for _,_,p in children:
            if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)
        refresh_report(root)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--lane',choices=[*LABELS,'latent_fit']);args=p.parse_args();root=args.root.resolve()
    try:
        if args.prepare:prepare(root)
        elif args.lane=='latent_fit':latent_worker(root)
        elif args.lane:decoder_worker(root,args.lane)
        else:campaign(root)
    except BaseException as error:
        if args.lane:atomic_json(root/args.lane/'status.json',dict(state='failed',error=repr(error)))
        raise
