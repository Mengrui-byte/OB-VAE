"""CPU preparation of matched direct-readout initializations; starts no training."""
import argparse
import hashlib
import json
import os
from pathlib import Path

import torch

from model.autoencoder.direct_readout_vae import DirectReadoutOrderBookVAE
from model.layers.branch_precision import apply_branch_precision_
from train_dual.util.checkpoint import atomic_save, freeze_sources
from train_dual.util.direct_readout_training import restore_direct_readout_adam
from train_dual.util.phase_training import tensor_digest


def prepare(goal):
    torch.set_num_threads(2)
    parent = goal / 'round_010_branch_precision'
    old = json.loads((parent / 'plan.json').read_text())
    source = parent / 'source.pt'
    assert hashlib.sha256(source.read_bytes()).hexdigest() == old['source_sha256']
    payload = torch.load(source, map_location='cpu', mmap=True, weights_only=False)
    assert payload['unified_vae_config']['levels'] == 2048
    assert payload['regional_phase_config']['layout'] == 'frame1'
    root = goal / 'direct_readout_preparation_20261029'
    root.mkdir()
    os.link(source, root / 'source.pt')
    records = {}
    shared_hash = None
    for activation in ['identity', 'gelu']:
        model = DirectReadoutOrderBookVAE(readout_activation=activation, readout_hidden=2048,
            **payload['regional_phase_config'], **payload['unified_vae_config'])
        missing, unexpected = model.load_state_dict(payload['model'], strict=False)
        expected = ['direct_quantity_readout.' + name for name in [
            'input_projection.weight', 'input_projection.bias', 'output_projection.weight', 'output_projection.bias']]
        assert missing == expected and not unexpected
        for name, value in payload['model'].items():
            torch.testing.assert_close(model.state_dict()[name], value, rtol=0, atol=0)
        apply_branch_precision_(model, encoder_fp32=True, decoders_fp32=True)
        optimizer, groups = restore_direct_readout_adam(model, payload['optimizer'], old['original_parameter_names'])
        restored = optimizer.state_dict()
        assert restored['param_groups'][:3] == payload['optimizer']['param_groups']
        assert restored['state'].keys() == payload['optimizer']['state'].keys()
        for index, state in payload['optimizer']['state'].items():
            for name, value in state.items():
                other = restored['state'][index][name]
                if torch.is_tensor(value): torch.testing.assert_close(other, value, rtol=0, atol=0)
                else: assert other == value
        assert all(p not in optimizer.state for p in model.direct_quantity_readout.parameters())
        digest = tensor_digest(model)
        if shared_hash is not None: assert digest == shared_hash
        shared_hash = digest
        initial = {name: payload[name] for name in ['format_version', 'config', 'unified_vae_config',
                                                   'regional_phase_config', 'local_hint_config'] if name in payload}
        initial.update(model=model.state_dict(), direct_readout_config=model.direct_readout_config,
                       branch_precision_config=dict(encoder_fp32=True, decoders_fp32=True))
        atomic_save(initial, root / f'initial_{activation}.pt')
        records[activation] = dict(original_model_tensors_exact=True, all3_original_Adam_groups_exact=True,
            original_Adam_states=len(payload['optimizer']['state']), new_Adam_group_empty=True,
            optimizer_groups=len(groups), additional_parameters=sum(p.numel() for p in model.direct_quantity_readout.parameters()),
            initial_model_sha256=digest, zero_output_weight=not bool(model.direct_quantity_readout.output_projection.weight.any()),
            zero_output_bias=not bool(model.direct_quantity_readout.output_projection.bias.any()))
        del model, optimizer, initial
    plan = dict(state='CPU_preparation_only', source_relative='round_010_branch_precision/source.pt',
        source_sha256=old['source_sha256'], labels=['identity', 'gelu'], records=records,
        actual_source_input_contract=[1, 256, 2, 2048, 2], unique_latent_contract=[1, 64, 128],
        full_reconstruction_contract=[1, 256, 2, 2048], head_dimensions=[256, 2048, 4096],
        factor='Identity versus GELU between identical two linear layers; same parameter count, weights, zero residual, FP32 arithmetic. '
               'Signed logit correction reads source post-Z quantity-frame features. No new window latent, source Encoder skip, or new labels.',
        source_state_role='source.pt is unchanged original source WITH3Adam/RNG; initial_identity/gelu.pt are inference/model initializations WITHOUT optimizer, never optimizer migration evidence.',
        training_scope='Not scheduled. Review existing frozen-price512 endpoint first. Any paired run must fix training data/order/seed42, '
                       'all3oldAdam plus empty fourth group, frozen Encoder/price, objective/coefficients and update budget before launch.',
        pending=['Actual full2048 GPU forward/backward, shared8192Z/fresh decode, both initial native source replays, CUDA RNG and dtypes, '
                 'fourgroup optimizer update/frozen price proof, memory/throughput, declaration of training protocol.'],
        neural_forward_calls=0, optimizer_updates=0, independent_test_used=False)
    (root / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n')
    freeze_sources(root / 'source_snapshot')
    (root / 'status.json').write_text(json.dumps(dict(state='prepared_requires_full_GPU_preflight_no_training_started'), indent=2) + '\n')
    print(json.dumps(plan), flush=True)
    return root


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('goal', type=Path)
    args = parser.parse_args()
    prepare(args.goal.resolve())
