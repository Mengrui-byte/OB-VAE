"""Top16 quantity weight x global quantity weight: matched full-window fit."""
import argparse
from datetime import datetime
import json
import os
from pathlib import Path

import numpy as np

from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.loss_control_run import campaign, worker
from train_dual.util.checkpoint import freeze_sources


LABELS = {
    'baseline': '全局1·Top16数量0.25（匹配对照）',
    'no_topq': '全局1·Top16数量0',
    'global8': '全局8·Top16数量0.25',
    'global8_no_topq': '全局8·Top16数量0（交互对照）',
}


def prepare(parent):
    parent = parent.resolve()
    project = Path(__file__).resolve().parents[2]
    root = project / 'recons' / ('loss_allocation_' + datetime.now().strftime('%Y%m%d_%H%M%S'))
    root.mkdir()
    (root / 'data').mkdir()
    (root / 'logs').mkdir()
    for name in ('val_indices.npy', 'source_profiles.npz', 'audit_train.pt'):
        os.link(parent / name, root / name)
    os.link(parent / 'data/BTCUSDT.npz', root / 'data/BTCUSDT.npz')
    os.link(parent / 'full/step512.pt', root / 'initial.pt')
    os.link(parent / 'full/step512_evaluation.json', root / 'initial_expected.json')
    os.link(parent / 'train_indices.npy', root / 'source_train_indices.npy')
    source_indices = np.load(parent / 'train_indices.npy')
    positions = np.unique(np.linspace(0, len(source_indices) - 1, 4, dtype=int))
    selected = source_indices[positions]
    diagnostic = Path(Path('/tmp/gradient_capacity_path').read_text().strip())
    np.testing.assert_array_equal(selected, np.load(diagnostic / 'small_train_indices.npy'))
    np.save(root / 'train_indices.npy', selected)
    lanes = {
        name: dict(mode='shape_mass', global_quantity_weight=gw, top_quantity_weight=tw)
        for name, gw, tw in [('baseline', 1., .25), ('no_topq', 1., 0.),
                             ('global8', 8., .25), ('global8_no_topq', 8., 0.)]
    }
    plan = json.loads((parent / 'plan.json').read_text())
    plan.update(
        experiment='2x2 global-vs-Top16 quantity loss allocation;4-window fitting diagnostic',
        parent=str(parent), pretraining_steps=2816,
        source_checkpoint='gradient_route/full/step512: AE2048+shape_mass256+full_route512; use the matched control, not best validation lane',
        loss_family='allocation', lanes=lanes, labels=LABELS,
        gradient_routes={name: dict(detach_quantity_latent=False, detach_quantity_geometry=False) for name in lanes},
        fit_windows=4, seen_windows=4, evaluation_windows=16, initial_seen_evaluation=True,
        training_cache_positions=positions.tolist(), selected_training_indices=selected.tolist(),
        steps=1024, checkpoints=[32,128,256,512,1024], max_seconds=7200,
        queue_max_seconds=7200, wait_for_relative=str(parent.relative_to(project)),
        wait_for_relatives=[str(parent.relative_to(project))],
        default_variant='baseline', viewer_default_model=2, viewer_route='loss_allocation',
        objective=dict(price_weight=1., quantity_weight=1., log_weight=1., pair_weight=.25,
                       topk=16, shape_weight=1., mass_weight=1.),
        hypothesis='Top16-heavy allocation sacrifices ordinary quantity fitting. Redistributing quantity weights should improve full-book amplitude and temporal changes if that is a principal limiting factor.',
        initialization='All4 share full-route512 model and AdamW state, total2816 shared source updates. All restart sampler identically at seed42; this is a four-window fitting diagnostic, not continuation of the previous64-window data trajectory.',
        control_contract=dict(
            fixed=['same2816-step source model and AdamW state', 'full256frames,8192latent,nearest+conv',
                   'same4training windows selected before this study; same16development windows',
                   'same normalization fitted on source64training windows; not refitted on development',
                   'price and Top16-price loss, log-quantity, distributionKL and mass weights unchanged',
                   'full quantity gradient routing in all4', 'seed42,batch1accum4,AdamW1e-4,clip1',
                   '1024additionalupdates;BF16train,FP32eval,TF32off'],
            factors=['Top16 quantity Huber coefficient .25 versus0; Top16 price stays.25',
                     'All-valid linear quantity Huber coefficient1 versus8; log coefficient stays1'],
            formula='Lp+.25*Top16Price+w_global*Lq+Llog+w_top*Top16Quantity+KL_distribution+Lmass;beta0,Z=mu',
            effective_weights='At2048 valid levels, baseline Top16 quantity has32 extra per-point weight relative to global1. Global8 reduces that ratio to4; removing Top16 quantity removes the extra emphasis only.',
            interpretation='Global clipping is fixed at1; its frequency/magnitude may change with weights and is part of the optimization effect. No claim of isolated parameter-update magnitude.'),
        selection='Fixed1024 endpoint primary; retain all declared intermediates. Primary fitting evidence:4train-window quantityRMSE versus baseline and own initialization; minute log-quantity-change correlation;>=10/100BTC same-location precision AND recall. Exploratory meaningful fit target:>=10% lower train quantityRMSE than matched baseline and change correlation>=.10. Development quantityRMSE and dynamics reported separately; price guard <=1.10x matched baseline development priceRMSE. Improvements failing price guard are tradeoffs. No independent-test or2026 selection.',
        reference='Only baseline is matched. Former large-latent model in viewer is an external quality ruler with different capacity/history.',
        viewer_description='8192瓶颈、完整256分钟、损失分配2×2。四组共同full-route512权重/AdamW动量（此前累计2816更新），相同4个预选训练窗和16个2025Q1开发窗，追加1024步。只改变全局原始数量Huber系数1/8、Top16数量Huber系数.25/0；价格项、Top16价格项、log数量、分布KL、总量、完整梯度回传和上采样均固定。小训练集用于拟合诊断；开发集已反复使用，2026和独立测试未参与。',
        viewer_step_note='本轮追加步数；共同2816步起点，4训练窗，每次更新batch1累积4。',
    )
    plan.pop('kl_warmup_steps', None)
    atomic_json(root / 'plan.json', plan)
    atomic_json(root / 'status.json', dict(state='prepared'))
    atomic_json(root / 'data_contract.json', dict(
        raw_input_shape=[1,256,2,2048,2], latent_shape=[1,64,128],
        output_shape=[1,256,2,2048], positions=positions.tolist(),
        training_indices=selected.tolist(), normalization='Source64training-only statistics kept fixed',
        selection='Reuse the same4preselected training windows as the earlier gradient/capacity audit'))
    (root / 'README.md').write_text(
        '# 全局数量权重×Top16数量权重控制实验\n\n'
        '四组使用完整256分钟、唯一64×128瓶颈和相同最近邻上采样。共同起点为上一轮full匹配对照第512步，'
        '累计2816步；不是开发集最佳组。保留AdamW状态，全部端到端训练。\n\n'
        '因素A：Top16数量Huber权重0.25/0；因素B：全局数量Huber权重1/8。'
        '价格及Top16价格、log数量、分布KL和总量均固定，梯度完整回传。'
        '4个预先确定的训练窗、16个固定开发窗、seed42、batch1累积4、1024次追加更新。'
        '归一化仍使用原64个训练窗统计。clip1固定，但权重变化可改变裁剪强度。\n\n'
        'public/同时显示4训练窗拟合与16开发窗指标；每个档位分别画线，首个共同32步发布重建图。'
        '关注数量RMSE、分钟数量变化相关性、10/100BTC档位精确率和召回，并约束价格误差。'
        '本轮是小样本拟合诊断，不能视为2026或独立样本外验证。\n')
    freeze_sources(root / 'source_snapshot')
    remote = Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e') / root.relative_to(project)
    (root / 'run.sh').write_text(
        '#!/usr/bin/env bash\nset -euo pipefail\n'
        f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 '
        'OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\n'
        f'cd "{remote}/source_snapshot"\n'
        f'exec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.loss_allocation_run "{remote}"\n')
    Path('/tmp/loss_allocation_path').write_text(str(root))
    print(root, flush=True)


if __name__ == '__main__':
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('root', type=Path)
    p.add_argument('--prepare', action='store_true')
    p.add_argument('--lane')
    args = p.parse_args()
    if args.prepare:
        prepare(args.root)
    elif args.lane:
        worker(args.root, args.lane)
    else:
        campaign(args.root)
