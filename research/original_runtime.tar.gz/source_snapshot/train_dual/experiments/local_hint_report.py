"""Fixed-data factorial results; normal reconstruction and edits shown separately."""
import html
from train_dual.experiments.phase_detail_report import read,fmt,STYLE


def render(root):
    plan=read(root/'plan.json');status=read(root/'status.json',{})
    parts=[f'<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="30"><title>Local蒸馏 × 挂量增强</title><style>{STYLE}</style><main>',
        '<h1>Local中间表示蒸馏 × 在线挂量增强</h1>',
        f'<div class="note">状态：{html.escape(status.get("state","prepared"))}。远端GPU2–5，完整256分钟、每侧2048档，唯一64×128Gaussian。全部学生模块训练，保留价格监督。</div>',
        '<p>四组从逐帧Huber第4096步的相同权重、原Adam及保存的随机状态继续，数据为相同1024个2022–2024训练窗。追加8192步（32个等效epoch），单seed42，每组训练最多12小时。相同更新预算不等于相同FLOPs：蒸馏组额外教师前向耗时单独记录。</p>',
        '<p>教师冻结，用自己的normalizer处理与学生相同的原始或增强窗口。学生仅在瓶颈后读取数量空间种子，经16→16适配器预测教师Local。推理不依赖教师。增强概率0.5，每个被增强窗口2次随机交换/插入/消除事件；输入与重建目标同步变换。所有常规评估均使用未增强的真实订单簿。</p>',
        '<h2>训练进度</h2><div class="wrap"><table><tr><th>组别</th><th>状态</th><th>追加更新</th><th>累计等效epoch</th><th>原重建目标</th><th>提示MSE</th><th>梯度范数</th><th>教师累计秒</th></tr>']
    for lane,label in plan['labels'].items():
        p=read(root/lane/'progress.json',{});s=read(root/lane/'status.json',{})
        vals=[label,s.get('state','等待'),f'{p.get("step",0)}/{plan["steps"]}',fmt(p.get('epochs_equivalent')),fmt(p.get('pre_hint_loss')),fmt(p.get('local_hint_mse')),fmt(p.get('gradient_norm')),fmt(p.get('teacher_seconds'))]
        parts.append('<tr>'+''.join(f'<td>{html.escape(str(v))}</td>' for v in vals)+'</tr>')
    parts.append('</table></div>')
    for split,title in [('development','16个2025Q1开发窗'),('seen','8个见过的训练窗'),('unseen','32个未用于学生训练的2022–2024窗口')]:
        parts.extend([f'<h2>{title}</h2><div class="wrap"><table><tr><th>追加步数</th><th>组别</th><th>价格RMSE/USDT</th><th>挂量RMSE/BTC</th><th>Δlog挂量相关</th><th>100BTC召回</th><th>精确率</th><th>误报</th><th>最大预测量</th><th>图</th></tr>'])
        for step in [0,*plan['checkpoints']]:
            for lane,label in plan['labels'].items():
                value=read(root/lane/f'step{step}_{split}.json')
                if not value:continue
                d=value['result'];m=d['metrics'];t=d['thresholds']['100']
                link=f'{lane}/step{step}_preview.html' if split=='development' else f'{split}/{lane}/step{step}_preview.html'
                image=f'<a href="{link}">中间价＋逐档线</a>' if (root/link).exists() else '—'
                vals=[str(step),label,fmt(m['price_usdt']['rmse']),fmt(m['quantity_btc']['rmse']),fmt(m['temporal_log_quantity_1_minutes']['correlation']),fmt(t['recall']),fmt(t['precision']),str(t['fp']),fmt(d['prediction_max']),image]
                parts.append('<tr>'+''.join(f'<td>{v}</td>' for v in vals)+'</tr>')
        parts.append('</table></div>')
    calibration=read(root/'calibration.json',{})
    parts.extend(['<h2>训练期校准</h2>',f'<pre>{html.escape(__import__("json").dumps(calibration,ensure_ascii=False,indent=2))}</pre>',
        '<h2>固定位置/幅度反事实响应</h2><p>训练前在已拟合4窗模型上，保持价格与mask不变，只交换大单位置、加倍或清除指定挂量；分别记录真实增量和预测增量。这是已知输入扰动诊断，不是市场泛化成绩。</p>',
        '<p><a href="counterfactual.json">完整响应记录</a> · <a href="startup_control_audit.json">实际GPU启动核验</a> · <a href="plan.json">配置</a> · <a href="design.md">设计</a> · <a href="source_snapshot/sha256.json">源码哈希</a> · <a href="../">全部实验</a></p>',
        '<p>2025Q1已反复用于研究，仅称开发集；2025Q2与2026不使用。同年代未见窗口只针对当前学生训练索引，教师历史训练可能见过它们。常规评估不使用教师输出作为重建输入。只提高召回、降低合并损失或超过退化对照均不足以判优；价格同时对共同起点及匹配对照做1.10倍保护。没有达到8192步的组如实报告实际步数。</p>'])
    if status.get('error'):parts.append(f'<div class="note">{html.escape(status["error"])}</div>')
    parts.append('</main></html>')
    temp=root/'report.tmp';temp.write_text(''.join(parts));temp.replace(root/'index.html')
