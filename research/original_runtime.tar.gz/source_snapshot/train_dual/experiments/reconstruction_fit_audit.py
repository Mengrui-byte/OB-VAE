"""Read-only seen-window evaluation to separate fitting from temporal transfer."""

import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import numpy as np
import torch
from torch.utils.data import Subset

from train_dual.experiments.long_worker import atomic_json, datasets, evaluate
from train_dual.experiments.window_state_pilot import load_base, strict_precision
from train_dual.util.checkpoint import freeze_sources, load_for_inference, seed_everything


LANES = ('fixed', 'linear', 'nonlinear', 'attention')


def worker(root, audit, lane):
    torch.set_num_threads(4)
    seed_everything(42)
    strict_precision()
    started = time.monotonic()
    initial, norm = load_base(root)
    train = datasets(root, initial, 'train')
    fit = np.load(root / 'fit_indices.npy')
    positions = np.unique(np.linspace(0, len(fit) - 1, 128, dtype=int))
    small_positions = np.load(root / 'small_positions.npy')
    folder = audit / lane
    folder.mkdir(exist_ok=True)
    atomic_json(folder / 'status.json', dict(state='running'))

    def measure(checkpoint, name, selected):
        model, normalizer = load_for_inference(checkpoint, 'cuda:0')
        selected_indices = fit[selected]
        value = evaluate(model, normalizer, Subset(train, selected_indices.tolist()), len(selected), 'cuda:0')
        row = dict(checkpoint=str(checkpoint), result=value, split='actual_seen_training_windows',
            cache_positions=selected.tolist(), dataset_indices=selected_indices.tolist(),
            evaluation_backend='strict_fp32', elapsed_seconds=time.monotonic()-started)
        atomic_json(folder / (name + '.json'), row)
        del model
        torch.cuda.empty_cache()
        print(json.dumps(dict(lane=lane, stage=name, quantity_rmse=value['metrics']['quantity_btc']['rmse'],
            recall100=value['thresholds']['100']['recall'])), flush=True)

    try:
        measure(root / 'main' / lane / 'initial.pt', 'seen_initial', positions)
        measure(root / 'main' / lane / 'final.pt', 'seen_final', positions)
        measure(root / 'main' / lane / 'final.pt', 'small_seen_main_final', small_positions)
        measure(root / 'small_fit' / lane / 'final.pt', 'small_seen_diagnostic_final', small_positions)
        if lane == 'fixed':
            measure(root / 'initial.pt', 'source_seen', positions)
            measure(root / 'initial.pt', 'source_small_seen', small_positions)
        atomic_json(folder / 'status.json', dict(state='complete', elapsed_seconds=time.monotonic()-started))
    except BaseException as error:
        atomic_json(folder / 'status.json', dict(state='failed', error=repr(error)))
        raise


def run(root, audit):
    children = []
    started = time.monotonic()
    try:
        for gpu, lane in zip((2,3,4,5), LANES):
            env = dict(os.environ, CUDA_VISIBLE_DEVICES=str(gpu), CUDA_DEVICE_ORDER='PCI_BUS_ID',
                PYTHONPATH=str(audit/'source_snapshot'), PYTHONDONTWRITEBYTECODE='1',
                OMP_NUM_THREADS='4', OPENBLAS_NUM_THREADS='4', MKL_NUM_THREADS='4')
            with (audit / (lane+'.log')).open('ab', buffering=0) as log:
                p = subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.reconstruction_fit_audit',
                    str(root),str(audit),'--lane',lane], cwd=audit/'source_snapshot',env=env,
                    stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            children.append((lane,p))
        atomic_json(audit/'status.json',dict(state='running',children=[dict(lane=l,pid=p.pid) for l,p in children]))
        while any(p.poll() is None for _,p in children):
            if any(p.poll() not in (None,0) for _,p in children):raise RuntimeError('Seen-window audit worker failed')
            if time.monotonic()-started>900:raise TimeoutError('Seen-window evaluation exceeded 15 minutes')
            time.sleep(3)
        if any(p.returncode!=0 for _,p in children):raise RuntimeError('Nonzero audit worker exit')
        source=json.loads((audit/'fixed/source_seen.json').read_text())['result']
        rows={}
        for lane in LANES:
            row={stage:json.loads((audit/lane/(stage+'.json')).read_text()) for stage in
                ('seen_initial','seen_final','small_seen_main_final','small_seen_diagnostic_final')}
            row['development_final']=json.loads((root/'main'/lane/'final_evaluation.json').read_text())
            row['seen_quantity_ratio_to_source']=row['seen_final']['result']['metrics']['quantity_btc']['rmse']/source['metrics']['quantity_btc']['rmse']
            rows[lane]=row
        report=dict(source_seen=source,source_small_seen=json.loads((audit/'fixed/source_small_seen.json').read_text())['result'],
            rows=rows,protocol='128 fixed windows selected from actual8192 training windows; same32 small-fit windows; no optimizer steps; development results reused',
            limitation='Single checkpoint/seed, finite training budget; train and development have different distributions, so compare each to its own uncompressed source baseline')
        atomic_json(audit/'comparison.json',report)
        atomic_json(audit/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started))
    except BaseException as error:
        atomic_json(audit/'status.json',dict(state='failed',error=repr(error)))
        raise
    finally:
        for _,p in children:
            if p.poll() is None:
                try:os.killpg(p.pid,signal.SIGTERM)
                except ProcessLookupError:pass
        for _,p in children:
            try:p.wait(timeout=10)
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL)


def prepare(root):
    audit=root/'analysis'/('fit_audit_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
    audit.mkdir(parents=True)
    freeze_sources(audit/'source_snapshot')
    old=json.loads((root/'source_snapshot/sha256.json').read_text())
    changed=[]
    for name,digest in old.items():
        if name.startswith('model/') and hashlib.sha256((audit/'source_snapshot'/name).read_bytes()).hexdigest()!=digest:
            changed.append(name)
    if changed:raise RuntimeError(f'Model implementation differs from original checkpoint sources: {changed}')
    plan=dict(training_run=str(root),purpose='Separate insufficient training fit from temporal generalization failure',
        checkpoints=['main/*/initial.pt','main/*/final.pt','small_fit/*/final.pt','initial.pt'],
        actual_seen_windows=128,small_fit_windows=32,gpus=[2,3,4,5],seed=42,optimizer_steps=0,
        model_source_changes=[],independent_test_used=False,price_units='canonical inverse_price; old diagnostic price conversion is not reused')
    atomic_json(audit/'plan.json',plan)
    atomic_json(audit/'status.json',dict(state='prepared'))
    project=Path(__file__).resolve().parents[2]
    remote_project=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')
    remote_root=remote_project/root.relative_to(project)
    remote_audit=remote_project/audit.relative_to(project)
    (audit/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'
        f'export PYTHONPATH="{remote_audit}/source_snapshot" PYTHONDONTWRITEBYTECODE=1\n'
        f'cd "{remote_audit}/source_snapshot"\n'
        f'exec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.reconstruction_fit_audit "{remote_root}" "{remote_audit}"\n')
    Path('/tmp/reconstruction_fit_audit_path').write_text(str(audit))
    print(audit,flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('root',type=Path);p.add_argument('audit',type=Path,nargs='?')
    p.add_argument('--prepare',action='store_true');p.add_argument('--lane',choices=LANES)
    a=p.parse_args()
    if a.prepare:prepare(a.root)
    elif a.lane:worker(a.root,a.audit,a.lane)
    else:run(a.root,a.audit)
