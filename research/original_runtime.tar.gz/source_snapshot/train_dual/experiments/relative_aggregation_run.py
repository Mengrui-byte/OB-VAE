"""Controlled relative-log reduction continuation, preserving source precision."""
import argparse
from copy import deepcopy
import html
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import numpy as np
import torch

from model.losses.log_relative_detail import RelativeDetailBookLoss,relative_log_quantity_huber
from train_dual.experiments import local_hint_run as shared
from train_dual.experiments.auxiliary_reconstruction_run import reviewed_candidate_decision,verify_detail_calibration_data
from train_dual.experiments.branch_precision_run import choose_precision_source,optimizer_factory as precision_optimizer
from train_dual.experiments.confirm_recall_goal import require_matching_replay
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.goal_evaluate import assess_file
from train_dual.experiments.log_relative_detail_run import run_cohort
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read,STYLE
from train_dual.experiments.price_safe_readout import file_hash
from train_dual.experiments.recall_goal_run import candidates,record,render as render_goal
from train_dual.experiments.region_task_run import gpu_free
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import atomic_save,freeze_sources,load_for_inference,seed_everything
from train_dual.util.hint_training import restore_regional_phase_adam
from train_dual.util.inherited_book_loss import inherited_book_loss
from train_dual.util.phase_training import tensor_digest
from train_dual.util.quantity_strata import evaluate_with_quantity_strata

MODULE='train_dual.experiments.relative_aggregation_run'
POWERS=dict(control=None,equal_bins=0.,sqrt_counts=.5,per_position=1.)
LABELS=dict(control='来源原目标',equal_bins='相对log等桶权',sqrt_counts='相对log按√计数',per_position='相对log按位置')
LOSS_KEYS=['regional_phase_config','stratified_quantity_loss_config','mid_lowpass_loss_config','local_detail_loss_config','relative_detail_loss_config','precision_policy_config','branch_precision_config']


def predecessor_live(queue,pid,proc=Path('/proc')):
    try:args=(proc/str(pid)/'cmdline').read_bytes().split(b'\0')
    except FileNotFoundError:return False
    return b'train_dual.experiments.branch_precision_run' in args and str(queue).encode() in args and b'--controller' in args


def loss_configuration(source,detail):
    old=deepcopy(source.get('relative_detail_loss_config'))
    if old is None:
        old=dict(relative_enabled=False,detail_enabled=False,relative_weight=0.,detail_weight=0.,epsilon_BTC=1e-4,radii=detail['radii'],detail_RMS=detail['RMS_scales'],relative_count_power=0.)
    if old.get('relative_count_power',0.)!=0.:raise ValueError('This protocol requires a historical equal-bin source')
    if old['relative_weight'] is None or old['detail_weight'] is None:raise ValueError('Actual source coefficients must be locked')
    return old


def lock_coefficient(root,weight,extra=None):
    if not math.isfinite(weight) or weight<=0:raise ValueError('Finite positive shared relative coefficient required')
    p=read(root/'plan.json');old=p['source_relative_config'];source_weight=old['relative_weight']
    if source_weight and weight!=source_weight:raise ValueError('Nonzero inherited relative coefficient must not be refit')
    for lane in p['checkpoint_extras']:
        if lane not in POWERS:raise ValueError('Unknown relative aggregation arm')
        alpha=POWERS[lane]
        c=deepcopy(old);c.update(relative_count_power=0. if alpha is None else alpha,
            relative_weight=source_weight if lane=='control' else weight,relative_enabled=bool(source_weight) if lane=='control' else True)
        p['checkpoint_extras'][lane]['relative_detail_loss_config']=c
    atomic_json(root/'plan.json',p)
    atomic_json(root/'aggregation_calibration.json',dict(state='complete',weight_calibration_locked=True,shared_relative_weight=weight,
        coefficient_mode='reuse_actual_source_weight' if source_weight else ('one_alpha0_training_only_calibration' if p.get('calibration_relative_arm','equal_bins')=='equal_bins' else 'one_per_position_training_only_calibration'),**(extra or {})))


def criterion(root,lane,device='cuda:0',*,calibrating=False):
    p=read(root/'plan.json');c=read(root/'aggregation_calibration.json');metadata=deepcopy(p['source_loss_metadata'])
    if calibrating:metadata['relative_detail_loss_config']=deepcopy(p['source_relative_config'])
    else:
        if c.get('state')!='complete' or not c.get('weight_calibration_locked'):raise ValueError('Shared relative coefficient is not locked')
        metadata['relative_detail_loss_config']=deepcopy(p['checkpoint_extras'][lane]['relative_detail_loss_config'])
    return inherited_book_loss(metadata,p,lane,read(root/'calibration.json'),read(root/'quantity_calibration.json'),read(root/'detail_calibration.json',{})).to(device)


def prepare_queue(goal,pid):
    prep=goal/'relative_aggregation_preparation_20261028';audit=read(prep/'audit.json');assert audit['state']=='passed'
    root=goal/'relative_aggregation_after_precision_20261028';root.mkdir();(root/'logs').mkdir()
    refroot=goal/'round_008_auxiliary/control';ref=assess_file(refroot/'step512_development.json',goal/'reference_evaluation.json')
    p=dict(queue_only=True,parent='round_010_branch_precision',parent_queue='branch_precision_after_relative_20261028',parent_pid=pid,
        preparation=prep.name,steps=2048,checkpoints=[256,512,1024,2048],max_seconds=43200,wait_seconds=46800,seed=42,
        powers=POWERS,gradient_norm_fraction=.25,price_reference_origin='round_008_auxiliary',price_reference_lane='control',price_reference_step=512,
        price_reference_checkpoint_sha256=file_hash(refroot/'step512.pt'),price_reference_evaluation_sha256=file_hash(refroot/'step512_development.json'),
        source_selection_price_guard_USDT=1.1*ref['price_rmse'],
        source_policy='All shared parent checkpoints, one actual source0 fallback and frozen round008/control512 reference; fixed joint violations plus1.10x strong-reference price violation. Selection is exploratory, not a causal cross-budget comparison.',
        coefficient_policy='If source has a nonzero relative coefficient, reuse it exactly and replace only its reduction. Otherwise calibrate once on alpha0 using existing8 train windows; same coefficient for all three added-relative arms.',
        controls='Same source parameters/all3Adam/RNG/data/order/augmentation/teacher/actual old objective and all coefficients/LR/clip/accumulation4/seed42/2048updates. Preserve source precision. Only relative point addition/reduction differs; signed-detail reduction and coefficient unchanged. No new model parameters.',
        candidate_policy='Native joint-gate candidates require checkpoint-bound schema2 full16 whole-book review before independent confirmation priority. No automatic Q2 or goal completion.',
        shape_contract=dict(input=[1,256,2,2048,2],latent=[1,64,128],output=[1,256,2,2048]),original_goal_contract_unchanged=True)
    atomic_json(root/'plan.json',p);atomic_json(root/'status.json',dict(state='prepared_not_started'));freeze_sources(root/'source_snapshot')
    project=Path(__file__).resolve().parents[2];remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 CUDA_DEVICE_ORDER=PCI_BUS_ID OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m {MODULE} "{remote}" --controller >> "{remote}/logs/controller.log" 2>&1\n')
    render(root);record(goal,'relative_aggregation_queue_prepared',wave=root.name,parent_pid=pid);return root


def prepare_actual(queue,selected,endpoint,*,root_name='round_011_relative_aggregation',labels=None,gpu_workers=None,force_precision=None):
    labels=LABELS if labels is None else labels
    if not labels or not set(labels)<=set(POWERS):raise ValueError('Declared aggregation arms required')
    if force_precision is not None and (set(force_precision)!=set(['encoder_fp32','decoders_fp32']) or any(type(v) is not bool for v in force_precision.values())):
        raise ValueError('Explicit boolean precision policy required')
    goal=queue.parent;study=read(queue/'plan.json');parent=goal/selected.get('source_origin',study['parent']);old=read(parent/'plan.json')
    logprep=goal/'log_relative_detail_preparation_20261028';identity=verify_detail_calibration_data(parent,logprep)
    source=parent/'source.pt' if selected['step']==0 else parent/selected['lane']/f"step{selected['step']}.pt"
    payload=torch.load(source,map_location='cpu',weights_only=False,mmap=True)
    assert payload['epoch_boundary'] and len(payload['optimizer']['param_groups'])==3
    if selected['step']:assert payload['step']==selected['step']
    assert not payload['regional_phase_config']['use_shape'] and not payload['regional_phase_config']['use_mass']
    assert not any(payload.get('precision_policy_config',{}).values())
    model,_=load_for_inference(source,'cpu');optimizer=restore_regional_phase_adam(model,payload['optimizer'],old['original_parameter_names'])
    assert optimizer.state_dict()['param_groups']==payload['optimizer']['param_groups']
    relative=loss_configuration(payload,read(logprep/'detail_calibration.json'))
    root=goal/root_name;root.mkdir()
    for name in ['data','logs','seen','unseen',*labels]:(root/name).mkdir()
    for split in ['seen','unseen']:
        for lane in labels:(root/split/lane).mkdir()
    os.link(source,root/'source.pt')
    if force_precision is None:os.link(source,root/'initial.pt')
    else:
        # Never edit a hard-linked historical checkpoint to set policy metadata.
        initial={k:deepcopy(payload[k]) for k in ['format_version','unified_vae_config','config','local_hint_config','model',*LOSS_KEYS] if k in payload}
        initial['branch_precision_config']=deepcopy(force_precision);atomic_save(initial,root/'initial.pt')
    for name in ['teacher.pt','calibration.json','train_indices.npy','val_indices.npy','seen_indices.npy','unseen_indices.npy','quantity_calibration_indices.npy','plotly.min.js']:
        os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    from shutil import copy2
    copy2(parent/'quantity_calibration.json',root/'quantity_calibration.json')
    if (parent/'detail_calibration.json').exists():copy2(parent/'detail_calibration.json',root/'detail_calibration.json')
    keys=['train','development','independent_test_untouched','window_size','stride','normalization','model_config','local_hint_config','original_parameter_names','objective','source_FP_rule','augmentation','lr','weight_decay','clip_grad','batch_size','accumulation','seed','beta','sample','input_shape','latent_shape','output_shape','precision']
    p={k:deepcopy(old[k]) for k in keys if k in old};source_lane='control' if selected['step']==0 else selected['lane'];spec=old['lanes'][source_lane]
    metadata={k:deepcopy(payload[k]) for k in LOSS_KEYS if k in payload}
    policy=deepcopy(force_precision if force_precision is not None else payload.get('branch_precision_config',dict(encoder_fp32=False,decoders_fp32=False)))
    extras={lane:dict(deepcopy(metadata),branch_precision_config=deepcopy(policy),relative_detail_loss_config=deepcopy(relative),
        training_numeric_policy=dict(deepcopy(payload.get('training_numeric_policy',{})),branch_precision_config=deepcopy(policy)),inference_numeric_policy=deepcopy(payload.get('inference_numeric_policy',{}))) for lane in labels}
    p.update(experiment='相对log损失聚合：原目标/等桶/√计数/位置平均',labels=labels,lanes={lane:deepcopy(spec) for lane in labels},
        source_loss_metadata=metadata,source_relative_config=relative,source_selection=selected,selection_common_endpoint=endpoint,
        source_sha256=file_hash(source),source_steps=payload['source_steps']+payload['step'],source_evaluation_relative=f"../{parent.name}/{source_lane}/step{selected['step']}_development.json",
        source_checkpoint_relative=str(source.relative_to(goal)),initial_model_sha256=tensor_digest(model),checkpoint_extras=extras,
        steps=study['steps'],checkpoints=study['checkpoints'],max_seconds=study['max_seconds'],gradient_norm_fraction=study['gradient_norm_fraction'],
        gpu_workers=gpu_workers if gpu_workers is not None else [[gpu,lane] for gpu,lane in zip([2,3,4,5],labels)],worker_module=MODULE,controls=study['controls'],
        relative_aggregation_ablation=True,loss_variant='relative_log_count_power',new_model_parameters=0,quantity_strata_metrics_schema=2,original_goal_contract_unchanged=True,
        parent_price_rmse_USDT=selected['price_rmse'],parent_price_limit_USDT=1.1*selected['price_rmse'],
        preview_descriptions={lane:'完整256分钟、唯一8192Gaussian；只改变相对逐点项的聚合，精度策略见协议。' for lane in labels})
    assert p['input_shape']==[1,256,2,2048,2] and p['latent_shape']==[1,64,128] and p['output_shape']==[1,256,2,2048]
    atomic_json(root/'plan.json',p);atomic_json(root/'calibration_data_identity.json',identity)
    atomic_json(root/'aggregation_calibration.json',dict(state='needs_actual_GPU_calibration',weight_calibration_locked=False,optimizer_updates=0))
    for split in ['seen','unseen']:
        atomic_json(root/split/'plan.json',dict(p,preview_descriptions={lane:'训练年代诊断，非独立测试。' for lane in labels}));os.link(root/'plotly.min.js',root/split/'plotly.min.js')
    for lane in labels:criterion(root,lane,'cpu',calibrating=True)
    atomic_json(root/'status.json',dict(state='prepared_requires_actual_GPU_calibration'));freeze_sources(root/'source_snapshot');render(root);return root


def calibrate(root):
    torch.set_num_threads(4);seed_everything(42);strict_precision();p=read(root/'plan.json')
    assert not read(root/'aggregation_calibration.json')['weight_calibration_locked'] and file_hash(root/'source.pt')==p['source_sha256']
    model,norm=load_for_inference(root/'initial.pt','cuda:0');model.train();before=tensor_digest(model)
    for name in p.get('frozen_modules',[]):model.get_submodule(name).requires_grad_(False).eval()
    teacher,tn=load_for_inference(root/'teacher.pt','cuda:0');teacher.eval().requires_grad_(False);teacher_before=tensor_digest(teacher)
    calibration_lane='control' if 'control' in p['labels'] else next(iter(p['labels']))
    gradient_module=p.get('calibration_gradient_module','encoder.mu')
    objective=criterion(root,calibration_lane,calibrating=True);data=dataset(root,'train')
    parameters=[t for t in model.get_submodule(gradient_module).parameters() if t.requires_grad]
    if not parameters:raise ValueError('Calibration target must contain trainable parameters')
    squares={name:[] for name in ['base','equal_bins','sqrt_counts','per_position']};cosines={name:[] for name in list(squares)[1:]}
    indices=np.load(root/'quantity_calibration_indices.npy');assert len(indices)==8 and set(indices.tolist())<=set(np.load(root/'train_indices.npy').tolist())
    for number,index in enumerate(indices):
        raw={k:v.unsqueeze(0) for k,v in data[int(index)].items()};assert list(raw['data'].shape)==p['input_shape']
        offset=int(data.base.starts[int(index)]);assert np.all(np.diff(data.base.times[offset:offset+256]//60000000)==1)
        target=shared.teacher_local(teacher,tn,raw);batch=norm.prepare(raw,'cuda:0');seen=[]
        hooks=[decoder.register_forward_pre_hook(lambda m,args:seen.append(args[0])) for decoder in [model.price_decoder,model.volume_decoder]]
        with torch.autocast('cuda',dtype=torch.bfloat16):out=call(model,batch,False)
        for hook in hooks:hook.remove()
        assert seen[0] is seen[1] is out['z'] and list(out['z'].shape)==p['latent_shape'] and list(out['volume'].shape)==p['output_shape']
        values=objective(out,batch,teacher_local=target);terms=dict(base=values['loss'])
        for lane,alpha in list(POWERS.items())[1:]:
            terms[lane]=relative_log_quantity_huber(out['volume'],batch['volume'],batch['mask'],epsilon=p['source_relative_config']['epsilon_BTC'],count_power=alpha)[0]
        gradients={}
        for n,(name,term) in enumerate(terms.items()):
            grad=torch.autograd.grad(term,parameters,retain_graph=n<len(terms)-1);assert all(torch.isfinite(g).all() for g in grad)
            gradients[name]=grad;squares[name].append(sum(float(g.float().square().sum()) for g in grad))
        for name in cosines:
            dot=sum(float((a.float()*b.float()).sum()) for a,b in zip(gradients['base'],gradients[name]));den=(squares['base'][-1]*squares[name][-1])**.5
            cosines[name].append(dot/den if den else None)
        atomic_json(root/'gradient_calibration_progress.json',dict(windows=number+1,total=8,optimizer_updates=0))
    norms={name:float(np.mean(v))**.5 for name,v in squares.items()};assert all(v>0 and math.isfinite(v) for v in norms.values())
    assert tensor_digest(model)==before and tensor_digest(teacher)==teacher_before and all(t.grad is None for t in model.parameters())
    calibration_arm=p.get('calibration_relative_arm','equal_bins')
    if calibration_arm not in ['equal_bins','sqrt_counts','per_position']:raise ValueError('Unknown calibration reduction')
    weight=p['source_relative_config']['relative_weight'] or p['gradient_norm_fraction']*norms['base']/norms[calibration_arm]
    extra=dict(gradient_module=gradient_module,calibration_relative_arm=calibration_arm,gradient_root_mean_square_L2_norms=norms,per_window_gradient_cosines=cosines,
        training_indices=indices.tolist(),student_forwards=8,teacher_feature_extractions=8,optimizer_updates=0,source_and_teacher_unchanged=True,
        actual_input=p['input_shape'],actual_latent=p['latent_shape'],actual_output=p['output_shape'],shared_single_Z=True)
    if gradient_module=='encoder.mu':extra['mu_head_root_mean_square_L2_norms']=norms
    lock_coefficient(root,weight,extra)
    assert file_hash(root/'source.pt')==p['source_sha256'];render(root)


def startup_relation(rows,configs):
    base=rows['control'];old=base['losses'];old_weight=configs['control']['relative_weight']
    unchanged=['pre_relative_detail_loss','signed_log_quantity_detail',*[f'relative_log_bin{i}' for i in range(6)],*[f'relative_log_bin{i}_count' for i in range(6)]]
    for lane,row in rows.items():
        assert row['training_indices']==base['training_indices'] and row['edits']==base['edits']
        assert all(row['losses'][key]==old[key] for key in unchanged)
        expected=old['loss']-old_weight*old['relative_quantity_log']+configs[lane]['relative_weight']*row['losses']['relative_quantity_log']
        assert math.isclose(row['losses']['loss'],expected,rel_tol=5e-6,abs_tol=5e-6)


def audit_startup(root):
    p=read(root/'plan.json');rows={lane:read(root/lane/'step1_data_audit.json',{}) for lane in LABELS}
    if not all(rows.values()) or not all((root/lane/'step8_gradient_audit.json').exists() for lane in LABELS):return False
    startup_relation(rows,{lane:p['checkpoint_extras'][lane]['relative_detail_loss_config'] for lane in LABELS})
    old=torch.load(root/'source.pt',map_location='cpu',weights_only=False,mmap=True);source=read(root/p['source_evaluation_relative'])['result']
    for lane in LABELS:
        assert read(root/lane/'actual_shape_contract.json')['passed'] and read(root/lane/'actual_branch_precision_audit.json')['passed']
        require_matching_replay(read(root/lane/'step0_development.json')['result'],source)
        new=torch.load(root/lane/'step0.pt',map_location='cpu',weights_only=False,mmap=True)
        assert old['model'].keys()==new['model'].keys()
        for name,value in old['model'].items():torch.testing.assert_close(value,new['model'][name],rtol=0,atol=0)
        assert new['relative_detail_loss_config']==p['checkpoint_extras'][lane]['relative_detail_loss_config']
        for key,value in p['source_loss_metadata'].items():
            if key!='relative_detail_loss_config':assert new[key]==value
        assert old['optimizer']['param_groups']==new['optimizer']['param_groups'] and old['optimizer']['state'].keys()==new['optimizer']['state'].keys()
        for index,state in old['optimizer']['state'].items():
            for key,value in state.items():
                if torch.is_tensor(value):torch.testing.assert_close(value,new['optimizer']['state'][index][key],rtol=0,atol=0)
                else:assert value==new['optimizer']['state'][index][key]
    atomic_json(root/'startup_control_audit.json',dict(passed=True,same_source_all3Adam_raw_order_and_inherited_precision=True,
        original_objective_or_single_relative_reduction_replacement_verified=True,native_FP32_step0_exact_all4=True,full256_unique8192_singleZ_verified=True));return True


def checkpoint_analysis(root,step):
    target=root/f'common{step}_analysis.json'
    if target.exists() or not all((root/lane/f'step{step}_development.json').exists() for lane in LABELS):return
    rows=[r for r in candidates(root,root.parent/'reference_evaluation.json') if r['step']==step]
    atomic_json(target,dict(step=step,design='relative_log_count_power',rows=rows));record(root.parent,'relative_aggregation_common_checkpoint',wave=root.name,step=step,rows=rows)


def render(root):
    p=read(root/'plan.json');s=read(root/'status.json',{});text='<h1>相对log挂量：等桶、√计数、位置平均</h1>'
    if p.get('queue_only'):text+='<p>等待完整分支精度四组正常结束与联合候选审查，随后选择一个共同来源。当前未启动聚合训练。</p>'
    else:
        text+='<p>完整256分钟、双侧2048档、唯一8192Gaussian。四组保留来源模型、精度、三组Adam/RNG及全部旧目标。若来源已有相对项则替换其归约、复用非零系数；否则只拟合一次共享系数，三个新相对项组共用。</p><table><tr><th>组</th><th>训练步</th><th>原生评估步</th><th>召回</th><th>精确率</th><th>价格RMSE USDT</th></tr>'
        for lane,label in p['labels'].items():
            paths=sorted((root/lane).glob('step*_development.json'),key=lambda f:int(f.name.split('_')[0][4:]));latest=paths[-1] if paths else None
            cells=[label,read(root/lane/'progress.json',{}).get('step',0)]
            if latest:
                a=assess_file(latest,root.parent/'reference_evaluation.json');cells += [int(latest.name.split('_')[0][4:]),f"{a['recall100']:.2%}",f"{a['precision100']:.2%}" if a['precision100'] is not None else '—',f"{a['price_rmse']:.4f}"]
            else:cells+=['待评估']*4
            text+='<tr>'+''.join('<td>'+html.escape(str(x))+'</td>' for x in cells)+'</tr>'
        text+='</table><p>仅比较共同更新预算，另报耗时。α=0/.5/1不改变逐桶误差定义。只有来源已有非零相对项时，control和equal_bins为确定性重复控制。</p>'
    text+='<p>状态：'+html.escape(str(s))+'</p><p>Q1反复用于开发，非独立测试；不自动读取Q2或宣布成功。大小单、峰宽和价格共同验收。</p><p><a href="plan.json">协议</a> · <a href="status.json">状态</a> · <a href="../">目标总览</a></p>'
    (root/'index.html').write_text('<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="30"><style>'+STYLE+'</style>'+text)


def controller(queue):
    p=read(queue/'plan.json');goal=queue.parent;parent=goal/p['parent'];parent_queue=goal/p['parent_queue'];begin=time.monotonic()
    while True:
        state=read(parent/'status.json',{});qs=read(parent_queue/'status.json',{});live=predecessor_live(parent_queue,p['parent_pid'])
        if state.get('state')=='failed' or qs.get('state')=='failed':raise RuntimeError('Parent failed; do not train from partial results')
        if not live:
            if qs.get('state','').startswith('not_run_'):
                atomic_json(queue/'status.json',dict(state='not_run_parent_candidate_requires_confirmation'));render(queue);return
            if state.get('state')=='complete':break
            raise RuntimeError('Exact parent controller missing without successful terminal state')
        if time.monotonic()-begin>p['wait_seconds']:raise TimeoutError('13hour parent wait ceiling')
        atomic_json(queue/'status.json',dict(state='verified_wait_parent',pid=os.getpid(),parent_pid=p['parent_pid'],parent_created=(parent/'plan.json').exists()));render(queue);time.sleep(20)
    assert read(parent/'startup_control_audit.json')['passed']
    assert all(read(parent/lane/'status.json')['state'] in ['complete','budget_complete'] for lane in read(parent/'plan.json')['labels'])
    rows=candidates(parent,goal/'reference_evaluation.json');qualified=[row for row in rows if row['pass']]
    existing=read(goal/'candidate_for_confirmation.json',{})
    if existing and assess_file(Path(existing['evaluation']),goal/'reference_evaluation.json')['pass']:qualified.append(existing)
    if qualified:
        candidate=max(qualified,key=lambda row:(row['recall100'],-row['price_rmse']));decision=reviewed_candidate_decision(goal,candidate)
        while decision is None:
            if time.monotonic()-begin>p['wait_seconds']:raise TimeoutError('Autonomous whole-book review pending')
            atomic_json(queue/'status.json',dict(state='waiting_whole_book_review',pid=os.getpid(),candidate=candidate));render(queue);time.sleep(20);decision=reviewed_candidate_decision(goal,candidate)
        if decision:
            atomic_json(queue/'status.json',dict(state='not_run_accepted_candidate_requires_confirmation',candidate=candidate));render(queue);return
    refroot=goal/p['price_reference_origin'];refpath=refroot/p['price_reference_lane']/f"step{p['price_reference_step']}_development.json"
    assert file_hash(refpath)==p['price_reference_evaluation_sha256'] and file_hash(refroot/p['price_reference_lane']/f"step{p['price_reference_step']}.pt")==p['price_reference_checkpoint_sha256']
    reference=dict(lane=p['price_reference_lane'],step=p['price_reference_step'],source_origin=refroot.name,checkpoint=str(refroot/p['price_reference_lane']/f"step{p['price_reference_step']}.pt"),evaluation=str(refpath),**assess_file(refpath,goal/'reference_evaluation.json'))
    selected,endpoint,guard=choose_precision_source(rows,tuple(read(parent/'plan.json')['labels']),parent.name,reference)
    atomic_json(queue/'source_selection.json',dict(selected=selected,all_rows=rows,common_endpoint=endpoint,price_reference=reference,source_selection_price_guard_USDT=guard,original_goal_contract_unchanged=True))
    while any(gpu_free().get(g,0)<47000 for g in [2,3,4,5]):
        if time.monotonic()-begin>p['wait_seconds']:raise TimeoutError('GPU release wait ceiling')
        atomic_json(queue/'status.json',dict(state='verified_wait_GPU_release',pid=os.getpid()));render(queue);time.sleep(10)
    root=prepare_actual(queue,selected,endpoint);atomic_json(queue/'status.json',dict(state='calibrating',pid=os.getpid(),wave=root.name));render(queue)
    env=dict(os.environ,CUDA_VISIBLE_DEVICES='2',PYTHONPATH=str(root/'source_snapshot'))
    with (root/'logs/calibration.log').open('ab',buffering=0) as log:
        child=subprocess.Popen([sys.executable,'-u','-m',MODULE,str(root),'--calibrate'],cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    start=time.monotonic()
    try:
        while child.poll() is None:
            if time.monotonic()-start>3600:raise TimeoutError('Onehour training-only gradient calibration ceiling')
            atomic_json(root/'status.json',dict(state='calibrating',controller_pid=os.getpid(),pid=child.pid));render(root);time.sleep(10)
        if child.returncode:raise RuntimeError('Training-only gradient calibration failed')
    finally:
        if child.poll() is None:os.killpg(child.pid,signal.SIGTERM)
    assert read(root/'aggregation_calibration.json')['weight_calibration_locked']
    atomic_json(queue/'status.json',dict(state='running',pid=os.getpid(),wave=root.name));render(queue)
    atomic_json(goal/'status.json',dict(state='running_relative_aggregation',wave=root.name))
    run_cohort(root,worker_module=MODULE,startup_auditor=audit_startup,renderer=render,analyzer=checkpoint_analysis)
    new=candidates(root,goal/'reference_evaluation.json');old=read(goal/'candidates.json',{}).get('rows',[])
    atomic_json(goal/'candidates.json',dict(rows=[row for row in old if row.get('experiment')!=root.name]+[dict(row,experiment=root.name) for row in new]))
    atomic_json(goal/'status.json',dict(state='relative_aggregation_complete_requires_joint_review',wave=root.name,goal_achieved=False))
    atomic_json(queue/'status.json',dict(state='complete',wave=root.name,goal_automatically_completed=False));render(queue);render_goal(goal)
    record(goal,'relative_aggregation_complete',wave=root.name,next='Joint whole-book and original gates review, frozen candidate and independent confirmation if eligible; no automatic Q2.')


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('root',type=Path);parser.add_argument('--prepare',action='store_true');parser.add_argument('--parent-pid',type=int);parser.add_argument('--controller',action='store_true');parser.add_argument('--calibrate',action='store_true');parser.add_argument('--lane',choices=list(LABELS));args=parser.parse_args();root=args.root.resolve()
    def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        if args.prepare:
            if not args.parent_pid:parser.error('--parent-pid required')
            print(prepare_queue(root,args.parent_pid),flush=True)
        elif args.controller:controller(root)
        elif args.calibrate:calibrate(root)
        elif args.lane:
            shared.evaluate=evaluate_with_quantity_strata
            shared.worker(root,args.lane,objective_factory=criterion,optimizer_factory=lambda model,state,names:precision_optimizer(root,args.lane,model,state,names))
        else:parser.error('Specify a mode')
    except BaseException as error:
        if not args.prepare:atomic_json((root/args.lane if args.lane else root)/'status.json',dict(state='failed',pid=os.getpid(),error=repr(error)))
        raise


if __name__=='__main__':main()
