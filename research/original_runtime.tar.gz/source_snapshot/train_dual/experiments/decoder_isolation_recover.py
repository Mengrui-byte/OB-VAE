"""Preserve failed artifacts; resume unchanged model/math from saved boundaries."""
import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import re

from train_dual.experiments.decoder_isolation_run import read,refresh_report
from train_dual.experiments.long_worker import atomic_json
from train_dual.util.checkpoint import freeze_sources


def prepare(parent):
    parent=parent.resolve();project=Path(__file__).resolve().parents[2]
    root=project/'recons'/('decoder_isolation_recovery_'+datetime.now().strftime('%Y%m%d_%H%M%S'));root.mkdir()
    for name in ['data','logs']:(root/name).mkdir()
    for name in ['initial.pt','initial_expected.json','train_indices.npy','val_indices.npy','seen_indices.npy','latent_fit_indices.npy','plotly.min.js','data_contract.json','startup_control_audit.json']:
        os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    plan=read(parent/'plan.json');steps={'original_warm':512,'original_fresh':512,'query_fresh':1024,'latent_fit':512}
    retained=[];reference_rows={};recovery={}
    for lane,step in steps.items():
        folder=root/lane;folder.mkdir();old=parent/lane
        checkpoint=old/(f'step{step}_codes.pt' if lane=='latent_fit' else f'step{step}.pt')
        if not checkpoint.exists():raise FileNotFoundError(checkpoint)
        for path in old.iterdir():
            if not path.is_file() or path.suffix=='.tmp':continue
            match=re.match(r'step(\d+)(?:_|\.)',path.name)
            include=match is not None and int(match.group(1))<=step
            include=include or path.name in ['initial_contract.json','initial_replay.json','first_step_data.json','first_step_gradient_norms.json','first_update_audit.json','trainable_modules.json']
            if include:
                os.link(path,folder/path.name);retained.append(str(path.relative_to(parent)))
        progress=read(old/'progress.json',{})
        recovery[lane]=dict(checkpoint_step=step,last_logged_step=progress.get('step'),last_logged_active_seconds=progress.get('elapsed_seconds'),checkpoint_sha256=hashlib.sha256(checkpoint.read_bytes()).hexdigest(),
            discarded_logged_updates=max(0,progress.get('step',step)-step),note='Updates after checkpoint must replay; exact unlogged tail count may be larger. Comparison uses retained optimizer-step endpoints.')
        source=old/'progress.jsonl'
        if source.exists():
            rows=[json.loads(line) for line in source.read_text().splitlines() if line.strip()]
            future=[row for row in rows if row['step']>step]
            if future:
                row=future[0];reference_rows[lane]={str(row['step']):row}
    original_status=read(parent/'status.json')
    plan.update(parent=str(parent),recovery_parent=str(parent),resume_steps=steps,resume_reference_rows=reference_rows,
        recovery=recovery,max_seconds=int(plan['max_seconds']-max(v['last_logged_active_seconds'] or 0 for v in recovery.values())),
        recovery_changes=['Optional report JSON read removes stat/open race; malformed existingJSON stillraises',
            'Report exceptions are explicitly logged/retried and do not terminate compute',
            'Restore model/optimizer/code state, exposures,RNG andepoch-boundary sampler order; no new model/loss/data settings'],
        original_failure=original_status,
        budget_accounting='Keep original2048decoder/1024latent endpoints. Repeated unsaved work disclosed in recovery records; no claim of equal physical compute after interruption. Ceiling deducts prior logged active seconds; idle pause excluded.')
    plan['report']['title']='Decoder隔离实验·检查点恢复运行'
    plan['report']['introduction']+=' 原运行因报告读取并发错误中断；本目录保留已完成结果并从512/512/1024步恢复三个Decoder，Z拟合从512步恢复，模型、损失和数据均不改动。'
    (root/'design.md').write_text((parent/'design.md').read_text()+'\n\n## 报告故障后的恢复\n\n'+plan['budget_accounting']+'\n\n'+json.dumps(recovery,ensure_ascii=False,indent=2)+'\n')
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared_recovery'))
    atomic_json(root/'recovery_manifest.json',dict(parent=str(parent),original_failure=original_status,resume_steps=steps,rows=recovery,retained_artifacts=retained,immutable_original_source_snapshot=True))
    current=freeze_sources(root/'source_snapshot');old_hashes=read(parent/'source_snapshot/sha256.json')
    old_models={k:v for k,v in old_hashes.items() if k.startswith('model/')}
    new_models={k:v for k,v in current.items() if k.startswith('model/')}
    if old_models!=new_models:raise RuntimeError('Model sources changed; exact recovery would be invalid')
    atomic_json(root/'model_source_identity.json',dict(passed=True,model_files=len(old_models),all_model_hashes_unchanged=True))
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'
        f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\n'
        f'cd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.decoder_isolation_run "{remote}"\n')
    refresh_report(root);Path('/tmp/decoder_isolation_path').write_text(str(root));print(root,flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('parent',type=Path);args=p.parse_args();prepare(args.parent)
