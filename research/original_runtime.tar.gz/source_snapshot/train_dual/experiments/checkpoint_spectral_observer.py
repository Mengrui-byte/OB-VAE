"""CPU-only spectral/whole-book review of saved frozen-price pilot checkpoints."""
import argparse
import hashlib
import html
import json
import os
from pathlib import Path
import time

import numpy as np

from train_dual.experiments.goal_evaluate import assess_file
from train_dual.util.spectral_alignment import spatial_band_alignment


MODULE = 'train_dual.experiments.checkpoint_spectral_observer'
BANDS = [(1, 16), (16, 64), (64, 256), (256, 1024), (1024, 2048)]


def read(path, default=None):
    try: return json.loads(path.read_text())
    except FileNotFoundError: return default


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    temp.replace(path)


def ready(folder, step):
    status = read(folder / 'evaluation_status.json', {})
    finished = status.get('step', -1) > step or (status.get('step') == step and status.get('state') == 'complete')
    return finished and all((folder / f'step{step}_{name}').exists()
                            for name in ['development.json', 'profiles.npz'])


def worker_live(parent, lane, pid):
    try: args = Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0')
    except FileNotFoundError: return False
    return (b'train_dual.experiments.idle_aggregation_pilot' in args
            and str(parent).encode() in args and b'--lane' in args and lane.encode() in args)


def prepare(parent):
    from train_dual.util.checkpoint import freeze_sources
    assert read(parent / 'startup_control_audit.json')['passed']
    root = parent.parent / 'frozen_price_spectral_observer_20261029'
    root.mkdir()
    (root / 'logs').mkdir()
    write(root / 'plan.json', dict(parent=parent.name, workers=dict(control=47724, per_position=47725),
        checkpoints=[0, 256, 512], wait_seconds=10800, epsilon_BTC=1e-4, bands=BANDS,
        scope='Read-only CPU review of saved native predictions. Full16 gates and quantity bins; '
              'spectra use only3fixed full256frame previews. No training/inference/Q2; no new acceptance thresholds.'))
    write(root / 'status.json', dict(state='prepared_not_started'))
    freeze_sources(root / 'source_snapshot')
    render(root)
    return root


def spectral_case(path, reference, bands, epsilon):
    with np.load(path) as data:
        assert data['truth'].shape == data['prediction'].shape == (3, 256, 2, 2048, 2)
        assert data['mask'].shape == (3, 256, 2, 2048) and data['indices'].tolist() == [0, 235, 505]
        assert data['mask'].all(), 'This comparison expects the same complete dense profiles'
        for key, value in reference.items(): np.testing.assert_array_equal(data[key], value)
        target = data['truth'][..., 1].astype(np.float64)
        prediction = data['prediction'][..., 1].astype(np.float64)
        assert (target > 0).all() and (prediction >= 0).all()
        raw = spatial_band_alignment(target.reshape(-1, 2048), prediction.reshape(-1, 2048), bands)
        log = spatial_band_alignment(np.log(target.reshape(-1, 2048) + epsilon),
                                     np.log(prediction.reshape(-1, 2048) + epsilon), bands)
        individual = []
        for index, t, p in zip(data['indices'], target, prediction):
            individual.append(dict(original_index=int(index), **spatial_band_alignment(
                np.log(t.reshape(512, 2048) + epsilon), np.log(p.reshape(512, 2048) + epsilon), bands[-2:])))
    return dict(raw_BTC=raw, physical_log_BTC=log, individual_window_log_detail=individual)


def report(root, step):
    p = read(root / 'plan.json'); parent = root.parent / p['parent']; destination = root / f'step{step}'
    if (destination / 'result.json').exists(): return
    assert all(ready(parent / lane, step) for lane in p['workers'])
    initial = read(parent / 'control/step0_development.json')['result']
    with np.load(parent / 'control/step0_profiles.npz') as data:
        reference = {key: data[key].copy() for key in ['truth', 'mask', 'indices', 'time']}
    rows = {}
    for lane in p['workers']:
        evaluation = parent / lane / f'step{step}_development.json'; profile = parent / lane / f'step{step}_profiles.npz'
        result = read(evaluation)['result']
        assert result['windows'] == initial['windows'] == 16
        assert result['window_indices'] == initial['window_indices']
        assert result['quantity_strata_schema_version'] == initial['quantity_strata_schema_version'] == 2
        for key in ['price_usdt', 'temporal_mid_1_minutes_usdt_per_minute']:
            assert result['metrics'][key] == initial['metrics'][key], ('Frozen native price changed', lane, step)
        assert [v['count'] for v in result['quantity_strata']] == [v['count'] for v in initial['quantity_strata']]
        rows[lane] = dict(native_gates=assess_file(evaluation, root.parent / 'reference_evaluation.json'),
            quantity_strata=result['quantity_strata'], native_price_metrics_exact=True,
            spectral=spectral_case(profile, reference, [tuple(x) for x in p['bands']], p['epsilon_BTC']),
            evaluation_relative=str(evaluation.relative_to(root.parent)), evaluation_sha256=sha(evaluation),
            profiles_relative=str(profile.relative_to(root.parent)), profiles_sha256=sha(profile))
    destination.mkdir(exist_ok=True)
    result = dict(state='complete_read_only_checkpoint_review', step=step, rows=rows, scope=p['scope'],
        metric_definition='Real DCT-II coefficient alignment cosine, not Pearson correlation. '
                          'Energy and cosine are secondary diagnostics, never new goal gates. '
                          'Truth-fitted scalar metrics are diagnostic only; no output correction applied.',
        observer_sha256=sha(Path(__file__)), metric_sha256=sha(Path(__file__).parents[1] / 'util/spectral_alignment.py'),
        neural_forward_calls=0, optimizer_updates=0, independent_test_used=False)
    write(destination / 'result.json', result)
    render(root)
    print(json.dumps(dict(reviewed_step=step, native_gates={k: v['native_gates'] for k, v in rows.items()})), flush=True)


def render(root):
    plan = read(root / 'plan.json'); parts = [
        '<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="30">',
        '<title>冻结价格：完整重建与频带细节</title><style>body{font:16px/1.7 system-ui;max-width:1250px;margin:30px auto;padding:20px}'
        'table{border-collapse:collapse;width:100%;font-size:14px}th,td{border:1px solid #ddd;padding:8px}</style>',
        '<h1>冻结价格：完整重建与频带细节</h1>',
        '<p>两组同一源模型、精度、Adam/RNG、数据和512更新预算，只比较新增逐位置log相对误差。'
        '总体指标来自16个固定开发窗口；频带分析仅来自3个完整256分钟预览。未使用保留确认集。</p>']
    for step in plan['checkpoints']:
        result = read(root / f'step{step}/result.json')
        if result is None: continue
        parts.append(f'<h2>{step}步</h2><table><tr><th>组</th><th>价格RMSE USDT</th><th>大单召回</th><th>精确率</th>'
                     '<th>小单预测均值BTC</th><th>小单误差≤20%</th><th>联合通过</th></tr>')
        for lane, row in result['rows'].items():
            gates = row['native_gates']; small = row['quantity_strata'][0]
            values = [lane, f"{gates['price_rmse']:.4f}", f"{gates['recall100']:.2%}", f"{gates['precision100']:.2%}",
                      f"{small['prediction_mean_BTC']:.6f}", f"{small['within20percent']:.2%}", gates['pass']]
            parts.append('<tr>' + ''.join('<td>' + html.escape(str(x)) + '</td>' for x in values) + '</tr>')
        parts.append('</table><p>真实小单均值约0.003577 BTC；价格与分钟mid变化的原生指标均须精确保持来源值。</p>')
        for domain, title in [('raw_BTC', '原始数量'), ('physical_log_BTC', '物理log数量')]:
            parts.append('<h3>' + title + '</h3><table><tr><th>组</th><th>DCT系数区间</th><th>预测/真实细节能量</th><th>对应系数对齐余弦</th></tr>')
            for lane, row in result['rows'].items():
                for band in row['spectral'][domain]['bands']:
                    values = [lane, f"[{band['coefficient_start']},{band['coefficient_stop_exclusive']})",
                              f"{band['prediction_to_target_energy_ratio']:.6f}", f"{band['coefficient_alignment_cosine']:.6f}"]
                    parts.append('<tr>' + ''.join('<td>' + html.escape(v) + '</td>' for v in values) + '</tr>')
            parts.append('</table>')
        parts.append(f'<p><a href="step{step}/result.json">该检查点完整数值与来源指纹</a></p>')
    parts.append('<p>对齐余弦不是Pearson相关；能量相同不等于位置正确。次要诊断不改变原联合目标。'
                 '读取真值拟合的频带增益仅用于分析，没有用于生成订单簿。</p>'
                 f'<p><a href="../{plan["parent"]}/">训练进度与逐档线条图</a> · <a href="status.json">观察进度</a></p>')
    temp = root / 'index.html.tmp'; temp.write_text(''.join(parts)); temp.replace(root / 'index.html')


def watch(root):
    p = read(root / 'plan.json'); parent = root.parent / p['parent']; start = time.monotonic()
    while True:
        for step in p['checkpoints']:
            if all(ready(parent / lane, step) for lane in p['workers']): report(root, step)
        complete = [step for step in p['checkpoints'] if (root / f'step{step}/result.json').exists()]
        live = [pid for lane, pid in p['workers'].items() if worker_live(parent, lane, pid)]
        if len(complete) == len(p['checkpoints']):
            write(root / 'status.json', dict(state='complete', pid=os.getpid(), reviewed_steps=complete)); render(root); return
        for lane, pid in p['workers'].items():
            if not worker_live(parent, lane, pid):
                assert read(parent / lane / 'status.json', {}).get('state') == 'complete', ('Owned worker missing', lane, pid)
                assert ready(parent / lane, 512), ('Worker ended without full512 evaluation', lane)
        assert time.monotonic() - start < p['wait_seconds'], 'Threehour observer ceiling'
        write(root / 'status.json', dict(state='verified_wait_checkpoint', pid=os.getpid(),
            verified_live_worker_pids=live, reviewed_steps=complete, neural_forward_calls=0, optimizer_updates=0))
        render(root); time.sleep(20)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path); parser.add_argument('--prepare', action='store_true'); parser.add_argument('--watch', action='store_true')
    args = parser.parse_args(); root = args.root.resolve()
    try:
        if args.prepare: print(prepare(root), flush=True)
        elif args.watch: watch(root)
        else: parser.error('Specify --prepare or --watch')
    except BaseException as error:
        if not args.prepare: write(root / 'status.json', dict(state='failed', pid=os.getpid(), error=repr(error)))
        raise


if __name__ == '__main__': main()
