"""Residual MLP depth controls for the full16x1024 reconstruction model."""

import argparse
from datetime import datetime
import json
import os
from pathlib import Path

from train_dual.experiments.frame_matrix_run import worker
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.small_codebook_run import campaign
from train_dual.util.checkpoint import freeze_sources


LABELS={'baseline':'浅层非线性对照','res2':'2个残差块·宽512','res4':'4个残差块·宽512','res4_wide':'4个残差块·宽1024'}


def prepare(parent):
    parent=parent.resolve();root=parent.parent/('frame_residual_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
    root.mkdir();(root/'data').mkdir();(root/'logs').mkdir()
    for name in ('initial.pt','source_profiles.npz','frame_basis.pt','small_latents.pt','fit_indices.npy','basis_fit.json','source_seen_evaluation.json'):
        os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    plan=json.loads((parent/'plan.json').read_text())
    for key in ('recovery_parent','resume_checkpoints','recovery_reason','resume_sampler','original_frozen_pilot'):
        plan.pop(key,None)
    plan.update(parent=str(parent),experiment='Residual MLP depth in full16x1024 matrix autoencoder',
        lanes={'baseline':dict(kind='nonlinear',hidden_dim=512,depth=0,mode='all',steps=2048),
               'res2':dict(kind='residual',hidden_dim=512,depth=2,mode='all',steps=2048),
               'res4':dict(kind='residual',hidden_dim=512,depth=4,mode='all',steps=2048),
               'res4_wide':dict(kind='residual',hidden_dim=1024,depth=4,mode='all',steps=2048)},
        labels=LABELS,default_variant='res2',strict_replay_control=None,
        encoder_lr=1e-5,linear_lr=1e-5,decoder_lr=1e-5,residual_lr=.001,
        checkpoints=[128,256,512,1024,2048],save_training_checkpoints=True,
        hypothesis='Additional nonlinear residual blocks may improve reconstruction optimization through the same1024-wide bottleneck; compare depth at equal width and a separately labeled width expansion.',
        initialization='Same best source and same train-only PCA initialization for all groups. Added residual blocks start as identity; outer nonlinear output projections start at zero. Equal-width input weights match the shallow control. No resume from different trained variants.',
        method='Encoder nonlinear branch: Linear4160->h, GELU, N blocks h+Linear(GELU(Linear(LayerNorm(h)))), Linear h->1024; decoder symmetric to4160. Each block expansion2. Existing learned linear projection is retained in parallel. All compressed information passes only through[B,16,1024].',
        comparison='Same512training windows,64dev windows,seed42,full-model training,optimizer rates and2048steps. Depth2vs4 at width512 tests depth; width1024 also increases capacity and is not a pure skip-connection ablation. Parameter counts and runtime reported.',
        selection='Report all declared checkpoints and fixed2048-step endpoints; no hidden semantic labels, future returns, extra seeds or independent-Q2 selection.',
        no_quantization=True,no_semantic_constraints=True,no_future_returns=True)
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(parent.parents[1])
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'
        f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\n'
        f'cd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.frame_residual_run "{remote}"\n')
    Path('/tmp/frame_residual_run_path').write_text(str(root));print(root,flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--lane');a=p.parse_args()
    if a.prepare:prepare(a.root)
    elif a.lane:worker(a.root,a.lane)
    else:campaign(a.root,worker_module='train_dual.experiments.frame_residual_run')
