"""FP32 distribution diagnostics on fixed windows; no training or fitting."""
import numpy as np
import torch

from model.losses.probability_book import quantity_distributions
from train_dual.experiments.unified_8192_run import call


def evaluate_probability(model, norm, dataset, windows, device, criterion):
    was_training=model.training
    model.eval()
    indices=np.unique(np.linspace(0,len(dataset)-1,windows,dtype=int))
    keys=['quantity_shape_kl','quantity_rank_w1','quantity_multiscale_kl',
          *[f'quantity_kl_group{g}' for g in criterion.multiscale_groups]]
    sums={key:0. for key in keys}
    shape_n=mass_n=temporal_n=0
    mass_sse=mass_log=pred_sum=true_sum=temporal_sum=0.
    try:
        with torch.inference_mode():
            for index in indices:
                raw={k:v.unsqueeze(0) for k,v in dataset[int(index)].items()}
                b=norm.prepare(raw,device)
                out=call(model,b,False)
                values=criterion(out,b)
                p,ph,valid=quantity_distributions(out['volume'],b['volume'],b['mask'],criterion.quantity_scale)
                count=int(valid.sum())
                shape_n+=count
                for key in keys:sums[key]+=float(values[key])*count
                side=b['mask'].any(-1)
                qm=(b['volume']*b['mask']).sum(-1)
                pm=(out['volume']*b['mask']).sum(-1)
                count=int(side.sum());mass_n+=count
                mass_sse+=float(((pm-qm).square()*side).sum())
                mass_log+=float(values['quantity_mass'])*count
                pred_sum+=float((pm*side).sum());true_sum+=float((qm*side).sum())
                temporal_valid=valid[:,1:]&valid[:,:-1]
                error=((ph[:,1:]-ph[:,:-1])-(p[:,1:]-p[:,:-1])).abs().sum(-1)
                temporal_sum+=float((error*temporal_valid).sum())
                temporal_n+=int(temporal_valid.sum())
        result={key:value/max(1,shape_n) for key,value in sums.items()}
        result.update(windows=len(indices),valid_frame_sides=shape_n,
            mass_rmse_btc=(mass_sse/max(1,mass_n))**.5,
            mass_log_huber=mass_log/max(1,mass_n),
            predicted_total_mass_mean_btc=pred_sum/max(1,mass_n),
            true_total_mass_mean_btc=true_sum/max(1,mass_n),
            temporal_distribution_l1=temporal_sum/max(1,temporal_n),
            note='Raw unweighted shape metrics, per-frame-side means; mass in BTC; fixed rank coordinates; FP32. No independent-test data.')
        if not all(np.isfinite(v) for v in result.values() if isinstance(v,(float,int))):
            raise FloatingPointError('Nonfinite probability evaluation')
        return result
    finally:model.train(was_training)
