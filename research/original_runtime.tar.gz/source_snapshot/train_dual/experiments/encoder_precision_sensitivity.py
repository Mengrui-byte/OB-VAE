"""Trace finite quantity perturbations to latent under three arithmetic policies.

One existing train window; no decoder, optimization, or development evaluation.
This diagnostic does not establish trainability or a reconstruction improvement.
"""
import argparse
import json
import os
from pathlib import Path
import time

import numpy as np
import torch

from model.layers.sensitive_precision import apply_sensitive_precision_
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.price_safe_readout import file_hash
from train_dual.util.checkpoint import freeze_sources,load_for_inference
from train_dual.util.phase_training import tensor_digest

MODULE='train_dual.experiments.encoder_precision_sensitivity'
POLICIES=('BF16','stem_FP32','encoder_FP32')
STAGES=('input_proj','down.0','down.1','down.2','down.3','frame','temporal','mu')
DELTAS=(.001,.01,1.,100.)


def prepare(goal):
    parent=goal/'round_008_auxiliary';root=goal/'encoder_precision_sensitivity_20261028'
    root.mkdir();(root/'data').mkdir();(root/'logs').mkdir()
    assert json.loads((parent/'startup_control_audit.json').read_text())['passed']
    assert all((parent/lane/'step1024_development.json').exists() for lane in ['control','quarter','unit','four'])
    os.link(parent/'control/step1024.pt',root/'source.pt')
    for name in ['train_indices.npy','quantity_calibration_indices.npy']:os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    old=json.loads((parent/'plan.json').read_text());p={k:old[k] for k in ['train','development','window_size','stride','input_shape','latent_shape','output_shape']}
    index=int(np.load(root/'quantity_calibration_indices.npy')[0]);assert index in np.load(root/'train_indices.npy')
    p.update(source_sha256=file_hash(root/'source.pt'),source_selection='Declared control at the existing common1024point; diagnostic reference, not a trained candidate selection.',
        training_index=index,frames=[0,127],policies=POLICIES,stages=STAGES,deltas_BTC=DELTAS,
        site_policy='Per side/frame choose the median eligible rank96..1951 with0<q<0.01; change one quantity at a time.',
        numerical_policy=dict(TF32=False,cudnn_deterministic=True,cudnn_benchmark=False,MHA_fastpath=False,mode='eval',grad=False),
        actual_encoder_input=[1,256,2,2048],actual_projection_input=[512,16,2048],minimum_free_GiB=16,
        interpretation='Finite forward sensitivity only. Quantized forward equality does not prove absent autograd signal: casts use surrogate derivatives, and training can reorganize representations. No reconstruction claims or independent data.')
    atomic_json(root/'plan.json',p);atomic_json(root/'status.json',dict(state='prepared_not_started'));freeze_sources(root/'source_snapshot')
    project=Path(__file__).resolve().parents[2];remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 CUDA_DEVICE_ORDER=PCI_BUS_ID OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m {MODULE} "{remote}" --run >> "{remote}/logs/run.log" 2>&1\n')
    print(root.resolve(),flush=True)


def difference_stats(delta,reference):
    a=delta.float();b=reference.float();aa=float(a.square().sum());bb=float(b.square().sum())
    return dict(changed_elements=int(torch.count_nonzero(a)),delta_L2=aa**.5,reference_FP32_delta_L2=bb**.5,
        cosine_to_FP32=float((a*b).sum())/(aa*bb)**.5 if aa*bb else None,
        relative_delta_error=float((a-b).square().sum())**.5/bb**.5 if bb else None)


def run(root):
    begin=time.monotonic();torch.set_num_threads(2);p=json.loads((root/'plan.json').read_text())
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    torch.backends.cudnn.deterministic=True;torch.backends.cudnn.benchmark=False;torch.backends.mha.set_fastpath_enabled(False)
    free,_=torch.cuda.mem_get_info();assert free/2**30>=p['minimum_free_GiB']
    assert file_hash(root/'source.pt')==p['source_sha256']
    model,norm=load_for_inference(root/'source.pt','cpu');model.eval().requires_grad_(False);before=tensor_digest(model)
    apply_sensitive_precision_(model);encoder=model.encoder.to('cuda:0');data=dataset(root,'train');index=p['training_index']
    raw={k:v.unsqueeze(0) for k,v in data[index].items()};assert list(raw['data'].shape)==p['input_shape']
    offset=int(data.base.starts[index]);times=data.base.times[offset:offset+256];assert np.all(np.diff(times//60000000)==1)
    b=norm.prepare(raw,'cuda:0');q=b['volume'];encoder_calls=0
    def capture(quantity,policy):
        nonlocal encoder_calls
        values={};apply_sensitive_precision_(model,encoder_input_fp32=policy=='stem_FP32')
        def trace(name):
            def hook(module,args,out):values[name]=out.detach().float().clone()
            return hook
        hooks=[encoder.get_submodule(name).register_forward_hook(trace(name)) for name in STAGES]
        try:
            with torch.no_grad(),torch.autocast('cuda',dtype=torch.bfloat16,enabled=policy!='encoder_FP32'):
                mu,logvar=encoder(b['price'],quantity,b['mask'],b['tick_norm'],b['times'])
            encoder_calls+=1
            assert list(mu.shape)==p['latent_shape'] and torch.isfinite(mu).all() and torch.isfinite(logvar).all()
            assert list(values['input_proj'].shape)==[512,32,2048] and list(values['mu'].shape)==[1,256,32]
            return values
        finally:
            for hook in hooks:hook.remove()
    atomic_json(root/'status.json',dict(state='running_encoder_only',pid=os.getpid()))
    baseline={policy:capture(q,policy) for policy in POLICIES}
    for policy in POLICIES:
        repeat=capture(q,policy)
        for name in STAGES:assert torch.equal(repeat[name],baseline[policy][name])
        del repeat
    records=[]
    for frame in p['frames']:
        for side in range(2):
            eligible=torch.nonzero((q[0,frame,side]>0)&(q[0,frame,side]<.01)&b['mask'][0,frame,side]).flatten()
            eligible=eligible[(eligible>=96)&(eligible<1952)];assert len(eligible)>0;rank=int(eligible[len(eligible)//2])
            for amount in DELTAS:
                edited=q.clone();edited[0,frame,side,rank]+=amount
                full=capture(edited,'encoder_FP32')
                reference={name:full[name]-baseline['encoder_FP32'][name] for name in STAGES};del full
                rows={}
                for policy in POLICIES:
                    if policy=='encoder_FP32':rows[policy]={name:difference_stats(reference[name],reference[name]) for name in STAGES};continue
                    values=capture(edited,policy)
                    rows[policy]={name:difference_stats(values[name]-baseline[policy][name],reference[name]) for name in STAGES};del values
                records.append(dict(frame=frame,side=side,rank_zero_based=rank,quantity_before_BTC=float(q[0,frame,side,rank]),delta_BTC=amount,policies=rows))
                del edited,reference
                atomic_json(root/'progress.json',dict(cases=len(records),total=16,encoder_forwards=encoder_calls,optimizer_updates=0,elapsed_seconds=time.monotonic()-begin))
    assert tensor_digest(model)==before and file_hash(root/'source.pt')==p['source_sha256']
    summary={}
    for amount in DELTAS:
        chosen=[row for row in records if row['delta_BTC']==amount];summary[str(amount)]={}
        for policy in POLICIES:
            rows=[row['policies'][policy] for row in chosen]
            summary[str(amount)][policy]={name:dict(cases=len(rows),unchanged_cases=sum(row[name]['changed_elements']==0 for row in rows),
                median_changed_elements=float(np.median([row[name]['changed_elements'] for row in rows])),
                median_delta_L2=float(np.median([row[name]['delta_L2'] for row in rows])),
                median_cosine_to_FP32=float(np.median([row[name]['cosine_to_FP32'] for row in rows if row[name]['cosine_to_FP32'] is not None])) if any(row[name]['cosine_to_FP32'] is not None for row in rows) else None) for name in STAGES}
    result=dict(state='complete',summary=summary,records=records,encoder_forwards=encoder_calls,decoder_forwards=0,full_model_forwards=0,
        optimizer_updates=0,actual_raw=p['input_shape'],actual_mu=p['latent_shape'],source_model_unchanged=True,training_windows_read=1,
        source_sha256=p['source_sha256'],elapsed_seconds=time.monotonic()-begin,interpretation=p['interpretation'],numerical_policy=p['numerical_policy'])
    atomic_json(root/'result.json',result);atomic_json(root/'status.json',dict(state='complete',pid=os.getpid()));print(json.dumps(dict(encoder_forwards=encoder_calls,optimizer_updates=0)),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('root',type=Path);parser.add_argument('--prepare',action='store_true');parser.add_argument('--run',action='store_true');args=parser.parse_args()
    try:
        if args.prepare:prepare(args.root.resolve())
        elif args.run:run(args.root.resolve())
        else:parser.error('Specify --prepare or --run')
    except BaseException as error:
        if args.run:atomic_json(args.root/'status.json',dict(state='failed',pid=os.getpid(),error=repr(error)))
        raise
