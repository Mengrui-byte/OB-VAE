"""Inspect latent distributions and residual codes in a local browser report."""

import argparse
from datetime import datetime,timezone
import json
from pathlib import Path
import time

import numpy as np

from train_dual.experiments.book_stem_viewer import build


LABELS={'direct':'直接RVQ对照','rq64':'RQ-VAE 64维量化空间','rq128':'RQ-VAE 128维量化空间','rq256':'RQ-VAE 256维量化空间'}
PAGE='''<!doctype html><html lang=zh-CN><meta charset=utf-8><title>Latent检查与RQ-VAE</title><script src=plotly.min.js></script>
<style>body{font:16px system-ui;max-width:1500px;margin:30px auto;padding:0 20px;color:#162235}p{line-height:1.8}table{border-collapse:collapse;width:100%}td,th{padding:9px;border:1px solid #d8dfe9;text-align:left}.plots{display:grid;grid-template-columns:1fr 1fr}a{color:#2563eb}select{font:inherit;padding:5px}h2{margin-top:32px}@media(max-width:900px){.plots{display:block}}</style>
<h1>先看Latent，再看残差量化</h1><p>对象为现有非线性模型的完整窗口向量[B,1024]。原始编码器与订单簿生成器冻结；另训练RQ-VAE，不使用未来收益。直接RVQ没有自编码器；三组RQ-VAE的量化空间分别为64/128/256维。每窗口一串8级整数码，每级256个码字，逐级叠加修正残差。</p><p id=status>准备中</p><p id=normalization></p><p><a href=./>逐档挂单线图</a> · <a href=previous/>量化前重建</a> · <a href=rq_plan.json>配置</a></p>
<table><thead><tr><th>GPU</th><th>方案</th><th>阶段</th><th>更新</th><th>损失</th><th>显存GiB</th></tr></thead><tbody id=progress></tbody></table>
<h2>原始Latent的分布</h2><p>8192个训练窗口；原始尺度与逐维标准化分别计算谱。有效秩为参与率，数值秩阈值为最大协方差特征值的1e-10，均不是内在流形维度。二维展示的标准化及PCA仅在训练期拟合。</p>
<table><thead><tr><th>模型</th><th>形状</th><th>原始有效秩</th><th>原始99%方差维数</th><th>标准化有效秩</th><th>标准化99%方差维数</th><th>标准化数值秩</th></tr></thead><tbody id=latentTable></tbody></table>
<p>显示 <select id=latentModel><option value=nonlinear>非线性编码</option><option value=fixed>固定PCA</option><option value=linear>线性编码</option><option value=attention>分组注意力编码</option></select>；着色 <select id=feature><option value=0>平均价差</option><option value=6>100档平均买卖不平衡</option><option value=9>窗口内已发生波动</option><option value=11>大额挂量占比</option></select></p>
<div class=plots><div id=spectrum></div><div id=projection></div><div id=eigen></div><div id=stds></div></div>
<h2>逐级残差与码本使用</h2><p>残差能量在量化空间中计算，曲线除以量化前能量。1024维向量恢复误差另列；订单簿误差不保证随深度单调。每级保留零码作为跳过选项。开发集仅128个窗口，其使用码字数最多128，不能把开发集未出现的码字直接叫作死码。</p>
<div class=plots><div id=residual></div><div id=latentError></div></div>
<p>码本/时间序列显示 <select id=codeModel><option value=rq128>RQ-VAE128</option><option value=rq64>RQ-VAE64</option><option value=rq256>RQ-VAE256</option><option value=direct>直接RVQ</option></select></p>
<div class=plots><div id=usage></div><div id=timeline></div></div><p>时间图为开发期前256个按实际顺序排列、不重叠的16分钟窗口。颜色仅表示码字编号，没有大小或涨跌含义。后一级码表达前面各级未解释的残差，不能把同一细级编号单独当作一种固定市场状态。</p>
<table><thead><tr><th>方案</th><th>级别</th><th>训练使用码字</th><th>训练困惑度</th><th>开发使用码字</th><th>开发困惑度</th><th>训练跳过比例</th></tr></thead><tbody id=codeTable></tbody></table>
<h2>量化后的订单簿重建</h2><p>同一128个2025年一季度开发窗口，严格FP32。连续AE对照用于隔离降维误差；未量化原模型是量化新增误差的基线。整数码目前保存为int64数组，1/2/4/8级的8/16/32/64位仅为理想码索引位数，不含模型、码本及元数据，也没有实际bit打包。</p>
<table><thead><tr><th>方案</th><th>恢复方式</th><th>标准化Latent MSE</th><th>价格RMSE USDT</th><th>数量RMSE BTC</th><th>分钟变化RMSE</th><th>≥100BTC召回</th></tr></thead><tbody id=bookTable></tbody></table>
<h2>第一级码字对应的已观测特征</h2><p>仅展示512个训练展示窗口中至少3个样本的常见码字，表中是这些历史样本的均值；不是用未来收益学习的分类标签，也不证明预测能力。</p><table><thead><tr><th>码字</th><th>展示样本数</th><th>平均价差bps</th><th>100档不平衡</th><th>已发生波动bps</th><th>大额挂量占比</th></tr></thead><tbody id=prototypes></tbody></table><small id=updated></small>
<script>let data={},diag=null,views={};const labels={direct:'直接RVQ',rq64:'RQ-VAE64',rq128:'RQ-VAE128',rq256:'RQ-VAE256'},sourceLabels={fixed:'固定PCA',linear:'线性编码',nonlinear:'非线性编码',attention:'分组注意力编码'};const colors={direct:'#64748b',rq64:'#16a34a',rq128:'#9333ea',rq256:'#f59e0b'};const n=(x,d=4)=>x==null?'—':x.toFixed(d);function row(a){let r=document.createElement('tr');for(let x of a){let c=document.createElement('td');c.textContent=x;r.append(c)}return r}function plot(id,traces,title,x='',y=''){Plotly.react(id,traces,{template:'plotly_white',height:370,title,xaxis:{title:x},yaxis:{title:y},margin:{t:55,l:65,r:25,b:60}},{responsive:true,displaylogo:false})}
function drawLatent(){if(!diag)return;let k=document.getElementById('latentModel').value;if(!diag.models[k])return;let d=diag.models[k],p=diag.projections[k],f=+document.getElementById('feature').value;plot('spectrum',['raw','standardized'].map((s,i)=>({y:d[s].cumulative_variance,name:i?'标准化':'原始尺度',type:'scatter',mode:'lines'})),'累计方差解释率','主成分序号（从0开始）','比例');plot('eigen',['raw','standardized'].map((s,i)=>({y:d[s].eigenvalues.map(x=>Math.log10(Math.max(x,1e-15))),name:i?'标准化':'原始尺度',type:'scatter',mode:'lines'})),'协方差特征值谱','主成分序号','log10特征值');plot('stds',[{x:d.per_dimension_std,type:'histogram',name:'标准差'}],'1024个坐标的训练标准差','标准差','维度数');let traces=[];for(let [key,name,symbol,features] of [['train','训练展示512','circle',diag.train_features],['development','开发128','diamond',diag.development_features]])traces.push({x:p[key].map(v=>v[0]),y:p[key].map(v=>v[1]),text:features.map(v=>'特征值 '+v[f].toFixed(5)),type:'scatter',mode:'markers',name,marker:{size:6,symbol,color:features.map(v=>v[f]),colorscale:'Viridis',showscale:key==='development',colorbar:{title:'特征值'}}});plot('projection',traces,'标准化Latent的训练拟合PCA二维投影','PC1','PC2')}
function drawCodes(){let lane=document.getElementById('codeModel').value,x=data.lanes?.[lane],metrics=x?.metrics,v=views[lane];if(metrics){let rs=[];for(let [kind,name,dash] of [['train','训练','solid'],['development','开发','dash']])rs.push({x:Array.from({length:9},(_,i)=>i),y:metrics[kind].residual_energy.map(a=>a/metrics[kind].residual_energy[0]),name:labels[lane]+name,mode:'lines+markers',line:{dash}});plot('residual',rs,'量化空间剩余残差比例','残差级数','剩余能量 / 初始能量');plot('usage',[{z:metrics.train.levels.map(z=>z.counts),type:'heatmap',colorscale:'Blues',colorbar:{title:'训练窗口数'}}],'每级码字使用次数','码字编号（含零码）','级别（从0开始）');let rows=metrics.train.levels.map((a,i)=>row([labels[lane],i+1,a.used_codes+' / 256',n(a.perplexity,2),metrics.development.levels[i].used_codes+' / 256',n(metrics.development.levels[i].perplexity,2),n(a.skip_fraction)]));document.getElementById('codeTable').replaceChildren(...rows)}if(v){plot('timeline',[{x:v.times,z:v.timeline,type:'heatmap',colorscale:'Turbo',showscale:false}],'连续窗口的残差码','窗口结束时间UTC','级别（从0开始）');document.getElementById('prototypes').replaceChildren(...v.prototypes.map(p=>row([p.code,p.count,n(p.features[0]),n(p.features[6]),n(p.features[9]),n(p.features[11])])))}let errors=[];for(let [name,z] of Object.entries(data.lanes||{}))if(z.metrics)errors.push({x:[1,2,4,8],y:[1,2,4,8].map(i=>z.metrics.development.prefixes[String(i)].normalized_latent_mse),name:labels[name],mode:'lines+markers',line:{color:colors[name]}});plot('latentError',errors,'开发集1024维Latent恢复误差','残差级数','标准化Latent MSE')}
async function refresh(){data=await(await fetch('rq_progress.json?t='+Date.now())).json();document.getElementById('normalization').textContent='本轮量化归一化：'+(data.normalization==='global'?'全局单一RMS尺度，保留原坐标误差权重':'逐维标准差缩放')+'。不同归一化下的归一化MSE不能直接横比，请结合原始坐标误差和订单簿指标。';document.getElementById('status').textContent='状态：'+data.status.state+'；'+(data.status.phase||'')+(data.status.error?'；'+data.status.error:'');let pr=[],books=[];for(let [i,[lane,label]] of Object.entries(Object.entries(labels))){let x=data.lanes[lane]||{},p=x.progress||{};pr.push(row([+i+2,label,x.status?.state==='complete'?'已完成':p.phase||'等待',p.step??'—',n(p.loss),n(p.reserved_gib,2)]));for(let [key,value] of Object.entries(x.book||{})){let m=value.result.metrics,metric=x.metrics?.development,err=key==='original'?0:key==='continuous'?metric?.continuous_normalized_mse:metric?.prefixes[key.replace('depth','')]?.normalized_latent_mse;books.push(row([label,key,n(err,6),n(m.price_usdt.rmse,3),n(m.quantity_btc.rmse),n(m.temporal_mid_1_minutes_usdt_per_minute.rmse,3),n(value.result.thresholds['100'].recall)]))}}document.getElementById('progress').replaceChildren(...pr);document.getElementById('bookTable').replaceChildren(...books);if(data.has_diagnostics){diag=await(await fetch('rq_latent_diagnostics.json?t='+Date.now())).json();document.getElementById('latentTable').replaceChildren(...Object.entries(diag.models).map(([k,d])=>row([sourceLabels[k],d.shape.join('×'),n(d.raw.participation_rank,2),d.raw.components_for_variance['0.99'],n(d.standardized.participation_rank,2),d.standardized.components_for_variance['0.99'],d.standardized.numerical_rank])));drawLatent()}if(data.has_code_views)views=await(await fetch('rq_code_views.json?t='+Date.now())).json();drawCodes();document.getElementById('updated').textContent='更新：'+new Date(data.utc).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai'})}for(let id of ['latentModel','feature'])document.getElementById(id).onchange=drawLatent;document.getElementById('codeModel').onchange=drawCodes;refresh().catch(console.error);setInterval(()=>refresh().catch(console.error),10000)</script></html>'''


def final_report(root):
    plan=json.loads((root/'plan.json').read_text());results=json.loads((root/'comparison.json').read_text())
    data=root/'report';data.mkdir(exist_ok=True)
    with np.load(root/'unquantized_profiles.npz') as p:
        arrays={k:p[k] for k in ('truth','mask','time','indices')};arrays['unquantized']=p['prediction']
    with np.load(root/'original_cross_profiles.npz') as p:arrays['cross_reference']=p['prediction']
    config=[dict(key='truth',label='真实订单簿',color='#2563eb'),dict(key='cross_reference',label='未压缩Cross参考',color='#64748b'),
        dict(key='unquantized',label='原1024维窗口Latent',color='#9333ea')]
    selected=[('rq128','continuous','连续AE128'),('rq128','depth1','RQ128·1级'),('rq128','depth2','RQ128·2级'),
        ('rq128','depth4','RQ128·4级'),('rq128','depth8','RQ128·8级'),('direct','depth8','直接RVQ·8级'),
        ('rq64','depth8','RQ64·8级'),('rq256','depth8','RQ256·8级')]
    for (lane,mode,label),color in zip(selected,['#0d9488','#f97316','#eab308','#ef4444','#16a34a','#64748b','#ec4899','#8b5cf6']):
        key=lane+'_'+mode
        with np.load(root/lane/mode/'profiles.npz') as p:
            if not np.array_equal(p['truth'],arrays['truth']):raise ValueError('Unmatched reconstruction windows')
            arrays[key]=p['prediction']
        config.append(dict(key=key,label=label,color=color))
    np.savez_compressed(data/'profiles.npz',**arrays)
    info=dict(seed=42,common_step=plan['rq_steps'],viewer_variants=config,default_model=7,plan=plan,results=results,
        comparison_label='查看原始Latent、残差码和重建指标',step_note='原1024维模型冻结；RQ-VAE只重建Latent；归一化 '+plan.get('normalization','per_dimension')+'。512步连续预热+2048步残差量化；直接RVQ为训练期KMeans对照。')
    (data/'comparison.json').write_text(json.dumps(info,ensure_ascii=False))
    (data/'index.html').write_text('<!doctype html><meta charset=utf-8><meta http-equiv=refresh content="0;url=../rq.html">')
    viewer=root/'viewer';build(data,viewer)
    for name in ('rq.html','rq_progress.json','rq_latent_diagnostics.json','rq_code_views.json','rq_plan.json'):
        if not (viewer/name).exists():(viewer/name).symlink_to(root/'public'/name)
    if not (viewer/'previous').exists():(viewer/'previous').symlink_to(root/'public/previous',target_is_directory=True)
    return viewer


def monitor(root):
    public=root/'public';public.mkdir(exist_ok=True)
    selector=root.parents[1]/'.local/dual_viewer/current.json';previous=Path(json.loads(selector.read_text())['directory'])
    if not (public/'previous').exists():(public/'previous').symlink_to(previous,target_is_directory=True)
    for name,target in [('rq.html',None),('rq_plan.json',root/'plan.json'),('rq_latent_diagnostics.json',root/'latent_diagnostics.json')]:
        if name=='rq.html':(public/name).write_text(PAGE)
        elif not (public/name).is_symlink():(public/name).symlink_to(target)
    # Publish a new current directory; leave previous reports and their links immutable.
    for name in ('index.html','book.f64','mask.u8','viewer.json','plotly.min.js','comparison'):
        source=previous/name
        if source.exists() and not (public/name).exists():(public/name).symlink_to(source,target_is_directory=source.is_dir())
    tmp=selector.with_suffix('.tmp');tmp.write_text(json.dumps(dict(directory=str(public))));tmp.replace(selector)
    plan=json.loads((root/'plan.json').read_text())
    while True:
        try:
            status=json.loads((root/'status.json').read_text());lanes={};code_views={}
            for lane in LABELS:
                values={}
                for key,name in [('status','status.json'),('progress','progress.json'),('metrics','latent_metrics.json')]:
                    path=root/lane/name
                    if path.exists():values[key]=json.loads(path.read_text())
                values['book']={}
                for mode in ('original','continuous','depth1','depth2','depth4','depth8'):
                    path=root/lane/(mode+'_evaluation.json')
                    if path.exists():values['book'][mode]=json.loads(path.read_text())
                path=root/lane/'codes.npz'
                if path.exists():
                    with np.load(path) as p:
                        train=p['train'];positions=p['train_plot_positions'];features=p['train_plot_features'];codes=train[positions,0]
                        counts=np.bincount(codes,minlength=256);prototypes=[]
                        for code in np.argsort(counts)[::-1][:12]:
                            if counts[code]>=3:prototypes.append(dict(code=int(code),count=int(counts[code]),features=features[codes==code].mean(0).tolist()))
                        code_views[lane]=dict(timeline=p['timeline'].T.tolist(),
                            times=[str(np.datetime64(int(t),'us')) for t in p['timeline_end_time']],prototypes=prototypes)
                lanes[lane]=values
            if code_views:
                tmp=public/'rq_code_views.json.tmp';tmp.write_text(json.dumps(code_views));tmp.replace(public/'rq_code_views.json')
            payload=dict(utc=datetime.now(timezone.utc).isoformat(),status=status,lanes=lanes,
                has_diagnostics=(root/'latent_diagnostics.json').exists(),has_code_views=bool(code_views),normalization=plan.get('normalization','per_dimension'))
            tmp=public/'rq_progress.json.tmp';tmp.write_text(json.dumps(payload));tmp.replace(public/'rq_progress.json')
            if status['state']=='complete':
                viewer=final_report(root)
                tmp=selector.with_suffix('.tmp');tmp.write_text(json.dumps(dict(directory=str(viewer))));tmp.replace(selector)
                (root/'published.json').write_text(json.dumps(dict(directory=str(viewer))))
                break
            if status['state'] in ('failed','stopped_by_user'):break
        except (FileNotFoundError,ValueError):pass
        except Exception as error:
            (root/'report_error.json').write_text(json.dumps(dict(error=repr(error))));raise
        time.sleep(10)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);a=p.parse_args();monitor(a.root)
