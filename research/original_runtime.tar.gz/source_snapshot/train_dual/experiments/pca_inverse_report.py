"""Display equal-budget linear/nonlinear inverses of the same PCA vectors."""

import argparse
import json
from pathlib import Path

import numpy as np

from train_dual.experiments.book_stem_viewer import build
from train_dual.util.checkpoint import freeze_sources


LABELS={'linear1024':'1024维 · 线性展开续训','nonlinear1024':'1024维 · 非线性逆映射',
        'linear256':'256维 · 线性展开续训','nonlinear256':'256维 · 非线性逆映射'}


def report(root):
    result=json.loads((root/'comparison.json').read_text());plan=json.loads((root/'plan.json').read_text())
    data=root/'report';data.mkdir(exist_ok=False)
    with np.load(root/'original_source_profiles.npz') as source:
        arrays={k:source[k] for k in ['truth','mask','time','indices']};arrays['reference']=source['prediction']
    config=[dict(key='truth',label='真实订单簿',color='#2563eb'),dict(key='reference',label='原cross参考',color='#6b7280')]
    for (lane,label),color in zip(LABELS.items(),['#ef4444','#16a34a','#f59e0b','#9333ea']):
        with np.load(root/lane/'profiles.npz') as p:
            assert np.array_equal(p['truth'],arrays['truth'])
            arrays[lane]=p['prediction']
        config.append(dict(key=lane,label=label,color=color))
        (data/(lane+'_checkpoint.pt')).symlink_to(root/lane/'final.pt')
    for d in (1024,256):
        with np.load(root/f'linear{d}/profiles.npz') as a,np.load(root/f'nonlinear{d}/profiles.npz') as b:
            assert np.allclose(a['market_state'],b['market_state'],atol=1e-6)
    np.savez_compressed(data/'profiles.npz',**arrays)
    info=dict(seed=42,common_step=plan['steps'],viewer_variants=config,default_model=3,plan=plan,results=result,
              comparison_label='查看相同窗口向量的线性/非线性逆映射对照',
              step_note='PCA与状态向量固定；从适配256步的配对起点再训练192步。')
    (data/'comparison.json').write_text(json.dumps(info,ensure_ascii=False,indent=2))
    def cells(value):
        m=value['metrics'];v=[f"{m['price_usdt']['rmse']:.3f}",f"{m['quantity_btc']['rmse']:.4f}",
            f"{m['spatial_slope_64_levels_usdt_per_level']['rmse']:.6f}",f"{m['temporal_mid_1_minutes_usdt_per_minute']['rmse']:.3f}",f"{value['thresholds']['100']['recall']:.1%}"]
        return ''.join('<td>'+x+'</td>' for x in v)
    table='<table><tr><th>模型</th><th>阶段</th><th>价格RMSE</th><th>数量RMSE</th><th>64档斜率RMSE</th><th>分钟变化RMSE</th><th>≥100 BTC召回率</th></tr>'
    for lane,label in LABELS.items():
        for stage in ('initial','final'):table+='<tr><td>'+label+'</td><td>'+stage+'</td>'+cells(result['rows'][lane][stage]['result'])+'</tr>'
    table+='</table>'
    page='''<!doctype html><meta charset=utf-8><title>固定状态向量的非线性逆映射</title><style>body{font:17px system-ui;max-width:1450px;margin:30px auto;padding:0 20px;color:#162235}p{line-height:1.8}table{width:100%;border-collapse:collapse;text-align:right}td,th{padding:11px;border:1px solid #d8dfe9}a{color:#2563eb}</style><h1>固定PCA状态，比较线性和非线性逆映射</h1><p><a href=../>逐档重建线图</a> · <a href=../inverse.html>本轮进度</a> · <a href=../previous/>PCA基线与生成器适配结果</a> · <a href=comparison.json>全部指标和配置</a></p><p>同一维度的两组从完全相同的PCA适配256步权重出发，再各训练192步。PCA、源编码器、状态向量保持不变。非线性组仅增加从状态向量到完整global/local latent的残差MLP，输出层零初始化；开始时与线性组重建一致。其输出只是PCA逆映射的修正，不是额外输入信息。</p>'''+table
    page+='<p>非线性映射具有更多参数，新增模块学习率1e-4，原生成器仍为3e-5；两组使用相同样本及更新次数。此阶段检验解码能力，尚未改变状态编码或重新学习被投影丢弃的方向。</p><p>单种子42；训练期2022–2024年，128个固定2025年一季度开发窗口评估，严格FP32。独立测试期未使用。线图每档一条竖线，左右共享坐标，可切换1024/256及线性/非线性。</p>'
    (data/'index.html').write_text(page)
    viewer=root/'viewer';freeze_sources(viewer/'source_snapshot');build(data,viewer)
    for name in ('inverse.html','inverse_progress.json','pca.html','pca_progress.json'):
        (viewer/name).symlink_to(root/'public'/name)
    (viewer/'previous').symlink_to(root/'public/previous',target_is_directory=True)
    return viewer


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);print(report(p.parse_args().root))
