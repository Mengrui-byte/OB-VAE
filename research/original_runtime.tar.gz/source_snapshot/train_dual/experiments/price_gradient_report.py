"""Publish current-checkpoint shared-parameter conflict and price-error attribution."""
import argparse
from pathlib import Path
import json
import time
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np


def render(root):
 p=json.loads((root/'plan.json').read_text());results=json.loads((root/'results.json').read_text())['results'];font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc';font_manager.fontManager.addfont(font);plt.rcParams.update({'font.family':font_manager.FontProperties(fname=font).get_name(),'axes.unicode_minus':False,'font.size':10});labels=p['labels'];colors=['#366590','#337c70','#b27c33','#ab6173']
 fig,axes=plt.subplots(1,2,figsize=(14,5),layout='constrained')
 keys=['encoder','encoder.frame','encoder.patch','encoder.mu','price_decoder'];x=np.arange(len(keys))
 for (lane,v),color in zip(results.items(),colors):
  axes[0].plot(x,[v['groups'][k]['cosine'] for k in keys],marker='o',label=labels[lane],color=color);axes[1].plot(np.arange(1,17),[w['price_rmse_usdt'] for w in v['development_windows']],marker='o',lw=1.1,color=color,label=labels[lane])
 axes[0].axhline(0,color='#657386',lw=.8);axes[0].set_ylim(-1,1);axes[0].set_xticks(x,keys,rotation=25);axes[0].set_title('价格 / 数量梯度余弦：负值表示局部冲突');axes[0].set_ylabel('梯度cos');axes[1].set_title('相同16开发窗价格RMSE');axes[1].set_xlabel('开发窗口序号');axes[1].set_ylabel('USDT')
 for ax in axes:ax.grid(alpha=.2);ax.legend(fontsize=8)
 fig.suptitle(f'当前四组共同追加第{p["audit_checkpoint_step"]}步｜4训练窗梯度＋16开发窗误差',fontsize=14);fig.savefig(root/'conflicts_and_windows.png',dpi=160);fig.savefig(root/'conflicts_and_windows.svg');plt.close(fig)
 rows='';decomp='';local=''
 for lane,v in results.items():
  e=v['groups']['encoder'];a=v['groups']['ALL'];g=v['groups']['price_decoder'];d=v['development_decomposition'];s=v['encoder_quantity_only_step'];rows+=f'<tr><td>{labels[lane]}</td><td>{e["cosine"]:.4f}</td><td>{e["quantity_to_price_norm_ratio"]:.2f}</td><td>{e["price_derivative_along_negative_total"]:.6f}</td><td>{a["cosine"]:.4f}</td><td>{g["quantity_to_price_norm_ratio"]:.5f}</td></tr>'
  decomp+=f'<tr><td>{labels[lane]}</td><td>{d["price_rmse_usdt"]:.2f}</td><td>{d["weighted_mid_rmse_usdt"]:.2f}</td><td>{d["relative_mid_shape_rmse_usdt"]:.2f}</td><td>{d["cross_mse_component"]:.2f}</td></tr>'
  local+=f'<tr><td>{labels[lane]}</td><td>{s["price_before"]:.7f}</td><td>{s["price_after"]:.7f}</td><td>{s["predicted_first_order_price_delta"]:.7f}</td><td>{s["quantity_before"]:.5f}</td><td>{s["quantity_after"]:.5f}</td></tr>'
 css='body{font:15px/1.85 system-ui;color:#243447;background:#f5f6f8;margin:0}main{max-width:1350px;margin:28px auto;padding:38px 44px;background:white;border:1px solid #dce4eb}table{width:100%;border-collapse:collapse;font-size:13px}th,td{padding:10px;text-align:left;border-bottom:1px solid #dce4eb}th{background:#f5f8fb}img{width:100%}.note{padding:15px 20px;background:#f5f8fb;border-left:3px solid #7596b4}.wrap{overflow:auto}a{color:#366590}h1{font-size:29px}h2{font-size:22px;margin-top:30px}.formula{font:20px/1.9 Georgia,serif;background:#fafbfd;padding:20px;text-align:center;overflow:auto}@media(max-width:700px){main{margin:8px;padding:22px 15px}}'
 html=f'''<!doctype html><html lang=zh-CN><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>当前价格与挂量梯度冲突检查</title><style>{css}</style><main><h1>是否出现梯度冲突：共享Encoder的直接检查</h1><p>使用四组分布KL/总量实验共同的追加第{p['audit_checkpoint_step']}步检查点，同4个预先固定的完整256分钟训练窗口计算梯度，同16个2025Q1开发窗口分解价格误差。只读诊断，模型权重扰动后恢复，不修改现有训练。</p><p><a href=results.json>完整数值、逐窗梯度和误差</a> · <a href=plan.json>协议</a> · <a href=../>全部实验</a></p><h2>1. 冲突定义与强度</h2><div class=formula>cos(g<sub>p</sub>, g<sub>q</sub>) = ⟨g<sub>p</sub>,g<sub>q</sub>⟩ / (‖g<sub>p</sub>‖‖g<sub>q</sub>‖)<br>dL<sub>p</sub>(θ − ηg<sub>q</sub>)/dη |<sub>0</sub> = −⟨g<sub>p</sub>,g<sub>q</sub>⟩</div><p>负余弦说明在同一共享参数上，沿数量负梯度小步移动会一阶推高价格目标。这是多目标取舍，不是自动微分算错。数量梯度若很小，即便夹角负也未必主导实际更新；Adam动量还会改变实际方向。</p><div class=wrap><table><thead><tr><th>组</th><th>共享Encoder cos</th><th>Encoder数量/价格梯度L2比</th><th>Encoder负总梯度对价格方向导数</th><th>全参数cos</th><th>价格Decoder数量/价格梯度L2比</th></tr></thead><tbody>{rows}</tbody></table></div><div class=note>第三列方向导数对应按该参数组总梯度L2归一化后的负方向；大于0表示该共享组当前总目标的局部下降方向会推高价格目标。全参数余弦包含独立数量头等互不重叠的参数，可稀释共享冲突，不能只看全模型余弦。</div><img src=conflicts_and_windows.png alt="共享层梯度夹角及16窗价格误差"><h2>2. 局部方向干预：只沿数量梯度移动Encoder</h2><p>参数扰动L2=0.001，Decoder参数固定，权重随即恢复。检验的是同一训练点的局部作用，不是实际Adam训练步骤，也不能单独解释整个训练轨迹。</p><div class=wrap><table><thead><tr><th>组</th><th>价格目标之前</th><th>价格目标之后</th><th>一阶预测价格变化</th><th>数量目标之前</th><th>数量目标之后</th></tr></thead><tbody>{local}</tbody></table></div><h2>3. 价格误差来自mid还是盘口相对形状？</h2><p>此处覆盖全部16个开发窗，不仅是预览3窗。相对形状误差通过减去预测与真实各自的mid差作诊断；真实逐帧mid没有传入Decoder，也不用于修正价格曲线。</p><div class=wrap><table><thead><tr><th>组</th><th>全部价格RMSE USDT</th><th>mid偏移RMSE USDT</th><th>相对mid形状RMSE USDT</th><th>误差交叉项（MSE单位）</th></tr></thead><tbody>{decomp}</tbody></table></div><p>总MSE = mid偏移MSE + 相对形状MSE + 交叉项；上述RMSE不可直接相加。部分抽样窗口改善不代表16窗总体改善，应结合逐窗结果检查离群窗口。</p><div class=note>这些指标测量当前检查点的局部梯度关系。若要证明价格退化主要由某条梯度路径造成，需要固定其它因素，分别阻断数量到共享Z/Encoder的梯度与预测价格条件梯度，做匹配消融；本页不把局部负余弦直接当作完整轨迹的因果证明。</div></main></html>'''
 (root/'index.html').write_text(html);index=root.parents[1]/'recons/index.html';s=index.read_text();href=root.name+'/'
 if href not in s:index.write_text(s.replace('</main>',f'<p><a href="{href}">当前分布/总量实验的梯度冲突与价格误差分解</a></p></main>'))
 print(root/'index.html',flush=True)

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);a=p.parse_args()
 for _ in range(60):
  f=a.root/'status.json'
  if f.exists() and json.loads(f.read_text()).get('state')=='complete':render(a.root.resolve());break
  time.sleep(5)
 else:raise TimeoutError('Currentgradientaudit still incomplete after5minutes')
