"""Training-fitted raw and standardized views of the unchanged window latent."""

import argparse
import json
from pathlib import Path

import numpy as np
import torch


PAGE='''<!doctype html><html lang=zh-CN><meta charset=utf-8><title>直接查看1024维Latent</title><script src=../plotly.min.js></script><style>body{font:17px system-ui;max-width:1500px;margin:30px auto;padding:0 20px;color:#162235}p{line-height:1.8}.plots{display:grid;grid-template-columns:1fr 1fr}select{font:inherit;padding:5px}a{color:#2563eb}</style><h1>直接查看窗口Latent：原始坐标与等尺度坐标</h1><p>同一[B,1024]非线性窗口向量。所有均值、尺度与PCA投影仅在8192个训练窗口拟合，展示512个训练窗口和128个2025年一季度开发窗口。投影不是内在流形维度估计；散点颜色只用于查看已观测特征，未使用未来收益。</p><p><a href=../rq.html>残差量化与码本</a> · <a href=../>逐档重建线图</a> · <a href=data.json>投影数据</a></p><p>颜色 <select id=feature><option value=0>平均价差bps</option><option value=6>100档平均买卖不平衡</option><option value=9>窗口内已发生波动bps</option><option value=11>大额挂量占比</option><option value=code>RQ128第一级码（分类编号）</option></select></p><div class=plots><div id=raw></div><div id=standardized></div></div><div id=spectrum></div><p>圆点为训练展示样本，菱形为开发样本。训练与开发使用相同颜色范围。码字颜色只是类别，不表示大小或涨跌；后续残差码的含义取决于此前选中的码。</p><p>本轮将整个1024维向量映射到一个128维量化位置，再用8级码近似它：最终每窗口8个整数，理论64位，不含码本/模型/元数据，也未位打包。并非16个逐分钟状态。</p><script>let d;async function main(){d=await(await fetch('data.json')).json();draw();window.latentProjectionReady=true}function draw(){let f=document.getElementById('feature').value,code=f==='code',j=+f;let cs=code?d.train_codes.map(c=>c[0]):d.train_features.map(v=>v[j]),lo=code?0:Math.min(...cs),hi=code?255:Math.max(...cs);for(let key of ['raw','standardized']){let ts=[];for(let split of ['train','development']){let p=d[split+'_'+key],feat=d[split+'_features'],codes=d[split+'_codes'];ts.push({type:'scatter',mode:'markers',x:p.map(v=>v[0]),y:p.map(v=>v[1]),name:split==='train'?'训练展示512':'开发128',text:p.map((v,i)=>'窗口 '+d[split+'_indices'][i]+'<br>RQ码 '+codes[i].join(',')+'<br>价差 '+feat[i][0].toFixed(4)+'<br>不平衡 '+feat[i][6].toFixed(4)+'<br>已发生波动 '+feat[i][9].toFixed(4)),marker:{size:split==='train'?6:9,symbol:split==='train'?'circle':'diamond',opacity:split==='train'?.5:.9,color:code?codes.map(c=>c[0]):feat.map(v=>v[j]),colorscale:code?'Turbo':'Viridis',cmin:lo,cmax:hi,showscale:split==='development'}})}Plotly.react(key,ts,{template:'plotly_white',height:530,title:key==='raw'?'原始尺度PCA：强方向直接可见':'逐坐标标准化PCA：观察等尺度方向',xaxis:{title:'PC1'},yaxis:{title:'PC2'},margin:{t:65,l:60,r:20,b:50}},{responsive:true,displaylogo:false})}Plotly.react('spectrum',[{y:d.raw_cumulative,name:'原始尺度',mode:'lines'},{y:d.standardized_cumulative,name:'逐维标准化',mode:'lines'}],{template:'plotly_white',height:380,title:'累计方差：强方向之外仍有长尾',xaxis:{title:'主成分序号（从0开始）'},yaxis:{title:'累计方差比例',range:[0,1]},margin:{t:60,l:60,r:20,b:50}},{responsive:true,displaylogo:false})}document.getElementById('feature').onchange=draw;main().catch(console.error)</script></html>'''


def generate(root):
    torch.set_num_threads(4)
    payload=torch.load(root/'states.pt',map_location='cpu',weights_only=False)
    diagnostic=json.loads((root/'latent_diagnostics.json').read_text())
    train=payload['train'].double();dev=payload['development'].double();center=train.mean(0)
    eigen,basis=torch.linalg.eigh((train-center).T@(train-center)/(len(train)-1))
    basis=basis[:,-2:].flip(1)
    selected=payload['train_plot_positions']
    with np.load(root/'rq128/codes.npz') as codes:
        output=dict(train_raw=((train[selected]-center)@basis).numpy().tolist(),development_raw=((dev-center)@basis).numpy().tolist(),
            train_standardized=diagnostic['projections']['nonlinear']['train'],development_standardized=diagnostic['projections']['nonlinear']['development'],
            train_features=payload['train_plot_features'].tolist(),development_features=payload['development_features'].tolist(),
            train_codes=codes['train'][selected].tolist(),development_codes=codes['development'].tolist(),
            train_indices=payload['train_indices'][selected].tolist(),development_indices=payload['development_indices'].tolist(),
            raw_cumulative=diagnostic['models']['nonlinear']['raw']['cumulative_variance'],
            standardized_cumulative=diagnostic['models']['nonlinear']['standardized']['cumulative_variance'],
            fit_split='8192 training windows only',source_state='nonlinear window vector1024',independent_test_used=False)
    folder=root/'latent_inspection';folder.mkdir(exist_ok=True)
    (folder/'data.json').write_text(json.dumps(output,ensure_ascii=False))
    (folder/'index.html').write_text(PAGE)
    link=root/'viewer/latent_raw'
    if not link.exists():link.symlink_to(folder,target_is_directory=True)
    print(folder)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);generate(p.parse_args().root)
