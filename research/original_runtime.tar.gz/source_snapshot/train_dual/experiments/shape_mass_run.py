"""Queued fully neural decoder factorial after the mid/tail loss experiment."""
import argparse
from datetime import datetime
import html
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import torch

from model.autoencoder.shape_mass_vae import ShapeMassOrderBookVAE
from train_dual.experiments import local_hint_run as shared
from train_dual.experiments.goal_evaluate import assess_file
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read,fmt,STYLE
from train_dual.experiments.recall_goal_run import wave_criterion,record
from train_dual.experiments.region_task_run import gpu_free
from train_dual.util.checkpoint import atomic_save,freeze_sources,load_for_inference
from train_dual.util.hint_training import restore_shape_mass_adam
from train_dual.util.phase_training import tensor_digest


LABELS={'control':'原数量输出','shape':'形状修正','mass':'总量修正','both':'形状＋总量修正'}


def select_source(rows):
    """Use a common endpoint, prefer price-safe sources without moving the ruler."""
    groups={lane:{r['step'] for r in rows if r['lane']==lane} for lane in ['baseline','mid','tail','both']}
    common=set.intersection(*groups.values())
    if not common:raise ValueError('No common checkpoint across the four loss controls')
    eligible=[r for r in rows if r['step']==max(common)]
    safe=[r for r in eligible if r['price_rmse']<=r['price_limit'] and r['mid_delta_rmse']<=r['mid_delta_limit']]
    source=max(safe or eligible,key=lambda r:(r['recall100'] or 0.,-r['price_rmse']))
    return source,bool(safe)


def actual_controller_pids(goal):
    """A state file alone is not proof that the predecessor is running."""
    found=[]
    for p in Path('/proc').glob('[0-9]*/cmdline'):
        try:args=p.read_bytes().split(b'\0')
        except (FileNotFoundError,PermissionError,ProcessLookupError):continue
        if b'train_dual.experiments.recall_goal_run' in args and str(goal).encode() in args:
            found.append(int(p.parent.name))
    return found


def render(root):
    plan=read(root/'plan.json',{});status=read(root/'status.json',{})
    parts=[f'<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta http-equiv="refresh" content="30"><title>神经数量Decoder形状与总量</title><style>{STYLE}</style><main>',
           '<h1>可学习形状 × 总量修正</h1>',f'<div class="note">状态：{html.escape(status.get("state","prepared"))}</div>',
           '<p>完整256分钟、双侧2048档；原可训练神经Encoder、唯一64×128 Gaussian。新增数量头只读取Z解码后的特征，不显式编码原始大单地址或数量。四组新增参数相同、零初始化输出相同；数据、增强、损失、原Adam及随机状态一致。</p>',
           '<p>先完成中间价保护×大单平衡实验，再按固定规则选择同一检查点。若该起点同时通过固定价格及分钟中间价变化门槛，四组均冻结Encoder和价格Decoder，并逐检查点核对哈希，保留已有价格结果；否则四组均继续联合训练，不能声称保证价格不变。所有组保留相同中间价保护和大单/误报目标。</p>',
           f'<p>训练协议：{html.escape(str(plan.get("training_protocol","等待上一轮真实结果")))}</p>',
           '<div class="wrap"><table><tr><th>组</th><th>进度</th><th>步数</th><th>召回</th><th>精确率</th><th>价格RMSE</th><th>分钟mid变化RMSE</th><th>开发门槛</th><th>图</th></tr>']
    for lane,label in plan.get('labels',{}).items():
        progress=read(root/lane/'progress.json',{})
        for step in [0,*plan['checkpoints']]:
            path=root/lane/f'step{step}_development.json'
            if not path.exists():continue
            result=assess_file(path,Path(plan['goal_root'])/'reference_evaluation.json')
            link=f'{lane}/step{step}_preview.html';image=f'<a href="{link}">中间价＋挂量线</a>' if (root/link).exists() else '—'
            vals=[label,f'{progress.get("step",0)}/{plan["steps"]}',step,fmt(result['recall100']),fmt(result['precision100']),fmt(result['price_rmse']),fmt(result['mid_delta_rmse']),result['pass']]
            parts.append('<tr>'+''.join(f'<td>{html.escape(str(v))}</td>' for v in vals)+f'<td>{image}</td></tr>')
    parts.extend(['</table></div><p>开发集为反复使用的16个2025Q1窗口，不能当作最终独立测试。大单按同时间/侧/档位≥100BTC统计。未读取预留Q2，不自动声明目标完成。</p>',
                  '<p><a href="design.md">结构与控制说明</a> · <a href="plan.json">配置</a> · <a href="source_snapshot/sha256.json">源码哈希</a> · <a href="../">上级目录</a></p></main></html>'])
    temp=root/'report.tmp';temp.write_text(''.join(parts));temp.replace(root/'index.html')


def prepare_queue(goal):
    queue=goal/'shape_mass_after';queue.mkdir();(queue/'logs').mkdir()
    (queue/'design.md').write_text((Path(__file__).resolve().parents[2]/'docs/models/SHAPE_MASS_DECODER.md').read_text())
    atomic_json(queue/'plan.json',dict(goal_root=str(goal),predecessor='round_001_mid_tail',wait_seconds=13*3600,per_cohort_training_seconds=43200,
        admission='fullylearnedneuralEncoder,noexplicitrawaddresscodec',selection='largestcommoncheckpoint,preferfixedpriceguardthenhigherrecall;freezeEncoder+Priceonlyifsafesource;fixedoriginalreferenceunchanged'))
    atomic_json(queue/'status.json',dict(state='prepared_waiting_predecessor'))
    freeze_sources(queue/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/queue.relative_to(Path(__file__).resolve().parents[2])
    (queue/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.shape_mass_run "{remote}"\n')
    render(queue);print(queue,flush=True)


def prepare_cohort(queue,source_row,price_safe):
    goal=queue.parent;parent=goal/'round_001_mid_tail';root=goal/'round_002_shape_mass';root.mkdir()
    for name in ['data','logs','seen','unseen',*LABELS]:(root/name).mkdir()
    for split in ['seen','unseen']:
        for lane in LABELS:(root/split/lane).mkdir()
    for name in ['train_indices.npy','val_indices.npy','seen_indices.npy','unseen_indices.npy','calibration_indices.npy','plotly.min.js','teacher.pt']:
        os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    os.link(source_row['checkpoint'],root/'source.pt')
    payload=torch.load(root/'source.pt',map_location='cpu',weights_only=False)
    if not payload['epoch_boundary']:raise ValueError('Need epoch-boundary source')
    plan=dict(read(parent/'plan.json'));plan.update(experiment='Fullyneuraldecoder:shape x mass2x2',labels=LABELS,
        lanes={lane:dict(hint=True,augmentation=True,protect_mid=True,use_tail=True,use_shape=lane in ['shape','both'],use_mass=lane in ['mass','both']) for lane in LABELS},
        source=str(root/'source.pt'),source_steps=payload['source_steps']+payload['step'],steps=4096,checkpoints=[512,1024,2048,4096],max_seconds=43200,
        gpu_workers=[[g,l] for g,l in zip([2,3,4,5],LABELS)],goal_root=str(goal),frozen_modules=['encoder','price_decoder'] if price_safe else [],
        training_protocol='freezeEncoder+Price,preservehashes' if price_safe else 'jointtraining,priceguardnotyetachieved',loss_variant='recall_guard',
        controls='Identicalzero-initialized546headparametersinallarms,samefullsourceweights,sourceAdam2groupsplusnewemptythirdgroup,RNG/data/augmentation/teacher/loss/4096updates. Samebothmid+tailobjectiveinallarms. Onlyshape/massswitchesdiffer. FixedpricebaselineNOTreset.',
        preview_descriptions={lane:'完整256分钟；2025Q1开发集已反复用于研究，非最终独立测试。唯一8192神经latent，数量Decoder形状/总量消融。' for lane in LABELS})
    plan['checkpoint_extras']={}
    for lane,spec in plan['lanes'].items():
        cfg=dict(plan['local_hint_config'],use_shape=spec['use_shape'],use_mass=spec['use_mass'])
        model=ShapeMassOrderBookVAE(**cfg,**plan['model_config'])
        missing,extra=model.load_state_dict(payload['model'],strict=False)
        if missing!=['shape_head.weight','mass_head.weight','mass_head.bias'] or extra:raise ValueError((missing,extra))
        digest=tensor_digest(model)
        if lane=='control':plan['initial_model_sha256']=digest
        elif digest!=plan['initial_model_sha256']:raise AssertionError('Mismatched initial parameters')
        restore_shape_mass_adam(model,payload['optimizer'],plan['original_parameter_names'])
        plan['checkpoint_extras'][lane]=dict(shape_mass_config=cfg)
        checkpoint=dict(format_version=1,model=model.state_dict(),unified_vae_config=plan['model_config'],shape_mass_config=cfg,config=payload['config'],step=0)
        atomic_save(checkpoint,root/lane/'initial.pt')
        if lane=='control':atomic_save(checkpoint,root/'initial.pt')
    atomic_json(root/'plan.json',plan)
    for name in ['calibration.json','data_contract.json']:(root/name).write_bytes((parent/name).read_bytes())
    for split in ['seen','unseen']:
        atomic_json(root/split/'plan.json',dict(plan,preview_descriptions={lane:'同年代训练诊断；seen实际参与训练，unseen排除学生索引但教师可能见过，不是最终独立测试。' for lane in LABELS}))
        os.link(root/'plotly.min.js',root/split/'plotly.min.js')
    (root/'design.md').write_bytes((queue/'design.md').read_bytes())
    atomic_json(root/'status.json',dict(state='prepared',source=source_row,price_safe=price_safe))
    freeze_sources(root/'source_snapshot');render(root)
    record(goal,'shape_mass_cohort_prepared',wave=root.name,source=source_row,price_safe=price_safe,
           hypothesis='Finequantityresponsesneednonlinearshapeamplification;factorialmasscontroltestsifglobalmasssuffices. Allinformationcomesfromlearned8192Z.')
    return root


def startup_audit(root):
    rows={}
    for lane in LABELS:
        data=read(root/lane/'step1_data_audit.json');shape=read(root/lane/'actual_shape_contract.json');grad=read(root/lane/'step8_gradient_audit.json')
        if not all([data,shape,grad]):return False
        rows[lane]=dict(data=data,shape=shape,gradient=grad)
    control=rows['control']['data']
    for row in rows.values():
        assert row['data']['training_indices']==control['training_indices'] and row['data']['edits']==control['edits']
        assert row['data']['losses']['loss']==control['losses']['loss']
    atomic_json(root/'startup_control_audit.json',dict(passed=True,same_initial_weights_function_losses_inputs=True,rows=rows));return True


def run_cohort(root):
    plan=read(root/'plan.json');children=[];started=time.monotonic();audited=False
    try:
        if any(gpu_free().get(g,0)<47000 for g in [2,3,4,5]):raise RuntimeError('Need idle GPUs2–5')
        for gpu,lane in plan['gpu_workers']:
            env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),PYTHONPATH=str(root/'source_snapshot'))
            with (root/'logs'/f'{lane}.log').open('ab',buffering=0) as log:
                p=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.shape_mass_run',str(root),'--lane',lane],cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            children.append((lane,gpu,p))
        atomic_json(root/'status.json',dict(state='running',children=[dict(role=l,gpu=g,pid=p.pid) for l,g,p in children]))
        while any(p.poll() is None for l,g,p in children):
            if time.monotonic()-started>plan['max_seconds']+900:raise TimeoutError('12hour+evaluation ceiling')
            if any(p.poll() not in [None,0] for l,g,p in children):raise RuntimeError('Owned shape/mass worker failed')
            if not audited:audited=startup_audit(root)
            render(root);time.sleep(10)
        if any(p.returncode for l,g,p in children):raise RuntimeError('Worker failed')
        atomic_json(root/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started))
    except BaseException as error:
        atomic_json(root/'status.json',dict(state='failed',error=repr(error)));raise
    finally:
        for l,g,p in children:
            if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)
        render(root)


def controller(queue):
    goal=queue.parent;plan=read(queue/'plan.json');started=time.monotonic()
    while True:
        state=read(goal/'status.json',{});kind=state.get('state','')
        if kind=='development_pass_requires_independent_confirmation':
            atomic_json(queue/'status.json',dict(state='not_run_candidate_requires_confirmation'));render(queue);return
        if kind=='cohort_complete_next_hypothesis_required':break
        if any(word in kind for word in ['failed','missing','investigation']):
            atomic_json(queue/'status.json',dict(state='not_run_predecessor_requires_investigation',predecessor=state));render(queue);return
        pids=actual_controller_pids(goal)
        if not pids:
            # Give the predecessor one observation interval to publish terminal state.
            time.sleep(10)
            if read(goal/'status.json',{}).get('state')!=kind:continue
            atomic_json(queue/'status.json',dict(state='deferred_predecessor_handle_missing',predecessor=state));render(queue);return
        if time.monotonic()-started>plan['wait_seconds']:raise TimeoutError('13hour predecessor wait ceiling')
        atomic_json(queue/'status.json',dict(state='verified_wait_loss_cohort',predecessor=kind,live_controller_pids=pids));render(queue);time.sleep(30)
    rows=read(goal/'candidates.json')['rows'];rows=[r for r in rows if r.get('experiment')=='round_001_mid_tail']
    source,safe=select_source(rows)
    waiting=time.monotonic()
    while any(gpu_free().get(g,0)<47000 for g in [2,3,4,5]):
        if time.monotonic()-waiting>3600:raise TimeoutError('1hour owned GPU wait ceiling')
        atomic_json(queue/'status.json',dict(state='waiting_verified_idle_gpus'));render(queue);time.sleep(20)
    root=prepare_cohort(queue,source,safe)
    atomic_json(queue/'status.json',dict(state='running_neural_decoder_cohort',cohort=root.name));render(queue)
    run_cohort(root)
    from train_dual.experiments.recall_goal_run import candidates,render as render_goal
    new=candidates(root,goal/'reference_evaluation.json')
    for row in new:row['experiment']=root.name
    all_rows=read(goal/'candidates.json')['rows']+new;atomic_json(goal/'candidates.json',dict(rows=all_rows))
    passing=[r for r in new if r['pass']]
    if passing:
        selected=max(passing,key=lambda r:(r['recall100'],-r['price_rmse']))
        atomic_json(goal/'candidate_for_confirmation.json',selected)
        state=dict(state='development_pass_requires_independent_confirmation',candidate=selected)
    else:state=dict(state='cohort_complete_next_hypothesis_required',wave=root.name,goal_achieved=False)
    atomic_json(goal/'status.json',state);atomic_json(queue/'status.json',dict(state='complete',cohort=root.name,goal_achieved=False))
    record(goal,'shape_mass_cohort_evaluated',wave=root.name,next='Freezeandconfirmactualpassingnativecandidate,orinspectfactorialresultsandchooseanewhypothesis. Goalremainsactive.');render_goal(goal);render(queue)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('root',type=Path);parser.add_argument('--prepare',action='store_true');parser.add_argument('--lane',choices=list(LABELS));args=parser.parse_args();root=args.root.resolve()
    def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        if args.prepare:prepare_queue(root)
        elif args.lane:shared.worker(root,args.lane,objective_factory=wave_criterion,optimizer_factory=restore_shape_mass_adam)
        else:controller(root)
    except BaseException as error:
        atomic_json((root/args.lane if args.lane else root)/'status.json',dict(state='failed',error=repr(error)));raise
