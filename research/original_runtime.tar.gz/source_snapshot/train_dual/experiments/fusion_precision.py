"""Re-evaluate frozen pilot weights with TF32 disabled, without retraining."""

import argparse
import json
from pathlib import Path

import numpy as np
import torch

from model.experimental.dual_fusion import FusedOrderBookVAE
from train_dual.experiments.long_worker import atomic_json, datasets, evaluate, forward
from train_dual.util.checkpoint import seed_everything
from train_dual.util.data import DualNormalizer


def evaluate_pair(root, variant):
    torch.set_num_threads(4)
    seed_everything(42)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    target = root / "strict_fp32" / variant
    target.mkdir(exist_ok=True)
    plan = json.loads((root / "plan.json").read_text())
    initial = torch.load(root / "initial.pt", map_location="cpu", weights_only=False)
    model = FusedOrderBookVAE(fusion_variant=variant, fusion_seed=42, **initial["model_config"])
    model.load_volume_initial(initial["model"])
    model.to("cuda:0")
    cfg = initial["config"]["normalization"]
    normalizer = DualNormalizer(tick_size=cfg["tick_size"], price_scale=cfg["price_scale"])
    data = datasets(root, initial, "val")
    for phase in ("initial", "final"):
        if phase == "final":
            saved = torch.load(root / variant / "final.pt", map_location="cpu", weights_only=False)
            model.load_state_dict(saved["model"], strict=True)
        previous = json.loads((root / variant / (phase + "_evaluation.json")).read_text())
        result = evaluate(model, normalizer, data, plan["evaluation_windows"], "cuda:0")
        previous.update(result=result, evaluation_backend="strict_fp32", cudnn_tf32=False, matmul_tf32=False)
        atomic_json(target / (phase + "_evaluation.json"), previous)
    model.eval()
    predictions, truths, masks = [], [], []
    with torch.inference_mode():
        for index in plan["example_indices"]:
            raw = {k: v.unsqueeze(0) for k, v in data[index].items()}
            batch = normalizer.prepare(raw, "cuda:0")
            out = forward(model, batch, False)
            predictions.append(np.stack([normalizer.inverse_price(out["price_norm"], batch)[0].cpu().numpy(),
                                         out["volume"][0].cpu().numpy()], -1))
            truths.append(raw["data"][0].numpy())
            masks.append(batch["mask"][0].cpu().numpy())
    np.savez_compressed(target / "profiles.npz", prediction=np.stack(predictions), truth=np.stack(truths), mask=np.stack(masks))
    print(json.dumps(dict(variant=variant, evaluated=True, backend="strict_fp32")), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("variant")
    args = parser.parse_args()
    evaluate_pair(args.root, args.variant)
