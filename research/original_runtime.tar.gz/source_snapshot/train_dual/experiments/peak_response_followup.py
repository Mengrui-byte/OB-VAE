"""Bounded follow-up: sampled decoder Jacobian and quantity-feature paths."""
import argparse
import json
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F

from model.autoencoder.unified_book_vae import UnifiedOrderBookVAE
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import load_for_inference, seed_everything


def main(root):
    plan=json.loads((root/'plan.json').read_text());parent=root.parents[1]/'recons'/Path(plan['parent']).name
    folder=root/'followup';folder.mkdir(exist_ok=True)
    config=json.loads((parent/'plan.json').read_text())
    raw={k:v.unsqueeze(0) for k,v in dataset(parent,'train')[plan['training_index']].items()}
    model,norm=load_for_inference(root/'checkpoint.pt','cuda:0');model.eval();model.requires_grad_(False)
    b=norm.prepare(raw,'cuda:0');t,s,k=plan['frame'],plan['side'],plan['rank'];flat=t*2+s
    peak=dict(b,volume=b['volume'].clone());peak['volume'][0,t,s,k]+=1000
    with torch.no_grad():
        baseline=call(model,b,False);changed=call(model,peak,False)
        full_features0=model.encoder.features(b['price'],b['volume'],b['mask'],b['tick_norm']).clone()
        full_features1=model.encoder.features(peak['price'],peak['volume'],peak['mask'],peak['tick_norm']).clone()
        features0=full_features0[flat].clone()
        features1=full_features1[flat].clone()
    delta=features1-features0
    groups={'none':[], 'raw_quantity':[1], 'log_only':[2],
            'multiscale_only':list(range(4,16)), 'log_and_multiscale':[2,*range(4,16)],
            'all_quantity':[1,2,*range(4,16)]}
    selected=[[]];last_spatial={}
    def inject(module,args,out):
        out=out.clone();row=features0.clone()
        if selected[0]:row[selected[0]]=features1[selected[0]]
        out[flat]=row
        if selected[0]==groups['all_quantity']:
            assert torch.equal(out,full_features1), 'All-channel transplant changed feature values'
        return out
    def spatial(module,args,out):last_spatial['value']=out[flat].detach().cpu()
    hs=model.encoder.features.register_forward_hook(inject)
    hh=model.encoder.spatial[-1].register_forward_hook(spatial)
    results={};reference=None;input_vectors={};mu_vectors={}
    try:
        with torch.no_grad():
            for name,channels in groups.items():
                selected[0]=channels
                out=call(model,b,False)
                if reference is None:reference=last_spatial['value'].clone()
                dfeature=torch.zeros_like(delta)
                if channels:dfeature[channels]=delta[channels]
                projected=F.conv1d(dfeature[None],model.encoder.input_proj.weight,bias=None)
                skip=projected
                for layer in model.encoder.down:
                    skip=F.conv1d(skip,layer.weight,bias=None,stride=2,padding=1)
                input_vectors[name]=projected.flatten().cpu()
                mu_vectors[name]=(out['z']-baseline['z']).flatten().cpu()
                results[name]=dict(channels=channels,input_projected_delta_l2=float(projected.norm()),
                    linear_skip_space_delta_l2=float(skip.norm()),
                    actual_spatial_delta_l2=float((last_spatial['value']-reference).norm()),
                    latent_delta_l2=float((out['z']-baseline['z']).norm()),
                    target_output_delta=float(out['volume'][0,t,s,k]-baseline['volume'][0,t,s,k]))
                if name=='none':assert float((out['volume']-baseline['volume']).abs().max())<2e-6
                if name=='all_quantity':
                    difference=float((out['volume']-changed['volume']).abs().max())
                    atomic_json(folder/'full_transplant_replay.json',dict(max_abs_output_difference=difference,tolerance=2e-6,exact_feature_values=True))
                    assert difference<2e-6
    finally:hs.remove();hh.remove()
    def cosine(a,c):
        den=float(a.norm()*c.norm())
        return float(a.dot(c))/den if den>1e-25 else None
    feature_report=dict(groups=results,
        raw_vs_log_input_projection_cosine=cosine(input_vectors['raw_quantity'],input_vectors['log_and_multiscale']),
        raw_vs_log_latent_delta_cosine=cosine(mu_vectors['raw_quantity'],mu_vectors['log_and_multiscale']),
        input_projection_column_norms=model.encoder.input_proj.weight[:,:,0].norm(dim=0).cpu().tolist(),
        scope='One-coordinate feature-channel transplantation, no training. Nonlinear branch deltas need not add linearly. Linear skip chain omits residual branches and is only one exact computational path.')
    atomic_json(folder/'feature_paths.json',feature_report)
    ranks=np.unique(np.r_[np.linspace(0,2047,16,dtype=int),k]).tolist()
    z0=baseline['z'].detach();price={key:baseline[key].detach() for key in ['price_norm','gap_norm','mid_norm','spread_norm']}
    dz=(changed['z']-baseline['z']).detach().flatten().cpu()
    results_j={}
    for name in ['trained','fresh_reference']:
        if name=='trained':decoder=model.volume_decoder
        else:
            torch.manual_seed(42)
            fresh=UnifiedOrderBookVAE(**config['model_config']).to('cuda:0').eval().requires_grad_(False)
            decoder=fresh.volume_decoder
        z=z0.clone().requires_grad_(True)
        q=decoder(z,price,b['mask'],b['tick_norm'],b['times'])
        rows=[]
        for i,rank in enumerate(ranks):
            grad=torch.autograd.grad(q[0,t,s,rank],z,retain_graph=i<len(ranks)-1)[0]
            rows.append(grad.detach().flatten().cpu())
            atomic_json(folder/'jacobian_progress.json',dict(case=name,rows=i+1,total=len(ranks)))
        j=torch.stack(rows).double();norms=j.norm(dim=1)
        unit=j/norms[:,None].clamp_min(1e-25)
        singular=torch.linalg.svdvals(unit)
        energy=singular.square();energy=energy/energy.sum().clamp_min(1e-25)
        cos=unit@unit.T;offdiag=cos[~torch.eye(len(ranks),dtype=torch.bool)]
        actual=(j@dz.double()).tolist()
        results_j[name]=dict(ranks=ranks,row_gradient_norms=norms.tolist(),
            row_normalized_singular_energy=energy.tolist(),first_component_fraction=float(energy[0]),
            first_four_fraction=float(energy[:4].sum()),
            effective_rank=float(torch.exp(-(energy*energy.clamp_min(1e-25).log()).sum())),
            pairwise_row_cosine_mean=float(offdiag.mean()),pairwise_row_cosine_min=float(offdiag.min()),
            pairwise_row_cosine_max=float(offdiag.max()),actual_encoder_delta_directional_responses=actual)
        np.savez_compressed(folder/f'{name}_sampled_jacobian.npz',jacobian=j.numpy(),ranks=np.array(ranks))
        del q,z,grad,rows,decoder
        if name=='fresh_reference':del fresh
        torch.cuda.empty_cache()
    atomic_json(folder/'sampled_decoder_jacobian.json',dict(cases=results_j,optimizer_updates=0,
        scope='17sampled outputcoordinates inoneframe/side, directZ path withfixedtrainedpredictedpriceconditions. Local Jacobian only, not global latent or data intrinsicrank. Fresh reference is a descriptive random-initialization comparison, not a matched training-capacity result.'))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('root',type=Path)
    args=parser.parse_args();torch.set_num_threads(4);seed_everything(42);strict_precision();main(args.root.resolve())
