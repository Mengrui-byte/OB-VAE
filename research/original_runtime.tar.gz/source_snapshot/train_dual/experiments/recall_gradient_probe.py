"""Read-only FP32 CPU gradient directions on fixed training windows."""
import argparse
import hashlib
import itertools
import json
import os
from pathlib import Path
import time

import numpy as np
import torch
from torch.nn import functional as F

from model.losses.recall_guard import RecallGuardBookLoss
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.gradient_audit import cos,flatnorm
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.unified_8192_run import call
from train_dual.util.checkpoint import freeze_sources,load_for_inference
from train_dual.util.phase_training import tensor_digest


def partition(values,out,batch,criterion,frequency=False):
    mask=batch['mask']
    point=F.huber_loss(out['price_norm'].float(),batch['price'].float(),reduction='none')
    indices=batch['volume'].masked_fill(~mask,-torch.inf).topk(min(criterion.topk,mask.shape[-1]),-1).indices
    chosen=mask.gather(-1,indices)
    price=criterion.price_weight*values['price']+criterion.pair_weight*(point.gather(-1,indices)*chosen).sum()/chosen.sum().clamp_min(1)
    if frequency:
        return dict(price=price,quantity_and_hint=values['pre_guard_loss']-price,
                    mid_level=values['mid_level_mse'],mid_delta=values['mid_delta_mse'])
    return dict(price=price,quantity_and_hint=values['pre_guard_loss']-price,
                mid=values['mid_protection'],positive=values['tail_positive_huber'],false_positive=values['tail_false_positive_huber'])


def prepare(goal,frequency=False):
    root=goal/('price_frequency_gradient_probe' if frequency else 'current_gradient_probe');root.mkdir()
    parent=goal/'round_001_mid_tail'
    indices=np.load(parent/'calibration_indices.npy')[[0,-1]].tolist()
    lanes=['mid'] if frequency else ['baseline','mid'];step=4096 if frequency else 1024
    for lane in lanes:os.link(parent/lane/f'step{step}.pt',root/f'{lane}.pt')
    plan=dict(parent=str(parent),indices=indices,lanes=lanes,step=step,frequency=frequency,threads=8,max_seconds=1800,
              scope=f'Two preselected training calibration windows; source checkpoints{step}; readonly CPU FP32 gradients, not actual BF16 accumulated/clipped Adam updates. No augmentation, no optimizer, no development/test reads. Teacher hint recomputed from the same raw input. No population-level conflict claim from two windows. Frequency mode splits level and one-minute-difference MSE; it does not include successor tail auxiliaries and does not choose a training coefficient.')
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot')
    print(root,flush=True)


def run(root):
    plan=json.loads((root/'plan.json').read_text());parent=Path(plan['parent'])
    config=json.loads((parent/'plan.json').read_text());cal=json.loads((parent/'calibration.json').read_text())
    torch.set_num_threads(plan['threads']);torch.manual_seed(42)
    teacher,tn=load_for_inference(parent/'teacher.pt','cpu');teacher.eval().requires_grad_(False)
    data=dataset(parent,'train');targets={};raws={};windows={};started=time.monotonic()
    atomic_json(root/'status.json',dict(state='running',pid=os.getpid(),completed_records=0))
    for index in plan['indices']:
        raw={k:v.unsqueeze(0) for k,v in data[index].items()};raws[index]=raw
        assert list(raw['data'].shape)==[1,256,2,2048,2]
        start=int(data.base.starts[index]);absolute=data.base.times[start:start+256]
        assert len(absolute)==256 and np.all(np.diff(absolute//60_000_000)==1)
        windows[index]=dict(raw_shape=list(raw['data'].shape),consecutive_minute_buckets=True,first_utc=str(np.datetime64(int(absolute[0]),'us')),last_utc=str(np.datetime64(int(absolute[-1]),'us')))
        b=tn.prepare(raw,'cpu')
        with torch.no_grad():_,targets[index]=teacher.encode_fused(*[b[k] for k in ['price','volume','mask','tick_norm','times']])
    del teacher
    atomic_json(root/'actual_window_contract.json',dict(passed=True,windows=windows))
    rows=[]
    for lane in plan['lanes']:
        model,norm=load_for_inference(root/f'{lane}.pt','cpu');model.train()
        initial=tensor_digest(model)
        criterion=RecallGuardBookLoss(config['normalization']['quantity_scale'],mode='shape_mass',use_hint=True,
            hint_weight=cal['hint_weight'],hint_mean=cal['channel_mean'],hint_scale=cal['channel_scale'],**config['objective'])
        names,params=zip(*model.named_parameters())
        for index in plan['indices']:
            if time.monotonic()-started>plan['max_seconds']:raise TimeoutError('Readonly CPU probe time ceiling')
            batch=norm.prepare(raws[index],'cpu');out=call(model,batch,False)
            assert list(out['z'].shape)==[1,64,128]
            assert list(out['price_norm'].shape)==list(out['volume'].shape)==[1,256,2,2048]
            atomic_json(root/'actual_shape_contract.json',dict(passed=True,raw=[1,256,2,2048,2],mu=list(out['mu'].shape),logvar=list(out['logvar'].shape),z=list(out['z'].shape),price=list(out['price_norm'].shape),quantity=list(out['volume'].shape)))
            values=criterion(out,batch,teacher_local=targets[index]);parts=partition(values,out,batch,criterion,frequency=plan.get('frequency',False))
            torch.testing.assert_close(parts['price']+parts['quantity_and_hint'],values['pre_guard_loss'])
            if plan.get('frequency',False):torch.testing.assert_close(parts['mid_level']+parts['mid_delta'],values['mid_protection'])
            gradients={};latent_gradients={}
            for i,(key,value) in enumerate(parts.items()):
                computed=torch.autograd.grad(value,[*params,out['z']],retain_graph=i<len(parts)-1,allow_unused=True)
                gradients[key]=tuple(g.detach() if g is not None else None for g in computed[:-1])
                latent_gradients[key]=computed[-1].detach() if computed[-1] is not None else None
            groups={}
            for prefix in ['encoder','encoder.frame','encoder.patch','encoder.mu','price_decoder','volume_decoder']:
                ii=[i for i,n in enumerate(names) if n.startswith(prefix+'.')]
                gs={k:[v[i] for i in ii] for k,v in gradients.items()}
                groups[prefix]=dict(l2={k:flatnorm(v) for k,v in gs.items()},cosines={a+'__'+b:cos(gs[a],gs[b]) for a,b in itertools.combinations(gs,2)})
            gs={k:[v] for k,v in latent_gradients.items()}
            groups['z']=dict(l2={k:flatnorm(v) for k,v in gs.items()},cosines={a+'__'+b:cos(gs[a],gs[b]) for a,b in itertools.combinations(gs,2)})
            nonfinite=sum(int((~torch.isfinite(g)).sum()) for values0 in gradients.values() for g in values0 if g is not None)
            assert nonfinite==0
            row=dict(lane=lane,index=index,groups=groups,losses={k:float(v.detach()) for k,v in parts.items()},nonfinite_gradients=nonfinite,
                     mid_weight=cal['mid_weight'],tail_weight=cal['tail_weight'],elapsed_seconds=time.monotonic()-started)
            rows.append(row);atomic_json(root/'records.json',dict(rows=rows,scope=plan['scope']))
            atomic_json(root/'status.json',dict(state='running',pid=os.getpid(),completed_records=len(rows),elapsed_seconds=time.monotonic()-started))
            print(lane,index,groups['encoder'],flush=True)
            del out,values,parts,gradients,latent_gradients,computed,gs
        assert tensor_digest(model)==initial
        atomic_json(root/f'{lane}_readonly_audit.json',dict(passed=True,initial_and_final_model_sha256=initial,checkpoint_sha256=hashlib.sha256((root/f'{lane}.pt').read_bytes()).hexdigest(),optimizer_updates=0))
        del model
    atomic_json(root/'status.json',dict(state='complete',completed_records=len(rows),elapsed_seconds=time.monotonic()-started))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--frequency',action='store_true');a=p.parse_args()
    root=a.root.resolve()
    try:
        if a.prepare:prepare(root,frequency=a.frequency)
        else:run(root)
    except BaseException as error:
        if not a.prepare:atomic_json(root/'status.json',dict(state='failed',error=repr(error)))
        raise
