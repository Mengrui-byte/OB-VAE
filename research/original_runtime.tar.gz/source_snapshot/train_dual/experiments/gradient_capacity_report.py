"""Live, browser-readable gradient audit and controlled fitting results."""
import argparse
import csv
from datetime import datetime
import json
from pathlib import Path
import time

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np
from train_dual.experiments.long_worker import atomic_json

PAGE='''<!doctype html><html lang=zh-CN><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>梯度传播与容量×损失诊断</title><style>body{background:#f5f6f8;color:#243447;font:15px/1.85 system-ui;margin:0}main{max-width:1460px;margin:25px auto;background:white;border:1px solid #dfe5ed;padding:38px 45px}h1{font-size:29px}h2{font-size:22px;margin-top:30px}table{border-collapse:collapse;width:100%;font-size:12px}th,td{padding:9px;text-align:left;border-bottom:1px solid #e0e5eb}th{background:#f6f8fb}.wrap{overflow:auto}.note{background:#f5f8fb;border-left:3px solid #7596b4;padding:15px 20px;margin:20px 0}.gold{background:#faf6ee;border-color:#b99a64}a{color:#366590}img{width:100%;height:auto}button,input{font:inherit;padding:5px 8px}.muted{color:#6c798b;font-size:12px}.plots{display:grid;grid-template-columns:1fr 1fr;gap:20px}.wideplot{width:100%}code{font:12px monospace;background:#edf2f7;padding:2px 4px}details{margin:15px 0}summary{cursor:pointer}@media(max-width:750px){main{padding:24px 16px;margin:8px}.plots{grid-template-columns:1fr}}@media print{body{background:white}main{border:0;padding:0;margin:0}.note,img,table{break-inside:avoid}}</style><main><div class=muted>CONTROLLED DIAGNOSIS · COMPLETE 256-FRAME WINDOWS</div><h1>梯度是否正常？容量还是损失限制了重建？</h1><p>固定同一AE2048权重，在4个预先选定的训练窗口检查每层梯度与方向。随后做容量128/256通道 × 原Huber/数量MSE的2×2拟合对照。每个输入仍为完整256分钟、双侧各2048档。所有新结果位于本recons目录。</p><p id=status>加载中</p><p><a href=plan.json>配置及控制变量</a> · <a href=gradient_audit/summary.json>梯度原始摘要</a> · <a href=gradient_audit/layer_gradients.csv>逐层梯度CSV</a> · <a href=progress.json>完整实时数据</a> · <a href=../>全部实验</a></p><div class=note>梯度范数回答“信号有多大”，不独立证明方向正确。这里同时计算价格/数量梯度夹角，并用中心有限差分检验自动微分。沿负梯度的小步应下降；较大步或带历史动量的Adam一步未必下降，不直接解释为反传错误。</div><h2>1. 梯度方向与数值核对</h2><div id=summary>待诊断</div><div class=wrap><table><thead><tr><th>模块</th><th>价格梯度L2</th><th>数量梯度L2</th><th>总梯度L2</th><th>价格/数量cos</th></tr></thead><tbody id=modules></tbody></table></div><h3>有限差分方向检查</h3><div class=wrap><table><thead><tr><th>参数扰动L2</th><th>自动微分预测方向导数</th><th>中心有限差分</th><th>相对误差</th><th>负梯度后的总损失</th><th>正梯度后的总损失</th></tr></thead><tbody id=finite></tbody></table></div><h3>同一梯度：恢复Adam动量与新Adam的一步</h3><div class=wrap><table><thead><tr><th>优化器</th><th>更新后价格目标</th><th>更新后数量目标</th><th>更新后总目标</th><th>更新/负总梯度cos</th><th>更新/负数量梯度cos</th></tr></thead><tbody id=adam></tbody></table></div><p id=before class=muted></p><h2>2. 各层的L2范数与每参数RMS</h2><p>同一有效batch4的平均梯度；层参数数目不同，RMS比单独比较L2更容易解释。相对梯度=‖g‖/‖θ‖，权重初值为零时不作该比值解释。AE使用μ且β=0，logvar头不参与有效优化，零梯度为预期行为。</p><div id=gradient-images></div><label>筛选层名 <input id=filter placeholder="encoder / volume_decoder / temporal"></label><div class=wrap style="max-height:600px;overflow:auto"><table><thead><tr><th>层</th><th>参数数</th><th>总梯度L2</th><th>总梯度RMS</th><th>数量梯度L2</th><th>价格/数量cos</th><th>裁剪后L2</th><th>零梯度比例</th><th>状态</th></tr></thead><tbody id=layers></tbody></table></div><details><summary>查看激活张量上的梯度</summary><p>首次训练窗口FP32、只为插桩关闭激活检查点。数值是损失对模块输出的梯度，不能与不同张量尺寸的L2直接当作衰减率。</p><div class=wrap><table><thead><tr><th>模块</th><th>激活形状</th><th>激活RMS</th><th>梯度RMS</th><th>梯度L2</th></tr></thead><tbody id=activations></tbody></table></div></details><h2>3. 2×2容量与损失拟合对照</h2><p>8192是主线；16384仅用于容量诊断。所有组从AE2048共同权重出发，扩大组使用平衡正负扰动并平分解码输入权重，初始函数误差单独核对。四组均使用新AdamW1e−4、batch1、裁剪1、固定4个训练窗口顺序、512次更新。价格损失与上采样不变。两因素分别有匹配对照，并可观察交互。</p><div class=wrap><table><thead><tr><th>方案</th><th>状态</th><th>额外更新</th><th>整窗latent</th><th>训练价格RMSE</th><th>训练挂量RMSE</th><th>分钟挂量变化相关</th><th>≥100BTC召回</th></tr></thead><tbody id=capacity></tbody></table></div><div id=capacity-images></div><div class="note gold">小训练集拟合成功，只能说明此配置在这些完整窗口上具备拟合能力；不能直接证明全64窗或样本外效果。未拟合成功也不能单独证明容量不足，需要结合训练时长、目标与优化诊断。原4组损失对照继续，不改写其配置。</div><h2>4. 真实训练日志中的裁剪</h2><p>只统计已有日志记录点，通常每8次更新记录一次；不是每次更新的完整统计。全局裁剪会缩放各层原始梯度，后续Adam还受到动量与二阶矩影响。</p><div class=wrap><table><thead><tr><th>训练轨迹</th><th>已记录点数</th><th>记录点裁剪比例</th><th>裁剪前L2中位数</th><th>裁剪系数中位数</th></tr></thead><tbody id=clipping></tbody></table></div><p class=muted>固定seed42，纯重建目标，无未来收益。2025Q1仅作已反复使用的开发集。本页自动刷新，详细结果包含原始检查点、数据索引和冻结实现。</p></main><script>let data;const $=id=>document.getElementById(id),f=(v,n=5)=>Number.isFinite(v)?v.toPrecision(n):'—';function row(xs){let tr=document.createElement('tr');for(let x of xs){let td=document.createElement('td');td.textContent=x;tr.append(td)}return tr}function layers(){let q=$('filter').value.toLowerCase();$('layers').replaceChildren(...(data.layers||[]).filter(x=>x.layer.toLowerCase().includes(q)).map(x=>row([x.layer,x.parameters,f(x.total_grad_l2),f(x.total_grad_rms),f(x.quantity_grad_l2),f(x.price_quantity_cosine),f(x.clipped_grad_l2),f(x.zero_fraction*100,3)+'%',x.expected_inactive?'AE预期不活跃':x.nonfinite?'非有限值':x.total_grad_l2===0?'零梯度待核对':'有有限梯度'])))}async function refresh(){data=await(await fetch('progress.json?t='+Date.now())).json();$('status').textContent='状态：'+data.status.state+'；更新：'+data.time;let a=data.audit;if(a){let b=a.effective_batch4;$('summary').textContent='有效batch4：价格梯度L2 '+f(b.price_grad_l2)+'；数量梯度L2 '+f(b.quantity_grad_l2)+'；cos '+f(b.price_quantity_cosine)+'；全局裁剪系数 '+f(b.global_clip_coefficient)+'。FP32/BF16总梯度cos '+f(a.precision.cosine)+'；Softplus导数<1e−4比例 '+f(a.output_gate.softplus_derivative_lt_1e4_fraction*100)+'%。';$('modules').replaceChildren(...Object.entries(a.modules).map(([k,v])=>row([k,f(v.price_l2),f(v.quantity_l2),f(v.total_l2),f(v.price_quantity_cosine)])));$('finite').replaceChildren(...a.finite_difference.map(v=>row([v.epsilon_parameter_l2,f(v.predicted_derivative),f(v.central_finite_difference),f(v.relative_error),f(v.negative_gradient_losses.total),f(v.positive_gradient_losses.total)])));$('before').textContent='更新前：价格目标 '+f(a.base_losses.price)+'，数量目标 '+f(a.base_losses.quantity)+'，总目标 '+f(a.base_losses.total)+'。';$('adam').replaceChildren(...Object.entries(a.adam_one_step).map(([k,v])=>row([k,f(v.losses_after.price),f(v.losses_after.quantity),f(v.losses_after.total),f(v.cosine_with_negative_total_gradient),f(v.cosine_with_negative_quantity_gradient)])));$('clipping').replaceChildren(...Object.entries(a.training_clipping_logs).map(([k,v])=>row([k,v.recorded_updates,f(v.clipped_fraction*100,3)+'%',f(v.median_preclip_l2),f(v.median_clip_coefficient)])))}layers();$('activations').replaceChildren(...(data.activations||[]).map(v=>row([v.layer,JSON.stringify(v.shape),f(v.activation_rms),f(v.gradient_rms),f(v.gradient_l2)])));$('capacity').replaceChildren(...Object.entries(data.capacity).map(([k,v])=>{let m=v.evaluations?.at(-1),d=m?.result,mm=d?.metrics;return row([v.label,v.status?.state||'等待',v.progress?.step||0,JSON.stringify(v.progress?.latent_shape||v.latent_shape),f(mm?.price_usdt.rmse),f(mm?.quantity_btc.rmse),f(mm?.temporal_log_quantity_1_minutes.correlation),d?f(d.thresholds['100'].recall*100,3)+'%':'—'])}));for(let [id,files] of [['gradient-images',data.gradient_figures],['capacity-images',data.capacity_figures]]){$(id).replaceChildren(...(files||[]).map(x=>{let a=document.createElement('a');a.href=x;let img=document.createElement('img');img.alt=x;img.src=x+'?v='+data.figure_version;a.append(img);return a}))}}$('filter').oninput=layers;refresh().catch(console.error);setInterval(()=>refresh().catch(console.error),15000)</script></html>'''


def read(path,default=None):
 try:return json.loads(path.read_text())
 except (OSError,ValueError):return default


def gradient_figures(root,audit,layers):
 folder=root/'gradient_audit';font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc';font_manager.fontManager.addfont(font);plt.rcParams.update({'font.family':font_manager.FontProperties(fname=font).get_name(),'axes.unicode_minus':False,'font.size':9})
 fields=list(layers[0]);
 with (folder/'layer_gradients.csv').open('w',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(layers)
 rows=[v for v in layers if not v['expected_inactive']];x=np.arange(len(rows));fig,axes=plt.subplots(2,1,figsize=(19,10),layout='constrained')
 for key,label,color in [('price_grad_l2','价格梯度','#b27c33'),('quantity_grad_l2','数量梯度','#337c70'),('total_grad_l2','总梯度','#366590')]:axes[0].semilogy(x,[max(v[key],1e-15) for v in rows],color=color,label=label,lw=1.)
 axes[0].set_title('每层参数梯度L2（有效batch4平均，裁剪前）');axes[0].set_ylabel('L2范数');axes[0].legend()
 axes[1].semilogy(x,[max(v['total_grad_rms'],1e-15) for v in rows],color='#366590',lw=1.2,label='每参数梯度RMS');axes[1].set_ylabel('RMS');axes[1].legend()
 for ax in axes:ax.grid(alpha=.18);ax.set_xticks(x[::3]);ax.set_xticklabels([rows[i]['layer'] for i in x[::3]],rotation=90,fontsize=6)
 fig.savefig(folder/'gradient_layers.png',dpi=150);fig.savefig(folder/'gradient_layers.svg');plt.close(fig)
 keys=['encoder','encoder.mu','encoder.frame','encoder.patch','price_decoder','volume_decoder','volume_decoder.temporal','volume_decoder.spatial','volume_decoder.geometry','volume_decoder.quantity'];m=audit['modules'];fig,axes=plt.subplots(1,2,figsize=(15,6),layout='constrained');x=np.arange(len(keys));axes[0].barh(x-.17,[max(m[k]['price_l2'],1e-15) for k in keys],height=.32,color='#b27c33',label='价格梯度');axes[0].barh(x+.17,[max(m[k]['quantity_l2'],1e-15) for k in keys],height=.32,color='#337c70',label='数量梯度');axes[0].set_xscale('log');axes[0].set_yticks(x,keys);axes[0].legend();axes[0].set_title('关键模块梯度强度')
 values=np.array([np.nan if m[k]['price_quantity_cosine'] is None else m[k]['price_quantity_cosine'] for k in keys])[:,None];im=axes[1].imshow(values,aspect='auto',cmap='RdBu',vmin=-1,vmax=1);axes[1].set_yticks(x,keys);axes[1].set_xticks([0],['价格 / 数量梯度cos']);fig.colorbar(im,ax=axes[1],shrink=.8);fig.savefig(folder/'gradient_modules.png',dpi=150);plt.close(fig)
 return ['gradient_audit/gradient_layers.png','gradient_audit/gradient_modules.png']


def capacity_figure(root,capacity):
 font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc';font_manager.fontManager.addfont(font);plt.rcParams.update({'font.family':font_manager.FontProperties(fname=font).get_name(),'axes.unicode_minus':False,'font.size':10})
 fig,axes=plt.subplots(2,2,figsize=(14,8),layout='constrained')
 for (key,c),color in zip(capacity.items(),['#366590','#337c70','#b27c33','#ab6173']):
  es=c['evaluations'];steps=[e['step'] for e in es]
  for ax,metric,title in zip(axes.flat,['price_usdt','quantity_btc','temporal_log_quantity_1_minutes','tail'],['训练价格RMSE USDT','训练挂量RMSE BTC','训练分钟挂量变化相关','训练≥100BTC召回']):
   values=[e['result']['thresholds']['100']['recall'] if metric=='tail' else e['result']['metrics'][metric]['correlation' if metric.startswith('temporal') else 'rmse'] for e in es];ax.plot(steps,values,marker='o',lw=1.3,color=color,label=c['label']);ax.set_title(title);ax.grid(alpha=.18);ax.set_xlabel('额外更新');ax.legend(fontsize=8)
 fig.suptitle('容量×损失2×2｜同4个完整256分钟训练窗口｜同AE2048起点',fontsize=14);fig.savefig(root/'capacity_curves.png',dpi=150);fig.savefig(root/'capacity_curves.svg');plt.close(fig);return ['capacity_curves.png']


def monitor(root):
 root=root.resolve();plan=read(root/'plan.json');(root/'index.html').write_text(PAGE);gradient_plots=[];capacity_plots=[];last_capacity=None;figversion=0
 index=root.parents[1]/'recons/index.html';s=index.read_text();link=root.name+'/'
 if link not in s:index.write_text(s.replace('</main>',f'<p><a href="{link}">每层梯度与容量×损失控制诊断</a></p></main>'))
 while True:
  status=read(root/'status.json',{});a=read(root/'gradient_audit/summary.json');ls=read(root/'gradient_audit/layer_gradients.json',[]);acts=read(root/'gradient_audit/activation_gradients.json',[]);capacity={}
  if a and ls and not gradient_plots:gradient_plots=gradient_figures(root,a,ls);figversion+=1
  for lane,config in plan['lanes'].items():
   evaluations=[]
   for step in [0,*plan['checkpoints']]:
    d=read(root/lane/f'step{step}_train.json')
    if d:evaluations.append(dict(step=step,result=d['result']))
   capacity[lane]=dict(label=plan['labels'][lane],status=read(root/lane/'status.json'),progress=read(root/lane/'progress.json'),latent_shape=[1,64,config['latent_channels']],evaluations=evaluations)
  mark=tuple((k,len(v['evaluations'])) for k,v in capacity.items())
  if any(v['evaluations'] for v in capacity.values()) and mark!=last_capacity:capacity_plots=capacity_figure(root,capacity);last_capacity=mark;figversion+=1
  atomic_json(root/'progress.json',dict(time=datetime.now().isoformat(),status=status,audit=a,layers=ls,activations=acts,capacity=capacity,gradient_figures=gradient_plots,capacity_figures=capacity_plots,figure_version=figversion))
  if status.get('state') in ['complete','failed','partial_failure']:break
  time.sleep(10)

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);monitor(p.parse_args().root)
