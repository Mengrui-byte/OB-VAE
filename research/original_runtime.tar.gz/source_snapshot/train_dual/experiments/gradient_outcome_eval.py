"""Compare all2x2endpoints under common objectives andallocation/scale diagnostics."""
import argparse
import json
from pathlib import Path
import torch
from train_dual.util.checkpoint import load_for_inference,seed_everything
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.experiments.long_worker import atomic_json
from model.losses.controlled_book import ControlledBookLoss


def run(root):
 torch.set_num_threads(4);seed_everything(42);strict_precision();plan=json.loads((root/'plan.json').read_text());raw=torch.load(root/'small_train.pt',map_location='cpu',weights_only=False);q0=plan['normalization']['quantity_scale'];criteria={k:ControlledBookLoss(q0,mode=k) for k in ['baseline','quantity_mse','shape_mass']};results={}
 paths={'initial':root/'initial.pt',**{k:root/k/'step512.pt' for k in plan['lanes']}}
 for name,path in paths.items():
  model,norm=load_for_inference(path,'cuda:0');parts=[]
  with torch.inference_mode():
   for i in range(4):
    b=norm.prepare({k:v[i:i+1] for k,v in raw.items()},'cuda:0');o=call(model,b,False);a=criteria['baseline'](o,b);c=criteria['quantity_mse'](o,b);d=criteria['shape_mass'](o,b);valid=b['mask'];parts.append(dict(base_objective=float(a['loss']),price_huber=float(a['price']),quantity_huber=float(a['quantity']),quantity_log_huber=float(a['quantity_log']),top16_pair=float(a['pair']),mse_objective=float(c['loss']),distribution_kl=float(d['quantity_shape_kl']),total_mass_huber=float(d['quantity_mass']),mean_predicted_quantity=float(o['volume'][valid].mean()),mean_true_quantity=float(b['volume'][valid].mean())))
  results[name]={k:sum(v[k] for v in parts)/len(parts) for k in parts[0]};del model;torch.cuda.empty_cache();atomic_json(root/'factorial_objectives.json',dict(scope='CommonFP32objectives on identical4full256frame trainingwindows; originalAE2048 versusall512additionalupdateendpoints',results=results));print(name,results[name],flush=True)

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);run(p.parse_args().root)
