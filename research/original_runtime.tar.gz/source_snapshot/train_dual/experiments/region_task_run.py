"""Bounded2x2 end-to-end fit: ordered regional bottleneck x explicit price loss."""
import argparse
from datetime import datetime
import json
import math
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

import numpy as np
import torch
from torch.utils.data import DataLoader,RandomSampler

from model.autoencoder.region_grid_vae import RegionGridOrderBookVAE
from model.losses.task_book import TaskBookLoss
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.local_quant_reconstruction import CacheWindows
from train_dual.experiments.long_worker import atomic_json,evaluate
from train_dual.experiments.phase_detail_report import read,preview
from train_dual.experiments.probability_eval import evaluate_probability
from train_dual.experiments.time_logit_run import calibrate_heads,write_profiles
from train_dual.experiments.unified_8192_run import call,group_gradients
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import atomic_save,freeze_sources,load_for_inference,seed_everything,source_hashes,random_state
from train_dual.util.moving_peak import MovingPeakWindows
from train_dual.util.phase_training import tensor_digest


LABELS={'frame_joint':'逐帧·价量联合','frame_quantity':'逐帧·仅挂量监督',
        'region_joint':'区域·价量联合','region_quantity':'区域·仅挂量监督'}


def refresh(root):
    from train_dual.experiments.region_task_report import render
    try:
        render(root)
        atomic_json(root/'report_status.json',dict(state='complete'))
        return True
    except Exception as error:
        import traceback
        atomic_json(root/'report_status.json',dict(state='failed_retry_pending',error=repr(error)))
        with (root/'logs/report_errors.log').open('a') as f:f.write(traceback.format_exc()+'\n')
        return False


def prepare(parent):
    torch.set_num_threads(4)
    parent=parent.resolve();project=Path(__file__).resolve().parents[2]
    root=project/'recons'/('region_task_'+datetime.now().strftime('%Y%m%d_%H%M%S'));root.mkdir()
    for name in ['data','logs','reference',*LABELS]:(root/name).mkdir()
    for phase in ['moving','real','development']:
        (root/phase).mkdir()
        for lane in LABELS:(root/phase/lane).mkdir()
    for name in ['val_indices.npy','plotly.min.js']:
        os.link(parent/name,root/name)
    np.save(root/'train_indices.npy',np.load(parent/'latent_fit_indices.npy'))
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    os.link(parent/'data/moving_peak_windows.pt',root/'data/moving_peak_windows.pt')
    old=read(parent/'plan.json')
    plan={k:old[k] for k in ['train','development','independent_test_untouched','normalization','model_config','objective','window_size','stride','input_shape','latent_shape','output_shape','batch_size','accumulation','lr','weight_decay','clip_grad']}
    lanes={lane:dict(organization=lane.split('_')[0],joint=lane.endswith('joint')) for lane in LABELS}
    plan.update(experiment='Ordered regional8192 bottleneck x quantity-only/joint supervision2x2',
        predecessor=parent.name,labels=LABELS,lanes=lanes,fit_windows=4,evaluation_windows=16,
        steps=2048,checkpoints=[128,512,1024,2048],phases=['moving','real'],
        gpu_workers=[[gpu,lane] for gpu,lane in zip([2,3,4,5],LABELS)],seed=42,beta=0.,sample=False,
        max_seconds=21600,queue_max_seconds=7200,
        region_grid_config=dict(frame_ffn=1536,temporal_ffn=2048,regional_ffn=2048,seed_hidden=1024),
        source_initialization='Fresh seed42, no historical weights. Same-organization task pairs share initial checkpoint. Common shape-compatible stem/cross/region and decoder modules copied exactly; identical calibrated constant initial outputs across architectures.',
        organization_factor='frame:256frame32D posterior serialized64x128, old frame-spatial seed. region:64time patches x2sides x8regions x8channels, time attention perregion followed byregional attention; each code emits its own4frames and local subregions. Identical unique8192 Gaussian, no Encoder bypass. FFN and seed networks differ; whole architecture organization is the factor, not reshape alone.',
        task_factor='Keep all quantity Huber/log/Top16/fineKL/mass terms unchanged. quantity-only removes ONLY explicit price andTop16price supervision. Both retain predicted-price geometry and its gradients into price decoder; no target-price condition, no freezing.',
        controls='Complete256minutes,2048levels per side, one posterior64x128,seed42,batch1accum4,AdamW1e-4weightdecay0,clip1,Z=mu,beta0,no logit replacement,W1/multiscale off. Four fixed train windows, sameorder,2048updates in each phase. Moving/real start from identical initial weights and freshAdam andseed; no synthetic warm start.',
        primary='Fixed2048endpoint same-frame/side/rank >=100BTC recall ANDprecision on4fit windows, quantityRMSE and1minlogquantity dynamics. Every declared checkpoint retained. Development16 atreal0/2048 only. quantity-only isdiagnostic, not a complete jointreconstruction winner.',
        screening_criterion='Exploratory go-to-larger-fit: real4fit recall100>=0.50,precision100>=0.50, quantityRMSE <=0.90 same-task framecontrol and quantity1mindynamics correlation>=0.50. Forjoint also priceRMSE<=1.10joint framecontrol. These thresholds do not establish generalization. No automatic1024window expansion.',
        queue_policy='Wait for predecessor complete and all GPUs2–5 memoryfree>=47000MiB, max2hours; never kill or colocate with predecessor/foreign jobs. Then replay old reference onGPU2 and run4owned workers, bounded6hours perworker andcampaign.',
        historical_reference='checkpoints/dual256_20261026_090533/reference/final.pt; different1064960-scalar representation, pretraining and historical losses/budget; quality yardstick, not matched causal control.',
        selection='Single seed42 peruser, noseed sweep. Train2022–2024; reused2025Q1development only.2025Q2/2026 untouched. Synthetic fit and real training fit are not OOS. No future return labels.')
    atomic_json(root/'plan.json',plan)
    original=dataset(root,'train');indices=np.load(root/'train_indices.npy');windows=[];times=[]
    for index in indices:
        raw=original[int(index)];windows.append(raw)
        start=int(original.base.starts[int(index)]);times.append(original.base.times[start:start+256])
        assert list(raw['data'].shape)==[256,2,2048,2]
        assert (np.diff(times[-1]//60_000_000)==1).all()
    atomic_save(dict(windows=windows,source_indices=indices,absolute_times=np.stack(times)),root/'data/real_fit_windows.pt')
    config=dict(normalization=dict(tick_size=plan['normalization']['tick_size'],price_scale=plan['normalization']['price_scale']),
                arguments=dict(window_size=256,stride=256,levels=2048,batch_size=1,accumulation_steps=4,precision='bf16'),loss=plan['objective'])
    contracts={}
    for organization in ['frame','region']:
        seed_everything(42)
        arch=dict(organization=organization,**plan['region_grid_config'])
        model=RegionGridOrderBookVAE(**arch,**plan['model_config']);calibrate_heads(model,plan['normalization'])
        contracts[organization]=dict(parameters=sum(p.numel() for p in model.parameters()),model_sha256=tensor_digest(model),shared_modules={name:tensor_digest(module) for name,module in [('stem',model.encoder.input_proj),('cross',model.encoder.cross),('region',model.encoder.region),('price_up',model.price_decoder.spatial.up),('volume_up',model.volume_decoder.spatial.up),('price_temporal',model.price_decoder.temporal),('volume_temporal',model.volume_decoder.temporal)]})
        atomic_save(dict(format_version=1,model=model.state_dict(),unified_vae_config=plan['model_config'],region_grid_config=arch,config=config,step=0),root/f'initial_{organization}.pt')
    assert contracts['frame']['shared_modules']==contracts['region']['shared_modules']
    plan['initial_contracts']=contracts
    plan['parameter_relative_difference']=contracts['region']['parameters']/contracts['frame']['parameters']-1
    assert abs(plan['parameter_relative_difference'])<.02
    atomic_json(root/'plan.json',plan)
    for phase in ['moving','real','development']:
        description={'moving':'合成移动峰训练拟合：挂量由规则构造，价格来自训练模板。目标参与拟合，不是实际市场、未见轨迹或样本外成绩。',
            'real':'固定4个真实2022–2024训练窗口的拟合结果，目标参与训练，不是样本外成绩。',
            'development':'固定16个2025Q1开发窗口，未参与本轮梯度更新，但已反复用于研究；不是最终独立测试。'}[phase]
        atomic_json(root/phase/'plan.json',dict(plan,preview_descriptions={lane:description for lane in LABELS}))
        os.link(root/'plotly.min.js',root/phase/'plotly.min.js')
    atomic_json(root/'data_contract.json',dict(raw_input=plan['input_shape'],posterior=plan['latent_shape'],price_output=plan['output_shape'],quantity_output=plan['output_shape'],real_training_indices=indices.tolist(),synthetic_training_template_indices=indices.tolist(),development_indices=np.load(root/'val_indices.npy').tolist(),region_internal_shape=[1,64,2,8,8],posterior_count=1,encoder_skip=False,normalization='Reused training-only statistics, not refit.'))
    shutil.copy2(project/'docs/models/REGION_TASK.md',root/'design.md')
    atomic_json(root/'status.json',dict(state='prepared'))
    freeze_sources(root/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'
        f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\n'
        f'cd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.region_task_run "{remote}"\n')
    refresh(root);Path('/tmp/region_task_path').write_text(str(root));print(root,flush=True)


def criterion_for(plan,lane):
    return TaskBookLoss(plan['normalization']['quantity_scale'],joint=plan['lanes'][lane]['joint'],mode='shape_mass',add_wasserstein=False,add_multiscale=False,**plan['objective'])


def safe_preview(root,lane,step):
    try:
        preview(root,lane,step)
        atomic_json(root/lane/'preview_status.json',dict(state='complete',step=step))
    except Exception as error:
        import traceback
        atomic_json(root/lane/'preview_status.json',dict(state='failed',step=step,error=repr(error)))
        with (root/lane/'preview_errors.log').open('a') as f:f.write(traceback.format_exc()+'\n')


def assess(root,lane,phase,step,model,norm,criterion,train,dev,original):
    folder=root/phase/lane
    atomic_json(root/lane/'evaluation_status.json',dict(state='evaluating',phase=phase,step=step))
    value=evaluate(model,norm,train,len(train),'cuda:0')
    atomic_json(folder/f'step{step}_evaluation.json',dict(result=value,scope='Synthetic fitted templates' if phase=='moving' else 'Real training fit, not OOS'))
    atomic_json(folder/f'step{step}_probability.json',dict(training=evaluate_probability(model,norm,train,len(train),'cuda:0',criterion)))
    write_profiles(folder,step,model,norm,train)
    safe_preview(root/phase,lane,step)
    if phase=='real' and step in [0,read(root/'plan.json')['steps']]:
        folder=root/'development'/lane
        atomic_json(folder/f'step{step}_evaluation.json',dict(result=evaluate(model,norm,dev,len(dev),'cuda:0')))
        write_profiles(folder,step,model,norm,dev,original);safe_preview(root/'development',lane,step)
    atomic_json(root/lane/'evaluation_status.json',dict(state='complete',phase=phase,step=step))


def shape_audit(root,lane,model,norm,train):
    raw={k:v.unsqueeze(0) for k,v in train[0].items()};b=norm.prepare(raw,'cuda:0')
    model.eval();seen=[]
    hooks=[d.register_forward_pre_hook(lambda m,a:seen.append(a[0])) for d in [model.price_decoder,model.volume_decoder]]
    with torch.inference_mode():
        out=call(model,b,False);replay=model.decode(out['z'],b['mask'],b['tick_norm'],b['times'])
        for key in ['price_norm','volume','quantity_logit']:torch.testing.assert_close(out[key],replay[key],rtol=0,atol=0)
    for hook in hooks:hook.remove()
    assert seen[0] is seen[1] and seen[0] is out['z']
    assert list(raw['data'].shape)==[1,256,2,2048,2]
    assert list(out['z'].shape)==list(out['mu'].shape)==list(out['logvar'].shape)==[1,64,128]
    assert list(out['price_norm'].shape)==list(out['volume'].shape)==[1,256,2,2048]
    atomic_json(root/lane/'actual_shape_contract.json',dict(passed=True,raw_input=list(raw['data'].shape),posterior=list(out['mu'].shape),logvar=list(out['logvar'].shape),latent=list(out['z'].shape),output=list(out['volume'].shape),shared_z_object=True,decode_only_replay_exact=True,posterior_count=1,encoder_skip=False))


def train_phase(root,lane,phase,started):
    plan=read(root/'plan.json');spec=plan['lanes'][lane]
    seed_everything(42);strict_precision()
    initial=root/f'initial_{spec["organization"]}.pt'
    model,norm=load_for_inference(initial,'cuda:0');model.train().requires_grad_(True)
    digest=tensor_digest(model)
    assert digest==plan['initial_contracts'][spec['organization']]['model_sha256']
    opt=torch.optim.AdamW(model.parameters(),lr=plan['lr'],weight_decay=plan['weight_decay'])
    criterion=criterion_for(plan,lane);folder=root/phase/lane
    train=MovingPeakWindows(root/'data'/('moving_peak_windows.pt' if phase=='moving' else 'real_fit_windows.pt'))
    assert len(train)==4
    original=dataset(root,'val') if phase=='real' else None
    dev=CacheWindows(original,np.load(root/'val_indices.npy')) if original is not None else None
    generator=torch.Generator().manual_seed(42)
    worker_generator=torch.Generator().manual_seed(42)
    loader=DataLoader(train,batch_size=1,sampler=RandomSampler(train,generator=generator),num_workers=0,pin_memory=True,generator=worker_generator)
    iterator=iter(loader);exposures=np.zeros(len(train),dtype=np.int64)
    atomic_json(folder/'initial_reset_audit.json',dict(passed=True,model_sha256=digest,optimizer_state_entries=len(opt.state),seed=42,previous_phase_weights_used=False))
    if phase=='moving':shape_audit(root,lane,model,norm,train)
    config=torch.load(initial,map_location='cpu',weights_only=False)['config'];hashes=source_hashes()
    def save(step):
        atomic_save(dict(format_version=1,model=model.state_dict(),unified_vae_config=plan['model_config'],
            region_grid_config=dict(organization=spec['organization'],**plan['region_grid_config']),
            config=dict(config,loss_family='task',loss=dict(plan['objective'],joint=spec['joint'])),step=step,lane=lane,phase=phase,
            optimizer=opt.state_dict(),rng_state=random_state(generator),sampler_generator_state=generator.get_state(),
            source_hashes=hashes,epoch_boundary=True,training_data=dict(exposure_counts=exposures.copy(),indices=train.indices,windows=4,epochs_equivalent=float(exposures.mean()))),folder/f'step{step}.pt')
    atomic_json(root/lane/'status.json',dict(state='training',phase=phase))
    save(0);assess(root,lane,phase,0,model,norm,criterion,train,dev,original)
    for step in range(1,plan['steps']+1):
        if time.monotonic()-started>plan['max_seconds']:raise TimeoutError('Six-hour worker ceiling')
        model.train();opt.zero_grad(set_to_none=True);record={};order=[]
        for micro in range(plan['accumulation']):
            try:raw=next(iterator)
            except StopIteration:iterator=iter(loader);raw=next(iterator)
            pos=int(raw['cache_position'][0]);exposures[pos]+=1;order.append(int(train.indices[pos]))
            b=norm.prepare(raw,'cuda:0')
            assert list(raw['data'].shape)==plan['input_shape']
            with torch.autocast('cuda',dtype=torch.bfloat16):out=call(model,b,False)
            assert list(out['z'].shape)==plan['latent_shape'] and list(out['volume'].shape)==plan['output_shape']
            values=criterion(out,b,beta=0.)
            if not bool(torch.isfinite(values['loss'])):raise FloatingPointError('Nonfinite training loss')
            (values['loss']/plan['accumulation']).backward()
            for key,v in values.items():record[key]=record.get(key,0.)+float(v.detach())/plan['accumulation']
        if step in [1,8]:
            gradients=group_gradients(model)
            if any(not math.isfinite(v) for v in gradients.values()):raise FloatingPointError('Nonfinite module gradient')
            if step==8 and any(v<=0 for name,v in gradients.items() if name!='posterior_logvar'):
                raise RuntimeError(f'Missing end-to-end gradient:{gradients}')
            atomic_json(folder/f'step{step}_gradient_audit.json',dict(passed=True,gradients=gradients,
                logvar_zero_expected_beta0=True,quantity_geometry_gradients_into_price_allowed=True))
        if step==1:atomic_json(folder/'first_step_data.json',dict(training_indices=order,losses=record))
        grad=torch.nn.utils.clip_grad_norm_(model.parameters(),plan['clip_grad'],error_if_nonfinite=True)
        opt.step()
        if step==1 or step%8==0:
            row=dict(phase=phase,step=step,total=plan['steps'],elapsed_seconds=time.monotonic()-started,
                gradient_norm=float(grad),reserved_gib=torch.cuda.memory_reserved()/2**30,epochs_equivalent=float(exposures.mean()),training_indices=order,**record)
            atomic_json(root/lane/'progress.json',row)
            with (folder/'progress.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
            print(json.dumps(row),flush=True)
        if step in plan['checkpoints']:
            save(step);assess(root,lane,phase,step,model,norm,criterion,train,dev,original)
    atomic_json(folder/'status.json',dict(state='complete',step=plan['steps'],synthetic_weights_discarded=phase=='moving'))
    del iterator,loader,opt,model,criterion,train,dev,original
    torch.cuda.empty_cache()


def worker(root,lane):
    torch.set_num_threads(4);started=time.monotonic()
    train_phase(root,lane,'moving',started)
    train_phase(root,lane,'real',started)
    atomic_json(root/lane/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started))


def replay_reference(root):
    torch.set_num_threads(4);strict_precision()
    project=root.parents[1]
    source=project/'checkpoints/dual256_20261026_090533/reference/final.pt'
    model,norm=load_for_inference(source,'cuda:0')
    original=dataset(root,'val');indices=np.load(root/'val_indices.npy');data=CacheWindows(original,indices)
    old_indices=np.load(source.parent.parent/'val_indices.npy')
    assert np.array_equal(indices,old_indices)
    result=evaluate(model,norm,data,len(data),'cuda:0')
    expected=read(source.parent/'step512_evaluation.json')['result']
    delta={key:result['metrics'][key]['rmse']-expected['metrics'][key]['rmse'] for key in ['price_usdt','quantity_btc']}
    passed=all(np.isclose(result['metrics'][key]['rmse'],expected['metrics'][key]['rmse'],rtol=1e-5,atol=1e-5) for key in delta)
    passed=passed and result['thresholds']['100']==expected['thresholds']['100']
    atomic_json(root/'reference/evaluation.json',dict(result=result))
    atomic_json(root/'reference/replay_audit.json',dict(passed=bool(passed),same_development_indices=True,rmse_delta=delta,
        recall100=result['thresholds']['100']['recall'],price_rmse=result['metrics']['price_usdt']['rmse'],quantity_rmse=result['metrics']['quantity_btc']['rmse'],
        note='Old larger-latent quality reference, not matched capacity/optimization control. Newly replayed using FP32 evaluator; no training.'))
    if not passed:raise RuntimeError('Historical reference replay mismatch')


def endpoint_summary(root):
    plan=read(root/'plan.json');summary={}
    for phase in plan['phases']:
        rows={}
        for lane in LABELS:
            d=read(root/phase/lane/f'step{plan["steps"]}_evaluation.json')['result'];m=d['metrics']
            rows[lane]=dict(quantity_rmse=m['quantity_btc']['rmse'],price_rmse=m['price_usdt']['rmse'],
                quantity_change_correlation=m['temporal_log_quantity_1_minutes']['correlation'],**d['thresholds']['100'])
        for lane in ['region_joint','region_quantity']:
            r=rows[lane];base=rows[lane.replace('region','frame')]
            r['quantity_rmse_ratio_to_matched_frame']=r['quantity_rmse']/base['quantity_rmse']
            r['price_rmse_ratio_to_matched_frame']=r['price_rmse']/base['price_rmse']
            r['passes_small_fit_screen']=bool(r['recall'] is not None and r['recall']>=.50 and r['precision'] is not None and r['precision']>=.50
                and r['quantity_rmse_ratio_to_matched_frame']<=.90 and r['quantity_change_correlation'] is not None and r['quantity_change_correlation']>=.50
                and (lane.endswith('quantity') or r['price_rmse_ratio_to_matched_frame']<=1.10))
        summary[phase]=rows
    summary['note']='Training/synthetic fit only; no automaticlarger training. Not a generalization claim, not a latent-dimension lower bound.'
    atomic_json(root/'endpoint_summary.json',summary)


def gpu_free():
    rows=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.free','--format=csv,noheader,nounits'],text=True).splitlines()
    return {int(row.split(',')[0]):int(row.split(',')[1]) for row in rows}


def startup_audit(root):
    """Compare actual first batches/functions, not just config names."""
    rows={}
    for lane in LABELS:
        shape=read(root/lane/'actual_shape_contract.json')
        first=read(root/'moving'/lane/'first_step_data.json')
        gradient=read(root/'moving'/lane/'step8_gradient_audit.json')
        if not all([shape,first,gradient]):return False
        rows[lane]=dict(shape=shape,first=first,gradient=gradient)
    baseline=rows['frame_joint']['first']
    for lane,row in rows.items():
        assert row['shape']['passed'] and row['gradient']['passed']
        assert row['first']['training_indices']==baseline['training_indices']
        for key in ['full_joint_loss','price','quantity','quantity_log','quantity_pair','quantity_shape_kl','quantity_mass']:
            if row['first']['losses'][key]!=baseline['losses'][key]:
                raise RuntimeError(f'Initial output/objective mismatch:{lane}:{key}')
    atomic_json(root/'startup_control_audit.json',dict(passed=True,actual_full_window=True,
        shared_unique_latent=True,initial_full_joint_function_losses_exact=True,
        first_training_indices=baseline['training_indices'],rows=rows))
    return True


def campaign(root):
    plan=read(root/'plan.json');queued=time.monotonic();children=[]
    def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        while True:
            state=read(root.parent/plan['predecessor']/'status.json',{})
            if state.get('state')=='failed':raise RuntimeError('Predecessor failed; inspect rather than silently replacing it')
            free=gpu_free()
            if state.get('state')=='complete' and all(free.get(g,0)>=47000 for g in [2,3,4,5]):break
            if time.monotonic()-queued>plan['queue_max_seconds']:raise TimeoutError('Two-hour queue ceiling; no jobs displaced')
            atomic_json(root/'status.json',dict(state='queued_waiting_predecessor',predecessor=plan['predecessor'],
                predecessor_state=state.get('state'),gpu_free_mib=free,queued_seconds=time.monotonic()-queued))
            refresh(root);time.sleep(20)
        atomic_json(root/'predecessor_endpoint.json',dict(status=state,results={lane:read(root.parent/plan['predecessor']/lane/'step4096_evaluation.json') for lane in ['patch_huber','patch_logit','frame_huber','frame_logit']}))
        started=time.monotonic()
        atomic_json(root/'status.json',dict(state='replaying_historical_reference'))
        env=dict(os.environ,CUDA_VISIBLE_DEVICES='2',CUDA_DEVICE_ORDER='PCI_BUS_ID',PYTHONPATH=str(root/'source_snapshot'))
        with (root/'logs/reference.log').open('ab',buffering=0) as log:
            replay=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.region_task_run',str(root),'--replay'],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        children.append(('reference',2,replay))
        while replay.poll() is None:
            if time.monotonic()-started>1800:raise TimeoutError('Historical replay30minute ceiling')
            refresh(root);time.sleep(10)
        if replay.returncode:raise RuntimeError('Historical reference replay failed; see logs/reference.log')
        children=[]
        for gpu,lane in plan['gpu_workers']:
            env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),CUDA_DEVICE_ORDER='PCI_BUS_ID',PYTHONPATH=str(root/'source_snapshot'))
            with (root/'logs'/f'{lane}.log').open('ab',buffering=0) as log:
                child=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.region_task_run',str(root),'--lane',lane],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            children.append((lane,gpu,child))
        atomic_json(root/'status.json',dict(state='running',children=[dict(role=l,gpu=g,pid=p.pid) for l,g,p in children]))
        audited=False
        while any(p.poll() is None for _,_,p in children):
            if time.monotonic()-started>plan['max_seconds']:raise TimeoutError('Six-hour campaign ceiling')
            failed={l:p.returncode for l,_,p in children if p.poll() not in [None,0]}
            if failed:raise RuntimeError(f'Owned worker failed:{failed}')
            if not audited:audited=startup_audit(root)
            refresh(root);time.sleep(10)
        failed={l:p.returncode for l,_,p in children if p.returncode!=0}
        if failed:raise RuntimeError(f'Owned worker failed:{failed}')
        endpoint_summary(root)
        atomic_json(root/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started,queued_seconds=started-queued))
    except BaseException as error:
        atomic_json(root/'status.json',dict(state='failed',error=repr(error)));raise
    finally:
        for _,_,p in children:
            if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)
        refresh(root)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path)
    p.add_argument('--prepare',action='store_true');p.add_argument('--lane',choices=list(LABELS));p.add_argument('--replay',action='store_true')
    args=p.parse_args();root=args.root.resolve()
    try:
        if args.prepare:prepare(root)
        elif args.replay:replay_reference(root)
        elif args.lane:worker(root,args.lane)
        else:campaign(root)
    except BaseException as error:
        if args.lane:atomic_json(root/args.lane/'status.json',dict(state='failed',error=repr(error)))
        raise
