"""Training-only cached-decoder capability pilot, never a goal candidate."""
import argparse
import hashlib
import html
import json
import os
from pathlib import Path
import time

import numpy as np
import torch

from model.layers.local_phase import LocalPhaseReadout
from model.layers.regional_phase import RegionalPhaseReadout
from model.losses.recall_guard import RecallGuardBookLoss
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.local_phase_run import SWITCHES,LABELS
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read,STYLE
from train_dual.experiments.unified_8192_run import call
from train_dual.util.checkpoint import freeze_sources,load_for_inference
from train_dual.util.phase_training import tensor_digest


def file_hash(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(4*1024*1024),b''):digest.update(block)
    return digest.hexdigest()


def criterion(plan,calibration):
    # Frozen hint_adapter/seed and teacher make hint loss constant with respect
    # to all readout parameters. Omitting this term preserves their gradients.
    return RecallGuardBookLoss(plan['normalization']['quantity_scale'],mode='shape_mass',use_hint=False,
        use_tail=True,protect_mid=True,tail_weight=calibration['tail_weight'],mid_weight=calibration['mid_weight'],
        mid_delta_weight=1.,**plan['FP_rule'],**plan['objective'])


def prepare(goal,seen8=False,regional=False):
    seen8=seen8 or regional
    parent=goal/'round_002_fp_rule';source=parent/'recall/step1024.pt'
    payload=torch.load(source,map_location='cpu',weights_only=False)
    assert payload['step']==1024 and payload['epoch_boundary']
    root=goal/('local_phase_cached_regional8_pilot' if regional else 'local_phase_cached_seen8_pilot' if seen8 else 'local_phase_cached_pilot');root.mkdir();(root/'logs').mkdir()
    os.link(source,root/'source.pt')
    old=read(parent/'plan.json');spec=old['lanes']['recall']
    rule={k:spec[k] for k in ['fp_normalization','fp_error','fp_weight']}
    indices=np.load(parent/'seen_indices.npy').tolist() if seen8 else [0,6152]
    steps=512 if seen8 else 128
    plan=dict(parent=str(parent),source=str(source),source_sha256=file_hash(source),indices=indices,batch_windows=2,
        head_type='regional' if regional else 'shared',head_parameters=36992 if regional else 289,
        source_selection='Fixed best-recall lane at the already-published common1024 checkpoint; selected before this training-only pilot. Not the future architecture cohort source.',
        normalization=old['normalization'],objective=old['objective'],FP_rule=rule,seed=42,threads=8,
        steps=steps,checkpoints=[0,16,64,128,512] if seen8 else [0,16,64,128],learning_rate=.001,weight_decay=0.,clip_grad=1.,max_seconds=1800,
        scope=f'Mechanism pilot: cached source quantity/seed on {len(indices)} fixed training windows; only{36992 if regional else 289}zeroheadparameters train. SourceEncoder/Decoders frozen, no augmentation, no new loss, no development/independent inference. Four2x2arms, same{steps}iterations and headoptimizer;2cachedwindowsperiteration in fixed cyclic order. Head-only lr1e-3 differs from production lr1e-4 and end-to-end fitting; cannot substitute for that experiment or the recall80goal. The128step endpoint can be compared with the earlier2window pilot at the same number of window exposures;512is a separate longer budget shared by all4arms.',
        omitted_hint='Constant in these head-only parameters, gradient-equivalence tested. Price/mid terms retained and constant; no teacher needed.',
        input_shape=[1,256,2,2048,2],latent_shape=[1,64,128],output_shape=[1,256,2,2048],
        full_architecture_queue_unchanged=True,labels=LABELS)
    atomic_json(root/'plan.json',plan);atomic_json(root/'calibration.json',read(parent/'calibration.json'))
    if regional:
        previous=goal/'local_phase_cached_seen8_pilot';old=read(previous/'plan.json')
        assert read(previous/'status.json')['state']=='complete'
        for key in ['indices','source_sha256','batch_windows','steps','checkpoints','learning_rate','weight_decay','clip_grad','normalization','objective','FP_rule']:
            assert old[key]==plan[key],key
        plan.update(cache_from=str(previous),cache_sha256=file_hash(previous/'cache.pt'),
                    sharing_control='Only shared-vs-region-specific readout changes relative to completed8windowpilot. Region count128; time and side remain shared. 289vs36992parameters is the declared architecture-capacity factor. Production queue is unchanged.')
        os.link(previous/'cache.pt',root/'cache.pt')
        atomic_json(root/'plan.json',plan);atomic_json(root/'inherited_cache_audit.json',read(previous/'cache_audit.json'))
    atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot')
    print(root,flush=True)


def metrics(predictions,cache):
    tp=fp=fn=0;squared=0.;count=0
    for pred,row in zip(predictions,cache):
        target=row['batch']['volume'];mask=row['batch']['mask'];actual=mask&(target>=100);predicted=mask&(pred>=100)
        tp+=int((actual&predicted).sum());fp+=int((~actual&predicted).sum());fn+=int((actual&~predicted).sum())
        squared+=float(((pred.double()-target.double()).square()*mask).sum());count+=int(mask.sum())
    return dict(tp=tp,fp=fp,fn=fn,recall100=tp/(tp+fn) if tp+fn else None,
                precision100=tp/(tp+fp) if tp+fp else None,quantity_rmse=(squared/count)**.5)


def cached_positions(step,windows,batch_windows=2):
    if step<1 or windows<batch_windows or batch_windows<1:raise ValueError('Invalid cached minibatch')
    start=(step-1)*batch_windows
    return [(start+i)%windows for i in range(batch_windows)]


def render(root,rows,complete=False):
    plan=read(root/'plan.json');head_label=f'{plan.get("head_parameters",289)}个'+('分区域' if plan.get('head_type')=='regional' else '共享')+'形状/总量参数'
    text='<!doctype html><meta charset="utf-8"><title>局部解码头训练窗拟合检查</title><style>'+STYLE+'</style><main><h1>仅训练窗：固定数量特征的局部解码头拟合</h1><p>状态：'+('完成' if complete else '运行中')+f'。{len(plan["indices"])}个预先固定的训练窗口{plan["indices"]}，完整256分钟×双侧2048档。主模型全部冻结，只训练{head_label}，四组相同{plan["steps"]}次迭代，每步固定循环抽2窗，lr1e-3。'+ '不执行开发或独立测试，不是目标候选；正式四卡全模型实验来源、学习率和优化路径不同，不能直接外推。</p><table><tr><th>组</th><th>步数</th><th>训练窗严格召回</th><th>精确率</th><th>TP</th><th>FP</th><th>FN</th><th>挂量RMSE</th><th>损失</th></tr>'
    for row in rows:
        vals=[LABELS[row['lane']],row['step'],row['recall100'],row['precision100'],row['tp'],row['fp'],row['fn'],row['quantity_rmse'],row['loss']]
        text+='<tr>'+''.join('<td>'+html.escape(f'{v:.5f}' if isinstance(v,float) else str(v))+'</td>' for v in vals)+'</tr>'
    text+='</table><p>价格固定为来源预测，不因仅挂量头更新而变化。省略的教师hint项对新头为常数，已验证梯度等价。没有改变误报规则或添加监督项；训练拟合改善也不能证明泛化改善。</p><p><a href="plan.json">协议</a> · <a href="results.json">原始结果</a> · <a href="../local_phase_after/">独立的全模型条件接续实验</a></p></main>'
    temporary=root/'index.tmp';temporary.write_text(text);temporary.replace(root/'index.html')


def run(root):
    plan=read(root/'plan.json');torch.set_num_threads(plan['threads']);torch.manual_seed(plan['seed']);started=time.monotonic()
    atomic_json(root/'status.json',dict(state='verifying_reused_training_cache' if plan.get('cache_from') else 'caching_training_windows',pid=os.getpid()))
    source_hash=file_hash(root/'source.pt');assert source_hash==plan['source_sha256']
    if plan.get('cache_from'):
        assert file_hash(root/'cache.pt')==plan['cache_sha256']
        inherited=read(root/'inherited_cache_audit.json')
        assert inherited['passed'] and inherited['source_sha256']==source_hash
        assert [row['index'] for row in inherited['contracts']]==plan['indices']
        cache=torch.load(root/'cache.pt',map_location='cpu',weights_only=False)
        atomic_json(root/'cache_audit.json',dict(inherited,exact_reused_cache_sha256=plan['cache_sha256'],cache_recomputed=False))
    else:
        model,norm=load_for_inference(root/'source.pt','cpu');model.eval().requires_grad_(False);digest=tensor_digest(model)
        data=dataset(Path(plan['parent']),'train');cache=[];contracts=[]
        for index in plan['indices']:
            raw={k:v.unsqueeze(0) for k,v in data[index].items()};batch=norm.prepare(raw,'cpu')
            start=int(data.base.starts[index]);times=data.base.times[start:start+256]
            assert list(raw['data'].shape)==plan['input_shape'] and len(times)==256 and np.all(np.diff(times//60_000_000)==1)
            with torch.no_grad():out=call(model,batch,False)
            assert all(list(out[k].shape)==plan['latent_shape'] for k in ['mu','logvar','z'])
            assert all(list(out[k].shape)==plan['output_shape'] for k in ['price_norm','volume'])
            cache.append(dict(batch={k:batch[k].detach() for k in ['price','volume','mask']},
                              out={k:out[k].detach() for k in ['volume','quantity_seed','price_norm','mid_norm','mu','logvar']}))
            contracts.append(dict(index=index,raw=plan['input_shape'],z=list(out['z'].shape),quantity=list(out['volume'].shape),consecutive_minute_buckets=True))
        assert tensor_digest(model)==digest
        atomic_json(root/'cache_audit.json',dict(passed=True,source_model_hash_unchanged=digest,contracts=contracts,source_sha256=source_hash,training_only=True))
        torch.save(cache,root/'cache.pt');del model,data,out,raw,batch
    objective=criterion(plan,read(root/'calibration.json'));rows=[];initial_losses=[]
    for lane,(shape,mass) in SWITCHES.items():
        head=RegionalPhaseReadout() if plan.get('head_type')=='regional' else LocalPhaseReadout()
        assert sum(p.numel() for p in head.parameters())==plan.get('head_parameters',289)
        opt=torch.optim.AdamW(head.parameters(),lr=plan['learning_rate'],weight_decay=plan['weight_decay'])
        enabled=shape or mass
        for step in range(plan['steps']+1):
            if time.monotonic()-started>plan['max_seconds']:raise TimeoutError('Cached-pilot30minute ceiling')
            if step>0:
                opt.zero_grad(set_to_none=True)
                for position in cached_positions(step,len(cache),plan.get('batch_windows',len(cache))):
                    row=cache[position]
                    out=dict(row['out']);out['volume']=head(out['volume'],out['quantity_seed'],row['batch']['mask'],use_shape=shape,use_mass=mass)
                    values=objective(out,row['batch'])
                    assert bool(torch.isfinite(values['loss']))
                    if enabled:(values['loss']/plan.get('batch_windows',len(cache))).backward()
                if enabled:torch.nn.utils.clip_grad_norm_(head.parameters(),plan['clip_grad'],error_if_nonfinite=True)
                opt.step()
            if step in plan['checkpoints']:
                with torch.no_grad():
                    predictions=[];loss=0.
                    for row in cache:
                        out=dict(row['out']);out['volume']=head(out['volume'],out['quantity_seed'],row['batch']['mask'],use_shape=shape,use_mass=mass)
                        predictions.append(out['volume']);loss+=float(objective(out,row['batch'])['loss'])/len(cache)
                measured=dict(lane=lane,step=step,loss=loss,**metrics(predictions,cache),elapsed_seconds=time.monotonic()-started)
                rows.append(measured)
                if step==0:initial_losses.append(loss);assert loss==initial_losses[0]
                atomic_json(root/'results.json',dict(rows=rows,scope=plan['scope'],goal_candidate=False));render(root,rows)
                print(json.dumps(measured),flush=True)
            if step%8==0:atomic_json(root/'status.json',dict(state='running_head_only',pid=os.getpid(),lane=lane,step=step,elapsed_seconds=time.monotonic()-started))
        torch.save(dict(head=head.state_dict(),optimizer=opt.state_dict(),shape=shape,mass=mass,steps=plan['steps'],not_a_full_model=True),root/f'{lane}_heads.pt')
    assert file_hash(root/'source.pt')==source_hash
    atomic_json(root/'read_only_source_audit.json',dict(passed=True,source_checkpoint_sha256=source_hash,source_neural_model_updates=0,head_only_updates=plan['steps'],goal_candidate=False,reserved_data_read=False))
    atomic_json(root/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started,goal_candidate=False));render(root,rows,complete=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--seen8',action='store_true');p.add_argument('--regional',action='store_true');a=p.parse_args();root=a.root.resolve()
    try:
        if a.prepare:prepare(root,a.seen8,a.regional)
        else:run(root)
    except BaseException as error:
        if not a.prepare:atomic_json(root/'status.json',dict(state='failed',error=repr(error)))
        raise
