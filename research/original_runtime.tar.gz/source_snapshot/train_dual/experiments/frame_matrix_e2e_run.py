"""Train the complete16x1024 model and separate duration from frozen-source effects."""

import argparse
from datetime import datetime
import json
import os
from pathlib import Path

from train_dual.experiments.frame_matrix_run import worker
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.small_codebook_run import campaign
from train_dual.util.checkpoint import freeze_sources


def prepare(parent):
    parent=parent.resolve();root=parent.parent/('frame_matrix_e2e_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
    root.mkdir();(root/'data').mkdir();(root/'logs').mkdir()
    for name in ('initial.pt','source_profiles.npz','frame_basis.pt','small_latents.pt','fit_indices.npy','basis_fit.json','source_seen_evaluation.json'):
        os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    os.link(parent/'nonlinear_joint/final_evaluation.json',root/'expected_control512.json')
    plan=json.loads((parent/'plan.json').read_text())
    plan.update(parent=str(parent),experiment='Full-model16x1024 end-to-end training',
        lanes={'frozen_long':dict(kind='nonlinear',mode='joint',steps=2048),
               'e2e':dict(kind='nonlinear',mode='all',steps=2048),
               'e2e_fast':dict(kind='nonlinear',mode='all',steps=2048,encoder_lr=.0001,linear_lr=.0001,decoder_lr=.0001),
               'e2e_smallfit':dict(kind='nonlinear',mode='all',steps=2048,train_windows=32)},
        encoder_lr=.00001,checkpoints=[128,256,512,1024,2048],save_training_checkpoints=True,
        strict_replay_control='frozen_long',
        hypothesis='The frozen encoder/Cross did not adapt to the1024-row bottleneck; complete-model reconstruction training may preserve details without changing the latent shape.',
        initialization='All groups restart from the same best source and same train-only PCA basis, with zero nonlinear residual outputs. No optimizer-reset continuation from512-step weights.',
        method='Main end-to-end groups recompute encoder and Cross on every raw training batch and backpropagate through them, compression/decompression and both generators. Frozen-source duration control alone uses immutable cached source latents. No detached source or stale latent targets in end-to-end groups.',
        comparison='Same512training windows and64development windows; compare128/256/512/1024/2048 budgets. Main e2e differs from frozen_long only in unfreezing encoder/Cross. e2e_fast changes learning rates and is an optimization control.32-window lane is fitting diagnosis, not a matched data-budget competitor.',
        selection='Report all predeclared checkpoints and fixed2048-step final endpoints; no future-return selection or independent-Q2 evaluation.',
        training_mode_note='Deterministic posterior means, KL0, reconstruction-only objectives. All trainable encoder/Cross parameters are enabled; logvariance-only outputs unused by deterministic means may have zero gradient.',
        original_frozen_pilot=str(parent),no_quantization=True,no_semantic_constraints=True,no_future_returns=True)
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(parent.parents[1])
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'
        f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\n'
        f'cd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.frame_matrix_e2e_run "{remote}"\n')
    Path('/tmp/frame_matrix_e2e_run_path').write_text(str(root));print(root,flush=True)


def recover(parent):
    parent=parent.resolve();root=parent.parent/('frame_matrix_e2e_resume_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
    root.mkdir();(root/'data').mkdir();(root/'logs').mkdir();(root/'resume').mkdir()
    for name in ('initial.pt','source_profiles.npz','frame_basis.pt','small_latents.pt','fit_indices.npy','basis_fit.json','source_seen_evaluation.json'):
        os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    plan=json.loads((parent/'plan.json').read_text());resumes={}
    for lane in plan['lanes']:
        checkpoints=[]
        for file in (parent/lane).glob('step*.pt'):
            number=file.stem[4:]
            if number.isdigit():checkpoints.append((int(number),file))
        step,file=max(checkpoints);os.link(file,root/'resume'/(lane+'.pt'));folder=root/lane;folder.mkdir()
        for source in (parent/lane).glob('*.json'):
            if source.name in ('status.json','progress.json','first_step_gradient_norms.json','trainable_modules.json'):continue
            if source.name.startswith('step'):
                number=source.name[4:].split('_')[0]
                if number.isdigit() and int(number)>step:continue
            os.link(source,folder/source.name)
        for old_step,source in checkpoints:
            if old_step<=step:os.link(source,folder/source.name)
        history=[]
        for line in (parent/lane/'progress.jsonl').read_text().splitlines():
            value=json.loads(line)
            if value.get('step',0)<=step:history.append(line)
        (folder/'progress.jsonl').write_text('\n'.join(history)+'\n')
        old_progress=json.loads((parent/lane/'progress.json').read_text())
        resumes[lane]=dict(checkpoint_step=step,last_logged_step=old_progress.get('step'),source=str(file))
    plan.update(recovery_parent=str(parent),resume_checkpoints=resumes,strict_replay_control=None,
        recovery_reason='Historical independent-run512-step trajectory check failed, supervisor stopped other jobs. Restore full model/Adam/epoch-boundary sampler and RNG from saved checkpoints.',
        comparison='Use checkpoints within each recovered trajectory for duration comparisons. Preserve and disclose historical cross-run control drift; retain strict inference replay checks against the exact saved checkpoint.',
        resume_sampler='At epoch boundaries split worker-seed RNG from saved RandomSampler RNG, avoiding an extra new-loader base-seed draw that would alter the next epoch permutation.')
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(parent.parents[1])
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'
        f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\n'
        f'cd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.frame_matrix_e2e_run "{remote}"\n')
    atomic_json(parent/'recovery.json',dict(recovered_as=str(root),historical_results_preserved=True,resumes=resumes))
    Path('/tmp/frame_matrix_e2e_run_path').write_text(str(root));print(root,flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--recover',action='store_true');p.add_argument('--lane');a=p.parse_args()
    if a.prepare:prepare(a.root)
    elif a.recover:recover(a.root)
    elif a.lane:worker(a.root,a.lane)
    else:campaign(a.root,worker_module='train_dual.experiments.frame_matrix_e2e_run')
