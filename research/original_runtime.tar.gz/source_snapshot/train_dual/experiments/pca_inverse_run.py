"""Matched continuation: fixed PCA vector with linear or nonlinear inverse."""

import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import numpy as np
import torch
from torch.utils.data import DataLoader

from model.experimental.pca_residual_state import ResidualPCAWindowVAE
from model.losses.dual import DualLossConfig,DualVAELoss
from train_dual.experiments.long_worker import atomic_json,datasets,evaluate,rng_state
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.experiments.pca_run import CachedWindows,examples
from train_dual.util.checkpoint import load_for_inference,atomic_save,seed_everything,source_hashes


LANES=('linear1024','nonlinear1024','linear256','nonlinear256')


def worker(root,lane):
    torch.set_num_threads(4);seed_everything(42);strict_precision()
    plan=json.loads((root/'plan.json').read_text());spec=plan['lanes'][lane];dimension=spec['dimension'];nonlinear=spec['nonlinear']
    parent=torch.load(root/f'initial_{dimension}.pt',map_location='cpu',weights_only=False)
    if nonlinear:
        model=ResidualPCAWindowVAE(**parent['pca_state_config'],hidden_dim=plan['hidden_dim'],**parent['model_config'])
        model.load_pca_initial(parent['model'])
        scale=torch.load(root/f'train_states_{dimension}.pt',map_location='cpu',weights_only=False)['states'].std(0).clamp_min(1e-4)
        model.latent_residual.state_scale.copy_(scale)
        _,normalizer=load_for_inference(root/f'initial_{dimension}.pt','cpu')
        model.to('cuda:0')
    else:model,normalizer=load_for_inference(root/f'initial_{dimension}.pt','cuda:0')
    states=torch.load(root/f'train_states_{dimension}.pt',map_location='cpu',weights_only=False)['states']
    initial=torch.load(root/'initial.pt',map_location='cpu',weights_only=False)
    folder=root/lane;folder.mkdir(exist_ok=True);started=time.monotonic();hashes=source_hashes()
    val=datasets(root,initial,'val');criterion=DualVAELoss(config=DualLossConfig(**plan['loss']))
    groups=[dict(params=[p for n,p in model.named_parameters() if n.startswith(('price_decoder.','volume_decoder.','volume_refinement.'))],lr=plan['decoder_lr'])]
    if nonlinear:groups.append(dict(params=list(model.latent_residual.parameters()),lr=plan['residual_lr']))
    optimizer=torch.optim.AdamW(groups,weight_decay=.01)
    def save(path,step):
        value=dict(format_version=1,model=model.state_dict(),model_config=parent['model_config'],pca_state_config=model.pca_state_config,
            config=dict(parent['config'],loss=plan['loss']),step=step,source_hashes=hashes,optimizer=optimizer.state_dict(),rng=rng_state(),
            initial_checkpoint=spec['parent_checkpoint'],epoch_completed=False)
        if nonlinear:value['residual_pca_config']=model.residual_pca_config
        atomic_save(value,path)
    def validate(stage,step):
        result=evaluate(model,normalizer,val,plan['evaluation_windows'],'cuda:0')
        row=dict(stage=stage,step=step,result=result,elapsed_seconds=time.monotonic()-started,state_dim=dimension,nonlinear=nonlinear)
        atomic_json(folder/(stage+'_evaluation.json'),row)
        with (folder/'evaluations.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
        return row
    try:
        atomic_json(folder/'progress.json',dict(state='initial_validation',step=0))
        validate('initial',0);examples(root,folder,model,normalizer,initial,plan);(folder/'profiles.npz').replace(folder/'initial_profiles.npz')
        train=datasets(root,initial,'train');loader=DataLoader(CachedWindows(train,np.load(root/'fit_indices.npy'),np.load(root/'train_cache_order.npy')),
            batch_size=plan['physical_batch'],shuffle=False,num_workers=2,pin_memory=True,generator=torch.Generator().manual_seed(42))
        accumulation=plan['effective_batch']//plan['physical_batch'];step=0;loss_sum=0.;optimizer.zero_grad(set_to_none=True);model.train()
        torch.cuda.reset_peak_memory_stats()
        for micro,raw in enumerate(loader,1):
            b=normalizer.prepare(raw,'cuda:0');state=states[raw['cache_position']].to('cuda:0')
            with torch.autocast('cuda',dtype=torch.bfloat16):out=model.decode_state(state,b['mask'],b['tick_norm'],b['times'])
            loss=criterion(out,b)['loss']
            if not torch.isfinite(loss):raise FloatingPointError('Nonfinite inverse-training loss')
            (loss/accumulation).backward();loss_sum+=loss.item()/accumulation
            if micro%accumulation:continue
            norm=torch.nn.utils.clip_grad_norm_([p for group in groups for p in group['params']],1.,error_if_nonfinite=True)
            optimizer.step();optimizer.zero_grad(set_to_none=True);step+=1
            if step==1 or step%8==0:
                row=dict(state='training',step=step,loss=loss_sum,gradient_norm=float(norm),elapsed_seconds=time.monotonic()-started,
                         reserved_gib=torch.cuda.memory_reserved()/2**30,peak_allocated_gib=torch.cuda.max_memory_allocated()/2**30)
                atomic_json(folder/'progress.json',row);print(json.dumps(row),flush=True)
            loss_sum=0.
            if step%64==0:save(folder/'last.pt',step);validate('latest',step)
            if step==plan['steps']:break
        if step!=plan['steps']:raise RuntimeError('Inverse training ended early')
        save(folder/'final.pt',step);validate('final',step);examples(root,folder,model,normalizer,initial,plan)
        atomic_json(folder/'status.json',dict(state='complete',step=step,elapsed_seconds=time.monotonic()-started))
    except BaseException as error:atomic_json(folder/'status.json',dict(state='failed',error=repr(error)));raise


def run(root):
    plan=json.loads((root/'plan.json').read_text());children=[];started=time.monotonic();status=dict(state='running',children=[])
    try:
        for gpu,lane in zip((2,3,4,5),LANES):
            env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),CUDA_DEVICE_ORDER='PCI_BUS_ID',PYTHONPATH=str(root/'source_snapshot'),
                     PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4')
            with (root/'logs'/(lane+'.log')).open('ab',buffering=0) as log:
                p=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.pca_inverse_run',str(root),'--lane',lane],
                    cwd=root/'source_snapshot',env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            children.append((lane,p));status['children'].append(dict(lane=lane,gpu=gpu,pid=p.pid))
        atomic_json(root/'status.json',status)
        while any(p.poll() is None for _,p in children):
            if time.monotonic()-started>plan['timeout_seconds']:raise TimeoutError('Inverse comparison timeout')
            if any(p.poll() not in (None,0) for _,p in children):raise RuntimeError('An inverse comparison worker failed')
            time.sleep(3)
        if any(p.returncode!=0 for _,p in children):raise RuntimeError('An inverse comparison worker exited unsuccessfully')
        rows={lane:{stage:json.loads((root/lane/(stage+'_evaluation.json')).read_text()) for stage in ('initial','final')} for lane,_ in children}
        for dim in (1024,256):
            a,b=[rows[name+str(dim)]['initial']['result']['metrics'] for name in ('linear','nonlinear')]
            for key in ('price_usdt','quantity_btc'):
                if abs(a[key]['rmse']-b[key]['rmse'])>1e-4:raise RuntimeError('Zero-residual paired initialization mismatch')
        atomic_json(root/'comparison.json',dict(rows=rows,seed=42,steps=plan['steps'],
            intervention='Only nonlinear latent inverse is added; PCA vectors and source encoder are identical within each pair',
            caveat='This tests inverse capacity, not yet a learned nonlinear encoding of previously discarded directions'))
        status.update(state='complete',elapsed_seconds=time.monotonic()-started)
    except BaseException as error:status.update(state='failed',error=repr(error));raise
    finally:
        for _,p in children:
            if p.poll() is None:
                try:os.killpg(p.pid,signal.SIGTERM)
                except ProcessLookupError:pass
        for _,p in children:
            try:p.wait(timeout=10)
            except subprocess.TimeoutExpired:
                try:os.killpg(p.pid,signal.SIGKILL)
                except ProcessLookupError:pass
        atomic_json(root/'status.json',status)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--lane',choices=LANES);a=p.parse_args()
    if a.lane:worker(a.root,a.lane)
    else:run(a.root)
