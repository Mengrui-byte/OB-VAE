"""Actual512-side-frame input projection precision, no model training."""
import argparse
import json
import os
from pathlib import Path
import time

import numpy as np
import torch

from model.layers.sensitive_precision import apply_sensitive_precision_
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.price_safe_readout import file_hash
from train_dual.util.checkpoint import freeze_sources,load_for_inference
from train_dual.util.phase_training import tensor_digest

MODULE='train_dual.experiments.production_stem_precision'
DELTAS=(.001,.01,1.,100.)


def prepare(goal):
    source=goal/'round_008_auxiliary';root=goal/'production_stem_precision_20261028'
    root.mkdir();(root/'data').mkdir();(root/'logs').mkdir()
    assert json.loads((source/'startup_control_audit.json').read_text())['passed']
    for name in ['source.pt','train_indices.npy','quantity_calibration_indices.npy']:
        os.link(source/name,root/name)
    os.link(source/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    old=json.loads((source/'plan.json').read_text())
    plan={k:old[k] for k in ['train','development','window_size','stride','input_shape','latent_shape','output_shape']}
    index=int(np.load(root/'quantity_calibration_indices.npy')[0])
    assert index in np.load(root/'train_indices.npy')
    plan.update(source_sha256=file_hash(root/'source.pt'),training_index=index,frames=[0,127],deltas_BTC=list(DELTAS),
        actual_stem_batch=[512,16,2048],site_policy='One deterministic median eligible0<q<0.01 rank96..1951 per side and frame0/127.',
        scope='One existing training window, full256frames; compare original BF16 vs forced-FP32 firstConv at actual512side-frame batch. Only features and input projection; no full-model inference or optimizer updates.',
        numerical_policy=dict(TF32=False,cudnn_deterministic=True,cudnn_benchmark=False),source_model_frozen=True)
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared_not_running'))
    freeze_sources(root/'source_snapshot')
    project=Path(__file__).resolve().parents[2]
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 CUDA_DEVICE_ORDER=PCI_BUS_ID\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m {MODULE} "{remote}" --run >> "{remote}/logs/run.log" 2>&1\n')
    print(root.resolve(),flush=True)


def run(root):
    begin=time.monotonic();torch.set_num_threads(2)
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
    p=json.loads((root/'plan.json').read_text());assert file_hash(root/'source.pt')==p['source_sha256']
    model,norm=load_for_inference(root/'source.pt','cpu');model.eval().requires_grad_(False)
    before=tensor_digest(model);apply_sensitive_precision_(model)
    feature=model.encoder.features.to('cuda:0');stem=model.encoder.input_proj.to('cuda:0')
    data=dataset(root,'train');index=p['training_index'];raw={k:v.unsqueeze(0) for k,v in data[index].items()}
    assert list(raw['data'].shape)==[1,256,2,2048,2]
    times=data.base.times[int(data.base.starts[index]):int(data.base.starts[index])+256]
    assert np.all(np.diff(times//60000000)==1)
    b=norm.prepare(raw,'cuda:0');q=b['volume'];mask=b['mask'];records=[]

    def project(features,force):
        apply_sensitive_precision_(model,encoder_input_fp32=force)
        with torch.autocast('cuda',dtype=torch.bfloat16):out=stem(features)
        assert out.dtype==(torch.float32 if force else torch.bfloat16)
        return out.float()

    atomic_json(root/'status.json',dict(state='running_GPU_submodule_only',pid=os.getpid()))
    with torch.inference_mode():
        f0=feature(b['price'],q,mask,b['tick_norm']);assert list(f0.shape)==p['actual_stem_batch']
        h32=project(f0,True);hb=project(f0,False)
        assert torch.equal(h32,project(f0,True)) and torch.equal(hb,project(f0,False))
        for frame in p['frames']:
            for side in range(2):
                eligible=torch.nonzero((q[0,frame,side]>0)&(q[0,frame,side]<.01)&mask[0,frame,side]).flatten()
                eligible=eligible[(eligible>=96)&(eligible<1952)];assert len(eligible)>0
                rank=int(eligible[len(eligible)//2])
                for delta in DELTAS:
                    edited=q.clone();edited[0,frame,side,rank]+=delta
                    f1=feature(b['price'],edited,mask,b['tick_norm'])
                    a=project(f1,True)-h32;c=project(f1,False)-hb
                    aa=float(a.square().sum());cc=float(c.square().sum());assert aa>0
                    assert torch.isfinite(a).all() and torch.isfinite(c).all()
                    changed_rows=torch.nonzero(a.abs().sum((1,2))+c.abs().sum((1,2))).flatten().tolist()
                    assert changed_rows==[2*frame+side]
                    records.append(dict(training_index=index,frame=frame,side=side,rank_zero_based=rank,
                        quantity_before_BTC=float(q[0,frame,side,rank]),delta_BTC=delta,
                        FP32_changed_elements=int(torch.count_nonzero(a)),BF16_changed_elements=int(torch.count_nonzero(c)),
                        FP32_delta_norm=aa**.5,BF16_delta_norm=cc**.5,
                        delta_cosine=float((a*c).sum())/(aa*cc)**.5 if cc>0 else None,
                        relative_delta_error_norm=float((a-c).square().sum())**.5/aa**.5,
                        BF16_input_features_identical=torch.equal(f0.to(torch.bfloat16),f1.to(torch.bfloat16)),
                        unaffected_side_frames_exact=True))
                    del edited,f1,a,c
                    atomic_json(root/'progress.json',dict(cases=len(records),total=16,elapsed_seconds=time.monotonic()-begin))
    assert tensor_digest(model)==before and file_hash(root/'source.pt')==p['source_sha256']
    summary={}
    for delta in DELTAS:
        rows=[r for r in records if r['delta_BTC']==delta];cos=[r['delta_cosine'] for r in rows if r['delta_cosine'] is not None]
        summary[str(delta)]=dict(cases=len(rows),BF16_whole_stem_unchanged=sum(r['BF16_changed_elements']==0 for r in rows),
            median_delta_cosine=float(np.median(cos)) if cos else None,
            median_relative_delta_error_norm=float(np.median([r['relative_delta_error_norm'] for r in rows])),
            median_FP32_changed_elements=float(np.median([r['FP32_changed_elements'] for r in rows])),
            median_BF16_changed_elements=float(np.median([r['BF16_changed_elements'] for r in rows])))
    result=dict(state='complete_production_batch_submodule_diagnostic',summary=summary,records=records,device=torch.cuda.get_device_name(0),
        source_model_unchanged=True,actual_input=[1,256,2,2048,2],actual_projection_input=p['actual_stem_batch'],
        source_encoder_type=type(model.encoder).__name__,source_sha256=p['source_sha256'],
        neural_full_model_forwards=0,optimizer_updates=0,elapsed_seconds=time.monotonic()-begin,
        interpretation='One training window; confirms arithmetic sensitivity at production stem batch, not a training benefit, latent sufficiency result, or full-model reconstruction score.')
    atomic_json(root/'result.json',result);atomic_json(root/'status.json',dict(state='complete',pid=os.getpid()))
    print(json.dumps(summary),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('root',type=Path);parser.add_argument('--prepare',action='store_true');parser.add_argument('--run',action='store_true');a=parser.parse_args()
    try:
        if a.prepare:prepare(a.root.resolve())
        elif a.run:run(a.root.resolve())
        else:parser.error('Specify --prepare or --run')
    except BaseException as error:
        if a.run:atomic_json(a.root/'status.json',dict(state='failed',pid=os.getpid(),error=repr(error)))
        raise
