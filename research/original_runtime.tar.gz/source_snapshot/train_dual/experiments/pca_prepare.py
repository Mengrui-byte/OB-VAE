"""Cache full decoder latents and fit grouped PCA on training windows only."""

import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import numpy as np
import torch
from torch.utils.data import DataLoader, Subset

from model.experimental.dual_fusion import FusedOrderBookVAE
from train_dual.experiments.long_worker import atomic_json, datasets
from train_dual.experiments.window_state_pilot import load_base, strict_precision
from train_dual.util.checkpoint import atomic_save, seed_everything


def extract(root, chunk):
    torch.set_num_threads(4);seed_everything(42);strict_precision()
    initial,norm=load_base(root)
    model=FusedOrderBookVAE(fusion_variant='cross',fusion_seed=42,**initial['model_config']).to('cuda:0')
    model.load_state_dict(initial['model'],strict=True);model.eval()
    data=datasets(root,initial,'train');all_indices=np.load(root/'fit_indices.npy')
    indices=np.array_split(all_indices,4)[chunk]
    loader=DataLoader(Subset(data,indices.tolist()),batch_size=8,shuffle=False,num_workers=2)
    parts={key:[] for key in ('global','local','mask','times')};seen=0
    with torch.inference_mode():
        for raw in loader:
            b=norm.prepare(raw,'cuda:0')
            p=model.encoder(b['price'],b['volume'],b['mask'],b['tick_norm'],times=b['times'],sample=False)
            f=model.fusion([(p['z_global'],p['z_local'])],p['latent_mask'],b['times'])
            for name,value in [('global',f['global_latent']),('local',f['local_latent']),('mask',p['latent_mask']),('times',b['times'])]:
                parts[name].append(value.cpu())
            seen+=len(raw['data'])
            if seen%128==0:atomic_json(root/f'extract_{chunk}.json',dict(state='extracting',windows=seen,total=len(indices)))
    output={key:torch.cat(value) for key,value in parts.items()};output['indices']=indices
    atomic_save(output,root/f'cache_{chunk}.pt')
    atomic_json(root/f'extract_{chunk}.json',dict(state='complete',windows=seen,total=len(indices)))
    print(json.dumps(dict(chunk=chunk,windows=seen)),flush=True)


def fit(root):
    torch.set_num_threads(4);seed_everything(42);strict_precision()
    plan=json.loads((root/'plan.json').read_text());parts=[]
    for chunk in range(4):parts.append(torch.load(root/f'cache_{chunk}.pt',map_location='cpu',weights_only=False))
    cache={key:torch.cat([p[key] for p in parts]) for key in ('global','local','mask','times')}
    indices=np.concatenate([p['indices'] for p in parts]);assert np.array_equal(indices,np.load(root/'fit_indices.npy'))
    atomic_save(cache,root/'decoder_latents.pt')
    del parts
    g=cache['global'].to('cuda:0');l=cache['local'].to('cuda:0');n=len(g)
    gs=g.reshape(-1,g.shape[-1]).std(0).clamp_min(.05).repeat(g.shape[1])
    ls=l.reshape(-1,l.shape[-1]).std(0).clamp_min(.05).repeat(l.shape[1]*l.shape[2]*l.shape[3])
    g=g.reshape(n,-1);l=l.reshape(n,-1);gm=g.mean(0);lm=l.mean(0)
    xg=(g-gm)/gs;xl=(l-lm)/ls
    del g,l
    atomic_json(root/'preparation_status.json',dict(state='fitting_global_pca',samples=n))
    ug,sg,vhg=torch.linalg.svd(xg,full_matrices=False)
    genergy=sg.square().cumsum(0)/sg.square().sum()
    requested=int(torch.searchsorted(genergy,torch.tensor(plan['global_variance_target'],device='cuda:0')).item())+1
    ng=min(requested,plan['global_component_cap'])
    maxlocal=max(plan['state_dimensions'])-ng;q=maxlocal+plan['pca_oversampling']
    atomic_json(root/'preparation_status.json',dict(state='fitting_local_pca',samples=n,global_components=ng,local_components=maxlocal))
    ul,sl,vl=torch.pca_lowrank(xl,q=q,center=False,niter=plan['pca_power_iterations'])
    gb=vhg[:ng].contiguous();lb=vl[:,:maxlocal].T.contiguous()
    gc=xg@gb.T;lc=xl@lb.T
    ge=float((gb@gb.T-torch.eye(ng,device='cuda:0')).abs().max())
    le=float((lb@lb.T-torch.eye(maxlocal,device='cuda:0')).abs().max())
    if ge>1e-3 or le>1e-3:raise RuntimeError(f'PCA basis orthogonality failed: {ge}, {le}')
    basis={k:v.cpu() for k,v in dict(global_mean=gm,global_scale=gs,global_basis=gb,
                                   local_mean=lm,local_scale=ls,local_basis=lb).items()}
    atomic_save(basis,root/'pca_basis.pt')
    local_total=float(xl.square().sum());metrics={}
    for dimension in plan['state_dimensions']:
        count=dimension-ng
        state=torch.cat([gc,lc[:,:count]],1).cpu()
        atomic_save(dict(states=state,indices=indices),root/f'train_states_{dimension}.pt')
        metrics[str(dimension)]=dict(global_components=ng,local_components=count,
            global_variance_retained=float(genergy[ng-1]),local_variance_retained=float(lc[:,:count].square().sum())/local_total)
    info=dict(fit_windows=n,fit_split=plan['train'],global_components_requested_for_target=requested,
        global_components=ng,global_target=plan['global_variance_target'],dimensions=metrics,
        basis_orthogonality_max_error=dict(global_basis=ge,local_basis=le),
        local_algorithm='randomized PCA',oversampling=plan['pca_oversampling'],power_iterations=plan['pca_power_iterations'],
        global_channel_scale_floor=.05,local_channel_scale_floor=.05,
        source='Frozen cross decoder-input posterior-mean latents after global/local fusion')
    atomic_json(root/'pca_fit.json',info)
    atomic_json(root/'preparation_status.json',dict(state='complete',samples=n,global_components=ng))
    print(json.dumps(info),flush=True)


def prepare(root):
    plan=json.loads((root/'plan.json').read_text());logs=root/'logs';logs.mkdir(exist_ok=True)
    children=[];started=time.monotonic()
    atomic_json(root/'preparation_status.json',dict(state='extracting_source_latents'))
    try:
        for chunk,gpu in enumerate((2,3,4,5)):
            env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),CUDA_DEVICE_ORDER='PCI_BUS_ID',
                     PYTHONPATH=str(root/'preparation_sources'),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4')
            with (logs/f'extract_{chunk}.log').open('ab',buffering=0) as log:
                p=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.pca_prepare',str(root),'--chunk',str(chunk)],
                    cwd=root/'preparation_sources',env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            children.append(p)
        while any(p.poll() is None for p in children):
            if time.monotonic()-started>plan['preparation_timeout_seconds']:raise TimeoutError('Source preparation timeout')
            if any(p.poll() not in (None,0) for p in children):raise RuntimeError('Source extraction failed')
            time.sleep(2)
        if any(p.returncode!=0 for p in children):raise RuntimeError('A source extraction worker failed')
        fit(root)
    except BaseException as error:
        atomic_json(root/'preparation_status.json',dict(state='failed',error=repr(error)));raise
    finally:
        for p in children:
            if p.poll() is None:
                try:os.killpg(p.pid,signal.SIGTERM)
                except ProcessLookupError:pass


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--chunk',type=int)
    a=p.parse_args()
    if a.chunk is None:prepare(a.root)
    else:extract(a.root,a.chunk)
