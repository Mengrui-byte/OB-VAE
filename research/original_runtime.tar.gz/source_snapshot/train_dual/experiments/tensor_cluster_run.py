"""Full-tensor-pair clustering at identical index rate, seed and source model."""

import argparse
from datetime import datetime
import json
import os
from pathlib import Path

from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.paired_matrix_run import worker
from train_dual.experiments.small_codebook_run import campaign
from train_dual.util.checkpoint import freeze_sources


METHODS=('kmeans_random','kmeans_pp','pam_squared','pam_distance')


def prepare(parent):
    parent=parent.resolve();root=parent.parent/('tensor_cluster_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
    root.mkdir();(root/'logs').mkdir();(root/'data').mkdir()
    for name in ('initial.pt','expected_reference.json','source_profiles.npz'):os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    for name in ('decoder_latents.pt','fit_indices.npy'):(root/name).symlink_to(os.path.relpath((parent/name).resolve(),root))
    plan=json.loads((parent/'plan.json').read_text())
    plan.update(parent=str(parent),experiment='Full tensor-pair clustering controls',
        lanes={method:dict(mode='joint',metric='l2',size=16,levels=8,tensor_method=method) for method in METHODS},
        pam_swaps=12,fit_iterations=12,residual_levels=8,depths=[1,2,4,8],seed=42,
        global_matrix_shape=[16,64],local_matrix_shape=[16,2,128,16],
        no_local_code_splitting=True,no_semantic_constraints=True,no_future_returns=True,
        method='Random Lloyd baseline; D-squared kmeans++ Lloyd; exact best-SWAP PAM on squared productL2; same PAM on productL2. Each PAM level accepts at most12 improving global swaps, may stop earlier; not guaranteed convergence when budget exhausted.',
        hypotheses=['Initialization alone may change degenerate residual assignments.',
                    'Real paired residual exemplars may decode differently from averaged prototypes at the same code rate.'],
        distance='All select nearest complete tensor pair using raw Eg+El. Square-root PAM changes only the summed fitting objective; no branch weights/whitening/size normalization.',
        rate_note='All8levels x16codes:32 logical index bits/window, codes[B,8]. Full CG[8,16,16,64], CL[8,16,16,2,128,16],32.5MiB codeword tensors; shared means, medoid indices, source model, mask/tick/anchor excluded. No bitpacking.',
        primary_evaluation='Complete-book price/quantity RMSE, minute quantity dynamics and >=100BTC recall; all final fixed-budget results retained.',
        algorithm_sources=['https://arxiv.org/abs/2008.05171','https://theory.stanford.edu/~sergei/papers/kMeansPP-soda.pdf'])
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(parent.parents[1])
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'
        f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\n'
        f'cd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.tensor_cluster_run "{remote}"\n')
    Path('/tmp/tensor_cluster_run_path').write_text(str(root));print(root,flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--lane',choices=METHODS);a=p.parse_args()
    if a.prepare:prepare(a.root)
    elif a.lane:worker(a.root,a.lane)
    else:campaign(a.root,worker_module='train_dual.experiments.tensor_cluster_run')
