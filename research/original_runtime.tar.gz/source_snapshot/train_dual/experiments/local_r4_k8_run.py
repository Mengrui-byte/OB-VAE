"""Historical16minute frozen local RVQ: R4K8 with R/K factorial controls."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import time

import numpy as np
import torch

from model.experimental.local_paired_state import LocalPairedOrderBookVAE
from train_dual.experiments.local_codebook_size_run import write,physical,probes
from train_dual.experiments.long_worker import datasets
from train_dual.util.data import DualNormalizer
from train_dual.util.dynamics import DynamicsMetrics
from util.model_sources import freeze_model_sources


def prefix_model(source,levels,size,config):
    model=LocalPairedOrderBookVAE(quant_window=16,quant_levels=levels,quant_size=size,**config).eval()
    state={k:(v[:levels].clone() if k in ('local_quantizer.book.global_codebook','local_quantizer.book.local_codebook') else v)
           for k,v in source.state_dict().items()}
    model.load_state_dict(state,strict=True)
    return model


def run(root):
    root=root.resolve();root.mkdir(parents=True,exist_ok=False);started=time.monotonic()
    project=Path(__file__).resolve().parents[2];parent=project/'recons/local8_k4_vs_k16_20261026';old=project/'checkpoints/local_quant_recon_20261025_150636'
    def progress(**kw):
        value=dict(elapsed_seconds=time.monotonic()-started,**kw);write(root/'progress.json',value)
        with (root/'progress.jsonl').open('a') as stream:stream.write(json.dumps(value)+'\n')
        print(json.dumps(value),flush=True)
    write(root/'status.json',dict(state='running'));torch.set_num_threads(4);torch.manual_seed(42)
    hashes=freeze_model_sources(root/'source_snapshot',project_root=project)
    for name in ['train_dual/experiments/local_r4_k8_run.py','train_dual/experiments/local_codebook_size_run.py',
                 'train_dual/experiments/long_worker.py','train_dual/util/data.py','train_dual/util/dynamics.py','util/dataset.py']:
        p=root/'source_snapshot'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(project/name,p)
        hashes[name]=hashlib.sha256(p.read_bytes()).hexdigest()
    write(root/'source_snapshot/sha256.json',hashes)
    priorfile=parent/'k4/final.pt';saved=torch.load(priorfile,map_location='cpu',weights_only=False)
    prior=LocalPairedOrderBookVAE(**saved['local_paired_config'],**saved['model_config']).eval();prior.load_state_dict(saved['model'],strict=True)
    common={k:v for k,v in saved['model'].items() if not k.startswith('local_quantizer.')}
    target=LocalPairedOrderBookVAE(quant_window=16,quant_levels=4,quant_size=8,**saved['model_config']).eval();target.load_cross_initial(common)
    control=LocalPairedOrderBookVAE(quant_window=16,quant_levels=8,quant_size=8,**saved['model_config']).eval();control.load_cross_initial(common)
    norm=DualNormalizer(**{k:saved['config']['normalization'][k] for k in ('tick_size','price_scale')})
    train=datasets(old,saved,'train');val=datasets(old,saved,'val')
    indices=np.load(parent/'evaluation_indices.npy');fit_indices=np.load(parent/'fit_indices.npy');sample=np.load(parent/'training_patch_indices.npy')
    for name in ('evaluation_indices.npy','fit_indices.npy','training_patch_indices.npy'):shutil.copy2(parent/name,root/name)
    b=norm.prepare({k:v.unsqueeze(0) for k,v in val[int(indices[0])].items()},'cpu')
    with torch.inference_mode():
        p=target.encoder(b['price'],b['volume'],b['mask'],b['tick_norm'],times=b['times'],sample=False)
        f=target.fusion([(p['z_global'],p['z_local'])],p['latent_mask'],b['times'])
        out=target.decode_latents(f['global_latent'],f['local_latent'],b['mask'],b['tick_norm'],b['times'])
    assert list(b['price'].shape)==[1,16,2,2048] and list(out['volume'].shape)==[1,16,2,2048]
    assert list(f['global_latent'].shape)==[1,16,64] and list(f['local_latent'].shape)==[1,16,2,128,16]
    write(root/'actual_shape_contract.json',dict(raw_input=[1,16,2,2048,2],global_latent=list(f['global_latent'].shape),
        local_latent=list(f['local_latent'].shape),price_output=list(out['price_norm'].shape),quantity_output=list(out['volume'].shape),
        target_integer_codes=[1,16,128,4],window_minutes=16,scope='User-requested continuation of the historical16minute local RVQ comparison, not256minute mainline.'))
    prefix_positions=set(np.linspace(0,127,16,dtype=int).tolist())
    specs={'r4_k4':dict(levels=4,size=4),'r4_k8':dict(levels=4,size=8),'r8_k8':dict(levels=8,size=8)}
    plan=dict(target='r4_k8',seed=42,specs=specs,existing_matched_control='r8_k4',parent=str(parent),
        train=['2022-01-01','2025-01-01'],development=['2025-01-01','2025-04-01'],window_minutes=16,
        fit_windows=8192,fit_samples=131072,iterations_per_level=12,adam_steps=0,precision='FP32CPU,4threads',evaluation_windows=128,
        target_prefix_evaluation_positions=sorted(prefix_positions),target_prefix_evaluation_windows=16,
        source_checkpoint=str(priorfile),source_sha256=hashlib.sha256(priorfile.read_bytes()).hexdigest(),
        hypotheses='Requested R4K8 jointly changes depth and size relative to R8K4. R4K4 isolates K at R4; R8K8 isolates R at K8. Report interactions without claiming a single-factor effect from the combined change.',
        initialization='Same source neural weights and training means; exact prior patch stream; shared per-level randperm initial samples. K4 first4 centers are subset of K8 first8 indices. Independently fit R4K8 and R8K8 and assert first4 codebooks identical.',
        inherited_r4k4='Use first4 fitted stages of previous R8K4; earlier residual KMeans stages are independent of later stages. Preserve exact prefix weights and label reuse.',
        inherited_r8k4='Reuse previous128-window full result only after matching all128 integer codes and identical decoder parameters; check saved reconstruction examples. No new training for this control.',
        budget='Same12iterations per level and same131072patches; R4 uses48KMeans iterations, R8 uses96. Different levels intrinsically alter total fitting compute; no equal-total-compute claim.',
        logical_bits_per_window={'r4_k4':16384,'r4_k8':24576,'r8_k4':32768,'r8_k8':49152},
        note='Index bits exclude codebooks, means, source model and metadata; indices not bitpacked. No semantic constraints or future outcomes. Single seed; reused development set, not independent final test.',source_hashes=hashes)
    write(root/'plan.json',plan);progress(phase='preparing_identical_fit_patches')
    cache=torch.load(old/'decoder_latents.pt',map_location='cpu',mmap=True,weights_only=False);g,l=cache['global'],cache['local']
    assert list(g.shape)==[8192,16,64] and list(l.shape)==[8192,16,2,128,16]
    with torch.inference_mode():
        for pos in (0,4096,8191):
            raw={k:v.unsqueeze(0) for k,v in train[int(fit_indices[pos])].items()};bb=norm.prepare(raw,'cpu')
            pp=prior.encoder(bb['price'],bb['volume'],bb['mask'],bb['tick_norm'],times=bb['times'],sample=False)
            ff=prior.fusion([(pp['z_global'],pp['z_local'])],pp['latent_mask'],bb['times'])
            torch.testing.assert_close(ff['global_latent'],g[pos:pos+1],rtol=1e-5,atol=1e-4)
            torch.testing.assert_close(ff['local_latent'],l[pos:pos+1],rtol=1e-5,atol=1e-4)
        go,lo=g.mean(0),l.mean(0)
        assert torch.equal(go,prior.local_quantizer.global_origin) and torch.equal(lo,prior.local_quantizer.local_origin)
        ix=torch.from_numpy(sample);wi=ix//(16*128);ti=(ix//128)%16;ki=ix%128
        pg=(g[wi,ti]-go[ti])[:,None];pl=l[wi,ti,:,ki]-lo[ti,:,ki]
    generator=torch.Generator().manual_seed(42);initials=torch.stack([torch.randperm(len(pg),generator=generator)[:8] for _ in range(8)])
    assert np.array_equal(initials.numpy(),np.load(parent/'center_initialization_indices.npy')[:,:8])
    np.save(root/'center_initialization_indices.npy',initials.numpy());del cache,g,l
    for name,m in [('r4_k8',target),('r8_k8',control)]:
        (root/name).mkdir();q=m.local_quantizer;q.global_origin.copy_(go);q.local_origin.copy_(lo)
        history=q.book.fit(pg,pl,iterations=12,seed=42,callback=lambda d:progress(phase='fitting_codebooks',variant=name,**d))
        write(root/name/'fit_history.json',history)
    del pg,pl
    for attr in ('global_codebook','local_codebook'):
        assert torch.equal(getattr(target.local_quantizer.book,attr),getattr(control.local_quantizer.book,attr)[:4])
    models={'r4_k4':prefix_model(prior,4,4,saved['model_config']),'r4_k8':target,'r8_k8':control}
    (root/'r4_k4').mkdir()
    for name,m in models.items():
        assert all(torch.equal(v,m.state_dict()[k]) for k,v in common.items())
        torch.save(dict(format_version=1,model=m.state_dict(),model_config=saved['model_config'],config=saved['config'],
            local_paired_config=m.local_paired_config,source_hashes=hashes,initial_checkpoint=str(priorfile)),root/name/'final.pt')
        assert m.local_quantizer.logical_bits()==plan['logical_bits_per_window'][name]
    previous=np.load(parent/'k4/codes_features.npz');previous_profiles=np.load(parent/'k4/profiles.npz');oldcodes=previous['codes']
    assert np.array_equal(previous['indices'],indices)
    stats={};tails={};codes={name:[] for name in models};energy={name:[] for name in models};features=[];months=[];profiles={name:[] for name in models};truths=[]
    def update(key,truth,pred,mask):
        if key not in stats:stats[key]=DynamicsMetrics(norm.tick_size);tails[key]=np.zeros(3,dtype='int64')
        stats[key].update(truth,pred,mask);a=(truth[...,1]>=100)&mask;bb=(pred[...,1]>=100)&mask
        tails[key]+=[int((a&bb).sum()),int((~a&bb&mask).sum()),int((a&~bb).sum())]
    with torch.inference_mode():
        for position,index in enumerate(indices):
            raw={k:v.unsqueeze(0) for k,v in val[int(index)].items()};b=norm.prepare(raw,'cpu')
            p=prior.encoder(b['price'],b['volume'],b['mask'],b['tick_norm'],times=b['times'],sample=False)
            f=prior.fusion([(p['z_global'],p['z_local'])],p['latent_mask'],b['times']);gg,ll=f['global_latent'],f['local_latent']
            truth=raw['data'][0].numpy().astype('float64');mask=b['mask'][0].numpy();assert bool(mask.all())
            features.append(physical(truth));stamp=int(val.base.times[int(val.base.starts[int(index)])]);months.append(str(np.datetime64(stamp,'us'))[:7])
            previous_q=prior.local_quantizer(gg,ll,prior.latent_mask(b['mask']).any(2))
            assert np.array_equal(previous_q['codes'][0].numpy(),oldcodes[position])
            if position in (0,63,127):
                truths.append(truth)
                oo=prior.decode_codes(previous_q['codes'],b['mask'],b['tick_norm'],b['times'])
                replay=np.stack([norm.inverse_price(oo['price_norm'],b)[0].numpy(),oo['volume'][0].numpy()],-1)
                np.testing.assert_allclose(replay,previous_profiles['prediction'][[0,63,127].index(position)],rtol=0,atol=1e-8)
            for name,m in models.items():
                q=m.local_quantizer;pg,pl=q.pairs(gg,ll);v=q.book(pg,pl);depths=q.book.levels
                code=v['codes'].reshape(1,16,128,depths);assert int(code.min())>=0 and int(code.max())<q.book.size
                codes[name].append(code[0].numpy().astype('uint8'));energy[name].append(v['residual_energy'].mean(0).numpy())
                for depth in (range(1,5) if name=='r4_k8' and position in prefix_positions else (depths,)):
                    output=m.decode_codes(code[...,:depth],b['mask'],b['tick_norm'],b['times'])
                    pred=np.stack([norm.inverse_price(output['price_norm'],b)[0].numpy(),output['volume'][0].numpy()],-1)
                    key=name if depth==depths else 'target_prefix'+str(depth);update(key,truth,pred,mask)
                    if name=='r4_k8' and depth==4 and position in prefix_positions:update('target_prefix4',truth,pred,mask)
                    if name=='r4_k4' and position in prefix_positions:update('r4_k4_previous_prefix_subset',truth,pred,mask)
                    if depth==depths and position in (0,63,127):profiles[name].append(pred)
                    if position==0 and depth==depths:
                        direct=m.forward_latents(gg,ll,b['mask'],b['tick_norm'],b['times'])
                        for field in ('volume','price_norm'):torch.testing.assert_close(direct[field],output[field],rtol=0,atol=0)
                        write(root/name/'integer_replay.json',dict(exact=True,code_shape=list(code.shape),code_min=int(code.min()),code_max=int(code.max())))
            if position==0 or (position+1)%8==0:progress(phase='development_evaluation',windows=position+1,total=128)
    results={}
    for name,stat in stats.items():
        d=stat.finish();tp,fp,fn=map(int,tails[name]);d['threshold100']=dict(tp=tp,fp=fp,fn=fn,recall=tp/(tp+fn) if tp+fn else None,precision=tp/(tp+fp) if tp+fp else None);results[name]=d
    older=json.loads((parent/'results.json').read_text());results['r8_k4']=older['k4_depth8'];results['original']=older['original']
    for field in ('price_usdt','quantity_btc'):
        assert abs(results['r4_k4_previous_prefix_subset']['metrics'][field]['rmse']-older['k4_depth4']['metrics'][field]['rmse'])<1e-8
    write(root/'results.json',results)
    # The old audit did not contain128-window R4K4 metrics; independently replay
    # its exact16-window prefix subset to validate inherited prefix weights.
    write(root/'r4_k4/prefix_source.json',dict(source=str(parent/'k4/final.pt'),method='Exact first4 stages, whose fitted values do not depend on later residual stages. Full128-window evaluation is new.'))
    for name,m in models.items():
        cc=np.stack(codes[name]);yy=np.stack(features);mm=np.array(months)
        np.savez_compressed(root/name/'codes_features.npz',codes=cc,features=yy,months=mm,indices=indices)
        np.savez_compressed(root/name/'profiles.npz',truth=np.stack(truths),prediction=np.stack(profiles[name]),indices=indices[[0,63,127]])
        write(root/name/'semantics.json',probes(cc,yy,mm,m.local_quantizer.book.size));write(root/name/'residual_energy.json',np.stack(energy[name]).mean(0).tolist())
    write(root/'verification.json',dict(common_neural_weights_unchanged=all(torch.equal(v,m.state_dict()[k]) for m in models.values() for k,v in common.items()),
        independently_fitted_r4k8_equals_r8k8_first4=True,all128_previous_r8k4_codes_identical=True,previous_r8k4_saved_examples_identical=True,
        integer_decode_replay_exact=True,source_sha256_unchanged=hashlib.sha256(priorfile.read_bytes()).hexdigest()==plan['source_sha256'],
        full128_window_shape_check=True,same_patch_and_initialization_stream=True))
    write(root/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started));progress(phase='complete')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);args=p.parse_args()
    try:run(args.root)
    except BaseException as e:
        if args.root.exists():write(args.root/'failure.json',dict(error=repr(e)))
        raise
