"""Matched loss-control monitor; actual objective losses are not comparable."""
import argparse
from pathlib import Path
from train_dual.experiments.full_window_report import PAGE,monitor

def main(root):
 page=PAGE.replace('256分钟双分支实验','8192维损失控制变量实验').replace('完整256分钟：双分支与整窗矩阵压缩','完整256分钟：损失函数单因素对照')
 begin=page.index('<p>实际输入');end=page.index('<p id=status>',begin)
 text=('<p>完整输入[B,256,2,2048,2]，唯一latent[B,64,128]。四组同一份AE512权重和AdamW状态，固定最近邻上采样、价格损失、归一化、64训练窗/16开发窗、seed42、batch1累积4、学习率1e−4及精度。额外训练1024步，最长4小时；确定性Z=μ，beta0。</p>'
 '<p>匹配对照为原损失基线。候选分别仅将归一化数量Huber换为0.5e²（含Top16数量项）、仅增加空间差分、仅增加时间差分。差分跨度1/4/16，mask有效交集，权重均预设为1。本轮不改变上采样，不组合候选。</p>'
 '<p>图中的训练损失统一显示原基础损失base_loss；实际优化的objective_loss另存日志，不能直接跨定义比较。开发期2025Q1已用于研究，非最终独立测试，2026不参与。显示步数均为本轮追加步数，起点512步训练成本共同计算。旧大latent仅为外部质量参照。</p>')
 page=page[:begin]+text+page[end:];page=page.replace('实际矩阵','实际唯一latent').replace("'训练损失'","'共同基础损失（非各组实际总目标）'")
 monitor(root,page)
if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);main(p.parse_args().root)
