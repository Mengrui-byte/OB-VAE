"""Full-size, train-only four-policy GPU preflight without optimizer updates."""
import argparse
import json
import os
from pathlib import Path
import time

import numpy as np
import torch

from model.layers.sensitive_precision import apply_sensitive_precision_,sensitive_precision_policy
from train_dual.experiments import local_hint_run as shared
from train_dual.experiments.auxiliary_reconstruction_run import criterion
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.price_safe_readout import file_hash
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import atomic_save,freeze_sources,load_for_inference
from train_dual.util.hint_training import restore_regional_phase_adam
from train_dual.util.phase_training import tensor_digest

MODULE='train_dual.experiments.sensitive_precision_preflight'
CASES=dict(control=(False,False),encoder_fp32=(True,False),quantity_fp32=(False,True),both_fp32=(True,True))
BRANCH_CASES=dict(control=(False,False),encoder_fp32=(True,False),decoders_fp32=(False,True),both_fp32=(True,True))


def prepare(goal,branches=False):
    parent=goal/'round_008_auxiliary';root=goal/('branch_precision_full_gpu_preflight_20261028' if branches else 'precision_full_gpu_preflight_20261028_v2')
    root.mkdir();(root/'logs').mkdir()
    old=json.loads((parent/'plan.json').read_text());assert json.loads((parent/'startup_control_audit.json').read_text())['passed']
    index=int(np.load(parent/'quantity_calibration_indices.npy')[0]);assert index in np.load(parent/'train_indices.npy')
    source_path=parent/'control/step1024.pt' if branches else parent/'source.pt'
    payload=torch.load(source_path,map_location='cpu',weights_only=False,mmap=True)
    atomic_json(root/'plan.json',dict(source_root='../round_008_auxiliary',source_sha256=file_hash(source_path),
        source_checkpoint_relative=str(source_path.relative_to(goal)),policy_scope='branches' if branches else 'layers',
        training_index=index,input_shape=[1,256,2,2048,2],latent_shape=[1,64,128],output_shape=[1,256,2,2048],
        source_steps=payload['source_steps']+payload['step'],source_objective='Actual source training objective, including frozen teacher hints; new auxiliary coefficient0.',
        policies=BRANCH_CASES if branches else CASES,scope='One already used training window, four full-size GPU forward/backward and fresh checkpoint Z-only decodes; no optimizer updates or development measurements. Match training mode AND grad context for disabled-policy parity; native inference remains FP32.',
        minimum_initial_free_GiB=24 if branches else 16))
    atomic_json(root/'status.json',dict(state='prepared_not_started'));freeze_sources(root/'source_snapshot')
    project=Path(__file__).resolve().parents[2];remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 CUDA_DEVICE_ORDER=PCI_BUS_ID OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m {MODULE} "{remote}" --run >> "{remote}/logs/run.log" 2>&1\n')
    print(root.resolve(),flush=True)


def run(root):
    begin=time.monotonic();torch.set_num_threads(2);strict_precision()
    p=json.loads((root/'plan.json').read_text());parent=(root/p['source_root']).resolve()
    source_path=root.parent/p.get('source_checkpoint_relative','round_008_auxiliary/source.pt')
    branches=p.get('policy_scope')=='branches'
    if branches:
        from model.layers.branch_precision import apply_branch_precision_,branch_precision_policy
        def apply_policy(model,e,d):return apply_branch_precision_(model,encoder_fp32=e,decoders_fp32=d)
        policy_state=branch_precision_policy;metadata_key='branch_precision_config';cases=BRANCH_CASES
    else:
        def apply_policy(model,e,d):return apply_sensitive_precision_(model,encoder_input_fp32=e,quantity_head_fp32=d)
        policy_state=sensitive_precision_policy;metadata_key='precision_policy_config';cases=CASES
    assert file_hash(source_path)==p['source_sha256']
    free,_=torch.cuda.mem_get_info();assert free/2**30>=p['minimum_initial_free_GiB'], 'Insufficient free owned GPU memory for diagnostic'
    atomic_json(root/'status.json',dict(state='running_full_GPU_preflight_only',pid=os.getpid()))
    model,norm=load_for_inference(source_path,'cuda:0');before=tensor_digest(model)
    source=torch.load(source_path,map_location='cpu',weights_only=False,mmap=True)
    parent_plan=json.loads((parent/'plan.json').read_text())
    opt=restore_regional_phase_adam(model,source['optimizer'],parent_plan['original_parameter_names'])
    ids=[id(x) for x in model.parameters()];optids=[[id(x) for x in group['params']] for group in opt.param_groups]
    data=dataset(parent,'train');raw={k:v.unsqueeze(0) for k,v in data[p['training_index']].items()}
    assert list(raw['data'].shape)==p['input_shape']
    b=norm.prepare(raw,'cuda:0')
    teacher,tn=load_for_inference(parent/'teacher.pt','cuda:0');teacher.eval().requires_grad_(False)
    target=shared.teacher_local(teacher,tn,raw);teacher_before=tensor_digest(teacher)
    obj=criterion(parent,'control','cuda:0')
    keys=['z','mu','logvar','price_norm','volume','quantity_logit']
    if branches:keys+=['hint_local','quantity_seed']
    model.eval()
    with torch.no_grad():baseline=call(model,b,False)
    reference_native={k:baseline[k].detach().clone() for k in keys};del baseline
    with torch.no_grad(),torch.autocast('cuda',dtype=torch.bfloat16):baseline=call(model,b,False)
    reference_eval_mu=baseline['mu'].detach().clone();del baseline
    model.train()
    with torch.autocast('cuda',dtype=torch.bfloat16):baseline=call(model,b,False)
    reference={k:baseline[k].detach().clone() for k in keys}
    original_mode_difference=dict(mu_changed_elements=int(torch.count_nonzero(reference_eval_mu-reference['mu'])),
        mu_max_abs_difference=float((reference_eval_mu-reference['mu']).abs().max()),
        scope='Original unmodified model: eval/no_grad/BF16 versus train/grad-enabled/BF16. Not a precision-policy comparison.')
    atomic_json(root/'original_execution_context_difference.json',original_mode_difference)
    del baseline,reference_eval_mu
    records=[]
    for label,(encoder,quantity) in cases.items():
        case_begin=time.monotonic();torch.cuda.reset_peak_memory_stats()
        model.zero_grad(set_to_none=True)
        apply_policy(model,encoder,quantity)
        assert ids==[id(x) for x in model.parameters()] and optids==[[id(x) for x in group['params']] for group in opt.param_groups]
        model.eval()
        with torch.no_grad():native=call(model,b,False)
        for key,value in reference_native.items():torch.testing.assert_close(native[key],value,rtol=0,atol=0)
        native_z=native['z'].detach();pred={k:native[k].detach().clone() for k in ['price_norm','volume','quantity_logit']+(['hint_local','quantity_seed'] if branches else [])}
        del native
        model.train().requires_grad_(True)
        seen=[];dtypes={}
        def trace(name):
            def hook(module,args,out):dtypes[name]=str(out.dtype)
            return hook
        hooks=[d.register_forward_pre_hook(lambda m,args:seen.append(args[0])) for d in [model.price_decoder,model.volume_decoder]]
        hooks += [model.encoder.input_proj.register_forward_hook(trace('encoder_input')),model.volume_decoder.quantity.register_forward_hook(trace('quantity_head'))]
        if branches:
            hooks += [model.encoder.down[3].register_forward_hook(trace('encoder_down3')),model.encoder.mu.register_forward_hook(trace('encoder_mu')),
                model.price_decoder.gap.register_forward_hook(trace('price_head')),model.hint_adapter.register_forward_hook(trace('hint_adapter'))]
        with torch.autocast('cuda',dtype=torch.bfloat16):out=call(model,b,False)
        for hook in hooks:hook.remove()
        assert seen[0] is seen[1] is out['z']
        assert list(out['z'].shape)==p['latent_shape'] and list(out['price_norm'].shape)==list(out['volume'].shape)==p['output_shape']
        expected=dict(encoder_input='torch.float32' if encoder else 'torch.bfloat16',quantity_head='torch.float32' if quantity else 'torch.bfloat16')
        if branches:expected.update(encoder_down3=expected['encoder_input'],encoder_mu=expected['encoder_input'],price_head=expected['quantity_head'],hint_adapter=expected['quantity_head'])
        assert dtypes==expected
        if label=='control':
            for key,value in reference.items():torch.testing.assert_close(out[key],value,rtol=0,atol=0)
        values=obj(out,b,teacher_local=target);assert torch.isfinite(values['loss'])
        values['loss'].backward()
        gradients={}
        for name,module in [('encoder',model.encoder),('price_decoder',model.price_decoder),('volume_decoder',model.volume_decoder)]:
            squared=0.
            for parameter in module.parameters():
                if parameter.grad is not None:
                    assert torch.isfinite(parameter.grad).all();squared+=float(parameter.grad.float().square().sum())
            gradients[name]=squared**.5;assert squared>0
        assert all(parameter.grad is None or not bool(parameter.grad.any()) for parameter in model.encoder.logvar.parameters())
        assert all(parameter.grad is None for parameter in teacher.parameters())
        loss=float(values['loss'].detach());del out,values;model.zero_grad(set_to_none=True)
        # Inference-only diagnostic checkpoint: model tensors and family metadata,
        # intentionally not a trained/resumable optimizer checkpoint.
        keep={k:v for k,v in source.items() if k not in ['optimizer','rng_state','sampler_generator_state','augmentation_generator_state']}
        keep.update(diagnostic_only=True,optimizer_updates=0);keep[metadata_key]=policy_state(model)
        case=root/label;case.mkdir();checkpoint=case/'inference_policy.pt';atomic_save(keep,checkpoint)
        fresh,_=load_for_inference(checkpoint,'cuda:0')
        def no_encoder(*args):raise AssertionError('Fresh Z-only decode called Encoder')
        hook=fresh.encoder.register_forward_pre_hook(no_encoder)
        with torch.no_grad():decoded=fresh.decode(native_z,b['mask'],b['tick_norm'],b['times'])
        hook.remove()
        for key,value in pred.items():torch.testing.assert_close(decoded[key],value,rtol=0,atol=0)
        assert policy_state(fresh)==policy_state(model)
        assert tensor_digest(model)==before and tensor_digest(fresh)==before
        records.append(dict(case=label,policy=policy_state(model),actual_layer_dtypes=dtypes,
            shared_single_Z=True,fresh_checkpoint_Z_only_decode_exact=True,finite_full_model_backward=True,
            original_FP32_inference_exact=True,disabled_training_forward_exact=label=='control',
            gradients=gradients,loss=loss,parameter_objects_and_all3Adam_links_unchanged=True,optimizer_updates=0,
            case_elapsed_seconds=time.monotonic()-case_begin,peak_reserved_GiB=torch.cuda.max_memory_reserved()/2**30))
        del fresh,decoded,native_z,pred,keep
        torch.cuda.empty_cache();atomic_json(root/'progress.json',dict(cases=len(records),total=4,elapsed_seconds=time.monotonic()-begin))
    assert tensor_digest(teacher)==teacher_before and file_hash(source_path)==p['source_sha256']
    result=dict(state='passed',cases=records,source_model_and_teacher_unchanged=True,all_optimizer_updates=0,
        full_student_forwards=11,teacher_feature_extractions=1,fresh_Z_only_decodes=4,development_windows_read=0,
        original_unmodified_model_execution_context_difference=original_mode_difference,
        policy_scope=p.get('policy_scope','layers'),
        actual_raw=p['input_shape'],actual_latent=p['latent_shape'],actual_output=p['output_shape'],elapsed_seconds=time.monotonic()-begin,
        interpretation='Functional and numeric GPU checks only, not evidence of reconstruction improvement or a future source selection.')
    atomic_json(root/'audit.json',result);atomic_json(root/'status.json',dict(state='complete',pid=os.getpid()));print(json.dumps(result),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('root',type=Path);parser.add_argument('--prepare',action='store_true');parser.add_argument('--run',action='store_true');parser.add_argument('--branches',action='store_true');args=parser.parse_args()
    try:
        if args.prepare:prepare(args.root.resolve(),branches=args.branches)
        elif args.run:run(args.root.resolve())
        else:parser.error('Specify --prepare or --run')
    except BaseException as error:
        if args.run:atomic_json(args.root/'status.json',dict(state='failed',pid=os.getpid(),error=repr(error)))
        raise
