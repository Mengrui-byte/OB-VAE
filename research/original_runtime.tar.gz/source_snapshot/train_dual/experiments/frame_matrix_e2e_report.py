"""Live monitoring for complete-model matrix compression training."""

import argparse
from datetime import datetime,timezone
import json
from pathlib import Path
import time

import numpy as np

from train_dual.experiments.book_stem_viewer import build


LABELS={'frozen_long':'冻结编码器·延长训练对照','e2e':'全模型端到端','e2e_fast':'全模型·较大学习率','e2e_smallfit':'全模型·32窗口拟合诊断'}
PAGE='''<!doctype html><html lang=zh-CN><meta charset=utf-8><title>16×1024全模型端到端训练</title><script src=plotly.min.js></script><style>body{font:16px system-ui;max-width:1500px;margin:28px auto;padding:0 20px;color:#182b43}p{line-height:1.8}table{border-collapse:collapse;width:100%}td,th{padding:8px;border:1px solid #ddd}.plots{display:grid;grid-template-columns:1fr 1fr}a{color:#2563eb}</style><h1>16×1024：训练完整模型</h1><p>端到端组更新编码器、Cross、压缩/解压器、价格/数量解码器和幅度修正头。每批从原始订单簿实时编码，未使用冻结latent缓存。以原最佳未压缩模型和共同训练期线性投影初始化；矩阵始终为[B,16,1024]。没有量化、语义头或未来收益。</p><p>主组仍只用同512个训练窗口，64个2025Q1开发窗口。训练到2048步，在128/256/512/1024/2048步报告开发与训练样本指标并保存优化器。冻结源对照仅延长上一轮训练；较大学习率组是优化诊断；32窗口组只检验拟合能力，不能与512数据组视为同预算竞争。开发集已用于研究选型，独立2025Q2未用。</p><p id=status>加载</p><p><a href=./>逐档重建（训练完成前仍是上一轮）</a> · <a href=previous/matrix.html>上一轮冻结源试验</a> · <a href=e2e_plan.json>完整配置</a> · <a href=e2e_progress.json>完整进度</a></p><table><thead><tr><th>GPU</th><th>方案</th><th>状态</th><th>进度</th><th>已用秒</th></tr></thead><tbody id=progress></tbody></table><h2>同64个开发窗口的检查点</h2><table><thead><tr><th>方案</th><th>训练步</th><th>价格RMSE USDT</th><th>数量RMSE BTC</th><th>分钟挂量变化相关</th><th>≥100BTC召回</th></tr></thead><tbody id=results></tbody></table><div class=plots><div id=quantity></div><div id=recall></div><div id=loss></div><div id=seenQuantity></div></div><h2>首步梯度检查</h2><p>下面是裁剪之前各模块梯度范数，用于确认编码器/Cross实际参与了反向传播。梯度非零不等于训练效果已经改善。</p><table><thead><tr><th>方案</th><th>编码器</th><th>Cross</th><th>压缩器</th><th>价格解码</th><th>数量解码</th><th>幅度修正</th></tr></thead><tbody id=gradients></tbody></table><script>const labels={frozen_long:'冻结源长训练',e2e:'全模型端到端',e2e_fast:'全模型较大lr',e2e_smallfit:'32窗口拟合'},f=(x,n=3)=>Number.isFinite(x)?x.toFixed(n):'—';function row(a){let r=document.createElement('tr');for(let x of a){let c=document.createElement('td');c.textContent=x;r.append(c)}return r}function plot(id,a,title){Plotly.react(id,a,{height:360,title,template:'plotly_white',xaxis:{title:'优化步数'}},{responsive:true,displaylogo:false})}async function refresh(){let d=await(await fetch('e2e_progress.json?t='+Date.now())).json();document.getElementById('status').textContent='状态：'+d.status.state;let p=[],r=[],g=[],i=2,traces={quantity:[],recall:[],loss:[],seenQuantity:[]};if(d.source){let m=d.source.metrics;r.push(row(['原未压缩Cross','—',f(m.price_usdt.rmse),f(m.quantity_btc.rmse),f(m.temporal_log_quantity_1_minutes.correlation),f(d.source.thresholds['100'].recall*100,1)+'%']))}for(let [lane,label] of Object.entries(labels)){let x=d.lanes[lane]||{},v=x.progress||{};p.push(row([i++,label,x.status?.state||'等待',v.step?v.step+'/'+v.total:'初始化',f(v.elapsed_seconds,1)]));let history=Object.entries(x.evaluations||{}).sort((a,b)=>Number(a[0])-Number(b[0]));for(let [step,value] of history){let m=value.metrics;r.push(row([label,step,f(m.price_usdt.rmse),f(m.quantity_btc.rmse),f(m.temporal_log_quantity_1_minutes.correlation),f(value.thresholds['100'].recall*100,1)+'%']))}for(let [key,fn] of [['quantity',x=>x.metrics.quantity_btc.rmse],['recall',x=>x.thresholds['100'].recall*100]])traces[key].push({x:history.map(x=>+x[0]),y:history.map(x=>fn(x[1])),name:label,mode:'lines+markers'});let seen=Object.entries(x.seen||{}).sort((a,b)=>+a[0]-+b[0]);traces.seenQuantity.push({x:seen.map(x=>+x[0]),y:seen.map(x=>x[1].metrics.quantity_btc.rmse),name:label,mode:'lines+markers'});let h=(x.history||[]).filter(x=>x.step);traces.loss.push({x:h.map(x=>x.step),y:h.map(x=>x.loss),name:label,mode:'lines'});if(x.gradients)g.push(row([label,...['encoder','fusion','codec','price_decoder','volume_decoder','volume_refinement'].map(k=>f(x.gradients[k]))]))}document.getElementById('progress').replaceChildren(...p);document.getElementById('results').replaceChildren(...r);document.getElementById('gradients').replaceChildren(...g);plot('quantity',traces.quantity,'开发集数量RMSE BTC');plot('recall',traces.recall,'开发集≥100BTC召回%');plot('loss',traces.loss,'训练损失（不同小批次）');plot('seenQuantity',traces.seenQuantity,'见过的训练窗口数量RMSE（32窗口组为诊断）')}refresh().catch(console.error);setInterval(()=>refresh().catch(console.error),10000);</script></html>'''


def final_viewer(root,previous):
    folder=root/'report';folder.mkdir(exist_ok=True)
    plan=json.loads((root/'plan.json').read_text());labels=plan.get('labels',LABELS)
    with np.load(root/'source_profiles.npz') as p:
        arrays={k:p[k] for k in ('truth','mask','time','indices')};arrays['source']=p['prediction']
    config=[dict(key='truth',label='真实订单簿',color='#2563eb'),dict(key='source',label='原未压缩Cross',color='#64748b')]
    for (lane,label),color in zip(labels.items(),['#eab308','#2563eb','#9333ea','#16a34a']):
        with np.load(root/lane/'profiles.npz') as p:
            np.testing.assert_array_equal(p['truth'],arrays['truth']);arrays[lane]=p['prediction']
        config.append(dict(key=lane,label=label+'·2048步',color=color))
    np.savez_compressed(folder/'profiles.npz',**arrays)
    default=2+list(labels).index(plan['default_variant']) if 'default_variant' in plan else 3
    note='16×1024残差压缩；所有组512训练窗口、完整模型训练、固定2048步终点。' if 'labels' in plan else '16×1024完整模型训练；主组512训练窗口；各组固定2048步终点。32窗口组仅拟合诊断。'
    (folder/'comparison.json').write_text(json.dumps(dict(viewer_variants=config,default_model=default,seed=42,common_step=2048,
        step_note=note,comparison_label='全模型训练指标和进度'),ensure_ascii=False))
    (folder/'index.html').write_text('<!doctype html><meta charset=utf-8><meta http-equiv=refresh content="0;url=../e2e.html">')
    viewer=root/'viewer';build(folder,viewer)
    for name in ('e2e.html','e2e_plan.json','e2e_progress.json'):(viewer/name).symlink_to(root/'public'/name)
    (viewer/'matrix.html').symlink_to(root/'public/e2e.html');(viewer/'previous').symlink_to(previous,target_is_directory=True)
    return viewer


def monitor(root,page=None):
    root=root.resolve();public=root/'public';public.mkdir(exist_ok=True)
    selector=root.parents[1]/'.local/dual_viewer/current.json';previous=Path(json.loads(selector.read_text())['directory'])
    (public/'e2e.html').write_text(page or PAGE);(public/'e2e_plan.json').symlink_to(root/'plan.json');(public/'previous').symlink_to(previous,target_is_directory=True)
    # Expose the new monitor from the currently published previous viewer.
    for name in ('e2e.html','e2e_plan.json','e2e_progress.json'):
        link=previous/name
        if link.is_symlink() or not link.exists():
            temp=link.with_suffix(link.suffix+'.tmp');temp.symlink_to(public/name);temp.replace(link)
    plan=json.loads((root/'plan.json').read_text())
    while True:
        status=json.loads((root/'status.json').read_text());lanes={};source=None
        for lane in plan.get('labels',LABELS):
            value=dict(evaluations={},seen={},history=[])
            for key,filename in [('status','status.json'),('progress','progress.json'),('gradients','first_step_gradient_norms.json')]:
                p=root/lane/filename
                if p.exists():value[key]=json.loads(p.read_text())
            for key in ['original','compressed']:
                p=root/lane/(key+'_evaluation.json')
                if p.exists():
                    v=json.loads(p.read_text())['result']
                    if key=='original':source=v
                    else:value['evaluations']['0']=v
            for step in plan['checkpoints']:
                for key,suffix in [('evaluations','_evaluation.json'),('seen','_seen_evaluation.json')]:
                    p=root/lane/(f'step{step}'+suffix)
                    if p.exists():value[key][str(step)]=json.loads(p.read_text())['result']
            p=root/lane/'progress.jsonl'
            if p.exists():
                for line in p.read_text().splitlines():
                    try:value['history'].append(json.loads(line))
                    except ValueError:pass
            lanes[lane]=value
        value=dict(utc=datetime.now(timezone.utc).isoformat(),status=status,lanes=lanes,source=source)
        p=public/'e2e_progress.json';tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(value));tmp.replace(p)
        if status['state']=='complete':
            viewer=final_viewer(root,previous);tmp=selector.with_suffix('.tmp');tmp.write_text(json.dumps(dict(directory=str(viewer))));tmp.replace(selector)
            (root/'published.json').write_text(json.dumps(dict(directory=str(viewer))));break
        if status['state']=='failed':break
        time.sleep(10)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);monitor(p.parse_args().root)
