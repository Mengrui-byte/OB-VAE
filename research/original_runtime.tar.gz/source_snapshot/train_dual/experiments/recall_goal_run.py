"""Persistent goal ledger and a queued mid-protection x balanced-tail cohort."""
import argparse
from datetime import datetime
import html
import json
import math
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

import numpy as np
import torch

from model.losses.recall_guard import RecallGuardBookLoss
from train_dual.experiments import local_hint_run as shared
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.goal_evaluate import assess_file
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read,fmt,STYLE
from train_dual.experiments.region_task_run import gpu_free
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import atomic_save,freeze_sources,load_for_inference
from train_dual.util.phase_training import tensor_digest


LABELS={'baseline':'原目标继续训练','mid':'显式中间价保护','tail':'大单＋误报平衡','both':'中间价保护＋大单平衡'}


def live_children(status,expected_root=None):
    result={}
    for child in status.get('children',[]):
        pid=child['pid']
        try:
            os.kill(pid,0)
            command=Path(f'/proc/{pid}/cmdline').read_bytes().replace(b'\0',b' ').decode()
            result[str(pid)]=dict(alive='train_dual.experiments.' in command and (expected_root is None or str(expected_root) in command),command=command)
        except (ProcessLookupError,FileNotFoundError):result[str(pid)]=dict(alive=False)
    return result


def candidates(parent,reference):
    rows=[]
    for lane in read(parent/'plan.json')['labels']:
        for f in sorted((parent/lane).glob('step*_development.json'),key=lambda p:int(p.name.split('_')[0][4:])):
            step=int(f.name.split('_')[0][4:]);checkpoint=parent/lane/f'step{step}.pt'
            if not checkpoint.exists():continue
            rows.append(dict(lane=lane,step=step,checkpoint=str(checkpoint),evaluation=str(f),**assess_file(f,reference)))
    return rows


def render(goal):
    contract=read(goal/'contract.json');status=read(goal/'status.json',{})
    rows=read(goal/'candidates.json',{}).get('rows',[])
    parts=[f'<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta http-equiv="refresh" content="30"><title>大单召回80%持续实验</title><style>{STYLE}</style><main>',
        '<h1>持续目标：大单召回超过80%，保护价格恢复</h1>',
        f'<div class="note">状态：{html.escape(status.get("state","prepared"))}。完整256分钟、双侧各2048档、唯一64×128Gaussian；价格不允许跨瓶颈的输入旁路。</div>',
        f'<p>锁定共同起点：价格RMSE≤{fmt(contract["price_rmse_limit"])}USDT，一分钟中间价变化RMSE≤{fmt(contract["mid_delta_rmse_limit"])}；同帧/侧/档≥100BTC召回严格&gt;80%。额外质量筛选：精确率≥50%，数量RMSE≤共同起点1.10倍，防止大量误报抬高召回。开发集反复使用，不作为最终独立测试。</p>',
        '<p>完成声明还需冻结候选、核对实际8192结构及单Z解码，并在预留数据上确认；下表pass仅是开发筛选，不代表目标已完成。GPU只用远端2–5，现有训练与其只读响应评估正常完成后再接续新四组，每组最多12小时。</p>',
        '<div class="wrap"><table><tr><th>实验</th><th>组</th><th>追加步数</th><th>100BTC召回</th><th>精确率</th><th>价格RMSE</th><th>分钟mid变化RMSE</th><th>挂量RMSE</th><th>开发筛选通过</th></tr>']
    for row in rows:
        vals=[row.get('experiment',''),row['lane'],str(row['step']),fmt(row['recall100']),fmt(row['precision100']),fmt(row['price_rmse']),fmt(row['mid_delta_rmse']),fmt(row['quantity_rmse']),str(row['pass'])]
        parts.append('<tr>'+''.join(f'<td>{html.escape(str(v))}</td>' for v in vals)+'</tr>')
    parts.append('</table></div>')
    if (goal/'small_order_reconstruction_proposal_v2.json').exists():
        parts.append('<div class="note">用户追加要求：小、中、大挂单必须分层恢复。上表旧开发筛选pass不能代表整本订单簿成功；独立确认前仍须审查六数量区间的误差、幅度及同档位数量精度。</div><p><a href="quantity_strata_audit_20261028_1333/">大小挂单分层诊断</a> · <a href="quantity_strata_preparation_v2/">分桶损失准备</a> · <a href="round_005_regional_phase/reconstruction_view2048_v2/">订单簿交互图</a></p>')
    try:
        plot_progress(goal,rows)
        parts.append('<p><a href="progress.png"><img src="progress.png" style="max-width:100%" alt="Recall convergence and fixed80% target"></a></p>')
    except Exception as error:
        atomic_json(goal/'plot_status.json',dict(state='failed_retry_pending',error=repr(error)))
    for child in sorted(goal.glob('round_*/plan.json')):
        title=read(child,{}).get('experiment','模型控制实验')
        parts.append(f'<p><a href="{child.parent.name}/">{child.parent.name}：{html.escape(title)}</a></p>')
    parts.append('<p><a href="research.md">研究目标与约束</a> · <a href="contract.json">固定验收口径</a> · <a href="candidates.json">逐检查点评估</a> · <a href="research_log.jsonl">迭代记录</a> · <a href="../">全部实验</a></p></main></html>')
    temp=goal/'report.tmp';temp.write_text(''.join(parts));temp.replace(goal/'index.html')


def plot_progress(goal,rows):
    import hashlib,importlib.util
    signature=hashlib.sha256(json.dumps(rows,sort_keys=True).encode()).hexdigest()
    old=read(goal/'plot_status.json',{})
    if old.get('signature')==signature and (goal/'progress.png').exists():return
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    spec=importlib.util.spec_from_file_location('recall_goal_style',goal/'style_presets.py');style=importlib.util.module_from_spec(spec);spec.loader.exec_module(style);style.rcparams()
    fig,ax=plt.subplots(figsize=(8,4.8));groups={}
    for row in rows:groups.setdefault((row.get('experiment',''),row['lane']),[]).append(row)
    for (experiment,lane),items in groups.items():
        items=sorted(items,key=lambda r:r['step']);x=[r['step'] for r in items];y=[100*(r['recall100'] or 0.) for r in items]
        ax.plot(x,y,marker='o',label=experiment[-12:]+'/'+lane)
    ax.axhline(80,color='black',linestyle='--',linewidth=1,label='Required: >80%')
    ax.set(xlabel='Additional updates within cohort',ylabel='Development recall (%)',ylim=(-2,102))
    if groups:ax.legend(fontsize=7,ncol=2)
    fig.tight_layout();tmp=goal/'progress.png.tmp';fig.savefig(tmp,format='png');plt.close(fig);tmp.replace(goal/'progress.png')
    atomic_json(goal/'plot_status.json',dict(state='complete',signature=signature))


def record(goal,kind,**kwargs):
    row=dict(utc=datetime.utcnow().isoformat(),kind=kind,**kwargs)
    with (goal/'research_log.jsonl').open('a') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n')
    path=goal/'autoresearch-results.tsv'
    if not path.exists():path.write_text('timestamp\titeration\texperiment\tmetric\tscore\tstatus\treason\tartifact\n')
    with path.open('a') as f:f.write('\t'.join(str(v).replace('\t',' ').replace('\n',' ') for v in [row['utc'],len(list(goal.glob('round_*'))),kwargs.get('wave','parent'),'recall100',kwargs.get('candidate',{}).get('recall100',''),kind,kwargs.get('hypothesis',kwargs.get('next','')),kwargs.get('wave','research_log.jsonl')])+'\n')


def prepare(parent):
    parent=parent.resolve();project=Path(__file__).resolve().parents[2]
    goal=project/'recons'/('recall80_goal_'+datetime.now().strftime('%Y%m%d_%H%M%S'));goal.mkdir();(goal/'logs').mkdir()
    shutil.copy2('/home/mengrui/.agents/skills/autoresearch-skill/scripts/style_presets.py',goal/'style_presets.py')
    reference=project/'recons/time_logit_20261027_124432/frame_huber/step4096_evaluation.json'
    os.link(reference,goal/'reference_evaluation.json')
    os.link(project/'recons/time_logit_20261027_124432/frame_huber/step4096.pt',goal/'reference_model.pt')
    result=read(reference)['result'];m=result['metrics']
    atomic_json(goal/'contract.json',dict(objective='接下来不断迭代模型/训练算法/损失函数，直到大单召回率超过80%，并且价格恢复不能明显落后当前的模型',
        reference_checkpoint='recons/time_logit_20261027_124432/frame_huber/step4096.pt',reference_price_rmse=m['price_usdt']['rmse'],price_rmse_limit=m['price_usdt']['rmse']*1.10,
        reference_mid_delta_rmse=m['temporal_mid_1_minutes_usdt_per_minute']['rmse'],mid_delta_rmse_limit=m['temporal_mid_1_minutes_usdt_per_minute']['rmse']*1.10,
        recall_threshold_strictly_greater_than=.80,quantity_threshold_btc=100.,min_precision_quality_guard=.50,quantity_rmse_limit=m['quantity_btc']['rmse']*1.10,
        evaluation='same16reused2025Q1developmentwindows, same raw fixed100BTCthreshold/same-frame-side-rank. Trainingfitdoesnotcount. Frozenmodel mustthenpassindependentconfirmation; nofuture-returnslabels.',
        architecture=dict(raw=[1,256,2,2048,2],posterior=[1,64,128],single_z=True,encoder_bypass=False),
        keep_policy='pass_only forcompletion; inferiorcandidates retainedasresearchrecords, neveroverwritebesthistoricalcheckpoint.',
        pause_every='never,userexplicitcontinuousgoal',per_cohort_training_seconds=43200,seed=42,confirmation_status='not_started',predecessor=parent.name))
    (goal/'research.md').write_text(f'''# Goal\n持续迭代，训练外同位≥100BTC召回严格超过80%，同时价格恢复不明显落后固定当前模型。\n\n# Success Metric\n固定16个2025Q1开发窗，召回>0.80；绝对价格RMSE≤{m['price_usdt']['rmse']*1.1:.10f}USDT，一分钟mid变化RMSE≤{m['temporal_mid_1_minutes_usdt_per_minute']['rmse']*1.1:.10f}。额外质量筛选精确率≥0.50，挂量RMSE≤共同起点1.10倍。训练拟合不计。达到开发门槛后冻结模型，另做独立确认与结构审计，未确认前不宣称完成。\n\n# Constraints\nEvaluator: python -m train_dual.experiments.goal_evaluate RESULT --reference {goal.name}/reference_evaluation.json\nKeep policy: pass_only\npause_every: never（用户已授权持续后台迭代，无需再次询问）\nmax_iterations: unbounded_until_user_goal_or_manual_stop\nnoise_runs: 1（用户指定seed42，不做多种子）\nper_cohort_timeout: 12hours（用户长实验授权覆盖技能默认5分钟）\n无Git仓库，不执行git回滚；历史权重、配置、快照不改写。所有新模型在model/，配置结果在recons/。完整256分钟、每侧2048档、唯一8192Gaussian，禁止Encoder旁路。只用远端GPU2–5，不中断别人作业。2025Q2/2026留作最终冻结确认，不参与本轮训练或校准。\n\n# Current Approach\n上一轮Local蒸馏＋增强在追加4096步开发召回52.9%、精确率29.9%、价格RMSE83.35；分钟mid变化RMSE40.77，仍未通过价格保护。等待既定8192步完成。新四组检验显式mid水平/变化监督与稀疏大单/误报平衡监督，所有组保留原shape_mass与Local提示、增强、相同权重/Adam/RNG/数据和预算。\n\n# Search Space\n优先损失与梯度组织、中间价保护、真实大单定位/幅度监督；其次瓶颈后的空间表示/Decoder及训练日程。两三次有效负结果后换假设，不重复冻结旧Z后读出头试验。每组都必须有匹配控制。后续假设依据实际结果，不自动降低目标。\n\n# Context & References\n{parent.name}；固定当前模型time_logit/frame_huber/step4096；旧1064960维教师不具备本目标8192容量，不能冒充达标模型。\n\n# History\n初始目标turn：核对真实远端PID存活；新增4096检查点的52.9%召回改变下一步方向，属于progress。按本research.md持续记录，目标保持active。\n''')
    atomic_json(goal/'status.json',dict(state='prepared',parent=parent.name))
    record(goal,'goal_initialized',previous_turn_classification='progress',evidence='Actual4096developmentrecall52.9% plusmidRMSE40.77 changednextlossdesign; verified remotePIDs4601–4604 live.')
    freeze_sources(goal/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/goal.relative_to(project)
    (goal/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.recall_goal_run "{remote}"\n')
    render(goal);Path('/tmp/recall80_goal_path').write_text(str(goal));print(goal,flush=True)


def prepare_wave(goal,parent,source_row):
    wave=goal/'round_001_mid_tail';wave.mkdir()
    for name in ['data','logs','seen','unseen',*LABELS]:(wave/name).mkdir()
    for split in ['seen','unseen']:
        for lane in LABELS:(wave/split/lane).mkdir()
    for name in ['train_indices.npy','val_indices.npy','seen_indices.npy','unseen_indices.npy','calibration_indices.npy','plotly.min.js','teacher.pt']:
        os.link(parent/name,wave/name)
    os.link(parent/'data/BTCUSDT.npz',wave/'data/BTCUSDT.npz')
    source=Path(source_row['checkpoint']);os.link(source,wave/'source.pt')
    payload=torch.load(source,map_location='cpu',weights_only=False);assert payload['epoch_boundary']
    atomic_save(dict(format_version=1,model=payload['model'],unified_vae_config=payload['unified_vae_config'],local_hint_config=payload['local_hint_config'],config=payload['config'],step=0),wave/'initial.pt')
    old=read(parent/'plan.json');plan=dict(old)
    plan.update(experiment='Explicitmidprotection x balancedlargequantity/falsepositiveloss2x2',labels=LABELS,
        lanes={lane:dict(hint=True,augmentation=True,protect_mid=lane in ['mid','both'],use_tail=lane in ['tail','both']) for lane in LABELS},
        steps=4096,checkpoints=[512,1024,2048,4096],max_seconds=43200,
        source=str(source),source_steps=payload.get('source_steps',0)+payload['step'],initial_model_sha256=None,
        gpu_workers=[[g,l] for g,l in zip([2,3,4,5],LABELS)],loss_variant='recall_guard',goal_root=str(goal),
        additional_controls='All4useexistingLocalhint+sameaugmentation. Onlytwofactors: explicitmidlevel+1minchangeMSE, positive>=100Huber+activefalsepositiveHuber. Both extraweights fixedbytraining-onlymu-gradientRMSratio1.0. OriginalpriceHuber/Top16/logq/shape/massandhintcoefficients unchanged. RestorebothAdamgroups andallstoredRNGs. No newmodelparameters.',
        predeclared_selection='Parent source=maxrecall amonghint/both atcommonlargestdeclaredendpoint,tiepreferlowerprice. Source maynotpassgoalpriceguard; no baseline reset orloosercompletionthreshold. Goalcontractalwaysusesoriginal74.704price/20.0369middelta.',
        preview_descriptions={lane:'固定16个2025Q1开发窗口，已反复用于研究。完整256分钟，唯一8192latent。新价格/大单损失匹配对照，非最终独立测试。' for lane in LABELS})
    model,_=load_for_inference(wave/'initial.pt','cpu');plan['initial_model_sha256']=tensor_digest(model)
    atomic_json(wave/'plan.json',plan);cal=dict(read(parent/'calibration.json'),tail_weight=1.,mid_weight=1.,new_weights_state='pending_training_gradient_calibration')
    atomic_json(wave/'calibration.json',cal)
    shutil.copy2(parent/'data_contract.json',wave/'data_contract.json')
    for split in ['seen','unseen']:
        atomic_json(wave/split/'plan.json',dict(plan,preview_descriptions={lane:'真实训练诊断；seen参与学生训练，unseen排除学生训练索引但教师可能见过；不是独立测试。' for lane in LABELS}))
        os.link(wave/'plotly.min.js',wave/split/'plotly.min.js')
    (wave/'design.md').write_text('完整目标与固定门槛见../research.md及contract.json。\n本轮两个因素：保留原损失，额外添加显式mid水平/一分钟变化MSE，或按真实>=100BTC与预测>=100但真实<100的活跃误报分别均值Huber。两项权重仅在训练8窗用μ头梯度RMS与原目标1:1校准后固定。四组无/有×无/有，全部保留Local蒸馏和相同增强。source/Adam/RNG相同，完整256分钟、唯一8192，不使用真实价格作为数量条件。\n每组4096追加更新，固定512/1024/2048/4096检查点，最多12小时；不把未达到固定步数的结果冒充完成。\n')
    atomic_json(wave/'status.json',dict(state='prepared',source=source_row))
    freeze_sources(wave/'source_snapshot')
    record(goal,'wave_prepared',wave=wave.name,source=source_row,hypothesis='Positive/FP balancing increasesusefullargeorderrecall whiledirectmidMSE restorespricepath; equal-budget2x2 controls separateeffects.')
    return wave


def wave_criterion(root,lane):
    plan=read(root/'plan.json');cal=read(root/'calibration.json');spec=plan['lanes'][lane]
    return RecallGuardBookLoss(plan['normalization']['quantity_scale'],mode='shape_mass',use_hint=True,hint_weight=cal['hint_weight'],hint_mean=cal['channel_mean'],hint_scale=cal['channel_scale'],use_tail=spec['use_tail'],protect_mid=spec['protect_mid'],tail_weight=cal['tail_weight'],mid_weight=cal['mid_weight'],large_threshold=100.,add_wasserstein=False,add_multiscale=False,**plan['objective']).to('cuda:0')


def calibrate_wave(root):
    torch.set_num_threads(4);strict_precision();plan=read(root/'plan.json')
    model,norm=load_for_inference(root/'initial.pt','cuda:0');model.train()
    teacher,tn=load_for_inference(root/'teacher.pt','cuda:0');teacher.eval().requires_grad_(False)
    objective=wave_criterion(root,'both');parameters=list(model.encoder.mu.parameters());squares={name:[] for name in ['pre_guard_loss','tail_balanced','mid_protection']}
    data=dataset(root,'train')
    for index in np.load(root/'calibration_indices.npy'):
        raw={k:v.unsqueeze(0) for k,v in data[int(index)].items()};target=shared.teacher_local(teacher,tn,raw);b=norm.prepare(raw,'cuda:0')
        with torch.autocast('cuda',dtype=torch.bfloat16):out=call(model,b,False)
        values=objective(out,b,teacher_local=target)
        for key in squares:
            gradient=torch.autograd.grad(values[key],parameters,retain_graph=key!='mid_protection')
            squares[key].append(sum(float(g.float().square().sum()) for g in gradient))
    rms={key:math.sqrt(float(np.mean(values))) for key,values in squares.items()}
    if any(not math.isfinite(x) or x<=0 for x in rms.values()):raise RuntimeError(f'Invalidtraininggradientcalibration:{rms}')
    cal=read(root/'calibration.json');cal.update(tail_weight=rms['pre_guard_loss']/rms['tail_balanced'],mid_weight=rms['pre_guard_loss']/rms['mid_protection'],new_weights_state='locked',new_gradient_rms=rms,new_weight_scope='8preselectedtrainwindows only; nooptimizerupdate; equalinitialmuheadgradientRMS1.0; notdevelopment-selected.')
    atomic_json(root/'calibration.json',cal)


def render_wave(root):
    # Same metrics/layout machinery; this dedicated note identifies the new factors.
    from train_dual.experiments.local_hint_report import render as base
    base(root)
    p=root/'index.html';s=p.read_text()
    s=s.replace('Local中间表示蒸馏 × 在线挂量增强','中间价保护 × 大单/误报平衡')
    s=s.replace('四组从逐帧Huber第4096步的相同权重、原Adam及保存的随机状态继续，数据为相同1024个2022–2024训练窗。追加8192步（32个等效epoch），单seed42，每组训练最多12小时。','四组从上一轮同一个有效检查点、相同Adam及RNG继续；全部保留Local提示和相同增强。两个因素为显式mid水平/变化监督、真实大单/活跃误报平衡监督。相同1024窗，追加4096步，单seed42，每组最多12小时。')
    p.write_text(s)


def wave_startup(root):
    plan=read(root/'plan.json');rows={}
    for lane in LABELS:
        shape=read(root/lane/'actual_shape_contract.json');data=read(root/lane/'step1_data_audit.json');grad=read(root/lane/'step8_gradient_audit.json')
        if not all([shape,data,grad]):return False
        rows[lane]=dict(shape=shape,data=data,gradient=grad)
    control=rows['baseline']['data']
    for row in rows.values():
        assert row['data']['training_indices']==control['training_indices'] and row['data']['edits']==control['edits']
        assert row['data']['losses']['pre_guard_loss']==control['losses']['pre_guard_loss']
    atomic_json(root/'startup_control_audit.json',dict(passed=True,same_inputs_edits_initialweights_original_loss=True,rows=rows));return True


def run_wave(root):
    plan=read(root/'plan.json');children=[]
    def launch(lane=None,setup=False):
        gpu=2 if setup else dict((l,g) for g,l in plan['gpu_workers'])[lane]
        args=['--calibrate'] if setup else ['--wave-lane',lane]
        env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),CUDA_DEVICE_ORDER='PCI_BUS_ID',PYTHONPATH=str(root/'source_snapshot'))
        with (root/'logs'/('setup.log' if setup else lane+'.log')).open('ab',buffering=0) as log:
            p=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.recall_goal_run',str(root),*args],cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        children.append((lane or 'setup',gpu,p));return p
    def refresh():
        try:render_wave(root)
        except Exception as error:atomic_json(root/'report_status.json',dict(state='failed_retry_pending',error=repr(error)))
    try:
        if any(gpu_free().get(g,0)<47000 for g in [2,3,4,5]):raise RuntimeError('Need idle GPUs2–5')
        setup=launch(setup=True);started=time.monotonic();atomic_json(root/'status.json',dict(state='gpu_calibration',pid=setup.pid))
        while setup.poll() is None:
            if time.monotonic()-started>1800:raise TimeoutError('30minute calibration ceiling')
            refresh();time.sleep(10)
        if setup.returncode:raise RuntimeError('Wavecalibrationfailed')
        children=[];started=time.monotonic()
        for lane in LABELS:launch(lane=lane)
        atomic_json(root/'status.json',dict(state='running',children=[dict(role=l,gpu=g,pid=p.pid) for l,g,p in children]));audited=False
        while any(p.poll() is None for l,g,p in children):
            if time.monotonic()-started>plan['max_seconds']+900:raise TimeoutError('12hour+evaluation ceiling')
            if any(p.poll() not in [None,0] for l,g,p in children):raise RuntimeError('Owned wave worker failed')
            if not audited:audited=wave_startup(root)
            refresh();time.sleep(10)
        if any(p.returncode for l,g,p in children):raise RuntimeError('Waveworkerfailed')
        atomic_json(root/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started))
    except BaseException as error:
        atomic_json(root/'status.json',dict(state='failed',error=repr(error)));raise
    finally:
        for l,g,p in children:
            if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)
        refresh()


def controller(goal):
    contract=read(goal/'contract.json');parent=goal.parent/contract['predecessor'];reference=goal/'reference_evaluation.json';start=time.monotonic()
    while True:
        state=read(parent/'status.json',{});live=live_children(state,parent);rows=candidates(parent,reference)
        for row in rows:row['experiment']=parent.name
        atomic_json(goal/'candidates.json',dict(rows=rows))
        if state.get('state')=='failed':
            atomic_json(goal/'status.json',dict(state='predecessor_failed_requires_investigation',parent=state));record(goal,'parent_failed',state=state);render(goal);return
        if state.get('state')=='complete':break
        if state.get('state')=='running' and live and not any(p['alive'] for p in live.values()):
            child_states=[read(parent/child['role']/'status.json',{}) for child in state.get('children',[])]
            if child_states and all(s.get('state') in ['complete','budget_complete'] for s in child_states):
                time.sleep(10);continue
            atomic_json(goal/'status.json',dict(state='predecessor_processes_missing_requires_investigation',live_processes=live))
            record(goal,'actual_process_handles_missing',live_processes=live);render(goal);return
        if time.monotonic()-start>13*3600:raise TimeoutError('Parent wait13hours ceiling')
        atomic_json(goal/'status.json',dict(state='verified_wait_parent_training',parent=parent.name,live_processes=live,latest_development_recall=max((r['recall100'] or 0 for r in rows),default=0.)))
        render(goal);time.sleep(30)
    passing=[r for r in rows if r['pass']]
    if passing:
        selected=max(passing,key=lambda r:(r['recall100'],-r['price_rmse']))
        atomic_json(goal/'candidate_for_confirmation.json',selected)
        atomic_json(goal/'status.json',dict(state='development_pass_requires_independent_confirmation',candidate=selected))
        record(goal,'development_pass_not_goal_complete',candidate=selected);render(goal);return
    common=max({r['step'] for r in rows if r['lane']=='hint'}&{r['step'] for r in rows if r['lane']=='both'})
    eligible=[r for r in rows if r['lane'] in ['hint','both'] and r['step']==common]
    selected=max(eligible,key=lambda r:(r['recall100'],-r['price_rmse']))
    response=parent/'response_after/status.json';waiting=time.monotonic()
    while True:
        state=read(response,{})
        if state.get('state') in ['complete','failed','not_run_parent_failed'] and all(gpu_free().get(g,0)>=47000 for g in [2,3,4,5]):break
        if time.monotonic()-waiting>3600:raise TimeoutError('Wait for owned response evaluation/idle GPUs1hour ceiling')
        atomic_json(goal/'status.json',dict(state='waiting_owned_response_evaluation',response=state));render(goal);time.sleep(20)
    wave=prepare_wave(goal,parent,selected)
    atomic_json(goal/'status.json',dict(state='running_next_controlled_cohort',wave=wave.name));render(goal)
    run_wave(wave)
    next_rows=candidates(wave,reference)
    for row in next_rows:row['experiment']=wave.name
    rows.extend(next_rows);atomic_json(goal/'candidates.json',dict(rows=rows))
    passing=[r for r in next_rows if r['pass']]
    if passing:
        selected=max(passing,key=lambda r:(r['recall100'],-r['price_rmse']));atomic_json(goal/'candidate_for_confirmation.json',selected)
        atomic_json(goal/'status.json',dict(state='development_pass_requires_independent_confirmation',candidate=selected));record(goal,'development_pass_not_goal_complete',candidate=selected)
    else:
        atomic_json(goal/'status.json',dict(state='cohort_complete_next_hypothesis_required',wave=wave.name,goal_achieved=False));record(goal,'cohort_negative_or_incomplete',wave=wave.name,next='Inspectfullendpointandretainedcontrols; choose nextmodel/optimizerhypothesis. Goalremainsactive.')
    render(goal)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--calibrate',action='store_true');p.add_argument('--wave-lane',choices=list(LABELS));args=p.parse_args();root=args.root.resolve()
    if not args.prepare and not args.calibrate and not args.wave_lane:
        def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
        signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        if args.prepare:prepare(root)
        elif args.calibrate:calibrate_wave(root)
        elif args.wave_lane:shared.worker(root,args.wave_lane,objective_factory=wave_criterion)
        else:controller(root)
    except BaseException as error:
        if args.wave_lane:atomic_json(root/args.wave_lane/'status.json',dict(state='failed',error=repr(error)))
        elif not args.prepare:atomic_json(root/'status.json',dict(state='controller_failed',error=repr(error)))
        raise
