"""Publish actual reconstructed books from a common saved intermediate step."""

import argparse
from datetime import datetime
import json
from pathlib import Path

import numpy as np
import torch

from train_dual.experiments.book_stem_viewer import build
from train_dual.experiments.long_worker import datasets
from train_dual.experiments.window_state_pilot import load_base
from train_dual.util.checkpoint import load_for_inference,freeze_sources


LABELS={'frozen_long':'冻结编码器对照','e2e':'完整模型端到端','e2e_fast':'端到端·较大学习率'}
PAGE='''<!doctype html><html lang=zh-CN><meta charset=utf-8><title>16×1024压缩后的实际恢复</title><script src=plotly.min.js></script><style>body{font:17px system-ui;max-width:1450px;margin:28px auto;line-height:1.8}table{border-collapse:collapse;width:100%}td,th{padding:9px;border:1px solid #ddd}select{font:inherit;padding:6px}a{color:#2563eb}</style><h1>16×1024压缩：256步检查点的实际恢复</h1><p>同512个训练窗口、同64个2025Q1开发窗口。此页固定展示已保存且可恢复的256步中间模型，不是2048步终点。完整模型组编码器、Cross、压缩/解压器和生成器均训练；输入仍只压缩为连续矩阵，没有量化、语义头或未来收益。独立2025Q2未使用。</p><p><a href=./>逐档挂单线图</a> · <a href=e2e.html>恢复后的训练实时进度</a> · <a href=compression_data.json>完整数据</a></p><table><thead><tr><th>方案</th><th>价格RMSE USDT</th><th>挂量RMSE BTC</th><th>分钟挂量变化相关</th><th>≥100BTC召回</th><th>≥100BTC精确率</th></tr></thead><tbody id=metrics></tbody></table><p>以下矩阵来自所选检查点对开发窗口的实际编码。每个矩阵为16×1024，并已验证只用矩阵和原模型已有元数据就能重放对应重建输出。</p><p>模型 <select id=model></select> 窗口 <select id=sample><option value=0>窗口1</option><option value=1>窗口2</option><option value=2>窗口3</option></select></p><div id=matrix></div><script>let d;const $=x=>document.getElementById(x),f=(x,n=3)=>Number.isFinite(x)?x.toFixed(n):'—';function draw(){let k=$('model').value,s=+$('sample').value;Plotly.react('matrix',[{z:d.models[k].matrices[s],type:'heatmap',colorscale:'RdBu',zmid:0}],{height:430,title:d.models[k].label+' · 16×1024',xaxis:{title:'学习通道'},yaxis:{title:'窗口内时间位置'},template:'plotly_white'},{responsive:true,displaylogo:false})}fetch('compression_data.json').then(x=>x.json()).then(x=>{d=x;let all=[{label:'原未压缩Cross',metrics:d.reference},...Object.values(d.models)];$('metrics').replaceChildren(...all.map(x=>{let m=x.metrics.metrics,t=x.metrics.thresholds['100'],r=document.createElement('tr');for(let v of [x.label,f(m.price_usdt.rmse),f(m.quantity_btc.rmse),f(m.temporal_log_quantity_1_minutes.correlation),f(t.recall*100,1)+'%',f(t.precision*100,1)+'%']){let c=document.createElement('td');c.textContent=v;r.append(c)}return r}));$('model').replaceChildren(...Object.entries(d.models).map(([k,v])=>new Option(v.label,k)));$('model').value='e2e';draw()});$('model').onchange=draw;$('sample').onchange=draw;</script></html>'''


def main(root,step=256):
    root=root.resolve();torch.set_num_threads(4);plan=json.loads((root/'plan.json').read_text())
    labels=plan.get('labels',LABELS);default=plan.get('default_variant','e2e')
    folder=root/'previews'/('checkpoint'+str(step)+'_'+datetime.now().strftime('%Y%m%d_%H%M%S'));folder.mkdir(parents=True)
    source,norm=load_base(root);data=datasets(root,source,'val');models={}
    with np.load(root/'source_profiles.npz') as p:
        arrays={k:p[k] for k in ('truth','mask','time','indices')};arrays['source']=p['prediction']
    config=[dict(key='truth',label='真实订单簿',color='#2563eb'),dict(key='source',label='原未压缩Cross',color='#64748b')]
    for (lane,label),color in zip(labels.items(),['#eab308','#2563eb','#9333ea','#16a34a']):
        checkpoint=root/lane/f'step{step}.pt';model,_=load_for_inference(checkpoint,'cpu');predictions=[];matrices=[]
        with torch.inference_mode():
            for index in plan['example_indices']:
                raw={k:v.unsqueeze(0) for k,v in data[index].items()};b=norm.prepare(raw,'cpu')
                out=model(b['price'],b['volume'],b['mask'],b['tick_norm'],times=b['times'],sample=False)
                replay=model.decode_matrix(out['matrix_latent'],b['mask'],b['tick_norm'],b['times'])
                torch.testing.assert_close(out['volume'],replay['volume'],rtol=0,atol=0)
                torch.testing.assert_close(out['price_norm'],replay['price_norm'],rtol=0,atol=0)
                np.testing.assert_array_equal(raw['data'][0].numpy(),arrays['truth'][len(predictions)])
                predictions.append(np.stack([norm.inverse_price(out['price_norm'],b)[0].numpy(),out['volume'][0].numpy()],-1))
                matrices.append(out['matrix_latent'][0].numpy())
        arrays[lane]=np.stack(predictions);config.append(dict(key=lane,label=label+f'·{step}步',color=color))
        metrics=json.loads((root/lane/f'step{step}_evaluation.json').read_text())['result']
        models[lane]=dict(label=label,metrics=metrics,matrices=np.stack(matrices).tolist(),checkpoint=str(checkpoint),matrix_only_decode_exact=True)
        np.savez_compressed(folder/(lane+'_matrices.npz'),matrix=np.stack(matrices))
        del model
    reference=json.loads((root/default/'original_evaluation.json').read_text())['result']
    (folder/'compression_data.json').write_text(json.dumps(dict(step=step,reference=reference,models=models,
        metrics_precision='Original stored GPU FP32 evaluation',illustration_precision='CPU FP32 checkpoint replay',final_training_complete=False),ensure_ascii=False))
    np.savez_compressed(folder/'profiles.npz',**arrays)
    (folder/'comparison.json').write_text(json.dumps(dict(viewer_variants=config,default_model=2+list(labels).index(default),seed=42,common_step=step,
        step_note=f'实际保存的{step}步检查点；16×1024完整模型压缩；2048步训练尚在继续。',comparison_label='压缩指标和16×1024矩阵'),ensure_ascii=False))
    page=PAGE.replace('256步',f'{step}步').replace("$('model').value='e2e'",f"$('model').value={json.dumps(default)}")
    if 'labels' in plan:page=page.replace('16×1024压缩：','16×1024残差压缩：').replace('完整模型组编码器','所有组编码器')
    (folder/'compression.html').write_text(page)
    (folder/'index.html').write_text('<!doctype html><meta charset=utf-8><meta http-equiv=refresh content="0;url=../compression.html">')
    viewer=folder/'viewer';build(folder,viewer)
    for name in ('compression.html','compression_data.json'):(viewer/name).symlink_to(folder/name)
    for name in ('e2e.html','e2e_plan.json','e2e_progress.json'):(viewer/name).symlink_to(root/'public'/name)
    (viewer/'matrix.html').symlink_to(folder/'compression.html')
    selector=root.parents[1]/'.local/dual_viewer/current.json';previous=Path(json.loads(selector.read_text())['directory'])
    (viewer/'previous').symlink_to(previous,target_is_directory=True)
    temp=selector.with_suffix('.tmp');temp.write_text(json.dumps(dict(directory=str(viewer))));temp.replace(selector)
    freeze_sources(folder/'source_snapshot')
    (root/'preview_published.json').write_text(json.dumps(dict(step=step,directory=str(viewer))));print(viewer,flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--step',type=int,default=256);a=p.parse_args();main(a.root,a.step)
