"""No optimizer updates: repeat actual cached head gradients under CUDA kernels."""
import argparse
import os
from pathlib import Path

import numpy as np
import torch

from model.layers.paired_logit import PairedQuantityLogitReadout
from train_dual.experiments.local_peak_quantity_run import criterion
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.paired_logit_run import predict
from train_dual.experiments.phase_detail_report import read
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import freeze_sources


def prepare(goal):
    root=goal/'paired_gradient_repro_probe';root.mkdir();(root/'logs').mkdir()
    source=goal/'paired_logit_readout'
    for name in ['train_cache.pt','train_order.npy','calibration.json']:os.link(source/name,root/name)
    plan=dict(read(source/'plan.json'));atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot')
    project=Path(__file__).resolve().parents[2];remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export CUDA_VISIBLE_DEVICES=2 PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.paired_gradient_repro_probe "{remote}" --worker >> "{remote}/logs/run.log" 2>&1\n');print(root,flush=True)


def worker(root):
    torch.set_num_threads(4);strict_precision();atomic_json(root/'status.json',dict(state='running',pid=os.getpid()));plan=read(root/'plan.json')
    cached=torch.load(root/'train_cache.pt',map_location='cpu',weights_only=False,mmap=True);order=np.load(root/'train_order.npy');cache=[{outer:{k:v.cuda() for k,v in values.items()} for outer,values in cached[int(pos)].items()} for pos in order[:2]]
    old=torch.load(root.parent/'paired_logit_readout/phase/step512.pt',map_location='cpu',weights_only=False,mmap=True);results=[]
    modes=[(False,'gather',0.),(True,'gather',0.),(False,'gather',1.),(True,'gather',1.),(True,'unfold',1.)]
    for deterministic,kernel,weight in modes:
        torch.backends.cudnn.deterministic=deterministic;torch.backends.cudnn.benchmark=False
        temporary=dict(plan,local_peak_kernel=kernel,lanes=dict(test=dict(local_peak_weight=weight)))
        atomic_json(root/'objective/plan.json',temporary) if (root/'objective').exists() else None
        if not (root/'objective').exists():(root/'objective').mkdir();atomic_json(root/'objective/plan.json',temporary)
        if not (root/'objective/calibration.json').exists():os.link(root/'calibration.json',root/'objective/calibration.json')
        loss_fn=criterion(root/'objective','test').cuda();copies=[]
        for repeat in range(5):
            head=PairedQuantityLogitReadout().cuda();head.load_state_dict({k:old['model']['local_readout.'+k] for k in head.state_dict()});head.zero_grad(set_to_none=True)
            for row in cache:
                out=predict(head,row,dict(phase_specific=True),plan['normalization']['quantity_scale']);(loss_fn(out,row['batch'])['loss']/2).backward()
            copies.append([p.grad.detach().clone() for p in head.parameters()])
        exact=all(torch.equal(a,b) for gradients in copies[1:] for a,b in zip(copies[0],gradients));maximum=max(float((a-b).abs().max()) for gradients in copies[1:] for a,b in zip(copies[0],gradients))
        results.append(dict(cudnn_deterministic=deterministic,local_peak_kernel=kernel,local_peak_weight=weight,gradients_bitexact_five_repeats=exact,max_abs_gradient_difference=maximum))
        atomic_json(root/'progress.json',dict(modes=len(results),total=len(modes)));print(results[-1],flush=True)
    atomic_json(root/'result.json',dict(rows=results,optimizer_updates=0,model_weights_unchanged=True,source_cache='Same32trainingcache; first2fixedsamplepositions',independent_data_read=False));atomic_json(root/'status.json',dict(state='complete',pid=os.getpid(),optimizer_updates=0))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--worker',action='store_true');a=p.parse_args();root=a.root.resolve()
    try:
        if a.prepare:prepare(root)
        elif a.worker:worker(root)
    except BaseException as error:
        if not a.prepare:atomic_json(root/'status.json',dict(state='failed',pid=os.getpid(),error=repr(error)))
        raise
