"""Matched K4/K16 frozen local RVQ continuation of the historical16minute model."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import time

import numpy as np
import torch

from model.experimental.local_paired_state import LocalPairedOrderBookVAE
from train_dual.experiments.long_worker import datasets
from train_dual.util.data import DualNormalizer
from train_dual.util.dynamics import DynamicsMetrics
from util.model_sources import freeze_model_sources


def write(path, value):
    path=Path(path);tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False));tmp.replace(path)


def physical(raw):
    p,q=raw[...,0].astype('float64'),raw[...,1].astype('float64')
    qb=q.reshape(16,2,128,16);pb=p.reshape(16,2,128,16)
    dep=qb.sum(-1);total=dep.sum(1);log=np.log1p(total);mid=p[:,:,0].mean(1)
    local=[log,(dep[:,0]-dep[:,1])/total.clip(1e-12),np.log1p(qb.max((1,3))),
           np.abs(np.diff(pb,axis=-1)).mean((1,3)),
           np.abs(pb-mid[:,None,None,None]).mean((1,3))/mid[:,None]*1e4,
           np.concatenate([np.zeros((1,128)),np.diff(log,axis=0)])]
    glob=[(mid/mid[0]-1)*1e4,(p[:,1,0]-p[:,0,0])/mid*1e4,np.concatenate([[0],np.diff(np.log(mid))*1e4])]
    return np.stack(local+[x[:,None].repeat(128,1) for x in glob],-1)


FEATURES=['log_block_total_depth','block_bid_ask_imbalance','log_block_max_quantity','block_mean_gap_usdt',
          'block_distance_mid_bps','minute_log_block_depth_change','mid_path_from_anchor_bps','spread_bps','minute_mid_change_bps']


def probes(c,y,months,size):
    levels=c.shape[-1]
    folds=np.empty(len(c),dtype=int)
    for month in np.unique(months):
        ix=np.flatnonzero(months==month);folds[ix]=np.arange(len(ix))%2
    errors=np.empty((levels+1,len(c),y.shape[-1]));alone=np.empty((levels,len(c),y.shape[-1]));adjusted=np.empty_like(y)
    for fold in (0,1):
        tr=folds!=fold;te=~tr;base=np.empty_like(y)
        for month in np.unique(months):base[months==month]=y[tr&(months==month)].mean(0)
        target=y-base;adjusted[te]=target[te];trres=target[tr].copy();teres=target[te].copy()
        errors[0,te]=(teres**2).sum((1,2))
        for r in range(levels):
            code=c[tr,...,r].ravel();count=np.bincount(code,minlength=size).clip(1)
            def means(v):return np.stack([np.bincount(code,weights=v[...,j].ravel(),minlength=size)/count for j in range(y.shape[-1])],-1)
            inc=means(trres);mu=means(target[tr])
            trres-=inc[c[tr,...,r]];teres-=inc[c[te,...,r]]
            errors[r+1,te]=(teres**2).sum((1,2))
            alone[r,te]=((target[te]-mu[c[te,...,r]])**2).sum((1,2))
    base=errors[0].sum(0)
    occupancy=[];profiles=[]
    for r in range(levels):
        count=np.bincount(c[...,r].ravel(),minlength=size);prob=count/count.sum()
        occupancy.append(dict(level=r+1,counts=count.tolist(),effective_codes=float(np.exp(-(prob[prob>0]*np.log(prob[prob>0])).sum()))))
        for k in range(size):
            hit=c[...,r]==k
            profiles.append(dict(level=r+1,code=k,cells=int(hit.sum()),windows=int(hit.any((1,2)).sum()),
                adjusted_mean=adjusted[hit].mean(0).tolist() if hit.any() else None,
                monthly={str(m):dict(cells=int(hit[months==m].sum()),mean=adjusted[months==m][hit[months==m]].mean(0).tolist() if hit[months==m].any() else None) for m in np.unique(months)}))
    return dict(feature_names=FEATURES,standalone_r2=(1-alone.sum(1)/base).tolist(),prefix_r2=(1-errors.sum(1)/base).tolist(),
        monthly_standalone_r2={str(m):(1-alone[:,months==m].sum(1)/errors[0,months==m].sum(0)).tolist() for m in np.unique(months)},
        occupancy=occupancy,code_profiles=profiles,
        protocol='Two-fold whole-window cross-fitting within month; train-fold month/time/depth mean removed. Descriptive association, not independent factors or future prediction. Single seed42.')


def run(root):
    root=root.resolve();root.mkdir(parents=True,exist_ok=False);started=time.monotonic()
    project=Path(__file__).resolve().parents[2];old=project/'checkpoints/local_quant_recon_20261025_150636'
    def progress(**kw):
        value=dict(elapsed_seconds=time.monotonic()-started,**kw);write(root/'progress.json',value)
        with (root/'progress.jsonl').open('a') as log:log.write(json.dumps(value)+'\n')
        print(json.dumps(value),flush=True)
    write(root/'status.json',dict(state='running'))
    hashes=freeze_model_sources(root/'source_snapshot',project_root=project)
    script=root/'source_snapshot/train_dual/experiments/local_codebook_size_run.py';script.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(__file__,script)
    # Freeze evaluator dependencies as well as model implementation.
    for name in ['train_dual/experiments/long_worker.py','train_dual/util/data.py','train_dual/util/dynamics.py','util/dataset.py']:
        target=root/'source_snapshot'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(project/name,target)
    hashes.update({str(p.relative_to(root/'source_snapshot')):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'source_snapshot').rglob('*.py')})
    write(root/'source_snapshot/sha256.json',hashes)
    torch.set_num_threads(4);torch.manual_seed(42)
    checkpoint=old/'local8_frozen/final.pt';saved=torch.load(checkpoint,map_location='cpu',weights_only=False)
    common={k:v for k,v in saved['model'].items() if not k.startswith('local_quantizer.')}
    models={k:LocalPairedOrderBookVAE(quant_window=16,quant_levels=8,quant_size=k,**saved['model_config']).eval() for k in (4,16)}
    for m in models.values():m.load_cross_initial(common)
    assert all(torch.equal(v,models[16].state_dict()[k]) for k,v in models[4].state_dict().items() if not k.startswith('local_quantizer.'))
    norm=DualNormalizer(**{k:saved['config']['normalization'][k] for k in ('tick_size','price_scale')})
    train=datasets(old,saved,'train');val=datasets(old,saved,'val')
    evaluation=json.loads((old/'local8_frozen/final_evaluation.json').read_text())['result'];indices=evaluation['window_indices']
    fit_indices=np.load(old/'fit_indices.npy');np.save(root/'fit_indices.npy',fit_indices);np.save(root/'evaluation_indices.npy',indices)
    pre_raw={k:v.unsqueeze(0) for k,v in val[indices[0]].items()};pre=norm.prepare(pre_raw,'cpu')
    with torch.inference_mode():
        post=models[4].encoder(pre['price'],pre['volume'],pre['mask'],pre['tick_norm'],times=pre['times'],sample=False)
        fused=models[4].fusion([(post['z_global'],post['z_local'])],post['latent_mask'],pre['times'])
        original=models[4].decode_latents(fused['global_latent'],fused['local_latent'],pre['mask'],pre['tick_norm'],pre['times'])
    assert list(pre_raw['data'].shape)==[1,16,2,2048,2]
    assert list(original['volume'].shape)==[1,16,2,2048]
    write(root/'actual_shape_contract.json',dict(raw_input=list(pre_raw['data'].shape),global_latent=list(fused['global_latent'].shape),
        local_latent=list(fused['local_latent'].shape),integer_codes=[1,16,128,8],price_output=list(original['price_norm'].shape),quantity_output=list(original['volume'].shape),
        window_minutes=16,scope='Explicit continuation of the historical16minute local8 model discussed in this conversation; not256minute mainline or8192Gaussian model.'))
    prefix_positions=set(np.linspace(0,127,16,dtype=int).tolist())
    plan=dict(seed=42,only_changed_factor='codebook_size K4 versus K16',sizes=[4,16],residual_levels=8,fit_windows=8192,fit_samples=131072,iterations_per_level=12,
        raw_window_minutes=16,quantized_shape=[1,16,128,8],fit_period=['2022-01-01','2025-01-01'],development=['2025-01-01','2025-04-01'],evaluation_windows=128,
        prefixes=list(range(1,9)),prefix_evaluation_positions=sorted(prefix_positions),prefix_evaluation_windows=16,full_depth_evaluation_windows=128,
        source_checkpoint=str(checkpoint),source_sha256=hashlib.sha256(checkpoint.read_bytes()).hexdigest(),latent_cache=str((old/'decoder_latents.pt').resolve()),
        frozen_encoder_and_decoders=True,adam_steps=0,precision='FP32CPU; same hardware and ordered sample stream for both K values',
        initialization='Same source neural weights and training means. Same sampled patch indices and same per-level randperm; K4 initial centers are first4 of K16 indices at each level. Residual values naturally differ after first level.',
        rate_note='K4=32768logicalbits=4KiB, K16=65536bits=8KiB per16minute window; codebooks/means/model/metadata excluded; codes not bitpacked.',
        historical_control='Historical GPU K16 is an external reference only; newly refitted CPU K16 is matched control. CPU/CUDA RNG and algorithms can differ.',
        no_semantic_constraints=True,no_future_returns=True,no_independent_test_used=True,source_hashes=hashes)
    write(root/'plan.json',plan);progress(phase='loading_training_latents')
    cache=torch.load(old/'decoder_latents.pt',map_location='cpu',mmap=True,weights_only=False);g,l=cache['global'],cache['local']
    assert list(g.shape)==[8192,16,64] and list(l.shape)==[8192,16,2,128,16]
    # Audit exact cached inputs against the common frozen encoder on spread-out training windows.
    with torch.inference_mode():
        for pos in [0,4096,8191]:
            b=norm.prepare({k:v.unsqueeze(0) for k,v in train[int(fit_indices[pos])].items()},'cpu')
            p=models[4].encoder(b['price'],b['volume'],b['mask'],b['tick_norm'],times=b['times'],sample=False)
            f=models[4].fusion([(p['z_global'],p['z_local'])],p['latent_mask'],b['times'])
            torch.testing.assert_close(f['global_latent'],g[pos:pos+1],atol=1e-4,rtol=1e-5)
            torch.testing.assert_close(f['local_latent'],l[pos:pos+1],atol=1e-4,rtol=1e-5)
        go,lo=g.mean(0),l.mean(0)
        generator=torch.Generator().manual_seed(42);sample=torch.randint(len(g)*16*128,(131072,),generator=generator)
        wi=sample//(16*128);ti=(sample//128)%16;ki=sample%128
        pg=(g[wi,ti]-go[ti])[:,None];pl=l[wi,ti,:,ki]-lo[ti,:,ki]
    np.save(root/'training_patch_indices.npy',sample.numpy())
    generator=torch.Generator().manual_seed(42);initials=torch.stack([torch.randperm(len(pg),generator=generator)[:16] for _ in range(8)])
    np.save(root/'center_initialization_indices.npy',initials.numpy())
    del cache,g,l
    for size,m in models.items():
        folder=root/f'k{size}';folder.mkdir();q=m.local_quantizer;q.global_origin.copy_(go);q.local_origin.copy_(lo)
        history=q.book.fit(pg,pl,iterations=12,seed=42,callback=lambda x:progress(phase='fitting_codebooks',size=size,**x))
        write(folder/'fit_history.json',history)
        payload=dict(format_version=1,model=m.state_dict(),model_config=saved['model_config'],config=saved['config'],
            local_paired_config=m.local_paired_config,source_hashes=hashes,initial_checkpoint=str(checkpoint))
        torch.save(payload,folder/'final.pt')
        assert q.logical_bits()==16*128*8*int(np.log2(size))
    del pg,pl
    stats={};tails={};codes={k:[] for k in models};energies={k:[] for k in models};features=[];months=[];profiles={k:[] for k in models};profiletruth=[]
    def update(key,truth,pred,mask):
        if key not in stats:stats[key]=DynamicsMetrics(norm.tick_size);tails[key]=np.zeros(3,dtype='int64')
        stats[key].update(truth,pred,mask);a=(truth[...,1]>=100)&mask;h=(pred[...,1]>=100)&mask
        tails[key]+=[int((a&h).sum()),int((~a&h&mask).sum()),int((a&~h).sum())]
    with torch.inference_mode():
        for position,index in enumerate(indices):
            raw={k:v.unsqueeze(0) for k,v in val[index].items()};b=norm.prepare(raw,'cpu');m=models[4]
            p=m.encoder(b['price'],b['volume'],b['mask'],b['tick_norm'],times=b['times'],sample=False)
            f=m.fusion([(p['z_global'],p['z_local'])],p['latent_mask'],b['times']);gg,ll=f['global_latent'],f['local_latent']
            truth=raw['data'][0].numpy().astype('float64');mask=b['mask'][0].numpy();assert bool(mask.all())
            features.append(physical(truth));stamp=int(val.base.times[int(val.base.starts[index])]);months.append(str(np.datetime64(stamp,'us'))[:7])
            original=m.decode_latents(gg,ll,b['mask'],b['tick_norm'],b['times'])
            pred=np.stack([norm.inverse_price(original['price_norm'],b)[0].numpy(),original['volume'][0].numpy()],-1);update('original',truth,pred,mask)
            if position in (0,63,127):profiletruth.append(truth)
            for size,m in models.items():
                q=m.local_quantizer;pg,pl=q.pairs(gg,ll);v=q.book(pg,pl);code=v['codes'].reshape(1,16,128,8)
                assert int(code.min())>=0 and int(code.max())<size
                codes[size].append(code[0].numpy().astype('uint8'));energies[size].append(v['residual_energy'].mean(0).numpy())
                for depth in (range(1,9) if position in prefix_positions else (8,)):
                    output=m.decode_codes(code[...,:depth],b['mask'],b['tick_norm'],b['times'])
                    pred=np.stack([norm.inverse_price(output['price_norm'],b)[0].numpy(),output['volume'][0].numpy()],-1)
                    update(f'k{size}_depth{depth}',truth,pred,mask)
                    if depth==8 and position in prefix_positions:update(f'k{size}_prefix_depth8',truth,pred,mask)
                    if depth==8 and position in (0,63,127):profiles[size].append(pred)
                    if position==0 and depth==8:
                        direct=m.forward_latents(gg,ll,b['mask'],b['tick_norm'],b['times'])
                        for field in ('volume','price_norm'):torch.testing.assert_close(direct[field],output[field],rtol=0,atol=0)
                        write(root/f'k{size}'/'integer_replay.json',dict(exact=True,code_shape=list(code.shape),code_min=int(code.min()),code_max=int(code.max())))
            if position==0 or (position+1)%8==0:progress(phase='matched_evaluation',windows=position+1,total=128)
    results={}
    for key,metric in stats.items():
        d=metric.finish();tp,fp,fn=map(int,tails[key]);d['threshold100']=dict(tp=tp,fp=fp,fn=fn,recall=tp/(tp+fn) if tp+fn else None,precision=tp/(tp+fp) if tp+fp else None)
        results[key]=d
    write(root/'results.json',results)
    external=json.loads((old/'local8_frozen/original_evaluation.json').read_text())['result']
    replay={k:dict(current=results['original']['metrics'][k]['rmse'],historical=external['metrics'][k]['rmse']) for k in ('price_usdt','quantity_btc')}
    for v in replay.values():assert abs(v['current']-v['historical'])<1e-3
    write(root/'continuous_source_replay.json',replay)
    for size in models:
        c=np.stack(codes[size]);y=np.stack(features);mm=np.array(months)
        np.savez_compressed(root/f'k{size}'/'codes_features.npz',codes=c,features=y,months=mm,indices=indices)
        np.savez_compressed(root/f'k{size}'/'profiles.npz',truth=np.stack(profiletruth),prediction=np.stack(profiles[size]),indices=np.array(indices)[[0,63,127]])
        write(root/f'k{size}'/'semantics.json',probes(c,y,mm,size))
        write(root/f'k{size}'/'residual_energy.json',np.stack(energies[size]).mean(0).tolist())
    write(root/'verification.json',dict(common_neural_weights_unchanged=all(torch.equal(v,m.state_dict()[k]) for m in models.values() for k,v in common.items()),
        same_training_means=bool(torch.equal(models[4].local_quantizer.global_origin,models[16].local_quantizer.global_origin) and torch.equal(models[4].local_quantizer.local_origin,models[16].local_quantizer.local_origin)),
        cached_training_windows_replayed=[0,4096,8191],integer_decode_replay_exact=True,source_sha256_unchanged=hashlib.sha256(checkpoint.read_bytes()).hexdigest()==plan['source_sha256']))
    write(root/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started))
    progress(phase='complete')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('root',type=Path);args=parser.parse_args()
    try:run(args.root)
    except BaseException as error:
        if args.root.exists():write(args.root/'failure.json',dict(error=repr(error)))
        raise
