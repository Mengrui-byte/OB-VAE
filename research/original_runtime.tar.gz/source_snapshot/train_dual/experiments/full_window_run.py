"""Actual256frame full-model trials with explicit16x1024 window bottlenecks."""

import argparse
from copy import deepcopy
from datetime import datetime
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import numpy as np
import torch
from torch.utils.data import DataLoader

from model.experimental.full_window_matrix import FullWindowMatrixOrderBookVAE
from model.losses.quantized_book import QuantizedBookLoss
from train_dual.experiments.local_quant_reconstruction import CacheWindows
from train_dual.experiments.long_worker import atomic_json,evaluate
from train_dual.experiments.window_state_pilot import load_base,strict_precision
from train_dual.util.checkpoint import atomic_save,freeze_sources,seed_everything,source_hashes
from train_dual.util.data import DualWindowDataset


LABELS={'reference':'256分钟·未压缩参考','shared_mlp':'共享编码器·浅层压缩','shared_res2':'共享编码器·残差压缩','tower_res2':'价格/挂量双塔·残差压缩'}


def dataset(root,split):
    plan=json.loads((root/'plan.json').read_text());start,end=plan['train' if split=='train' else 'development']
    if plan['window_size']!=256 or plan['stride']!=256:raise ValueError('This trial requires complete nonoverlapping256minute windows')
    return DualWindowDataset(asset='BTCUSDT',npz_dir=root/'data/BTCUSDT.npz',start=start,end=end,levels=2048,window_size=256,stride=256,time_unit_seconds=60)


def prepare(parent):
    parent=parent.resolve();root=parent.parent/('dual256_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
    root.mkdir();(root/'logs').mkdir();(root/'data').mkdir()
    os.link(parent/'initial.pt',root/'initial.pt');os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    plan=dict(parent=str(parent),experiment='Full256minute dual-branch reconstruction',seed=42,window_size=256,stride=256,
        train=['2022-01-01','2025-01-01'],development=['2025-01-01','2025-04-01'],independent_test_untouched=['2025-04-01','2025-07-01'],
        fit_windows=64,evaluation_windows=16,seen_windows=8,basis_windows=32,basis_width=256,
        matrix_shape=[16,1024],input_shape=[1,256,2,2048,2],batch_size=1,accumulation=4,
        encoder_lr=1e-5,decoder_lr=1e-5,linear_lr=1e-5,residual_lr=1e-4,
        checkpoints=[32,128,256,512],steps=512,max_seconds=43200,labels=LABELS,default_variant='shared_res2',
        lanes={'reference':dict(branch_mode='shared',compress=False,codec_kind='nonlinear',codec_depth=0),
               'shared_mlp':dict(branch_mode='shared',compress=True,codec_kind='nonlinear',codec_depth=0),
               'shared_res2':dict(branch_mode='shared',compress=True,codec_kind='residual',codec_depth=2),
               'tower_res2':dict(branch_mode='tower',compress=True,codec_kind='residual',codec_depth=2)},
        source_initialization='Known Cross weights trained on16minute inputs are initialization only. Every train/eval window here has256frames; all modules are trained. No claim of starting from a256minute-trained source.',
        method='Full256frame encoders and Cross; trainable4160->256 channel projection; flatten16 consecutive channel vectors to4096 and learn4096->1024 for each of16matrix rows; inverse learned maps restore256frames. Full-window source temporal context precedes grouping. No16minute independent encoder calls or anchor resets.',
        initialization='Channel projection PCA fitted only on32complete256minute training windows; temporal projection starts as4DCT time modes per256channels. Both projections remain trainable; residual outputs start at zero.',
        comparison='Reference and shared groups share source weights; same-width compressed groups initially equal. Modality gates and two-source fusion alter tower initial outputs, which are reported separately.',
        precision='BF16 training with activation checkpointing; FP32 evaluation; both TF32 flags off',
        objective=dict(price=1.,volume_log=1.,volume_linear=.05,gap_log=.05,spread_log=.05,mid=.1,volume_tail=.25,temporal_quantity=.5,temporal_price=.1,latent_mse=.01,kl=0.),
        no_quantization=True,no_future_returns=True,selection='All declared checkpoints and fixed512step endpoints on the same16development windows; seed42only;2026 is not used for fitting or selection.')
    atomic_json(root/'plan.json',plan)
    for split,count in [('train',plan['fit_windows']),('val',plan['evaluation_windows'])]:
        data=dataset(root,split);indices=np.unique(np.linspace(0,len(data)-1,count,dtype=np.int64));assert len(indices)==count
        np.save(root/(split+'_indices.npy'),indices)
        item=data[int(indices[0])];start=int(data.base.starts[int(indices[0])]);absolute=data.base.times[start:start+256]
        assert list(item['data'].shape)==[256,2,2048,2] and bool((np.diff(absolute//60_000_000)==1).all())
        atomic_json(root/(split+'_data_contract.json'),dict(raw_shape=[1,*item['data'].shape],window_minutes=256,first_utc=str(np.datetime64(int(absolute[0]),'us')),last_utc=str(np.datetime64(int(absolute[-1]),'us')),candidate_windows=len(data),selected_windows=len(indices),first_selected_index=int(indices[0]),last_selected_index=int(indices[-1])))
    atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(parent.parents[1])
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.full_window_run "{remote}"\n')
    Path('/tmp/dual256_run_path').write_text(str(root));print(root,flush=True)


def profiles(root,model,norm,original,indices,path):
    positions=np.unique(np.linspace(0,len(indices)-1,3,dtype=int));truth=[];prediction=[];masks=[];times=[];matrices=[];model.eval()
    with torch.inference_mode():
        for pos in positions:
            index=int(indices[pos]);raw={k:v.unsqueeze(0) for k,v in original[index].items()};b=norm.prepare(raw,'cuda:0')
            out=model(b['price'],b['volume'],b['mask'],b['tick_norm'],b['times'],sample=False)
            assert list(out['price_norm'].shape)==[1,256,2,2048] and list(raw['data'].shape)==[1,256,2,2048,2]
            if model.compress:
                assert list(out['matrix_latent'].shape)==[1,16,1024]
                replay=model.decode_matrix(out['matrix_latent'],b['mask'],b['tick_norm'],b['times'])
                for key in ('volume','price_norm'):torch.testing.assert_close(out[key],replay[key],rtol=0,atol=0)
                matrices.append(out['matrix_latent'][0].cpu().numpy())
            truth.append(raw['data'][0].numpy());masks.append(b['mask'][0].cpu().numpy())
            prediction.append(np.stack([norm.inverse_price(out['price_norm'],b)[0].cpu().numpy(),out['volume'][0].cpu().numpy()],-1))
            start=int(original.base.starts[index]);times.append(original.base.times[start:start+256])
    values=dict(truth=np.stack(truth),prediction=np.stack(prediction),mask=np.stack(masks),time=np.stack(times),indices=indices[positions])
    if matrices:values['matrix']=np.stack(matrices)
    np.savez_compressed(path,**values)


def prepare_basis(root):
    torch.set_num_threads(4);seed_everything(42);strict_precision();plan=json.loads((root/'plan.json').read_text());source,norm=load_base(root)
    atomic_json(root/'status.json',dict(state='preparing_256minute_basis'))
    model=FullWindowMatrixOrderBookVAE(compress=False,**source['model_config']).to('cuda:0').eval().requires_grad_(False)
    model.load_cross_initial(source['model']);data=dataset(root,'train');indices=np.load(root/'train_indices.npy');chosen=indices[np.unique(np.linspace(0,len(indices)-1,plan['basis_windows'],dtype=int))];parts=[]
    started=time.monotonic()
    with torch.inference_mode():
        for n,index in enumerate(chosen):
            b=norm.prepare({k:v.unsqueeze(0) for k,v in data[int(index)].items()},'cuda:0')
            g,l=model.encode_fused(b['price'],b['volume'],b['mask'],b['tick_norm'],b['times'])
            assert list(g.shape)==[1,256,64] and list(l.shape)==[1,256,2,128,16]
            parts.append(torch.cat([g,l.flatten(2)],-1).reshape(-1,4160).cpu())
            atomic_json(root/'basis_progress.json',dict(windows=n+1,total=len(chosen),elapsed_seconds=time.monotonic()-started))
    x=torch.cat(parts).to('cuda:0');del parts;mean=x.mean(0);x=x-mean
    torch.manual_seed(42);_,_,v=torch.pca_lowrank(x,q=288,center=False,niter=3);basis=v[:,:256].T.contiguous()
    energy=float((x@basis.T).square().sum()/x.square().sum());atomic_save(dict(mean=mean.cpu(),basis=basis.cpu()),root/'frame_basis.pt')
    atomic_json(root/'basis_fit.json',dict(windows=len(chosen),rows=len(x),retained_training_energy=energy,source_input_minutes=256,global_shape=[1,256,64],local_shape=[1,256,2,128,16],fit_split='2022–2024training only',elapsed_seconds=time.monotonic()-started))
    del x,mean,basis,v;torch.cuda.empty_cache()
    val=dataset(root,'val');value=evaluate(model,norm,CacheWindows(val,np.load(root/'val_indices.npy')),plan['evaluation_windows'],'cuda:0');model.eval()
    atomic_json(root/'source_evaluation.json',dict(result=value));profiles(root,model,norm,val,np.load(root/'val_indices.npy'),root/'source_profiles.npz')
    del model;torch.cuda.empty_cache()


def worker(root,lane):
    torch.set_num_threads(4);seed_everything(42);strict_precision();plan=json.loads((root/'plan.json').read_text());spec=plan['lanes'][lane];source,norm=load_base(root)
    folder=root/lane;folder.mkdir(exist_ok=True);started=time.monotonic();atomic_json(folder/'status.json',dict(state='running'))
    def progress(**value):
        d=dict(value,elapsed_seconds=time.monotonic()-started,reserved_gib=torch.cuda.memory_reserved()/2**30)
        atomic_json(folder/'progress.json',d)
        with (folder/'progress.jsonl').open('a') as f:f.write(json.dumps(d)+'\n')
        print(json.dumps(d),flush=True)
    try:
        model=FullWindowMatrixOrderBookVAE(**spec,**source['model_config']);model.load_cross_initial(source['model'])
        if model.compress:
            basis=torch.load(root/'frame_basis.pt',map_location='cpu',weights_only=False);model.window_codec.frame.initialize_pca(basis['mean'],basis['basis'])
        model.to('cuda:0');original_train=dataset(root,'train');original_val=dataset(root,'val');train_indices=np.load(root/'train_indices.npy');val_indices=np.load(root/'val_indices.npy')
        train=CacheWindows(original_train,train_indices);val=CacheWindows(original_val,val_indices)
        modules=dict(encoder=model.encoder,fusion=model.fusion,price_decoder=model.price_decoder,volume_decoder=model.volume_decoder,volume_refinement=model.volume_refinement)
        if model.compress:modules.update(channel_codec=model.window_codec.frame,time_codec=model.window_codec.time)
        if model.two_towers:modules['quantity_encoder']=model.quantity_encoder
        atomic_json(folder/'trainable_modules.json',{k:dict(parameters=sum(p.numel() for p in m.parameters()),trainable=sum(p.numel() for p in m.parameters() if p.requires_grad)) for k,m in modules.items()})
        initial=evaluate(model,norm,val,plan['evaluation_windows'],'cuda:0');atomic_json(folder/'initial_evaluation.json',dict(result=initial));model.train()
        groups={}
        for name,p in model.named_parameters():
            group='residual' if name.startswith('window_codec.') and '_residual.' in name else 'linear' if name.startswith('window_codec.') else 'encoder' if name.startswith(('encoder.','quantity_encoder.','fusion.')) else 'decoder'
            groups.setdefault(group,[]).append(p)
        opt=torch.optim.AdamW([dict(params=ps,lr=plan[k+'_lr']) for k,ps in groups.items()],weight_decay=0.)
        criterion=QuantizedBookLoss();loader=DataLoader(train,batch_size=1,shuffle=True,num_workers=2,persistent_workers=True,pin_memory=True,generator=torch.Generator().manual_seed(42));iterator=iter(loader)
        config=deepcopy(source['config']);config['arguments'].update(window_size=256,stride=256,batch_size=1,accumulation_steps=4,precision='bf16',npz_dir=str(root/'data/BTCUSDT.npz'))
        def payload(step,full=False):
            value=dict(format_version=1,model=model.state_dict(),model_config=source['model_config'],window_matrix_config=model.window_matrix_config,config=config,step=step,source_hashes=source_hashes(),source_initial_window_minutes=16)
            if full:value.update(optimizer=opt.state_dict(),sampler_generator_state=loader.generator.get_state(),torch_rng_state=torch.get_rng_state(),cuda_rng_state=torch.cuda.get_rng_state_all(),epoch_boundary=step*plan['accumulation']%len(train)==0)
            return value
        for step in range(1,plan['steps']+1):
            model.train();opt.zero_grad(set_to_none=True);record={}
            for micro in range(plan['accumulation']):
                try:raw=next(iterator)
                except StopIteration:iterator=iter(loader);raw=next(iterator)
                if list(raw['data'].shape)!=[1,256,2,2048,2]:raise ValueError('Actual training input is not256frames')
                b=norm.prepare(raw,'cuda:0')
                with torch.autocast('cuda',dtype=torch.bfloat16):out=model(b['price'],b['volume'],b['mask'],b['tick_norm'],b['times'],sample=False)
                values=criterion(out,b)
                if not bool(torch.isfinite(values['loss'])):raise FloatingPointError('Nonfinite full-window loss')
                (values['loss']/plan['accumulation']).backward()
                for k in ('loss','volume_log','volume_tail','temporal_quantity','latent_mse'):record[k]=record.get(k,0.)+float(values[k].detach())/plan['accumulation']
                if step==1 and micro==0:
                    assert list(out['price_norm'].shape)==[1,256,2,2048]
                    atomic_json(folder/'actual_shape_contract.json',dict(raw_input=list(raw['data'].shape),price_output=list(out['price_norm'].shape),quantity_output=list(out['volume'].shape),matrix=list(out['matrix_latent'].shape) if model.compress else None,window_minutes=256,one_anchor_for_all256minutes=True))
                    if model.compress:assert list(out['matrix_latent'].shape)==[1,16,1024]
            if step==1:
                norms={k:sum(float(p.grad.detach().square().sum()) for p in m.parameters() if p.grad is not None)**.5 for k,m in modules.items()}
                if any(not np.isfinite(v) or v<=0 for v in norms.values()):raise RuntimeError(f'Missing actual training gradients:{norms}')
                atomic_json(folder/'first_step_gradient_norms.json',norms)
            grad=torch.nn.utils.clip_grad_norm_(model.parameters(),1.)
            if not bool(torch.isfinite(grad)):raise FloatingPointError('Nonfinite full-window gradient')
            opt.step()
            if step==1 or step%8==0:progress(phase='full256_training',step=step,total=plan['steps'],**record)
            if step in plan['checkpoints']:
                dev=evaluate(model,norm,val,len(val),'cuda:0');model.eval();atomic_json(folder/f'step{step}_evaluation.json',dict(result=dev))
                seen=evaluate(model,norm,train,plan['seen_windows'],'cuda:0');model.eval();atomic_json(folder/f'step{step}_seen_evaluation.json',dict(result=seen))
                atomic_save(payload(step,True),folder/f'step{step}.pt');profiles(root,model,norm,original_val,val_indices,folder/f'step{step}_profiles.npz')
                atomic_save(payload(step),folder/'latest.pt')
        atomic_save(payload(step),folder/'final.pt');atomic_json(folder/'final_evaluation.json',dict(result=dev))
        atomic_json(folder/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started,step=step))
    except BaseException as error:atomic_json(folder/'status.json',dict(state='failed',error=repr(error)));raise


def campaign(root):
    plan=json.loads((root/'plan.json').read_text());started=time.monotonic();children=[]
    try:
        prepare_basis(root)
        for gpu,lane in zip((2,3,4,5),plan['lanes']):
            env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),CUDA_DEVICE_ORDER='PCI_BUS_ID',PYTHONPATH=str(root/'source_snapshot'))
            with (root/'logs'/(lane+'.log')).open('ab',buffering=0) as log:
                child=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.full_window_run',str(root),'--lane',lane],cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            children.append((lane,gpu,child))
        atomic_json(root/'status.json',dict(state='running',children=[dict(lane=l,gpu=g,pid=p.pid) for l,g,p in children]))
        while any(p.poll() is None for _,_,p in children):
            if time.monotonic()-started>plan['max_seconds']:raise TimeoutError('12hour experiment ceiling reached')
            time.sleep(5)
        failures={l:p.returncode for l,_,p in children if p.returncode!=0}
        atomic_json(root/'status.json',dict(state='partial_failure' if failures else 'complete',failures=failures,elapsed_seconds=time.monotonic()-started))
    except BaseException as error:atomic_json(root/'status.json',dict(state='failed',error=repr(error)));raise
    finally:
        for _,_,p in children:
            if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--lane');args=p.parse_args()
    if args.prepare:prepare(args.root)
    elif args.lane:worker(args.root,args.lane)
    else:campaign(args.root)
