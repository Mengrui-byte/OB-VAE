"""Reconstruction-first local paired quantization, with controlled adaptation."""

import argparse
from datetime import datetime
import json
import os
from pathlib import Path
import time

import numpy as np
import torch
from torch.utils.data import Dataset,DataLoader

from model.experimental.local_paired_state import LocalPairedOrderBookVAE
from model.losses.quantized_book import QuantizedBookLoss
from train_dual.experiments.long_worker import atomic_json,datasets,evaluate
from train_dual.experiments.pca_run import examples
from train_dual.experiments.small_codebook_run import campaign
from train_dual.experiments.window_state_pilot import load_base,strict_precision
from train_dual.util.checkpoint import atomic_save,freeze_sources,seed_everything,source_hashes


class CacheWindows(Dataset):
    def __init__(self,dataset,indices):self.dataset,self.indices=dataset,indices
    def __len__(self):return len(self.indices)
    def __getitem__(self,index):return dict(self.dataset[int(self.indices[index])],cache_position=torch.tensor(index))


def prepare(parent):
    parent=parent.resolve();root=parent.parent/('local_quant_recon_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
    root.mkdir();(root/'data').mkdir();(root/'logs').mkdir()
    for name in ('initial.pt','expected_reference.json','source_profiles.npz'):os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    for name in ('decoder_latents.pt','fit_indices.npy'):(root/name).symlink_to(os.path.relpath((parent/name).resolve(),root))
    plan=json.loads((parent/'plan.json').read_text())
    plan.update(parent=str(parent),hypothesis='Local paired codes preserve details lost by whole-window prototypes; reconstruction feedback can further improve quantized books.',
        lanes={'local4_frozen':dict(levels=4,mode='frozen',steps=0),
               'local8_frozen':dict(levels=8,mode='frozen',steps=0),
               'local8_books':dict(levels=8,mode='books',steps=512),
               'local8_joint':dict(levels=8,mode='joint',steps=512)},
        codebook_size=16,fit_samples=131072,fit_iterations=12,batch_size=8,book_lr=.001,decoder_lr=.0001,
        no_semantic_constraints=True,no_future_returns=True,seed=42,
        method='At each of16times and128depth positions, common index selects (Gpatch[1,64], Lpatch[2,16]); Global is reconstructed by averaging paired G patches. Position-conditioned train means are shared translations, not input-dependent side channels. Raw unweighted productL2 only.',
        rate_note='4levels:32768bits=4KiB/window;8levels:65536bits=8KiB/window. Old8x16 whole-window:32bits. Increased position count and rate are explicit; model/codebook/means/masks/tick/anchor overhead excluded. Codes not bitpacked.',
        objective=dict(price=1.,volume_log=1.,volume_linear=.05,gap_log=.05,spread_log=.05,mid=.1,volume_tail=.25,
                       temporal_quantity=.5,temporal_price=.1,latent_mse=.01,beta_global=0.,beta_local=0.),
        primary='Price and quantity RMSE, minute log-quantity change correlation, >=100BTC recall; final fixed-step results, no future-return selection.',
        pilot_targets=dict(price_rmse_usdt=10.,quantity_rmse_btc=1.,quantity_change_correlation=.9,large_recall=.8))
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(parent.parents[1])
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'
        f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\n'
        f'cd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.local_quant_reconstruction "{remote}"\n')
    Path('/tmp/local_quant_recon_run_path').write_text(str(root));print(root,flush=True)


def worker(root,lane):
    torch.set_num_threads(4);seed_everything(42);strict_precision();started=time.monotonic()
    plan=json.loads((root/'plan.json').read_text());spec=plan['lanes'][lane];source,norm=load_base(root)
    folder=root/lane;folder.mkdir(exist_ok=True)
    def progress(**value):
        value=dict(value,elapsed_seconds=time.monotonic()-started,reserved_gib=torch.cuda.memory_reserved()/2**30)
        atomic_json(folder/'progress.json',value)
        with (folder/'progress.jsonl').open('a') as f:f.write(json.dumps(value)+'\n')
        print(json.dumps(value),flush=True)
    atomic_json(folder/'status.json',dict(state='running'))
    try:
        model=LocalPairedOrderBookVAE(quant_levels=spec['levels'],quant_size=plan['codebook_size'],**source['model_config'])
        model.load_cross_initial(source['model']);model.to('cuda:0').eval();model.evaluation_mode='original'
        val=datasets(root,source,'val');original=evaluate(model,norm,val,plan['evaluation_windows'],'cuda:0');model.eval()
        expected=json.loads((root/'expected_reference.json').read_text())['result']['metrics']
        delta={k:abs(original['metrics'][k]['rmse']-expected[k]['rmse']) for k in ('price_usdt','quantity_btc')}
        if max(delta.values())>1e-4:raise RuntimeError(f'Original source changed {delta}')
        atomic_json(folder/'original_evaluation.json',dict(result=original,differences=delta));progress(phase='loading_cache')
        cache=torch.load(root/'decoder_latents.pt',map_location='cpu',mmap=True,weights_only=False)
        g,l=cache['global'].to('cuda:0'),cache['local'].to('cuda:0');del cache
        train=datasets(root,source,'train');fit_indices=np.load(root/'fit_indices.npy');alignment=[]
        with torch.inference_mode():
            for position in (0,4096,8191):
                b=norm.prepare({k:v.unsqueeze(0) for k,v in train[int(fit_indices[position])].items()},'cuda:0')
                p=model.encoder(b['price'],b['volume'],b['mask'],b['tick_norm'],times=b['times'],sample=False)
                f=model.fusion([(p['z_global'],p['z_local'])],p['latent_mask'],b['times'])
                torch.testing.assert_close(f['global_latent'],g[position:position+1],atol=1e-4,rtol=1e-5)
                torch.testing.assert_close(f['local_latent'],l[position:position+1],atol=1e-4,rtol=1e-5)
                alignment.append(position)
        atomic_json(folder/'cache_alignment.json',dict(positions=alignment,passed=True))
        history=model.local_quantizer.fit(g,l,samples=plan['fit_samples'],iterations=plan['fit_iterations'],seed=42,
            callback=lambda x:progress(phase='fit_local_codebooks',**x))
        atomic_json(folder/'fit_history.json',dict(levels=history));model.evaluation_mode='quantized'
        initial=evaluate(model,norm,val,plan['evaluation_windows'],'cuda:0');model.eval()
        atomic_json(folder/'initial_evaluation.json',dict(result=initial));progress(phase='initial_evaluated',quantity_rmse=initial['metrics']['quantity_btc']['rmse'])
        model.configure_training(spec['mode']);criterion=QuantizedBookLoss(source['model_config'].get('quantity_scale',1.))
        groups=[]
        if spec['mode']!='frozen':groups.append(dict(params=list(model.local_quantizer.book.parameters()),lr=plan['book_lr']))
        if spec['mode']=='joint':
            groups.append(dict(params=[p for name,p in model.named_parameters() if p.requires_grad and not name.startswith('local_quantizer.')],lr=plan['decoder_lr']))
        if spec['steps']:
            optimizer=torch.optim.AdamW(groups,weight_decay=0.)
            loader=DataLoader(CacheWindows(train,fit_indices),batch_size=plan['batch_size'],shuffle=True,
                num_workers=2,persistent_workers=True,pin_memory=True,generator=torch.Generator().manual_seed(42))
            iterator=iter(loader)
            for step in range(1,spec['steps']+1):
                try:raw=next(iterator)
                except StopIteration:iterator=iter(loader);raw=next(iterator)
                b=norm.prepare(raw,'cuda:0');positions=raw['cache_position'].to('cuda:0')
                optimizer.zero_grad(set_to_none=True)
                output=model.forward_latents(g[positions],l[positions],b['mask'],b['tick_norm'],b['times'])
                values=criterion(output,b);loss=values['loss']
                if not torch.isfinite(loss):raise FloatingPointError('Nonfinite reconstruction loss')
                loss.backward();grad=torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad],1.)
                if not torch.isfinite(grad):raise FloatingPointError('Nonfinite reconstruction gradient')
                optimizer.step()
                if step==1 or step%64==0:progress(phase='reconstruction_adaptation',step=step,total=spec['steps'],
                    **{k:float(values[k].detach()) for k in ('loss','volume_log','volume_linear','volume_tail','temporal_quantity','latent_mse')})
            del iterator,loader
        del g,l;torch.cuda.empty_cache();model.eval()
        final=evaluate(model,norm,val,plan['evaluation_windows'],'cuda:0');model.eval()
        atomic_json(folder/'final_evaluation.json',dict(result=final))
        examples(root,folder,model,norm,source,plan)
        # Encoding and replay of two development windows must agree without original latent inputs.
        codes=[]
        with torch.inference_mode():
            for index in (0,63):
                raw={k:v.unsqueeze(0) for k,v in val[index].items()};b=norm.prepare(raw,'cuda:0')
                out=model(b['price'],b['volume'],b['mask'],b['tick_norm'],times=b['times'],sample=False)
                replay=model.decode_codes(out['local_codes'],b['mask'],b['tick_norm'],b['times'])
                torch.testing.assert_close(out['volume'],replay['volume'],atol=0,rtol=0)
                torch.testing.assert_close(out['price_norm'],replay['price_norm'],atol=0,rtol=0)
                codes.append(out['local_codes'].cpu().numpy())
        np.savez_compressed(folder/'replay_codes.npz',codes=np.concatenate(codes),indices=np.array([0,63]))
        atomic_save(dict(format_version=1,model=model.state_dict(),model_config=source['model_config'],config=source['config'],
            local_paired_config=model.local_paired_config,source_hashes=source_hashes(),initial_checkpoint=plan['initial_checkpoint']),folder/'final.pt')
        targets=plan['pilot_targets'];metrics=final['metrics']
        gates=dict(price=bool(metrics['price_usdt']['rmse']<=targets['price_rmse_usdt']),
            quantity=bool(metrics['quantity_btc']['rmse']<=targets['quantity_rmse_btc']),
            dynamics=bool(metrics['temporal_log_quantity_1_minutes']['correlation']>=targets['quantity_change_correlation']),
            large=bool(final['thresholds']['100']['recall']>=targets['large_recall']))
        q=model.local_quantizer;cost=(q.book.global_codebook.numel()+q.book.local_codebook.numel())*4
        atomic_json(folder/'comparison.json',dict(initial=initial,final=final,original=original,pilot_gates=gates,
            logical_bits=q.logical_bits(),codebook_bytes=cost,shared_origin_bytes=(q.global_origin.numel()+q.local_origin.numel())*4,
            code_shape=list(np.concatenate(codes).shape[1:]),integer_replay_exact=True,steps=spec['steps'],mode=spec['mode']))
        atomic_json(folder/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started,pilot_gates=gates))
    except BaseException as error:
        atomic_json(folder/'status.json',dict(state='failed',error=repr(error)));raise


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--lane');a=p.parse_args()
    if a.prepare:prepare(a.root)
    elif a.lane:worker(a.root,a.lane)
    else:campaign(a.root,worker_module='train_dual.experiments.local_quant_reconstruction')
