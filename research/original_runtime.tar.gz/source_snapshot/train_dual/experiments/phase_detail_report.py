"""Live HTML progress and full-mid / per-level-stem reconstruction previews."""
import html
import json
from pathlib import Path

import numpy as np


def read(path, default=None):
    # An optional live status may disappear between stat/open on the remote
    # mount during atomic replacement. Read once; missing means not yet ready.
    try:
        content=path.read_text()
    except FileNotFoundError:
        return default
    return json.loads(content)


def fmt(value):
    return '—' if value is None else f'{value:.6g}'


STYLE='''body{margin:0;background:#f3f5f8;color:#263a4a;font:15px/1.8 system-ui,sans-serif}main{max-width:1320px;margin:24px auto;background:white;padding:30px 38px;border:1px solid #dde4ec}h1{font-size:27px}h2{font-size:21px;margin-top:30px}a{color:#29638d}table{border-collapse:collapse;width:100%;font-size:13px}th,td{padding:10px;text-align:left;border-bottom:1px solid #dde4ec}th{background:#f3f7fa}.note{padding:14px;background:#f0f5fa;border-left:3px solid #7f9eb6}.wrap{overflow:auto}.small{font-size:12px;color:#687b8c}select{padding:6px;margin:5px}.plot{height:430px}@media(max-width:700px){main{margin:8px;padding:18px 12px}}'''


def render(root):
    plan=read(root/'plan.json');status=read(root/'status.json',{})
    report=plan.get('report',{})
    title=html.escape(report.get('title','数量Decoder：原路径 / 区域修正 / 逐档修正'))
    scope=html.escape(report.get('scope','Encoder与价格Decoder冻结；只训练数量Decoder。'))
    introduction=html.escape(report.get('introduction','三组共享同一权重与原AdamW状态、1024训练窗、有效batch4、seed42、shape_mass损失与2048次更新。新增细节头全零初始化；off禁用，shared在区域内共享修正，independent分别生成16档修正。'))
    hardware=html.escape(report.get('hardware','GPU2–4训练，GPU5统一FP32评估和生成重建图。'))
    reference_note=html.escape(report.get('reference_note','共享参数起点的价格RMSE约78.05USDT，本轮目标为检验数量读出的增量。'))
    parts=[f'<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="30"><title>{title}</title><style>{STYLE}</style><main>',
        f'<h1>{title}</h1>',
        f'<div class="note">状态：{html.escape(status.get("state","prepared"))}。完整256分钟，每侧2048档，唯一64×128 latent。{scope}此页每30秒刷新。</div>',
        f'<p>{introduction}</p>',
        f'<p>{hardware}2025Q1为反复使用的开发集；2025Q2及2026未参与。{reference_note}</p>',
        '<h2>训练进度</h2><div class="wrap"><table><tr><th>模式</th><th>状态</th><th>更新</th><th>等效epoch</th><th>训练目标</th><th>梯度范数（裁剪前）</th><th>耗时</th></tr>']
    for lane,label in plan['labels'].items():
        row=read(root/lane/'progress.json',{});state=read(root/lane/'status.json',{})
        parts.append(f'<tr><td>{label}</td><td>{html.escape(state.get("state","等待启动"))}</td><td>{row.get("step",0)}/{row.get("total",plan["steps"])}</td><td>{fmt(row.get("epochs_equivalent"))}</td><td>{fmt(row.get("loss"))}</td><td>{fmt(row.get("gradient_norm"))}</td><td>{fmt(row.get("elapsed_seconds",0)/60)}分钟</td></tr>')
    ev=read(root/'evaluator_status.json',{}) if not plan.get('inline_evaluation') else {lane:read(root/lane/'evaluation_status.json',{}) for lane in plan['labels']}
    parts+=['</table></div>',f'<p class="small">FP32评估状态：{html.escape(json.dumps(ev,ensure_ascii=False))}</p>',
        '<h2>固定窗口的开发指标</h2><div class="wrap"><table><tr><th>更新</th><th>模式</th><th>价格RMSE / USDT</th><th>数量RMSE / BTC</th><th>Δlog数量相关</th><th>100BTC召回</th><th>100BTC精确率</th><th>误报数</th><th>最大预测量</th><th>重建图</th></tr>']
    for step in [0,*plan['checkpoints']]:
        for lane,label in plan['labels'].items():
            item=read(root/lane/f'step{step}_evaluation.json')
            if not item:continue
            r=item['result'];m=r['metrics'];tail=r['thresholds']['100']
            path=f'{lane}/step{step}_preview.html'
            preview=f'<a href="{path}">中间价＋逐档挂单线</a>' if (root/path).exists() else ('同off初始图' if step==0 else '生成中')
            parts.append(f'<tr><td>{step}</td><td>{label}</td><td>{fmt(m["price_usdt"]["rmse"])}</td><td>{fmt(m["quantity_btc"]["rmse"])}</td><td>{fmt(m["temporal_log_quantity_1_minutes"]["correlation"])}</td><td>{fmt(tail["recall"])}</td><td>{fmt(tail["precision"])}</td><td>{tail["fp"]}</td><td>{fmt(r["prediction_max"])}</td><td>{preview}</td></tr>')
    parts+=['</table></div><p class="small">精确率为“—”表示没有预测阳性，不能解读成100%。每个指标来自同一批16开发窗口；训练诊断使用固定8个训练窗口。</p>',
        '<h2>固定训练窗口的拟合指标</h2><div class="wrap"><table><tr><th>更新</th><th>模式</th><th>数量RMSE / BTC</th><th>Δlog数量相关</th><th>100BTC召回</th><th>100BTC精确率</th></tr>']
    for step in [0,*plan['checkpoints']]:
        for lane,label in plan['labels'].items():
            item=read(root/lane/f'step{step}_seen_evaluation.json')
            if not item:continue
            r=item['result'];m=r['metrics'];tail=r['thresholds']['100']
            parts.append(f'<tr><td>{step}</td><td>{label}</td><td>{fmt(m["quantity_btc"]["rmse"])}</td><td>{fmt(m["temporal_log_quantity_1_minutes"]["correlation"])}</td><td>{fmt(tail["recall"])}</td><td>{fmt(tail["precision"])}</td></tr>')
    parts+=['</table></div>']
    if plan.get('loss_family')=='peak_aux':
        parts+=['<h2>辅助位置分类：与数量重建分开判断</h2><div class="wrap"><table><tr><th>更新</th><th>模式</th><th>位置头训练</th><th>AP（4096分箱）</th><th>正例占比</th><th>0.5分数精确率</th><th>0.5分数召回</th><th>0.5分数误报</th><th>真实大单处平均预测量</th></tr>']
        for step in [0,*plan['checkpoints']]:
            for lane,label in plan['labels'].items():
                item=read(root/lane/f'step{step}_peak_aux.json')
                if not item:continue
                r=item['development'];t=r['fixed_probability_thresholds']['0.5']
                trained='启用' if item['location_head_trained'] else '未训练'
                parts.append(f'<tr><td>{step}</td><td>{label}</td><td>{trained}</td><td>{fmt(r["histogram_average_precision"])}</td><td>{fmt(r["prevalence"])}</td><td>{fmt(t["precision"])}</td><td>{fmt(t["recall"])}</td><td>{t["fp"]}</td><td>{fmt(r["mean_reconstructed_quantity_at_true_peaks_btc"])}</td></tr>')
        parts+=['</table></div><p class="small">标签为真实数量≥10BTC。未训练头恒为0.5：在≥0.5阈值会全报阳性，AP等于正例占比，不能视为有效位置识别。类别平衡后的分数不保证是校准概率。位置AP提高也不代表数量重建改善。</p>']
    future=html.escape(report.get('future','本轮直接做真实订单簿对照；合成移动峰拟合、Encoder解冻和新损失均留给单独实验。响应方向增加本身不作为重建成功标准。'))
    parts+=[
        '<p>每个检查点保存模型、Adam状态、原参数名对应关系、窗口暴露次数、冻结模块哈希及完整重建数据。初始输出必须与旧模型完全一致；冻结模块哈希必须保持。</p>',
        f'<p>{future}</p>',
        '<p><a href="plan.json">完整配置</a> · <a href="status.json">进程状态</a> · <a href="data_contract.json">数据索引与形状</a> · <a href="source_snapshot/sha256.json">冻结源码哈希</a> · <a href="../decoder_design_20261026_205231/">模型结构图</a> · <a href="../">全部实验</a></p>']
    if status.get('error'):parts.append(f'<div class="note">运行错误：{html.escape(status["error"])}</div>')
    parts.append('</main></html>')
    temp=root/'index.html.tmp';temp.write_text(''.join(parts));temp.replace(root/'index.html')


def preview(root,lane,step):
    from plotly.offline import get_plotlyjs
    asset=root/'plotly.min.js'
    if not asset.exists():asset.write_text(get_plotlyjs())
    folder=root/lane
    with np.load(folder/f'step{step}_profiles.npz') as a:
        frames=[0,64,128,192,255];truth=a['truth'];pred=a['prediction'];mask=a['mask']
        payload=dict(indices=a['indices'].tolist(),frames=frames,mid_true=((truth[:,:,0,0,0]+truth[:,:,1,0,0])/2).tolist(),
            mid_pred=((pred[:,:,0,0,0]+pred[:,:,1,0,0])/2).tolist(),truth=truth[:,frames].tolist(),prediction=pred[:,frames].tolist(),mask=mask[:,frames].tolist())
        if 'peak_probability' in a:payload['peak_scores']=a['peak_probability'][:,frames].tolist()
    page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>逐档挂单重建</title><style>@@STYLE@@</style><script src="../plotly.min.js"></script><main>
    <h1>@@LABEL@@ · 追加@@STEP@@次更新</h1><p><a href="../">返回训练比较</a>。固定2025Q1开发样本，已用于模型研究；不是最终独立样本外测试。中间价显示完整256分钟；挂单抽样5帧，每个有效档位是一条竖线。</p>
    <label>窗口 <select id="window"></select></label><label>挂单帧 <select id="frame"></select></label><label>买卖侧 <select id="side"><option value="0">bid</option><option value="1">ask</option></select></label>
    <label>横轴 <select id="axis"><option value="level">档位</option><option value="price">实际价格</option></select></label><label>显示档位 <select id="depth"><option>2048</option><option>512</option><option>128</option></select></label>
    <label>数量纵轴 <select id="scale"><option value="linear">线性</option><option value="log">对数</option></select></label>
    <div id="mid" class="plot"></div><div id="book" class="plot"></div><div id="peak" class="plot" style="display:none"></div><p class="small">蓝色为真实，红色为重建；数量单位BTC。真实价格与预测价格各自配对各自数量；档位模式便于检验精确位置。可以缩放、框选及从图例隐藏某条曲线。若显示位置分数图，标签为真实数量≥10BTC，分数不保证是校准概率，也不参与数量生成。</p>
    <script>const D=@@DATA@@;const el=id=>document.getElementById(id);D.indices.forEach((v,i)=>el('window').add(new Option('数据窗口 '+v,i)));D.frames.forEach((v,i)=>el('frame').add(new Option('第 '+v+' 分钟',i)));el('frame').value='2';
    function draw(){const w=+el('window').value,f=+el('frame').value,s=+el('side').value,n=+el('depth').value;const x=Array.from({length:256},(_,i)=>i);
    Plotly.react('mid',[{x,y:D.mid_true[w],name:'真实中间价',line:{color:'#386f9a'}},{x,y:D.mid_pred[w],name:'重建中间价',line:{color:'#bd6158'}}],{title:'完整256分钟中间价',xaxis:{title:'分钟'},yaxis:{title:'USDT'},margin:{t:50,b:50,l:80,r:30}},{responsive:true});
    function stem(values,name,color){let x=[],y=[];for(let k=0;k<n;k++){if(!D.mask[w][f][s][k])continue;const p=el('axis').value==='price'?values[k][0]:k;x.push(p,p,null);y.push(0,values[k][1],null)}return {x,y,name,type:'scattergl',mode:'lines',line:{color,width:1},connectgaps:false}}
    Plotly.react('book',[stem(D.truth[w][f][s],'真实数量','#386f9a'),stem(D.prediction[w][f][s],'重建数量','#bd6158')],{title:'第'+D.frames[f]+'分钟 · '+(s?'ask':'bid')+' · 每档一条线',xaxis:{title:el('axis').value==='price'?'USDT':'档位，从最优到深档'},yaxis:{title:'挂单量 / BTC',type:el('scale').value},margin:{t:50,b:50,l:80,r:30}},{responsive:true});
    if(D.peak_scores){el('peak').style.display='block';const rank=Array.from({length:n},(_,i)=>i);const mask=D.mask[w][f][s];const target=rank.map(k=>mask[k]?(D.truth[w][f][s][k][1]>=10?1:0):null);const score=rank.map(k=>mask[k]?D.peak_scores[w][f][s][k]:null);Plotly.react('peak',[{x:rank,y:target,name:'真实≥10BTC标签',type:'scattergl',mode:'markers',marker:{color:'#386f9a',size:3}},{x:rank,y:score,name:'辅助位置分数',type:'scattergl',mode:'lines',line:{color:'#bd6158'}}],{title:'辅助位置识别 · 不参与数量生成',xaxis:{title:'档位'},yaxis:{title:'标签 / 分数',range:[-.05,1.05]},margin:{t:50,b:50,l:80,r:30}},{responsive:true})}}
    for(const id of ['window','frame','side','axis','depth','scale'])el(id).addEventListener('change',draw);draw();</script></main></html>'''
    plan=read(root/'plan.json')
    label=plan['labels'].get(lane,plan.get('diagnostic_labels',{}).get(lane,lane))
    description=plan.get('preview_descriptions',{}).get(lane)
    if description:
        page=page.replace('固定2025Q1开发样本，已用于模型研究；不是最终独立样本外测试。',html.escape(description))
    page=page.replace('@@STYLE@@',STYLE).replace('@@LABEL@@',html.escape(label)).replace('@@STEP@@',str(step)).replace('@@DATA@@',json.dumps(payload,separators=(',',':'),allow_nan=False))
    temp=folder/f'step{step}_preview.tmp';temp.write_text(page);temp.replace(folder/f'step{step}_preview.html')
