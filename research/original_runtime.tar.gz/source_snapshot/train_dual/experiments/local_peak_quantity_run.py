"""Conditional queue: matched local peak KL weights, with exact zero replay."""
import argparse
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import torch

from model.losses.local_peak import LocalPeakBookLoss
from train_dual.experiments import frozen_price_quantity_run as shared
from train_dual.experiments.goal_evaluate import assess_file
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.mid_delta_run import violation_key
from train_dual.experiments.phase_detail_report import read,STYLE
from train_dual.experiments.price_safe_readout import file_hash
from train_dual.experiments.recall_goal_run import candidates,record
from train_dual.experiments.region_task_run import gpu_free
from train_dual.util.checkpoint import freeze_sources


FACTORS=dict(control=0.,quarter=.25,unit=1.,four=4.)


def render(root):
    plan=read(root/'plan.json');state=read(root/'status.json',{})
    if plan.get('queue_only'):
        text='<h1>条件接续：大单邻域分布KL</h1><p>等待固定价格的数量Decoder四组完成并退出。若已有通过联合门槛的原生候选，优先确认，不启动本轮。</p><p>否则从最终共同2048步的三个可训练组中，按既定五项门槛最大违约比/总违约比/召回/价格顺序选择训练开关；新实验仍从原始同一来源开始，而不是从已训练的父模型继续。零权重组必须重放父实验相应组的全部检查点。</p>'
    else:
        text='<h1>固定价格：大单邻域分布KL权重对照</h1><p>完整256分钟、唯一64×128 Gaussian、原生模型结构与上采样不变。只改变同一time/side真实≥100BTC档位周围±8档的条件数量分布KL权重。原有量价、形态、总量及正负例损失均保留，严格同档位评估不变。</p><p>四组使用同一原始来源、缓存、32训练窗口、seed42、采样顺序、Adam、BF16计算、lr1e-4、2048步与评估。Encoder与价格始终冻结，数量训练开关：'+str(plan['selected_trainability'])+'。新增权重由8个固定训练窗上的参数梯度RMS标定，设置相对预算0 / 0.25 / 1 / 4；不使用开发结果调节标定系数。</p><table><tr><th>组</th><th>步数</th><th>召回</th><th>精确率</th><th>价格RMSE</th><th>分钟变化RMSE</th><th>数量RMSE</th><th>通过</th></tr>'
        for lane in FACTORS:
            for step in [0,*plan['checkpoints']]:
                path=root/lane/f'step{step}_development.json'
                if not path.exists():continue
                row=assess_file(path,root.parent/'reference_evaluation.json');values=[plan['labels'][lane],step,row['recall100'],row['precision100'],row['price_rmse'],row['mid_delta_rmse'],row['quantity_rmse'],row['pass']]
                text+='<tr>'+''.join('<td>'+str(round(v,5) if isinstance(v,float) else v)+'</td>' for v in values)+'</tr>'
        text+='</table><p>零权重组的权重和全部Adam状态必须逐值重放父实验对应组；每个检查点保留审计。固定16个Q1开发窗口已反复用于选型，不是独立测试；独立确认集不参与本轮。</p>'
    (root/'index.html').write_text('<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="30"><title>大单邻域KL控制实验</title><style>'+STYLE+'</style><main>'+text+'<p>状态：'+str(state.get('state'))+'</p><p><a href="plan.json">协议</a> · <a href="status.json">进度</a></p></main>')


def prepare_queue(goal):
    parent=goal/'frozen_price_quantity';probe=goal/'local_peak_gradient_probe'
    if read(probe/'status.json',{}).get('state')!='complete':raise ValueError('Need completed read-only training gradient calibration')
    root=goal/'local_peak_quantity_after';root.mkdir();(root/'logs').mkdir();freeze_sources(root/'source_snapshot')
    parent_state=read(parent/'status.json',{})
    atomic_json(root/'plan.json',dict(queue_only=True,parent=parent.name,parent_controller_pid=parent_state.get('controller_pid',parent_state.get('pid')),probe=probe.name,factors=FACTORS,steps=2048,checkpoints=[256,1024,2048],wait_seconds=46800,max_seconds=10800,
        selection='Largest shared final2048, trainable parent arms only; min fixed five-gate violation key, then frozen original source/data/Adam replay. No best trained parent weights used.',
        skip_if='Any eligible native candidate requires confirmation first; no new candidate training then.',seed=42))
    atomic_json(root/'status.json',dict(state='prepared'));render(root)
    project=Path(__file__).resolve().parents[2];remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.local_peak_quantity_run "{remote}" --controller >> "{remote}/logs/controller.log" 2>&1\n')
    record(goal,'local_peak_quantity_queue_prepared',root=root.name,probe=probe.name,source='Same original price-safe source; zero-loss control replays selected parent trainability',steps=2048);print(root,flush=True)


def live_parent(parent,pid=None):
    state=read(parent/'status.json',{});pid=pid if pid is not None else state.get('controller_pid',state.get('pid'))
    if pid is None:return False
    try:cmd=Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0')
    except FileNotFoundError:return False
    return b'train_dual.experiments.frozen_price_quantity_run' in cmd and b'--controller' in cmd and os.fsencode(str(parent)) in cmd


def select_mask(rows,step=2048):
    pool=[r for r in rows if r['step']==step and r['lane'] in ['temporal','spatial','both']]
    if len(pool)!=3 or {r['lane'] for r in pool}!={'temporal','spatial','both'}:raise ValueError('Need all3trained masks at the same declared2048endpoint')
    return min(pool,key=violation_key)


def prepare_actual(queue,selected):
    goal=queue.parent;parent=goal/read(queue/'plan.json')['parent'];probe=goal/'local_peak_gradient_probe';root=goal/'local_peak_quantity';root.mkdir()
    for name in ['data','logs',*FACTORS]:(root/name).mkdir()
    for name in ['source.pt','source_development.json','train_cache.pt','cache_audit.json','train_indices.npy','train_order.npy','val_indices.npy','calibration.json','plotly.min.js']:os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz');os.link(probe/'result.json',root/'gradient_calibration.json')
    old=read(parent/'plan.json');flags=old['lanes'][selected['lane']];cal=read(probe/'result.json')['gradient_calibration'][selected['lane']];scale=cal['unit_weight']
    plan=dict(old,experiment='Peak-neighborhood conditional quantity KL single-factor weights',labels={lane:f'局部KL梯度预算×{factor:g}' for lane,factor in FACTORS.items()},
        lanes={lane:dict(flags,local_peak_weight=factor*scale) for lane,factor in FACTORS.items()},selected_trainability=selected['lane'],trainability_selection=selected,
        local_peak_radius=8,local_peak_calibration=cal,replay_control_root=str(parent),replay_control_lane=selected['lane'],
        source_control='Same ORIGINAL source and Adam/data/order/precision/budget as selected parent mask; only local peak KL weight varies; weight0mustreplayparentat0/256/1024/2048. No new model params, future data or upsampling change.',
        preview_descriptions={lane:'固定16个反复用于研究的Q1开发窗口。完整256分钟、唯一8192原生Z。Encoder/价格冻结，追加大单邻域条件分布KL；严格同档位评估，非独立测试。' for lane in FACTORS})
    assert file_hash(root/'train_cache.pt')==read(probe/'plan.json')['cache_sha256']
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot');render(root)
    record(goal,'local_peak_quantity_started',root=root.name,selected_trainability=selected['lane'],lambda_unit=scale,steps=2048,source='Unchanged original price-safe source; not trained parent endpoint');return root


def criterion(root,lane):
    plan=read(root/'plan.json');cal=read(root/'calibration.json')
    return LocalPeakBookLoss(plan['normalization']['quantity_scale'],mode='shape_mass',use_hint=False,use_tail=True,protect_mid=True,
        tail_weight=cal['tail_weight'],mid_weight=cal['mid_weight'],mid_delta_weight=plan['fixed_mid_delta_weight'],
        local_peak_weight=plan['lanes'][lane]['local_peak_weight'],local_peak_radius=plan['local_peak_radius'],local_peak_kernel=plan.get('local_peak_kernel','gather'),**plan['source_FP_rule'],**plan['objective'])


def replay_control(root,lane,step,model,optimizer):
    if lane!='control':return
    plan=read(root/'plan.json');path=Path(plan['replay_control_root'])/plan['replay_control_lane']/f'step{step}.pt';old=torch.load(path,map_location='cpu',weights_only=False)
    current=model.state_dict()
    if current.keys()!=old['model'].keys():raise ValueError('Replay model layout changed')
    for name,value in current.items():torch.testing.assert_close(value.detach().cpu(),old['model'][name],rtol=0,atol=0,msg=lambda m:'Zero-KL replay model '+name+': '+m)
    new=optimizer.state_dict();previous=old['optimizer']
    assert new['param_groups']==previous['param_groups'] and new['state'].keys()==previous['state'].keys()
    for index,state in previous['state'].items():
        assert state.keys()==new['state'][index].keys()
        for key,value in state.items():
            actual=new['state'][index][key]
            assert torch.equal(value.cpu(),actual.cpu()) if torch.is_tensor(value) else value==actual
    atomic_json(root/lane/f'step{step}_parent_replay_audit.json',dict(passed=True,source=str(path),all_model_values_exact=True,all_Adam_values_exact=True))


def run_cohort(root):
    plan=read(root/'plan.json');children=[];started=time.monotonic();audited=False
    try:
        for gpu,lane in zip([2,3,4,5],FACTORS):
            env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),PYTHONPATH=str(root/'source_snapshot'))
            with (root/'logs'/f'{lane}.log').open('ab',buffering=0) as log:child=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.local_peak_quantity_run',str(root),'--lane',lane],cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            children.append(child)
        atomic_json(root/'status.json',dict(state='running',controller_pid=os.getpid(),pids=[p.pid for p in children]))
        while any(child.poll() is None for child in children):
            if any(child.poll() not in [None,0] for child in children):raise RuntimeError('Owned local-KL worker failed; controls/results preserved')
            if time.monotonic()-started>plan['max_controller_seconds']:raise TimeoutError('Declared3hourplusassessment ceiling')
            if not audited:
                rows={lane:read(root/lane/'step1_data_audit.json') for lane in FACTORS}
                if all(rows.values()):
                    control=rows['control']
                    for lane,row in rows.items():
                        assert row['indices']==control['indices']
                        for key in ['pre_local_peak_loss','local_peak_kl','tail_balanced','quantity_shape_kl']:assert math.isclose(row['losses'][key],control['losses'][key],rel_tol=2e-6,abs_tol=2e-6)
                        expected=control['losses']['loss']+plan['lanes'][lane]['local_peak_weight']*control['losses']['local_peak_kl'];assert math.isclose(row['losses']['loss'],expected,rel_tol=3e-6,abs_tol=3e-6)
                    audited=True;atomic_json(root/'startup_control_audit.json',dict(passed=True,same_source_model_Adam_data_base_and_local_losses=True,only_local_peak_weight_varies=True))
            update_common(root);render(root);time.sleep(10)
        if any(child.returncode for child in children):raise RuntimeError('Owned local-KL worker failed')
        if not audited:raise RuntimeError('Missing full startup audit')
        update_common(root);atomic_json(root/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started,goal_automatically_completed=False));render(root)
    finally:
        for child in children:
            if child.poll() is None:os.killpg(child.pid,signal.SIGTERM)


def update_common(root):
    plan=read(root/'plan.json')
    for step in plan['checkpoints']:
        paths=[root/lane/f'step{step}_development.json' for lane in FACTORS]
        if not (root/f'common{step}_analysis.json').exists() and all(p.exists() for p in paths):
            rows=[dict(lane=lane,step=step,checkpoint=str(root/lane/f'step{step}.pt'),evaluation=str(path),**assess_file(path,root.parent/'reference_evaluation.json')) for lane,path in zip(FACTORS,paths)]
            atomic_json(root/f'common{step}_analysis.json',dict(rows=rows,source_price_replay_passed=True,independent_data_read=False));passing=[row for row in rows if row['pass']]
            if passing:atomic_json(root/'eligible_candidate.json',max(passing,key=lambda row:(row['recall100'],-row['price_rmse'])))


def controller(queue):
    torch.set_num_threads(4);config=read(queue/'plan.json');goal=queue.parent;parent=goal/config['parent'];started=time.monotonic()
    while True:
        state=read(parent/'status.json',{});live=live_parent(parent,config.get('parent_controller_pid'))
        if state.get('state')=='failed':raise RuntimeError('Parent failed; do not launch a fresh study')
        if state.get('state')=='complete' and not live:break
        if not live:raise RuntimeError('Parent is not terminal and its verified controller is missing')
        if time.monotonic()-started>config['wait_seconds']:raise TimeoutError('Verified predecessor wait ceiling')
        atomic_json(queue/'status.json',dict(state='verified_wait_parent',parent_pid=config.get('parent_controller_pid',state.get('controller_pid',state.get('pid')))));render(queue);time.sleep(20)
    if (goal/'candidate_for_confirmation.json').exists() or (parent/'eligible_candidate.json').exists():
        atomic_json(queue/'status.json',dict(state='not_run_candidate_for_confirmation'));render(queue);return
    rows=candidates(parent,goal/'reference_evaluation.json');selected=select_mask(rows,config['steps'])
    while any(gpu_free().get(g,0)<20000 for g in [2,3,4,5]):
        if time.monotonic()-started>config['wait_seconds']:raise TimeoutError('Shared GPU wait ceiling')
        atomic_json(queue/'status.json',dict(state='verified_wait_GPU_release',selected=selected));render(queue);time.sleep(20)
    root=prepare_actual(queue,selected);atomic_json(queue/'status.json',dict(state='running',wave=root.name));render(queue);run_cohort(root)
    atomic_json(queue/'status.json',dict(state='complete',wave=root.name,goal_automatically_completed=False));render(queue)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--controller',action='store_true');p.add_argument('--lane',choices=list(FACTORS));a=p.parse_args();root=a.root.resolve()
    def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        if a.prepare:prepare_queue(root)
        elif a.lane:shared.worker(root,a.lane,objective_factory=criterion,render_fn=render,checkpoint_auditor=replay_control)
        elif a.controller:controller(root)
    except BaseException as error:
        if not a.prepare:atomic_json((root/a.lane if a.lane else root)/'status.json',dict(state='failed',error=repr(error),pid=os.getpid()))
        raise
