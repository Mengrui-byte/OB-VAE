"""2x2 ordered-Wasserstein and multiscale-KL controls, no architecture changes."""
import argparse
from datetime import datetime
import json
import math
import os
from pathlib import Path

import numpy as np
import torch

from model.losses.probability_book import ProbabilityBookLoss
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.loss_control_run import campaign as train_campaign, worker
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import freeze_sources, load_for_inference, seed_everything


LABELS={'baseline':'原分布KL·匹配对照','wasserstein':'仅新增Wasserstein',
        'multiscale':'仅新增多尺度KL','both':'Wasserstein＋多尺度KL'}


def prepare(parent):
    parent=parent.resolve()
    project=Path(__file__).resolve().parents[2]
    root=project/'recons'/('probability_shape_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
    root.mkdir()
    for name in ['data','logs']:(root/name).mkdir()
    for name in ['initial.pt','initial_expected.json','initial_seen_expected.json','source_profiles.npz','val_indices.npy','seen_indices.npy']:
        os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    os.link(parent/'indices/n1024.npy',root/'train_indices.npy')
    indices=np.load(root/'train_indices.npy')
    assert len(indices)==1024
    positions=np.unique(np.linspace(0,len(indices)-1,4,dtype=int))
    np.save(root/'calibration_indices.npy',indices[positions])
    plan=json.loads((parent/'plan.json').read_text())
    plan.update(
        experiment='2x2 probability-shape supervision:W1 and8/64-binKL',parent=str(parent),
        labels=LABELS,lanes={lane:dict(mode='shape_mass',add_wasserstein=lane in ['wasserstein','both'],
                                     add_multiscale=lane in ['multiscale','both']) for lane in LABELS},
        loss_family='probability',probability_evaluation=True,fit_windows=1024,
        training_windows_by_lane={lane:1024 for lane in LABELS},
        training_indices_files={lane:'train_indices.npy' for lane in LABELS},
        seen_indices_file='seen_indices.npy',seen_windows=8,initial_seen_evaluation=True,
        track_data_exposures=True,steps=2048,checkpoints=[128,512,1024,2048],max_seconds=14400,
        wait_for_relative=str(parent.relative_to(project)),wait_for_relatives=[str(parent.relative_to(project))],
        objective=dict(price_weight=1.,quantity_weight=1.,log_weight=1.,pair_weight=.25,topk=16,
                       shape_weight=1.,mass_weight=1.,w1_weight=1.,multiscale_weight=1.,multiscale_groups=[8,64]),
        calibration_pending=True,
        calibration_protocol='At common initial state on4equally spaced preselected positions in1024train pool, compute per-window Encoder parameter-gradient L2 of existing fineKL, rawW1 and rawmultiscaleKL. Set each newterm weight to RMS(fineKLgradient)/RMS(newtermgradient), targetratio1. BF16neural forward/FP32loss, same astraining. No optimizer updates, no development scores. Freeze coefficients before any lane starts. Combinedcase adds both calibratedterms; not renormalized to conceal interaction.',
        default_variant='baseline',viewer_default_model=2,viewer_route='probability_shape',
        viewer_source_label='共同2816步起点·8192·未做四窗微调',
        initialization='Same2816-update source model and AdamW moments as previous coverage study, before4-window fitting. Do not select a previous final lane by development performance. Same1024monthly trainingindices and seed42sampler restart for all4.',
        control_contract=dict(
            fixed=['same2816-update model+optimizer state','complete256frames,2sides,2048levels,unique64x128Z',
                   'same Softplus quantity output, nearest+conv decoder and full gradient routes',
                   'samepointHuber/log/Top16/fineKL/massloss andweights',
                   'same1024nestedmonthly trainingwindows,same8seen,same16development',
                   'same source64-training-only normalization','seed42,batch1accum4,AdamW1e-4,clip1,2048updates',
                   'sameBF16train/FP32eval,TF32off'],
            factors=['Add ordered one-dimensional Wasserstein at l/(2047)','Add mean of KL after summing contiguous8/64levels'],
            definitions='Each frame-side is a separate distribution. Invalid levels have zero mass. Zero-target-mass sides excluded fromshapeonly. CDFsum excludes finalcoordinate. Binning sums probabilitymass withzero-padding, not average logits. All newprobability computations FP32.',
            scale='Initial training-only Encodergradient RMS calibration, then fixed. Totalmass objective remains enabled. No predicted-price coordinate entersW1.',
            interaction='Both terms together form the fourth factorial case; no claim that combined improvement belongs to onefactor.',
            limit='Distributionloss may still average shapes if latent omits peaklocation. No claim that W1 guarantees sharpness or reconstruction.'),
        hypothesis='Distance-aware and multiscale mass supervision may give useful location gradients missing from pointwiseKL; test actual peak location/dynamics, not just decrease of added losses.',
        selection='Fixed2048endpoint andall checkpoints. Report fineKL,rankW1,8/64KL,totalmass errors,quantityRMSE,minutequantitychangecorrelation,10/100BTCprecision/recall/FP. Exploratoryscreen:W1>=10%below baseline andbelow source, fineKL no worse thanbaseline, quantityRMSE<=1.05xsource ANDbaseline, priceRMSE<=1.10xsource ANDbaseline, minutequantitycorr>=.10. Screening is not independent-test proof; all tradeoffs retained.',
        reference='Viewer shows exact common8192initialization; baseline is same-data,same-budget loss control. Prior data-scale endpoints are historical only.',
        viewer_description='挂量概率形态监督2×2：原分布KL对照、仅加Wasserstein、仅加8/64档多尺度KL、两项组合。四组相同2816步起点和AdamW动量、相同1024个月份覆盖训练窗/8训练诊断窗/16个2025Q1开发窗、相同8192瓶颈和Softplus输出、追加2048更新。新增系数只用4个预先指定训练窗的Encoder初始梯度RMS校准后锁定。原数量/价格/总量损失和结构均保留。2025Q1为重复使用的开发期，2026和独立测试未参与。',
        viewer_step_note='本轮追加更新；每组1024训练窗、batch1累积4；新增形态损失是唯一因素。',
        authorization='User approved the proposed W1 x multiscaleKL2x2 experiment. This bounded cohort does not start the later factorized-output architecture study.',
    )
    for key in ['gradient_routes','kl_warmup_steps','training_cache_positions','selected_training_indices']:
        plan.pop(key,None)
    atomic_json(root/'plan.json',plan)
    atomic_json(root/'plan_before_calibration.json',plan)
    previous=json.loads((parent/'data_contract.json').read_text())
    atomic_json(root/'data_contract.json',dict(input_shape=[1,256,2,2048,2],latent_shape=[1,64,128],
        reconstruction_shape=[1,256,2,2048],training_windows=1024,
        training_monthly_counts=previous['subsets']['n1024']['monthly_counts'],
        training_indices_sha256=previous['subsets']['n1024']['indices_sha256'],
        seen_training_indices=np.load(root/'seen_indices.npy').tolist(),
        development_indices=np.load(root/'val_indices.npy').tolist(),
        calibration_indices=indices[positions].tolist(),calibration_selection='4fixed evenly spaced positions, before inspecting newlosses',
        normalization='Unchanged source64training-only statistics',train_end_before_development=True))
    atomic_json(root/'status.json',dict(state='prepared'))
    (root/'README.md').write_text(
        '# 挂量概率形态监督2×2\n\n'
        '四组固定完整256分钟、唯一64×128latent、Softplus输出和最近邻上采样；共同2816步权重/AdamW起点，'
        '相同1024个月份覆盖训练窗、8个训练诊断窗、16个2025Q1开发窗，追加2048更新。\n\n'
        '已有逐档分布KL、总量和全部数值损失保留。两个因素为新增按档位距离的归一化W1、以及新增相邻8/64档概率质量求和后的KL。'
        '四组包含两项组合的交互对照。总量与形态输出参数化留到后续独立实验，本轮不改。\n\n'
        '新增系数通过预先指定4训练窗的初始Encoder梯度RMS对齐原细档KL，校准不更新模型，不读开发指标；'
        'plan_before_calibration.json保留校准前配置，calibration.json及最终plan.json记录锁定系数。\n\n'
        '同一批窗口同时评估形态KL/W1/多尺度KL、总量、数量RMSE、大单精确率/召回和分钟变化；价格对起点和匹配对照双重约束。'
        '所有结果及完整模型源码快照保存在此处，仅seed42，不使用未来收益或独立测试数据。\n')
    freeze_sources(root/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'
        f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\n'
        f'cd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.probability_shape_run "{remote}"\n')
    Path('/tmp/probability_shape_path').write_text(str(root))
    print(root,flush=True)


def calibrate(root):
    torch.set_num_threads(4);seed_everything(42);strict_precision()
    plan=json.loads((root/'plan.json').read_text())
    model,norm=load_for_inference(root/'initial.pt','cuda:0');model.train()
    flags=getattr(model,'gradient_route_config',{})
    if any(flags.values()):raise ValueError('Shape controls require the full existing gradient routes')
    ds=dataset(root,'train')
    criterion=ProbabilityBookLoss(plan['normalization']['quantity_scale'],mode='shape_mass',**plan['objective'])
    params=list(model.encoder.parameters())
    terms=['quantity_shape_kl','quantity_rank_w1','quantity_multiscale_kl']
    rows=[]
    for index in np.load(root/'calibration_indices.npy'):
        raw={k:v.unsqueeze(0) for k,v in ds[int(index)].items()}
        assert list(raw['data'].shape)==[1,256,2,2048,2]
        b=norm.prepare(raw,'cuda:0')
        with torch.autocast('cuda',dtype=torch.bfloat16):out=call(model,b,False)
        assert list(out['z'].shape)==[1,64,128]
        v=criterion(out,b)
        row=dict(training_index=int(index),encoder_gradient_l2={},raw_losses={})
        for i,key in enumerate(terms):
            gradients=torch.autograd.grad(v[key],params,allow_unused=True,retain_graph=i<len(terms)-1)
            if any(not bool(torch.isfinite(g).all()) for g in gradients if g is not None):
                raise FloatingPointError('Nonfinite calibration gradient')
            value=math.sqrt(sum(float(g.detach().float().square().sum()) for g in gradients if g is not None))
            if not math.isfinite(value) or value<=1e-20:raise RuntimeError(f'Calibration term has no usable Encoder gradient:{key}')
            row['encoder_gradient_l2'][key]=value;row['raw_losses'][key]=float(v[key].detach())
            del gradients
        rows.append(row)
        atomic_json(root/'calibration_progress.json',dict(completed_training_windows=len(rows),total=4))
        del out,v,b,raw
    rms={key:math.sqrt(sum(row['encoder_gradient_l2'][key]**2 for row in rows)/len(rows)) for key in terms}
    weights=dict(w1_weight=rms['quantity_shape_kl']/rms['quantity_rank_w1'],
                 multiscale_weight=rms['quantity_shape_kl']/rms['quantity_multiscale_kl'])
    if not all(math.isfinite(w) and w>0 for w in weights.values()):raise FloatingPointError('Invalid calibrated coefficients')
    calibration=dict(passed=True,weights=weights,encoder_gradient_rms=rms,rows=rows,
        target_ratio_to_fine_kl=1.,optimizer_updates=0,development_windows_used=0,
        neural_precision='BF16,matchingtraining',loss_precision='FP32',
        formula='weight_new=RMS_per_window(norm(grad_encoder(fineKL)))/RMS_per_window(norm(grad_encoder(rawnewterm)))',
        latent_shape=[1,64,128],parameter_count=sum(p.numel() for p in model.parameters()))
    atomic_json(root/'calibration.json',calibration)
    plan['objective'].update(weights);plan['calibration_pending']=False
    atomic_json(root/'plan.json',plan)
    del model,criterion,params
    torch.cuda.empty_cache()


def campaign(root):
    try:
        atomic_json(root/'status.json',dict(state='training_only_weight_calibration'))
        calibrate(root)
        train_campaign(root)
    except BaseException as error:
        atomic_json(root/'status.json',dict(state='failed',error=repr(error)))
        raise


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root',type=Path)
    parser.add_argument('--prepare',action='store_true')
    parser.add_argument('--lane')
    args=parser.parse_args()
    if args.prepare:prepare(args.root)
    elif args.lane:worker(args.root,args.lane)
    else:campaign(args.root)
