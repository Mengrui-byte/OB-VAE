"""Framewise Local dependence; true-mid removal is diagnostic only."""

import argparse
from datetime import datetime
import json
import os
from pathlib import Path

import numpy as np
import torch

from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import freeze_sources,load_for_inference,seed_everything
from train_dual.util.dynamics import DynamicsMetrics


LABELS={'baseline':'原Global＋Local','mean_global':'Local＋Global训练均值','zero_global':'Local＋Global置零'}


def prepare(parent):
    parent=parent.resolve();root=parent.parent/('local_frames_256_'+datetime.now().strftime('%Y%m%d_%H%M%S'));root.mkdir();(root/'data').mkdir()
    for name in ('checkpoint.pt','training_means.pt','train_indices.npy','val_indices.npy','expected_reference.json'):os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    plan=json.loads((parent/'plan.json').read_text());plan.update(parent=str(parent),experiment='Framewise Local sensitivity',labels=LABELS,
        diagnostic='No per-frame true midpoint is supplied to the decoder. Price shape RMSE subtracts each true/predicted midpoint after inference for diagnosis only. Local is post-Cross and contains exchanged global context. No training.')
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(parent.parents[1])
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.local_frame_analysis "{remote}"\n')
    Path('/tmp/local_frames_256_path').write_text(str(root));print(root,flush=True)


def run(root):
    seed_everything(42);strict_precision();torch.set_num_threads(4);model,norm=load_for_inference(root/'checkpoint.pt','cuda:0');means=torch.load(root/'training_means.pt',map_location='cpu',weights_only=False);mg=means['global_mean'].to('cuda:0')
    assert not model.compress and model.window_size==256
    val=dataset(root,'val');indices=np.load(root/'val_indices.npy');positions=set(np.unique(np.linspace(0,len(indices)-1,3,dtype=int)).tolist())
    stats={k:DynamicsMetrics(norm.tick_size) for k in LABELS};frames={k:[] for k in LABELS};profiles={k:[] for k in LABELS};truths=[];masks=[];times=[];shown=[]
    atomic_json(root/'status.json',dict(state='running'))
    try:
        with torch.inference_mode():
            for i,index in enumerate(indices):
                raw={k:v.unsqueeze(0) for k,v in val[int(index)].items()};assert list(raw['data'].shape)==[1,256,2,2048,2]
                b=norm.prepare(raw,'cuda:0');g,l=model.encode_fused(b['price'],b['volume'],b['mask'],b['tick_norm'],b['times'])
                truth=raw['data'][0].numpy().astype(np.float64);mask=b['mask'][0].cpu().numpy();n=mask.sum((1,2));p=truth[...,0];q=truth[...,1];mid=p[:,:,0].mean(1)
                for key,gh in [('baseline',g),('mean_global',mg),('zero_global',torch.zeros_like(g))]:
                    out=model.decode_latents(gh,l,b['mask'],b['tick_norm'],b['times']);pred=np.stack([norm.inverse_price(out['price_norm'],b)[0].cpu().numpy(),out['volume'][0].cpu().numpy()],-1)
                    if not np.isfinite(pred[mask]).all():raise FloatingPointError(key)
                    stats[key].update(truth,pred,mask);ph=pred[...,0];qh=pred[...,1];midh=ph[:,:,0].mean(1)
                    def rms(error):return np.sqrt(np.where(mask,error**2,0).sum((1,2))/n)
                    data=dict(price_rmse=rms(ph-p),quantity_rmse=rms(qh-q),price_shape_rmse=rms((ph-midh[:,None,None])-(p-mid[:,None,None])),mid_absolute_error=np.abs(midh-mid),log_quantity_rmse=rms(np.log1p(qh)-np.log1p(q)))
                    for t in range(256):frames[key].append(dict(window=int(index),minute=t+1,**{k:float(v[t]) for k,v in data.items()}))
                    if i in positions:profiles[key].append(pred)
                if i in positions:
                    truths.append(truth);masks.append(mask);start=int(val.base.starts[int(index)]);times.append(val.base.times[start:start+256]);shown.append(int(index))
                atomic_json(root/'progress.json',dict(windows=i+1,total=len(indices)))
        rows={}
        for key,label in LABELS.items():
            summary={}
            for metric in ('price_rmse','quantity_rmse','price_shape_rmse','mid_absolute_error','log_quantity_rmse'):
                a=np.array([r[metric] for r in frames[key]]);summary[metric]=dict(mean=float(a.mean()),median=float(np.median(a)),p90=float(np.quantile(a,.9)),p95=float(np.quantile(a,.95)),max=float(a.max()))
            rows[key]=dict(label=label,result=stats[key].finish(),frame_summary=summary,frames=frames[key])
        expected=json.loads((root/'expected_reference.json').read_text())['result']['metrics'];actual=rows['baseline']['result']['metrics']
        delta={k:abs(expected[k]['rmse']-actual[k]['rmse']) for k in ('price_usdt','quantity_btc')}
        if max(delta.values())>1e-4:raise RuntimeError(f'Baseline replay mismatch:{delta}')
        np.savez_compressed(root/'profiles.npz',truth=np.stack(truths),mask=np.stack(masks),time=np.stack(times),indices=np.array(shown),**{k:np.stack(v) for k,v in profiles.items()})
        atomic_json(root/'results.json',dict(rows=rows,frames_per_variant=len(indices)*256,baseline_replay=delta,decoder_metadata='One original first-frame anchor per256minute window; never frame-specific true anchors',local_is_post_cross=True,price_shape_metric='Offline true/predicted mid removal; not actual absolute-price reconstruction'))
        atomic_json(root/'status.json',dict(state='complete'));print('Complete4096frames per condition',flush=True)
    except BaseException as error:atomic_json(root/'status.json',dict(state='failed',error=repr(error)));raise


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');args=p.parse_args()
    if args.prepare:prepare(args.root)
    else:run(args.root)
