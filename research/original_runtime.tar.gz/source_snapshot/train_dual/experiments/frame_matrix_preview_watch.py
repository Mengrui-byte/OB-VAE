"""Publish common512/1024-step reconstruction previews without changing training."""

import argparse
import json
from pathlib import Path
import time

from train_dual.experiments.frame_matrix_checkpoint_viewer import main as publish


def watch(root):
    root=root.resolve();published=0
    plan=json.loads((root/'plan.json').read_text());lanes=plan.get('labels',('frozen_long','e2e','e2e_fast'))
    while True:
        status=json.loads((root/'status.json').read_text())['state']
        if status in ('failed','complete'):break
        ready=[step for step in (512,1024) if step>published and all(
            (root/lane/f'step{step}.pt').exists() and (root/lane/f'step{step}_evaluation.json').exists()
            for lane in lanes)]
        if ready:
            step=max(ready);publish(root,step);published=step
        time.sleep(15)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);watch(p.parse_args().root)
