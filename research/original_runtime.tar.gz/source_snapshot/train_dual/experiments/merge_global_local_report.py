"""Single-Local bottleneck report without stale16x1024 compression claims."""

import argparse
from pathlib import Path

from train_dual.experiments.full_window_report import PAGE,monitor


def main(root):
    page=PAGE.replace('256分钟双分支实验','256分钟Global合并Local').replace('完整256分钟：双分支与整窗矩阵压缩','完整256分钟：Global信息写入Local')
    begin=page.index('<p>实际输入');end=page.index('<p id=status>',begin)
    text=('<p>输入和输出均为完整256分钟。原Global＋Local为参考；其余三组仅保留Local[B,256,2,128,16]作为生成瓶颈：原Cross-Local配学习读出、残差写入Global、注意力写入Global。'
          '解码器内部Global条件完全从这份Local的空间分区均值和固定相对时间编码计算，不接收原Global或原始盘口。没有增加Local通道数，没有逐帧真实mid旁路。本轮只验证两路能否合并，尚未做16×1024压缩。</p>'
          '<p>共同起点是已完成256分钟训练的参考模型512步。三个候选先做256步训练期latent蒸馏预热，再与参考一起端到端更新512步；候选预热成本另计。'
          '同64个训练窗、16个2025Q1开发窗、seed42、batch1×累积4；BF16训练、FP32评估。32/128/256/512步保存并报告。2026与最终独立测试期未用于本轮训练或选型。</p>')
    page=page[:begin]+text+page[end:]
    page=page.replace('实际矩阵','实际Local瓶颈').replace('256分钟初始化样本','256分钟教师缓存样本')
    page=page.replace('x.history.map(',"x.history.filter(h=>h.phase==='end_to_end').map(")
    monitor(root,page=page)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);main(p.parse_args().root)
