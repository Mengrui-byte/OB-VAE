"""Matched2x2 continuation: relative log quantities x signed log spatial detail."""
import argparse
from copy import deepcopy
import html
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import numpy as np
import torch

from model.losses.log_relative_detail import RelativeDetailBookLoss
from train_dual.experiments import local_hint_run as shared
from train_dual.experiments.auxiliary_reconstruction_run import select_source,reviewed_candidate_decision,verify_detail_calibration_data
from train_dual.experiments.confirm_recall_goal import require_matching_replay
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.goal_evaluate import assess_file
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read,STYLE
from train_dual.experiments.price_safe_readout import file_hash
from train_dual.experiments.recall_goal_run import candidates,record,render as render_goal
from train_dual.experiments.region_task_run import gpu_free
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import freeze_sources,load_for_inference,seed_everything
from train_dual.util.hint_training import restore_regional_phase_adam
from train_dual.util.inherited_book_loss import inherited_book_loss
from train_dual.util.phase_training import tensor_digest
from train_dual.util.quantity_strata import evaluate_with_quantity_strata

MODULE='train_dual.experiments.log_relative_detail_run'
FACTORS=dict(control=(False,False),relative=(True,False),detail=(False,True),both=(True,True))
LABELS=dict(control='原目标接续',relative='相对log误差',detail='有符号log细节',both='相对误差＋细节')


def predecessor_live(queue,pid,proc=Path('/proc')):
    try:args=(proc/str(pid)/'cmdline').read_bytes().split(b'\0')
    except FileNotFoundError:return False
    return b'train_dual.experiments.auxiliary_reconstruction_run' in args and str(queue).encode() in args and b'--controller' in args


def prepare_queue(goal,pid):
    root=goal/'log_relative_detail_after_auxiliary_20261028';root.mkdir();(root/'logs').mkdir()
    parent=goal/'round_008_auxiliary';preparation=goal/'log_relative_detail_preparation_20261028'
    assert read(parent/'startup_control_audit.json')['passed']
    assert read(preparation/'status.json')['state']=='prepared_not_training'
    plan=dict(queue_only=True,parent=parent.name,parent_queue='auxiliary_after_factorial_20261028_v3',parent_pid=pid,
        preparation=preparation.name,steps=2048,checkpoints=[256,512,1024,2048],max_seconds=43200,wait_seconds=46800,
        factors=FACTORS,seed=42,epsilon_BTC=1e-4,radii=[1,2,4,8],gradient_norm_fraction_per_auxiliary=.25,
        source_policy='Wait normal parent termination. Among all4 largest common trained endpoints and exactly one original source0 fallback, minimize original joint-gate normalized violations. Same source across all new arms.',
        candidate_policy='Original-gate native candidates first require checkpoint-bound schema2 full16 whole-book review. Accepted candidates have confirmation priority; do not automatically consume Q2.',
        controls='Two binary loss factors with explicit combination ablation; same source parameters/all3Adam/RNG, raw order, augmentation, teacher, every inherited objective and coefficient, LR/clip/batch/accumulation4, seed42 and2048updates. No precision/activation/upsampling/latent changes.',
        shape_contract=dict(input=[1,256,2,2048,2],latent=[1,64,128],output=[1,256,2,2048]),
        original_goal_contract_unchanged=True,quantity_strata_metrics_schema=2,
        base_scale_policy='Preserve actual source RMS/weights. New physical-log detail RMS is separately train-only; no refit of inherited scales.')
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared_not_started'));freeze_sources(root/'source_snapshot')
    project=Path(__file__).resolve().parents[2];remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 CUDA_DEVICE_ORDER=PCI_BUS_ID OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m {MODULE} "{remote}" --controller >> "{remote}/logs/controller.log" 2>&1\n')
    render(root);record(goal,'log_relative_detail_queue_prepared',wave=root.name,parent_pid=pid);print(root.resolve(),flush=True)


def criterion(root,lane,device='cuda:0',*,calibrating=False):
    p=read(root/'plan.json');c=read(root/'relative_detail_calibration.json');d=read(root/'log_detail_calibration.json')
    if not calibrating and not (c['state']=='complete' and c['weight_calibration_locked']):raise ValueError('Both auxiliary calibrations must be locked before training')
    base=inherited_book_loss(p['source_loss_metadata'],p,lane,read(root/'calibration.json'),read(root/'quantity_calibration.json'),read(root/'detail_calibration.json',{}))
    relative,detail=FACTORS[lane]
    return RelativeDetailBookLoss(base,detail_scales=d['RMS_scales'],epsilon=p['epsilon_BTC'],radii=tuple(d['radii']),
        relative_weight=0. if calibrating or not relative else c['relative_weight'],
        detail_weight=0. if calibrating or not detail else c['detail_weight']).to(device)


def prepare_actual(queue,selected,endpoint):
    goal=queue.parent;study=read(queue/'plan.json');parent=goal/study['parent'];old=read(parent/'plan.json')
    preparation=goal/study['preparation'];data_audit=verify_detail_calibration_data(parent,preparation)
    source=parent/'source.pt' if selected['step']==0 else parent/selected['lane']/f"step{selected['step']}.pt"
    payload=torch.load(source,map_location='cpu',weights_only=False,mmap=True)
    assert payload['epoch_boundary'] and len(payload['optimizer']['param_groups'])==3 and 'relative_detail_loss_config' not in payload
    model,_=load_for_inference(source,'cpu');opt=restore_regional_phase_adam(model,payload['optimizer'],old['original_parameter_names'])
    assert opt.state_dict()['param_groups']==payload['optimizer']['param_groups']
    root=goal/'round_009_relative_detail';root.mkdir()
    for name in ['data','logs','seen','unseen',*LABELS]:(root/name).mkdir()
    for split in ['seen','unseen']:
        for lane in LABELS:(root/split/lane).mkdir()
    for name in ['source.pt','initial.pt']:os.link(source,root/name)
    for name in ['teacher.pt','calibration.json','train_indices.npy','val_indices.npy','seen_indices.npy','unseen_indices.npy','quantity_calibration_indices.npy','plotly.min.js']:
        os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    from shutil import copy2
    copy2(parent/'quantity_calibration.json',root/'quantity_calibration.json')
    if (parent/'detail_calibration.json').exists():copy2(parent/'detail_calibration.json',root/'detail_calibration.json')
    copy2(preparation/'detail_calibration.json',root/'log_detail_calibration.json')
    atomic_json(root/'calibration_data_identity.json',data_audit)
    keys=['train','development','independent_test_untouched','window_size','stride','normalization','model_config','local_hint_config',
        'original_parameter_names','objective','source_FP_rule','augmentation','lr','weight_decay','clip_grad','batch_size','accumulation','seed',
        'beta','sample','input_shape','latent_shape','output_shape','precision']
    p={k:deepcopy(old[k]) for k in keys if k in old}
    source_lane='control' if selected['step']==0 else selected['lane'];spec=old['lanes'][source_lane]
    metadata={k:deepcopy(payload[k]) for k in ['regional_phase_config','stratified_quantity_loss_config','mid_lowpass_loss_config','local_detail_loss_config','precision_policy_config','branch_precision_config'] if k in payload}
    assert 'regional_phase_config' in metadata
    configs={lane:dict(epsilon_BTC=study['epsilon_BTC'],radii=study['radii'],detail_RMS=read(root/'log_detail_calibration.json')['RMS_scales'],
        relative_enabled=flags[0],detail_enabled=flags[1],relative_weight=None,detail_weight=None) for lane,flags in FACTORS.items()}
    extras={lane:dict(deepcopy(metadata),relative_detail_loss_config=configs[lane],
        training_numeric_policy=deepcopy(payload.get('training_numeric_policy',{})),inference_numeric_policy=deepcopy(payload.get('inference_numeric_policy',{}))) for lane in LABELS}
    p.update(experiment='相对log挂量误差×有符号log局部细节2x2',labels=LABELS,lanes={lane:deepcopy(spec) for lane in LABELS},
        source_loss_metadata=metadata,source_selection=selected,selection_common_endpoint=endpoint,source_sha256=file_hash(source),
        source_steps=payload['source_steps']+payload['step'],source_evaluation_relative=f"../{parent.name}/{source_lane}/step{selected['step']}_development.json",
        source_checkpoint_relative=str(source.relative_to(goal)),initial_model_sha256=tensor_digest(model),checkpoint_extras=extras,
        auxiliary_kind='relative_log_x_signed_log_detail',relative_detail_factorial=True,epsilon_BTC=study['epsilon_BTC'],radii=study['radii'],
        gradient_norm_fraction_per_auxiliary=study['gradient_norm_fraction_per_auxiliary'],steps=study['steps'],checkpoints=study['checkpoints'],
        max_seconds=study['max_seconds'],gpu_workers=[[gpu,lane] for gpu,lane in zip([2,3,4,5],LABELS)],worker_module=MODULE,
        controls=study['controls'],loss_variant='log_relative_x_signed_log_detail',new_model_parameters=0,quantity_strata_metrics_schema=2,
        original_goal_contract_unchanged=True,parent_price_rmse_USDT=selected['price_rmse'],parent_price_limit_USDT=1.1*selected['price_rmse'],
        preview_descriptions={lane:'完整256分钟/唯一8192Gaussian；两种挂量损失单独及组合对照。Q1反复用于开发，非独立测试。' for lane in LABELS})
    assert p['input_shape']==[1,256,2,2048,2] and p['latent_shape']==[1,64,128] and p['output_shape']==[1,256,2,2048]
    atomic_json(root/'plan.json',p)
    atomic_json(root/'relative_detail_calibration.json',dict(state='needs_actual_GPU_gradient_calibration',weight_calibration_locked=False,
        relative_weight=None,detail_weight=None,training_indices=np.load(root/'quantity_calibration_indices.npy').tolist(),optimizer_updates=0))
    for split in ['seen','unseen']:
        atomic_json(root/split/'plan.json',dict(p,preview_descriptions={lane:'训练年代诊断，非独立测试。' for lane in LABELS}));os.link(root/'plotly.min.js',root/split/'plotly.min.js')
    atomic_json(root/'status.json',dict(state='prepared_requires_actual_GPU_calibration'));freeze_sources(root/'source_snapshot');render(root);return root


def calibrate(root):
    torch.set_num_threads(4);seed_everything(42);strict_precision();p=read(root/'plan.json');c=read(root/'relative_detail_calibration.json')
    assert not c['weight_calibration_locked'] and file_hash(root/'source.pt')==p['source_sha256']
    model,norm=load_for_inference(root/'source.pt','cuda:0');model.train();before=tensor_digest(model)
    teacher,tn=load_for_inference(root/'teacher.pt','cuda:0');teacher.eval().requires_grad_(False);teacher_before=tensor_digest(teacher)
    obj=criterion(root,'control',calibrating=True);data=dataset(root,'train');params=list(model.encoder.mu.parameters())
    squares={k:[] for k in ['base','relative','detail']};cosines={k:[] for k in ['relative','detail']}
    indices=np.load(root/'quantity_calibration_indices.npy');assert len(indices)==8 and set(indices.tolist())<=set(np.load(root/'train_indices.npy').tolist())
    for n,index in enumerate(indices):
        raw={k:v.unsqueeze(0) for k,v in data[int(index)].items()};assert list(raw['data'].shape)==p['input_shape']
        offset=int(data.base.starts[int(index)]);assert np.all(np.diff(data.base.times[offset:offset+256]//60000000)==1)
        target=shared.teacher_local(teacher,tn,raw);b=norm.prepare(raw,'cuda:0');seen=[]
        hooks=[decoder.register_forward_pre_hook(lambda m,args:seen.append(args[0])) for decoder in [model.price_decoder,model.volume_decoder]]
        with torch.autocast('cuda',dtype=torch.bfloat16):out=call(model,b,False)
        for hook in hooks:hook.remove()
        assert seen[0] is seen[1] is out['z'] and list(out['z'].shape)==p['latent_shape'] and list(out['volume'].shape)==p['output_shape']
        values=obj(out,b,teacher_local=target)
        gradients={}
        for number,(key,field) in enumerate([('base','pre_relative_detail_loss'),('relative','relative_quantity_log'),('detail','signed_log_quantity_detail')]):
            grad=torch.autograd.grad(values[field],params,retain_graph=number<2)
            assert all(torch.isfinite(g).all() for g in grad)
            gradients[key]=grad;squares[key].append(sum(float(g.float().square().sum()) for g in grad))
        for key in ['relative','detail']:
            dot=sum(float((a.float()*b.float()).sum()) for a,b in zip(gradients['base'],gradients[key]));den=(squares['base'][-1]*squares[key][-1])**.5
            cosines[key].append(dot/den if den else None)
        atomic_json(root/'gradient_calibration_progress.json',dict(windows=n+1,total=8,optimizer_updates=0))
    norms={key:float(np.mean(values))**.5 for key,values in squares.items()};assert all(v>0 and math.isfinite(v) for v in norms.values())
    assert tensor_digest(model)==before and tensor_digest(teacher)==teacher_before and all(parameter.grad is None for parameter in model.parameters())
    ratio=p['gradient_norm_fraction_per_auxiliary']
    c.update(state='complete',weight_calibration_locked=True,relative_weight=ratio*norms['base']/norms['relative'],detail_weight=ratio*norms['base']/norms['detail'],
        mu_head_root_mean_square_L2_norms=norms,per_window_gradient_cosines=cosines,gradient_norm_fraction_per_auxiliary=ratio,
        student_forwards=8,teacher_feature_extractions=8,optimizer_updates=0,source_and_teacher_unchanged=True,
        actual_input=p['input_shape'],actual_latent=p['latent_shape'],actual_output=p['output_shape'],shared_single_Z=True)
    assert file_hash(root/'source.pt')==p['source_sha256'];atomic_json(root/'relative_detail_calibration.json',c)
    for lane,(relative,detail) in FACTORS.items():
        p['checkpoint_extras'][lane]['relative_detail_loss_config'].update(relative_weight=c['relative_weight'] if relative else 0.,detail_weight=c['detail_weight'] if detail else 0.)
    atomic_json(root/'plan.json',p);render(root)


def startup_relation(rows,relative_weight,detail_weight):
    base=rows['control']
    for lane,(relative,detail) in FACTORS.items():
        row=rows[lane];assert row['training_indices']==base['training_indices'] and row['edits']==base['edits']
        for key in ['pre_relative_detail_loss','relative_quantity_log','signed_log_quantity_detail']:
            assert row['losses'][key]==base['losses'][key]
        expected=base['losses']['loss']+relative*relative_weight*base['losses']['relative_quantity_log']+detail*detail_weight*base['losses']['signed_log_quantity_detail']
        assert math.isclose(row['losses']['loss'],expected,rel_tol=5e-6,abs_tol=5e-6)


def audit_startup(root):
    rows={lane:read(root/lane/'step1_data_audit.json',{}) for lane in LABELS}
    if not all(rows.values()) or not all((root/lane/'step8_gradient_audit.json').exists() for lane in LABELS):return False
    p=read(root/'plan.json');c=read(root/'relative_detail_calibration.json');startup_relation(rows,c['relative_weight'],c['detail_weight'])
    old=torch.load(root/'source.pt',map_location='cpu',weights_only=False,mmap=True);source=read(root/p['source_evaluation_relative'])['result']
    for lane in LABELS:
        require_matching_replay(read(root/lane/'step0_development.json')['result'],source)
        assert read(root/lane/'actual_shape_contract.json')['passed'] and read(root/lane/'restore_audit.json')['restored_groups']==3
        new=torch.load(root/lane/'step0.pt',map_location='cpu',weights_only=False,mmap=True)
        assert old['model'].keys()==new['model'].keys()
        for name,value in old['model'].items():torch.testing.assert_close(value,new['model'][name],rtol=0,atol=0)
        assert old['optimizer']['param_groups']==new['optimizer']['param_groups'] and old['optimizer']['state'].keys()==new['optimizer']['state'].keys()
        for index,state in old['optimizer']['state'].items():
            for key,value in state.items():
                if torch.is_tensor(value):torch.testing.assert_close(value,new['optimizer']['state'][index][key],rtol=0,atol=0)
                else:assert value==new['optimizer']['state'][index][key]
    atomic_json(root/'startup_control_audit.json',dict(passed=True,same_source_all3Adam_and_RNG=True,
        same_inputs_and_unweighted_objectives=True,only_two_declared_loss_flags_change=True,
        same_native_step0_replayed=True,full256_unique8192_singleZ_verified=True));return True


def checkpoint_analysis(root,step):
    dest=root/f'common{step}_analysis.json'
    if dest.exists() or not all((root/lane/f'step{step}_development.json').exists() for lane in LABELS):return
    rows=[row for row in candidates(root,root.parent/'reference_evaluation.json') if row['step']==step]
    atomic_json(dest,dict(step=step,design='relative_log_x_signed_log_detail',rows=rows));record(root.parent,'log_relative_detail_common_checkpoint',step=step,rows=rows)


def render(root):
    p=read(root/'plan.json');status=read(root/'status.json',{});text='<h1>相对挂量误差 × 有符号局部细节</h1>'
    if p.get('queue_only'):text+='<p>等待当前四组正常结束及候选质量审查。固定一个来源后四卡比较原目标、相对log误差、log局部细节、两者组合。</p>'
    else:
        text+='<p>完整256分钟、双侧2048档、唯一64×128Gaussian，无Encoder跳接。只改变两项新增损失的开关；保留来源全部损失/权重、模型、精度、上采样、三组Adam与RNG。</p><table><tr><th>组</th><th>更新步</th><th>共同/已评估步</th><th>召回</th><th>精确率</th><th>价格RMSE USDT</th></tr>'
        for lane,label in LABELS.items():
            paths=sorted((root/lane).glob('step*_development.json'),key=lambda f:int(f.name.split('_')[0][4:]));latest=paths[-1] if paths else None
            row=[label,read(root/lane/'progress.json',{}).get('step',0)]
            if latest:
                a=assess_file(latest,root.parent/'reference_evaluation.json');row += [int(latest.name.split('_')[0][4:]),f"{a['recall100']:.2%}",f"{a['precision100']:.2%}" if a['precision100'] is not None else '—',f"{a['price_rmse']:.4f}"]
            else:row+=['待评估']*4
            text+='<tr>'+''.join('<td>'+html.escape(str(x))+'</td>' for x in row)+'</tr>'
        text+='</table><p>系数只用8个既有训练窗的实际GPU梯度范数校准，每项目标为原mu头梯度范数的0.25倍。两项都关闭时原目标损失与梯度精确保持。不同步结果不作效果排名。</p>'
    text+='<p>状态：'+html.escape(str(status))+'</p><p>大小单与价格需共同审查；Q1反复用于开发，不是独立测试。不会自动读取Q2或宣布目标完成。</p><p><a href="plan.json">协议</a> · <a href="status.json">状态</a> · <a href="../">目标总览</a></p>'
    (root/'index.html').write_text('<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="30"><style>'+STYLE+'</style>'+text)


def run_cohort(root,*,worker_module=MODULE,startup_auditor=audit_startup,renderer=render,analyzer=checkpoint_analysis):
    p=read(root/'plan.json');children=[];begin=time.monotonic();audited=False
    try:
        for gpu,lane in p['gpu_workers']:
            env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),PYTHONPATH=str(root/'source_snapshot'))
            with (root/'logs'/f'{lane}.log').open('ab',buffering=0) as f:
                children.append(subprocess.Popen([sys.executable,'-u','-m',worker_module,str(root),'--lane',lane],cwd=root/'source_snapshot',env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True))
        atomic_json(root/'status.json',dict(state='running',controller_pid=os.getpid(),pids=[child.pid for child in children]));renderer(root)
        while any(child.poll() is None for child in children):
            if any(child.poll() not in [None,0] for child in children):raise RuntimeError('Owned relative/detail worker failed')
            if time.monotonic()-begin>p['max_seconds']+1800:raise TimeoutError('12hour training plus30min evaluation ceiling')
            if not audited:audited=startup_auditor(root)
            for step in p['checkpoints']:analyzer(root,step)
            renderer(root);time.sleep(10)
        if any(child.returncode for child in children) or not (audited or startup_auditor(root)):raise RuntimeError('Controlled cohort startup or worker incomplete')
        for step in p['checkpoints']:analyzer(root,step)
        atomic_json(root/'status.json',dict(state='complete',controller_pid=os.getpid(),elapsed_seconds=time.monotonic()-begin));renderer(root)
    finally:
        for child in children:
            if child.poll() is None:os.killpg(child.pid,signal.SIGTERM)


def controller(queue):
    p=read(queue/'plan.json');goal=queue.parent;parent=goal/p['parent'];parent_queue=goal/p['parent_queue'];begin=time.monotonic()
    while True:
        state=read(parent/'status.json',{});live=predecessor_live(parent_queue,p['parent_pid'])
        if state.get('state')=='failed' or read(parent_queue/'status.json',{}).get('state')=='failed':raise RuntimeError('Parent failed; do not continue from partial data')
        if not live:
            if state.get('state')=='complete':break
            raise RuntimeError('Verified parent controller missing without complete terminal state')
        if time.monotonic()-begin>p['wait_seconds']:raise TimeoutError('Parent wait ceiling')
        atomic_json(queue/'status.json',dict(state='verified_wait_parent',pid=os.getpid(),parent_pid=p['parent_pid']));render(queue);time.sleep(20)
    assert read(parent/'startup_control_audit.json')['passed']
    assert all(read(parent/lane/'status.json')['state'] in ['complete','budget_complete'] for lane in read(parent/'plan.json')['labels'])
    rows=candidates(parent,goal/'reference_evaluation.json');qualified=[row for row in rows if row['pass']]
    existing=read(goal/'candidate_for_confirmation.json',{})
    if existing and assess_file(Path(existing['evaluation']),goal/'reference_evaluation.json')['pass']:qualified.append(existing)
    if qualified:
        candidate=max(qualified,key=lambda row:(row['recall100'],-row['price_rmse']));decision=reviewed_candidate_decision(goal,candidate)
        while decision is None:
            if time.monotonic()-begin>p['wait_seconds']:raise TimeoutError('Autonomous whole-book review pending')
            atomic_json(queue/'status.json',dict(state='waiting_whole_book_review',pid=os.getpid(),candidate=candidate));render(queue);time.sleep(20)
            decision=reviewed_candidate_decision(goal,candidate)
        if decision:
            atomic_json(queue/'status.json',dict(state='not_run_accepted_candidate_requires_confirmation',candidate=candidate));render(queue);return
    selected,endpoint=select_source(rows,lanes=tuple(read(parent/'plan.json')['labels']))
    atomic_json(queue/'source_selection.json',dict(selected=selected,largest_common_endpoint=endpoint,all_rows=rows,scope='Repeated Q1 development only; fixed original contract unchanged.'))
    while any(gpu_free().get(g,0)<47000 for g in [2,3,4,5]):
        if time.monotonic()-begin>p['wait_seconds']:raise TimeoutError('GPU release wait ceiling')
        atomic_json(queue/'status.json',dict(state='verified_wait_GPU_release',pid=os.getpid()));render(queue);time.sleep(10)
    root=prepare_actual(queue,selected,endpoint)
    atomic_json(queue/'status.json',dict(state='training_only_gradient_calibration',pid=os.getpid(),wave=root.name));render(queue)
    env=dict(os.environ,CUDA_VISIBLE_DEVICES='2',PYTHONPATH=str(root/'source_snapshot'))
    with (root/'logs/gradient_calibration.log').open('ab',buffering=0) as f:
        result=subprocess.run([sys.executable,'-u','-m',MODULE,str(root),'--calibrate'],cwd=root/'source_snapshot',env=env,stdout=f,stderr=subprocess.STDOUT,timeout=3600)
    if result.returncode or not read(root/'relative_detail_calibration.json')['weight_calibration_locked']:raise RuntimeError('Relative/detail GPU calibration failed before updates')
    atomic_json(queue/'status.json',dict(state='running',pid=os.getpid(),wave=root.name));render(queue)
    atomic_json(goal/'status.json',dict(state='running_log_relative_detail_factorial',wave=root.name));run_cohort(root)
    new=candidates(root,goal/'reference_evaluation.json');old=read(goal/'candidates.json',{}).get('rows',[])
    atomic_json(goal/'candidates.json',dict(rows=[row for row in old if row.get('experiment')!=root.name]+[dict(row,experiment=root.name) for row in new]))
    atomic_json(goal/'status.json',dict(state='relative_detail_complete_requires_joint_review',wave=root.name,goal_achieved=False))
    atomic_json(queue/'status.json',dict(state='complete',wave=root.name,goal_automatically_completed=False));render(queue);render_goal(goal)
    record(goal,'log_relative_detail_cohort_complete',wave=root.name,next='Review original goal, matched price and whole-book six-bin recovery before freezing any native candidate; no automatic Q2.')


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('root',type=Path);parser.add_argument('--prepare',action='store_true');parser.add_argument('--parent-pid',type=int)
    parser.add_argument('--controller',action='store_true');parser.add_argument('--calibrate',action='store_true');parser.add_argument('--lane',choices=list(LABELS));args=parser.parse_args();root=args.root.resolve()
    def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        if args.prepare:
            if not args.parent_pid:parser.error('--parent-pid required')
            prepare_queue(root,args.parent_pid)
        elif args.controller:controller(root)
        elif args.calibrate:calibrate(root)
        elif args.lane:
            shared.evaluate=evaluate_with_quantity_strata
            shared.worker(root,args.lane,objective_factory=criterion,optimizer_factory=restore_regional_phase_adam)
        else:parser.error('Specify a mode')
    except BaseException as error:
        if not args.prepare:atomic_json((root/args.lane if args.lane else root)/'status.json',dict(state='failed',pid=os.getpid(),error=repr(error)))
        raise


if __name__=='__main__':main()
