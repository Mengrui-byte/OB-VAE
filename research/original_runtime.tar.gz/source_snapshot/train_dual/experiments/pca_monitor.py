"""Local progress publication and automatic frozen/final book reports."""

import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from datetime import datetime,timezone


PAGE=r'''<!doctype html><meta charset=utf-8><title>PCA窗口状态实验进度</title><style>body{font:17px system-ui;max-width:1400px;margin:35px auto;padding:0 20px;color:#162235}p{line-height:1.8}table{border-collapse:collapse;width:100%}td,th{padding:11px;border:1px solid #d8dfe9;text-align:left}a{color:#2563eb}</style><h1>直接分组PCA：1024 / 512 / 256维窗口向量</h1><p>8192个训练窗口拟合PCA；源编码器、cross融合和PCA固定，比较原生成器与适配后的生成器。全窗口只输出一个[B,D]向量，没有16-token提前聚合。只运行种子42。</p><p id=status>加载中</p><table><thead><tr><th>GPU</th><th>方案</th><th>阶段</th><th>更新/256</th><th>损失</th><th>显存GiB</th></tr></thead><tbody id=lanes></tbody></table><h2>阶段A：冻结生成器</h2><table><thead><tr><th>方案</th><th>价格RMSE</th><th>数量RMSE</th><th>斜率RMSE</th><th>分钟变化RMSE</th><th>大额召回</th></tr></thead><tbody id=frozen></tbody></table><h2>阶段B：最近共同验证</h2><p>各组在64/128/192/256步评估；更新次数不同的结果用于观察曲线，最终按相同256步比较。</p><table><thead><tr><th>方案</th><th>验证步数</th><th>价格RMSE</th><th>数量RMSE</th><th>斜率RMSE</th><th>分钟变化RMSE</th><th>大额召回</th></tr></thead><tbody id=latest></tbody></table><p id=allocation></p><p id=selection></p><p><a href=./>打开已生成的逐档挂单线图</a> · <a href=previous/>上一轮窗口聚合结果</a></p><small id=updated></small><script>const labels={reference:'未压缩对照',d1024:'PCA1024维',d512:'PCA512维',d256:'PCA256维'};function row(vals){let r=document.createElement('tr');for(let x of vals){let t=document.createElement('td');t.textContent=x;r.append(t)}return r}function numbers(r){let m=r.metrics;return[m.price_usdt.rmse.toFixed(3),m.quantity_btc.rmse.toFixed(4),m.spatial_slope_64_levels_usdt_per_level.rmse.toFixed(6),m.temporal_mid_1_minutes_usdt_per_minute.rmse.toFixed(3),(r.thresholds['100'].recall*100).toFixed(1)+'%']}async function refresh(){let d=await(await fetch('pca_progress.json?t='+Date.now())).json();document.getElementById('status').textContent='状态：'+d.status.state+(d.status.error?'；'+d.status.error:'');let p=[],a=[],b=[];Object.entries(labels).forEach(([name,label],i)=>{let x=d.lanes[name]||{},v=x.progress||{};p.push(row([i+2,label,x.status?.state==='complete'?'已完成':v.state||'初始化',v.step??'—',v.loss?.toFixed(5)??'—',v.reserved_gib?.toFixed(1)??'—']));if(x.frozen)a.push(row([label,...numbers(x.frozen.result)]));let y=x.final||x.latest;if(y)b.push(row([label,y.step,...numbers(y.result)]))});document.getElementById('lanes').replaceChildren(...p);document.getElementById('frozen').replaceChildren(...a);document.getElementById('latest').replaceChildren(...b);document.getElementById('allocation').textContent=d.fit?'global配额 '+d.fit.global_components+'维；其余为local，配额与PCA均仅由训练期确定。':'';document.getElementById('selection').textContent=d.selection?'满足全部预定阈值的最小维度：冻结 '+d.selection.frozen+'，适配 '+d.selection.final+'（null表示无合格候选）':'等待最终同预算比较';document.getElementById('updated').textContent='更新：'+new Date(d.utc).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai'})}refresh().catch(console.error);setInterval(()=>refresh().catch(console.error),5000)</script>'''


def run(root):
    public=root/'public';public.mkdir(exist_ok=True)
    selector=root.parents[1]/'.local/dual_viewer/current.json'
    previous=Path(json.loads(selector.read_text())['directory'])
    if not (public/'previous').exists():(public/'previous').symlink_to(previous,target_is_directory=True)
    (public/'index.html').write_text(PAGE);(public/'pca.html').write_text(PAGE)
    def select(folder):
        p=selector.with_suffix('.tmp');p.write_text(json.dumps({'directory':str(folder)},indent=2));p.replace(selector)
    select(public)
    def publish(stage):
        marker=root/('published_'+stage+'.json')
        if marker.exists() or (root/('report_error_'+stage+'.json')).exists():return
        env=dict(os.environ,PYTHONPATH=str(root/'report_sources'),PYTHONDONTWRITEBYTECODE='1')
        with (root/('report_'+stage+'.log')).open('ab') as log:
            p=subprocess.run([sys.executable,'-m','train_dual.experiments.pca_report',str(root),'--stage',stage],
                cwd=root/'report_sources',env=env,stdout=log,stderr=subprocess.STDOUT)
        if p.returncode==0:
            folder=root/('viewer_'+stage);marker.write_text(json.dumps({'directory':str(folder)},indent=2));select(folder)
        else:(root/('report_error_'+stage+'.json')).write_text(json.dumps({'returncode':p.returncode}))
    while True:
        try:
            status=json.loads((root/'status.json').read_text());lanes={}
            for lane in ('reference','d1024','d512','d256'):
                values={}
                for key,file in [('progress','progress.json'),('status','status.json'),('frozen','frozen_evaluation.json'),('latest','latest_evaluation.json'),('final','final_evaluation.json')]:
                    p=root/lane/file
                    if p.exists():values[key]=json.loads(p.read_text())
                lanes[lane]=values
            data=dict(utc=datetime.now(timezone.utc).isoformat(),status=status,lanes=lanes)
            if (root/'pca_fit.json').exists():data['fit']=json.loads((root/'pca_fit.json').read_text())
            if (root/'comparison.json').exists():data['selection']=json.loads((root/'comparison.json').read_text())['minimum_dimension']
            p=public/'pca_progress.json.tmp';p.write_text(json.dumps(data));p.replace(public/'pca_progress.json')
            if all((root/lane/'frozen_profiles.npz').exists() for lane in ('d1024','d512','d256')):publish('frozen')
            if status['state']=='complete':publish('final');break
            if status['state'] in ('failed','stopped_by_user'):break
        except (FileNotFoundError,ValueError):pass
        time.sleep(10)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);run(p.parse_args().root)
