"""Read-only, common-checkpoint fit versus development analysis."""
import argparse
import html
import json
from pathlib import Path

import plotly.graph_objects as go
from plotly.subplots import make_subplots


def report(root, step):
    root = root.resolve()
    plan = json.loads((root / 'plan.json').read_text())
    rows, initial = {}, {}
    for lane in plan['lanes']:
        rows[lane], initial[lane] = {}, {}
        for role, suffix in [('train', '_seen'), ('development', '')]:
            rows[lane][role] = json.loads((root / lane / f'step{step}{suffix}_evaluation.json').read_text())['result']
            initial[lane][role] = json.loads((root / lane / f'initial{suffix}_evaluation.json').read_text())['result']
    folder = root / 'results' / f'step{step}'
    folder.mkdir(parents=True, exist_ok=True)
    payload = dict(common_step=step, rows=rows, initial=initial,
                   scope='seed42;4train windows;16reused2025Q1development windows;not independent test')
    (folder / 'comparison.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n')
    text = ['<!doctype html><html lang=zh-CN><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1">',
            '<title>数量损失分配：训练拟合与开发集</title><script src=../../public/plotly.min.js></script>',
            '<style>body{font:16px/1.8 system-ui;max-width:1400px;margin:28px auto;padding:0 20px;color:#1e293b}table{border-collapse:collapse;width:100%}td,th{border:1px solid #ddd;padding:8px;text-align:right}td:first-child,th:first-child{text-align:left}.table{overflow:auto}.note{background:#fff7ed;padding:16px}a{color:#2563eb}</style>',
            f'<h1>数量损失分配：共同追加第{step}步</h1>',
            '<p>四组相同起点（累计2816更新）、相同模型与完整梯度回传；只有全局数量Huber系数1/8、Top16数量Huber系数0.25/0两个因素变化。'
            '4个预选完整256分钟训练窗用于拟合诊断，16个2025Q1窗口用于开发。归一化沿用原64训练窗统计，seed42；2026和独立测试未参与。</p>',
            '<p class=note>训练样本开始学到部分数量结构，但当前开发集四组数量及价格误差均高于共同起点，数量时间变化相关性约0。'
            '相对本轮退化对照的改善不能直接解释为超过原模型。Top16偏重导致的幅度/误报权衡仍存在；尚无泛化成功证据。</p>']
    for role, title in [('train', '同4个训练窗口'), ('development', '同16个开发窗口')]:
        text += [f'<h2>{title}</h2><div class=table><table><thead><tr><th>方案</th><th>价格RMSE USDT</th><th>数量RMSE BTC</th>'
                 '<th>相对起点数量RMSE变化</th><th>分钟log数量变化相关性</th><th>≥100BTC精确率</th><th>≥100BTC召回</th></tr></thead><tbody>']
        def row(label, d, change=None):
            m, t = d['metrics'], d['thresholds']['100']
            precision = '无预测' if t['precision'] is None else f"{t['precision']:.2%}"
            delta = '—' if change is None else f'{change:+.2%}'
            return (f'<tr><td>{html.escape(label)}</td><td>{m["price_usdt"]["rmse"]:.3f}</td>'
                    f'<td>{m["quantity_btc"]["rmse"]:.5f}</td><td>{delta}</td>'
                    f'<td>{m["temporal_log_quantity_1_minutes"]["correlation"]:.5f}</td>'
                    f'<td>{precision}</td><td>{t["recall"]:.2%}</td></tr>')
        text.append(row('共同起点', initial['baseline'][role]))
        for lane, label in plan['labels'].items():
            d = rows[lane][role]
            change = d['metrics']['quantity_btc']['rmse'] / initial[lane][role]['metrics']['quantity_btc']['rmse'] - 1
            text.append(row(label, d, change))
        text.append('</tbody></table></div>')
    fig = make_subplots(rows=2, cols=2, subplot_titles=['训练数量RMSE BTC', '开发数量RMSE BTC',
                                                      '训练分钟数量变化相关性', '开发价格RMSE USDT'])
    colors = ['#d97706', '#db2777', '#2563eb', '#16a34a']
    for (lane, label), color in zip(plan['labels'].items(), colors):
        history = [0, *[s for s in plan['checkpoints'] if s <= step]]
        for role, metric, field, rr, cc in [('train','quantity_btc','rmse',1,1),
                                         ('development','quantity_btc','rmse',1,2),
                                         ('train','temporal_log_quantity_1_minutes','correlation',2,1),
                                         ('development','price_usdt','rmse',2,2)]:
            ys = []
            for s in history:
                suffix = '_seen' if role == 'train' else ''
                name = f'initial{suffix}_evaluation.json' if s == 0 else f'step{s}{suffix}_evaluation.json'
                d = json.loads((root/lane/name).read_text())['result']
                ys.append(d['metrics'][metric][field])
            fig.add_trace(go.Scatter(x=history, y=ys, name=label, legendgroup=lane,
                                    showlegend=(rr==1 and cc==1), mode='lines+markers', line=dict(color=color)), row=rr, col=cc)
    fig.update_xaxes(title_text='本轮追加更新步数')
    fig.update_layout(template='plotly_white', height=850, legend=dict(orientation='h', y=-.16))
    text += [fig.to_html(full_html=False, include_plotlyjs=False),
             '<p>大单指标指同帧、同侧、同档位聚合挂量；训练召回提高需同时检查误报和全局误差。'
             '本轮刻意缩小到4个窗口，开发退化与小样本过拟合/分布差异相符，尚不能排除其他因素。</p>',
             f'<p><a href=../../previews/step{step}/viewer/>打开第{step}步完整256帧、每档一条线的重建图</a> · '
             '<a href=../../public/>实时进度与全部指标</a></p></html>']
    (folder / 'index.html').write_text('\n'.join(text))
    print(folder, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    parser.add_argument('--step', type=int, required=True)
    args = parser.parse_args()
    report(args.root, args.step)
