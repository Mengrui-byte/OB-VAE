"""Raw-data sparsity bounds; these are oracle statistics, never model scores."""
import argparse
import json
from pathlib import Path
import time

import numpy as np

from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.long_worker import atomic_json


def audit(root,output):
    output.mkdir(parents=True,exist_ok=True);result={};started=time.monotonic()
    for split,index_name in [('train','train_indices.npy'),('val','val_indices.npy')]:
        data=dataset(root,split);indices=np.load(root/index_name)
        totals=np.zeros(3,np.float64);peaks=[];coverage={k:0 for k in [1,2,3,4,6,8,16]}
        side_coverage={k:0 for k in [1,2,4,8]}
        for n,index in enumerate(indices):
            raw=data[int(index)];q=raw['data'][...,1].numpy();counts=raw['level_counts'].numpy()
            valid=np.arange(q.shape[-1])<counts[...,None]
            if q.shape!=(256,2,2048):raise ValueError('Full256minute2048level book required')
            large=(q>=100)&valid;per_side=large.sum(-1);per_frame=per_side.sum(-1)
            totals+=[int(valid.sum()),int(large.sum()),int((q[valid].astype(np.float64)**2).sum())]
            peaks.extend(per_frame.tolist())
            for k in coverage:coverage[k]+=int(np.minimum(per_frame,k).sum())
            for k in side_coverage:side_coverage[k]+=int(np.minimum(per_side,k).sum())
            if n%32==0:atomic_json(output/'progress.json',dict(split=split,windows=n+1,total=len(indices),elapsed_seconds=time.monotonic()-started))
        count=int(totals[1]);result[split]=dict(windows=len(indices),valid_levels=int(totals[0]),true_large_positions=count,
            mean_large_per_frame=float(np.mean(peaks)),max_large_per_frame=int(max(peaks)),large_per_frame_quantiles={str(p):float(np.quantile(peaks,p)) for p in [.5,.9,.99,.999]},
            global_topk_oracle_recall={str(k):v/count if count else None for k,v in coverage.items()},
            per_side_topk_oracle_recall={str(k):v/count if count else None for k,v in side_coverage.items()})
        atomic_json(output/'oracle_sparsity.json',dict(scope='Raw same-window input statistics only. Directly retainingknownlargestquantities isanoracle capacitybound, not trainedmodelperformance, not a goal pass.2025Q1isreuseddevelopment;2025Q2/2026untouched.',splits=result,
            numerical_budget=[dict(global_peaks_per_frame=k,rank_amplitude_scalars_per_window=256*2*k,remaining_price_scalars_per_frame=32-2*k,total_scalars_per_window=8192) for k in [1,2,3,4,6,8]],elapsed_seconds=time.monotonic()-started))
    print(json.dumps(result,ensure_ascii=False),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('output',type=Path);args=p.parse_args();audit(args.root,args.output)
