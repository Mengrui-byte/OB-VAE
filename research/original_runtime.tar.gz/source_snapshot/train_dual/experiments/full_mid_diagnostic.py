"""CPU-only full16 development midpoint decomposition of one fixed checkpoint."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import numpy as np


def write(path,v):
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(v,indent=2));temp.replace(path)

def prepare(goal):
    from train_dual.util.checkpoint import freeze_sources
    from train_dual.experiments.price_safe_readout import file_hash
    parent=goal/'round_007_quantity_factorial';root=goal/'mid_full16_noaug512_CPU';root.mkdir();(root/'data').mkdir();(root/'logs').mkdir()
    p=json.loads((parent/'plan.json').read_text());plan={k:p[k] for k in ['train','development','window_size','stride','input_shape','latent_shape','output_shape']}
    os.link(parent/'no_aug/step512.pt',root/'source.pt');os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz');os.link(parent/'val_indices.npy',root/'val_indices.npy')
    os.link(parent/'no_aug/step512_development.json',root/'published_GPU.json')
    plan.update(source_sha256=file_hash(root/'source.pt'),scope='All fixed16development windows; CPU/FP32 price-only inference, not official GPU scores or an independent test.',
                source='Fixed no_aug/step512, chosen for worst price error at the completed512endpoint, not an improvement candidate.',
                workers=4,threads_per_worker=4,model_training=False,optimizer_updates=0,chunk_sizes=[16,64,256])
    write(root/'plan.json',plan);write(root/'status.json',dict(state='prepared_CPU_only'));freeze_sources(root/'source_snapshot');print(root.resolve(),flush=True)

def worker(root,chunk):
    import torch
    from train_dual.experiments.full_window_run import dataset
    from train_dual.util.checkpoint import load_for_inference
    from train_dual.util.phase_training import tensor_digest
    torch.set_num_threads(4);plan=json.loads((root/'plan.json').read_text());model,norm=load_for_inference(root/'source.pt','cpu');model.eval().requires_grad_(False)
    digest=tensor_digest(model);data=dataset(root,'val');indices=np.load(root/'val_indices.npy');chosen=np.array_split(indices,4)[chunk];rows=[];begin=time.monotonic()
    for index in chosen:
        raw={k:v.unsqueeze(0) for k,v in data[int(index)].items()};b=norm.prepare(raw,'cpu');offset=int(data.base.starts[int(index)]);times=data.base.times[offset:offset+256]
        assert list(raw['data'].shape)==[1,256,2,2048,2] and bool(np.all(np.diff(times//60000000)==1))
        with torch.inference_mode():
            mu,lv=model.encoder(b['price'],b['volume'],b['mask'],b['tick_norm'],b['times'])
            out=model.price_decoder(mu,b['mask'],b['tick_norm'],b['times'])
            pred=norm.inverse_price(out['price_norm'],b)[0].numpy()
        assert list(mu.shape)==list(lv.shape)==[1,64,128] and list(pred.shape)==[256,2,2048]
        truth=raw['data'][0,...,0].numpy().astype(np.float64);mask=b['mask'][0].numpy();assert mask.all()
        e=pred-truth;frame_offset=e.mean((-1,-2));miderr=pred[...,0].mean(-1)-truth[...,0].mean(-1)
        row=dict(index=int(index),price_count=int(e.size),price_sse=float(np.square(e).sum()),
                 frame_offset_sse=float(np.square(frame_offset).sum()*4096),
                 within_frame_shape_sse=float(np.square(e-frame_offset[:,None,None]).sum()),
                 mid_count=len(miderr),mid_sse=float(np.square(miderr).sum()),mid_bias=float(miderr.mean()),
                 window_bias_mid_sse=float(miderr.mean()**2*256),
                 lowpass_mid_sse={str(k):float(np.square(miderr.reshape(256//k,k).mean(-1)).sum()*k) for k in [16,64,256]},
                 price_RMSE_USDT=float(np.sqrt(np.square(e).mean())),mid_RMSE_USDT=float(np.sqrt(np.square(miderr).mean())))
        assert np.isclose(row['price_sse'],row['frame_offset_sse']+row['within_frame_shape_sse'],rtol=1e-12,atol=1e-7)
        rows.append(row);write(root/f'chunk{chunk}_progress.json',dict(pid=os.getpid(),windows=len(rows),total=len(chosen),rows=rows,elapsed_seconds=time.monotonic()-begin))
    assert tensor_digest(model)==digest
    write(root/f'chunk{chunk}.json',dict(state='complete',model_hash=digest,rows=rows,encoder_forwards=len(rows),price_decoder_forwards=len(rows),quantity_decoder_forwards=0,optimizer_updates=0))

def run(root):
    from train_dual.experiments.price_safe_readout import file_hash
    begin=time.monotonic();plan=json.loads((root/'plan.json').read_text());assert file_hash(root/'source.pt')==plan['source_sha256'];children=[]
    try:
        for i in range(4):
            env=dict(os.environ,CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',PYTHONPATH=str(root/'source_snapshot'))
            with (root/'logs'/f'chunk{i}.log').open('wb') as f:
                p=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.full_mid_diagnostic',str(root),'--chunk',str(i)],cwd=root/'source_snapshot',env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
            children.append(p)
        write(root/'status.json',dict(state='running_CPU_only',pid=os.getpid(),children=[p.pid for p in children]))
        while any(p.poll() is None for p in children):
            if any(p.poll() not in [None,0] for p in children):raise RuntimeError('Owned CPU diagnostic chunk failed')
            if time.monotonic()-begin>1200:raise TimeoutError('CPU diagnostic20min ceiling')
            time.sleep(3)
        assert all(p.returncode==0 for p in children)
        parts=[json.loads((root/f'chunk{i}.json').read_text()) for i in range(4)];assert len({p['model_hash'] for p in parts})==1
        rows=[row for p in parts for row in p['rows']];indices=np.load(root/'val_indices.npy').tolist();assert sorted(r['index'] for r in rows)==sorted(indices) and len(rows)==16
        n=sum(r['price_count'] for r in rows);ps=sum(r['price_sse'] for r in rows);ms=sum(r['mid_sse'] for r in rows);mn=sum(r['mid_count'] for r in rows)
        gpu=json.loads((root/'published_GPU.json').read_text())['result']['metrics']['price_usdt']['rmse'];cpu=float(np.sqrt(ps/n))
        assert file_hash(root/'source.pt')==plan['source_sha256']
        result=dict(state='complete_CPU_diagnostic_not_candidate',windows=16,actual_indices=indices,price_count=n,
            price_RMSE_CPU_USDT=cpu,published_price_RMSE_GPU_USDT=gpu,CPU_minus_GPU_price_RMSE_USDT=cpu-gpu,
            mid_absolute_RMSE_USDT=float(np.sqrt(ms/mn)),
            frame_offset_price_MSE_fraction=sum(r['frame_offset_sse'] for r in rows)/ps,
            window_mid_bias_MSE_fraction=sum(r['window_bias_mid_sse'] for r in rows)/ms,
            lowpass_mid_error_MSE_fraction={str(k):sum(r['lowpass_mid_sse'][str(k)] for r in rows)/ms for k in [16,64,256]},
            rows=rows,encoder_forwards=16,price_decoder_forwards=16,quantity_decoder_forwards=0,optimizer_updates=0,
            source_model_hash=parts[0]['model_hash'],source_file_unchanged=True,elapsed_seconds=time.monotonic()-begin,
            scope=plan['scope'],price_only_path='Exactly native sample=False encoder mu followed by native price decoder; quantity branch omitted because no price-to-quantity-to-price feedback exists. No whole-model completion or rare-order claims.')
        write(root/'result.json',result);write(root/'status.json',dict(state='complete',pid=os.getpid(),elapsed_seconds=time.monotonic()-begin));print(json.dumps(result),flush=True)
    finally:
        import signal
        for p in children:
            if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--run',action='store_true');p.add_argument('--chunk',type=int,choices=range(4));args=p.parse_args();root=args.root.resolve()
    try:
        if args.prepare:prepare(root)
        elif args.chunk is not None:worker(root,args.chunk)
        elif args.run:run(root)
        else:p.error('Specify a mode')
    except BaseException as e:
        if not args.prepare:write(root/(f'chunk{args.chunk}_failed.json' if args.chunk is not None else 'status.json'),dict(state='failed',pid=os.getpid(),error=repr(e)))
        raise
