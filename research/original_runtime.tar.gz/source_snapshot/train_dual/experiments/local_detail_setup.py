"""Fit signed-detail scales from existing training windows; never launch training."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import time

import numpy as np
import torch

from model.losses.local_detail import signed_spatial_detail
from model.losses.quantity_strata import QUANTITY_LOWER_BOUNDS
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.price_safe_readout import file_hash
from train_dual.util.checkpoint import freeze_sources
from train_dual.util.data import DualNormalizer

RADII=(1,2,4,8)


def prepare(goal):
    torch.set_num_threads(4);begin=time.monotonic()
    source=goal/'round_007_quantity_factorial'
    root=goal/'local_detail_preparation_20261028';root.mkdir();(root/'data').mkdir();(root/'logs').mkdir()
    parent=json.loads((source/'plan.json').read_text())
    for name in ['train_indices.npy','val_indices.npy','seen_indices.npy','quantity_calibration_indices.npy']:
        os.link(source/name,root/name)
    os.link(source/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    plan={key:parent[key] for key in ['train','development','window_size','stride','normalization','input_shape','latent_shape','output_shape','seed']}
    assert plan['input_shape']==[1,256,2,2048,2] and plan['latent_shape']==[1,64,128]
    indices=np.load(root/'quantity_calibration_indices.npy');assert indices.tolist()==np.load(root/'seen_indices.npy').tolist()
    assert len(indices)==8 and set(indices.tolist())<=set(np.load(root/'train_indices.npy').tolist())
    plan.update(preparation_only=True,training_launched=False,detail_radii=list(RADII),quantity_bins_lower_BTC=list(QUANTITY_LOWER_BOUNDS),
        transform='u=log1p(q in physical BTC), H_r(u)[l]=u[l]-.5*(u[l-r]+u[l+r]); complete-neighborhood valid mask; preserve signed lobes',
        scale_floor=1e-4,training_indices=indices.tolist(),parent_checkpoint_not_selected=True,
        parent_selection='Await completed matched current cohort. No independent/test fitting and no provisional-source GPU continuation.',
        hypothesis='Phase- and amplitude-matched local supervision may recover details missed by absolute quantity fitting; equal variance at the wrong price rank must still incur loss.',
        next_ablation='One fixed model/data/parent/budget recipe; only extra signed-detail coefficient0/.25/1/4 changes, following a training-only gradient calibration. Do not mix with upsampling changes.',
        calibration_policy='RMS per radius x true center-quantity bin; only these eight predeclared training windows; zero neural forwards/optimizer updates.')
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='fitting_training_detail_scales',pid=os.getpid()))
    data=dataset(root,'train');norm=DualNormalizer(tick_size=plan['normalization']['tick_size'],price_scale=plan['normalization']['price_scale'])
    counts=np.zeros((4,6),np.int64);squares=np.zeros((4,6),np.float64);data_hash=hashlib.sha256()
    for n,index in enumerate(indices):
        raw={k:v.unsqueeze(0) for k,v in data[int(index)].items()};offset=int(data.base.starts[int(index)]);times=data.base.times[offset:offset+256]
        assert list(raw['data'].shape)==[1,256,2,2048,2] and bool(np.all(np.diff(times//60000000)==1))
        data_hash.update(raw['data'].numpy().tobytes());b=norm.prepare(raw,'cpu');q=b['volume'];u=torch.log1p(q)
        for j,radius in enumerate(RADII):
            response,valid=signed_spatial_detail(u,b['mask'],radius)
            for i,lower in enumerate(QUANTITY_LOWER_BOUNDS):
                selected=valid&(q>=lower)
                if i<5:selected &= q<QUANTITY_LOWER_BOUNDS[i+1]
                values=response[selected].double();counts[j,i]+=values.numel();squares[j,i]+=float(values.square().sum())
        atomic_json(root/'progress.json',dict(windows=n+1,total=8,elapsed_seconds=time.monotonic()-begin,neural_forward_calls=0,optimizer_updates=0))
    assert bool((counts>0).all())
    scales=np.maximum(np.sqrt(squares/counts),plan['scale_floor'])
    atomic_json(root/'detail_calibration.json',dict(state='scales_fit_requires_future_source_gradient_calibration',radii=list(RADII),
        lower_BTC=list(QUANTITY_LOWER_BOUNDS),counts=counts.tolist(),RMS_scales=scales.tolist(),
        training_indices=indices.tolist(),selected_raw_values_sha256=data_hash.hexdigest(),scale_floor=plan['scale_floor'],
        weight_calibration_locked=False,base_weight=None,neural_forward_calls=0,optimizer_updates=0,
        scope='Train-only statistics; no source/candidate selection, no GPU calibration or training.'))
    atomic_json(root/'status.json',dict(state='prepared_not_training',elapsed_seconds=time.monotonic()-begin,neural_forward_calls=0,optimizer_updates=0))
    freeze_sources(root/'source_snapshot')
    atomic_json(root/'preparation_provenance.json',dict(actual_input=[1,256,2,2048,2],data_samefile_as_current_factorial=(root/'data/BTCUSDT.npz').samefile(source/'data/BTCUSDT.npz'),
        current_factorial_snapshot_untouched=True,loss_source_sha256=file_hash(Path(__file__).resolve().parents[2]/'model/losses/local_detail.py'),
        tests='tests.test_local_detail_loss and tests.test_quantity_strata:10 passed before scale fitting'))
    (root/'index.html').write_text('<!doctype html><meta charset="utf-8"><h1>有符号局部细节损失：准备完成，尚未训练</h1><p>仅8个既有训练窗口的固定差分统计，0神经前向、0优化器更新。窗口仍为256分钟；没有改变正在运行的四组实验。</p><p>候选要求尖峰在正确档位和分钟出现，不能由整体方差放大替代。当前尚无开发质量收益或新模型成绩；需等待当前对照后选择统一来源，单独做系数消融及GPU梯度校准。</p><p><a href="detail_calibration.json">训练集尺度</a> · <a href="plan.json">假设与协议</a></p>')
    print(root.resolve(),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('goal',type=Path);args=p.parse_args();prepare(args.goal.resolve())
