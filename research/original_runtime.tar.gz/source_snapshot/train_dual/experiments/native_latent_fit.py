"""Fit eight training-only codes to diagnose the CURRENT fixed native Decoder."""
import argparse
import html
import os
from pathlib import Path
import time

import numpy as np
import torch

from model.losses.latent_fit import LatentFitObjective
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read, STYLE
from train_dual.experiments.price_safe_readout import file_hash
from train_dual.experiments.recall_goal_run import record
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import atomic_save, freeze_sources, load_for_inference, seed_everything
from train_dual.util.phase_training import tensor_digest


def render(root):
    state = read(root / 'status.json', {})
    text = '<h1>固定当前Decoder：直接拟合8192维窗口代码</h1><p>仅8个预先指定的2022–2024训练窗口。全部模型参数冻结；每窗口从Encoder均值初始化一个64×128代码，只更新代码，两个Decoder使用同一代码。完整256分钟、双侧2048档、预测价格条件不变。训练标签参与代码优化，因此这是表达能力诊断，不是Encoder重建成绩或样本外候选。</p><p>对照为同窗口未经优化的来源代码。每窗口独立Adam、相同128次更新，7项损失按各自来源训练窗口初始值固定归一化；没有按开发成绩调参。失败不能证明结构不可能；成功也不能证明Encoder已能生成该代码。</p>'
    text += '<p>状态：' + html.escape(str(state)) + '</p><table><tr><th>更新/窗口</th><th>召回</th><th>精确率</th><th>价格RMSE</th><th>分钟mid变化RMSE</th><th>数量RMSE</th><th>价格双门槛</th></tr>'
    for step in [0, 32, 128]:
        result = read(root / f'step{step}_fit_evaluation.json')
        if result:
            m = result['pooled']
            values = [step, m['recall'], m['precision'], m['price_rmse'], m['mid_delta_rmse'], m['quantity_rmse'], result['pooled_price_guard_passed']]
            text += '<tr>' + ''.join('<td>' + (f'{v:.6g}' if isinstance(v, float) else str(v)) + '</td>' for v in values) + '</tr>'
    text += '</table><p><a href="plan.json">预先协议</a> · <a href="progress.json">进度</a> · <a href="step128_fit_evaluation.json">最终逐窗诊断</a></p>'
    (root / 'index.html').write_text('<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="30"><style>' + STYLE + '</style><main>' + text + '</main>')


def prepare(goal):
    parent = goal / 'paired_logit_readout'
    old = read(parent / 'plan.json')
    root = goal / 'native_latent_fit'
    root.mkdir()
    for name in ['data', 'logs']:
        (root / name).mkdir()
    os.link(parent / 'source.pt', root / 'source.pt')
    os.link(parent / 'data/BTCUSDT.npz', root / 'data/BTCUSDT.npz')
    indices = np.load(parent / 'train_indices.npy')[np.unique(np.linspace(0, 31, 8, dtype=int))]
    np.save(root / 'train_indices.npy', indices)
    predecessor = goal / 'paired_response_space_v3'
    atomic_json(root / 'plan.json', dict(
        train=old['train'], development=old['development'], window_size=256, stride=256,
        input_shape=[1, 256, 2, 2048, 2], latent_shape=[1, 64, 128], output_shape=[1, 256, 2, 2048],
        indices=indices.tolist(), seed=42, steps_per_window=128, checkpoints=[32, 128],
        learning_rate=.01, clip_grad=1., max_seconds=10800, quantity_scale=old['normalization']['quantity_scale'],
        source_sha256=file_hash(root / 'source.pt'), source='Original first price-safe delta64/step256, identical to frozen-Decoder head studies',
        previous_direct_z='decoder_isolation_recovery_20261027_112135 used an earlier zero-recall source. Its1024fit remained zero; do not conflate that source with current nonzero-recall Frame1 model.',
        source_selection='Fixed before this diagnostic; no developed-code result used to select source or indices',
        objective='Equal sum of7terms normalized by EACH training window initial value floored1e-4: priceMSE, mid-deltaMSE, global quantityHuber, logquantityHuber, true100Huber, negative soft100Huber, true100 +/-8localKL. Scales fixed, beta0, no code prior/drift penalty.',
        control='Unoptimized source Encoder means on exact same8trainingwindows; not a causal model-training ablation. Separate Adam per code to avoid inactive-row momentum updates.',
        scope='Target-assisted training-only oracle; no model parameters trained, no model candidate emitted, no development or independent data read.',
        precision='FP32 train/eval, cudnn deterministicTrue, benchmarkFalse, bothTF32off',
        predecessor=predecessor.name, predecessor_pid=read(predecessor / 'status.json')['pid'],
        wait='Wait verified owned paired_response_space_v3 process exit and complete; never restart it on observation timeout.'
    ))
    atomic_json(root / 'status.json', dict(state='prepared'))
    freeze_sources(root / 'source_snapshot')
    project = Path(__file__).resolve().parents[2]
    remote = Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e') / root.relative_to(project)
    (root / 'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n' + f'export CUDA_VISIBLE_DEVICES=2 CUDA_DEVICE_ORDER=PCI_BUS_ID PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.native_latent_fit "{remote}" --worker >> "{remote}/logs/run.log" 2>&1\n')
    render(root)
    record(goal, 'native_latent_diagnostic_prepared', root=root.name, indices=indices.tolist(), steps_per_window=128, scope='Training-only codes; no production candidate')
    print(root, flush=True)


def wait_predecessor(root, plan):
    parent = root.parent / plan['predecessor']
    start = time.monotonic()
    while True:
        try:
            command = Path(f"/proc/{plan['predecessor_pid']}/cmdline").read_bytes().split(b'\0')
            live = b'train_dual.experiments.paired_logit_run' in command and os.fsencode(str(parent)) in command
        except FileNotFoundError:
            live = False
        state = read(parent / 'status.json', {}).get('state')
        if not live:
            if state != 'complete':
                raise RuntimeError(f'Predecessor missing but not complete: {state}')
            return
        if time.monotonic() - start > plan['max_seconds']:
            raise TimeoutError('Verified predecessor wait ceiling')
        atomic_json(root / 'status.json', dict(state='verified_wait_predecessor', pid=os.getpid(), predecessor_pid=plan['predecessor_pid']))
        time.sleep(15)


def fit_metrics(model, norm, batches, codes, z0, indices, reference=None):
    rows = []
    with torch.no_grad():
        for i, batch in enumerate(batches):
            out = model.decode(codes[i], batch['mask'], batch['tick_norm'], batch['times'])
            mask = batch['mask']
            pred, truth = out['volume'], batch['volume']
            price = norm.inverse_price(out['price_norm'], batch).double()
            target_price = norm.inverse_price(batch['price'], batch).double()
            price_error = (price - target_price)[mask]
            q_error = (pred.double() - truth.double())[mask]
            mid = price[..., 0].mean(-1)
            target_mid = target_price[..., 0].mean(-1)
            frame_valid = mask[..., 0].all(-1)
            pairs = frame_valid[:, 1:] & frame_valid[:, :-1]
            delta = (mid.diff(dim=1) - target_mid.diff(dim=1))[pairs]
            positive, predicted = (truth >= 100.) & mask, (pred >= 100.) & mask
            tp, fp, fn = (int((positive & predicted).sum()), int((~positive & predicted & mask).sum()), int((positive & ~predicted).sum()))
            rows.append(dict(training_index=int(indices[i]), tp=tp, fp=fp, fn=fn,
                price_sse=float(price_error.square().sum()), quantity_sse=float(q_error.square().sum()), count=int(mask.sum()),
                mid_delta_sse=float(delta.square().sum()), mid_delta_count=delta.numel(),
                source_z_norm=float(z0[i].norm()), z_norm=float(codes[i].norm()),
                relative_z_drift=float((codes[i] - z0[i]).norm() / z0[i].norm().clamp_min(1e-12))))
    def finish(row):
        row.update(recall=row['tp'] / (row['tp'] + row['fn']) if row['tp'] + row['fn'] else None,
            precision=row['tp'] / (row['tp'] + row['fp']) if row['tp'] + row['fp'] else None,
            price_rmse=(row['price_sse'] / max(1, row['count'])) ** .5,
            quantity_rmse=(row['quantity_sse'] / max(1, row['count'])) ** .5,
            mid_delta_rmse=(row['mid_delta_sse'] / max(1, row['mid_delta_count'])) ** .5)
        return row
    keys = ['tp', 'fp', 'fn', 'price_sse', 'quantity_sse', 'count', 'mid_delta_sse', 'mid_delta_count']
    pooled = finish({key: sum(row[key] for row in rows) for key in keys})
    rows = [finish(row) for row in rows]
    def guard(row, base):
        return row['price_rmse'] <= 1.1 * base['price_rmse'] and row['mid_delta_rmse'] <= 1.1 * base['mid_delta_rmse']
    if reference:
        for row, base in zip(rows, reference['per_window']):
            row['price_guard_passed'] = guard(row, base)
    return dict(pooled=pooled, per_window=rows, pooled_price_guard_passed=guard(pooled, reference['pooled']) if reference else True,
        scope='Fitted training codes only. Not a neural Encoder inference or goal candidate.')


def worker(root):
    plan = read(root / 'plan.json')
    wait_predecessor(root, plan)
    if (root.parent / 'candidate_for_confirmation.json').exists():
        atomic_json(root / 'status.json', dict(state='not_run_confirmation_priority', pid=os.getpid()))
        return
    torch.set_num_threads(4)
    seed_everything(42)
    strict_precision()
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    start = time.monotonic()
    atomic_json(root / 'status.json', dict(state='actual_GPU_preflight', pid=os.getpid()))
    assert file_hash(root / 'source.pt') == plan['source_sha256']
    model, norm = load_for_inference(root / 'source.pt', 'cuda:0')
    model.eval().requires_grad_(False)
    digest = tensor_digest(model)
    original = dataset(root, 'train')
    indices = np.load(root / 'train_indices.npy')
    batches, z0, scales, contracts = [], [], [], []
    objective = LatentFitObjective(plan['quantity_scale'])
    with torch.no_grad():
        for index in indices:
            raw = {k: v.unsqueeze(0) for k, v in original[int(index)].items()}
            assert list(raw['data'].shape) == plan['input_shape']
            offset = int(original.base.starts[int(index)])
            times = original.base.times[offset:offset + 256]
            assert len(times) == 256 and bool((np.diff(times // 60_000_000) == 1).all())
            batch = norm.prepare(raw, 'cuda:0')
            seen = []
            hooks = [module.register_forward_pre_hook(lambda m, args: seen.append(args[0])) for module in (model.price_decoder, model.volume_decoder)]
            out = call(model, batch, False)
            for hook in hooks:
                hook.remove()
            assert len(seen) == 2 and seen[0] is seen[1] and seen[0] is out['z']
            assert all(list(out[k].shape) == [1, 64, 128] for k in ['mu', 'logvar', 'z'])
            assert all(list(out[k].shape) == plan['output_shape'] for k in ['price_norm', 'volume'])
            replay = model.decode(out['z'], batch['mask'], batch['tick_norm'], batch['times'])
            for key in ['price_norm', 'volume']:
                torch.testing.assert_close(out[key], replay[key], rtol=0, atol=0)
            batches.append(batch)
            z0.append(out['z'].detach().clone())
            scales.append(objective.calibration(objective.components(out, batch)))
            contracts.append(dict(index=int(index), first_utc=str(np.datetime64(int(times[0]), 'us')), last_utc=str(np.datetime64(int(times[-1]), 'us'))))
    # Actual fresh instance receives only saved codes and allowed conditions.
    fresh, _ = load_for_inference(root / 'source.pt', 'cuda:0')
    fresh.eval().requires_grad_(False)
    with torch.no_grad():
        b = batches[0]
        actual = fresh.decode(z0[0], b['mask'], b['tick_norm'], b['times'])
        for key, value in model.decode(z0[0], b['mask'], b['tick_norm'], b['times']).items():
            torch.testing.assert_close(value, actual[key], rtol=0, atol=0)
    del fresh, out, replay
    torch.cuda.empty_cache()
    atomic_json(root / 'actual_contract.json', dict(passed=True, raw_shape=plan['input_shape'], posterior_shape=[1, 64, 128], output_shape=plan['output_shape'], shared_z_object=True, fresh_Z_only_decode_exact=True, trainable_model_parameters=0, windows=contracts, source_model_sha256=digest))
    atomic_json(root / 'training_only_calibration.json', dict(indices=indices.tolist(), per_window_scales=scales, fixed_before_first_update=True))
    def forbidden_encoder(*args):
        raise RuntimeError('Encoder cannot be called during free-code fitting')
    hook = model.encoder.register_forward_pre_hook(forbidden_encoder)
    codes = [torch.nn.Parameter(z.clone()) for z in z0]
    optimizers = [torch.optim.Adam([z], lr=plan['learning_rate']) for z in codes]
    reference = fit_metrics(model, norm, batches, codes, z0, indices)
    atomic_json(root / 'step0_fit_evaluation.json', reference)
    atomic_json(root / 'status.json', dict(state='fitting_training_codes', pid=os.getpid()))
    render(root)
    for step in range(1, plan['steps_per_window'] + 1):
        if time.monotonic() - start > plan['max_seconds']:
            raise TimeoutError('Three-hour diagnostic ceiling')
        losses, gradients = [], []
        for i, (code, optimizer, batch) in enumerate(zip(codes, optimizers, batches)):
            optimizer.zero_grad(set_to_none=True)
            out = model.decode(code, batch['mask'], batch['tick_norm'], batch['times'])
            loss, _ = objective(out, batch, scales[i])
            assert bool(torch.isfinite(loss))
            loss.backward()
            gradient = float(torch.nn.utils.clip_grad_norm_([code], plan['clip_grad'], error_if_nonfinite=True))
            assert gradient > 0
            optimizer.step()
            losses.append(float(loss.detach()))
            gradients.append(gradient)
        if step == 1:
            assert not any(p.grad is not None for p in model.parameters())
            assert tensor_digest(model) == digest
            atomic_json(root / 'first_update_audit.json', dict(passed=True, code_gradients=gradients, all_model_parameters_unchanged=True, no_encoder_calls_after_initialization=True, distinct_optimizers=True))
        if step == 1 or step % 4 == 0:
            atomic_json(root / 'progress.json', dict(step=step, total=plan['steps_per_window'], code_updates=8*step, losses=losses, gradient_norms=gradients, elapsed_seconds=time.monotonic()-start, pid=os.getpid()))
        if step in plan['checkpoints']:
            assert tensor_digest(model) == digest
            atomic_json(root / f'step{step}_frozen_audit.json', dict(passed=True, all_model_values_exact=True, model_sha256=digest))
            atomic_save(dict(format='training_only_latent_fit_v1', step_per_window=step, indices=indices, source_sha256=plan['source_sha256'], source_model_sha256=digest, z0=torch.cat(z0).cpu(), z=torch.cat([z.detach() for z in codes]).cpu(), optimizers=[o.state_dict() for o in optimizers], not_production_inference=True), root / f'step{step}_codes.pt')
            atomic_json(root / f'step{step}_fit_evaluation.json', fit_metrics(model, norm, batches, codes, z0, indices, reference))
            render(root)
    hook.remove()
    atomic_json(root / 'status.json', dict(state='complete', pid=os.getpid(), elapsed_seconds=time.monotonic()-start, source_model_unchanged=True, goal_candidate=False))
    render(root)
    record(root.parent, 'native_latent_diagnostic_complete', root=root.name, final=read(root / 'step128_fit_evaluation.json'), goal_candidate=False)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    parser.add_argument('--prepare', action='store_true')
    parser.add_argument('--worker', action='store_true')
    args = parser.parse_args()
    root = args.root.resolve()
    try:
        if args.prepare:
            prepare(root)
        elif args.worker:
            worker(root)
    except BaseException as error:
        if not args.prepare:
            atomic_json(root / 'status.json', dict(state='failed', pid=os.getpid(), error=repr(error)))
        raise
