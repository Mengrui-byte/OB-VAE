"""Browser progress and final per-level book plots for learned state encoders."""

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import time

import numpy as np

from train_dual.experiments.book_stem_viewer import build


LABELS = {'fixed':'固定PCA', 'linear':'可学习线性编码', 'nonlinear':'非线性编码', 'attention':'分组注意力编码'}
PAGE = '''<!doctype html><html lang=zh-CN><meta charset=utf-8><title>窗口状态编码实验</title>
<style>body{font:17px system-ui;max-width:1450px;margin:30px auto;padding:0 20px;color:#162235}p{line-height:1.8}table{border-collapse:collapse;width:100%}td,th{padding:10px;border:1px solid #d8dfe9;text-align:left}a{color:#2563eb}</style>
<h1>1024维窗口状态：四种编码方式</h1><p>整个16分钟窗口聚合成一个[B,1024]向量。四组从相同Cross权重及PCA重建出发，仅改变编码分支。32窗口拟合检查通过后，重新初始化进行1024步正式训练：前128步只训练压缩/恢复模块，随后896步联合适配生成器。有效batch64；种子42。</p>
<p id=status>加载中</p><table><thead><tr><th>GPU</th><th>模型</th><th>阶段</th><th>更新</th><th>损失</th><th>编码梯度</th><th>显存GiB</th></tr></thead><tbody id=progress></tbody></table>
<h2>32训练窗口拟合诊断</h2><table><thead><tr><th>模型</th><th>初始损失</th><th>结束损失</th><th>损失比</th><th>数量RMSE</th><th>状态变化RMS</th></tr></thead><tbody id=small></tbody></table>
<h2>正式训练的最近开发集评估</h2><p>固定128个2025年一季度开发窗口，严格FP32。各组速度不同，最终按相同更新次数比较；独立测试集未使用。</p><table><thead><tr><th>模型</th><th>更新</th><th>价格RMSE USDT</th><th>数量RMSE BTC</th><th>64档斜率RMSE</th><th>分钟变化RMSE</th><th>≥100BTC精确率</th><th>召回率</th></tr></thead><tbody id=metrics></tbody></table>
<p><a href=../>已发布的逐档挂单线图</a> · <a href=previous/>上一轮重建结果</a> · <a href=plan.json>实验配置</a></p><small id=updated></small>
<script>const labels={fixed:'固定PCA',linear:'可学习线性编码',nonlinear:'非线性编码',attention:'分组注意力编码'};
function row(xs){let r=document.createElement('tr');for(let x of xs){let c=document.createElement('td');c.textContent=x;r.append(c)}return r}const num=(x,n=4)=>x==null?'—':x.toFixed(n);
async function refresh(){let d=await(await fetch('encoding_progress.json?t='+Date.now())).json();document.getElementById('status').textContent='状态：'+d.status.state+'；阶段：'+(d.status.phase||'—')+(d.status.error?'；'+d.status.error:'')+(d.gate?'；小样本门槛：'+(d.gate.passed?'通过':'未通过'):'');let p=[],s=[],m=[];
for(let [name,label] of Object.entries(labels)){let a=d.small[name]||{},b=d.main[name]||{},x=d.status.phase==='small'?a:b,v=x.progress||{};p.push(row([d.gpus[name],label,x.status?.state||v.state||'等待',String(v.step??0)+' / '+(d.status.phase==='small'?96:1024),num(v.loss),num(v.encoder_gradient_norm),num(v.reserved_gib,1)]));if(a.final)s.push(row([label,num(a.initial?.loss),num(a.final.loss),num(a.final.relative_loss),num(a.final.quantity_rmse),num(a.final.state_change_rms)]));let y=b.final||b.latest||b.frozen||b.initial;if(y){let z=y.result,q=z.metrics;m.push(row([label,y.step,num(q.price_usdt.rmse,3),num(q.quantity_btc.rmse),num(q.spatial_slope_64_levels_usdt_per_level.rmse,6),num(q.temporal_mid_1_minutes_usdt_per_minute.rmse,3),num(z.thresholds['100'].precision),num(z.thresholds['100'].recall)]))}}
document.getElementById('progress').replaceChildren(...p);document.getElementById('small').replaceChildren(...s);document.getElementById('metrics').replaceChildren(...m);document.getElementById('updated').textContent='更新：'+new Date(d.utc).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai'})}refresh().catch(console.error);setInterval(()=>refresh().catch(console.error),5000)</script></html>'''


def final_report(root):
    plan=json.loads((root/'plan.json').read_text())
    results=json.loads((root/'comparison.json').read_text())
    data=root/'report';data.mkdir(exist_ok=True)
    with np.load(root/'reference_profiles.npz') as p:
        arrays={k:p[k] for k in ('truth','mask','time','indices')}
        arrays['reference']=p['prediction']
    config=[dict(key='truth',label='真实订单簿',color='#2563eb'),dict(key='reference',label='未压缩Cross参考',color='#6b7280')]
    for (lane,label),color in zip(LABELS.items(),['#ef4444','#16a34a','#9333ea','#f59e0b']):
        with np.load(root/'main'/lane/'profiles.npz') as p:
            if not np.array_equal(p['truth'],arrays['truth']):raise ValueError('Book examples are not matched')
            arrays[lane]=p['prediction']
        config.append(dict(key=lane,label=label,color=color))
    np.savez_compressed(data/'profiles.npz',**arrays)
    info=dict(seed=42,common_step=plan['steps'],viewer_variants=config,default_model=4,plan=plan,results=results,
        comparison_label='查看四种编码器的同预算指标',step_note='单种子42；完整窗口状态1024维；各组1024步，同损失同样本。')
    (data/'comparison.json').write_text(json.dumps(info,ensure_ascii=False,indent=2))
    table='<table><tr><th>模型</th><th>阶段</th><th>更新</th><th>价格RMSE</th><th>数量RMSE</th><th>64档斜率RMSE</th><th>分钟变化RMSE</th><th>≥100BTC精确率</th><th>召回率</th></tr>'
    for lane,label in LABELS.items():
        for stage in ('initial','frozen','final'):
            r=results['rows'][lane][stage];m=r['result']['metrics'];q=r['result']['thresholds']['100']
            values=[label,stage,str(r['step'])]+[f"{m[k]['rmse']:.6f}" for k in ('price_usdt','quantity_btc','spatial_slope_64_levels_usdt_per_level','temporal_mid_1_minutes_usdt_per_minute')]+[str(q['precision']),str(q['recall'])]
            table+='<tr>'+''.join('<td>'+v+'</td>' for v in values)+'</tr>'
    table+='</table>'
    (data/'index.html').write_text('<!doctype html><meta charset=utf-8><style>body{font:17px system-ui;margin:30px}td,th{padding:10px;border:1px solid #ddd}table{border-collapse:collapse}</style><h1>1024维窗口状态编码对照</h1><p><a href=../>逐档挂单线图</a> · <a href=../encoding.html>训练进度</a> · <a href=comparison.json>完整配置与指标</a></p><p>相同初始化、样本、损失和更新次数；模型容量随编码方式不同。开发集参与选型，独立测试未使用。单次失败不代表低维表示不存在。</p>'+table)
    viewer=root/'viewer';build(data,viewer)
    for name in ('encoding.html','encoding_progress.json','plan.json'):
        if not (viewer/name).exists():(viewer/name).symlink_to(root/'public'/name)
    if not (viewer/'previous').exists():(viewer/'previous').symlink_to(root/'public/previous',target_is_directory=True)
    return viewer


def monitor(root):
    public=root/'public';public.mkdir(exist_ok=True)
    selector=root.parents[1]/'.local/dual_viewer/current.json'
    previous=Path(json.loads(selector.read_text())['directory'])
    if not (public/'previous').exists():(public/'previous').symlink_to(previous,target_is_directory=True)
    (public/'index.html').write_text(PAGE);(public/'encoding.html').write_text(PAGE)
    if not (public/'plan.json').exists():(public/'plan.json').symlink_to(root/'plan.json')
    def select(path):
        tmp=selector.with_suffix('.tmp');tmp.write_text(json.dumps(dict(directory=str(path))));tmp.replace(selector)
    # Keep the last reconstruction at the root; expose this run's progress beside it.
    for name in ('encoding.html','encoding_progress.json','plan.json'):
        target=previous/name
        if target.is_symlink():target.unlink()
        if not target.exists():target.symlink_to(public/name)
    while True:
        try:
            status=json.loads((root/'status.json').read_text())
            stages={}
            for stage,folder in [('small','small_fit'),('main','main')]:
                lanes={}
                for lane in LABELS:
                    values={}
                    for key,name in [('progress','progress.json'),('status','status.json'),('initial','initial_evaluation.json'),('frozen','frozen_evaluation.json'),('latest','latest_evaluation.json'),('final','final_evaluation.json')]:
                        path=root/folder/lane/name
                        if path.exists():values[key]=json.loads(path.read_text())
                    lanes[lane]=values
                stages[stage]=lanes
            payload=dict(utc=datetime.now(timezone.utc).isoformat(),status=status,gpus=dict(zip(LABELS,(2,3,4,5))),**stages)
            if (root/'small_fit_gate.json').exists():payload['gate']=json.loads((root/'small_fit_gate.json').read_text())
            temp=public/'encoding_progress.json.tmp';temp.write_text(json.dumps(payload));temp.replace(public/'encoding_progress.json')
            if status['state']=='complete':
                try:
                    viewer=final_report(root);select(viewer)
                    (root/'published.json').write_text(json.dumps(dict(directory=str(viewer))))
                except Exception as error:
                    (root/'report_error.json').write_text(json.dumps(dict(error=repr(error))))
                    raise
                break
            if status['state'] in ('failed','diagnostic_failed','stopped_by_user'):break
        except (FileNotFoundError,ValueError):pass
        time.sleep(10)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--report-only',action='store_true');a=p.parse_args()
    if a.report_only:print(final_report(a.root))
    else:monitor(a.root)
