"""Full2048 GPU backward/calibration probe on a verified released control card."""
import argparse
import os
from pathlib import Path
import time

import numpy as np
import torch

from model.layers.branch_precision import branch_precision_policy
from train_dual.experiments import local_hint_run as shared
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.idle_aggregation_pilot import bind_reference,setup,worker_live,POLICY
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read
from train_dual.experiments.price_safe_readout import file_hash
from train_dual.experiments.region_task_run import gpu_free
from train_dual.experiments.relative_aggregation_run import calibrate,criterion
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import freeze_sources,load_for_inference,seed_everything
from train_dual.util.phase_training import tensor_digest

MODULE='train_dual.experiments.frozen_quantity_preflight'


def prepare(goal):
    parent=goal/'round_010_branch_precision';root=goal/'frozen_quantity_full_gpu_preflight_20261029';root.mkdir();(root/'logs').mkdir();private=root/'private';private.mkdir()
    # Relative aliases remain valid through the differently mounted remote tree.
    for name in ['round_010_branch_precision','log_relative_detail_preparation_20261028','reference_evaluation.json']:
        (private/name).symlink_to(os.path.relpath(goal/name,private),target_is_directory=(goal/name).is_dir())
    queue=private/'private_queue';queue.mkdir();parentplan=read(parent/'plan.json')
    atomic_json(queue/'plan.json',dict(parent=parent.name,source_sha256=parentplan['source_sha256'],steps=512,checkpoints=[256,512],max_seconds=7200,gradient_norm_fraction=.25,
        controls='Private functional GPU preflight only; no model updates or quality measurement.',reference_policy='Own frozen source; source0 only, not a trained candidate.'))
    cohort=setup(queue,bind_reference(queue))
    atomic_json(root/'plan.json',dict(cohort_relative=str(cohort.relative_to(root)),parent='round_010_branch_precision',control_pid=41249,encoder_pid=41250,
        scope='One full-window forward/backward on all volume parameters, followed by8train-window functional gradient calibration.0 production updates, no Q2.',source_sha256=parentplan['source_sha256']))
    atomic_json(root/'status.json',dict(state='prepared_not_started'));freeze_sources(root/'source_snapshot')
    project=Path(__file__).resolve().parents[2];remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 CUDA_DEVICE_ORDER=PCI_BUS_ID OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m {MODULE} "{remote}" --run >> "{remote}/logs/run.log" 2>&1\n')
    return root


def run(root):
    p=read(root/'plan.json');parent=root.parent/p['parent'];state=read(parent/'control/status.json')
    assert state['state']=='complete' and state['step']==2048 and not worker_live(parent,p['control_pid'],'control')
    assert worker_live(parent,p['encoder_pid'],'encoder_fp32')
    assert 2048-read(parent/'encoder_fp32/progress.json')['step']>=128, 'Leave sufficient time for the queued two-card experiment'
    assert gpu_free().get(2,0)>=47000 and os.environ.get('CUDA_VISIBLE_DEVICES')=='2'
    torch.set_num_threads(4);seed_everything(42);strict_precision();begin=time.monotonic();cohort=root/p['cohort_relative'];cfg=read(cohort/'plan.json')
    atomic_json(root/'status.json',dict(state='running',pid=os.getpid(),scope='No model updates'))
    model,norm=load_for_inference(cohort/'initial.pt','cuda:0');model.train()
    for name in cfg['frozen_modules']:model.get_submodule(name).requires_grad_(False).eval()
    assert branch_precision_policy(model)==POLICY
    before=tensor_digest(model);data=dataset(cohort,'train');index=int(np.load(cohort/'quantity_calibration_indices.npy')[0])
    raw={k:v.unsqueeze(0) for k,v in data[index].items()};assert list(raw['data'].shape)==[1,256,2,2048,2]
    teacher,tn=load_for_inference(cohort/'teacher.pt','cuda:0');teacher.eval().requires_grad_(False);target=shared.teacher_local(teacher,tn,raw);batch=norm.prepare(raw,'cuda:0')
    dtypes={};modules=dict(encoder_input=model.encoder.input_proj,encoder_mu=model.encoder.mu,price_head=model.price_decoder.gap,quantity_head=model.volume_decoder.quantity)
    def hook(name):
        def observe(module,args,out):dtypes[name]=str(out.dtype)
        return observe
    hooks=[module.register_forward_hook(hook(name)) for name,module in modules.items()];seen=[]
    hooks += [decoder.register_forward_pre_hook(lambda m,args:seen.append(args[0])) for decoder in [model.price_decoder,model.volume_decoder]]
    with torch.autocast('cuda',dtype=torch.bfloat16):out=call(model,batch,False)
    for h in hooks:h.remove()
    assert seen[0] is seen[1] is out['z'] and list(out['z'].shape)==[1,64,128]
    assert list(out['volume'].shape)==list(out['price_norm'].shape)==[1,256,2,2048]
    assert not out['mu'].requires_grad and not out['price_norm'].requires_grad and out['volume'].requires_grad
    assert all(v=='torch.float32' for v in dtypes.values())
    obj=criterion(cohort,'control',calibrating=True);values=obj(out,batch,teacher_local=target)
    grads=torch.autograd.grad(values['loss']+values['relative_quantity_log'],list(model.volume_decoder.parameters()))
    assert all(torch.isfinite(g).all() for g in grads) and sum(float(g.square().sum()) for g in grads)>0
    assert all(q.grad is None for q in model.parameters()) and tensor_digest(model)==before
    first=dict(actual_input=list(raw['data'].shape),actual_z=list(out['z'].shape),actual_output=list(out['volume'].shape),actual_dtypes=dtypes,
        Encoder_and_price_no_grad=True,quantity_requires_grad=True,all_volume_parameter_gradients_finite=True,same_single_Z=True,source_weights_unchanged=True,
        max_reserved_gib=torch.cuda.max_memory_reserved()/2**30)
    del grads,values,out,seen,obj,target,batch,raw,model,teacher,data
    import gc
    gc.collect();torch.cuda.empty_cache()
    calibrate(cohort);cal=read(cohort/'aggregation_calibration.json')
    assert cal['weight_calibration_locked'] and cal['gradient_module']=='volume_decoder' and cal['calibration_relative_arm']=='per_position' and cal['optimizer_updates']==0
    assert file_hash(cohort/'source.pt')==p['source_sha256']
    result=dict(state='passed',first_full_window=first,gradient_calibration=cal,max_reserved_gib=torch.cuda.max_memory_reserved()/2**30,
        elapsed_seconds=time.monotonic()-begin,student_forwards=9,teacher_feature_extractions=9,optimizer_updates=0,
        scope='Functional full2048 frozen-Encoder/price volume backward and private8train calibration; production pilot will calibrate independently. No reconstruction quality claim or reserved-data use.')
    atomic_json(root/'result.json',result);atomic_json(root/'status.json',dict(state='complete',pid=os.getpid()));print(result,flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('root',type=Path);parser.add_argument('--prepare',action='store_true');parser.add_argument('--run',action='store_true');a=parser.parse_args();root=a.root.resolve()
    try:
        if a.prepare:print(prepare(root),flush=True)
        elif a.run:run(root)
        else:parser.error('Specify a mode')
    except BaseException as error:
        if not a.prepare:atomic_json(root/'status.json',dict(state='failed',pid=os.getpid(),error=repr(error)))
        raise


if __name__=='__main__':main()
