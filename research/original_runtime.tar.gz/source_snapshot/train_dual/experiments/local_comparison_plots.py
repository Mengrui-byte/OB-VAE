"""Two reproducible plots from saved256minute Global/Local ablation outputs."""

import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager,ticker
import numpy as np
from plotly.offline import get_plotlyjs

from train_dual.util.checkpoint import freeze_sources


MODELS=[dict(key='truth',label='真实订单簿',color='#2563eb'),dict(key='baseline',label='完整Global＋Local',color='#15803d'),
        dict(key='mean_global',label='Local＋Global训练均值',color='#d97706'),dict(key='zero_global',label='Local＋Global置零',color='#dc2626')]
STYLE='''<meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><style>body{font:16px system-ui;max-width:1550px;margin:28px auto;padding:0 20px;color:#172b45;line-height:1.75}a{color:#2563eb}.controls{display:flex;flex-wrap:wrap;gap:18px;align-items:center;background:#eef3f8;padding:14px;position:sticky;top:0;z-index:10}select{font:inherit;padding:5px}table{border-collapse:collapse;width:100%}td,th{padding:7px;border:1px solid #ddd}.note{color:#526276}#chart{min-height:700px}</style>'''
NOTE='同一256分钟参考模型的512步权重；2025Q1开发样本，已用于研究。两种Local条件仅替换Cross之后的Global，Local保持原值。推理只使用整窗首帧价格锚点，没有逐分钟真实中间价旁路，也没有事后平移重建曲线。'
MID_PAGE='''<!doctype html><html lang=zh-CN><title>256分钟中间价重建对比</title>__STYLE__<h1>中间价曲线：完整256分钟的重建对比</h1><p>__NOTE__ 中间价按同一帧最优买价、最优卖价的平均计算。</p><p><a href=frames.html>订单簿抽样帧对比</a> · <a href=midprice_comparison.png>下载全部窗口PNG</a> · <a href=midprice_comparison.svg>下载SVG</a> · <a href=manifest.json>数据和抽样说明</a></p><div class=controls><label>窗口 <select id=sample></select></label></div><p id=window></p><div id=chart></div><h2>所选窗口的中间价误差（USDT）</h2><table><thead><tr><th>条件</th><th>RMSE</th><th>MAE</th><th>最大绝对误差</th></tr></thead><tbody id=metrics></tbody></table><script src=plotly.min.js></script><script>let d;const $=id=>document.getElementById(id);async function draw(){let w=+$('sample').value,v=d.windows[w],traces=[];for(let m of d.models){traces.push({x:v.time,y:v.mid[m.key],name:m.label,mode:'lines',line:{color:m.color,width:m.key==='truth'?2:1.5,dash:m.key==='zero_global'?'dash':'solid'},hovertemplate:'%{x}<br>中间价 %{y:.3f} USDT<extra>'+m.label+'</extra>'});if(m.key!=='truth')traces.push({x:v.time,y:v.mid[m.key].map((x,t)=>x-v.mid.truth[t]),name:m.label,xaxis:'x2',yaxis:'y2',mode:'lines',showlegend:false,line:{color:m.color},hovertemplate:'%{x}<br>误差 %{y:.3f} USDT<extra>'+m.label+'</extra>'})}await Plotly.react('chart',traces,{height:760,title:'窗口'+(w+1)+' · 256分钟',template:'plotly_white',margin:{t:80,l:85,r:25,b:65},legend:{orientation:'h',y:1.13},xaxis:{domain:[0,1],anchor:'y',type:'date',title:'时间（UTC）'},yaxis:{domain:[.39,1],title:'中间价（USDT）'},xaxis2:{domain:[0,1],anchor:'y2',type:'date',matches:'x',title:'时间（UTC）'},yaxis2:{domain:[0,.25],title:'预测－真实（USDT）',zeroline:true},annotations:[{xref:'paper',yref:'paper',x:.01,y:.28,text:'中间价误差；未作任何位置对齐',showarrow:false}]},{responsive:true,displaylogo:false,scrollZoom:true,toImageButtonOptions:{filename:'midprice_window'+(w+1),format:'png',scale:2}});$('window').textContent=v.time[0]+' 至 '+v.time.at(-1)+'；开发窗口索引 '+v.index;let rows=[];for(let m of d.models.slice(1)){let z=v.metrics[m.key],r=document.createElement('tr');for(let x of [m.label,z.rmse.toFixed(3),z.mae.toFixed(3),z.max_absolute_error.toFixed(3)]){let c=document.createElement('td');c.textContent=x;r.append(c)}rows.push(r)}$('metrics').replaceChildren(...rows);window.midReady=true}fetch('mid_data.json').then(x=>x.json()).then(x=>{d=x;d.windows.forEach((w,i)=>$('sample').add(new Option('窗口'+(i+1)+' · '+w.time[0],i)));return draw()}).catch(console.error);$('sample').onchange=draw;</script></html>'''
FRAMES_PAGE='''<!doctype html><html lang=zh-CN><title>抽样帧订单簿重建对比</title>__STYLE__<h1>订单簿抽样帧：每个档位一条挂单线</h1><p>__NOTE__ 每个窗口固定取第1、52、103、154、205、256分钟，与重建误差无关。左列真实、右列所选重建；每个有效档位画一条独立竖线，买盘绿色、卖盘红色。每行真实与重建使用相同坐标范围。</p><p><a href=mid.html>中间价曲线对比</a> · <a id=png href=book_frames_window1.png>下载所选窗口PNG（Local＋Global置零）</a> · <a href=manifest.json>数据和抽样说明</a></p><div class=controls><label>窗口 <select id=sample></select></label><label>模型 <select id=model></select></label><label>买卖侧 <select id=side><option value=both>买卖两侧</option><option value=0>仅买盘</option><option value=1>仅卖盘</option></select></label><label>横轴 <select id=axis><option value=price>实际价格（USDT）</option><option value=rank>档位序号</option></select></label></div><p class=note>价格轴保留实际定位误差；档位轴便于比较挂量。可框选放大、悬停查看档位。没有将重建价格对齐到真实中间价。</p><p id=window></p><div id=chart></div><script src=plotly.min.js></script><script>let meta,data,loaded=-1;const $=id=>document.getElementById(id);async function draw(){let w=+$('sample').value,key=$('model').value;if(w!==loaded){data=await(await fetch('frames_window'+w+'.json')).json();loaded=w}let traces=[],annotations=[],layout={height:1900,template:'plotly_white',margin:{t:45,b:65,l:70,r:20},showlegend:false},sides=$('side').value==='both'?[0,1]:[+$('side').value],rank=$('axis').value==='rank';for(let r=0;r<6;r++){let lo=Infinity,hi=-Infinity,maxq=0;for(let k of ['truth',key])for(let s of sides)for(let l=0;l<data.mask[r][s].length;l++)if(data.mask[r][s][l]){let [p,q]=data.books[k][r][s][l],a=rank?l+1:p;lo=Math.min(lo,a);hi=Math.max(hi,a);maxq=Math.max(maxq,q)}let pad=Math.max((hi-lo)*.025,rank?1:.1),yd=[1-(r+1)/6+.035,1-r/6-.035];for(let col=0;col<2;col++){let n=r*2+col+1,suffix=n===1?'':n,xx='x'+suffix,yy='y'+suffix,k=col?key:'truth',xd=col?[.55,1]:[0,.45];layout['xaxis'+suffix]={domain:xd,anchor:yy,range:[lo-pad,hi+pad],title:rank?'档位序号':'价格（USDT）',tickformat:rank?'d':',.0f'};layout['yaxis'+suffix]={domain:yd,anchor:xx,range:[0,Math.max(1,maxq*1.06)],title:'挂量 BTC'};annotations.push({xref:'paper',yref:'paper',x:(xd[0]+xd[1])/2,y:yd[1]+.012,text:'第'+(meta.positions[r]+1)+'分钟 · '+data.time[r].slice(11,19)+' UTC · '+(col?meta.models.find(m=>m.key===key).label:'真实订单簿'),showarrow:false,font:{size:13}});for(let s of sides){let x=[],y=[],custom=[];for(let l=0;l<data.mask[r][s].length;l++)if(data.mask[r][s][l]){let [p,q]=data.books[k][r][s][l],a=rank?l+1:p;x.push(a,a,null);y.push(0,q,null);custom.push([l+1,p,q],[l+1,p,q],null)}traces.push({type:'scattergl',mode:'lines',x,y,customdata:custom,xaxis:xx,yaxis:yy,line:{color:s?'#dc2626':'#15803d',width:1},name:s?'卖盘':'买盘',hovertemplate:'档位 %{customdata[0]}<br>价格 %{customdata[1]:.3f} USDT<br>挂量 %{customdata[2]:.5f} BTC<extra>'+(s?'卖盘':'买盘')+'</extra>'})}}}layout.annotations=annotations;await Plotly.react('chart',traces,layout,{responsive:true,displaylogo:false,scrollZoom:true,toImageButtonOptions:{filename:'book_frames_window'+(w+1)+'_'+key,format:'png',scale:2}});$('window').textContent='开发窗口 '+data.index+'；窗口范围 '+meta.windows[w].start+' 至 '+meta.windows[w].end;$('png').href='book_frames_window'+(w+1)+'.png';window.framesReady=true;window.frameSelection={w,key,side:$('side').value,axis:$('axis').value}}fetch('manifest.json').then(x=>x.json()).then(x=>{meta=x;meta.windows.forEach((w,i)=>$('sample').add(new Option('窗口'+(i+1)+' · '+w.start,i)));meta.models.slice(1).forEach(m=>$('model').add(new Option(m.label,m.key)));$('model').value='zero_global';return draw()}).catch(console.error);for(let id of ['sample','model','side','axis'])$(id).onchange=draw;</script></html>'''


def main(root):
    root=root.resolve();folder=root/('comparison_plots_'+datetime.now().strftime('%Y%m%d_%H%M%S'));folder.mkdir()
    with np.load(root/'profiles.npz') as f:arrays={k:f[k] for k in ('truth','baseline','mean_global','zero_global','mask','time','indices')}
    assert arrays['truth'].shape==(3,256,2,2048,2) and arrays['mask'][:,:,:,0].all()
    positions=np.linspace(0,255,6,dtype=int);windows=[];mid_windows=[];frame_result=json.loads((root/'results.json').read_text())
    for w,index in enumerate(arrays['indices']):
        times=[str(np.datetime64(int(t),'us'))+'Z' for t in arrays['time'][w]];mids={m['key']:arrays[m['key']][w,:,:,0,0].mean(1) for m in MODELS}
        metrics={}
        for m in MODELS[1:]:
            error=mids[m['key']]-mids['truth'];metrics[m['key']]=dict(rmse=float(np.sqrt(np.mean(error**2))),mae=float(np.abs(error).mean()),max_absolute_error=float(np.abs(error).max()))
            expected=[f['mid_absolute_error'] for f in frame_result['rows'][m['key']]['frames'] if f['window']==int(index)]
            np.testing.assert_allclose(np.abs(error),expected,rtol=0,atol=1e-8)
        windows.append(dict(index=int(index),start=times[0],end=times[-1]));mid_windows.append(dict(index=int(index),time=times,mid={k:v.tolist() for k,v in mids.items()},metrics=metrics))
        payload=dict(index=int(index),time=[times[t] for t in positions],mask=arrays['mask'][w,positions].tolist(),books={m['key']:arrays[m['key']][w,positions].tolist() for m in MODELS})
        (folder/f'frames_window{w}.json').write_text(json.dumps(payload,separators=(',',':'),allow_nan=False))
    manifest=dict(windows=windows,models=MODELS,positions=positions.tolist(),frame_minutes=(positions+1).tolist(),input_minutes=256,
        data_split='2025Q1development;2022–2024training; already used for research',checkpoint_step=512,source=str(root/'profiles.npz'),
        source_sha256=hashlib.sha256((root/'profiles.npz').read_bytes()).hexdigest(),sampling='Three pre-existing diagnostic windows;6equally spaced frames chosen without looking at reconstruction outcomes',
        price_alignment='None. All lines are raw saved physical-unit predictions; midpoint subtraction occurs only in the explicitly labeled error panel.',midpoint='(best_bid+best_ask)/2',
        first_frame_anchor_only=True,midpoint_metrics_replay_verified=True)
    (folder/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2));(folder/'mid_data.json').write_text(json.dumps(dict(models=MODELS,windows=mid_windows),ensure_ascii=False,allow_nan=False))
    for name,page in [('mid.html',MID_PAGE),('frames.html',FRAMES_PAGE)]:
        (folder/name).write_text(page.replace('__STYLE__',STYLE).replace('__NOTE__',NOTE))
    (folder/'index.html').write_text('<!doctype html><meta charset=utf-8>'+STYLE+'<h1>256分钟重建：两组对比图</h1><p><a href=mid.html>① 完整中间价曲线</a></p><p><a href=frames.html>② 六个抽样帧的逐档订单簿</a></p><p>'+NOTE+'</p>')
    (folder/'plotly.min.js').write_text(get_plotlyjs())
    font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
    font_manager.fontManager.addfont(font);plt.rcParams.update({'font.family':font_manager.FontProperties(fname=font).get_name(),'axes.unicode_minus':False,'font.size':10})
    fig,axes=plt.subplots(3,2,figsize=(15,10),layout='constrained')
    for w,v in enumerate(mid_windows):
        x=np.arange(1,257);truth=np.array(v['mid']['truth'])
        for m in MODELS:
            y=np.array(v['mid'][m['key']]);axes[w,0].plot(x,y,color=m['color'],lw=1.5 if m['key']=='truth' else 1.1,label=m['label'],ls='--' if m['key']=='zero_global' else '-')
            if m['key']!='truth':axes[w,1].plot(x,y-truth,color=m['color'],lw=1.1,label=m['label'])
        for col in range(2):
            ax=axes[w,col];ax.set_title(f"窗口{w+1} · {v['time'][0][:10]} · "+('中间价' if col==0 else '预测－真实'));ax.grid(alpha=.2);ax.set_xlim(1,256);ax.set_xlabel('窗口内分钟');ax.set_ylabel('USDT');ax.yaxis.set_major_formatter(ticker.StrMethodFormatter('{x:,.0f}'))
        axes[w,1].axhline(0,color='#64748b',lw=.7);axes[w,0].legend(fontsize=8,loc='best')
    fig.suptitle('完整256分钟中间价重建对比｜同一512步模型｜2025Q1开发样本',fontsize=16)
    fig.savefig(folder/'midprice_comparison.png',dpi=180);fig.savefig(folder/'midprice_comparison.svg');plt.close(fig)
    for w in range(3):
        fig,axes=plt.subplots(6,2,figsize=(15,18),layout='constrained')
        for r,t in enumerate(positions):
            valid=arrays['mask'][w,t];books=[arrays['truth'][w,t],arrays['zero_global'][w,t]];lo=min(x[...,0][valid].min() for x in books);hi=max(x[...,0][valid].max() for x in books);maxq=max(x[...,1][valid].max() for x in books);pad=max(.1,(hi-lo)*.025)
            for col,(book,label) in enumerate(zip(books,['真实订单簿','Local＋Global置零'])):
                ax=axes[r,col]
                for side,color in [(0,'#15803d'),(1,'#dc2626')]:
                    v=valid[side];ax.vlines(book[side,v,0],0,book[side,v,1],color=color,lw=.65,alpha=.8,label='买盘' if side==0 else '卖盘')
                ax.set_xlim(lo-pad,hi+pad);ax.set_ylim(0,max(1,maxq*1.06));ax.set_title(f'第{t+1}分钟 · {mid_windows[w]["time"][t][11:19]} UTC · '+label,fontsize=10);ax.set_xlabel('实际价格（USDT）');ax.set_ylabel('挂量（BTC）');ax.grid(alpha=.15);ax.xaxis.set_major_formatter(ticker.StrMethodFormatter('{x:,.0f}'))
                if r==0:ax.legend(fontsize=8)
        fig.suptitle(f'窗口{w+1} · {windows[w]["start"][:10]}｜6个固定抽样帧｜每档独立挂单线',fontsize=16)
        fig.savefig(folder/f'book_frames_window{w+1}.png',dpi=180);plt.close(fig)
    freeze_sources(folder/'source_snapshot')
    selector=root.parents[1]/'.local/dual_viewer/current.json';viewer=Path(json.loads(selector.read_text())['directory']);(viewer/'comparisons').symlink_to(folder,target_is_directory=True)
    (root/'latest_comparison_plots.json').write_text(json.dumps(dict(directory=str(folder),mid_url='http://172.16.30.28:8874/comparisons/mid.html',frames_url='http://172.16.30.28:8874/comparisons/frames.html')))
    Path('/tmp/local_comparison_plots_path').write_text(str(folder));print(folder,flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('root',type=Path);main(parser.parse_args().root)
