"""Gradient audit plus2x2 latent-capacity/quantity-loss fitting controls."""
import argparse
from datetime import datetime
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import numpy as np
import torch
from model.autoencoder.unified_book_vae import UnifiedOrderBookVAE
from model.experimental.widen_unified import load_balanced_double_latent
from model.losses.controlled_book import ControlledBookLoss
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.gradient_audit import audit
from train_dual.experiments.long_worker import atomic_json,evaluate
from train_dual.experiments.local_quant_reconstruction import CacheWindows
from train_dual.experiments.unified_8192_run import call,group_gradients,write_profiles
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import atomic_save,freeze_sources,load_for_inference,seed_everything,source_hashes

LANES={'huber8192':dict(latent_channels=128,loss_mode='baseline'),'mse8192':dict(latent_channels=128,loss_mode='quantity_mse'),'huber16384':dict(latent_channels=256,loss_mode='baseline'),'mse16384':dict(latent_channels=256,loss_mode='quantity_mse')}


def prepare(parent):
 torch.set_num_threads(4);seed_everything(42);parent=parent.resolve();project=Path(__file__).resolve().parents[2];root=project/'recons'/('gradient_capacity_'+datetime.now().strftime('%Y%m%d_%H%M%S'));root.mkdir();(root/'data').mkdir();(root/'logs').mkdir()
 for name in ['train_indices.npy','val_indices.npy']:os.link(parent/name,root/name)
 os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz');os.link(parent/'ae/step2048.pt',root/'initial.pt')
 plan=json.loads((parent/'plan.json').read_text());plan.update(experiment='Gradient audit and2x2capacity-loss training fit controls',parent=str(parent),lanes=LANES,steps=512,checkpoints=[32,128,256,512],fit_windows=4,training_windows_source=64,accumulation=1,max_seconds=3600,
  labels={'huber8192':'8192·原Huber','mse8192':'8192·数量MSE','huber16384':'16384·原Huber','mse16384':'16384·数量MSE'},
  control_contract='2x2factorial: latent128/256channels and originalHuber/quantityMSE; other architecture, data, budget,seed42 andfreshAdamW1e-4 fixed. All full256frame windows. All shared parameters fromAE2048. Wide posterior +/-balanced perturbation anddecoderinput half-weights preserve initial decoded function up to audited FP32 tolerance. New optimizer is fresh for all4, so not an exact continuation of old optimizer trajectory.',
  scope='Only4trainingwindows overfit diagnostic; not a substitute for64window or independent-test performance. Wide16384 is capacity diagnosis, not a change to8192mainline. Negative results at512steps do not prove impossibility. No high-resolution encoder skips.',
  gradient_audit='4fixed original trainingwindows, per-layerL2/RMS, relativegradient, activity, price/quantity taskcosine, globalclip, finite-difference descent andrestored-vs-freshAdam steps, matchedFP32/BF16; no parameter updates to any existing run.',
  device='RemoteGPU2audit, then4parallel single-GPUoverfit controls onGPU2–5. Existing4loss runs continue; short diagnostics share available GPUmemory, durations are reported.',
  evaluation='All4seen windows atdeclared endpoints and16fixeddevelopment windows atfinal, with no future-return training or selection. No seed sweep.',
  objective=dict(price_weight=1.,quantity_weight=1.,log_weight=1.,pair_weight=.25,topk=16))
 atomic_json(root/'plan.json',plan)
 train=dataset(root,'train');indices=np.load(root/'train_indices.npy');positions=np.unique(np.linspace(0,len(indices)-1,4,dtype=int));selected=indices[positions];np.save(root/'small_train_indices.npy',selected)
 items=[train[int(i)] for i in selected];cached={k:torch.stack([x[k] for x in items]) for k in items[0]};torch.save(cached,root/'small_train.pt')
 atomic_json(root/'data_contract.json',dict(raw_shape=list(cached['data'].shape),training_cache_positions=positions.tolist(),original_training_indices=selected.tolist(),frames=256,levels_per_side=2048,selection='4equally spaced positions in pre-existing64trainingindices, before inspecting losses; no development samples selected'))
 payload=torch.load(root/'initial.pt',map_location='cpu',weights_only=False);cfg=dict(payload['unified_vae_config'],latent_channels=256);wide=UnifiedOrderBookVAE(**cfg);load_balanced_double_latent(wide,payload['model'])
 atomic_save(dict(format_version=1,model=wide.state_dict(),unified_vae_config=cfg,config=payload['config'],step=0,source_step=2048,widening_seed=42,balanced_perturbation=.01),root/'initial_wide.pt')
 freeze_sources(root/'source_snapshot');atomic_json(root/'status.json',dict(state='prepared'))
 remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
 (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.gradient_capacity_run "{remote}"\n')
 Path('/tmp/gradient_capacity_path').write_text(str(root));print(root,flush=True)


def worker(root,lane):
 torch.set_num_threads(4);seed_everything(42);strict_precision();started=time.monotonic();plan=json.loads((root/'plan.json').read_text());case=plan['lanes'][lane];folder=root/lane;folder.mkdir(exist_ok=True);path=root/('initial.pt' if case['latent_channels']==128 else 'initial_wide.pt');payload=torch.load(path,map_location='cpu',weights_only=False);model,norm=load_for_inference(path,'cuda:0');cfg=payload['unified_vae_config'];train_original=dataset(root,'train');val_original=dataset(root,'val');ids=np.load(root/'small_train_indices.npy');vi=np.load(root/'val_indices.npy');train=CacheWindows(train_original,ids);val=CacheWindows(val_original,vi);raw=torch.load(root/'small_train.pt',map_location='cpu',weights_only=False);batches=[norm.prepare({k:v[i:i+1] for k,v in raw.items()},'cuda:0') for i in range(len(ids))]
 criterion=ControlledBookLoss(plan['normalization']['quantity_scale'],mode=case['loss_mode'],**plan['objective']);opt=torch.optim.AdamW(model.parameters(),lr=1e-4,weight_decay=0.);hashes=source_hashes()
 def save(step):atomic_save(dict(format_version=1,model=model.state_dict(),unified_vae_config=cfg,config=dict(payload['config'],loss=dict(mode=case['loss_mode'],**plan['objective'])),step=step,source_step=2048,optimizer=opt.state_dict(),source_hashes=hashes),folder/f'step{step}.pt')
 try:
  atomic_json(folder/'status.json',dict(state='initial_evaluation'));result=evaluate(model,norm,train,len(train),'cuda:0');atomic_json(folder/'step0_train.json',dict(result=result));atomic_json(folder/'status.json',dict(state='training'))
  for step in range(1,plan['steps']+1):
   if time.monotonic()-started>plan['max_seconds']:raise TimeoutError('1hour diagnostic ceiling')
   b=batches[(step-1)%len(batches)];model.train();opt.zero_grad(set_to_none=True)
   with torch.autocast('cuda',dtype=torch.bfloat16):out=call(model,b,False)
   assert list(out['z'].shape)==[1,64,case['latent_channels']] and list(out['volume'].shape)==[1,256,2,2048]
   values=criterion(out,b,beta=0.)
   if not bool(torch.isfinite(values['loss'])):raise FloatingPointError('Nonfinite capacityloss')
   values['loss'].backward()
   if step==1:atomic_json(folder/'first_step_gradients.json',group_gradients(model))
   gn=torch.nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True);opt.step()
   if step==1 or step%8==0:
    row=dict(step=step,total=plan['steps'],loss=float(values['loss'].detach()),base_loss=float(values['base_loss'].detach()),gradient_norm=float(gn),elapsed_seconds=time.monotonic()-started,latent_shape=list(out['z'].shape),allocated_gib=torch.cuda.max_memory_allocated()/2**30);atomic_json(folder/'progress.json',row)
    with (folder/'progress.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
    print(json.dumps(row),flush=True)
   if step in plan['checkpoints']:
    result=evaluate(model,norm,train,len(train),'cuda:0');atomic_json(folder/f'step{step}_train.json',dict(result=result));save(step)
  dev=evaluate(model,norm,val,len(val),'cuda:0');atomic_json(folder/'final_development.json',dict(result=dev));write_profiles(root,folder,step,model,norm,train_original,ids);atomic_json(folder/'status.json',dict(state='complete',step=step,elapsed_seconds=time.monotonic()-started))
 except BaseException as e:atomic_json(folder/'status.json',dict(state='failed',error=repr(e)));raise


def check_widening(root):
 model,norm=load_for_inference(root/'initial.pt','cuda:0');wide,_=load_for_inference(root/'initial_wide.pt','cuda:0');raw=torch.load(root/'small_train.pt',map_location='cpu',weights_only=False);b=norm.prepare({k:v[:1] for k,v in raw.items()},'cuda:0')
 with torch.inference_mode():
  a=call(model,b,False);c=call(wide,b,False)
  delta={k:float((a[k]-c[k]).abs().max()) for k in ['price_norm','volume']}
 atomic_json(root/'initial_widening_replay.json',dict(max_absolute_deltas=delta,latent_shapes=[list(a['z'].shape),list(c['z'].shape)],shared_weights=True,balanced_posterior_perturbation=.01,description='Balanced widening preserves initial function in real arithmetic; FP32 kernel differences audited, not bit-exact.'))
 if delta['price_norm']>1e-3 or delta['volume']>1e-2:raise RuntimeError(f'Widening initialfunction replay failed:{delta}')
 del model,wide,a,c;torch.cuda.empty_cache()


def campaign(root):
 torch.set_num_threads(4);seed_everything(42);strict_precision();children=[];started=time.monotonic()
 def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
 signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
 try:
  atomic_json(root/'status.json',dict(state='gradient_audit'));audit(root);check_widening(root)
  plan=json.loads((root/'plan.json').read_text())
  for gpu,lane in zip([2,3,4,5],plan['lanes']):
   env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),CUDA_DEVICE_ORDER='PCI_BUS_ID',PYTHONPATH=str(root/'source_snapshot'))
   with (root/'logs'/f'{lane}.log').open('ab',buffering=0) as log:p=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.gradient_capacity_run',str(root),'--lane',lane],cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   children.append((lane,gpu,p))
  atomic_json(root/'status.json',dict(state='capacity_controls_running',children=[dict(lane=l,gpu=g,pid=p.pid) for l,g,p in children]))
  while any(p.poll() is None for _,_,p in children):
   if time.monotonic()-started>5400:raise TimeoutError('90minute diagnostic ceiling')
   time.sleep(5)
  failures={l:p.returncode for l,_,p in children if p.returncode};atomic_json(root/'status.json',dict(state='partial_failure' if failures else 'complete',failures=failures,elapsed_seconds=time.monotonic()-started))
 except BaseException as e:atomic_json(root/'status.json',dict(state='failed',error=repr(e)));raise
 finally:
  for _,_,p in children:
   if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--lane');a=p.parse_args()
 if a.prepare:prepare(a.root)
 elif a.lane:worker(a.root,a.lane)
 else:campaign(a.root)
