"""Frozen final checkpoints on predeclared stratified2026 book windows."""

import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import Dataset

from train_dual.experiments.book_stem_viewer import build
from train_dual.experiments.long_worker import atomic_json,evaluate
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import atomic_save,freeze_sources,load_for_inference,seed_everything
from train_dual.util.data import DualWindowDataset
from train_dual.util.dynamics import DynamicsMetrics


def sha256(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda:stream.read(4*1024*1024),b''):digest.update(chunk)
    return digest.hexdigest()


class FixtureDataset(Dataset):
    def __init__(self,fixtures):self.fixtures=fixtures
    def __len__(self):return len(self.fixtures['data'])
    def __getitem__(self,index):return {k:self.fixtures[k][index] for k in ('data','level_counts','times')}


def prepare(parent,windows=6,seed=42):
    parent=parent.resolve();root=parent.parent/('inspection_2026_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
    initial=torch.load(parent/'initial.pt',map_location='cpu',weights_only=False)
    arguments=initial['config']['arguments'];assert arguments['start']=='2022-01-01' and arguments['end']=='2025-01-01'
    archive=parent/'data/BTCUSDT.npz'
    with np.load(archive,allow_pickle=False) as p:metadata=json.loads(p['metadata'].item())
    end=min(metadata['available_end'],'2027-01-01');assert end>'2026-01-01'
    data=DualWindowDataset(asset='BTCUSDT',npz_dir=archive,start='2026-01-01',end=end,levels=arguments['levels'],window_size=16,stride=16,time_unit_seconds=arguments.get('time_unit_seconds',60))
    if windows<1 or len(data)<windows:raise ValueError('Not enough nonoverlapping2026 windows')
    rng=np.random.default_rng(seed);strata=np.array_split(np.arange(len(data)),windows)
    indices=np.array([rng.choice(s) for s in strata],dtype=np.int64)
    records=[data[int(i)] for i in indices]
    absolute=np.stack([data.base.times[int(data.base.starts[int(i)]):int(data.base.starts[int(i)])+16] for i in indices])
    assert (absolute>=np.datetime64('2026-01-01','us').astype(np.int64)).all()
    assert (np.diff(absolute//60_000_000,axis=1)==1).all()
    root.mkdir();(root/'weights').mkdir();(root/'logs').mkdir()
    payload={key:torch.stack([record[key] for record in records]) for key in ('data','level_counts','times')}
    payload.update(absolute_times=torch.from_numpy(absolute),indices=torch.from_numpy(indices));atomic_save(payload,root/'fixtures.pt')
    parent_plan=json.loads((parent/'plan.json').read_text())
    variants={'source':dict(label='原未压缩Cross',filename='source.pt',parent_path=str(parent/'initial.pt'))}
    for lane,label in parent_plan['labels'].items():variants[lane]=dict(label=label+'·2048步',filename=lane+'.pt',parent_path=str(parent/lane/'final.pt'))
    for v in variants.values():
        os.link(v['parent_path'],root/'weights'/v['filename']);v['sha256']=sha256(root/'weights'/v['filename'])
    plan=dict(parent=str(parent),task='Frozen2026 reconstruction inspection; no training',train=[arguments['start'],arguments['end']],evaluation_period=['2026-01-01',end],seed=seed,windows=windows,candidate_windows=len(data),variants=variants,
        sampling='One uniform random window per equal-size stratum of all valid chronological16minute nonoverlapping windows; numpy default_rng(seed42); fixed before any checkpoint inference; no filtering by reconstruction or market features.',
        sampled_windows=[dict(index=int(i),stratum=[int(s[0]),int(s[-1])],start_utc=str(np.datetime64(int(t[0]),'us'))+'Z',end_utc=str(np.datetime64(int(t[-1]),'us'))+'Z') for i,s,t in zip(indices,strata,absolute)],
        fixtures_sha256=sha256(root/'fixtures.pt'),normalization=initial['config']['normalization'],source_archive=dict(path=str(archive),size_bytes=archive.stat().st_size,available_end=metadata['available_end']),
        selection='Source reference and all four pre-existing2048step final models fixed before inference; no2026 refitting, calibration, checkpoint choice, or training.',precision='FP32; TF32 disabled',independent_2025Q2_evaluated=False)
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(parent.parents[1])
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.sample_2026_reconstruction "{remote}"\n')
    Path('/tmp/inspection_2026_path').write_text(str(root));print(root,flush=True)


def per_window(truth,prediction,mask,tick):
    metric=DynamicsMetrics(tick);metric.update(truth,prediction,mask);value=metric.finish();q=truth[...,1];qh=prediction[...,1]
    a=(q>=100)&mask;b=(qh>=100)&mask;tp=int((a&b).sum());fp=int((~a&b).sum());fn=int((a&~b).sum())
    value['threshold_100btc']=dict(tp=tp,fp=fp,fn=fn,recall=tp/(tp+fn) if tp+fn else None,precision=tp/(tp+fp) if tp+fp else None)
    return value


def run(root):
    torch.set_num_threads(4);seed_everything(42);strict_precision();plan=json.loads((root/'plan.json').read_text());device='cuda:0'
    fixtures=torch.load(root/'fixtures.pt',map_location='cpu',weights_only=False);assert sha256(root/'fixtures.pt')==plan['fixtures_sha256']
    data=FixtureDataset(fixtures);truth=fixtures['data'].numpy();mask=np.arange(truth.shape[-2])<fixtures['level_counts'].numpy()[...,None]
    arrays=dict(truth=truth,mask=mask,time=fixtures['absolute_times'].numpy(),indices=fixtures['indices'].numpy());results={}
    atomic_json(root/'status.json',dict(state='running'))
    try:
        for lane,spec in plan['variants'].items():
            checkpoint=root/'weights'/spec['filename'];assert sha256(checkpoint)==spec['sha256']
            model,norm=load_for_inference(checkpoint,device);metrics=evaluate(model,norm,data,len(data),device);model.eval();predictions=[];matrices=[];details=[]
            with torch.inference_mode():
                for i in range(len(data)):
                    batch=norm.prepare({k:v.unsqueeze(0) for k,v in data[i].items()},device)
                    output=model(batch['price'],batch['volume'],batch['mask'],batch['tick_norm'],times=batch['times'],sample=False)
                    prediction=np.stack([norm.inverse_price(output['price_norm'],batch)[0].cpu().numpy(),output['volume'][0].cpu().numpy()],-1)
                    if not np.isfinite(prediction[mask[i]]).all():raise FloatingPointError('Nonfinite output')
                    if lane!='source':
                        assert list(output['matrix_latent'].shape)==[1,16,1024]
                        replay=model.decode_matrix(output['matrix_latent'],batch['mask'],batch['tick_norm'],batch['times'])
                        for k in ('price_norm','volume'):torch.testing.assert_close(output[k],replay[k],rtol=0,atol=0)
                        matrices.append(output['matrix_latent'][0].cpu().numpy())
                    predictions.append(prediction);details.append(per_window(truth[i],prediction,mask[i],norm.tick_size))
            arrays[lane]=np.stack(predictions)
            if matrices:np.savez_compressed(root/(lane+'_matrices.npz'),matrix=np.stack(matrices))
            results[lane]=dict(label=spec['label'],result=metrics,per_window=details,checkpoint_sha256=spec['sha256'],matrix_only_decode_exact=lane!='source')
            atomic_json(root/'results.json',dict(plan=plan,variants=results));print(lane,json.dumps(metrics['metrics']['quantity_btc']),flush=True)
            del model;torch.cuda.empty_cache()
        np.savez_compressed(root/'profiles.npz',**arrays);atomic_json(root/'status.json',dict(state='complete'))
    except BaseException as error:atomic_json(root/'status.json',dict(state='failed',error=repr(error)));raise


REPORT='''<!doctype html><html lang=zh-CN><meta charset=utf-8><title>2026订单簿抽样重建</title><style>body{font:16px system-ui;max-width:1400px;margin:32px auto;padding:0 20px;line-height:1.8}table{border-collapse:collapse;width:100%}td,th{padding:8px;border:1px solid #ddd}a{color:#2563eb}</style><h1>2026订单簿：固定权重抽样重建</h1><p>6个16分钟窗口，按2026年可用时间分6段，每段固定随机抽一个。抽样先于推理，没有按恢复效果挑选。模型训练期为2022–2024，2025Q1用于开发；本次沿用既有权重和归一化，仅推理。小样本只用于检查，不能代表2026全年表现。重建使用完整非因果输入窗口，不能解释为未来预测。</p><p><a href=../>查看每个档位一条线的订单簿</a> · <a href=results.json>完整指标和抽样清单</a> · <a href=plan.json>抽样和权重清单</a> · <a href=../previous/>上一轮2025Q1结果</a></p><h2>同一批6个窗口的合并指标</h2><table><thead><tr><th>模型</th><th>价格RMSE USDT</th><th>挂量RMSE BTC</th><th>分钟挂量变化相关</th><th>≥100BTC召回</th><th>≥100BTC精确率</th></tr></thead><tbody id=aggregate></tbody></table><p id=counts></p><h2>抽样时间（UTC）</h2><table><thead><tr><th>窗口</th><th>开始</th><th>结束</th></tr></thead><tbody id=samples></tbody></table><h2>每个窗口</h2><table><thead><tr><th>窗口</th><th>模型</th><th>价格RMSE USDT</th><th>挂量RMSE BTC</th><th>分钟挂量变化相关</th><th>≥100BTC召回</th></tr></thead><tbody id=details></tbody></table><script>const f=(x,n=3)=>Number.isFinite(x)?x.toFixed(n):'无样本';function row(xs){let r=document.createElement('tr');for(let x of xs){let c=document.createElement('td');c.textContent=x;r.append(c)}return r}fetch('results.json').then(x=>x.json()).then(d=>{let a=[],b=[];for(let [k,v] of Object.entries(d.variants)){let m=v.result.metrics,t=v.result.thresholds['100'];a.push(row([v.label,f(m.price_usdt.rmse),f(m.quantity_btc.rmse),f(m.temporal_log_quantity_1_minutes.correlation),f(t.recall===null?null:t.recall*100,1)+'%',f(t.precision===null?null:t.precision*100,1)+'%']));v.per_window.forEach((w,i)=>{let m=w.metrics,t=w.threshold_100btc;b.push(row([i+1,v.label,f(m.price_usdt.rmse),f(m.quantity_btc.rmse),f(m.temporal_log_quantity_1_minutes.correlation),f(t.recall===null?null:t.recall*100,1)+'%']))})}document.getElementById('aggregate').replaceChildren(...a);document.getElementById('details').replaceChildren(...b);document.getElementById('samples').replaceChildren(...d.plan.sampled_windows.map((w,i)=>row([i+1,w.start_utc,w.end_utc])));let t=d.variants.source.result.thresholds['100'];document.getElementById('counts').textContent='真实≥100BTC档位共'+(t.tp+t.fn)+'个，计数单位为时间×买卖侧×档位。'}).catch(console.error)</script></html>'''


def publish(root):
    root=root.resolve();assert json.loads((root/'status.json').read_text())['state']=='complete';plan=json.loads((root/'plan.json').read_text())
    description='2026年抽样样本外重建：模型训练于2022–2024，2025Q1用于开发。本页从2026-01-01至'+plan['evaluation_period'][1]+'（不含）的可用窗口中，分6段、每段随机抽一个16分钟窗口。抽样先于推理；五个模型沿用固定权重及归一化，本次没有训练或重新选择检查点。小样本不能代表全年表现。模型使用完整非因果输入窗口进行重建，不是未来预测。'
    config=[dict(key='truth',label='真实订单簿',color='#2563eb')]
    for (lane,spec),color in zip(plan['variants'].items(),['#64748b','#eab308','#2563eb','#9333ea','#16a34a']):config.append(dict(key=lane,label=spec['label'],color=color))
    atomic_json(root/'comparison.json',dict(viewer_variants=config,default_model=3,seed=plan['seed'],common_step=2048,
        step_note='2026年6个抽样窗口；压缩模型为固定2048步终点。',comparison_label='2026抽样指标和逐窗口对比',evaluation_period=plan['evaluation_period'],evaluation_description=description,
        evaluation_role='Frozen-checkpoint2026 sampled inspection, not whole-year performance',used_for_model_selection=False,inspection_manifest=str(root/'plan.json')))
    (root/'index.html').write_text(REPORT);viewer=root/'viewer';build(root,viewer)
    selector=root.parents[1]/'.local/dual_viewer/current.json';previous=Path(json.loads(selector.read_text())['directory'])
    (viewer/'previous').symlink_to(previous,target_is_directory=True)
    temp=selector.with_suffix('.tmp');temp.write_text(json.dumps(dict(directory=str(viewer))));temp.replace(selector)
    atomic_json(root/'published.json',dict(directory=str(viewer)));print(viewer,flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('root',type=Path);parser.add_argument('--prepare',action='store_true');parser.add_argument('--publish',action='store_true');parser.add_argument('--windows',type=int,default=6);args=parser.parse_args()
    if args.prepare:prepare(args.root,windows=args.windows)
    elif args.publish:publish(args.root)
    else:run(args.root)
