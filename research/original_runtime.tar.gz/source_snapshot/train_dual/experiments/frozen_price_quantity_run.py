"""Original native VAE: fixed Encoder/price, temporal x spatial Q finetuning."""
import argparse
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import numpy as np
import torch

from train_dual.experiments.confirm_recall_goal import require_matching_replay
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.goal_evaluate import assess_file
from train_dual.experiments.local_quant_reconstruction import CacheWindows
from train_dual.experiments.long_worker import atomic_json,evaluate
from train_dual.experiments.phase_detail_report import read,STYLE
from train_dual.experiments.price_safe_readout import file_hash,head_criterion,price_replay
from train_dual.experiments.recall_goal_run import record
from train_dual.experiments.region_task_run import safe_preview,gpu_free
from train_dual.experiments.time_logit_run import write_profiles
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import atomic_save,freeze_sources,load_for_inference,seed_everything,source_hashes
from train_dual.util.frozen_quantity import configure_quantity_training,decode_cached_quantity,restore_original_optimizer,audit_frozen_state,decoder_gradient_norms
from train_dual.util.phase_training import tensor_digest


LABELS=dict(control='数量Decoder冻结',temporal='仅解冻数量时间模块',spatial='仅解冻数量空间模块',both='解冻完整数量Decoder')
SWITCHES=dict(control=(False,False),temporal=(True,False),spatial=(False,True),both=(True,True))


def render(root):
    plan=read(root/'plan.json');state=read(root/'status.json',{})
    text='<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="30"><title>冻结价格：完整数量Decoder对照</title><style>'+STYLE+'</style><main><h1>固定Encoder与价格：数量时间模块 × 空间模块</h1><p>原生单Gaussian64×128，输入完整256分钟×双侧2048档。模型结构、参数数量、数据和损失均不变；只改变数量Decoder的训练开关。所有新增梯度仅进入数量Decoder，价格与Encoder权重及对应Adam状态逐值冻结。数量空间模块包括空间seed、买卖侧位置编码、价格几何、上采样及最终数量头。</p><p>同一来源、原32训练窗口、seed42、固定打乱顺序、batch1累积2、原Adam lr1e-4、clip1、2048次优化器调用，BF16神经/FP32损失和评估，TF32均关闭。无新读出头、无上采样修改、无额外损失、无增强和教师；hint对本轮关闭。冻结对照没有可训练参数，optimizer.step不会更新任何Adam状态，明确不算2048次有效权重更新。</p><p>训练复用冻结Encoder的Z和冻结价格Decoder的预测几何；它们来自同一个原生Z，绝不使用真实价格作解码条件。评估重新运行完整Encoder和双Decoder，不依赖训练缓存。状态：'+str(state.get('state'))+'</p><table><tr><th>组</th><th>调用步数</th><th>召回</th><th>精确率</th><th>价格RMSE</th><th>分钟变化RMSE</th><th>数量RMSE</th><th>联合通过</th></tr>'
    for lane,label in LABELS.items():
        for step in [0,*plan['checkpoints']]:
            p=root/lane/f'step{step}_development.json'
            if not p.exists():continue
            row=assess_file(p,root.parent/'reference_evaluation.json');values=[label,step,row['recall100'],row['precision100'],row['price_rmse'],row['mid_delta_rmse'],row['quantity_rmse'],row['pass']]
            text+='<tr>'+''.join('<td>'+str(round(v,5) if isinstance(v,float) else v)+'</td>' for v in values)+'</tr>'
    text+='</table><p>固定16个Q1开发窗口已反复用于研究，不是最终独立测试；Q2确认集未用于本轮。训练拟合另行报告，不能代替开发成绩或独立确认。每组预算3小时；可与现有主实验在远端2–5号卡共存，GPU0/1不参与。正在运行及排队的旧控制实验保持原预算与协议。</p><p><a href="plan.json">完整协议</a> · <a href="cache_audit.json">实际形状与缓存等价</a> · <a href="startup_control_audit.json">四组初始化对照</a> · <a href="design.md">设计说明</a></p></main>'
    (root/'index.html').write_text(text)


def prepare(goal):
    prior=goal/'price_safe_logit_readout'
    if read(prior/'status.json',{}).get('state')!='complete':raise ValueError('Complete prior readout controls first')
    root=goal/'frozen_price_quantity';root.mkdir();project=Path(__file__).resolve().parents[2]
    for name in ['data','logs',*LABELS]:(root/name).mkdir()
    for name in ['source.pt','source_development.json','train_indices.npy','train_order.npy','val_indices.npy','calibration.json','plotly.min.js']:os.link(prior/name,root/name)
    os.link(prior/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    payload=torch.load(root/'source.pt',map_location='cpu',weights_only=False);old=read(prior/'plan.json');model,_=load_for_inference(root/'source.pt')
    plan=dict(old);plan.update(experiment='Frozen Encoder and price; native Q temporal x spatial finetuning',labels=LABELS,
        lanes={lane:dict(temporal=t,spatial=s) for lane,(t,s) in SWITCHES.items()},positive_logit_study=False,
        learning_rate=1e-4,steps=2048,checkpoints=[256,1024,2048],accumulation=2,batch_size=1,max_seconds=10800,
        max_controller_seconds=12600,gpu_workers=list(zip([2,3,4,5],LABELS)),seed=42,source_model_sha256=tensor_digest(model),
        source_control='Same native source,32trainwindows/order/seed42/sourceAdam/loss; only Q temporal/spatial trainability changes. No new model parameter, Encoder bypass, upsampling change or future label. Cached Z and P are source predictions; fullmodeldevelopment inference.',
        source_hint_omitted='Hint disabled uniformly; unlike head-only experiments, omitted hint could have gradients on the trainable Q modules. All four arms use the same no-hint loss; no claim of equivalence to the teacher-trained main cohort.',
        training_precision='BF16 Q neural ops; FP32 posterior, cached predicted price geometry, loss and evaluation; bothTF32flags off',
        evaluation_scope='Fresh fullnative model on16reusedQ1development windows; not independent confirmation.',
        preview_descriptions={lane:'固定16个已用于研究的Q1开发窗口；完整256分钟、唯一8192Z。Encoder与价格冻结，仅按声明的开关微调数量Decoder。非独立测试。' for lane in LABELS})
    for key in ['reuse_cache','replay_controls','replay_control_root']:plan.pop(key,None)
    assert file_hash(root/'source.pt')==plan['source_sha256']
    assert [g['lr'] for g in payload['optimizer']['param_groups']]==[plan['learning_rate']]*2
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot');render(root)
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.frozen_price_quantity_run "{remote}" --controller >> "{remote}/logs/controller.log" 2>&1\n')
    record(goal,'frozen_price_quantity_prepared',root=root.name,hypothesis='Fixed linear readouts barely improve training; test original Q Decoder trainability with Encoder/P unchanged',steps=2048,source=plan['source_selection']);print(root,flush=True)


def cache_source(root):
    strict_precision();plan=read(root/'plan.json');model,norm=load_for_inference(root/'source.pt','cuda:0');model.eval();original=dataset(root,'train');cache=[];contracts=[]
    atomic_json(root/'cache_status.json',dict(state='running',pid=os.getpid()))
    for position,index in enumerate(np.load(root/'train_indices.npy')):
        raw={k:v.unsqueeze(0) for k,v in original[int(index)].items()};batch=norm.prepare(raw,'cuda:0');start=int(original.base.starts[int(index)]);times=original.base.times[start:start+256]
        assert list(raw['data'].shape)==[1,256,2,2048,2] and len(times)==256 and np.all(np.diff(times//60_000_000)==1)
        model.eval();seen=[];hooks=[d.register_forward_pre_hook(lambda m,a:seen.append(a[0])) for d in [model.price_decoder,model.volume_decoder]] if position==0 else []
        with torch.no_grad():out=call(model,batch,False)
        assert all(list(out[k].shape)==[1,64,128] for k in ['mu','logvar','z'])
        assert list(out['price_norm'].shape)==list(out['volume'].shape)==[1,256,2,2048]
        row=dict(batch={k:batch[k] for k in ['price','volume','mask','tick_norm','times']},posterior={k:out[k] for k in ['mu','logvar','z']},price_output={k:out[k] for k in ['price_norm','mid_norm','spread_norm','gap_norm']})
        with torch.no_grad():replay=decode_cached_quantity(model,row)
        torch.testing.assert_close(replay['volume'],out['volume'],rtol=0,atol=0)
        if position==0:
            assert seen[0] is seen[1] is out['z']
            for h in hooks:h.remove()
            fresh,_=load_for_inference(root/'source.pt','cuda:0');fresh.eval()
            def no_encoder(*args):raise AssertionError('Decode used Encoder')
            h=fresh.encoder.register_forward_pre_hook(no_encoder)
            with torch.no_grad():decoded=fresh.decode(out['z'],batch['mask'],batch['tick_norm'],batch['times'])
            h.remove()
            for key in ['volume','price_norm']:torch.testing.assert_close(decoded[key],out[key],rtol=0,atol=0)
            del fresh
            mixed=None
            for temporal,spatial in SWITCHES.values():
                configure_quantity_training(model,temporal=temporal,spatial=spatial)
                with torch.no_grad(),torch.autocast('cuda',dtype=torch.bfloat16):value=decode_cached_quantity(model,row)['volume']
                if mixed is None:mixed=value
                else:torch.testing.assert_close(value,mixed,rtol=0,atol=0)
        configure_quantity_training(model,temporal=False,spatial=False)
        with torch.no_grad(),torch.autocast('cuda',dtype=torch.bfloat16):training=decode_cached_quantity(model,row)
        row['source_training']={k:training[k] for k in ['volume','quantity_logit']}
        cache.append({name:{k:v.detach().cpu() for k,v in values.items()} for name,values in row.items()})
        contracts.append(dict(index=int(index),input=[1,256,2,2048,2],posterior=[1,64,128],output=[1,256,2,2048],consecutive_minutes=True,FP32_cached_Z_price_decode_exact=True))
        atomic_json(root/'cache_progress.json',dict(windows=position+1,total=32))
    atomic_save(cache,root/'train_cache.pt');model.eval();dev=dataset(root,'val');selected=CacheWindows(dev,np.load(root/'val_indices.npy'));result=evaluate(model,norm,selected,len(selected),'cuda:0');require_matching_replay(result,read(root/'source_development.json')['result'])
    for lane in LABELS:atomic_json(root/lane/'step0_development.json',dict(result=result,scope='Common source16GPUreplay; native source weights identical in all four arms'))
    atomic_json(root/'cache_audit.json',dict(passed=True,contracts=contracts,unique_Z=True,fresh_Z_only_decode_exact=True,source_development_replay=True,first_actual_BF16_outputs_equal_all_flags=True,cache_sha256=file_hash(root/'train_cache.pt'),source_sha256=file_hash(root/'source.pt'),optimizer_updates=0))
    atomic_json(root/'cache_status.json',dict(state='complete'));del model,cache;torch.cuda.empty_cache()


def train_fit(model,cache,indices):
    model.eval();tp=fp=fn=0;square=count=0.;windows=[]
    with torch.inference_mode():
        for index,row in zip(indices,cache):
            q=decode_cached_quantity(model,row)['volume'];target=row['batch']['volume'];mask=row['batch']['mask'];a=mask&(target>=100);b=mask&(q>=100)
            t=int((a&b).sum());f=int((~a&b).sum());n=int((a&~b).sum());err=float(((q-target).square()*mask).sum());num=int(mask.sum())
            tp+=t;fp+=f;fn+=n;square+=err;count+=num
            windows.append(dict(index=int(index),tp=t,fp=f,fn=n,recall=t/max(1,t+n),precision=t/max(1,t+f),quantity_rmse=(err/max(1,num))**.5,target_rms=float((target.square()*mask).sum()/max(1,num))**.5))
    return dict(tp=tp,fp=fp,fn=fn,recall=tp/max(1,tp+fn),precision=tp/max(1,tp+fp),quantity_rmse=(square/max(1,count))**.5,windows=windows,scope='Original32trainingwindows; FP32 Q decoding of source Z and predicted geometry. Insampleonly,not independent data.')


def evaluate_checkpoint(root,lane,step,model,norm,cache):
    folder=root/lane;atomic_json(folder/'evaluation_status.json',dict(state='running',step=step,pid=os.getpid()));model.eval()
    atomic_json(folder/f'step{step}_train_fit.json',train_fit(model,cache,np.load(root/'train_indices.npy')))
    dev=dataset(root,'val');selected=CacheWindows(dev,np.load(root/'val_indices.npy'));result=evaluate(model,norm,selected,len(selected),'cuda:0');price_replay(result,read(root/'source_development.json')['result'])
    atomic_json(folder/f'step{step}_development.json',dict(result=result,scope=read(root/'plan.json')['evaluation_scope'],quantity_steps=step))
    write_profiles(folder,step,model,norm,selected,dev);safe_preview(root,lane,step)
    atomic_json(folder/'evaluation_status.json',dict(state='complete',step=step,pid=os.getpid()))


def worker(root,lane,*,objective_factory=None,render_fn=None,checkpoint_auditor=None):
    torch.set_num_threads(4);seed_everything(42);strict_precision();started=time.monotonic();plan=read(root/'plan.json');folder=root/lane;spec=plan['lanes'][lane]
    switches={k:spec[k] for k in ['temporal','spatial']};refresh=render if render_fn is None else render_fn
    atomic_json(folder/'status.json',dict(state='starting',pid=os.getpid()))
    payload=torch.load(root/'source.pt',map_location='cpu',weights_only=False);model,norm=load_for_inference(root/'source.pt','cuda:0');names=configure_quantity_training(model,**switches)
    assert tensor_digest(model)==plan['source_model_sha256'];optimizer=restore_original_optimizer(model,payload['optimizer'],plan['original_parameter_names']);criterion=(head_criterion(plan,read(root/'calibration.json')) if objective_factory is None else objective_factory(root,lane)).cuda();hashes=source_hashes()
    atomic_json(folder/'initial_state_audit.json',dict(passed=True,model_sha256=tensor_digest(model),trainable_names=names,trainable_scalars=sum(p.numel() for p in model.parameters() if p.requires_grad),audit=audit_frozen_state(model,optimizer,payload['model'],payload['optimizer'])))
    if file_hash(root/'train_cache.pt')!=read(root/'cache_audit.json')['cache_sha256']:raise ValueError('Cache changed')
    cached=torch.load(root/'train_cache.pt',map_location='cpu',weights_only=False);cache=[{outer:{k:v.to('cuda:0') for k,v in values.items()} for outer,values in row.items()} for row in cached];del cached
    order=np.load(root/'train_order.npy');indices=np.load(root/'train_indices.npy');active=[p for p in model.parameters() if p.requires_grad]
    constants=[]
    with torch.no_grad():
        for row in cache:
            baseline=dict(**row['posterior'],**row['price_output'],**row['source_training']);constants.append({k:float(v.detach()) for k,v in criterion(baseline,row['batch']).items()})
    def save(step):
        audit=audit_frozen_state(model,optimizer,payload['model'],payload['optimizer']);atomic_json(folder/f'step{step}_frozen_state_audit.json',audit)
        atomic_save(dict(format_version=1,model=model.state_dict(),unified_vae_config=payload['unified_vae_config'],local_hint_config=payload['local_hint_config'],config=payload['config'],
            optimizer=optimizer.state_dict(),source_hashes=hashes,step=step,source_steps=plan['source_steps'],lane=lane,quantity_finetune_config=spec,encoder_updates=0,price_updates=0,
            quantity_decoder_optimizer_updates=step if active else 0,optimizer_calls=step,phase='frozen_price_quantity',training_data=payload['training_data'],
            training_data_scope='Original source body exposures plus separately recorded Q-only exposures. Encoder and P never updated.',quantity_training_data=dict(indices=indices,windows=32,exposures=2*step,epochs_equivalent=2*step/32)),folder/f'step{step}.pt')
        if checkpoint_auditor is not None:checkpoint_auditor(root,lane,step,model,optimizer)
    save(0);atomic_json(folder/'step0_train_fit.json',train_fit(model,cache,indices));configure_quantity_training(model,**switches)
    atomic_json(folder/'status.json',dict(state='running',pid=os.getpid()))
    for step in range(1,plan['steps']+1):
        if time.monotonic()-started>plan['max_seconds']:raise TimeoutError('Declared 3hour Q training ceiling')
        optimizer.zero_grad(set_to_none=True);losses={};positions=[]
        for micro in range(2):
            pos=int(order[((step-1)*2+micro)%len(order)]);positions.append(pos);row=cache[pos]
            if active:
                with torch.autocast('cuda',dtype=torch.bfloat16):out=decode_cached_quantity(model,row)
                values=criterion(out,row['batch']);assert bool(torch.isfinite(values['loss']));(values['loss']/2).backward();values={k:float(v.detach()) for k,v in values.items()}
            else:values=constants[pos]
            for key,value in values.items():losses[key]=losses.get(key,0.)+value/2
        if step in [1,8]:
            gradients=decoder_gradient_norms(model);assert all(math.isfinite(v) for v in gradients.values()) and gradients['frozen']==0.
            assert bool(gradients['temporal']>0)==spec['temporal'] and bool(gradients['spatial']>0)==spec['spatial']
            atomic_json(folder/f'step{step}_gradient_audit.json',dict(passed=True,gradient_norms=gradients,only_declared_Q_modules_have_gradients=True))
        if step==1:
            expected={k:(constants[positions[0]][k]+constants[positions[1]][k])/2 for k in constants[0]}
            for key in expected:
                if not math.isclose(losses[key],expected[key],rel_tol=2e-6,abs_tol=2e-6):raise AssertionError('Initial BF16 loss changed: '+key)
            atomic_json(folder/'step1_data_audit.json',dict(passed=True,indices=indices[positions].tolist(),positions=positions,losses=losses,source_BF16_loss_replay=True))
        grad=float(torch.nn.utils.clip_grad_norm_(active,1.,error_if_nonfinite=True)) if active else 0.;optimizer.step()
        if step==1 or step%8==0:
            atomic_json(folder/'progress.json',dict(step=step,total=plan['steps'],elapsed_seconds=time.monotonic()-started,gradient_norm=grad,indices=indices[positions].tolist(),losses=losses,pid=os.getpid(),optimizer_calls=step,effective_Q_updates=step if active else 0));refresh(root)
        if step in plan['checkpoints']:
            save(step);evaluate_checkpoint(root,lane,step,model,norm,cache);configure_quantity_training(model,**switches)
    assert file_hash(root/'source.pt')==plan['source_sha256'];atomic_json(folder/'status.json',dict(state='complete',pid=os.getpid(),elapsed_seconds=time.monotonic()-started))


def update_common(root):
    plan=read(root/'plan.json')
    for step in plan['checkpoints']:
        paths=[root/lane/f'step{step}_development.json' for lane in LABELS]
        if not (root/f'common{step}_analysis.json').exists() and all(p.exists() for p in paths):
            rows=[dict(lane=lane,step=step,checkpoint=str(root/lane/f'step{step}.pt'),evaluation=str(path),**assess_file(path,root.parent/'reference_evaluation.json')) for lane,path in zip(LABELS,paths)]
            atomic_json(root/f'common{step}_analysis.json',dict(rows=rows,source_price_replay_passed=True,independent_data_read=False));passing=[r for r in rows if r['pass']]
            if passing:atomic_json(root/'eligible_candidate.json',max(passing,key=lambda r:(r['recall100'],-r['price_rmse'])))


def controller(root):
    torch.set_num_threads(4);seed_everything(42);strict_precision();plan=read(root/'plan.json')
    if read(root/'status.json')['state']!='prepared':raise ValueError('Fresh controller only; inspect interrupted state before retry')
    if any(gpu_free().get(g,0)<20000 for g in [2,3,4,5]):raise RuntimeError('Need20GiBfree on each owned GPU for the additional matched cohort')
    atomic_json(root/'status.json',dict(state='cache_preparation',pid=os.getpid()));cache_source(root);children=[];started=time.monotonic();audited=False
    try:
        for gpu,lane in plan['gpu_workers']:
            env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),PYTHONPATH=str(root/'source_snapshot'))
            with (root/'logs'/f'{lane}.log').open('ab',buffering=0) as log:
                child=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.frozen_price_quantity_run',str(root),'--lane',lane],cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            children.append(child)
        atomic_json(root/'status.json',dict(state='running',controller_pid=os.getpid(),pids=[p.pid for p in children]));render(root)
        while any(p.poll() is None for p in children):
            if any(p.poll() not in [None,0] for p in children):raise RuntimeError('Owned Q worker failed; preserve all artifacts for diagnosis')
            if time.monotonic()-started>plan['max_controller_seconds']:raise TimeoutError('Declared controller ceiling')
            if not audited:
                starts={lane:read(root/lane/'step1_data_audit.json') for lane in LABELS}
                if all(starts.values()):
                    first=starts['control']
                    for other in starts.values():
                        assert first['indices']==other['indices']
                        for key in first['losses']:assert math.isclose(first['losses'][key],other['losses'][key],rel_tol=2e-6,abs_tol=2e-6)
                    audited=True;atomic_json(root/'startup_control_audit.json',dict(passed=True,same_source_model_and_Adam=True,same_initial_data_and_loss=True,only_Q_trainability_changes=True))
            update_common(root)
            render(root);time.sleep(10)
        if any(p.returncode for p in children):raise RuntimeError('Owned Q worker failed')
        if not audited:raise RuntimeError('Missing complete four-arm startup controls')
        update_common(root)
        atomic_json(root/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started,goal_automatically_completed=False));render(root)
        record(root.parent,'frozen_price_quantity_complete',root=root.name,steps=plan['steps'])
    finally:
        for child in children:
            if child.poll() is None:os.killpg(child.pid,signal.SIGTERM)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--controller',action='store_true');p.add_argument('--lane',choices=list(LABELS));a=p.parse_args();root=a.root.resolve()
    def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        if a.prepare:prepare(root)
        elif a.lane:worker(root,a.lane)
        elif a.controller:controller(root)
    except BaseException as error:
        if not a.prepare:atomic_json((root/a.lane if a.lane else root)/'status.json',dict(state='failed',error=repr(error),pid=os.getpid()))
        raise
