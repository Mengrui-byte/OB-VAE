"""CPU forensic ablation of a trained regional head; same weights and Z."""
import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import time

import numpy as np
import torch

from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.local_quant_reconstruction import CacheWindows
from train_dual.experiments.long_worker import atomic_json, evaluate
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import freeze_sources, load_for_inference, seed_everything
from train_dual.util.phase_training import tensor_digest


def file_hash(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def input_digest(args, kwargs):
    h = hashlib.sha256()
    for value in [*args, kwargs['times']]:
        value = value.detach().cpu().contiguous()
        h.update(str((tuple(value.shape), value.dtype)).encode())
        h.update(value.numpy().tobytes())
    return h.hexdigest()


class Capture:
    """An evaluation adapter, not an alternative production model."""
    def __init__(self, model, root):
        self.model, self.root, self.cache, self.per_window = model, root, [], []
        self.begin = time.monotonic()

    def eval(self):
        self.model.eval()
        return self

    def train(self):
        self.model.train()
        return self

    def __call__(self, *args, **kwargs):
        assert kwargs['sample'] is False
        seen = []
        hooks = [m.register_forward_pre_hook(lambda m, a: seen.append(a[0]))
                 for m in [self.model.price_decoder, self.model.volume_decoder]]
        try:
            output = self.model(*args, **kwargs)
        finally:
            for hook in hooks:
                hook.remove()
        assert seen[0] is seen[1] is output['z']
        assert output['z'].shape == output['mu'].shape == output['logvar'].shape == (1, 64, 128)
        assert torch.equal(output['z'], output['mu'])
        for key in ['price_norm', 'volume', 'base_volume']:
            assert output[key].shape == (1, 256, 2, 2048)
        record = {k: output[k].clone() for k in ['price_norm', 'volume', 'base_volume']}
        record['input_digest'] = input_digest(args, kwargs)
        self.cache.append(record)
        truth, mask = args[1], args[2]
        positive = mask & (truth >= 100)
        counts = {}
        for key in ['volume', 'base_volume']:
            selected = mask & (output[key] >= 100)
            counts[key] = dict(tp=int((positive & selected).sum()),
                               fp=int((~positive & selected).sum()),
                               fn=int((positive & ~selected).sum()))
        self.per_window.append(counts)
        atomic_json(self.root / 'progress.json', dict(windows=len(self.cache), total=16,
                    elapsed_seconds=time.monotonic() - self.begin, last_window_counts=counts,
                    device='cpu', optimizer_updates=0))
        print(json.dumps(dict(windows=len(self.cache), counts=counts)), flush=True)
        return output


class Replay:
    """Replay captured predictions through the unchanged metric evaluator."""
    def __init__(self, cache, quantity_key):
        self.cache, self.quantity_key, self.cursor = cache, quantity_key, 0

    def eval(self):
        self.cursor = 0
        return self

    def train(self):
        return self

    def __call__(self, *args, **kwargs):
        item = self.cache[self.cursor]
        self.cursor += 1
        assert item['input_digest'] == input_digest(args, kwargs)
        return dict(price_norm=item['price_norm'], volume=item[self.quantity_key])


def prepare(goal):
    parent = goal / 'round_005_regional_phase'
    source = parent / 'shape/step2048.pt'
    root = goal / 'regional_head_fixed_weights_v2'
    root.mkdir()
    (root / 'logs').mkdir()
    atomic_json(root / 'plan.json', dict(
        parent=str(parent.resolve()), checkpoint=str(source.resolve()), checkpoint_sha256=file_hash(source),
        runtime_source=str((parent / 'source_snapshot').resolve()),
        window_indices=np.load(parent / 'val_indices.npy').tolist(), windows=16,
        input_shape=[1, 256, 2, 2048, 2], latent_shape=[1, 64, 128],
        comparison='One captured forward per window: compare returned volume versus base_volume, preserving all weights, sharedZ and predicted price. Cached final stream must exactly replay through original evaluator.',
        split='Reused Q1 development; never independent test', device='cpu',
        optimizer_updates=0, max_seconds=10800,
        interpretation='CPU forensic result is not a GPU candidate score or independent confirmation. Published GPU outputs may differ numerically; report differences explicitly.'))
    freeze_sources(root / 'source_snapshot')
    atomic_json(root / 'status.json', dict(state='prepared'))
    print(root.resolve(), flush=True)


def run(root):
    os.environ['CUDA_VISIBLE_DEVICES'] = ''
    torch.set_num_threads(4)
    seed_everything(42)
    strict_precision()
    plan = json.loads((root / 'plan.json').read_text())
    parent, checkpoint = Path(plan['parent']), Path(plan['checkpoint'])
    assert file_hash(checkpoint) == plan['checkpoint_sha256']
    atomic_json(root / 'status.json', dict(state='running', pid=os.getpid(), device='cpu'))
    model, norm = load_for_inference(checkpoint, 'cpu')
    assert model.use_shape and not model.use_mass
    model.eval().requires_grad_(False)
    before = tensor_digest(model)
    original = dataset(parent, 'val')
    indices = np.load(parent / 'val_indices.npy')
    assert indices.tolist() == plan['window_indices']
    first = original[int(indices[0])]
    assert list(first['data'].shape) == [256, 2, 2048, 2]
    start = int(original.base.starts[int(indices[0])])
    times = original.base.times[start:start+256]
    assert np.all(np.diff(times // 60_000_000) == 1)
    data = CacheWindows(original, indices)
    capture = Capture(model, root)
    active = evaluate(capture, norm, data, 16, 'cpu')
    assert len(capture.cache) == 16
    base = evaluate(Replay(capture.cache, 'base_volume'), norm, data, 16, 'cpu')
    replay = evaluate(Replay(capture.cache, 'volume'), norm, data, 16, 'cpu')
    assert active == replay, 'Captured final predictions did not exactly replay standard metrics'
    assert tensor_digest(model) == before and all(p.grad is None for p in model.parameters())
    assert file_hash(checkpoint) == plan['checkpoint_sha256']
    for key in ['price_usdt', 'temporal_mid_1_minutes_usdt_per_minute']:
        assert active['metrics'][key] == base['metrics'][key]
    gpu = json.loads((parent / 'shape/step2048_development.json').read_text())['result']
    atomic_json(root / 'active_cpu.json', dict(result=active))
    atomic_json(root / 'base_cpu.json', dict(result=base))
    atomic_json(root / 'summary.json', dict(
        active_cpu100=active['thresholds']['100'], base_cpu100=base['thresholds']['100'],
        gpu_published100=gpu['thresholds']['100'],
        active_cpu10=active['thresholds']['10'], base_cpu10=base['thresholds']['10'],
        price_identical_between_variants=True, model_weights_unchanged=True,
        original_checkpoint_unchanged=True, cached_final_metric_replay_exact=True,
        per_window=[dict(actual_index=int(i), **row) for i, row in zip(indices, capture.per_window)],
        neural_forward_calls=16, optimizer_updates=0, independent_data_read=False,
        note='Fixed-weight CPU ablation only. Any promising disabled-head result still requires native GPU replay and frozen-candidate independent confirmation.'))
    atomic_json(root / 'status.json', dict(state='complete', pid=os.getpid(), windows=16,
        optimizer_updates=0, goal_achieved=False))
    print(json.dumps(json.loads((root / 'summary.json').read_text()), ensure_ascii=False), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    parser.add_argument('--prepare', action='store_true')
    args = parser.parse_args()
    if args.prepare:
        prepare(args.root.resolve())
    else:
        try:
            run(args.root.resolve())
        except BaseException as error:
            atomic_json(args.root / 'status.json', dict(state='failed', pid=os.getpid(), error=repr(error)))
            raise
