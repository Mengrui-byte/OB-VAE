"""Read-only decomposition of saved price predictions; no model forwards."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

LANES=['control','no_aug','strata','no_aug_strata']

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def quant(v):return dict(zip(['p10','median','p90'],map(float,np.quantile(v,[.1,.5,.9]))))

def analyze(path):
    with np.load(path,allow_pickle=False) as z:
        truth=z['truth'][...,0].astype(np.float64);pred=z['prediction'][...,0].astype(np.float64)
        mask=z['mask'];indices=z['indices'];times=z['time']
    assert truth.shape==pred.shape==mask.shape and truth.shape[1:]==(256,2,2048)
    assert mask.dtype==np.bool_ and mask.all()
    e=pred-truth;mid=truth[...,0].mean(-1);midh=pred[...,0].mean(-1);me=midh-mid
    mse=float(np.square(e).mean());offset=e.mean(axis=(-2,-1),keepdims=True)
    offset_mse=float(np.square(offset).mean());residual_mse=float(np.square(e-offset).mean())
    assert np.isclose(mse,offset_mse+residual_mse,rtol=1e-12,atol=1e-9)
    centered=e-me[...,None,None]
    # Per-side cumulative gap error is zero at best level; fit a linear depth drift.
    sign=np.array([-1.,1.])[None,None,:,None]
    dist=sign*centered;spread_err=dist[...,0];cum=dist-dist[...,:1]
    ranks=np.arange(2048,dtype=np.float64);slope=(cum*ranks).sum(-1)/np.square(ranks).sum()
    linear=sign*slope[...,None]*ranks
    without_drift=e-linear
    identity=hashlib.sha256()
    for a in [truth,mask,indices,times]:identity.update(np.ascontiguousarray(a).tobytes())
    return dict(indices=indices.tolist(),target_identity=identity.hexdigest(),shape=list(truth.shape),
        file_sha256=sha(path),price_RMSE_USDT=float(np.sqrt(mse)),
        BBO_mid_RMSE_USDT=float(np.sqrt(np.square(me).mean())),
        BBO_mid_bias_USDT=float(me.mean()),BBO_mid_error_quantiles_USDT=quant(me),
        per_window_mid_bias_USDT=me.mean(1).tolist(),
        per_window_mid_bias_MSE_fraction=float(np.square(me.mean(1)).mean()/np.square(me).mean()),
        lowpass_mid_error_MSE_fraction={str(k):float(np.square(me.reshape(me.shape[0],256//k,k).mean(-1)).mean()/np.square(me).mean()) for k in [16,64,256]},
        per_frame_global_offset_RMSE_USDT=float(np.sqrt(offset_mse)),
        within_frame_shape_RMSE_USDT=float(np.sqrt(residual_mse)),
        orthogonal_global_offset_MSE_fraction=offset_mse/mse,
        orthogonal_within_frame_shape_MSE_fraction=residual_mse/mse,
        prefix_price_RMSE_USDT={str(n):float(np.sqrt(np.square(e[...,:n]).mean())) for n in [1,10,100,500,1000,2048]},
        oracle_true_mid_only_RMSE_USDT=float(np.sqrt(np.square(centered).mean())),
        per_side_linear_cumulative_gap_drift_USDT_per_level=quant(slope),
        linear_cumulative_gap_drift_RMS_USDT_per_level=float(np.sqrt(np.square(slope).mean())),
        oracle_linear_gap_drift_removed_RMSE_USDT=float(np.sqrt(np.square(without_drift).mean())),
        oracle_scope='Both oracle corrections use true prices and are diagnostics only; not deployable predictions, candidate quality or confirmation.')

def run(root):
    destination=root/'price_error_diagnosis';destination.mkdir(exist_ok=True)
    checkpoints=sorted(set.intersection(*[{int(p.name.split('_')[0][4:]) for p in (root/lane).glob('step*_profiles.npz')} for lane in LANES]))
    rows={};identity=None
    for step in checkpoints:
        rows[str(step)]={}
        for lane in LANES:
            result=analyze(root/lane/f'step{step}_profiles.npz')
            if identity is None:identity=result['target_identity']
            assert result['target_identity']==identity
            rows[str(step)][lane]=result
    output=dict(state='complete_read_only',scope='Same fixed3development preview windows, all256frames,2sides,2048levels. These are not full16window headline metrics.',
                metric_units='USDT; e=predicted_price-true_price; per-frame global mean error and centered residual give an exact orthogonal MSE decomposition.',
                target_identity=identity,model_forward_calls=0,optimizer_updates=0,checkpoints=rows,observer_sha256=sha(Path(__file__)))
    path=destination/'decomposition_v2.json';path.write_text(json.dumps(output,indent=2))
    source=destination/('observer_'+sha(Path(__file__))+'.py')
    if not source.exists():source.write_bytes(Path(__file__).read_bytes())
    print(json.dumps(output))

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);args=p.parse_args();run(args.root.resolve())
