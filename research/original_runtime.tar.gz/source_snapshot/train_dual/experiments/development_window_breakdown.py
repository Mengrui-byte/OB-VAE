"""Read-only per-window native inference, checked against published aggregates."""
import argparse
import math
import os
from pathlib import Path

import numpy as np
import torch
from torch.nn import functional as F

from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.local_quant_reconstruction import CacheWindows
from train_dual.experiments.long_worker import atomic_json,evaluate
from train_dual.experiments.phase_detail_report import read
from train_dual.experiments.price_safe_readout import file_hash
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import freeze_sources,load_for_inference
from train_dual.util.phase_training import tensor_digest


def prepare(goal):
    parent=goal/'frozen_price_quantity';root=goal/'development_window_breakdown';root.mkdir();(root/'logs').mkdir()
    cases={}
    for name,lane,step in [('source','control',0),('temporal1024','temporal',1024),('spatial1024','spatial',1024),('both1024','both',1024)]:
        checkpoint=parent/lane/f'step{step}.pt';published=parent/lane/f'step{step}_development.json'
        if not checkpoint.exists() or not published.exists():raise ValueError('Need all fullnative checkpoints and evaluations first')
        cases[name]=dict(lane=lane,step=step,checkpoint=str(checkpoint.relative_to(goal)),evaluation=str(published.relative_to(goal)),sha256=file_hash(checkpoint))
    atomic_json(root/'plan.json',dict(cases=cases,parent=parent.name,scope='Same16reusedQ1developmentwindows,read-onlyfullnativeinference;noindependentdataoroptimization',input=[1,256,2,2048,2]))
    atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot')
    project=Path(__file__).resolve().parents[2];remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project);original_snapshot=remote.parent/parent.name/'source_snapshot'
    # The external new driver uses the checkpoint's exact ORIGINAL inference code.
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export CUDA_VISIBLE_DEVICES=2 CUDA_DEVICE_ORDER=PCI_BUS_ID PYTHONPATH="{original_snapshot}" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\ncd "{original_snapshot}"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u "{remote}/source_snapshot/train_dual/experiments/development_window_breakdown.py" "{remote}" --worker >> "{remote}/logs/run.log" 2>&1\n')
    print(root,flush=True)


def check_aggregate(rows,published):
    for key in ['tp','fp','fn']:
        if sum(row['thresholds']['100'][key] for row in rows)!=published['thresholds']['100'][key]:raise AssertionError('Per-window event counts fail published replay: '+key)
    for key in ['price_usdt','quantity_btc','temporal_mid_1_minutes_usdt_per_minute']:
        counts=[row['metrics'][key]['count'] for row in rows];rmse=math.sqrt(sum(n*row['metrics'][key]['rmse']**2 for n,row in zip(counts,rows))/sum(counts))
        if sum(counts)!=published['metrics'][key]['count'] or not math.isclose(rmse,published['metrics'][key]['rmse'],rel_tol=1e-7,abs_tol=1e-8):raise AssertionError('Per-window RMSE fails published replay: '+key)


def worker(root):
    torch.set_num_threads(4);strict_precision();plan=read(root/'plan.json');goal=root.parent;parent=goal/plan['parent'];original=dataset(parent,'val');indices=np.load(parent/'val_indices.npy');results={}
    atomic_json(root/'status.json',dict(state='running',pid=os.getpid()))
    for name,spec in plan['cases'].items():
        path=goal/spec['checkpoint'];assert file_hash(path)==spec['sha256'];payload=torch.load(path,map_location='cpu',weights_only=False)
        for relative,digest in payload['source_hashes'].items():assert file_hash(parent/'source_snapshot'/relative)==digest
        del payload;model,norm=load_for_inference(path,'cuda:0');before=tensor_digest(model);rows=[]
        for position,index in enumerate(indices):
            captured=[];hook=model.register_forward_hook(lambda m,a,o:captured.append(o['volume'][0].detach().cpu()))
            result=evaluate(model,norm,CacheWindows(original,np.array([index])),1,'cuda:0');hook.remove();raw=original[int(index)]
            assert list(raw['data'].shape)==[256,2,2048,2] and len(captured)==1
            mask=torch.arange(2048)<raw['level_counts'][...,None];target=raw['data'][...,1];pred=captured[0];large=mask&(target>=100);fp=mask&(target<100)&(pred>=100)
            nearest={}
            for radius in [2,8]:
                near=F.max_pool1d(large.reshape(-1,1,2048).float(),2*radius+1,stride=1,padding=radius).reshape_as(mask).bool()
                nearest[str(radius)]=dict(near_fp=int((fp&near).sum()),fp=int(fp.sum()),fraction=float((fp&near).sum()/fp.sum()) if bool(fp.any()) else None)
            start=int(original.base.starts[int(index)]);times=original.base.times[start:start+256];assert (np.diff(times//60_000_000)==1).all()
            rows.append(dict(position=position,index=int(index),start_utc=str(np.datetime64(int(times[0]),'us')),thresholds=result['thresholds'],metrics=result['metrics'],nearby_false_positives=nearest))
            atomic_json(root/'progress.json',dict(case=name,windows=position+1,total=16,pid=os.getpid()))
        check_aggregate(rows,read(goal/spec['evaluation'])['result']);assert tensor_digest(model)==before;results[name]=rows
        atomic_json(root/f'{name}.json',dict(rows=rows,published_aggregate_replayed=True,model_unchanged=True,optimizer_updates=0));del model;torch.cuda.empty_cache()
    baseline=results['source'];comparisons={}
    for name,rows in results.items():
        if name=='source':continue
        count=dict(recall_better=0,recall_worse=0,recall_same=0,precision_better=0,precision_worse=0,quantity_rmse_better=0,quantity_rmse_worse=0)
        for a,b in zip(baseline,rows):
            assert a['index']==b['index'];x,y=a['thresholds']['100'],b['thresholds']['100']
            if x['recall'] is not None:
                key='recall_better' if y['recall']>x['recall'] else 'recall_worse' if y['recall']<x['recall'] else 'recall_same';count[key]+=1
            if x['precision'] is not None and y['precision'] is not None:
                if y['precision']!=x['precision']:count['precision_better' if y['precision']>x['precision'] else 'precision_worse']+=1
            if b['metrics']['quantity_btc']['rmse']!=a['metrics']['quantity_btc']['rmse']:count['quantity_rmse_better' if b['metrics']['quantity_btc']['rmse']<a['metrics']['quantity_btc']['rmse'] else 'quantity_rmse_worse']+=1
        comparisons[name]=count
    atomic_json(root/'summary.json',dict(comparisons=comparisons,scope=plan['scope'],all_published_aggregates_replayed=True,optimizer_updates=0,independent_data_read=False))
    text='<h1>16个开发窗口：完整原生推理分解</h1><p>仅重放已有Q1开发窗口，无优化器更新、无新独立数据。每个方案逐窗结果的计数和RMSE均重放已发布的总体成绩。邻档误报比例仅作描述，严格同档位召回没有放宽。</p><table><tr><th>日期/索引</th><th>真实大单数</th><th>来源召回</th><th>时间组1024</th><th>空间组1024</th><th>组合组1024</th></tr>'
    for i,row in enumerate(baseline):
        values=[row['start_utc']+'/'+str(row['index']),row['thresholds']['100']['tp']+row['thresholds']['100']['fn']]
        values.extend('—' if results[name][i]['thresholds']['100']['recall'] is None else f"{results[name][i]['thresholds']['100']['recall']*100:.2f}%" for name in plan['cases'])
        text+='<tr>'+''.join('<td>'+str(v)+'</td>' for v in values)+'</tr>'
    text+='</table><p><a href="summary.json">每窗增减统计</a> · <a href="../frozen_price_quantity/">总体指标与训练</a></p>'
    (root/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>开发窗口分解</title><style>body{max-width:1300px;margin:40px auto;font:16px/1.7 system-ui}table{border-collapse:collapse;width:100%}td,th{padding:9px;border-bottom:1px solid #ddd}</style>'+text)
    atomic_json(root/'status.json',dict(state='complete',pid=os.getpid(),all_aggregates_replayed=True,optimizer_updates=0));print('Per-window breakdown complete; original16windowaggregatesreplayed',flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--worker',action='store_true');args=p.parse_args();root=args.root.resolve()
    try:
        if args.prepare:prepare(root)
        elif args.worker:worker(root)
    except BaseException as error:
        if not args.prepare:atomic_json(root/'status.json',dict(state='failed',pid=os.getpid(),error=repr(error)))
        raise
