"""Use released fast-arm GPUs for a matched, short count-reduction pilot."""
import argparse
from copy import deepcopy
import html
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import numpy as np
import torch

from train_dual.experiments import local_hint_run as shared
from train_dual.experiments.branch_precision_run import optimizer_factory
from train_dual.experiments.confirm_recall_goal import require_matching_replay
from train_dual.experiments.goal_evaluate import assess_file
from train_dual.experiments.log_relative_detail_run import run_cohort
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read,STYLE
from train_dual.experiments.price_safe_readout import file_hash
from train_dual.experiments.recall_goal_run import candidates,record
from train_dual.experiments.region_task_run import gpu_free
from train_dual.experiments.relative_aggregation_run import calibrate,criterion,prepare_actual
from train_dual.util.checkpoint import freeze_sources
from train_dual.util.quantity_strata import evaluate_with_quantity_strata

MODULE='train_dual.experiments.idle_aggregation_pilot'
LABELS=dict(control='冻结价格原目标',per_position='冻结价格＋位置相对项')
POLICY=dict(encoder_fp32=True,decoders_fp32=True)


def worker_live(parent,pid,lane,proc=Path('/proc')):
    try:args=(proc/str(pid)/'cmdline').read_bytes().split(b'\0')
    except FileNotFoundError:return False
    return b'train_dual.experiments.branch_precision_run' in args and str(parent).encode() in args and b'--lane' in args and lane.encode() in args


def readiness(goal,plan,proc=Path('/proc')):
    parent=goal/plan['parent'];state=read(parent/'status.json',{}).get('state')
    if state=='failed':raise RuntimeError('Parent precision experiment failed')
    if state=='complete':return 'skip_parent_finished_main_queue_priority'
    for lane,pid in plan['fast_workers'].items():
        s=read(parent/lane/'status.json',{})
        if s.get('state')=='failed':raise RuntimeError('Owned fast parent failed')
        if worker_live(parent,pid,lane,proc):return 'wait_fast_workers'
        if s.get('state')!='complete' or s.get('step')!=2048:raise RuntimeError('Fast parent missing without complete2048')
    if state!='running':raise RuntimeError('Parent is not actively running')
    for lane,pid in plan['slow_workers'].items():
        if not worker_live(parent,pid,lane,proc):raise RuntimeError('Exact slow parent missing')
        progress=read(parent/lane/'progress.json',{})
        if progress.get('total',2048)-progress.get('step',0)<plan['minimum_slow_remaining_steps']:
            return 'skip_insufficient_parent_overlap_main_queue_priority'
    if not (parent/'both_fp32/step0_development.json').exists():return 'wait_reference_checkpoints'
    return 'ready'


def prepare(goal,fast_control,fast_encoder):
    parent=goal/'round_010_branch_precision';old=read(parent/'plan.json');assert read(parent/'startup_control_audit.json')['passed']
    assert old['source_checkpoint_relative']=='round_008_auxiliary/control/step512.pt' and old['source_steps']==25088
    root=goal/'idle_aggregation_pilot_after_fast_20261028';root.mkdir();(root/'logs').mkdir()
    p=dict(queue_only=True,parent=parent.name,fast_workers=dict(control=fast_control,encoder_fp32=fast_encoder),slow_workers=dict(decoders_fp32=41251,both_fp32=41252),
        minimum_slow_remaining_steps=768,wait_seconds=36000,steps=512,checkpoints=[256,512],max_seconds=7200,gradient_norm_fraction=.25,
        controls='Same original strong source parameters/all3Adam/RNG/data/order/noaugmentation/teacher/oldobjective/LR/clip/accumulation4/seed42/512updates. Both pilot arms use fullEncoder+postZ FP32 with Encoder and priceDecoder frozen. Only one per-position physical-log relative term is off/on; one training-only volumeDecoder-gradient calibration coefficient.',
        reference_policy='Own frozen-Encoder/price no-relative control is the matched baseline. Parent both_fp32 step0 only binds original initialization/native price; fully-trainable parent later checkpoints are not a matched frozen-model control.',
        resource_policy='Only GPU2/3 after exact fast workers completed2048 and exited, with>=47000MiB free. Never displace parents or GPU0/1. Skip if full parent finished or either slow parent has<768updates remaining; formal4arm aggregation retains priority.',
        source_sha256=old['source_sha256'],source_policy='Fixed same original source as parent precision cohort; not the fast arms final models.',
        inference_policy='NativeFP32 allcases. Actual256frames/2048levels/single8192Z, source replay/all3Adam/firstbatch/dtype audits precede interpretation.',
        candidate_policy='Original gates plus whole-book review; no automatic Q2 or goal completion. This is a512update pilot, not the predeclared2048 fourarm result.',
        shape_contract=dict(input=[1,256,2,2048,2],latent=[1,64,128],output=[1,256,2,2048]),original_goal_contract_unchanged=True)
    atomic_json(root/'plan.json',p);atomic_json(root/'status.json',dict(state='prepared_not_started'));freeze_sources(root/'source_snapshot')
    project=Path(__file__).resolve().parents[2];remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 CUDA_DEVICE_ORDER=PCI_BUS_ID OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m {MODULE} "{remote}" --controller >> "{remote}/logs/controller.log" 2>&1\n')
    render(root);return root


def bind_reference(queue):
    goal=queue.parent;p=read(queue/'plan.json');parent=goal/p['parent'];bindings={}
    assert read(parent/'plan.json')['source_sha256']==p['source_sha256']
    cp=parent/'source.pt';ev=parent/'both_fp32/step0_development.json'
    assert file_hash(cp)==p['source_sha256']
    bindings['source']=dict(checkpoint_relative=str(cp.relative_to(goal)),checkpoint_sha256=file_hash(cp),evaluation_relative=str(ev.relative_to(goal)),evaluation_sha256=file_hash(ev))
    atomic_json(queue/'reference_bindings.json',bindings);return bindings


def setup(queue,bindings):
    goal=queue.parent;p=read(queue/'plan.json');parent=goal/p['parent'];selected=dict(lane='control',step=0,source_origin=parent.name,**assess_file(parent/'control/step0_development.json',goal/'reference_evaluation.json'))
    root=prepare_actual(queue,selected,0,root_name='relative_aggregation_early_pilot_20261028',labels=LABELS,
        gpu_workers=[[2,'control'],[3,'per_position']],force_precision=POLICY)
    spec=read(root/'plan.json');spec.update(experiment='空闲双卡：固定Encoder和价格，只训练挂量Decoder的相对项对照',relative_aggregation_pilot=True,
        worker_module=MODULE,reference_parent=parent.name,reference_bindings=bindings,source_precision_for_both_pilot_arms=POLICY,
        reference_control_policy=p['reference_policy'],pilot_only=True,frozen_modules=['encoder','price_decoder'],calibration_gradient_module='volume_decoder',calibration_relative_arm='per_position')
    atomic_json(root/'plan.json',spec);render(root);return root


def startup_relation(rows,coefficient):
    a=rows['control'];b=rows['per_position']
    assert a['training_indices']==b['training_indices'] and a['edits']==b['edits']
    for row in rows.values():
        v=row['losses'];assert v['pre_relative_detail_loss']==a['losses']['loss']
    assert math.isclose(b['losses']['loss'],a['losses']['loss']+coefficient*b['losses']['relative_quantity_log'],rel_tol=5e-6,abs_tol=5e-6)
    for i in range(6):
        for key in [f'relative_log_bin{i}',f'relative_log_bin{i}_count']:assert a['losses'][key]==b['losses'][key]


def audit_startup(root):
    p=read(root/'plan.json');rows={lane:read(root/lane/'step1_data_audit.json',{}) for lane in LABELS}
    if not all(rows.values()) or not all((root/lane/'step8_gradient_audit.json').exists() for lane in LABELS):return False
    parent=root.parent/p['reference_parent'];reference=read(parent/'both_fp32/step1_data_audit.json');c=read(root/'aggregation_calibration.json')
    startup_relation(rows,c['shared_relative_weight'])
    assert all(row['training_indices']==reference['training_indices'] and row['edits']==reference['edits'] for row in rows.values())
    source=torch.load(root/'source.pt',map_location='cpu',weights_only=False,mmap=True);native=read(parent/'both_fp32/step0_development.json')['result']
    for lane in LABELS:
        assert read(root/lane/'actual_shape_contract.json')['passed'] and read(root/lane/'actual_branch_precision_audit.json')['passed']
        require_matching_replay(read(root/lane/'step0_development.json')['result'],native)
        new=torch.load(root/lane/'step0.pt',map_location='cpu',weights_only=False,mmap=True)
        assert new['model'].keys()==source['model'].keys() and new['branch_precision_config']==POLICY
        for key,value in source['model'].items():torch.testing.assert_close(value,new['model'][key],rtol=0,atol=0)
        assert new['optimizer']['param_groups']==source['optimizer']['param_groups'] and new['optimizer']['state'].keys()==source['optimizer']['state'].keys()
        for index,state in source['optimizer']['state'].items():
            for key,value in state.items():
                if torch.is_tensor(value):torch.testing.assert_close(value,new['optimizer']['state'][index][key],rtol=0,atol=0)
                else:assert value==new['optimizer']['state'][index][key]
    atomic_json(root/'startup_control_audit.json',dict(passed=True,same_source_all3Adam=True,same_raw_firstbatch_as_parent_full_precision_control=True,
        native_source_replay_exact=True,both_pilot_arms_full_precision=True,both_Encoder_and_price_frozen=True,only_global_relative_term_changes=True,full256_unique8192_singleZ=True));return True


def checkpoint_analysis(root,step):
    out=root/f'common{step}_analysis.json'
    if out.exists() or not all((root/lane/f'step{step}_development.json').exists() for lane in LABELS):return
    p=read(root/'plan.json');binding=p['reference_bindings']['source'];goal=root.parent;cp=goal/binding['checkpoint_relative'];ev=goal/binding['evaluation_relative']
    assert file_hash(cp)==binding['checkpoint_sha256'] and file_hash(ev)==binding['evaluation_sha256']
    control=torch.load(cp,map_location='cpu',weights_only=False,mmap=True)
    baseline=torch.load(root/'control'/f'step{step}.pt',map_location='cpu',weights_only=False,mmap=True)
    original_metrics=read(ev)['result']['metrics']
    for lane in LABELS:
        current=torch.load(root/lane/f'step{step}.pt',map_location='cpu',weights_only=False,mmap=True)
        assert current['step']==baseline['step']==step and current['source_steps']==baseline['source_steps']==25088
        torch.testing.assert_close(current['sampler_generator_state'],baseline['sampler_generator_state'],rtol=0,atol=0)
        torch.testing.assert_close(current['augmentation_generator_state'],baseline['augmentation_generator_state'],rtol=0,atol=0)
        np.testing.assert_array_equal(current['training_data']['exposure_counts'],baseline['training_data']['exposure_counts'])
        for name,value in control['model'].items():
            if name.startswith(('encoder.','price_decoder.')):torch.testing.assert_close(current['model'][name],value,rtol=0,atol=0)
        metrics=read(root/lane/f'step{step}_development.json')['result']['metrics']
        for name in ['price_usdt','temporal_mid_1_minutes_usdt_per_minute']:assert metrics[name]==original_metrics[name]
    rows=[row for row in candidates(root,goal/'reference_evaluation.json') if row['step']==step]
    atomic_json(out,dict(step=step,rows=rows,reference_hashes_verified=True,sampler_and_exposures_exact=True,Encoder_price_tensors_and_native_price_metrics_unchanged=True,
        scope='Own frozen-Encoder/price control versus global relative term; same source/precision/Adam/data/budget. Not new seeds or a2048update conclusion.'))
    record(goal,'idle_relative_aggregation_pilot_common_checkpoint',wave=root.name,step=step,rows=rows,Encoder_and_price_unchanged=True)


def render(root):
    p=read(root/'plan.json');s=read(root/'status.json',{});body='<h1>释放卡上的短聚合对照</h1>'
    if p.get('queue_only'):body+='<p>仅在精度快组完成2048并释放GPU2/3后运行；慢组仍须有至少768步余量。父实验结束则让正式聚合优先。当前未启动短实验。</p>'
    else:
        body+='<p>固定原强参考来源、同一初始化/三组Adam/RNG/数据/原目标。两组都完整FP32并冻结Encoder与价格Decoder，各512更新，只比较原目标与增加按位置平均的物理log相对项。系数仅在8训练窗按挂量Decoder梯度校准一次。已有完整精度实验仅提供源初始化，不当作冻结训练的匹配控制。</p><table><tr><th>组</th><th>训练步</th><th>评估步</th><th>召回</th><th>精确率</th><th>价格RMSE USDT</th></tr>'
        for lane,label in LABELS.items():
            files=sorted((root/lane).glob('step*_development.json'),key=lambda f:int(f.name.split('_')[0][4:]));latest=files[-1] if files else None
            cells=[label,read(root/lane/'progress.json',{}).get('step',0)]
            if latest:
                a=assess_file(latest,root.parent/'reference_evaluation.json');cells += [int(latest.name.split('_')[0][4:]),f"{a['recall100']:.2%}",f"{a['precision100']:.2%}" if a['precision100'] is not None else '—',f"{a['price_rmse']:.4f}"]
            else:cells+=['待评估']*4
            body+='<tr>'+''.join('<td>'+html.escape(str(x))+'</td>' for x in cells)+'</tr>'
        body+='</table><p>短实验不替代正式2048更新四组；大小单和价格共同验收，不把单项召回过线当完成。</p>'
    body+='<p>状态：'+html.escape(str(s))+'</p><p>完整256分钟、双侧2048档、唯一8192Gaussian。只用释放后的GPU2/3，0/1及慢组4/5不动。Q1反复用于开发；不自动读取Q2。</p><p><a href="plan.json">协议</a> · <a href="status.json">状态</a></p>'
    (root/'index.html').write_text('<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="30"><style>'+STYLE+'</style>'+body)


def controller(queue):
    p=read(queue/'plan.json');goal=queue.parent;start=time.monotonic()
    while True:
        state=readiness(goal,p)
        if state.startswith('skip_'):atomic_json(queue/'status.json',dict(state='not_run_'+state,pid=os.getpid()));render(queue);return
        if state=='ready' and all(gpu_free().get(g,0)>=47000 for g in [2,3]):break
        if time.monotonic()-start>p['wait_seconds']:raise TimeoutError('Tenhour idle-card wait ceiling')
        atomic_json(queue/'status.json',dict(state='verified_'+state,pid=os.getpid(),fast_workers=p['fast_workers']));render(queue);time.sleep(20)
    bindings=bind_reference(queue);root=setup(queue,bindings);atomic_json(queue/'status.json',dict(state='calibrating',pid=os.getpid(),wave=root.name));render(queue)
    env=dict(os.environ,CUDA_VISIBLE_DEVICES='2',PYTHONPATH=str(root/'source_snapshot'))
    with (root/'logs/calibration.log').open('ab',buffering=0) as log:
        child=subprocess.Popen([sys.executable,'-u','-m',MODULE,str(root),'--calibrate'],cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    begin=time.monotonic()
    try:
        while child.poll() is None:
            if time.monotonic()-begin>3600:raise TimeoutError('Onehour calibration ceiling')
            atomic_json(root/'status.json',dict(state='calibrating',controller_pid=os.getpid(),pid=child.pid));render(root);time.sleep(10)
        if child.returncode:raise RuntimeError('Pilot calibration failed')
    finally:
        if child.poll() is None:os.killpg(child.pid,signal.SIGTERM)
    atomic_json(queue/'status.json',dict(state='running',pid=os.getpid(),wave=root.name));render(queue)
    run_cohort(root,worker_module=MODULE,startup_auditor=audit_startup,renderer=render,analyzer=checkpoint_analysis)
    rows=candidates(root,goal/'reference_evaluation.json');old=read(goal/'candidates.json',{}).get('rows',[])
    atomic_json(goal/'candidates.json',dict(rows=[x for x in old if x.get('experiment')!=root.name]+[dict(x,experiment=root.name) for x in rows]))
    atomic_json(queue/'status.json',dict(state='complete',wave=root.name,goal_automatically_completed=False));render(queue)
    record(goal,'idle_relative_aggregation_pilot_complete',wave=root.name,next='Joint whole-book review with own frozen-price no-relative control. Formal fourarm aggregation protocol remains unchanged; no automatic Q2.')


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('root',type=Path);parser.add_argument('--prepare',action='store_true');parser.add_argument('--fast-control',type=int);parser.add_argument('--fast-encoder',type=int);parser.add_argument('--controller',action='store_true');parser.add_argument('--calibrate',action='store_true');parser.add_argument('--lane',choices=list(LABELS));a=parser.parse_args();root=a.root.resolve()
    def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        if a.prepare:
            if not a.fast_control or not a.fast_encoder:parser.error('Both exact fast-worker PIDs required')
            print(prepare(root,a.fast_control,a.fast_encoder),flush=True)
        elif a.controller:controller(root)
        elif a.calibrate:calibrate(root)
        elif a.lane:
            shared.evaluate=evaluate_with_quantity_strata
            shared.worker(root,a.lane,objective_factory=criterion,optimizer_factory=lambda model,state,names:optimizer_factory(root,a.lane,model,state,names))
        else:parser.error('Specify a mode')
    except BaseException as error:
        if not a.prepare:atomic_json((root/a.lane if a.lane else root)/'status.json',dict(state='failed',pid=os.getpid(),error=repr(error)))
        raise


if __name__=='__main__':main()
