"""Bounded identity/gradient and read-only peak injection diagnostics."""
import argparse
from contextlib import nullcontext
import json
from pathlib import Path

import numpy as np
import torch

from model.losses.probability_book import ProbabilityBookLoss
from model.losses.unified_book import UnifiedBookLoss
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import load_for_inference, seed_everything
from train_dual.util.data import DualNormalizer


def alignment(root):
    plan=json.loads((root/'plan.json').read_text());parent=root.parents[1]/'recons'/Path(plan['parent']).name
    config=json.loads((parent/'plan.json').read_text())
    ds=dataset(parent,'train')
    raw={k:v.unsqueeze(0) for k,v in ds[plan['training_index']].items()}
    norm=DualNormalizer(tick_size=config['normalization']['tick_size'],price_scale=config['normalization']['price_scale'])
    b=norm.prepare(raw,'cpu')
    checkpoint=torch.load(root/'checkpoint.pt',map_location='cpu',weights_only=False)
    scales={key:float(checkpoint['model'][key]) for key in ['encoder.features.q0','volume_decoder.q0']}
    scale=config['normalization']['quantity_scale']
    assert all(np.isclose(v,scale,rtol=1e-6) for v in scales.values())
    assert torch.equal(b['volume'][b['mask']],raw['data'][...,1][b['mask']])
    out=dict(price_norm=b['price'].clone(),volume=b['volume'].clone(),mu=torch.zeros(1,64,128),logvar=torch.zeros(1,64,128))
    values=UnifiedBookLoss(scale)(out,b)
    assert values['loss'].item()==0.
    atomic_json(root/'alignment.json',dict(passed=True,raw_shape=list(raw['data'].shape),
        target_equals_raw_btc_at_all_valid_locations=True,q0_buffers=scales,criterion_q0=scale,
        original_oracle_losses={k:float(v) for k,v in values.items()},
        scope='One fixed realtrainingwindow; establishes the audited normalization/loss coordinate contract, not all possible data integrity.'))
    qh=b['volume'].clone().requires_grad_()
    target=dict(b,volume=b['volume'].clone())
    coordinate=(0,plan['frame'],plan['side'],511)
    target['volume'][coordinate]+=1000
    out=dict(out,volume=qh)
    criterion=ProbabilityBookLoss(scale,mode='shape_mass',add_wasserstein=True,add_multiscale=True,**config['objective'])
    values=criterion(out,target)
    gradient=torch.autograd.grad(values['loss'],qh)[0]
    assert torch.isfinite(gradient).all() and gradient[coordinate]<0
    minimum=np.unravel_index(int(gradient.argmin()),gradient.shape)
    atomic_json(root/'peak_loss_gradient.json',dict(passed=True,coordinate=list(coordinate),
        target_btc=float(target['volume'][coordinate]),prediction_btc=float(qh[coordinate].detach()),
        derivative_at_missed_peak=float(gradient[coordinate]),minimum_gradient_coordinate=list(map(int,minimum)),
        all_finite=True,negative_derivative_means_gradient_descent_increases_this_quantity=True,
        scope='Output-space gradient of actual currentloss; not a proof that parameter updates preserve the peak.'))


def probe(root):
    plan=json.loads((root/'plan.json').read_text());parent=root.parents[1]/'recons'/Path(plan['parent']).name
    ds=dataset(parent,'train')
    raw={k:v.unsqueeze(0) for k,v in ds[plan['training_index']].items()}
    model,norm=load_for_inference(root/'checkpoint.pt','cuda:0');model.eval()
    base=norm.prepare(raw,'cuda:0')
    t,s=plan['frame'],plan['side']
    captured={};hooks=[]
    def save(name,kind):
        def hook(module,args,out):
            if kind=='row':x=out[t*2+s]
            elif kind=='region':x=out[t,s]
            elif kind=='frame':x=out[0,t]
            elif kind=='patch':x=out[0,t//4]
            else:x=out[0]
            captured[name]=x.detach().float().cpu()
        return hook
    modules=[('features',model.encoder.features,'row')]
    modules += [(f'encoder_spatial{i}',m,'row') for i,m in enumerate(model.encoder.spatial)]
    modules += [('region',model.encoder.region,'region'),('frame',model.encoder.frame,'frame'),
                ('patch',model.encoder.patch,'patch'),('mu',model.encoder.mu,'all'),
                ('decoder_temporal',model.volume_decoder.temporal,'frame'),
                ('decoder_spatial',model.volume_decoder.spatial,'row')]
    for name,module,kind in modules:hooks.append(module.register_forward_hook(save(name,kind)))
    result={}
    try:
        with torch.inference_mode():
            for precision in ['fp32','bf16']:
                reference=None;rows=[];deltas=[]
                for amount,rank in [[0.,511],*plan['probes']]:
                    assert base['mask'][0,t,s,rank]
                    b=dict(base,volume=base['volume'].clone())
                    b['volume'][0,t,s,rank]+=amount
                    captured.clear()
                    ctx=torch.autocast('cuda',dtype=torch.bfloat16) if precision=='bf16' else nullcontext()
                    with ctx:out=call(model,b,False)
                    q=out['volume'][0].float().cpu()
                    stages=dict(captured)
                    if reference is None:
                        reference=dict(q=q,stages=stages)
                        continue
                    stage_changes={}
                    for key,value in stages.items():
                        diff=value-reference['stages'][key]
                        stage_changes[key]=dict(delta_l2=float(diff.norm()),
                            relative_l2=float(diff.norm()/reference['stages'][key].norm().clamp_min(1e-12)),
                            delta_rms=float(diff.square().mean().sqrt()))
                    delta=q-reference['q']
                    mu_delta=(stages['mu']-reference['stages']['mu']).flatten().double()
                    if amount==1000:deltas.append((rank,mu_delta))
                    local=delta[t,s,max(0,rank-16):rank+17].abs().sum()
                    row=dict(added_btc=amount,rank=rank,stage_changes=stage_changes,
                        original_input_btc=float(base['volume'][0,t,s,rank]),
                        base_prediction_btc=float(reference['q'][t,s,rank]),
                        changed_prediction_btc=float(q[t,s,rank]),
                        output_delta_at_injection=float(delta[t,s,rank]),
                        local_identity_gain=float(delta[t,s,rank])/amount,
                        same_frame_side_total_output_delta=float(delta[t,s].sum()),
                        absolute_delta_fraction_same_frame_within16levels=float(local/delta.abs().sum().clamp_min(1e-20)),
                        output_largest_absolute_change_coordinate=list(map(int,np.unravel_index(int(delta.abs().argmax()),delta.shape))))
                    rows.append(row)
                    atomic_json(root/'probe_progress.json',dict(precision=precision,completed_probes=len(rows),total=len(plan['probes'])))
                    del out,b
                cosines={}
                for i,(rank,a) in enumerate(deltas):
                    for rank2,b in deltas[i+1:]:
                        denominator=float(a.norm()*b.norm())
                        cosines[f'{rank}:{rank2}']=float(a.dot(b))/denominator if denominator>1e-25 else None
                result[precision]=dict(rows=rows,latent_delta_location_cosines=cosines)
                atomic_json(root/'peak_response.json',dict(results=result,
                    scope='Read-only counterfactual probes on one realtrainingwindow; same checkpoint/mask/prices/times. Sensitivity is not equivalent to information recoverability. Cross-precision magnitudes are descriptive, no trainingcausality claim.',
                    optimizer_updates=0))
    finally:
        for hook in hooks:hook.remove()


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root',type=Path)
    parser.add_argument('--alignment',action='store_true')
    args=parser.parse_args();torch.set_num_threads(4);seed_everything(42);strict_precision()
    if args.alignment:alignment(args.root)
    else:probe(args.root)
