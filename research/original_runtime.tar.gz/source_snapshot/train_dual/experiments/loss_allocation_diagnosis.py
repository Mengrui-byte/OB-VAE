"""CPU-only postmortem; no model updates or new GPU jobs."""
import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import maximum_filter1d

from train_dual.experiments.full_window_run import dataset


def main(root):
    plan = json.loads((root/'plan.json').read_text())
    folder = root/'postmortem'
    folder.mkdir(exist_ok=True)
    distributions = {}
    for split, file in [('train','train_indices.npy'),('val','val_indices.npy')]:
        ds = dataset(root, split)
        entries, valid_q = [], []
        for index in np.load(root/file):
            raw = ds[int(index)]
            data = raw['data'].numpy()
            counts = raw['level_counts'].numpy()
            mask = np.arange(2048) < counts[...,None]
            q = data[...,1][mask].astype(np.float64)
            valid_q.append(q)
            first = int(ds.base.starts[int(index)])
            date = str(np.datetime64(int(ds.base.times[first]),'us'))
            entries.append(dict(index=int(index), start=date, mean=float(q.mean()),
                                rms=float(np.sqrt(np.mean(q*q))), max=float(q.max()),
                                count100=int((q>=100).sum()), count10=int((q>=10).sum())))
        q = np.concatenate(valid_q)
        qq = q*q
        distributions[split] = dict(windows=entries, valid_levels=len(q),
            mean=float(q.mean()), rms=float(np.sqrt(qq.mean())),
            quantiles={str(p):float(np.quantile(q,p)) for p in [.5,.9,.99,.999,.9999]},
            fraction100=float(np.mean(q>=100)),
            fraction_squared_quantity_from100=float(qq[q>=100].sum()/qq.sum()),
            note='Actual selected raw windows, physical BTC; no network inference')
    preview = {}
    for lane in plan['lanes']:
        with np.load(root/lane/'step1024_profiles.npz') as data:
            q,pred,mask=data['truth'][...,1],data['prediction'][...,1],data['mask']
            true = (q>=100)&mask
            chosen = (pred>=100)&mask
            tolerances = {}
            for radius in [0,1,4,16,64]:
                near_pred = maximum_filter1d(chosen.astype(np.uint8),size=2*radius+1,axis=-1,mode='constant')>0
                near_true = maximum_filter1d(true.astype(np.uint8),size=2*radius+1,axis=-1,mode='constant')>0
                # These are separate coverage ratios, not one-to-one matching.
                tolerances[str(radius)] = dict(
                    truth_coverage=float((true&near_pred).sum()/max(1,true.sum())),
                    prediction_coverage=float((chosen&near_true).sum()/max(1,chosen.sum())) if chosen.any() else None)
            p,ph=data['truth'][...,0],data['prediction'][...,0]
            mid=(p[:,:,0,0]+p[:,:,1,0])/2
            midh=(ph[:,:,0,0]+ph[:,:,1,0])/2
            dm=midh-mid
            residual=(ph-midh[:,:,None,None])-(p-mid[:,:,None,None])
            err=ph-p
            preview[lane] = dict(indices=data['indices'].tolist(),
                true100=int(true.sum()), predicted100=int(chosen.sum()),
                rank_tolerance_coverage=tolerances,
                price_rmse=float(np.sqrt(np.mean(err[mask]**2))),
                mid_rmse=float(np.sqrt(np.mean(dm**2))),
                own_mid_removed_shape_rmse=float(np.sqrt(np.mean(residual[mask]**2))),
                price_error_decomposition_mse=dict(total=float(np.mean(err[mask]**2)),
                    translation=float(np.mean(np.broadcast_to(dm[:,:,None,None],mask.shape)[mask]**2)),
                    shape=float(np.mean(residual[mask]**2)),
                    cross=float(np.mean((2*dm[:,:,None,None]*residual)[mask]))),
                note='Only3preselected development preview windows; not the16-window aggregate. Rank tolerance is same-frame/side coverage, not order-identity or a replacement metric. Own-mid subtraction is diagnostic only.')
    curves = {}
    for lane in plan['lanes']:
        hist=[]
        for step in [0,*plan['checkpoints']]:
            item=dict(step=step)
            for role,suffix in [('train','_seen'),('development','')]:
                name=f'initial{suffix}_evaluation.json' if not step else f'step{step}{suffix}_evaluation.json'
                d=json.loads((root/lane/name).read_text())['result'];m=d['metrics']
                item[role]=dict(price_rmse=m['price_usdt']['rmse'],quantity_rmse=m['quantity_btc']['rmse'],
                    quantity_change_correlation=m['temporal_log_quantity_1_minutes']['correlation'],
                    quantity_correlation=m['quantity_btc']['correlation'],
                    quantity_rms=m['quantity_btc']['prediction_rms'],quantity_mae=m['quantity_btc']['mae'],
                    thresholds=d['thresholds'])
            hist.append(item)
        curves[lane]=hist
    result=dict(distributions=distributions, previews=preview,curves=curves,
        additional_training_exposures_per_window=plan['steps']*plan['accumulation']/plan['fit_windows'],
        unique_train_hours=plan['fit_windows']*256/60,
        scope='CPU-only read of existing data and saved results. No new training, no independent-test data.',
        limitations='Changing4-window fitting to representative training was not controlled here; overfit mechanism and distribution shift are supported/descriptive, not a complete causal separation.')
    (folder/'evidence.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(distributions={k:{n:v[n] for n in ['mean','rms','quantiles','fraction100','fraction_squared_quantity_from100']} for k,v in distributions.items()},
        previews=preview,exposures=result['additional_training_exposures_per_window'],hours=result['unique_train_hours']),ensure_ascii=False,indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root',type=Path)
    main(parser.parse_args().root.resolve())
