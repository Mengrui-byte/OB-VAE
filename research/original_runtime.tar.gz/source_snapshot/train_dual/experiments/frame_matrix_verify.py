"""Source seen-window baseline and final portability checks for the small pilot."""

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import torch

from model.experimental.frame_matrix_state import FrameMatrixOrderBookVAE
from train_dual.experiments.local_quant_reconstruction import CacheWindows
from train_dual.experiments.long_worker import atomic_json,datasets,evaluate
from train_dual.experiments.window_state_pilot import load_base,strict_precision
from train_dual.util.checkpoint import load_for_inference


def source_seen(root):
    torch.set_num_threads(4);strict_precision();source,norm=load_base(root)
    model=FrameMatrixOrderBookVAE(matrix_dim=1024,**source['model_config']).to('cuda:0').eval()
    model.load_cross_initial(source['model']);model.evaluation_mode='original'
    train=CacheWindows(datasets(root,source,'train'),np.load(root/'fit_indices.npy'))
    value=evaluate(model,norm,train,64,'cuda:0')
    atomic_json(root/'source_seen_evaluation.json',dict(result=value,actual_training_windows=True))
    print(json.dumps({k:value['metrics'][k] for k in ('price_usdt','quantity_btc')}))


def verify(root):
    torch.set_num_threads(4);source,_=load_base(root);plan=json.loads((root/'plan.json').read_text());checks={}
    for lane,spec in plan['lanes'].items():
        payload=torch.load(root/lane/'final.pt',map_location='cpu',weights_only=False)
        changes=[k for k,v in source['model'].items() if not torch.equal(v,payload['model'][k])]
        if spec['mode']=='joint':assert all(k.startswith(('price_decoder.','volume_decoder.','volume_refinement.')) for k in changes)
        else:assert not changes
        m,_=load_for_inference(root/lane/'final.pt','cpu')
        with np.load(root/lane/'matrix_examples.npz') as z:
            matrix=torch.from_numpy(z['matrix']);assert matrix.shape==(3,16,1024);assert torch.isfinite(matrix).all()
            x=m.frame_codec.decode(matrix);assert x.shape==(3,16,4160)
        checks[lane]=dict(source_changed_tensors=len(changes),encoder_and_cross_unchanged=True,
            matrix_shape=[3,16,1024],decoder_shape=[3,16,4160],checkpoint_loaded=True)
    # Verify original experiment snapshot files were not rewritten during development.
    original=root/'source_snapshot';hashes=json.loads((original/'sha256.json').read_text())
    bad=[k for k,h in hashes.items() if hashlib.sha256((original/k).read_bytes()).hexdigest()!=h];assert not bad
    checks['snapshot_hash_mismatches']=bad
    atomic_json(root/'verification.json',checks);print(json.dumps(checks,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--source-seen',action='store_true');a=p.parse_args()
    if a.source_seen:source_seen(a.root)
    else:verify(a.root)
