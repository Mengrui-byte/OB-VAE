"""True4096-dimensional joint PCA, followed by matched decoder-only adaptation."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

import numpy as np
import torch

from model.experimental.dual_fusion import FusedOrderBookVAE
from model.experimental.joint_pca_state import JointPCAWindowVAE
from model.losses.dual import DualLossConfig,DualVAELoss
from model.losses.quantity_dice import DiceOrderBookLoss,continuous_quantity_dice
from model.losses.quantity_morphology import MorphologyDiceOrderBookLoss,quantity_morphology_loss
from train_dual.experiments.local_codebook_size_run import write
from train_dual.experiments.long_worker import datasets
from train_dual.experiments.pca_run import decode_direct
from train_dual.util.data import DualNormalizer
from train_dual.util.dynamics import DynamicsMetrics
from util.model_sources import freeze_model_sources


def progress(root,**kw):
    write(root/'progress.json',kw)
    with (root/'progress.jsonl').open('a') as f:f.write(json.dumps(kw)+'\n')
    print(json.dumps(kw),flush=True)


def load_source(plan):
    saved=torch.load(plan['source_checkpoint'],map_location='cpu',weights_only=False)
    norm=DualNormalizer(**{k:saved['config']['normalization'][k] for k in ('tick_size','price_scale')})
    return saved,norm


def worker(root,lane):
    torch.set_num_threads(4);torch.manual_seed(42);started=time.monotonic()
    plan=json.loads((root/'plan.json').read_text());saved,norm=load_source(plan);folder=root/lane;folder.mkdir()
    compressed=lane=='compressed4096'
    if compressed:
        model=JointPCAWindowVAE(state_dim=4096,window_size=16,**saved['model_config'])
        model.load_cross_initial(saved['model']);model.state_codec.load_basis(torch.load(root/'joint_pca_basis.pt',map_location='cpu',mmap=True,weights_only=False))
    else:
        model=FusedOrderBookVAE(fusion_variant='cross',fusion_seed=42,**saved['model_config']);model.load_state_dict(saved['model'],strict=True)
        model.encoder.requires_grad_(False);model.fusion.requires_grad_(False)
    model.eval();source=Path(plan['data_source']);train=datasets(source,saved,'train');val=datasets(source,saved,'val')
    cache=torch.load(source/'decoder_latents.pt',map_location='cpu',mmap=True,weights_only=False)
    states=torch.load(root/'training_states.pt',map_location='cpu',mmap=True,weights_only=False)['states'] if compressed else None
    development=torch.load(root/'development_states.pt',map_location='cpu',mmap=True,weights_only=False)
    order=np.load(root/'training_order.npy');fit_indices=np.load(source/'fit_indices.npy');val_indices=np.array(plan['development_indices'])
    train_parameters=[]
    for name,p in model.named_parameters():
        allowed=name.startswith(('price_decoder.','volume_decoder.','volume_refinement.'));p.requires_grad_(allowed)
        if allowed:train_parameters.append(p)
    frozen_before={k:v.clone() for k,v in model.state_dict().items() if k.startswith(('encoder.','fusion.'))}
    loss_cfg=DualLossConfig(**plan['loss'])
    objective=plan.get('quantity_objective','original')
    is_dice=objective in ('squared_dice','squared_dice_morphology')
    if objective=='squared_dice_morphology':
        criterion=MorphologyDiceOrderBookLoss(saved['model_config'].get('quantity_scale',1.),loss_cfg,
            dice_weight=plan['dice_weight'],epsilon=plan['dice_epsilon'],morphology_weight=plan['morphology_weight'],
            scales=tuple(plan['morphology_scales']),huber_beta=plan['morphology_huber_beta'])
    elif is_dice:
        criterion=DiceOrderBookLoss(saved['model_config'].get('quantity_scale',1.),loss_cfg,
            dice_weight=plan['dice_weight'],epsilon=plan['dice_epsilon'])
    else:criterion=DualVAELoss(saved['model_config'].get('quantity_scale',1.),loss_cfg)
    optimizer=torch.optim.AdamW(train_parameters,lr=plan['learning_rate'],weight_decay=plan['weight_decay'])
    def checkpoint(step):
        state={k:v for k,v in model.state_dict().items() if not k.startswith('state_codec.')}
        effective_loss=dict(plan['loss'])
        if is_dice:effective_loss.update(volume_log=0.,volume_linear=0.,volume_tail=0.)
        config=dict(saved['config'],loss=effective_loss,quantity_objective=plan.get('quantity_objective','original'),
            training_experiment=dict(seed=plan['seed'],steps=plan['steps'],batch_size=plan['batch_size'],learning_rate=plan['learning_rate'],weight_decay=plan['weight_decay']))
        if is_dice:config.update(dice_weight=plan['dice_weight'],dice_epsilon=plan['dice_epsilon'])
        if objective=='squared_dice_morphology':
            config.update(morphology_weight=plan['morphology_weight'],morphology_scales=plan['morphology_scales'],morphology_huber_beta=plan['morphology_huber_beta'])
        payload=dict(model=state,model_config=saved['model_config'],config=config,step=step,optimizer=optimizer.state_dict(),
            lane=lane,source_checkpoint=plan['source_checkpoint'],source_hashes=plan['source_hashes'])
        if compressed:payload.update(joint_pca_config=model.joint_pca_config,codec_file=str(root/'joint_pca_basis.pt'),codec_sha256=plan['codec_sha256'])
        path=folder/('final.pt' if step==plan['steps'] else f'step{step}.pt');torch.save(payload,path)
    def decode_positions(positions,b,split):
        if split=='train':
            if compressed:return model.decode_state(states[positions],b['mask'],b['tick_norm'],b['times'])
            return decode_direct(model,cache['global'][positions],cache['local'][positions],b['mask'],b['tick_norm'],b['times'])
        if compressed:return model.decode_state(development['states'][positions],b['mask'],b['tick_norm'],b['times'])
        return decode_direct(model,development['global'][positions],development['local'][positions],b['mask'],b['tick_norm'],b['times'])
    def evaluate(split,positions,step,save_profiles=False,state_dim=None):
        model.eval();metric=DynamicsMetrics(norm.tick_size);counts=np.zeros(3,dtype='int64');truths=[];predictions=[];sample_indices=[];shape_sums={}
        with torch.inference_mode():
            for count,position in enumerate(positions,1):
                index=int(fit_indices[position]) if split=='train' else int(val_indices[position]);data=train if split=='train' else val
                raw={k:v.unsqueeze(0) for k,v in data[index].items()};b=norm.prepare(raw,'cpu')
                if state_dim==4095:
                    z=development['states'][position:position+1].clone();z[:,-1]=0
                    out=model.decode_state(z,b['mask'],b['tick_norm'],b['times'])
                else:out=decode_positions(torch.tensor([position]),b,split)
                truth=raw['data'][0].numpy().astype('float64');pred=np.stack([norm.inverse_price(out['price_norm'],b)[0].numpy(),out['volume'][0].numpy()],-1);mask=b['mask'][0].numpy()
                metric.update(truth,pred,mask);a=(truth[...,1]>=100)&mask;bb=(pred[...,1]>=100)&mask
                counts+=[int((a&bb).sum()),int((~a&bb&mask).sum()),int((a&~bb).sum())]
                if plan.get('evaluate_morphology'):
                    mm,components=quantity_morphology_loss(out['volume'],b['volume'],b['mask'],scales=tuple(plan['morphology_scales']),
                        quantity_scale=saved['model_config'].get('quantity_scale',1.),huber_beta=plan['morphology_huber_beta'])
                    values=dict(morphology=float(mm),quantity_dice=float(continuous_quantity_dice(out['volume'],b['volume'],b['mask'],
                        quantity_scale=saved['model_config'].get('quantity_scale',1.),epsilon=plan['dice_epsilon'])),**{'morphology_k'+k:float(v) for k,v in components.items()})
                    for k,v in values.items():shape_sums[k]=shape_sums.get(k,0.)+v
                if save_profiles and position in (0,63,127):truths.append(truth);predictions.append(pred);sample_indices.append(index)
                if len(positions)>16 and count%32==0:progress(folder,phase='evaluation',split=split,step=step,windows=count,total_windows=len(positions),state_dim=state_dim or (4096 if compressed else 66560),elapsed_seconds=time.monotonic()-started)
        dd=metric.finish();tp,fp,fn=map(int,counts);dd['threshold100']=dict(tp=tp,fp=fp,fn=fn,recall=tp/(tp+fn) if tp+fn else None,precision=tp/(tp+fp) if tp+fp else None)
        dd.update(step=step,split=split,positions=list(map(int,positions)),elapsed_seconds=time.monotonic()-started)
        if shape_sums:dd['shape_metrics']={k:v/len(positions) for k,v in shape_sums.items()}
        label=f'{split}_step{step}_{len(positions)}windows'+('_d4095' if state_dim==4095 else '');write(folder/(label+'.json'),dd)
        if predictions:np.savez_compressed(folder/(label+'_profiles.npz'),truth=np.stack(truths),prediction=np.stack(predictions),indices=sample_indices)
        return dd
    allval=list(range(128));monitor=plan['monitor_development_positions'];seen=plan['seen_training_positions']
    progress(folder,phase='initial_evaluation',step=0,lane=lane)
    if plan.get('initial_reference_parent'):
        parent=Path(plan['initial_reference_parent']);reference=parent/lane
        original=torch.load(reference/'step0.pt',map_location='cpu',weights_only=False)['model']
        assert all(torch.equal(v,model.state_dict()[k]) for k,v in original.items())
        assert os.path.samefile(root/'joint_pca_basis.pt',parent/'joint_pca_basis.pt')
        assert os.path.samefile(root/'training_states.pt',parent/'training_states.pt')
        assert os.path.samefile(root/'development_states.pt',parent/'development_states.pt')
        assert np.array_equal(order,np.load(parent/'training_order.npy'))
        profiles=np.load(reference/'development_step0_128windows_profiles.npz')
        with torch.inference_mode():
            for i,position in enumerate((0,63,127)):
                raw={k:v.unsqueeze(0) for k,v in val[int(val_indices[position])].items()};b=norm.prepare(raw,'cpu')
                out=decode_positions(torch.tensor([position]),b,'development')
                pred=np.stack([norm.inverse_price(out['price_norm'],b)[0].numpy(),out['volume'][0].numpy()],-1)
                np.testing.assert_allclose(pred,profiles['prediction'][i],rtol=0,atol=1e-8)
        for name in ['initial_evaluation.json','initial_4095_evaluation.json','initial_seen_evaluation.json','train_step0_16windows.json','development_step0_128windows.json','development_step0_128windows_profiles.npz']:
            if (reference/name).exists():shutil.copy2(reference/name,folder/name)
        write(folder/'initial_reference_verification.json',dict(neural_weights_exact=True,shared_codec_and_state_files_same_inode=True,same_training_order=True,three_saved_reconstructions_exact=True,reference=str(reference)))
    else:
        baseline=evaluate('development',allval,0,True);write(folder/'initial_evaluation.json',baseline)
        if compressed and not plan.get('skip_initial_4095'):write(folder/'initial_4095_evaluation.json',evaluate('development',allval,0,state_dim=4095))
        trainbase=evaluate('train',seen,0);write(folder/'initial_seen_evaluation.json',trainbase)
    checkpoint(0)
    if plan.get('evaluation_only'):
        write(folder/'status.json',dict(state='complete',evaluation_only=True,elapsed_seconds=time.monotonic()-started));return
    first_gradients={}
    for step in range(1,plan['steps']+1):
        model.train();model.encoder.eval();model.fusion.eval();positions=order[step-1]
        raw=[train[int(fit_indices[p])] for p in positions];raw={k:torch.stack([item[k] for item in raw]) for k in raw[0]}
        b=norm.prepare(raw,'cpu');optimizer.zero_grad(set_to_none=True)
        out=decode_positions(torch.tensor(positions),b,'train');terms=criterion(out,b);loss=terms['loss']
        if not bool(torch.isfinite(loss)):raise FloatingPointError('Nonfinite decoder loss')
        loss.backward()
        if step==1:
            for name in ('price_decoder','volume_decoder','volume_refinement'):
                gradients=[p.grad for p in getattr(model,name).parameters() if p.grad is not None]
                first_gradients[name]=float(torch.sqrt(sum(g.double().square().sum() for g in gradients)))
            assert all(v>0 for v in first_gradients.values());assert all(p.grad is None for p in model.encoder.parameters())
            write(folder/'first_step_gradients.json',first_gradients)
            write(folder/'actual_training_shape.json',dict(raw_input=list(raw['data'].shape),state=list(out['market_state'].shape) if 'market_state' in out else None,
                price_output=list(out['price_norm'].shape),quantity_output=list(out['volume'].shape),quantity_objective=objective))
        grad=torch.nn.utils.clip_grad_norm_(train_parameters,1.,error_if_nonfinite=True);optimizer.step()
        if step==1 or step%8==0:
            progress(folder,phase='decoder_adaptation',step=step,total_steps=plan['steps'],lane=lane,loss=float(loss.detach()),
                quantity_dice=float(terms['quantity_dice'].detach()) if 'quantity_dice' in terms else None,
                quantity_morphology=float(terms['quantity_morphology'].detach()) if 'quantity_morphology' in terms else None,
                gradient_norm=float(grad),elapsed_seconds=time.monotonic()-started)
        if step in plan['checkpoints']:
            checkpoint(step);evaluate('development',allval if step==plan['steps'] else monitor,step,step==plan['steps'])
            evaluate('train',seen,step)
    final=json.loads((folder/f'development_step{plan["steps"]}_128windows.json').read_text());write(folder/'final_evaluation.json',final)
    verified=all(torch.equal(v,model.state_dict()[k]) for k,v in frozen_before.items());assert verified
    write(folder/'verification.json',dict(encoder_and_fusion_bitwise_unchanged=verified,only_decoders_trained=True,steps=plan['steps'],codec_frozen=True))
    write(folder/'status.json',dict(state='complete',steps=plan['steps'],elapsed_seconds=time.monotonic()-started))


def prepare(root):
    root=root.resolve();root.mkdir(parents=True,exist_ok=False);torch.set_num_threads(4);torch.manual_seed(42);started=time.monotonic()
    project=Path(__file__).resolve().parents[2];source=project/'checkpoints/pca_state_20261024_222656';prior=project/'recons/unified_continuous_rank_20261026'
    write(root/'status.json',dict(state='preparing'))
    hashes=freeze_model_sources(root/'source_snapshot',project_root=project)
    for directory in ('train_dual','util'):
        for file in (project/directory).rglob('*.py'):
            rel=file.relative_to(project);dest=root/'source_snapshot'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(file,dest);hashes[str(rel)]=hashlib.sha256(file.read_bytes()).hexdigest()
    write(root/'source_snapshot/sha256.json',hashes)
    checkpoint=source/'reference/final.pt';saved=torch.load(checkpoint,map_location='cpu',weights_only=False)
    oldplan=json.loads((prior/'plan.json').read_text());assert hashlib.sha256(checkpoint.read_bytes()).hexdigest()==oldplan['source_sha256']
    plan=dict(scope='Historical16minute prequantization Global/Local -> one true4096continuous state; decoder-only warm-start adaptation.',
        source_checkpoint=str(checkpoint),source_sha256=oldplan['source_sha256'],data_source=str(source),seed=42,window_minutes=16,
        raw_shape=[1,16,2,2048,2],global_shape=[1,16,64],local_shape=[1,16,2,128,16],state_shape=[1,4096],state_dtype='float32',
        pca_fit_windows=8192,pca_fit_period=['2022-01-01','2025-01-01'],development=['2025-01-01','2025-04-01'],development_indices=oldplan.get('indices',np.load(prior/'development_indices.npy').tolist()),
        steps=128,batch_size=2,learning_rate=3e-5,weight_decay=.01,gradient_clip=1.,checkpoints=[32,64,128],
        monitor_development_positions=np.linspace(0,127,16,dtype=int).tolist(),
        initialization='Both decoder arms start from identical pretrained source decoder weights. Compressed arm changes only decoder input to fixed joint4096-PCA reconstruction. Encoder/fusion/PCA are frozen.',
        precision='FP64PCAfit then FP32basis,state and decoder training/evaluation; CPU4threads per worker',
        loss=dict(saved['config']['loss'],beta_global=0.,beta_local=0.),
        pca_method='One raw unscaled joint PCA over all66560coordinates;8192fitting windows allow4096nonzero directions. No VQ or integer codes.',
        limitations='128updates x2windows=256training visits, a bounded adaptation pilot rather than training to convergence. Single seed42; reused development set, no independent test.4095prior used4096fitting windows; do not attribute differences to one added dimension.',
        source_hashes=hashes)
    generator=torch.Generator().manual_seed(42);order=torch.randperm(8192,generator=generator)[:plan['steps']*plan['batch_size']].reshape(plan['steps'],plan['batch_size']).numpy()
    np.save(root/'training_order.npy',order);plan['seen_training_positions']=order.ravel()[np.linspace(0,order.size-1,16,dtype=int)].tolist();write(root/'plan.json',plan)
    progress(root,phase='constructing_all8192_joint_training_matrix',elapsed_seconds=time.monotonic()-started)
    cache=torch.load(source/'decoder_latents.pt',map_location='cpu',mmap=True,weights_only=False);g,l=cache['global'],cache['local']
    assert list(g.shape)==[8192,16,64] and list(l.shape)==[8192,16,2,128,16]
    x=torch.empty(8192,66560,dtype=torch.float64)
    for i in range(0,8192,128):x[i:i+128,:1024]=g[i:i+128].flatten(1).double();x[i:i+128,1024:]=l[i:i+128].flatten(1).double()
    mean=x.mean(0);x-=mean
    progress(root,phase='fitting8192_training_gram',elapsed_seconds=time.monotonic()-started)
    gram=x@x.T;progress(root,phase='eigendecomposition8192',elapsed_seconds=time.monotonic()-started)
    ev,u=torch.linalg.eigh(gram);del gram;ev=ev.flip(0);u=u.flip(1)
    assert float(ev[4095])>float(ev[0])*max(x.shape)*torch.finfo(torch.float64).eps
    write(root/'pca_fit.json',dict(fit_windows=8192,nonzero_components_requested=4096,eigenvalue_4096=float(ev[4095]),largest_eigenvalue=float(ev[0]),training_energy_retained=float(ev[:4096].sum()/x.square().sum()),scaling='none; raw joint coordinates',fit_period='2022-2024only'))
    factor=u[:,:4096]/ev[:4096].sqrt();basis=torch.empty(4096,66560,dtype=torch.float32)
    progress(root,phase='constructing_joint4096_basis',elapsed_seconds=time.monotonic()-started)
    for i in range(0,66560,4096):basis[:,i:i+4096]=(factor.T@x[:,i:i+4096]).float()
    del x,factor,u,ev
    sample=np.linspace(0,4095,64,dtype=int);dots=basis[sample].double()@basis.double().T
    expected=torch.zeros_like(dots);expected[torch.arange(len(sample)),torch.tensor(sample)]=1
    orth_error=float((dots-expected).abs().max());assert orth_error<1e-5
    basis_data=dict(mean=mean.float(),basis=basis,state_dim=4096,window_size=16)
    torch.save(basis_data,root/'joint_pca_basis.pt');plan['codec_sha256']=hashlib.sha256((root/'joint_pca_basis.pt').read_bytes()).hexdigest();write(root/'plan.json',plan)
    states=torch.empty(8192,4096,dtype=torch.float32)
    with torch.inference_mode():
        for i in range(0,8192,128):
            flat=torch.cat([g[i:i+128].flatten(1),l[i:i+128].flatten(1)],1)
            states[i:i+128]=(flat-basis_data['mean'])@basis.T
            if i%1024==0:progress(root,phase='encoding_fp32_training_states',windows=i+128,total=8192,elapsed_seconds=time.monotonic()-started)
    torch.save(dict(states=states),root/'training_states.pt')
    dd=np.load(prior/'development_continuous_latents.npz');dg=torch.from_numpy(dd['global_latent']);dl=torch.from_numpy(dd['local_latent'])
    with torch.inference_mode():
        flat=torch.cat([dg.flatten(1),dl.flatten(1)],1);ds=(flat-basis_data['mean'])@basis.T
    devfile=dict(states=ds,indices=dd['indices']);devfile['global']=dg;devfile['local']=dl;torch.save(devfile,root/'development_states.pt')
    del states,g,l,cache
    # Real-window checks: source-cache alignment, unique state and decode-only replay.
    model=JointPCAWindowVAE(state_dim=4096,window_size=16,**saved['model_config']).eval();model.load_cross_initial(saved['model']);model.state_codec.load_basis(basis_data)
    norm=DualNormalizer(**{k:saved['config']['normalization'][k] for k in ('tick_size','price_scale')});val=datasets(source,saved,'val')
    raw={k:v.unsqueeze(0) for k,v in val[int(dd['indices'][0])].items()};b=norm.prepare(raw,'cpu')
    with torch.inference_mode():
        state=model.extract_market_state(b['price'],b['volume'],b['mask'],b['tick_norm'],b['times'])
        torch.testing.assert_close(state,ds[:1],rtol=1e-5,atol=1e-4)
        out=model(b['price'],b['volume'],b['mask'],b['tick_norm'],b['times']);replay=model.decode_state(out['market_state'],b['mask'],b['tick_norm'],b['times'])
        for key in ('volume','price_norm'):torch.testing.assert_close(out[key],replay[key],rtol=0,atol=0)
        # Same new8192-fit basis truncated to4095: isolate one-coordinate effect.
        z4095=ds[:1].clone();z4095[:,-1]=0;truncated=model.decode_state(z4095,b['mask'],b['tick_norm'],b['times'])
    write(root/'actual_shape_contract.json',dict(raw_input=list(raw['data'].shape),global_latent=[1,16,64],local_latent=[1,16,2,128,16],continuous_state=list(out['market_state'].shape),state_dtype=str(out['market_state'].dtype),price_output=list(out['price_norm'].shape),quantity_output=list(out['volume'].shape),decode_only_exact=True))
    write(root/'preflight.json',dict(sampled_basis_orthogonality_max_error=orth_error,online_cache_state_close=True,decode_only_exact=True,real_state_shape=list(state.shape)))
    del model,basis_data,basis,mean,flat,ds,dg,dl
    progress(root,phase='launching_matched_decoder_workers',elapsed_seconds=time.monotonic()-started)
    children=[]
    env=dict(os.environ,PYTHONPATH=str(root/'source_snapshot'),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',MKL_NUM_THREADS='4')
    try:
        for lane in ('compressed4096','uncompressed'):
            log=(root/(lane+'.log')).open('wb')
            p=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.joint4096_decoder_run',str(root),'--worker',lane],env=env,cwd=root/'source_snapshot',stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT)
            log.close();children.append((lane,p))
        write(root/'status.json',dict(state='training',workers=[dict(lane=lane,pid=p.pid) for lane,p in children]))
        while any(p.poll() is None for _,p in children):
            if any(p.poll() not in (None,0) for _,p in children):raise RuntimeError('A matched decoder worker failed')
            time.sleep(2)
        assert all(p.returncode==0 for _,p in children)
        comparisons={lane:{stage:json.loads((root/lane/(stage+'_evaluation.json')).read_text()) for stage in ('initial','final')} for lane,_ in children}
        write(root/'comparison.json',comparisons);write(root/'status.json',dict(state='complete',steps=128,elapsed_seconds=time.monotonic()-started))
        progress(root,phase='complete',elapsed_seconds=time.monotonic()-started)
    finally:
        for _,p in children:
            if p.poll() is None:p.terminate()
        for _,p in children:
            try:p.wait(timeout=10)
            except subprocess.TimeoutExpired:p.kill();p.wait()


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('root',type=Path);parser.add_argument('--worker',choices=['compressed4096','uncompressed']);a=parser.parse_args()
    try:
        if a.worker:worker(a.root.resolve(),a.worker)
        else:prepare(a.root)
    except BaseException as error:
        location=a.root/a.worker if a.worker else a.root
        if location.exists():write(location/'failure.json',dict(error=repr(error)))
        raise
