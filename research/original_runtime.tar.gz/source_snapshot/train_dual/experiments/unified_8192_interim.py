"""Fixed-common-checkpoint development inspection; never changes training."""
import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager,ticker
import numpy as np
from plotly.offline import get_plotlyjs

from train_dual.experiments.local_comparison_plots import MID_PAGE,FRAMES_PAGE,STYLE
from train_dual.util.checkpoint import freeze_sources

MODELS=[dict(key='truth',label='真实订单簿',color='#172b45'),dict(key='source',label='旧大latent参考·512步',color='#8a949f'),dict(key='ae',label='确定性AE',color='#366590'),dict(key='vae_1e6',label='VAE β=1e−6',color='#337c70'),dict(key='vae_1e5',label='VAE β=1e−5',color='#b27c33'),dict(key='vae_1e4',label='VAE β=1e−4',color='#ab6173')]


def read(path):return json.loads(path.read_text())


def main(root):
    root=root.resolve();plan=read(root/'plan.json');lanes=list(plan['lanes'])
    ready=[step for step in plan['checkpoints'] if all((root/lane/f'step{step}_profiles.npz').exists() and (root/lane/f'step{step}_evaluation.json').exists() for lane in lanes)]
    if not ready:raise RuntimeError('No complete common checkpoint yet')
    step=max(ready);output_root=root.parents[1]/'recons'/(root.name+'_interim');folder=output_root/f'step{step}';folder.mkdir(parents=True,exist_ok=False)
    arrays={};hashes={}
    with np.load(root/'source_profiles.npz') as d:
        for key in ('truth','mask','time','indices'):arrays[key]=d[key]
        arrays['source']=d['prediction']
    hashes['source_profiles.npz']=hashlib.sha256((root/'source_profiles.npz').read_bytes()).hexdigest()
    for lane in lanes:
        p=root/lane/f'step{step}_profiles.npz'
        with np.load(p) as d:
            for key in ('truth','mask','time','indices'):np.testing.assert_array_equal(arrays[key],d[key])
            arrays[lane]=d['prediction']
        hashes[str(p.relative_to(root))]=hashlib.sha256(p.read_bytes()).hexdigest()
    assert arrays['truth'].shape==(3,256,2,2048,2)
    note=(f'8192维统一瓶颈中期检查：新模型共同第{step}步，整窗256分钟，推理用μ。旧大latent参考使用其512步权重，仅作外部质量标尺，容量和训练预算不同。'
          '三例预先固定的2025Q1开发窗口，已经用于研究；无训练时间重叠，但不能当作最终独立测试。价格使用真实保存的物理单位结果，只使用首帧锚点，没有逐帧真实mid旁路或事后对齐。')
    positions=np.linspace(0,255,6,dtype=int);windows=[];mid_windows=[]
    for w,index in enumerate(arrays['indices']):
        times=[str(np.datetime64(int(t),'us'))+'Z' for t in arrays['time'][w]]
        mid={m['key']:arrays[m['key']][w,:,:,0,0].mean(1) for m in MODELS}
        metrics={}
        for m in MODELS[1:]:
            error=mid[m['key']]-mid['truth'];metrics[m['key']]=dict(rmse=float(np.sqrt(np.mean(error**2))),mae=float(np.abs(error).mean()),max_absolute_error=float(np.abs(error).max()))
        windows.append(dict(index=int(index),start=times[0],end=times[-1]))
        mid_windows.append(dict(index=int(index),time=times,mid={k:v.tolist() for k,v in mid.items()},metrics=metrics))
        payload=dict(index=int(index),time=[times[t] for t in positions],mask=arrays['mask'][w,positions].tolist(),books={m['key']:arrays[m['key']][w,positions].tolist() for m in MODELS})
        (folder/f'frames_window{w}.json').write_text(json.dumps(payload,separators=(',',':'),allow_nan=False))
    manifest=dict(run=root.name,common_step=step,source_reference_step=512,windows=windows,models=MODELS,positions=positions.tolist(),frame_minutes=(positions+1).tolist(),input_minutes=256,latent_shape=[64,128],
        evaluation_windows=16,visualization_windows=3,split='2025Q1 repeatedly-used development, not pristine independent test',sampling='Same3predeclared windows and6uniform frames, independent of reconstruction quality',price_alignment='None; raw saved physical-unit prediction',source_sha256=hashes,note=note)
    (folder/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
    (folder/'mid_data.json').write_text(json.dumps(dict(models=MODELS,windows=mid_windows),ensure_ascii=False,allow_nan=False))
    midpage=MID_PAGE.replace('__STYLE__',STYLE).replace('__NOTE__',note)
    framespage=FRAMES_PAGE.replace('__STYLE__',STYLE).replace('__NOTE__',note).replace("$('model').value='zero_global'","$('model').value='ae'").replace('（Local＋Global置零）','（确定性AE）')
    for name,page in [('mid.html',midpage),('frames.html',framespage)]:
        page=page.replace('<h1>','<h1>第'+str(step)+'步 · ',1)
        (folder/name).write_text(page)
    (folder/'plotly.min.js').write_text(get_plotlyjs())
    records={};history={}
    def compact(d):
        m=d['metrics'];return dict(price_rmse_usdt=m['price_usdt']['rmse'],quantity_rmse_btc=m['quantity_btc']['rmse'],quantity_correlation=m['quantity_btc']['correlation'],mid_change_correlation=m['temporal_mid_1_minutes_usdt_per_minute']['correlation'],mid_change_rmse=m['temporal_mid_1_minutes_usdt_per_minute']['rmse'],quantity_change_correlation=m['temporal_log_quantity_1_minutes']['correlation'],quantity_change_amplitude=m['temporal_log_quantity_1_minutes']['centered_amplitude_ratio'],spatial64_variation_correlation=m['spatial_slope_64_within_frame_variation']['correlation'],large100=d['thresholds']['100'],large10=d['thresholds']['10'],quantity_max_btc=d['prediction_max'],target_quantity_max_btc=d['target_max'],posterior=d.get('posterior'))
    records['source']=compact(read(root/'reference_evaluation.json')['result'])
    for lane in lanes:
        records[lane]=compact(read(root/lane/f'step{step}_evaluation.json')['result']);history[lane]={}
        for n in [0,*ready]:
            p=root/lane/('initial_evaluation.json' if n==0 else f'step{n}_evaluation.json')
            if p.exists():history[lane][str(n)]=compact(read(p)['result'])
    progress={lane:read(root/lane/'progress.json') for lane in lanes}
    summary=dict(created_at=datetime.now().isoformat(),common_step=step,current_training_steps={k:v['step'] for k,v in progress.items()},records=records,history=history,scope=note)
    (folder/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,allow_nan=False))
    table=''
    for m in MODELS[1:]:
        v=records[m['key']];table+=f'<tr><td>{m["label"]}</td><td>{512 if m["key"]=="source" else step}</td><td>{v["price_rmse_usdt"]:.2f}</td><td>{v["quantity_rmse_btc"]:.3f}</td><td>{v["mid_change_correlation"]:.3f}</td><td>{v["quantity_change_correlation"]:.4f}</td><td>{v["large100"]["recall"]*100:.1f}%</td></tr>'
    page=f'''<!doctype html><html lang=zh-CN><title>8192维VAE第{step}步中期重建</title>{STYLE}<h1>8192维统一瓶颈 · 第{step}步重建检查</h1><p>{note}</p><p>报告创建时训练进度：{', '.join(k+' '+str(v['step'])+'/2048' for k,v in progress.items())}。下表评价全部16个开发窗口，图中展示固定的3例。</p><p><a href=mid.html>① 中间价完整256分钟曲线</a> · <a href=frames.html>② 每档一条线的订单簿对比</a> · <a href=summary.json>数值与历史检查点</a> · <a href=manifest.json>数据来源与哈希</a></p><table><thead><tr><th>模型</th><th>步数</th><th>价格RMSE USDT</th><th>数量RMSE BTC</th><th>分钟mid变化相关</th><th>分钟挂量变化相关</th><th>≥100BTC召回</th></tr></thead><tbody>{table}</tbody></table><h2>训练中间价与挂量指标轨迹</h2><img style="width:100%" src=development_curves.png alt="三个声明检查点的开发指标"><h2>完整256分钟中间价对比</h2><p>所有曲线均未对齐或平移；右列直接显示预测减真实的误差。</p><a href=mid.html><img style="width:100%" src=midprice_comparison.png alt="三个窗口的完整中间价重建与误差"></a><h2>挂单量随时间演变</h2><p>首个固定窗口，全2048档。数量取log1p仅用于显示；真实、旧参考与AE使用相同色阶。</p><img style="width:100%" src=quantity_evolution.png alt="真实、旧参考、AE的买卖两侧挂量演变"><h2>逐档挂单线</h2><p>可切换三例窗口、四种新模型与旧参考，横轴可选实际价格或档位序号。<a href=frames.html>打开交互图</a></p><img style="width:100%" src=book_frames_window1.png alt="第一窗口六帧真实与AE的逐档挂单线"></html>'''
    (folder/'index.html').write_text(page)
    font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc';font_manager.fontManager.addfont(font)
    plt.rcParams.update({'font.family':font_manager.FontProperties(fname=font).get_name(),'axes.unicode_minus':False,'font.size':10})
    fig,axes=plt.subplots(3,2,figsize=(16,10),layout='constrained')
    x=np.arange(1,257)
    for w,v in enumerate(mid_windows):
        true=np.array(v['mid']['truth'])
        for m in MODELS:
            y=np.array(v['mid'][m['key']]);axes[w,0].plot(x,y,color=m['color'],lw=1.7 if m['key']=='truth' else 1.,alpha=.95,label=m['label'])
            if m['key']!='truth':axes[w,1].plot(x,y-true,color=m['color'],lw=1.,label=m['label'])
        for c in range(2):
            ax=axes[w,c];ax.set_title(f'窗口{w+1} · {v["time"][0][:10]} · '+('中间价' if c==0 else '预测－真实'));ax.set_xlabel('窗口内分钟');ax.set_ylabel('USDT');ax.grid(alpha=.18);ax.set_xlim(1,256);ax.yaxis.set_major_formatter(ticker.StrMethodFormatter('{x:,.0f}'))
        axes[w,0].legend(fontsize=7,ncol=2);axes[w,1].axhline(0,color='#64748b',lw=.6)
    fig.suptitle(f'8192维模型共同第{step}步｜完整256分钟中间价｜2025Q1开发样本',fontsize=16);fig.savefig(folder/'midprice_comparison.png',dpi=160);fig.savefig(folder/'midprice_comparison.svg');plt.close(fig)
    fig,axes=plt.subplots(2,2,figsize=(14,8),layout='constrained')
    for ax,(key,title) in zip(axes.flat,[('price_rmse_usdt','价格RMSE（USDT）'),('quantity_rmse_btc','数量RMSE（BTC）'),('mid_change_correlation','分钟中间价变化相关'),('quantity_change_correlation','分钟挂量变化相关')]):
        for m in MODELS[2:]:
            h=history[m['key']];steps=sorted(map(int,h));ax.plot(steps,[h[str(n)][key] for n in steps],marker='o',lw=1.4,color=m['color'],label=m['label'])
        ax.axhline(records['source'][key],color=MODELS[1]['color'],ls='--',lw=1,label='旧大latent参考');ax.set_title(title);ax.set_xlabel('新模型更新步数');ax.grid(alpha=.2);ax.legend(fontsize=8)
    fig.suptitle('全部16个开发窗口｜固定声明检查点｜旧参考容量/训练预算不同',fontsize=14);fig.savefig(folder/'development_curves.png',dpi=150);plt.close(fig)
    fig,axes=plt.subplots(2,3,figsize=(16,9),layout='constrained');mx=np.log1p(arrays['truth'][0,...,1][arrays['mask'][0]]).max()
    for side in range(2):
        for col,key in enumerate(['truth','source','ae']):
            q=np.log1p(arrays[key][0,:,side,:,1]);q=np.where(arrays['mask'][0,:,side],q,np.nan)
            im=axes[side,col].imshow(q.T,aspect='auto',origin='lower',extent=[1,256,1,2048],cmap='viridis',vmin=0,vmax=mx)
            axes[side,col].set_title(('买盘' if side==0 else '卖盘')+' · '+next(m['label'] for m in MODELS if m['key']==key));axes[side,col].set_xlabel('窗口内分钟');axes[side,col].set_ylabel('档位（1=最优档）')
    fig.colorbar(im,ax=axes,shrink=.75,label='log(1 + 挂量BTC)');fig.suptitle(f'第{step}步｜窗口1挂量演变｜相同色阶，全2048档',fontsize=15);fig.savefig(folder/'quantity_evolution.png',dpi=150);plt.close(fig)
    for w in range(3):
        fig,axes=plt.subplots(6,2,figsize=(15,18),layout='constrained')
        for row,t in enumerate(positions):
            valid=arrays['mask'][w,t];books=[arrays['truth'][w,t],arrays['ae'][w,t]]
            lo=min(a[...,0][valid].min() for a in books);hi=max(a[...,0][valid].max() for a in books);maxq=max(a[...,1][valid].max() for a in books);pad=max(.1,(hi-lo)*.025)
            for col,(book,label) in enumerate(zip(books,['真实订单簿','确定性AE'])):
                ax=axes[row,col]
                for side,color in [(0,'#15803d'),(1,'#dc2626')]:
                    v=valid[side];ax.vlines(book[side,v,0],0,book[side,v,1],color=color,lw=.65,alpha=.8,label='买盘' if side==0 else '卖盘')
                ax.set_xlim(lo-pad,hi+pad);ax.set_ylim(0,max(1,maxq*1.06));ax.set_title(f'第{t+1}分钟 · {mid_windows[w]["time"][t][11:19]} UTC · '+label,fontsize=10);ax.set_xlabel('实际价格 USDT');ax.set_ylabel('挂量 BTC');ax.grid(alpha=.15);ax.xaxis.set_major_formatter(ticker.StrMethodFormatter('{x:,.0f}'))
                if row==0:ax.legend(fontsize=8)
        fig.suptitle(f'第{step}步 · 窗口{w+1} · 固定六帧逐档挂单线｜真实与AE同坐标',fontsize=16);fig.savefig(folder/f'book_frames_window{w+1}.png',dpi=140);plt.close(fig)
    freeze_sources(folder/'source_snapshot')
    pointer=root/'public/interim';temp=root/'public/interim.tmp';temp.symlink_to(folder,target_is_directory=True);temp.replace(pointer)
    (output_root/'latest.json').write_text(json.dumps(dict(step=step,directory=str(folder),url=f'http://172.16.30.28:8875/recons/{output_root.name}/step{step}/'),indent=2))
    print(json.dumps(dict(directory=str(folder),step=step,records=records),ensure_ascii=False),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);main(p.parse_args().root)
