"""Reuse the fixed4096 experiment and change only the quantity objective."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

from train_dual.experiments.local_codebook_size_run import write
from util.model_sources import freeze_model_sources


def run(root,parent):
    root=root.resolve();parent=parent.resolve();root.mkdir(parents=True,exist_ok=False);started=time.monotonic()
    project=Path(__file__).resolve().parents[2];plan=json.loads((parent/'plan.json').read_text())
    for name in ['joint_pca_basis.pt','training_states.pt','development_states.pt','training_order.npy']:
        assert (parent/name).exists();(root/name).symlink_to(os.path.relpath(parent/name,root))
    for name in ['pca_fit.json','actual_shape_contract.json','preflight.json']:
        shutil.copy2(parent/name,root/name)
    hashes=freeze_model_sources(root/'source_snapshot',project_root=project)
    for directory in ('train_dual','util'):
        for file in (project/directory).rglob('*.py'):
            rel=file.relative_to(project);p=root/'source_snapshot'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(file,p);hashes[str(rel)]=hashlib.sha256(p.read_bytes()).hexdigest()
    write(root/'source_snapshot/sha256.json',hashes)
    plan.update(quantity_objective='squared_dice',dice_weight=1.,dice_epsilon=1e-6,
        initial_reference_parent=str(parent),comparison_parent=str(parent),source_hashes=hashes,
        only_changed_factor='Quantity objective: replace source volume_log/volume_linear/volume_tail terms with1.0continuous squared Dice; all price terms preserve their original weights.',
        dice_reduction='Per [batch,minute,side], reduce valid depth levels, then mean over valid rows. Prediction/target quantities remain continuous BTC amounts scaled by original q0, no binarization.',
        dice_formula='1-(2*sum(pred*target)+eps)/(sum(pred^2)+sum(target^2)+eps)',
        user_approved_scope='Dice supervises quantities only; original price supervision retained.')
    write(root/'plan.json',plan);write(root/'status.json',dict(state='training',quantity_objective='squared_dice',parent=str(parent)))
    env=dict(os.environ,PYTHONPATH=str(root/'source_snapshot'),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',MKL_NUM_THREADS='4')
    log=(root/'compressed4096.log').open('wb')
    p=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.joint4096_decoder_run',str(root),'--worker','compressed4096'],cwd=root/'source_snapshot',env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT);log.close()
    try:
        code=p.wait()
        if code!=0:raise RuntimeError(f'Dice decoder worker exited{code}')
        write(root/'status.json',dict(state='complete',steps=plan['steps'],elapsed_seconds=time.monotonic()-started))
    finally:
        if p.poll() is None:p.terminate();p.wait()


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--parent',type=Path,required=True);a=p.parse_args()
    try:run(a.root,a.parent)
    except BaseException as error:
        if a.root.exists():write(a.root/'failure.json',dict(error=repr(error)))
        raise
