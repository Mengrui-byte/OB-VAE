"""Matched-checkpoint task conflicts and complete16window price decomposition."""
import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import torch
import numpy as np
from model.losses.controlled_book import ControlledBookLoss
from train_dual.experiments.gradient_audit import add,cos,dot,flatnorm,mean_grad,price_component
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import freeze_sources,load_for_inference,seed_everything


def prepare(parent):
 parent=parent.resolve();project=Path(__file__).resolve().parents[2];plan=json.loads((parent/'plan.json').read_text());step=max(n for n in plan['checkpoints'] if all((parent/k/f'step{n}_evaluation.json').exists() for k in plan['lanes']));root=project/'recons'/('price_gradient_'+datetime.now().strftime('%Y%m%d_%H%M%S'));root.mkdir();(root/'data').mkdir()
 plan.update(parent=str(parent),audit_checkpoint_step=step,experiment='Currentquantityobjectives versuspricegradient:sharedEncoder andpricegeometry routes',scope='Read-only diagnostics atsamecompletedadditionalcheckpoint for4quantitylosscontrols. Fixed4trainingwindows forgradientcosines andfixed16developmentwindows forpriceerror decomposition. No model-training updates.')
 for name in ['train_indices.npy','val_indices.npy']:os.link(parent/name,root/name)
 os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz');old=Path(Path('/tmp/gradient_capacity_path').read_text().strip());np.testing.assert_array_equal(np.load(parent/'train_indices.npy'),np.load(old/'train_indices.npy'));os.link(old/'small_train.pt',root/'small_train.pt')
 hashes={}
 for k in plan['lanes']:
  source=parent/k/f'step{step}.pt';os.link(source,root/f'{k}.pt');hashes[k]=hashlib.sha256(source.read_bytes()).hexdigest()
 atomic_json(root/'plan.json',plan);atomic_json(root/'checkpoint_sha256.json',hashes);atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot')
 remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
 (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.price_gradient_conflict "{remote}"\n')
 Path('/tmp/price_gradient_path').write_text(str(root));print(root,flush=True)


def run(root):
 torch.set_num_threads(4);seed_everything(42);strict_precision();plan=json.loads((root/'plan.json').read_text());raw=torch.load(root/'small_train.pt',map_location='cpu',weights_only=False);ids=np.load(root/'val_indices.npy');val=dataset(root,'val');results={}
 atomic_json(root/'status.json',dict(state='auditing'))
 for lane,case in plan['lanes'].items():
  model,norm=load_for_inference(root/f'{lane}.pt','cuda:0');model.train();model.encoder.activation_checkpointing=False;model.price_decoder.spatial.activation_checkpointing=False;model.volume_decoder.spatial.activation_checkpointing=False;names,params=zip(*model.named_parameters());params=list(params);criterion=ControlledBookLoss(plan['normalization']['quantity_scale'],mode=case['mode'],**plan['objective']);batches=[norm.prepare({k:v[i:i+1] for k,v in raw.items()},'cuda:0') for i in range(4)]
  gps=[];gqs=[];individual=[];p0=q0=0.
  for i,b in enumerate(batches):
   o=call(model,b,False);lp=price_component(o,b);v=criterion(o,b);lq=v['loss']-lp
   gp=[g.detach().cpu() if g is not None else None for g in torch.autograd.grad(lp,params,allow_unused=True,retain_graph=True)];gq=[g.detach().cpu() if g is not None else None for g in torch.autograd.grad(lq,params,allow_unused=True)];gps.append(gp);gqs.append(gq);p0+=float(lp.detach())/4;q0+=float(lq.detach())/4
   ii=[i for i,n in enumerate(names) if n.startswith('encoder.')];individual.append(dict(window=i,encoder_cosine=cos([gp[i] for i in ii],[gq[i] for i in ii])));del o,lp,lq,v
  gp,gq=mean_grad(gps),mean_grad(gqs);groups={}
  for prefix in ['ALL','encoder','encoder.input_proj','encoder.frame','encoder.patch','encoder.mu','price_decoder','price_decoder.mid_spread','volume_decoder']:
   ii=[i for i,n in enumerate(names) if prefix=='ALL' or n.startswith(prefix+'.')];p=[gp[i] for i in ii];q=[gq[i] for i in ii];g=add(p,q);pn,qn=flatnorm(p),flatnorm(q)
   groups[prefix]=dict(price_gradient_l2=pn,quantity_gradient_l2=qn,cosine=cos(p,q),quantity_to_price_norm_ratio=qn/pn if pn>1e-25 else None,price_derivative_along_negative_total=-dot(p,g)/max(flatnorm(g),1e-30),price_derivative_along_negative_quantity=-dot(p,q)/max(qn,1e-30))
  # Falsifiable local prediction: only Encoder takes a small negativequantity step.
  ii=[i for i,n in enumerate(names) if n.startswith('encoder.')];qn=flatnorm([gq[i] for i in ii]);saved=[params[i].detach().clone() for i in ii]
  with torch.no_grad():
   for i in ii:
    if gq[i] is not None:params[i].add_(gq[i].to('cuda:0'),alpha=-.001/max(qn,1e-30))
   pa=qa=0.
   for b in batches:
    o=call(model,b,False);lp=price_component(o,b);v=criterion(o,b);pa+=float(lp)/4;qa+=float(v['loss']-lp)/4
   for i,p in zip(ii,saved):params[i].copy_(p)
  perturb=dict(scope='OnlyEncoder negativequantitygradient, parameterL2epsilon.001; not an actualAdamtrainingstep',price_before=p0,price_after=pa,quantity_before=q0,quantity_after=qa,predicted_first_order_price_delta=.001*groups['encoder']['price_derivative_along_negative_quantity'])
  del gps,gqs,gp,gq,params,saved;torch.cuda.empty_cache();model.eval();windows=[]
  with torch.inference_mode():
   for pos,index in enumerate(ids):
    item={k:v.unsqueeze(0) for k,v in val[int(index)].items()};b=norm.prepare(item,'cuda:0');o=call(model,b,False);pred=norm.inverse_price(o['price_norm'],b)[0].cpu().numpy();truth=item['data'][0,...,0].numpy().astype(np.float64);mask=b['mask'][0].cpu().numpy();mid=truth[:,:,0].mean(1);mh=pred[:,:,0].mean(1);dm=mh-mid;e=pred-truth;shape=e-dm[:,None,None];n=int(mask.sum());midse=float((dm**2*mask.sum((1,2))).sum());shapese=float((shape[mask]**2).sum());cross=float(2*(shape*dm[:,None,None])[mask].sum());se=float((e[mask]**2).sum());windows.append(dict(position=pos,index=int(index),valid=n,price_squared_error=se,price_rmse_usdt=(se/n)**.5,mid_squared_component=midse,shape_squared_component=shapese,cross_component=cross,mid_rmse_usdt=float(np.sqrt(np.mean(dm**2)))))
  n=sum(v['valid'] for v in windows);total=sum(v['price_squared_error'] for v in windows);decomposition=dict(price_rmse_usdt=(total/n)**.5,weighted_mid_rmse_usdt=(sum(v['mid_squared_component'] for v in windows)/n)**.5,relative_mid_shape_rmse_usdt=(sum(v['shape_squared_component'] for v in windows)/n)**.5,mid_mse_component=sum(v['mid_squared_component'] for v in windows)/n,shape_mse_component=sum(v['shape_squared_component'] for v in windows)/n,cross_mse_component=sum(v['cross_component'] for v in windows)/n,note='TotalMSE=midMSE+shapeMSE+crossMSE. Mid subtraction diagnostic only, not decodercondition.')
  results[lane]=dict(checkpoint_step=plan['audit_checkpoint_step'],groups=groups,training_windows=individual,encoder_quantity_only_step=perturb,development_decomposition=decomposition,development_windows=windows)
  atomic_json(root/'results.json',dict(scope=plan['scope'],results=results));print(lane,json.dumps(dict(encoder=groups['encoder'],encoder_step=perturb,decomposition=decomposition)),flush=True);del model;torch.cuda.empty_cache()
 atomic_json(root/'status.json',dict(state='complete'))

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');a=p.parse_args();prepare(a.root) if a.prepare else run(a.root)
