"""Price-frozen native logit readout: feature source x positive threshold loss."""
import argparse
from copy import deepcopy
import html
import os
from pathlib import Path
import time

import numpy as np
import torch

from model.autoencoder.logit_readout_vae import LogitReadoutOrderBookVAE
from model.layers.logit_readout import QuantityLogitReadout,add_quantity_logit
from train_dual.experiments.confirm_recall_goal import require_matching_replay
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.goal_evaluate import assess_file
from train_dual.experiments.local_quant_reconstruction import CacheWindows
from train_dual.experiments.long_worker import atomic_json,evaluate
from train_dual.experiments.phase_detail_report import read,STYLE
from train_dual.experiments.price_safe_readout import FROZEN,file_hash,head_criterion,price_replay
from train_dual.experiments.recall_goal_run import record
from train_dual.experiments.region_task_run import safe_preview
from train_dual.experiments.time_logit_run import write_profiles
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import atomic_save,freeze_sources,load_for_inference,source_hashes
from train_dual.util.hint_training import restore_logit_readout_adam
from train_dual.util.phase_training import tensor_digest


LABELS=dict(seed_control='局部16维·原损失',seed_logit='局部16维·阈值损失',frame_control='完整帧256维·原损失',frame_logit='完整帧256维·阈值损失')


def render(root):
    plan=read(root/'plan.json');progress=read(root/'progress.json',{})
    text='<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="30"><title>固定价格：逐档logit读出</title><style>'+STYLE+'</style><main><h1>局部16维 vs 完整帧256维：原生挂量logit残差</h1><p>完整256分钟×双侧2048档，唯一Gaussian64×128。价格安全来源骨干完全冻结，无Encoder跳接。局部/完整帧特征均来自同一Z的数量Decoder。逐档零初始化仿射修正原Softplus logit，形态和总量不再单独归一化。</p><p>控制因素：输入特征（局部16维/完整帧256维）×正例阈值损失（0/1）。共同来源、32个原训练窗、seed42、相同采样、FP32训练、学习率1e-3、batch2、2048次更新；空间上采样保持一致。参数数目分别69632和1052672，这个对比检验读出输入与容量的整体改变，不能单独归因于信息或参数量。</p><p>进度：'+str(progress.get('step',0))+'/2048；状态：'+html.escape(str(read(root/'status.json',{}).get('state')))+'</p><table><tr><th>组</th><th>步数</th><th>召回</th><th>精确率</th><th>价格RMSE</th><th>分钟变化RMSE</th><th>数量RMSE</th><th>联合通过</th></tr>'
    for lane,label in LABELS.items():
        for step in [0,*plan['checkpoints']]:
            p=root/lane/f'step{step}_development.json'
            if not p.exists():continue
            row=assess_file(p,root.parent/'reference_evaluation.json')
            values=[label,step,row['recall100'],row['precision100'],row['price_rmse'],row['mid_delta_rmse'],row['quantity_rmse'],row['pass']]
            text+='<tr>'+''.join('<td>'+html.escape(f'{v:.5f}' if isinstance(v,float) else str(v))+'</td>' for v in values)+'</tr>'
    text+='</table><p>固定16个Q1开发窗口已经反复用于选型，不是独立测试；Q2保留未读。训练缓存仅限原训练期；候选重新在GPU用完整模型编码与生成，并核对来源价格逐项重放。四组均通过相同预算后才比较。</p><p><a href="plan.json">协议</a> · <a href="cache_audit.json">实际完整窗口审计</a> · <a href="frozen_backbone_audit.json">冻结与Adam审计</a> · <a href="logs/run.log">运行日志</a></p></main>'
    (root/'index.html').write_text(text)


def prepare(goal):
    prior=goal/'price_safe_logit';old=read(prior/'plan.json')
    if read(prior/'status.json',{}).get('state')!='complete':raise ValueError('Finish the matched prior experiment first')
    project=Path(__file__).resolve().parents[2];root=goal/'price_safe_logit_readout';root.mkdir()
    for name in ['data','logs',*LABELS]:(root/name).mkdir()
    for name in ['source.pt','source_development.json','val_indices.npy','train_indices.npy','train_order.npy','plotly.min.js','calibration.json']:os.link(prior/name,root/name)
    os.link(prior/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    plan=dict(old);plan.update(experiment='Native ordered logit residual feature capacity x positive threshold loss',labels=LABELS,
        lanes={lane:dict(feature_source=lane.split('_')[0],positive_logit_weight=float(lane.endswith('logit'))) for lane in LABELS},
        positive_logit_study=True,steps=2048,checkpoints=[512,2048],max_train_seconds=10800,
        reuse_cache=False,training_device='cuda:0',training_dtype='float32',seed=42,
        source_control='Only decoder readout feature source/capacity and declared threshold-lossfactor vary;sourceNN frozen;same32windows/order/lr/budget/upsampling as prior. Sourcehintconstant omitted. NativefullGPU inference,sourceprice replay.',
        preview_descriptions={lane:'固定16个已用于研究的Q1开发窗口；完整256分钟、唯一8192Z。价格冻结，训练原生逐档挂量logit残差。非独立测试。' for lane in LABELS})
    for key in ['replay_controls','replay_control_root','readout_kernel']:plan.pop(key,None)
    assert file_hash(root/'source.pt')==plan['source_sha256']
    for name in ['train_indices.npy','train_order.npy','val_indices.npy']:
        assert file_hash(root/name)==file_hash(prior/name)
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot');render(root)
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 CUDA_VISIBLE_DEVICES=2 CUDA_DEVICE_ORDER=PCI_BUS_ID OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.price_safe_logit_readout "{remote}" --worker >> "{remote}/logs/run.log" 2>&1\n')
    record(goal,'price_safe_logit_readout_prepared',root=root.name,source=plan['source_selection'],factors='seed16/frame256 x positiveBCE0/1',seed=42,steps=2048)
    print(root,flush=True)


def make_model(payload,spec,device='cpu'):
    config=dict(payload['local_hint_config'],feature_source=spec['feature_source'])
    model=LogitReadoutOrderBookVAE(**config,**payload['unified_vae_config'])
    missing,extra=model.load_state_dict(payload['model'],strict=False)
    if missing!=['local_readout.weight','local_readout.bias'] or extra:raise ValueError('Source parameter order/family changed')
    return model.to(device).eval(),config


def cache_gpu(root):
    plan=read(root/'plan.json');started=time.monotonic();payload=torch.load(root/'source.pt',map_location='cpu',weights_only=False)
    assert file_hash(root/'source.pt')==plan['source_sha256']
    model,_=make_model(payload,dict(feature_source='frame'),'cuda:0');model.requires_grad_(False)
    source,norm=load_for_inference(root/'source.pt','cuda:0');source.eval();data=dataset(root,'train');cache=[];contracts=[]
    atomic_json(root/'status.json',dict(state='caching_training_features',pid=os.getpid()))
    for position,index in enumerate(np.load(root/'train_indices.npy')):
        raw={k:v.unsqueeze(0) for k,v in data[int(index)].items()};b=norm.prepare(raw,'cuda:0');start=int(data.base.starts[int(index)]);times=data.base.times[start:start+256]
        assert list(raw['data'].shape)==[1,256,2,2048,2] and len(times)==256 and np.all(np.diff(times//60_000_000)==1)
        seen=[];hooks=[d.register_forward_pre_hook(lambda m,a:seen.append(a[0])) for d in [model.price_decoder,model.volume_decoder]] if position==0 else []
        with torch.no_grad():out=call(model,b,False)
        assert all(list(out[k].shape)==[1,64,128] for k in ['mu','logvar','z'])
        assert list(out['price_norm'].shape)==list(out['volume'].shape)==[1,256,2,2048]
        torch.testing.assert_close(out['volume'],out['base_volume'],rtol=0,atol=0)
        if position==0:
            assert seen[0] is seen[1] is out['z']
            for hook in hooks:hook.remove()
            with torch.no_grad():reference=call(source,b,False)
            for key in ['volume','price_norm','mu','logvar','z']:torch.testing.assert_close(out[key],reference[key],rtol=0,atol=0)
            for feature_source in ['seed','frame']:
                fresh,_=make_model(payload,dict(feature_source=feature_source),'cuda:0')
                def forbid_encode(*args):raise AssertionError('Fresh decode used Encoder')
                h=fresh.encoder.register_forward_pre_hook(forbid_encode)
                with torch.no_grad():replay=fresh.decode(out['z'],b['mask'],b['tick_norm'],b['times'])
                h.remove()
                for key in ['volume','price_norm']:torch.testing.assert_close(out[key],replay[key],rtol=0,atol=0)
                del fresh
            sample_seen=[];sample_hooks=[d.register_forward_pre_hook(lambda m,a:sample_seen.append(a[0])) for d in [model.price_decoder,model.volume_decoder]]
            with torch.no_grad():sampled=call(model,b,True)
            for hook in sample_hooks:hook.remove()
            assert sample_seen[0] is sample_seen[1] is sampled['z']
            assert sampled['z'].shape==out['z'].shape and not torch.equal(sampled['z'],sampled['mu'])
        cache.append(dict(batch={k:b[k].detach().cpu() for k in ['price','volume','mask']},out={k:out[k].detach().cpu() for k in ['volume','quantity_logit','quantity_seed','quantity_frame','price_norm','mid_norm','mu','logvar']}))
        contracts.append(dict(index=int(index),input=[1,256,2,2048,2],posterior=[1,64,128],output=[1,256,2,2048],frame=[1,256,256],seed=[1,256,2,128,16],consecutive_minutes=True))
        atomic_json(root/'cache_progress.json',dict(windows=position+1,total=32,elapsed_seconds=time.monotonic()-started))
    atomic_save(cache,root/'train_cache.pt');dev=dataset(root,'val');selected=CacheWindows(dev,np.load(root/'val_indices.npy'))
    result=evaluate(model,norm,selected,len(selected),'cuda:0');require_matching_replay(result,read(root/'source_development.json')['result'])
    for lane in LABELS:atomic_json(root/lane/'step0_development.json',dict(result=result,scope='Actual GPU zerohead/source replay; both feature sources fresh Z-only decode.'))
    atomic_json(root/'cache_audit.json',dict(passed=True,contracts=contracts,unique_Z=True,source_zero_identity=True,fresh_Z_only_decode_both_sources=True,source16development_replay=True,cache_sha256=file_hash(root/'train_cache.pt'),source_sha256=file_hash(root/'source.pt'),optimizer_updates=0,training_dtype='float32',tf32_matmul=torch.backends.cuda.matmul.allow_tf32,tf32_cudnn=torch.backends.cudnn.allow_tf32))
    atomic_json(root/'cache_status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started));del source,model;torch.cuda.empty_cache()


def attach_head_optimizer(full,head,model):
    full.param_groups[2].update({k:deepcopy(v) for k,v in head.param_groups[0].items() if k!='params'})
    params=list(model.local_readout.parameters());source=head.param_groups[0]['params']
    if len(params)!=2 or len(source)!=2:raise ValueError('Unexpected logit head optimizer layout')
    for a,b in zip(params,source):
        if a.shape!=b.shape:raise ValueError('Readout moment shape changed')
        if b in head.state:full.state[a]={k:v.detach().cpu().clone() if torch.is_tensor(v) else deepcopy(v) for k,v in head.state[b].items()}


def predict(head,row,q0):
    out=dict(row['out']);delta=head(out['quantity_seed'],out['quantity_frame'])
    out['volume'],out['quantity_logit']=add_quantity_logit(out['quantity_logit'],delta,row['batch']['mask'],q0)
    return out


def evaluate_heads_on_cache(heads,cache,q0):
    rows={}
    with torch.no_grad():
        for lane,head in heads.items():
            tp=fp=fn=0;square=count=0.
            for row in cache:
                q=predict(head,row,q0)['volume'];target=row['batch']['volume'];mask=row['batch']['mask'];actual=mask&(target>=100);pred=mask&(q>=100)
                tp+=int((actual&pred).sum());fp+=int((~actual&pred).sum());fn+=int((actual&~pred).sum());square+=float(((q-target).square()*mask).sum());count+=int(mask.sum())
            rows[lane]=dict(tp=tp,fp=fp,fn=fn,recall=tp/max(1,tp+fn),precision=tp/max(1,tp+fp),quantity_rmse=(square/max(1,count))**.5,scope='Training32cachedsourcewindows,insampleonly')
    return rows


def evaluate_checkpoints(root,step):
    strict_precision();plan=read(root/'plan.json');dev=dataset(root,'val');selected=CacheWindows(dev,np.load(root/'val_indices.npy'));reference=read(root/'source_development.json')['result']
    atomic_json(root/'evaluation_status.json',dict(state='running',step=step,pid=os.getpid()))
    for lane in LABELS:
        model,norm=load_for_inference(root/lane/f'step{step}.pt','cuda:0');model.eval();result=evaluate(model,norm,selected,len(selected),'cuda:0');price_replay(result,reference)
        atomic_json(root/lane/f'step{step}_development.json',dict(result=result,scope=plan['evaluation_scope'],head_steps=step))
        write_profiles(root/lane,step,model,norm,selected,dev);safe_preview(root,lane,step);del model;torch.cuda.empty_cache();render(root)
    rows=[dict(lane=lane,step=step,checkpoint=str(root/lane/f'step{step}.pt'),evaluation=str(root/lane/f'step{step}_development.json'),**assess_file(root/lane/f'step{step}_development.json',root.parent/'reference_evaluation.json')) for lane in LABELS]
    atomic_json(root/f'common{step}_analysis.json',dict(rows=rows,source_price_replay_passed=True,independent_data_read=False))
    passing=[r for r in rows if r['pass']]
    if passing:atomic_json(root/'eligible_candidate.json',max(passing,key=lambda r:(r['recall100'],-r['price_rmse'])))
    atomic_json(root/'evaluation_status.json',dict(state='complete',step=step,pid=os.getpid()))


def worker(root):
    torch.set_num_threads(4);torch.manual_seed(42);strict_precision();started=time.monotonic();plan=read(root/'plan.json')
    if read(root/'status.json')['state']!='prepared':raise ValueError('Fresh worker only; inspect interrupted state before resuming')
    cache_gpu(root);payload=torch.load(root/'source.pt',map_location='cpu',weights_only=False);hashes=source_hashes();source_frozen={}
    cache=torch.load(root/'train_cache.pt',map_location='cpu',weights_only=False)
    if file_hash(root/'train_cache.pt')!=read(root/'cache_audit.json')['cache_sha256']:raise ValueError('Cache changed')
    cache=[{outer:{k:v.to('cuda:0') for k,v in block.items()} for outer,block in row.items()} for row in cache]
    q0=plan['normalization']['quantity_scale'];order=np.load(root/'train_order.npy')
    heads={lane:QuantityLogitReadout(feature_source=spec['feature_source']).cuda() for lane,spec in plan['lanes'].items()}
    optimizers={lane:torch.optim.AdamW(head.parameters(),lr=plan['learning_rate'],weight_decay=0.) for lane,head in heads.items()}
    objectives={lane:head_criterion(plan,read(root/'calibration.json'),spec) for lane,spec in plan['lanes'].items()}
    def save(lane,step):
        model,config=make_model(payload,plan['lanes'][lane]);model.local_readout.load_state_dict(heads[lane].state_dict())
        frozen={name:tensor_digest(model.get_submodule(name)) for name in FROZEN}
        if not source_frozen:source_frozen.update(frozen)
        assert frozen==source_frozen
        full=restore_logit_readout_adam(model,payload['optimizer'],plan['original_parameter_names']);attach_head_optimizer(full,optimizers[lane],model)
        for index,state in payload['optimizer']['state'].items():
            for key,value in state.items():
                actual=full.state_dict()['state'][index][key]
                assert torch.equal(value,actual) if torch.is_tensor(value) else value==actual
        atomic_save(dict(format_version=1,model=model.state_dict(),unified_vae_config=payload['unified_vae_config'],logit_readout_config=config,local_hint_config=payload['local_hint_config'],config=payload['config'],step=step,
            source_steps=plan['source_steps'],lane=lane,phase='head_only_price_frozen',backbone_optimizer_updates=0,head_optimizer_calls=step,head_training_indices=np.load(root/'train_indices.npy'),
            optimizer=full.state_dict(),frozen_module_hashes=frozen,source_hashes=hashes,training_data=payload['training_data'],
            training_data_scope='Inherited backbone exposures unchanged; head exposures separately recorded',head_training_data=dict(windows=32,exposures=2*step,epochs_equivalent=2*step/32),head_loss_variant=plan['lanes'][lane],hint_loss_config=read(root/'calibration.json')),root/lane/f'step{step}.pt')
    for lane in LABELS:save(lane,0)
    atomic_json(root/'train_cache_step0.json',evaluate_heads_on_cache(heads,cache,q0))
    atomic_json(root/'status.json',dict(state='GPU_head_training',pid=os.getpid()))
    for step in range(1,plan['steps']+1):
        if time.monotonic()-started>plan['max_train_seconds']:raise TimeoutError('Declared 3hour cohort ceiling')
        losses={}
        for lane,head in heads.items():
            opt=optimizers[lane];opt.zero_grad(set_to_none=True);value=0.
            for micro in range(2):
                row=cache[int(order[((step-1)*2+micro)%len(order)])];out=predict(head,row,q0);loss=objectives[lane](out,row['batch'])['loss'];assert bool(torch.isfinite(loss));(loss/2).backward();value+=float(loss.detach())/2
            torch.nn.utils.clip_grad_norm_(head.parameters(),plan['clip_grad'],error_if_nonfinite=True);opt.step();losses[lane]=value
        if step==1 or step%8==0:
            atomic_json(root/'progress.json',dict(step=step,total=plan['steps'],losses=losses,elapsed_seconds=time.monotonic()-started,pid=os.getpid(),device='cuda:0',dtype='float32'));render(root)
        if step in plan['checkpoints']:
            for lane in LABELS:save(lane,step)
            atomic_json(root/f'train_cache_step{step}.json',evaluate_heads_on_cache(heads,cache,q0));evaluate_checkpoints(root,step)
    assert file_hash(root/'source.pt')==plan['source_sha256']
    atomic_json(root/'frozen_backbone_audit.json',dict(passed=True,module_hashes=source_frozen,source_weights_and_Adam_unchanged=True,backbone_updates=0))
    atomic_json(root/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started,goal_automatically_completed=False));render(root)
    record(root.parent,'price_safe_logit_readout_complete',root=root.name,steps=plan['steps'],independent_confirmation_data_read=False)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--worker',action='store_true');args=p.parse_args();root=args.root.resolve()
    try:
        if args.prepare:prepare(root)
        elif args.worker:worker(root)
    except BaseException as error:
        if not args.prepare:atomic_json(root/'status.json',dict(state='failed',error=repr(error),pid=os.getpid()))
        raise
