"""Native head-only fitting from a price-safe checkpoint; full GPU evaluation."""
import argparse
from copy import deepcopy
import hashlib
import html
import math
import os
from pathlib import Path
import time

import numpy as np
import torch

from model.autoencoder.regional_phase_vae import RegionalPhaseOrderBookVAE
from model.layers.regional_linear import RegionalLinearPhaseReadout
from model.losses.recall_guard import RecallGuardBookLoss
from model.losses.large_logit import LargeLogitBookLoss
from train_dual.experiments.confirm_recall_goal import require_matching_replay
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.goal_evaluate import assess_file
from train_dual.experiments.local_phase_run import LABELS,SWITCHES
from train_dual.experiments.local_quant_reconstruction import CacheWindows
from train_dual.experiments.long_worker import atomic_json,evaluate
from train_dual.experiments.phase_detail_report import read,STYLE
from train_dual.experiments.region_task_run import safe_preview
from train_dual.experiments.time_logit_run import write_profiles
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import atomic_save,freeze_sources,load_for_inference,source_hashes
from train_dual.util.hint_training import restore_regional_phase_adam
from train_dual.util.phase_training import tensor_digest


FROZEN=('encoder','price_decoder','volume_decoder','hint_adapter')


def file_hash(path):
    value=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(4*1024*1024),b''):value.update(block)
    return value.hexdigest()


def price_replay(result,reference):
    if result['windows']!=reference['windows'] or result['window_indices']!=reference['window_indices']:
        raise ValueError('Different development windows')
    for key in ['price_usdt','temporal_mid_1_minutes_usdt_per_minute']:
        if not math.isclose(result['metrics'][key]['rmse'],reference['metrics'][key]['rmse'],rel_tol=1e-7,abs_tol=1e-8):
            raise ValueError('Frozen price prediction changed: '+key)


def head_criterion(plan,cal,spec=None):
    loss_type=LargeLogitBookLoss if plan.get('positive_logit_study') else RecallGuardBookLoss
    extra=dict(positive_logit_weight=(spec or {}).get('positive_logit_weight',0.)) if plan.get('positive_logit_study') else {}
    return loss_type(plan['normalization']['quantity_scale'],mode='shape_mass',use_hint=False,
        use_tail=True,protect_mid=True,tail_weight=cal['tail_weight'],mid_weight=cal['mid_weight'],
        mid_delta_weight=plan['fixed_mid_delta_weight'],**extra,**plan['source_FP_rule'],**plan['objective'])


def attach_head_optimizer(full_optimizer,head_optimizer,model):
    """Copy four local Adam states without advancing the source two groups."""
    target=full_optimizer.param_groups[2]
    target.update({k:deepcopy(v) for k,v in head_optimizer.param_groups[0].items() if k!='params'})
    params=list(model.local_readout.parameters());source=list(head_optimizer.param_groups[0]['params'])
    if len(params)!=4 or len(source)!=4:raise ValueError('Unexpected readout optimizer layout')
    for a,b in zip(params,source):
        if a.shape!=b.shape:raise ValueError('Readout moment mapping mismatch')
        if b in head_optimizer.state:full_optimizer.state[a]=deepcopy(head_optimizer.state[b])


def render(root):
    plan=read(root/'plan.json');progress=read(root/'train_progress.json',{})
    text='<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="30"><title>价格安全来源的原生读出训练</title><style>'+STYLE+'</style><main><h1>保留价格：分区域形状 × 总量头训练</h1><p>冻结来源Encoder、价格/挂量基础Decoder及hint_adapter，仅训练36992个post-Z区域参数。输入仍为完整256分钟×双侧2048档、唯一64×128 Gaussian，无Encoder跳接。四组共用32个既有训练窗、零初始化、seed42、固定采样、学习率1e-3、2048次头部更新及同一数量损失。来源已通过价格门槛，但尚未满足召回/精确率。</p><p>训练进度：'+html.escape(str(progress.get('step',0)))+'/2048。缓存只用于冻结特征训练；下表重新用完整模型在GPU上推理固定16个Q1开发窗口。开发集已反复用于研究，不是独立测试。教师hint对新头为常数，省略后梯度不变。基础价格参数与原Adam状态保持不变，评估必须重放来源价格。</p><table><tr><th>组</th><th>头部步数</th><th>召回</th><th>精确率</th><th>价格RMSE</th><th>分钟变化RMSE</th><th>通过联合门槛</th></tr>'
    if plan.get('positive_logit_study'):text+='<p>本轮因素为正例log挂量阈值BCE（权重0/1）×总量头（关/开），形状头始终开启。没有新分类头，分数直接由最终预测挂量计算；无损失组需精确重放上一轮形状/组合控制。</p>'
    for lane in plan['labels']:
        for step in [0,*plan['checkpoints']]:
            p=root/lane/f'step{step}_development.json'
            if not p.exists():continue
            row=assess_file(p,root.parent/'reference_evaluation.json')
            values=[plan['labels'][lane],step,row['recall100'],row['precision100'],row['price_rmse'],row['mid_delta_rmse'],row['pass']]
            text+='<tr>'+''.join('<td>'+html.escape(f'{v:.5f}' if isinstance(v,float) else str(v))+'</td>' for v in values)+'</tr>'
    text+='</table><p>固定骨干不等于目标达标；所有候选仍需完整8192/单Z审计与冻结后的独立确认。本实验不改变正在运行的四卡实验及后续同源控制协议。</p><p><a href="plan.json">协议</a> · <a href="cache_status.json">GPU缓存与初始重放</a> · <a href="train_status.json">头部训练</a> · <a href="evaluation_status.json">完整模型GPU评估</a></p></main>'
    (root/'index.html').write_text(text)


def prepare(goal,positive_logit=False):
    selected=read(goal/'first_price_safe_development.json')['checkpoint'];project=Path(__file__).resolve().parents[2]
    source=(project/selected['checkpoint']).resolve() if not Path(selected['checkpoint']).is_absolute() else Path(selected['checkpoint'])
    parent=source.parent.parent;old=read(parent/'plan.json');verdict=assess_file(source.with_name(source.stem+'_development.json'),goal/'reference_evaluation.json')
    if verdict['price_rmse']>verdict['price_limit'] or verdict['mid_delta_rmse']>verdict['mid_delta_limit']:raise ValueError('Source is not price-safe')
    labels=(dict(shape_control='形状·原损失',shape_logit='形状·阈值BCE',both_control='形状＋总量·原损失',both_logit='形状＋总量·阈值BCE') if positive_logit else LABELS)
    specs=({lane:dict(use_shape=True,use_mass=lane.startswith('both'),positive_logit_weight=1. if lane.endswith('logit') else 0.) for lane in labels} if positive_logit else {lane:dict(use_shape=shape,use_mass=mass) for lane,(shape,mass) in SWITCHES.items()})
    root=goal/('price_safe_logit' if positive_logit else 'price_safe_readout');root.mkdir()
    for name in ['data','logs',*labels]:(root/name).mkdir()
    os.link(source,root/'source.pt');os.link(source.with_name(source.stem+'_development.json'),root/'source_development.json')
    for name in ['val_indices.npy','plotly.min.js','calibration.json']:os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    original=np.load(parent/'train_indices.npy');indices=original[np.unique(np.linspace(0,len(original)-1,32,dtype=int))]
    assert len(indices)==32;np.save(root/'train_indices.npy',indices)
    order=np.random.default_rng(42).permutation(32);np.save(root/'train_order.npy',order)
    source_payload=torch.load(source,map_location='cpu',weights_only=False)
    plan=dict(old);plan.update(experiment='Price-safe native regional head-only adaptation',labels=labels,positive_logit_study=positive_logit,
        lanes=specs,
        source_selection=selected,source=str(root/'source.pt'),source_sha256=file_hash(source),
        source_steps=source_payload['source_steps']+source_payload['step'],fixed_mid_delta_weight=old['lanes'][selected['lane']]['mid_delta_weight'],
        steps=2048,checkpoints=[512,2048],learning_rate=.001,weight_decay=0.,clip_grad=1.,cache_batch_windows=2,
        max_train_seconds=7200,max_watch_seconds=10800,seed=42,goal_root=str(goal),train_windows=32,readout_kernel='linear',
        source_control='Same source and36992zeroheads in4arms;bodyfrozen,cached32originaltrainingwindows,noaugmentation,noFutureReturns,noQ2. Sourcehintconstant omitted. Fixed shuffled32window cycle;2048headoptimizer calls.',
        evaluation_scope='Fresh full-model GPU inference on fixed16Q1development windows, already repeatedly used for research. No independent data read.',
        preview_descriptions={lane:'固定16个已用于研究的2025Q1开发窗口；完整256分钟、唯一8192原生Z。冻结价格安全骨干，只训练分区域挂量头。非独立测试。' for lane in labels})
    if positive_logit:
        previous=goal/'price_safe_readout'
        if read(previous/'status.json',{}).get('state')!='complete':raise ValueError('Finish the original matched controls before the new loss study')
        prior=read(previous/'plan.json')
        for key in ['source_sha256','normalization','objective','source_FP_rule','fixed_mid_delta_weight','steps','learning_rate','weight_decay','clip_grad']:
            if prior[key]!=plan[key]:raise ValueError('Changed control '+key)
        for name in ['train_indices.npy','train_order.npy','val_indices.npy']:
            if file_hash(root/name)!=file_hash(previous/name):raise ValueError('Changed data/order '+name)
        for name in ['train_cache.pt','initial.pt']:os.link(previous/name,root/name)
        audit=read(previous/'cache_audit.json')
        if not audit['passed'] or file_hash(root/'train_cache.pt')!=audit['cache_sha256']:raise ValueError('Changed cached features')
        atomic_json(root/'cache_audit.json',dict(audit,inherited_from=str(previous),cache_recomputed=False))
        atomic_json(root/'cache_status.json',dict(state='complete',scope='Byteidentical training-only source cache reused'))
        baseline=read(root/'source_development.json')['result']
        for lane in labels:atomic_json(root/lane/'step0_development.json',dict(result=baseline,scope='Identical source/zeroheads; prior actual GPU all-flags identity and source replay inherited.'))
        plan.update(reuse_cache=True,replay_control_root=str(previous),replay_controls=dict(shape_control='shape',both_control='both'),
            source_control='Positive logquantity threshold BCE0vs1 × massoff/on;shapealwayson.Same prior32cache/source/data/order/lr2048headbudget;prior shape/both controls replayed. No new model parameter, future label, negative loss or upsampling change.')
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot');render(root)
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'gpu_run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 CUDA_VISIBLE_DEVICES=2 CUDA_DEVICE_ORDER=PCI_BUS_ID OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.price_safe_readout "{remote}" --gpu-controller >> "{remote}/logs/gpu.log" 2>&1\n')
    print(root,flush=True)


def make_model(payload,spec,device='cpu'):
    config=dict(payload['local_hint_config'],readout_kernel='linear',use_shape=spec['use_shape'],use_mass=spec['use_mass'])
    model=RegionalPhaseOrderBookVAE(**config,**payload['unified_vae_config'])
    missing,extra=model.load_state_dict(payload['model'],strict=False)
    if missing!=['local_readout.shape_weight','local_readout.shape_bias','local_readout.mass_weight','local_readout.mass_bias'] or extra:raise ValueError('Source family/order mismatch')
    return model.to(device).eval(),config


def cache_gpu(root):
    torch.set_num_threads(4);strict_precision();plan=read(root/'plan.json');started=time.monotonic()
    atomic_json(root/'cache_status.json',dict(state='running',pid=os.getpid()));payload=torch.load(root/'source.pt',map_location='cpu',weights_only=False)
    model,config=make_model(payload,dict(use_shape=True,use_mass=True),'cuda:0');_,norm=load_for_inference(root/'source.pt','cuda:0')
    model.requires_grad_(False);data=dataset(root,'train');indices=np.load(root/'train_indices.npy');cache=[];contracts=[]
    for position,index in enumerate(indices):
        raw={k:v.unsqueeze(0) for k,v in data[int(index)].items()};b=norm.prepare(raw,'cuda:0');start=int(data.base.starts[int(index)]);times=data.base.times[start:start+256]
        assert list(raw['data'].shape)==[1,256,2,2048,2] and len(times)==256 and np.all(np.diff(times//60_000_000)==1)
        seen=[]
        hooks=[d.register_forward_pre_hook(lambda m,a:seen.append(a[0])) for d in [model.price_decoder,model.volume_decoder]] if position==0 else []
        with torch.no_grad():out=call(model,b,False)
        if position==0:
            assert seen[0] is seen[1] is out['z']
            for hook in hooks:hook.remove()
        assert all(list(out[k].shape)==[1,64,128] for k in ['mu','logvar','z'])
        assert list(out['price_norm'].shape)==list(out['volume'].shape)==[1,256,2,2048]
        torch.testing.assert_close(out['volume'],out['base_volume'],rtol=0,atol=0)
        if position==0:
            with torch.no_grad():
                for shape,mass in SWITCHES.values():
                    model.use_shape,model.use_mass=shape,mass;replay=model.decode(out['z'],b['mask'],b['tick_norm'],b['times'])
                    for key in ['price_norm','volume']:torch.testing.assert_close(replay[key],out[key],rtol=0,atol=0)
            model.use_shape=model.use_mass=True
        cache.append(dict(batch={k:b[k].detach().cpu() for k in ['price','volume','mask']},out={k:out[k].detach().cpu() for k in ['volume','quantity_seed','price_norm','mid_norm','mu','logvar']}))
        contracts.append(dict(index=int(index),input=[1,256,2,2048,2],z=[1,64,128],output=[1,256,2,2048],consecutive_minutes=True))
        atomic_json(root/'cache_progress.json',dict(windows=position+1,total=32,elapsed_seconds=time.monotonic()-started))
    atomic_save(cache,root/'train_cache.pt')
    atomic_save(dict(format_version=1,model={k:v.detach().cpu() for k,v in model.state_dict().items()},unified_vae_config=payload['unified_vae_config'],regional_phase_config=config,local_hint_config=payload['local_hint_config'],config=payload['config']),root/'initial.pt')
    dev=dataset(root,'val');selected=CacheWindows(dev,np.load(root/'val_indices.npy'))
    result=evaluate(model,norm,selected,len(selected),'cuda:0');require_matching_replay(result,read(root/'source_development.json')['result'])
    for lane in plan['labels']:atomic_json(root/lane/'step0_development.json',dict(result=result,scope='Zerohead identity verified for all flags on actual full window; common source evaluation.'))
    atomic_json(root/'cache_audit.json',dict(passed=True,contracts=contracts,unique_Z=True,all_four_zero_flags_exact=True,source16development_replay=True,optimizer_updates=0,cache_sha256=file_hash(root/'train_cache.pt')))
    atomic_json(root/'cache_status.json',dict(state='complete',pid=os.getpid(),elapsed_seconds=time.monotonic()-started));render(root)


def train(root):
    torch.set_num_threads(8);torch.manual_seed(42);plan=read(root/'plan.json');started=time.monotonic()
    if read(root/'cache_status.json',{}).get('state')!='complete':raise ValueError('Need completed GPU cache/replay')
    if file_hash(root/'train_cache.pt')!=read(root/'cache_audit.json')['cache_sha256']:raise ValueError('Cache bytes changed')
    cache=torch.load(root/'train_cache.pt',map_location='cpu',weights_only=False);order=np.load(root/'train_order.npy')
    labels=plan['labels'];objectives={lane:head_criterion(plan,read(root/'calibration.json'),plan['lanes'][lane]) for lane in labels};heads={lane:RegionalLinearPhaseReadout() for lane in labels}
    optimizers={lane:torch.optim.AdamW(head.parameters(),lr=plan['learning_rate'],weight_decay=0.) for lane,head in heads.items()}
    payload=torch.load(root/'source.pt',map_location='cpu',weights_only=False);hashes=source_hashes();frozen_source={}
    atomic_json(root/'train_status.json',dict(state='running',pid=os.getpid()));atomic_json(root/'status.json',dict(state='head_training'))
    def save(lane,step):
        model,config=make_model(payload,plan['lanes'][lane]);model.local_readout.load_state_dict(heads[lane].state_dict())
        frozen={name:tensor_digest(model.get_submodule(name)) for name in FROZEN}
        if not frozen_source:frozen_source.update(frozen)
        assert frozen==frozen_source
        previous_lane=plan.get('replay_controls',{}).get(lane)
        if previous_lane:
            previous=torch.load(Path(plan['replay_control_root'])/previous_lane/f'step{step}.pt',map_location='cpu',weights_only=False)
            for name,value in model.local_readout.state_dict().items():torch.testing.assert_close(value,previous['model']['local_readout.'+name],rtol=0,atol=0)
        full=restore_regional_phase_adam(model,payload['optimizer'],plan['original_parameter_names']);attach_head_optimizer(full,optimizers[lane],model)
        for index,state in payload['optimizer']['state'].items():
            actual=full.state_dict()['state'][index]
            for key,value in state.items():assert torch.equal(value,actual[key]) if isinstance(value,torch.Tensor) else value==actual[key]
        atomic_save(dict(format_version=1,model=model.state_dict(),unified_vae_config=payload['unified_vae_config'],regional_phase_config=config,local_hint_config=payload['local_hint_config'],config=payload['config'],
            step=step,source_steps=plan['source_steps'],lane=lane,phase='head_only_price_frozen',backbone_optimizer_updates=0,head_optimizer_calls=step,
            head_training_indices=np.load(root/'train_indices.npy'),optimizer=full.state_dict(),frozen_module_hashes=frozen,source_hashes=hashes,
            training_data=payload['training_data'],training_data_scope='Inherited backbone exposures unchanged; head exposures are separately recorded',
            head_training_data=dict(windows=32,exposures=2*step,epochs_equivalent=2*step/32),head_loss_variant=plan['lanes'][lane],hint_loss_config=read(root/'calibration.json')),root/lane/f'step{step}.pt')
    for lane in labels:save(lane,0)
    for step in range(1,plan['steps']+1):
        if time.monotonic()-started>plan['max_train_seconds']:raise TimeoutError('Declared head-fitting ceiling')
        losses={}
        for lane,head in heads.items():
            opt=optimizers[lane];opt.zero_grad(set_to_none=True);spec=plan['lanes'][lane];enabled=spec['use_shape'] or spec['use_mass'];losses[lane]=0.
            for micro in range(2):
                row=cache[int(order[((step-1)*2+micro)%len(order)])];out=dict(row['out']);out['volume']=head(out['volume'],out['quantity_seed'],row['batch']['mask'],use_shape=spec['use_shape'],use_mass=spec['use_mass'])
                loss=objectives[lane](out,row['batch'])['loss'];assert bool(torch.isfinite(loss));losses[lane]+=float(loss.detach())/2
                if enabled:(loss/2).backward()
            torch.nn.utils.clip_grad_norm_(head.parameters(),plan['clip_grad'],error_if_nonfinite=True);opt.step()
        if step==1 or step%8==0:
            atomic_json(root/'train_progress.json',dict(step=step,total=plan['steps'],losses=losses,elapsed_seconds=time.monotonic()-started));render(root)
        if step in plan['checkpoints']:
            for lane in labels:save(lane,step)
            atomic_json(root/f'checkpoint{step}_ready.json',dict(complete=True,lanes=list(labels)))
    assert file_hash(root/'source.pt')==plan['source_sha256']
    atomic_json(root/'frozen_backbone_audit.json',dict(passed=True,module_hashes=frozen_source,source_weights_and_Adam_unchanged=True,backbone_updates=0))
    atomic_json(root/'train_status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started));atomic_json(root/'status.json',dict(state='training_complete_evaluation_pending'))


def gpu_controller(root):
    torch.set_num_threads(4);strict_precision()
    plan=read(root/'plan.json')
    if not plan.get('reuse_cache'):cache_gpu(root)
    torch.cuda.empty_cache();started=time.monotonic();dev=dataset(root,'val');selected=CacheWindows(dev,np.load(root/'val_indices.npy'))
    source=read(root/'source_development.json')['result']
    for step in plan['checkpoints']:
        while not (root/f'checkpoint{step}_ready.json').exists():
            if read(root/'train_status.json',{}).get('state')=='failed':raise RuntimeError('Head fitting failed')
            if time.monotonic()-started>plan['max_watch_seconds']:raise TimeoutError('Head-evaluation watch ceiling')
            atomic_json(root/'evaluation_status.json',dict(state='verified_wait_head_checkpoint',pid=os.getpid(),step=step));time.sleep(5)
        atomic_json(root/'evaluation_status.json',dict(state='evaluating_full_models',pid=os.getpid(),step=step))
        for lane in plan['labels']:
            model,norm=load_for_inference(root/lane/f'step{step}.pt','cuda:0');model.eval()
            result=evaluate(model,norm,selected,len(selected),'cuda:0');price_replay(result,source)
            atomic_json(root/lane/f'step{step}_development.json',dict(result=result,head_steps=step,scope=plan['evaluation_scope']))
            write_profiles(root/lane,step,model,norm,selected,dev);safe_preview(root,lane,step)
            del model;torch.cuda.empty_cache();render(root)
        rows=[dict(lane=lane,step=step,checkpoint=str(root/lane/f'step{step}.pt'),evaluation=str(root/lane/f'step{step}_development.json'),**assess_file(root/lane/f'step{step}_development.json',root.parent/'reference_evaluation.json')) for lane in plan['labels']]
        atomic_json(root/f'common{step}_analysis.json',dict(rows=rows,price_source_replay_passed=True,independent_data_read=False))
        passing=[r for r in rows if r['pass']]
        if passing:
            chosen=max(passing,key=lambda r:(r['recall100'],-r['price_rmse']));previous=read(root/'eligible_candidate.json')
            if previous is None or chosen['recall100']>=previous['recall100']:atomic_json(root/'eligible_candidate.json',chosen)
    while read(root/'train_status.json',{}).get('state')!='complete':time.sleep(1)
    atomic_json(root/'evaluation_status.json',dict(state='complete',pid=os.getpid()));atomic_json(root/'status.json',dict(state='complete',goal_automatically_completed=False));render(root)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--positive-logit',action='store_true');p.add_argument('--train',action='store_true');p.add_argument('--gpu-controller',action='store_true');a=p.parse_args();root=a.root.resolve()
    try:
        if a.prepare:prepare(root,a.positive_logit)
        elif a.train:train(root)
        elif a.gpu_controller:gpu_controller(root)
    except BaseException as error:
        if not a.prepare:
            role='train_status.json' if a.train else 'cache_status.json' if read(root/'cache_status.json',{}).get('state')!='complete' else 'evaluation_status.json'
            atomic_json(root/role,dict(state='failed',error=repr(error)));atomic_json(root/'status.json',dict(state='failed',error=repr(error)))
        raise
