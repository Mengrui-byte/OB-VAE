"""Read-only completed control/augmentation response on an otherwise idle GPU4."""
import argparse
import hashlib
import html
import json
import os
from pathlib import Path
import time

import numpy as np
import torch

from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read,fmt,STYLE
from train_dual.experiments.region_task_run import gpu_free
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import freeze_sources,load_for_inference


def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(4*1024*1024),b''):h.update(block)
    return h.hexdigest()


def render(root):
    status=read(root/'status.json',{});rows=read(root/'results.json',{}).get('records',[])
    text=f'<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="30"><title>8192步局部输入响应</title><style>{STYLE}</style><main><h1>已完成两组：局部大单输入响应</h1><p>状态：{html.escape(status.get("state","prepared"))}。这是已知输入干预诊断，不是模型训练或独立测试。GPU4空闲后只读运行，不影响仍在训练的两组。</p><p>固定沿用此前预选4个seen、4个student-unseen训练年代窗口；对每窗最大挂量交换17档、加倍、清除。价格与mask保持不变。增益1表示指定位置增量完全恢复，0表示没有响应；不把少量样本推广为整体能力。</p>'
    text+='<table><tr><th>模型</th><th>窗口类</th><th>操作</th><th>N</th><th>原位增益中位数</th><th>目的位增益中位数</th><th>全窗价格响应RMSE中位数</th></tr>'
    groups={}
    for r in rows:groups.setdefault((r['model'],r['split'],r['mode']),[]).append(r)
    for (model,split,mode),items in groups.items():
        def med(i):
            values=[x['positions'][i]['gain'] for x in items if x['positions'][i]['gain'] is not None]
            return float(np.median(values)) if values else None
        values=[model,split,mode,len(items),fmt(med(0)),fmt(med(1)) if mode=='swap' else '—',fmt(float(np.median([x['price_response_rmse_usdt'] for x in items])))]
        text+='<tr>'+''.join(f'<td>{html.escape(str(v))}</td>' for v in values)+'</tr>'
    text+='</table><p><a href="results.json">逐次量价响应</a> · <a href="selection.json">固定选择</a> · <a href="source_audit.json">实际执行源码</a> · <a href="../">研究目标</a></p></main>'
    temp=root/'index.tmp';temp.write_text(text);temp.replace(root/'index.html')


def prepare(goal):
    parent=goal.parent/read(goal/'contract.json')['predecessor'];root=goal/'early_native_response_8192';root.mkdir()
    for lane in ['control','augmentation']:
        if read(parent/lane/'status.json')['state']!='complete':raise ValueError('Need finished matched8192 controls')
    for name in ['data','logs']:(root/name).mkdir()
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    atomic_json(root/'plan.json',dict(read(parent/'plan.json'),parent_name=parent.name,models=['control','augmentation'],endpoint=8192,max_seconds=600,
        scope='Finishedsamebudgetcontrolversusaugmentation,read-only8windowinterventions. Other2x2armsnotfinished;noearlyfullfactorialconclusion/noQ2.'))
    (root/'selection.json').write_bytes((parent/'response_after/selection.json').read_bytes())
    atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot');render(root)
    project=Path(__file__).resolve().parents[2];remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e');rr=remote/root.relative_to(project);rp=remote/parent.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{rp}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=4 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\ncd "{rp}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u "{rr}/source_snapshot/train_dual/experiments/early_endpoint_response.py" "{rr}"\n')
    print(root,flush=True)


def run(root):
    torch.set_num_threads(4);strict_precision();plan=read(root/'plan.json');parent=root.parent.parent/plan['parent_name'];selection=read(root/'selection.json');started=time.monotonic();records=[];audits={}
    if gpu_free().get(4,0)<47000:raise RuntimeError('GPU4 must be idle; no jobs displaced')
    data=dataset(root,'train')
    for lane in plan['models']:
        path=parent/lane/f'step{plan["endpoint"]}.pt';payload=torch.load(path,map_location='cpu',weights_only=False)
        assert payload['step']==8192
        for name,h in payload['source_hashes'].items():
            if digest(parent/'source_snapshot'/name)!=h:raise ValueError(f'Snapshot changed: {name}')
        model,norm=load_for_inference(path,'cuda:0');model.eval();audits[lane]=dict(checkpoint=str(path),sha256=digest(path),source_snapshot=str(parent/'source_snapshot'),model_class=type(model).__module__+'.'+type(model).__name__,model_file=__import__('inspect').getfile(type(model)))
        assert Path(audits[lane]['model_file']).is_relative_to(parent/'source_snapshot')
        atomic_json(root/'source_audit.json',dict(passed=True,models=audits))
        def reconstruct(item):
            b=norm.prepare({k:v.unsqueeze(0) for k,v in item.items()},'cuda:0')
            with torch.inference_mode():
                out=call(model,b,False)
                assert list(out['z'].shape)==[1,64,128]
                return out['volume'][0].cpu(),norm.inverse_price(out['price_norm'],b)[0].cpu()
        for split,indices in selection['indices'].items():
            for index in indices:
                item=data[int(index)];assert list(item['data'].shape)==[256,2,2048,2]
                base,base_p=reconstruct(item);q=item['data'][...,1];valid=torch.arange(2048)<item['level_counts'][...,None]
                t,side,rank=np.unravel_index(int(q.masked_fill(~valid,-torch.inf).argmax()),q.shape);n=int(item['level_counts'][t,side]);destination=(int(rank)+17)%n
                for mode in ['swap','double','erase']:
                    if time.monotonic()-started>plan['max_seconds']:raise TimeoutError('10minute read-only ceiling')
                    changed={k:v.clone() for k,v in item.items()};d=changed['data']
                    if mode=='swap':d[t,side,rank,1],d[t,side,destination,1]=q[t,side,destination].clone(),q[t,side,rank].clone()
                    elif mode=='double':d[t,side,rank,1]*=2
                    else:d[t,side,rank,1]=0
                    torch.testing.assert_close(d[...,0],item['data'][...,0],rtol=0,atol=0)
                    assert torch.equal(changed['level_counts'],item['level_counts']) and bool((d[...,1]>=0).all())
                    pred,price=reconstruct(changed);delta=pred-base;target=d[...,1]-q;positions=[]
                    for level in [int(rank),int(destination)]:
                        td=float(target[t,side,level]);pd=float(delta[t,side,level])
                        positions.append(dict(level=level,true_before=float(q[t,side,level]),true_after=float(d[t,side,level,1]),prediction_before=float(base[t,side,level]),prediction_after=float(pred[t,side,level]),target_delta=td,predicted_delta=pd,gain=pd/td if td else None))
                    price_rmse=float((price-base_p)[valid].square().mean().sqrt())
                    records.append(dict(model=lane,split=split,source_index=int(index),time=int(t),side=int(side),mode=mode,positions=positions,price_response_rmse_usdt=price_rmse,prediction_delta_l1=float(delta.abs().sum()),target_delta_l1=float(target.abs().sum())))
                    atomic_json(root/'results.json',dict(records=records,scope=plan['scope'],no_optimizer_updates=True,endpoint=8192))
                    atomic_json(root/'status.json',dict(state='evaluating',model=lane,records=len(records)));render(root)
        del model,payload;torch.cuda.empty_cache()
    assert len(records)==48
    atomic_json(root/'status.json',dict(state='complete',records=len(records),gpu_seconds=time.monotonic()-started,no_optimizer_updates=True));render(root)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');args=p.parse_args();root=args.root.resolve()
    if args.prepare:prepare(root)
    else:
        try:run(root)
        except BaseException as error:atomic_json(root/'status.json',dict(state='failed',error=repr(error)));render(root);raise
