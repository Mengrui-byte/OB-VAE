"""One-seed, equal-update factorial pilot for latent fusion and modality towers."""

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import numpy as np
import torch
from torch.utils.data import DataLoader, Subset

from model.experimental.dual_fusion import FusedOrderBookVAE, FUSION_VARIANTS
from model.losses.dual import DualLossConfig, DualVAELoss
from train_dual.experiments.long_worker import atomic_json, datasets, evaluate, forward, rng_state
from train_dual.util.checkpoint import atomic_save, seed_everything, source_hashes
from train_dual.util.data import DualNormalizer


def utc():
    return datetime.now(timezone.utc).isoformat()


def worker(root, variant):
    plan = json.loads((root / "plan.json").read_text())
    folder = root / variant
    folder.mkdir(exist_ok=True)
    torch.set_num_threads(4)
    device = "cuda:0"
    initial = torch.load(root / "initial.pt", map_location="cpu", weights_only=False)
    seed_everything(plan["seed"])
    model = FusedOrderBookVAE(fusion_variant=variant, fusion_seed=plan["seed"], **initial["model_config"]).to(device)
    model.load_volume_initial(initial["model"])
    normalization = initial["config"]["normalization"]
    normalizer = DualNormalizer(tick_size=normalization["tick_size"], price_scale=normalization["price_scale"])
    train, val = datasets(root, initial, "train"), datasets(root, initial, "val")
    criterion = DualVAELoss(config=DualLossConfig(**plan["loss"]))
    optimizer = torch.optim.AdamW(model.parameters(), lr=plan["lr"], weight_decay=.01)
    params = sum(p.numel() for p in model.parameters())
    started = time.monotonic()
    hashes = source_hashes()

    def checkpoint(step):
        return dict(format_version=1, model=model.state_dict(), model_config=initial["model_config"],
                    fusion_variant=variant, research_variant="volume", refinement_seed=plan["seed"],
                    config=dict(initial["config"], loss=plan["loss"]), source_hashes=hashes,
                    optimizer=optimizer.state_dict(), rng=rng_state(), step=step, parameters=params,
                    source_checkpoint=plan["initial_checkpoint"], epoch_completed=False)

    try:
        before = evaluate(model, normalizer, val, plan["evaluation_windows"], device)
        atomic_json(folder / "initial_evaluation.json", dict(utc=utc(), result=before, parameters=params))
        # All arms consume exactly the same saved indices, batches and posterior
        # base noise. Model construction and validation do not advance training RNG.
        seed_everything(plan["seed"])
        indices = np.load(root / "train_indices.npy")
        loader = DataLoader(Subset(train, indices.tolist()), batch_size=plan["physical_batch"],
                            shuffle=False, num_workers=2, pin_memory=True,
                            generator=torch.Generator().manual_seed(plan["seed"]))
        torch.cuda.reset_peak_memory_stats()
        model.train()
        optimizer.zero_grad(set_to_none=True)
        step = 0
        accumulation = plan["effective_batch"] // plan["physical_batch"]
        loss_sum = 0.
        train_started = time.monotonic()
        for micro, raw in enumerate(loader, 1):
            batch = normalizer.prepare(raw, device)
            with torch.autocast(device_type="cuda", dtype=torch.bfloat16):
                output = forward(model, batch, True)
            terms = criterion(output, batch)
            if not torch.isfinite(terms["loss"]):
                raise FloatingPointError("Nonfinite training loss")
            (terms["loss"] / accumulation).backward()
            loss_sum += terms["loss"].item() / accumulation
            if micro % accumulation:
                continue
            norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1., error_if_nonfinite=True)
            optimizer.step()
            optimizer.zero_grad(set_to_none=True)
            step += 1
            if step == 1 or step % 8 == 0:
                row = dict(state="training", utc=utc(), variant=variant, step=step, loss=loss_sum,
                           gradient_norm=float(norm), samples_seen=step * plan["effective_batch"],
                           parameters=params, elapsed_seconds=time.monotonic() - started,
                           peak_allocated_gib=torch.cuda.max_memory_allocated() / 2**30,
                           reserved_gib=torch.cuda.memory_reserved() / 2**30)
                atomic_json(folder / "progress.json", row)
                with (folder / "train.jsonl").open("a") as stream:
                    stream.write(json.dumps(row) + "\n")
                print(json.dumps(row), flush=True)
            loss_sum = 0.
            if step % 32 == 0:
                atomic_save(checkpoint(step), folder / "last.pt")
            if step == plan["steps"]:
                break
        if step != plan["steps"]:
            raise RuntimeError(f"Expected {plan['steps']} optimizer steps, got {step}")
        training_seconds = time.monotonic() - train_started
        atomic_save(checkpoint(step), folder / "final.pt")
        result = evaluate(model, normalizer, val, plan["evaluation_windows"], device)
        atomic_json(folder / "final_evaluation.json", dict(utc=utc(), variant=variant, step=step,
                    result=result, training_seconds=training_seconds, parameters=params,
                    peak_allocated_gib=torch.cuda.max_memory_allocated() / 2**30))
        predictions, truths, masks = [], [], []
        with torch.inference_mode():
            model.eval()
            for index in plan["example_indices"]:
                raw = {k: v.unsqueeze(0) for k, v in val[index].items()}
                batch = normalizer.prepare(raw, device)
                out = forward(model, batch, False)
                predictions.append(np.stack([normalizer.inverse_price(out["price_norm"], batch)[0].cpu().numpy(),
                                             out["volume"][0].float().cpu().numpy()], -1))
                truths.append(raw["data"][0].numpy())
                masks.append(batch["mask"][0].cpu().numpy())
        np.savez_compressed(folder / "profiles.npz", prediction=np.stack(predictions), truth=np.stack(truths), mask=np.stack(masks))
        atomic_json(folder / "status.json", dict(state="complete", utc=utc(), step=step,
                    elapsed_seconds=time.monotonic() - started))
    except BaseException as error:
        atomic_json(folder / "status.json", dict(state="failed", utc=utc(), error=repr(error)))
        raise


def campaign(root):
    plan = json.loads((root / "plan.json").read_text())
    logs = root / "logs"
    logs.mkdir(exist_ok=True)
    children = []
    started = time.monotonic()
    state = dict(state="running", utc=utc(), seed=plan["seed"], steps=plan["steps"], children=[])
    atomic_json(root / "status.json", state)
    try:
        for gpu, variant in zip((2, 3, 4, 5), FUSION_VARIANTS):
            env = dict(os.environ, CUDA_VISIBLE_DEVICES=str(gpu), CUDA_DEVICE_ORDER="PCI_BUS_ID",
                       PYTHONPATH=str(root / "source_snapshot"), PYTHONDONTWRITEBYTECODE="1",
                       OMP_NUM_THREADS="4", MKL_NUM_THREADS="4")
            with (logs / (variant + ".log")).open("ab", buffering=0) as log:
                process = subprocess.Popen([sys.executable, "-u", "-m", "train_dual.experiments.fusion_pilot", str(root),
                                            "--variant", variant], env=env, cwd=root / "source_snapshot",
                                           stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                           start_new_session=True)
            children.append((variant, process))
            state["children"].append(dict(variant=variant, gpu=gpu, pid=process.pid))
        atomic_json(root / "status.json", state)
        while any(p.poll() is None for _, p in children):
            if time.monotonic() - started > plan["wall_clock_limit_seconds"]:
                raise TimeoutError("Pilot wall-clock limit reached")
            if any(p.poll() not in (None, 0) for _, p in children):
                raise RuntimeError("A worker failed; stop the paired experiment")
            time.sleep(3)
        exits = {name: process.returncode for name, process in children}
        if any(code != 0 for code in exits.values()):
            raise RuntimeError(f"Workers failed before comparison: {exits}")
        values = {name: dict(initial=json.loads((root / name / "initial_evaluation.json").read_text()),
                             final=json.loads((root / name / "final_evaluation.json").read_text()))
                  for name, _ in children}
        atomic_json(root / "comparison.json", dict(seed=plan["seed"], steps=plan["steps"], variants=values,
                    interpretation="Single-seed screening on development validation, not final test confirmation",
                    tower_initialization="Modality gates change pretrained encoder inputs; compare step zero as well as final results"))
        state.update(state="complete", finished_utc=utc(), elapsed_seconds=time.monotonic() - started)
    except BaseException as error:
        state.update(state="failed", error=repr(error), finished_utc=utc())
        raise
    finally:
        for _, process in children:
            if process.poll() is None:
                try:
                    os.killpg(process.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
        for _, process in children:
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
        atomic_json(root / "status.json", state)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("--variant", choices=FUSION_VARIANTS)
    args = parser.parse_args()
    if args.variant:
        worker(args.root, args.variant)
    else:
        campaign(args.root)


if __name__ == "__main__":
    main()
