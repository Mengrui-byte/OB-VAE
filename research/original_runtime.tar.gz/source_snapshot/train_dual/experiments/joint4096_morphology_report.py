"""Report quantity morphology supervision with matched Dice continuation."""
import argparse
import base64
import csv
import hashlib
import json
import os
from pathlib import Path

import numpy as np


def main(root):
    read=lambda p:json.loads((root/p).read_text());comparison=read('comparison.json');plan=read('plan.json')
    data=dict(comparison=comparison,plan=plan,verification=read('verification.json'),histories={},seen={},arm_verification={})
    for arm in ['dice_control','dice_morphology']:
        path=root/arm/'compressed4096'
        data['histories'][arm]=[json.loads(line) for line in (path/'progress.jsonl').read_text().splitlines() if json.loads(line).get('phase')=='decoder_adaptation']
        data['seen'][arm]=[json.loads((path/f'train_step{step}_16windows.json').read_text()) for step in (0,32,64,128)]
        data['arm_verification'][arm]=json.loads((path/'verification.json').read_text())
    rows=[]
    for name in ['initial','dice_control','dice_morphology']:
        d=comparison[name];m=d['metrics'];s=d['shape_metrics'];t=d['threshold100']
        rows.append([name,m['price_usdt']['rmse'],m['quantity_btc']['rmse'],m['temporal_log_quantity_1_minutes']['correlation'],t['recall'],s['quantity_dice'],s['morphology'],s['morphology_k3'],s['morphology_k9'],s['morphology_k33']])
    change=comparison['dice_morphology']['shape_metrics']['morphology']/comparison['dice_control']['shape_metrics']['morphology']-1
    initial_change=comparison['dice_morphology']['shape_metrics']['morphology']/comparison['initial']['shape_metrics']['morphology']-1
    verdict=('本轮未改善开发集形态：' if change>=0 else '开发集形态误差有所下降：')+f'相对匹配Dice对照，形态误差{("增加" if change>=0 else "下降")}{abs(change):.2%}；相对共同初始模型{("增加" if initial_change>=0 else "下降")}{abs(initial_change):.2%}。训练窗口上的形态改善不能直接当作开发集改善。'
    with (root/'comparison.csv').open('w') as stream:
        w=csv.writer(stream);w.writerow(['variant','price_rmse_usdt','quantity_rmse_btc','quantity_change_correlation','recall100','quantity_dice_loss','morphology_loss','morph_k3','morph_k9','morph_k33']);w.writerows(rows)
    os.environ['MPLCONFIGDIR']=str(root/'.mpl-cache')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    figures=root/'figures';figures.mkdir(exist_ok=True)
    initial=np.load(root/'common/compressed4096/development_step0_128windows_profiles.npz')
    control=np.load(root/'dice_control/compressed4096/development_step128_128windows_profiles.npz')
    morphology=np.load(root/'dice_morphology/compressed4096/development_step128_128windows_profiles.npz')
    assert np.array_equal(initial['indices'],control['indices']) and np.array_equal(initial['indices'],morphology['indices'])
    example_metrics={}
    truth=initial['truth'][...,1];target_diff=np.diff(np.log1p(truth),axis=-1).ravel()
    top=np.argsort(truth,axis=-1)[...,-16:]
    for name,profile in [('initial',initial),('dice_control',control),('dice_morphology',morphology)]:
        pred=profile['prediction'][...,1];pred_diff=np.diff(np.log1p(pred),axis=-1).ravel()
        selected=np.argsort(pred,axis=-1)[...,-16:]
        overlap=np.array([len(set(a)&set(b))/16 for a,b in zip(top.reshape(-1,16),selected.reshape(-1,16))]).mean()
        example_metrics[name]=dict(spatial_log_slope_correlation=float(np.corrcoef(target_diff,pred_diff)[0,1]),
            spatial_log_slope_std_ratio=float(pred_diff.std()/target_diff.std()),top16_same_rank_overlap=float(overlap),
            amplitude_ratio_at_true_top16=float(np.take_along_axis(pred,top,-1).sum()/np.take_along_axis(truth,top,-1).sum()))
    data['example_metrics']=example_metrics
    (root/'example_shape_metrics.json').write_text(json.dumps(dict(windows=3,minutes_per_window=16,indices=initial['indices'].tolist(),
        metrics=example_metrics,scope='Post-hoc descriptive diagnostics on3fixed saved examples only, not128-window population evaluation or independent samples.'),indent=2))
    images=[]
    for window in range(3):
        for use_log in (False,True):
            fig,axs=plt.subplots(3,2,figsize=(13,9),layout='constrained')
            for row,t in enumerate((0,7,15)):
                for side in (0,1):
                    ax=axs[row,side]
                    curves=[('Truth',initial['truth'][window,t,side,:,1],'#182f41','-'),
                        ('Shared Dice initialization',initial['prediction'][window,t,side,:,1],'#97a5ae','--'),
                        ('Dice continuation',control['prediction'][window,t,side,:,1],'#126c96','-'),
                        ('Dice + morphology',morphology['prediction'][window,t,side,:,1],'#d07832','-')]
                    for label,y,color,ls in curves:ax.plot(np.arange(len(y)),np.log1p(y) if use_log else y,label=label,color=color,ls=ls,lw=.8,alpha=.9)
                    ax.set(title=f'Minute{t} / '+('Bid' if side==0 else 'Ask'),xlabel='Ranked level',ylabel='log1p(quantity BTC)' if use_log else 'Quantity BTC')
                    ax.grid(alpha=.18)
            axs[0,0].legend(fontsize=8);fig.suptitle(f'Development window index{int(initial["indices"][window])}: complete2048levels per side')
            name=f'window{window}_'+('log' if use_log else 'linear')+'.png';fig.savefig(figures/name,dpi=140);plt.close(fig)
            images.append((window,use_log,name))
    imagehtml=''
    for window in range(3):
        imagehtml+=f'<details><summary>窗口{window+1}：原开发索引{int(initial["indices"][window])}，查看第0/7/15分钟</summary>'
        for w,log,name in images:
            if w!=window:continue
            imagehtml+='<h3>'+('log1p高度：查看小挂量细节' if log else '原始BTC高度：检查大单幅度')+'</h3><a href="figures/'+name+'"><img alt="同一窗口真实订单簿、共同初始化、Dice对照与形态监督的完整档位对比" src="data:image/png;base64,'+base64.b64encode((figures/name).read_bytes()).decode()+'"></a>'
        imagehtml+='</details>'
    template=r'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>生成订单簿的形态监督 · Dice匹配对照</title><style>*{box-sizing:border-box}body{margin:0;background:#f3f7fa;color:#183345;font:15px/1.75 system-ui,-apple-system,"Microsoft YaHei",sans-serif}main{max-width:1220px;margin:auto;padding:32px 22px 60px}h1{font-size:31px;line-height:1.35}h2{font-size:22px;margin:0 0 12px}h3{font-size:17px}a{color:#146e98}.eyebrow{font-size:12px;letter-spacing:.1em;font-weight:700;color:#087d77}.lead{font-size:17px;max-width:970px}.badge{display:inline-block;background:#e2f1f1;color:#08665f;font-size:12px;padding:3px 10px;border-radius:6px;margin:4px 6px 4px 0}.warn{background:#fff1d9;color:#80551d}.note{font-size:13px;color:#536d7e}section{background:white;border:1px solid #dce7ee;border-radius:13px;padding:25px;margin:22px 0}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}.card{background:#f6fafc;border:1px solid #e0eaf0;border-radius:9px;padding:17px}.number{font-size:28px;font-weight:750;color:#146e98}.callout{background:#edf8f5;border-left:4px solid #087d77;padding:13px 17px;margin:17px 0}.warning{background:#fff8ec;border-left-color:#c18932}.scroll{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:13px}th,td{padding:9px 11px;border-bottom:1px solid #dce7ee;text-align:right;white-space:nowrap}th:first-child,td:first-child{text-align:left}th{background:#f4f8fa}.target{background:#e6f5f4}.plots{display:grid;grid-template-columns:1fr 1fr;gap:20px}svg,img{max-width:100%;height:auto}svg{width:100%}code{background:#edf3f7;padding:2px 5px;border-radius:4px}pre{padding:16px;background:#f5f9fb;border-radius:8px;overflow:auto}details{margin:17px 0}summary{cursor:pointer;font-weight:650}nav{display:flex;gap:24px;flex-wrap:wrap;margin:24px 0}ul{padding-left:23px}button{font:inherit;padding:6px 10px;background:white;border:1px solid #c7d7e1;border-radius:6px;color:#183345;cursor:pointer}footer{font-size:12px;color:#536d7e;margin-top:25px}@media(max-width:740px){main{padding:20px 12px}section{padding:17px}.grid,.plots{grid-template-columns:1fr}h1{font-size:26px}}@media print{body{background:white}nav,button{display:none}main{padding:0}section{break-inside:avoid}}</style></head><body><main>
<header><div class="eyebrow">ORDER BOOK MORPHOLOGY · CONTROLLED DICE CONTINUATION</div><h1>让生成的订单簿学习局部形态</h1><p class="lead">在价格原损失与连续挂量Dice之外，增加多尺度形态梯度监督：比较真实和预测挂量曲线的膨胀−腐蚀。Dice继续约束挂量幅度，形态项约束不同宽度邻域的局部对比与边缘结构。</p><span class="badge warn">16分钟历史模型 · 固定4096维连续状态</span><span class="badge">共同Dice终点初始化</span><span class="badge">继续128步 × batch2 · seed42</span><span class="badge">仅增加形态梯度损失</span></header>
<nav><a href="#result">最终比较</a><a href="#definition">监督定义</a><a href="#curves">训练曲线</a><a href="#profiles">生成形态对照</a><a href="#repro">验证与权重</a></nav>
<section id="result"><h2>同128个开发窗口上的结果</h2><div class="grid" id="cards"></div><div class="callout" id="effect"></div><div class="scroll"><table><thead><tr><th>配置</th><th>价格RMSE / USDT ↓</th><th>挂量RMSE / BTC ↓</th><th>分钟挂量变化相关 ↑</th><th>≥100BTC召回 ↑</th><th>形态梯度误差 ↓</th><th>Dice误差 ↓</th></tr></thead><tbody id="rows"></tbody></table></div><p class="note">两组从同一已完成的Dice权重出发，各继续训练128步；不是将形态组与少训练128步的旧Dice终点直接比较。共同初始模型也单列，防止相对退化对照的改善被误读。</p><h3>不同形态尺度的误差</h3><div class="scroll"><table><thead><tr><th>配置</th><th>3档邻域</th><th>9档邻域</th><th>33档邻域</th></tr></thead><tbody id="scaleRows"></tbody></table></div></section>
<section id="definition"><h2>形态损失如何作用于OB</h2><pre>x = log1p(q / q0)
δₖ(x) = max pooling(x, k)       膨胀
εₖ(x) = min pooling(x, k)       腐蚀
Gₖ(x) = δₖ(x) − εₖ(x)          形态梯度
L_morph = meanₖ Huber(Gₖ(pred), Gₖ(target)), k∈{3,9,33}
L_total = L_original_price + L_Dice + 1.0 × L_morph</pre><ul><li>每个分钟、每一侧单独处理，沿排序档位轴计算，不跨分钟、买卖侧混合。</li><li>只对完整有效邻域监督，边界和padding不会制造伪边缘；各有效行与三个尺度等权，Huber beta=1。</li><li>Dice保留连续BTC幅度，不二值化。形态项使用log1p挂量，降低极端幅度对局部形状损失的支配。</li><li>这是局部邻域对比的监督，并非直接给每个峰指定语义；峰位和峰宽变化会影响形态梯度，但没有新增人工峰标签。</li><li>价格监督权重不变；编码器、融合模块和4096维PCA冻结，只训练原双Decoder及数量幅度修正头。</li></ul><div class="callout warning">本轮结构元素按“排序档位”定义，不按固定价格间隔定义。邻接档位可能价差不同，因此不能把该损失解释为同价格墙体持续性或真实增撤单事件监督。</div></section>
<section id="curves"><h2>训练与拟合情况</h2><p class="note">物理指标曲线始终使用同16个本轮训练窗口。两组总损失定义不同，不直接比较总损失绝对值。</p><div class="plots" id="plots"></div></section>
<section id="profiles"><h2>完整2048档的生成形态对照</h2><p>固定保存的三个开发窗口，展示第0、7、15分钟，买卖两侧分别绘制。黑色为真实挂量，灰色为共同Dice初始化，蓝色为继续Dice，橙色为增加形态监督。</p><p class="note">同时给出原始BTC高度和log1p高度，防止仅看对数图掩盖大单幅度不足；所有真实和预测均使用相同纵轴。图按档位对齐，与本轮监督轴一致，没有暗中平均或删除尖峰。点击图片可下载PNG。</p><div class="scroll"><table><thead><tr><th>仅固定3例的辅助诊断</th><th>相邻档位log挂量差分相关 ↑</th><th>差分标准差/真实值</th><th>Top16同档位重合 ↑</th><th>真实Top16位置的幅度比</th></tr></thead><tbody id="exampleRows"></tbody></table></div><p class="note">该表仅使用固定3个保存案例的全部16分钟，不是全128窗口统计；不据此给出显著性或泛化结论。Top16重合不设容差，幅度比为对应真实Top16位置的预测总量/真实总量。</p>__IMAGES__</section>
<section id="repro"><h2>控制与可复现性</h2><ul><li>两组共用完成Dice128步后的权重；重新初始化相同AdamW优化器，学习率3e−5、weight decay0.01、梯度裁剪1、batch2、继续128步。</li><li>共同seed42排列中的第257～512个训练窗口用于本轮，两组完全一致，并与前一阶段的256次窗口访问不重复。</li><li>共同初始化先完整评价128个开发窗口；两个训练组分别核对初始权重、共享PCA/状态文件和3个完整重建样本一致。</li><li>主表及尺度误差均为同128个2025 Q1开发窗口，形态误差为各窗口指标的均值；中途开发监控为固定16窗口，不混用口径。</li><li>10项模型和损失测试通过，覆盖峰位/峰宽/缺口、mask、空邻域、有效梯度、价格与Dice监督保持一致、单Z解码和冻结编码器。</li><li>固定seed42，不报告跨种子方差；这是有界续训与已复用开发集上的结果，不代表收敛上限或独立测试，更不代表latent无损。</li></ul><ul id="checks"></ul><details><summary>权重、指标与源码</summary><ul><li><a href="dice_morphology/compressed4096/final.pt">形态监督模型权重</a> · <a href="dice_control/compressed4096/final.pt">同预算Dice续训对照权重</a> · <a href="joint_pca_basis.pt">共享固定4096维PCA基底</a></li><li><a href="comparison.csv">完整结果CSV</a> · <a href="comparison.json">评价JSON</a> · <a href="plan.json">计划与形态定义</a> · <a href="verification.json">匹配核查</a></li><li><a href="source_snapshot/model/losses/quantity_morphology.py">形态损失源码</a> · <a href="source_snapshot/train_dual/experiments/joint4096_morphology_run.py">实验入口快照</a> · <a href="source_snapshot/sha256.json">源码哈希</a></li><li><a href="../joint4096_dice_20261026/">前一轮Dice报告</a></li></ul><p class="note">权重引用固定codec_file，需同时加载共享PCA基底。所有源权重和先前实验快照均保留。</p></details></section><footer>Joint4096 · Dice + morphological gradient · 2026-10-26 <button onclick="window.print()">打印 / 保存PDF</button></footer></main>
<script id="data" type="application/json">__DATA__</script><script>
'use strict';const D=JSON.parse(document.getElementById('data').textContent),$=id=>document.getElementById(id),f=(v,n=3)=>Number(v).toFixed(n),pct=v=>v===null?'—':f(v*100,2)+'%';const C=D.comparison,label={initial:'共同Dice终点·本轮初始',dice_control:'Dice继续128步',dice_morphology:'Dice+形态继续128步'};const metric=(d,k)=>k==='price'?d.metrics.price_usdt.rmse:k==='quantity'?d.metrics.quantity_btc.rmse:k==='dynamics'?d.metrics.temporal_log_quantity_1_minutes.correlation:d.threshold100.recall;
const m=C.dice_morphology,c=C.dice_control;$('cards').innerHTML=[['形态组·形态梯度误差',f(m.shape_metrics.morphology,5)],['形态组·挂量RMSE',f(metric(m,'quantity'),4)+' BTC'],['形态组·大单召回',pct(m.threshold100.recall)]].map(([a,b])=>`<article class="card"><div class="note">${a}</div><div class="number">${b}</div></article>`).join('');$('effect').textContent=`同预算对照与形态组的形态误差分别为${f(c.shape_metrics.morphology,5)}和${f(m.shape_metrics.morphology,5)}，挂量RMSE分别为${f(metric(c,'quantity'),4)}和${f(metric(m,'quantity'),4)}BTC，大单召回分别为${pct(c.threshold100.recall)}和${pct(m.threshold100.recall)}。同时检查价格，不能只凭形态项下降判断重建成功。`;$('rows').innerHTML=Object.keys(label).map(k=>{let d=C[k];return `<tr class="${k==='dice_morphology'?'target':''}"><td>${label[k]}</td><td>${f(metric(d,'price'))}</td><td>${f(metric(d,'quantity'),4)}</td><td>${f(metric(d,'dynamics'),4)}</td><td>${pct(d.threshold100.recall)}</td><td>${f(d.shape_metrics.morphology,5)}</td><td>${f(d.shape_metrics.quantity_dice,5)}</td></tr>`}).join('');$('scaleRows').innerHTML=Object.keys(label).map(k=>`<tr><td>${label[k]}</td>${[3,9,33].map(n=>`<td>${f(C[k].shape_metrics['morphology_k'+n],5)}</td>`).join('')}</tr>`).join('');
function chart(title,series){let W=500,H=230,L=55,R=15,T=20,B=34,all=series.flatMap(s=>s.values),lo=Math.min(0,...all.map(p=>p[1])),hi=Math.max(...all.map(p=>p[1]))*1.1||1,x=v=>L+v/128*(W-L-R),y=v=>H-B-(v-lo)/(hi-lo)*(H-T-B);return `<div><h3>${title}</h3><svg role="img" aria-label="${title}" viewBox="0 0 ${W} ${H}">${Array.from({length:5},(_,i)=>{let v=lo+(hi-lo)*i/4;return `<line x1="${L}" x2="${W-R}" y1="${y(v)}" y2="${y(v)}" stroke="#e0e9ef"/><text x="${L-7}" y="${y(v)+4}" text-anchor="end" font-size="10">${f(v,2)}</text>`}).join('')}${series.map((s,i)=>`<polyline points="${s.values.map(p=>x(p[0])+','+y(p[1])).join(' ')}" fill="none" stroke="${i===0?'#d07832':'#126c96'}" stroke-width="2.5"/><text x="${W-150}" y="${15+i*15}" font-size="11" fill="${i===0?'#d07832':'#126c96'}">${s.label}</text>`).join('')}${[0,32,64,128].map(v=>`<text x="${x(v)}" y="${H-10}" text-anchor="middle" font-size="11">${v}</text>`).join('')}</svg></div>`}
const arms=[['dice_morphology','Dice+形态'],['dice_control','Dice对照']];$('plots').innerHTML=chart('形态组训练批次的形态项',[{label:'Morphology',values:D.histories.dice_morphology.filter(v=>v.quantity_morphology!==null).map(v=>[v.step,v.quantity_morphology])}])+chart('同16训练窗口·形态误差',arms.map(([k,label])=>({label,values:D.seen[k].map(v=>[v.step,v.shape_metrics.morphology])})))+chart('同16训练窗口·挂量RMSE',arms.map(([k,label])=>({label,values:D.seen[k].map(v=>[v.step,metric(v,'quantity')])})))+chart('同16训练窗口·价格RMSE',arms.map(([k,label])=>({label,values:D.seen[k].map(v=>[v.step,metric(v,'price')])})));$('checks').innerHTML=`<li>${D.verification.paired_training_order_same_inode?'✓':'未通过'} 两组使用同一个批次顺序文件。</li><li>${D.verification.common_initial_checkpoint_sha256_unchanged?'✓':'未通过'} 共同源Dice权重SHA256保持不变。</li>`+arms.map(([k,label])=>`<li>${D.arm_verification[k].encoder_and_fusion_bitwise_unchanged?'✓':'未通过'} ${label}编码器与融合模块逐位未变，完成${D.arm_verification[k].steps}步。</li>`).join('');
</script></body></html>'''
    template=template.replace("const arms=[['dice_morphology'", "$('exampleRows').innerHTML=Object.keys(label).map(k=>{let v=D.example_metrics[k];return `<tr><td>${label[k]}</td><td>${f(v.spatial_log_slope_correlation,4)}</td><td>${f(v.spatial_log_slope_std_ratio,4)}</td><td>${pct(v.top16_same_rank_overlap)}</td><td>${f(v.amplitude_ratio_at_true_top16,4)}</td></tr>`}).join('');const arms=[['dice_morphology'")
    template=template.replace('<div class="callout" id="effect"></div>','<div class="callout" id="effect"></div><div class="callout warning">'+verdict+'</div>')
    template=template.replace('__IMAGES__',imagehtml).replace('__DATA__',json.dumps(data,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c'))
    (root/'index.html').write_text(template)
    report=dict(url='http://172.16.30.28:8875/recons/'+root.name+'/',live_url_verified=False)
    (root/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(report)
    for row in rows:print(row)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);main(p.parse_args().root)
