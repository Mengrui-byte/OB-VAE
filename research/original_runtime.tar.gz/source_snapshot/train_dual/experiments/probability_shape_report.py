"""Live probability-shape factorial report: geometry, mass, dynamics and peaks."""
import argparse
import json
from pathlib import Path
import threading

from train_dual.experiments.full_window_report import PAGE, monitor
from train_dual.experiments.long_worker import atomic_json


def read(path):
    try:return json.loads(path.read_text())
    except (OSError,ValueError):return None


def diagnostics(root):
    plan=read(root/'plan.json')
    rows={}
    for lane,label in plan['labels'].items():
        shapes={};seen={};dev={}
        for step in [0,*plan['checkpoints']]:
            prefix='initial' if step==0 else f'step{step}'
            shape=read(root/lane/(prefix+'_probability.json'))
            a=read(root/lane/(prefix+'_seen_evaluation.json'))
            b=read(root/lane/(prefix+'_evaluation.json'))
            if shape:shapes[str(step)]=shape
            if a:seen[str(step)]=a['result']
            if b:dev[str(step)]=b['result']
        rows[lane]=dict(label=label,shape=shapes,seen=seen,development=dev,
                        exposures=read(root/lane/'data_exposures.json'))
    common=[s for s in [0,*plan['checkpoints']] if all(str(s) in row['shape'] and str(s) in row['development'] and str(s) in row['seen'] for row in rows.values())]
    step=max(common) if common else None
    comparisons={}
    if step is not None and '0' in rows['baseline']['shape']:
        initial=rows['baseline']['development']['0']['metrics']
        base=rows['baseline']['development'][str(step)]['metrics']
        initial_shape=rows['baseline']['shape']['0']['development']
        base_shape=rows['baseline']['shape'][str(step)]['development']
        for lane,row in rows.items():
            shape=row['shape'][str(step)]['development'];d=row['development'][str(step)];m=d['metrics']
            q,p=m['quantity_btc']['rmse'],m['price_usdt']['rmse']
            corr=m['temporal_log_quantity_1_minutes']['correlation']
            shape_guard=(shape['quantity_rank_w1']<=.9*base_shape['quantity_rank_w1']
                and shape['quantity_rank_w1']<initial_shape['quantity_rank_w1']
                and shape['quantity_shape_kl']<=base_shape['quantity_shape_kl'])
            qguard=q<=1.05*base['quantity_btc']['rmse'] and q<=1.05*initial['quantity_btc']['rmse']
            pguard=p<=1.1*base['price_usdt']['rmse'] and p<=1.1*initial['price_usdt']['rmse']
            comparisons[lane]=dict(step=step,shape=shape,development=d,seen=row['seen'][str(step)],
                shape_guard=shape_guard,quantity_guard=qguard,price_guard=pguard,
                exploratory_screen_pass=step>0 and lane!='baseline' and shape_guard and qguard and pguard and corr is not None and corr>=.10)
        atomic_json(root/'latest_comparison.json',dict(common_step=step,rows=comparisons))
    result=dict(common_step=step,rows=rows,comparisons=comparisons,
                calibration=read(root/'calibration.json'),calibration_progress=read(root/'calibration_progress.json'),
                status=read(root/'status.json'))
    atomic_json(root/'public/probability_diagnostics.json',result)
    if step==plan['steps']:
        atomic_json(root/'endpoint_summary.json',dict(step=step,rows=comparisons,
            calibration=read(root/'calibration.json'),scope='Single seed42;fixed1024train/8seen/16reused2025Q1development;no2026orindependenttestselection.'))


def main(root):
    root=root.resolve()
    page=PAGE.replace('256分钟双分支实验','8192挂量概率形态对照').replace(
        '完整256分钟：双分支与整窗矩阵压缩','8192瓶颈：Wasserstein×多尺度KL形态监督')
    begin,end=page.index('<p>实际输入'),page.index('<p id=status>')
    text=('<p>完整256分钟、每侧2048档、唯一64×128latent。四组相同2816步权重及AdamW起点，'
          '相同1024个月份覆盖训练窗、8训练诊断窗、16个2025Q1开发窗，seed42、batch1累积4、AdamW1e−4、clip1，追加2048更新。</p>'
          '<p>原数量Huber/log/Top16、逐档分布KL和总量损失全部保留。2×2因素为：新增固定档位坐标上的Wasserstein；'
          '新增相邻8/64档概率质量求和后的KL。保持Softplus输出、最近邻上采样、预测价格条件和完整梯度回传。'
          '每帧每侧分别监督，零总量帧侧排除形态项；不引入独立latent或输入旁路。</p>'
          '<p>系数只用预先指定4训练窗的初始Encoder梯度RMS校准后锁定；不读取开发成绩。'
          'W1采用档位归一化距离，乘2047可换成档位单位。所有形态项FP32。2025Q1为反复使用的开发期，2026和独立测试未参与。</p>'
          '<p id=calibrationNote>正在进行训练样本初始梯度校准。</p>')
    page=page[:begin]+text+page[end:]
    page=page.replace('实际矩阵','实际唯一latent').replace('上一轮16分钟结果','上一轮实验结果')
    page=page.replace("'训练损失'","'共同基础损失（不含分布项）'")
    tables=('<h2>最新共同检查点：分布形态与总量</h2><p id=shapeStep>等待共同评估</p>'
            '<table><thead><tr><th>方案</th><th>样本</th><th>逐档KL↓</th><th>归一化W1↓</th><th>8档KL↓</th>'
            '<th>64档KL↓</th><th>总量RMSE BTC↓</th><th>时间形态L1↓</th></tr></thead><tbody id=shapeRows></tbody></table>'
            '<div class=plots><div id=klPlot></div><div id=w1Plot></div></div>'
            '<h2>同8个训练窗的拟合与开发大单定位</h2><table><thead><tr><th>方案</th><th>样本</th>'
            '<th>数量RMSE BTC</th><th>分钟数量变化相关</th><th>≥10BTC精确率/召回</th><th>≥100BTC精确率/召回</th>'
            '</tr></thead><tbody id=peakRows></tbody></table>'
            '<h2>训练数据实际曝光</h2><table><thead><tr><th>方案</th><th>已见不同窗</th><th>累计窗口展示</th>'
            '<th>等效遍历次数</th></tr></thead><tbody id=exposureRows></tbody></table>'
            '<p>形态误差下降需同时检查数量、时间变化和大单误报。价格与数量均对共同起点和匹配对照设置约束，'
            '不将单个新增损失降低解释为模型成功。完整结果见各检查点JSON。</p>')
    page=page.replace('<h2>首步实际梯度范数</h2>',tables+'<h2>首步实际梯度范数</h2>')
    js='''<script>(function(){let fmt=(x,n=4)=>Number.isFinite(x)?x.toFixed(n):'—',pct=x=>Number.isFinite(x)?(x*100).toFixed(2)+'%':'—';
async function aux(){let d=await(await fetch('probability_diagnostics.json?t='+Date.now())).json(),sr=[],pr=[],er=[],kl=[],w1=[];
document.getElementById('shapeStep').textContent=d.common_step===null?'等待共同评估':'共同追加第'+d.common_step+'步；训练和开发分开显示。';
let c=d.calibration;document.getElementById('calibrationNote').textContent=c?.passed?'训练样本校准已锁定：W1系数 '+c.weights.w1_weight.toPrecision(6)+'；多尺度KL系数 '+c.weights.multiscale_weight.toPrecision(6)+'。每个新增项的初始Encoder梯度RMS对齐原逐档KL。未更新模型、未使用开发指标。':'训练样本梯度校准：'+(d.calibration_progress?.completed_training_windows??0)+'/4窗';
for(let [lane,v] of Object.entries(d.rows)){let s=String(d.common_step),a=v.shape[s],e=v.exposures||{};
er.push(row([v.label,e.unique_windows_seen??'待实测',e.presentations??'—',fmt(e.epochs_equivalent,2)]));
if(a){for(let [role,label] of [['seen','训练8窗'],['development','开发16窗']]){let x=a[role],t=(role==='seen'?v.seen:v.development)[s],m=t.metrics,b=t.thresholds;
sr.push(row([v.label,label,fmt(x.quantity_shape_kl),fmt(x.quantity_rank_w1,6),fmt(x.quantity_kl_group8),fmt(x.quantity_kl_group64),fmt(x.mass_rmse_btc,2),fmt(x.temporal_distribution_l1)]));
pr.push(row([v.label,label,fmt(m.quantity_btc.rmse),fmt(m.temporal_log_quantity_1_minutes.correlation),pct(b['10'].precision)+' / '+pct(b['10'].recall),pct(b['100'].precision)+' / '+pct(b['100'].recall)]))}}
let history=Object.entries(v.shape).sort((a,b)=>+a[0]-+b[0]);kl.push({name:v.label,x:history.map(x=>+x[0]),y:history.map(x=>x[1].development.quantity_shape_kl),mode:'lines+markers'});w1.push({name:v.label,x:history.map(x=>+x[0]),y:history.map(x=>x[1].development.quantity_rank_w1),mode:'lines+markers'})}
document.getElementById('shapeRows').replaceChildren(...sr);document.getElementById('peakRows').replaceChildren(...pr);document.getElementById('exposureRows').replaceChildren(...er);
for(let [id,data,title] of [['klPlot',kl,'开发逐档分布KL'],['w1Plot',w1,'开发归一化档位W1']])Plotly.react(id,data,{title,height:360,template:'plotly_white',xaxis:{title:'追加更新步数'}},{responsive:true,displaylogo:false})}
aux().catch(console.error);setInterval(()=>aux().catch(console.error),10000)})()</script>'''
    page=page.replace('</html>',js+'</html>')
    (root/'public').mkdir(exist_ok=True)
    stop=threading.Event()
    def watch():
        while not stop.is_set():diagnostics(root);stop.wait(10)
    thread=threading.Thread(target=watch,daemon=True);thread.start()
    try:monitor(root,page)
    finally:stop.set();thread.join(timeout=2);diagnostics(root)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root',type=Path)
    main(parser.parse_args().root)
