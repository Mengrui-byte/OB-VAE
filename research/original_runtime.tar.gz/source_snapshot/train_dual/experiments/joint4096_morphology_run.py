"""Matched continuation: Dice alone versus Dice plus morphology supervision."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

import numpy as np
import torch

from train_dual.experiments.local_codebook_size_run import write
from util.model_sources import freeze_model_sources


def run(root,parent):
    root=root.resolve();parent=parent.resolve();root.mkdir(parents=True,exist_ok=False);started=time.monotonic()
    project=Path(__file__).resolve().parents[2];plan=json.loads((parent/'plan.json').read_text())
    source=parent/'compressed4096/final_with_objective.pt';assert source.exists()
    plan.update(source_checkpoint=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        initial_reference_parent=None,comparison_parent=str(parent),quantity_objective='squared_dice',
        morphology_weight=1.,morphology_scales=[3,9,33],morphology_huber_beta=1.,evaluate_morphology=True,
        skip_initial_4095=True,initialization='Both arms start at the exact completed Dice4096 checkpoint after its128updates; reset AdamW identically for a matched128update continuation.',
        only_changed_factor='Add morphology_weight1.0times mean multiscale Huber error of dilation-minus-erosion on log1p quantity; original price and Dice terms unchanged.',
        morphology_definition='Per-minute per-side ranked-depth morphology, k3/9/33. MaxPool dilation minus MinPool erosion of log1p(q/q0); only fully valid neighborhoods; mean Huber beta1per row and scale. No time mixing or price-grid resampling.',
        scope='Historical16minute original continuous source -> fixed4096state -> pretrained decoders. Add quantity shape supervision to the approved Dice objective.',
        limitations='Single seed42 and128x2visits per arm; development set reused. Rank-axis morphology is not a fixed-price-grid wall or event-flow measurement. No claim of convergence or latent losslessness.')
    for name in ['joint_pca_basis.pt','training_states.pt','development_states.pt']:(root/name).symlink_to(os.path.relpath(parent/name,root))
    for name in ['pca_fit.json','actual_shape_contract.json','preflight.json']:shutil.copy2(parent/name,root/name)
    generator=torch.Generator().manual_seed(42);allorder=torch.randperm(8192,generator=generator).numpy();order=allorder[256:512].reshape(128,2)
    assert not np.intersect1d(order.ravel(),np.load(parent/'training_order.npy').ravel()).size
    np.save(root/'training_order.npy',order);plan['seen_training_positions']=order.ravel()[np.linspace(0,order.size-1,16,dtype=int)].tolist()
    hashes=freeze_model_sources(root/'source_snapshot',project_root=project)
    for directory in ('train_dual','util'):
        for file in (project/directory).rglob('*.py'):
            rel=file.relative_to(project);dest=root/'source_snapshot'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(file,dest);hashes[str(rel)]=hashlib.sha256(dest.read_bytes()).hexdigest()
    write(root/'source_snapshot/sha256.json',hashes);plan['source_hashes']=hashes;write(root/'plan.json',plan)
    env=dict(os.environ,PYTHONPATH=str(root/'source_snapshot'),PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',MKL_NUM_THREADS='4')
    def setup(name,p):
        d=root/name;d.mkdir()
        for file in ['joint_pca_basis.pt','training_states.pt','development_states.pt','training_order.npy']:(d/file).symlink_to(os.path.relpath(root/file,d))
        write(d/'plan.json',p);return d
    def launch(d):
        log=(d/'run.log').open('wb');p=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.joint4096_decoder_run',str(d),'--worker','compressed4096'],cwd=root/'source_snapshot',env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT);log.close();return p
    write(root/'status.json',dict(state='common_initial_evaluation'))
    common=setup('common',dict(plan,evaluation_only=True))
    p=launch(common);code=p.wait()
    if code!=0:raise RuntimeError(f'Common morphology initial evaluation failed with{code}')
    children=[]
    try:
        for name,obj in [('dice_control','squared_dice'),('dice_morphology','squared_dice_morphology')]:
            d=setup(name,dict(plan,quantity_objective=obj,initial_reference_parent=str(common),evaluation_only=False))
            children.append((name,launch(d)))
        write(root/'status.json',dict(state='training',workers=[dict(lane=name,pid=p.pid) for name,p in children]))
        while any(p.poll() is None for _,p in children):
            if any(p.poll() not in (None,0) for _,p in children):raise RuntimeError('A morphology control worker failed')
            time.sleep(2)
        assert all(p.returncode==0 for _,p in children)
        comparison=dict(initial=json.loads((common/'compressed4096/initial_evaluation.json').read_text()),
            **{name:json.loads((root/name/'compressed4096/final_evaluation.json').read_text()) for name,_ in children})
        write(root/'comparison.json',comparison)
        write(root/'verification.json',dict(common_initial_checkpoint_sha256_unchanged=hashlib.sha256(source.read_bytes()).hexdigest()==plan['source_sha256'],
            paired_training_order_same_inode=os.path.samefile(root/'dice_control/training_order.npy',root/'dice_morphology/training_order.npy'),
            no_repeated_training_visits_from_previous_stage=True,source_is_completed_dice_checkpoint=True))
        write(root/'status.json',dict(state='complete',steps_per_arm=128,elapsed_seconds=time.monotonic()-started))
    finally:
        for _,p in children:
            if p.poll() is None:p.terminate()
        for _,p in children:
            try:p.wait(timeout=10)
            except subprocess.TimeoutExpired:p.kill();p.wait()


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--parent',type=Path,required=True);a=p.parse_args()
    try:run(a.root,a.parent)
    except BaseException as error:
        if a.root.exists():write(a.root/'failure.json',dict(error=repr(error)))
        raise
