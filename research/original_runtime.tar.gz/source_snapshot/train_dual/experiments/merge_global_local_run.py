"""Can unchanged-size Local absorb Global on complete256minute windows?"""

import argparse
from copy import deepcopy
from datetime import datetime
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import numpy as np
import torch
from torch.utils.data import DataLoader,TensorDataset

from model.experimental.global_into_local import GlobalIntoLocalOrderBookVAE
from model.losses.quantized_book import QuantizedBookLoss
from train_dual.experiments.full_window_run import dataset,profiles as source_profiles
from train_dual.experiments.local_quant_reconstruction import CacheWindows
from train_dual.experiments.long_worker import atomic_json,evaluate
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import atomic_save,freeze_sources,load_for_inference,seed_everything,source_hashes


LABELS={'reference':'原Global＋Local参考','local':'原Cross-Local＋学习读出','residual':'Global残差写入Local','attention':'Global注意力写入Local'}


def prepare(parent):
    parent=parent.resolve();root=parent.parent/('merge_global_local_256_'+datetime.now().strftime('%Y%m%d_%H%M%S'));root.mkdir();(root/'logs').mkdir();(root/'data').mkdir()
    for name in ('train_indices.npy','val_indices.npy'):os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz');os.link(parent/'reference/final.pt',root/'initial.pt');os.link(parent/'reference/step512_evaluation.json',root/'expected_reference.json')
    plan=json.loads((parent/'plan.json').read_text())
    for key in ('matrix_shape','basis_windows','basis_width','initialization'):plan.pop(key,None)
    plan.update(parent=str(parent),experiment='Global information into same-size Local; no independent Global decoder input',
        labels=LABELS,lanes={k:dict(merge_mode=k) for k in LABELS},default_variant='residual',local_shape=[256,2,128,16],
        steps=512,checkpoints=[32,128,256,512],warmup_steps=256,warmup_batch=4,warmup_lr=.001,merger_lr=.0001,
        global_distill_weight=.1,global_scale_floor=.05,local_scale_floor=.05,
        source_initialization='Completed256minute reference/final.pt at512steps. All groups share these weights; source is now256minute-trained. Old16minute runs are not this experiment.',
        method='Full256minute encoder+Cross produce G/L; write G into unchanged L[256,2,128,16]; decoder accepts only merged L. Internal Global condition is read from2sides x4spatial-band means of merged L plus fixed relative-time encoding. No original G, raw book, or per-frame anchor is passed to Local-only decoder.',
        warmup='Candidates only:256steps on cached training G/L to reconstruct frozen-teacher G, plus0.01 normalized Local-shift penalty; no development data, no generator updates. Cost is additional and reported separately.',
        objective_extra='All groups receive0.1 standardized Global-condition distillation to the same frozen256minute teacher during full-book training. Native book loss remains unchanged; candidate native latent_mse penalizes the Local write residual.',
        comparison='Same64training windows,16development windows,seed42,full-book batch1 accumulation4 and512end-to-end updates. Three candidates have equal extra warmup; reference has none. Report prewarm,postwarm and all declared endpoints.',
        acceptance=dict(price_rmse_max_vs_reference=1.10,quantity_rmse_max_vs_reference=1.10,quantity_dynamics_correlation_drop_max=.02,recall100_drop_max=.05),
        scope='Isolate single-Local fusion before further16x1024 compression. Same-size Local is an intermediate bottleneck, not fulfillment of the final16384element state target.',
        viewer_source_label='本轮起点·已训练256分钟参考',viewer_description='完整256分钟Global合并Local实验：训练2022–2024，展示2025Q1开发窗口。三个候选仅保留Local[256,2,128,16]，其解码器需要的内部Global条件也完全由Local计算。原Global＋Local是对照。没有逐帧真实中间价旁路。本轮尚未进一步压成16×1024。',
        viewer_step_note='完整256分钟；三个候选为单一Local瓶颈，未追加16×1024压缩。')
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(parent.parents[1])
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.merge_global_local_run "{remote}"\n')
    Path('/tmp/merge_global_local_256_path').write_text(str(root));print(root,flush=True)


def prepare_teacher(root):
    torch.set_num_threads(4);seed_everything(42);strict_precision();model,norm=load_for_inference(root/'initial.pt','cuda:0');train=dataset(root,'train');indices=np.load(root/'train_indices.npy');parts={k:[] for k in ('global','local','mask','times')}
    atomic_json(root/'status.json',dict(state='caching_training_teacher'))
    with torch.inference_mode():
        for n,index in enumerate(indices):
            b=norm.prepare({k:v.unsqueeze(0) for k,v in train[int(index)].items()},'cuda:0');g,l=model.encode_fused(b['price'],b['volume'],b['mask'],b['tick_norm'],b['times'])
            lm=torch.nn.functional.adaptive_max_pool1d(b['mask'].reshape(512,1,2048).float(),128).reshape(1,256,2,128).bool()
            assert list(g.shape)==[1,256,64] and list(l.shape)==[1,256,2,128,16]
            for key,value in [('global',g),('local',l),('mask',lm),('times',b['times'])]:parts[key].append(value.cpu())
            atomic_json(root/'teacher_progress.json',dict(windows=n+1,total=len(indices)))
    cache={k:torch.cat(v) for k,v in parts.items()};cache['global_scale']=cache['global'].std((0,1)).clamp_min(.05);cache['local_scale']=cache['local'].std((0,1,2,3)).clamp_min(.05)
    atomic_save(cache,root/'teacher_latents.pt');del cache,parts
    val=dataset(root,'val');source_profiles(root,model,norm,val,np.load(root/'val_indices.npy'),root/'source_profiles.npz');del model;torch.cuda.empty_cache()


def write_profiles(root,folder,step,model,norm,original,indices):
    truth=[];predictions=[];masks=[];times=[];locals_saved=[];positions=np.unique(np.linspace(0,len(indices)-1,3,dtype=int));model.eval()
    with torch.inference_mode():
        for pos in positions:
            index=int(indices[pos]);raw={k:v.unsqueeze(0) for k,v in original[index].items()};b=norm.prepare(raw,'cuda:0');out=model(b['price'],b['volume'],b['mask'],b['tick_norm'],b['times'],sample=False)
            assert list(out['volume'].shape)==[1,256,2,2048] and list(out['local_latent'].shape)==[1,256,2,128,16]
            if model.merge_mode!='reference':
                replay=model.decode_local(out['local_latent'],b['mask'],b['tick_norm'],b['times'])
                for key in ('volume','price_norm'):torch.testing.assert_close(out[key],replay[key],rtol=0,atol=0)
                locals_saved.append(out['local_latent'][0].cpu().numpy())
            truth.append(raw['data'][0].numpy());masks.append(b['mask'][0].cpu().numpy());predictions.append(np.stack([norm.inverse_price(out['price_norm'],b)[0].cpu().numpy(),out['volume'][0].cpu().numpy()],-1));start=int(original.base.starts[index]);times.append(original.base.times[start:start+256])
    path=folder/f'step{step}_profiles.npz';temporary=path.with_suffix('.tmp')
    with temporary.open('wb') as f:np.savez_compressed(f,truth=np.stack(truth),prediction=np.stack(predictions),mask=np.stack(masks),time=np.stack(times),indices=indices[positions])
    temporary.replace(path)
    if locals_saved:np.savez_compressed(folder/f'step{step}_local_examples.npz',local=np.stack(locals_saved),indices=indices[positions])


def worker(root,lane):
    torch.set_num_threads(4);seed_everything(42);strict_precision();started=time.monotonic();plan=json.loads((root/'plan.json').read_text());folder=root/lane;folder.mkdir(exist_ok=True)
    payload=torch.load(root/'initial.pt',map_location='cpu',weights_only=False);source,norm=load_for_inference(root/'initial.pt','cpu');del source
    model=GlobalIntoLocalOrderBookVAE(**plan['lanes'][lane],**payload['model_config']);model.load_reference_initial(payload['model']);model.to('cuda:0')
    cache=torch.load(root/'teacher_latents.pt',map_location='cpu',weights_only=False);gscale=cache['global_scale'].to('cuda:0');lscale=cache['local_scale'].to('cuda:0')
    original_train=dataset(root,'train');original_val=dataset(root,'val');ti=np.load(root/'train_indices.npy');vi=np.load(root/'val_indices.npy');train=CacheWindows(original_train,ti);val=CacheWindows(original_val,vi)
    def progress(**value):
        row=dict(value,elapsed_seconds=time.monotonic()-started,reserved_gib=torch.cuda.memory_reserved()/2**30);atomic_json(folder/'progress.json',row)
        with (folder/'progress.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
        print(json.dumps(row),flush=True)
    try:
        atomic_json(folder/'status.json',dict(state='initial_validation'));prewarm=evaluate(model,norm,val,len(val),'cuda:0');model.eval();atomic_json(folder/'prewarm_evaluation.json',dict(result=prewarm))
        if lane=='reference':
            expected=json.loads((root/'expected_reference.json').read_text())['result']['metrics'];delta={k:abs(prewarm['metrics'][k]['rmse']-expected[k]['rmse']) for k in ('price_usdt','quantity_btc')};atomic_json(folder/'initial_replay.json',delta)
            if max(delta.values())>1e-4:raise RuntimeError(f'Exact checkpoint replay failed:{delta}')
        else:
            atomic_json(folder/'status.json',dict(state='warmup'));model.requires_grad_(False);model.local_merger.requires_grad_(True);model.local_readout.requires_grad_(True);model.train()
            opt=torch.optim.AdamW([p for p in model.parameters() if p.requires_grad],lr=plan['warmup_lr'],weight_decay=0.)
            loader=DataLoader(TensorDataset(cache['global'],cache['local'],cache['mask'],cache['times']),batch_size=plan['warmup_batch'],shuffle=True,pin_memory=True,generator=torch.Generator().manual_seed(42));iterator=iter(loader)
            for step in range(1,plan['warmup_steps']+1):
                try:g,l,lm,times=next(iterator)
                except StopIteration:iterator=iter(loader);g,l,lm,times=next(iterator)
                g,l,lm,times=[x.to('cuda:0') for x in (g,l,lm,times)];opt.zero_grad(set_to_none=True)
                with torch.autocast('cuda',dtype=torch.bfloat16):h,ghat=model.merge_latents(g,l,lm,times)
                gl=((ghat.float()-g)/gscale).square().mean();shift=((h.float()-l)/lscale).square().mean();loss=gl+.01*shift
                if not bool(torch.isfinite(loss)):raise FloatingPointError('Nonfinite merger warmup loss')
                loss.backward();torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad],1.,error_if_nonfinite=True);opt.step()
                if step==1 or step%32==0:progress(phase='warmup',step=step,total=plan['warmup_steps'],loss=float(loss.detach()),global_distill=float(gl.detach()),local_shift=float(shift.detach()))
            del iterator,loader,opt;model.requires_grad_(True)
        initial=evaluate(model,norm,val,len(val),'cuda:0');model.eval();atomic_json(folder/'initial_evaluation.json',dict(result=initial))
        model.requires_grad_(True);groups={}
        for name,p in model.named_parameters():
            key='merger' if name.startswith(('local_merger.','local_readout.')) else 'encoder' if name.startswith(('encoder.','fusion.')) else 'decoder';groups.setdefault(key,[]).append(p)
        opt=torch.optim.AdamW([dict(params=ps,lr=plan[key+'_lr']) for key,ps in groups.items()],weight_decay=0.);criterion=QuantizedBookLoss();loader=DataLoader(train,batch_size=1,shuffle=True,num_workers=2,persistent_workers=True,pin_memory=True,generator=torch.Generator().manual_seed(42));iterator=iter(loader)
        modules=dict(encoder=model.encoder,fusion=model.fusion,price_decoder=model.price_decoder,volume_decoder=model.volume_decoder,volume_refinement=model.volume_refinement)
        if lane!='reference':modules['local_readout']=model.local_readout
        if lane in ('residual','attention'):modules['local_merger']=model.local_merger
        atomic_json(folder/'trainable_modules.json',{k:dict(parameters=sum(p.numel() for p in m.parameters()),trainable=sum(p.numel() for p in m.parameters() if p.requires_grad)) for k,m in modules.items()})
        config=deepcopy(payload['config']);config['arguments'].update(window_size=256,stride=256,batch_size=1,accumulation_steps=4,precision='bf16',npz_dir=str(root/'data/BTCUSDT.npz'))
        def save(path,step,full=False):
            value=dict(format_version=1,model=model.state_dict(),model_config=payload['model_config'],global_local_merge_config=model.global_local_merge_config,config=config,step=step,source_hashes=source_hashes(),initial_checkpoint=str(root/'initial.pt'))
            if full:value.update(optimizer=opt.state_dict(),sampler_generator_state=loader.generator.get_state(),torch_rng_state=torch.get_rng_state(),cuda_rng_state=torch.cuda.get_rng_state_all(),epoch_boundary=step*plan['accumulation']%len(train)==0)
            atomic_save(value,path)
        atomic_json(folder/'status.json',dict(state='training'))
        for step in range(1,plan['steps']+1):
            model.train();opt.zero_grad(set_to_none=True);record={}
            for micro in range(plan['accumulation']):
                try:raw=next(iterator)
                except StopIteration:iterator=iter(loader);raw=next(iterator)
                assert list(raw['data'].shape)==[1,256,2,2048,2];b=norm.prepare(raw,'cuda:0');target=cache['global'][raw['cache_position']].to('cuda:0')
                with torch.autocast('cuda',dtype=torch.bfloat16):out=model(b['price'],b['volume'],b['mask'],b['tick_norm'],b['times'],sample=False)
                values=criterion(out,b);gd=((out['global_readout'].float()-target)/gscale).square().mean();loss=values['loss']+plan['global_distill_weight']*gd
                if not bool(torch.isfinite(loss)):raise FloatingPointError('Nonfinite end-to-end loss')
                (loss/plan['accumulation']).backward()
                for key,value in [('loss',loss),('global_distill',gd),('temporal_quantity',values['temporal_quantity']),('volume_log',values['volume_log'])]:record[key]=record.get(key,0.)+float(value.detach())/plan['accumulation']
                if step==1 and micro==0:
                    assert list(out['local_latent'].shape)==[1,256,2,128,16] and list(out['volume'].shape)==[1,256,2,2048]
                    atomic_json(folder/'actual_shape_contract.json',dict(raw_input=list(raw['data'].shape),price_output=list(out['price_norm'].shape),quantity_output=list(out['volume'].shape),matrix=list(out['local_latent'].shape) if lane!='reference' else None,local_shape=list(out['local_latent'].shape),independent_global_decoder_input=lane=='reference',readout_global_is_function_of_local=lane!='reference'))
            if step==1:
                norms={k:sum(float(p.grad.detach().square().sum()) for p in m.parameters() if p.grad is not None)**.5 for k,m in modules.items()};atomic_json(folder/'first_step_gradient_norms.json',norms)
                if any(not np.isfinite(x) or x<=0 for x in norms.values()):raise RuntimeError(f'Missing full-model gradients:{norms}')
            torch.nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True);opt.step()
            if step==1 or step%8==0:progress(phase='end_to_end',step=step,total=plan['steps'],**record)
            if step in plan['checkpoints']:
                dev=evaluate(model,norm,val,len(val),'cuda:0');model.eval();atomic_json(folder/f'step{step}_evaluation.json',dict(result=dev));seen=evaluate(model,norm,train,plan['seen_windows'],'cuda:0');model.eval();atomic_json(folder/f'step{step}_seen_evaluation.json',dict(result=seen));save(folder/f'step{step}.pt',step,True);write_profiles(root,folder,step,model,norm,original_val,vi);save(folder/'latest.pt',step)
        save(folder/'final.pt',step);atomic_json(folder/'final_evaluation.json',dict(result=dev));atomic_json(folder/'status.json',dict(state='complete',step=step,elapsed_seconds=time.monotonic()-started))
    except BaseException as error:atomic_json(folder/'status.json',dict(state='failed',error=repr(error)));raise


def campaign(root):
    plan=json.loads((root/'plan.json').read_text());started=time.monotonic();children=[]
    try:
        prepare_teacher(root)
        for gpu,lane in zip((2,3,4,5),plan['lanes']):
            env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),CUDA_DEVICE_ORDER='PCI_BUS_ID',PYTHONPATH=str(root/'source_snapshot'))
            with (root/'logs'/(lane+'.log')).open('ab',buffering=0) as log:p=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.merge_global_local_run',str(root),'--lane',lane],cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            children.append((lane,gpu,p))
        atomic_json(root/'status.json',dict(state='running',children=[dict(lane=l,gpu=g,pid=p.pid) for l,g,p in children]))
        while any(p.poll() is None for _,_,p in children):
            if time.monotonic()-started>plan['max_seconds']:raise TimeoutError('12hour ceiling reached')
            time.sleep(5)
        failures={l:p.returncode for l,_,p in children if p.returncode!=0};atomic_json(root/'status.json',dict(state='partial_failure' if failures else 'complete',failures=failures,elapsed_seconds=time.monotonic()-started))
    except BaseException as error:atomic_json(root/'status.json',dict(state='failed',error=repr(error)));raise
    finally:
        for _,_,p in children:
            if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--lane');args=p.parse_args()
    if args.prepare:prepare(args.root)
    elif args.lane:worker(args.root,args.lane)
    else:campaign(args.root)
