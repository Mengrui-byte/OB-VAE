"""Numerically orthonormalize fitted PCA bases without altering fit history."""

import argparse
import json
from pathlib import Path

import torch

from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import atomic_save


def orthogonalize(root):
    torch.set_num_threads(4);strict_precision()
    plan=json.loads((root/'plan.json').read_text());fit=json.loads((root/'pca_fit.json').read_text())
    basis=torch.load(root/'pca_basis.pt',map_location='cpu',weights_only=False);errors={}
    for group in ('global','local'):
        old=basis[group+'_basis'].to(device='cuda:0',dtype=torch.float64)
        q,_=torch.linalg.qr(old.T,mode='reduced');rows=q.T.float().contiguous()
        double=rows.double();errors[group]=float((double@double.T-torch.eye(len(rows),device='cuda:0',dtype=torch.float64)).abs().max())
        basis[group+'_basis']=rows.cpu()
        del old,q,rows,double
    atomic_save(basis,root/'pca_basis_qr.pt')
    cached=torch.load(root/'decoder_latents.pt',map_location='cpu',weights_only=False)
    ng=fit['global_components'];device_basis={k:v.to('cuda:0') for k,v in basis.items()}
    gc,lc=[],[];gtotal=ltotal=0.
    with torch.inference_mode():
        for start in range(0,len(cached['global']),128):
            g=cached['global'][start:start+128].to('cuda:0').reshape(-1,len(basis['global_mean']))
            l=cached['local'][start:start+128].to('cuda:0').reshape(-1,len(basis['local_mean']))
            g=(g-device_basis['global_mean'])/device_basis['global_scale'];l=(l-device_basis['local_mean'])/device_basis['local_scale']
            gc.append((g@device_basis['global_basis'].T).cpu());lc.append((l@device_basis['local_basis'].T).cpu())
            gtotal+=float(g.double().square().sum());ltotal+=float(l.double().square().sum())
    gc,lc=torch.cat(gc),torch.cat(lc);dimensions={}
    for dimension in plan['state_dimensions']:
        states=torch.cat([gc,lc[:,:dimension-ng]],1)
        atomic_save(dict(states=states),root/f'train_states_qr_{dimension}.pt')
        dimensions[str(dimension)]=dict(global_components=ng,local_components=dimension-ng,
             global_variance_retained=float(gc.double().square().sum())/gtotal,
             local_variance_retained=float(lc[:,:dimension-ng].double().square().sum())/ltotal)
    audit=dict(reason='Remove finite-precision SVD orthogonality error before using transpose reconstruction',
               original_basis='pca_basis.pt',verified_basis='pca_basis_qr.pt',orthogonality_error_cpu_equivalent_fp64=errors,
               dimensions=dimensions,fit_split='training only; no new data or development fitting')
    atomic_json(root/'pca_qr_audit.json',audit)
    atomic_json(root/'basis_selection.json',dict(basis_file='pca_basis_qr.pt',state_pattern='train_states_qr_{dimension}.pt',audit_file='pca_qr_audit.json'))
    print(json.dumps(audit),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);orthogonalize(p.parse_args().root)
