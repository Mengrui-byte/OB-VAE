"""Describe exact-level peak errors from existing reconstruction caches only."""
import argparse
import hashlib
import html
import json
from pathlib import Path

import numpy as np

from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import STYLE
from train_dual.util.checkpoint import freeze_sources


def nearest_rank(events):
    index=np.arange(events.shape[-1])
    left=np.maximum.accumulate(np.where(events,index,-100000),axis=-1)
    right=np.minimum.accumulate(np.where(events,index,100000)[...,::-1],axis=-1)[...,::-1]
    return np.minimum(index-left,right-index)


def time_near(events,radius):
    result=events.copy()
    for lag in range(1,min(radius+1,events.shape[1])):
        result[:,lag:]|=events[:,:-lag]
        result[:,:-lag]|=events[:,lag:]
    return result


def analyze(truth,prediction,mask,threshold=100.):
    truth=np.asarray(truth);prediction=np.asarray(prediction);mask=np.asarray(mask,dtype=bool)
    if truth.shape!=prediction.shape or truth.shape!=mask.shape or truth.ndim!=4 or truth.shape[2]!=2:
        raise ValueError('Expected matching [windows,time,2,levels] quantities andmask')
    if not np.isfinite(truth[mask]).all() or not np.isfinite(prediction[mask]).all():raise ValueError('Nonfinite valid quantity')
    actual=mask&(truth>=threshold);predicted=mask&(prediction>=threshold)
    fp=predicted&~actual;fn=actual&~predicted;tp=actual&predicted
    nf=int(fp.sum());na=int(actual.sum());nt=int(tp.sum());npred=int(predicted.sum())
    distance_true=nearest_rank(actual);distance_pred=nearest_rank(predicted)
    radii=[0,1,2,4,8,16,32]
    return dict(true_events=na,predicted_events=npred,tp=nt,fp=nf,fn=int(fn.sum()),
        exact_recall=nt/na if na else None,exact_precision=nt/npred if npred else None,
        fp_true_quantity_bins={f'{lo:g}to{hi:g}':int((fp&(truth>=lo)&(truth<hi)).sum()) for lo,hi in [(0,1),(1,10),(10,50),(50,100)]},
        fp_predicted_quantity_bins={label:int((fp&(prediction>=lo)&(prediction<hi)).sum()) for label,lo,hi in [('100to125',100,125),('125to200',125,200),('200to500',200,500),('500plus',500,np.inf)]},
        fp_near_true_same_frame_rank={str(r):int((fp&(distance_true<=r)).sum()) for r in radii},
        fn_near_prediction_same_frame_rank={str(r):int((fn&(distance_pred<=r)).sum()) for r in radii},
        fp_near_true_same_rank_time={str(r):int((fp&time_near(actual,r)).sum()) for r in [0,1,2,4]},
        median_true_at_fp=float(np.median(truth[fp])) if nf else None,
        median_prediction_at_fp=float(np.median(prediction[fp])) if nf else None,
        median_prediction_at_true_event=float(np.median(prediction[actual])) if na else None,
        max_prediction=float(prediction[mask].max()) if mask.any() else None)


def run(goal):
    parent=goal/'round_001_mid_tail';root=goal/'peak_errors_2048';root.mkdir()
    labels=dict(baseline='Baseline',mid='Mid protection',tail='Tail penalty',both='Combined')
    val=np.load(parent/'val_indices.npy');expected=val[np.unique(np.linspace(0,len(val)-1,3,dtype=int))]
    plan=dict(source=str(parent),steps=[1024,2048],labels=labels,threshold=100.,original_indices=expected.tolist(),
        scope='Existing3profile windows are a subset of the same repeatedly used16Q1development windows, not another test. Exact same t/side/level metric remains the goal. Spatial/temporal proximity is descriptive, allows many-to-one neighbors, is not event matching and must not be called relaxed recall. No model execution, no training, noQ2reads.')
    atomic_json(root/'plan.json',plan);freeze_sources(root/'source_snapshot')
    rows=[];hashes={};reference=None
    for lane in labels:
        for step in plan['steps']:
            path=parent/lane/f'step{step}_profiles.npz';hashes[str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
            with np.load(path) as data:
                assert np.array_equal(data['indices'],expected)
                if reference is None:reference={k:data[k].copy() for k in ['truth','mask','time']}
                else:
                    for key in reference:assert np.array_equal(reference[key],data[key])
                rows.append(dict(lane=lane,step=step,**analyze(data['truth'][...,1],data['prediction'][...,1],data['mask'])))
    atomic_json(root/'results.json',dict(rows=rows,scope=plan['scope'],input_sha256=hashes,truth_time_mask_identical=True))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(1,2,figsize=(12,4.2),constrained_layout=True)
    endpoint=[r for r in rows if r['step']==2048];x=np.arange(len(endpoint));bottom=np.zeros(len(endpoint))
    for key in endpoint[0]['fp_true_quantity_bins']:
        values=np.array([r['fp_true_quantity_bins'][key] for r in endpoint]);axes[0].bar(x,values,bottom=bottom,label=key);bottom+=values
    axes[0].set_xticks(x,[labels[r['lane']] for r in endpoint],rotation=15);axes[0].set_ylabel('False positive count');axes[0].set_title('True BTC quantity at false predictions');axes[0].legend(title='True quantity',fontsize=8)
    radii=[0,1,2,4,8,16,32]
    for row in endpoint:
        if row['fp']:axes[1].plot(range(len(radii)),[100*row['fp_near_true_same_frame_rank'][str(r)]/row['fp'] for r in radii],marker='o',label=labels[row['lane']])
    axes[1].set_xticks(range(len(radii)),radii);axes[1].set_xlabel('Rank distance in the same frame and side');axes[1].set_ylabel('FP near a true >=100BTC event (%)');axes[1].set_title('Descriptive proximity, not relaxed recall');axes[1].legend(fontsize=8)
    fig.savefig(root/'diagnostics.png',dpi=160);plt.close(fig)
    def fmt(v):return '—' if v is None else f'{v:.3f}' if isinstance(v,float) else str(v)
    text='<!doctype html><meta charset="utf-8"><title>大单误报位置诊断</title><style>'+STYLE+'</style><main><h1>大单误报：位置偏移还是背景响应</h1><p>使用既有3个完整256分钟绘图窗口，原始开发索引'+str(expected.tolist())+'；它们是固定16个Q1开发窗口的子集，不是新测试集。8份重建缓存的真值、mask与时间完全一致，未执行模型、未更新参数。</p><p>目标仍是严格同帧、同侧、同档位≥100BTC召回。邻域比例允许多个误报靠近同一真实大单，只描述空间或时间邻近，不进行一对一匹配，不作为达标指标。</p><img src="diagnostics.png" alt="误报的真实挂量及邻档分布"><table><tr><th>方案</th><th>步数</th><th>真大单</th><th>TP</th><th>FP</th><th>严格召回</th><th>精确率</th><th>FP同帧距真大单≤2档</th><th>FP真实挂量中位数</th></tr>'
    for row in rows:
        vals=[labels[row['lane']],row['step'],row['true_events'],row['tp'],row['fp'],row['exact_recall'],row['exact_precision'],row['fp_near_true_same_frame_rank']['2']/row['fp'] if row['fp'] else None,row['median_true_at_fp']]
        text+='<tr>'+''.join('<td>'+html.escape(fmt(v))+'</td>' for v in vals)+'</tr>'
    text+='</table><p>上表召回与精确率用0–1小数表示。样本数及分母不同，不能将3窗口数值替换16窗口正式开发结果。跨侧、跨样本及窗口首尾均不连接；无效档位不能提供邻域证据。</p><p><a href="results.json">逐项计数、输入哈希</a> · <a href="plan.json">诊断范围</a> · <a href="../round_001_mid_tail/">16窗口主实验</a></p></main>'
    (root/'index.html').write_text(text);atomic_json(root/'status.json',dict(state='complete',model_executions=0,optimizer_updates=0,rows=len(rows)))
    print(root,flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('goal',type=Path);a=p.parse_args();run(a.goal.resolve())
