"""Streaming peak-location metrics, separate from actual quantity recovery."""
import numpy as np
import torch

from model.losses.peak_book import balanced_peak_bce
from train_dual.experiments.unified_8192_run import call


def histogram_ap(positive,negative):
    total=positive.sum()
    if total==0:return None
    tp=np.cumsum(positive[::-1],dtype=np.float64)
    fp=np.cumsum(negative[::-1],dtype=np.float64)
    precision=tp/np.maximum(tp+fp,1)
    recall=tp/total
    return float(np.sum(np.diff(np.r_[0.,recall])*precision))


def evaluate_peak_aux(model,norm,data,device,threshold=10.,bins=4096):
    model.eval();poshist=np.zeros(bins,dtype=np.int64);neghist=poshist.copy()
    counts={str(t):dict(tp=0,fp=0,fn=0,tn=0) for t in [.1,.5,.9]}
    positive_n=negative_n=0;positive_score=negative_score=positive_prediction=positive_target=loss_sum=0.
    with torch.inference_mode():
        for i in range(len(data)):
            raw={k:v.unsqueeze(0) for k,v in data[i].items()};b=norm.prepare(raw,device);out=call(model,b,False)
            scores=out['peak_logits'].float().sigmoid();mask=b['mask'];positive=mask&(b['volume']>=threshold);negative=mask&~positive
            if not bool(torch.isfinite(scores).all()):raise FloatingPointError('Nonfinite auxiliary scores')
            index=(scores*(bins-1)).long()
            poshist+=torch.bincount(index[positive],minlength=bins).cpu().numpy()
            neghist+=torch.bincount(index[negative],minlength=bins).cpu().numpy()
            positive_n+=int(positive.sum());negative_n+=int(negative.sum())
            positive_score+=float(scores[positive].sum());negative_score+=float(scores[negative].sum())
            positive_prediction+=float(out['volume'][positive].sum());positive_target+=float(b['volume'][positive].sum())
            loss_sum+=float(balanced_peak_bce(out['peak_logits'],b['volume'],mask,threshold))
            for t in [.1,.5,.9]:
                predicted=scores>=t;c=counts[str(t)]
                c['tp']+=int((predicted&positive).sum());c['fp']+=int((predicted&negative).sum())
                c['fn']+=int((~predicted&positive).sum());c['tn']+=int((~predicted&negative).sum())
    for c in counts.values():
        c['precision']=c['tp']/(c['tp']+c['fp']) if c['tp']+c['fp'] else None
        c['recall']=c['tp']/(c['tp']+c['fn']) if c['tp']+c['fn'] else None
    return dict(windows=len(data),label_quantity_threshold_btc=threshold,positive_levels=positive_n,negative_levels=negative_n,
        prevalence=positive_n/max(1,positive_n+negative_n),balanced_bce_mean=loss_sum/max(1,len(data)),
        histogram_average_precision=histogram_ap(poshist,neghist),histogram_bins=bins,
        fixed_probability_thresholds=counts,mean_score_positive=positive_score/max(1,positive_n),mean_score_negative=negative_score/max(1,negative_n),
        mean_reconstructed_quantity_at_true_peaks_btc=positive_prediction/max(1,positive_n),mean_true_quantity_at_peaks_btc=positive_target/max(1,positive_n),
        note='Auxiliary location at>=10BTC is distinct from actual reconstructed quantity threshold recall. AP approximated by4096score bins; all-tied untrained score AP equals prevalence. Balanced BCE scores need not be calibrated probabilities. All valid levels, FP32, no test data.')
