"""Describe naturally learned small matrix codebooks without training semantic heads."""

import argparse
from datetime import datetime
import json
from pathlib import Path
import shutil

import numpy as np

from train_dual.experiments.book_stem_viewer import build
from train_dual.experiments.paired_state_analysis import FEATURES, association, bh, eta, group_profiles
from train_dual.experiments.paired_second_code_analysis import entropy
from train_dual.util.checkpoint import freeze_sources


EXTRA = [('detrended_rms_bps','去趋势价格路径RMS','bp'),
         ('range_bps','窗口价格范围','bp'),('curvature_bps_min','后半段减前半段斜率','bp/min'),
         ('drawdown_bps','窗口最高点至终点回撤','bp'),('depth_cv','深度时间变动系数',''),
         ('imbalance_std','深度不平衡时间标准差','')]
LABELS={'k8_l8':'8级×8码','k16_l8':'8级×16码','k32_l8':'8级×32码','k16_l16':'16级×16码'}


def extend_features(z):
    p=z['curves'][:,0];t=np.arange(16,dtype=float);tc=t-t.mean()
    slope=(p@tc)/(tc@tc);detrended=p-p.mean(1,keepdims=True)-slope[:,None]*tc
    tc8=np.arange(8,dtype=float)-3.5
    curvature=(p[:,8:]@tc8-p[:,:8]@tc8)/(tc8@tc8)
    side=z['curves'][:,1:];depth=side.sum(1)
    imbalance=(side[:,0]-side[:,1])/np.maximum(depth,1e-12)
    extra=np.stack([np.sqrt(np.square(detrended).mean(1)),np.ptp(p,axis=1),curvature,
                    p.max(1)-p[:,-1],depth.std(1)/np.maximum(depth.mean(1),1e-12),imbalance.std(1)],1)
    return np.concatenate([z['values'],extra],1)


def conditional_association(y,codes,months,level,permutations=999):
    # Parent groups include every previous code and the calendar month.
    _,month=np.unique(months,return_inverse=True)
    parent=np.column_stack([codes[:,:level],month])
    _,parent_index=np.unique(parent,axis=0,return_inverse=True)
    current=codes[:,level]
    _,child=np.unique(np.column_stack([parent_index,current]),axis=0,return_inverse=True)
    base=eta(y,parent_index)
    denominator=1-base;valid=denominator>1e-12
    def gain(new_child):
        return np.divide(eta(y,new_child)-base,denominator,out=np.zeros_like(base),where=valid)
    observed=gain(child);rng=np.random.default_rng(42)
    groups=[np.flatnonzero(parent_index==p) for p in np.unique(parent_index)]
    movable=[ix for ix in groups if len(ix)>1 and len(np.unique(current[ix]))>1]
    if not movable:
        null=np.zeros((permutations,y.shape[1]))
    else:
        values=[]
        for _ in range(permutations):
            shuffled=current.copy()
            for ix in movable:shuffled[ix]=rng.permutation(current[ix])
            _,shuffled_child=np.unique(np.column_stack([parent_index,shuffled]),axis=0,return_inverse=True)
            values.append(gain(shuffled_child))
        null=np.asarray(values)
    null_mean=null.mean(0)
    p=(1+(null>=observed-1e-12).sum(0))/(len(null)+1)
    return dict(eta_squared=observed.tolist(),null_mean=null_mean.tolist(),
        excess_eta_squared=np.divide(observed-null_mean,1-null_mean,out=np.zeros_like(base),where=(1-null_mean)>1e-12).tolist(),
        permutation_p=p.tolist(),parent_groups=len(groups),movable_windows=sum(len(ix) for ix in movable),
        note='Conditional on all preceding code indices and calendar month; insufficient within-parent variation is not evidence of absence of residual information.')


def r2(truth,prediction):
    return (1-np.square(truth-prediction).sum(0)/np.maximum(np.square(truth-truth.mean(0)).sum(0),1e-30)).tolist()


def describe(raw,codes,size,level):
    values=raw['values'];label=codes[:,level];counts=np.bincount(label,minlength=size)
    h=entropy(label)
    return dict(groups=group_profiles(values,label,raw['profiles'],raw['curves']),used=int((counts>0).sum()),
        entropy_bits=h,perplexity=2**h,counts=counts.tolist(),largest_fraction=float(counts.max()/len(label)),
        singleton_codes=int((counts==1).sum()),prefixes=int(len(np.unique(codes[:,:level+1],axis=0))),
        conditional_entropy_bits=max(0.,entropy(codes[:,:level+1])-(entropy(codes[:,:level]) if level else 0.)))


PAGE='''<!doctype html><html lang=zh-CN><meta charset=utf-8><title>小codebook自然分类</title><script src=plotly.min.js></script><style>body{font:16px system-ui;max-width:1500px;margin:25px auto;padding:0 20px;color:#182b43}p{line-height:1.8}select{font:inherit;padding:5px}table{border-collapse:collapse;width:100%}td,th{padding:7px;border:1px solid #ddd}.plots{display:grid;grid-template-columns:1fr 1fr}a{color:#2563eb}</style><h1>小codebook自然分出了什么？</h1><p>原Cross编码器、生成器冻结；联合双矩阵、原始无权重L2距离、随机成对样本初始化、每级12轮、种子42保持一致。不加语义头、占用正则、分支缩放或未来收益目标。8192训练窗口拟合，128个2025Q1开发窗口审计；独立2025Q2未使用。以下特征仅作训练后的解释，没有用于拟合、选码或挑选检查点。</p><p><a href=./>小码本逐档重建</a> · <a href=previous/>上一轮重建</a> · <a href=small_analysis.json>完整分析</a></p><h2>各方案最后一级的重建</h2><table><thead><tr><th>方案</th><th>逻辑索引bit</th><th>码本MiB</th><th>价格RMSE USDT</th><th>数量RMSE BTC</th><th>≥100BTC召回</th></tr></thead><tbody id=books></tbody></table><p>8级×8/16/32码分别24/32/40bit；16级×16码为64bit，与旧8级×256码索引码率相同，但码本大小、深度和计算路径不同。模型和元数据未计入索引码率，整数码未位打包。类别编号本身没有经济意义。</p><p>方案 <select id=variant></select> 级别 <select id=level></select> 数据 <select id=split><option value=development>开发128窗口</option><option value=train>训练8192窗口</option></select> 类别 <select id=code></select></p><p id=summary></p><div class=plots><div id=occupancy></div><div id=information></div></div><div id=heat></div><div class=plots><div id=path></div><div id=profile></div></div><h2>当前级别自然关联哪些特征？</h2><p>边际R²用训练期本级类均值估计开发窗口内已发生的特征；前缀R²逐级使用训练期同码组合均值，仅在训练支持≥20时更新，否则回退到上一级。负值表示不如开发整体常数。条件检验控制前面全部级别和月份，在组内置换本级标签；若可置换样本少，无法可靠判断新增语义。999次置换，全部方法/级别/特征/三种检验统一BH校正。</p><table><thead><tr><th>特征</th><th>开发类间超随机η²</th><th>BH q</th><th>按月超随机η²</th><th>BH q</th><th>前级+月份条件增量η²</th><th>BH q</th><th>本级边际R²</th><th>前缀R²</th><th>前缀ΔR²</th></tr></thead><tbody id=associations></tbody></table><h2>选中类别的原始单位特征</h2><table><thead><tr><th>特征</th><th>类别均值</th><th>整体均值</th><th>训练同级同码均值</th><th>单位</th></tr></thead><tbody id=features></tbody></table><p>波动、路径、挂量之间可以存在真实关联；不要求不同级别完全独立。有效码数高不等于语义可靠，单样本码不赋予经济名称。全前缀变成稀疏组合后，条件检验和前缀估计会受样本量限制。</p><script>let d;const $=x=>document.getElementById(x),f=(x,n=3)=>Number.isFinite(x)?x.toFixed(n):'—';function rows(id,a){$(id).replaceChildren(...a.map(x=>{let r=document.createElement('tr');for(let v of x){let c=document.createElement('td');c.textContent=v;r.append(c)}return r}))}function plot(id,a,title){Plotly.react(id,a,{height:390,title,template:'plotly_white',margin:{t:60,b:90,l:85}},{responsive:true,displaylogo:false})}function levels(){let v=d.variants[$('variant').value];$('level').replaceChildren(...v.levels.map((_,i)=>new Option('第'+(i+1)+'级',i)));fill()}function fill(){let v=d.variants[$('variant').value],x=v.levels[+$('level').value],s=$('split').value;$('code').replaceChildren(...x[s].groups.map(g=>new Option(g.code+'（n='+g.count+'）',g.code)));draw()}function draw(){let v=d.variants[$('variant').value],i=+$('level').value,x=v.levels[i],s=$('split').value,z=x[s],r=z.groups.find(g=>g.code==$('code').value),tr=x.train.groups.find(g=>g.code===r.code),a=x.association,base=d.splits[s].mean;plot('occupancy',['train','development'].map(k=>({x:v.levels.map((_,j)=>j+1),y:v.levels.map(z=>z[k].perplexity),name:k==='train'?'训练':'开发',mode:'lines+markers'})),'各级有效码数2^H');plot('information',['train','development'].map(k=>({x:v.levels.map((_,j)=>j+1),y:v.levels.map(z=>z[k].conditional_entropy_bits),name:k==='train'?'训练':'开发',mode:'lines+markers'})),'给定全部前级的条件熵bit（经验值）');let groups=z.groups.filter(g=>g.count>=(s==='train'?20:3));plot('heat',[{type:'heatmap',x:d.features.map(f=>f[1]),y:groups.map(g=>g.code+' n='+g.count),z:groups.map(g=>g.mean.map((val,j)=>(val-base[j])/Math.max(d.splits[s].std[j],1e-12))),colorscale:'RdBu',zmid:0}],'类内特征偏离（相对整体标准差）');plot('path',[{x:Array.from({length:16},(_,j)=>j),y:r.mean_curves[0],mode:'lines+markers'}],'本级码 '+r.code+' 的平均价格路径（bp）');plot('profile',[0,1].map(k=>({x:Array.from({length:32},(_,j)=>j*64+32),y:r.profile[k],name:k?'卖盘':'买盘',mode:'lines+markers'})),'同码窗口的平均原始挂量轮廓');rows('associations',d.features.map((ftr,j)=>[ftr[1],f(a.raw.excess_eta_squared[j]),f(a.raw.bh_q[j]),f(a.within_month.excess_eta_squared[j]),f(a.within_month.bh_q[j]),f(a.conditional.excess_eta_squared[j]),f(a.conditional.bh_q[j]),f(x.marginal_r2[j]),f(x.prefix_r2[j]),f(x.prefix_delta_r2[j])]));rows('features',d.features.map((ftr,j)=>[ftr[1],f(r.mean[j]),f(base[j]),tr?f(tr.mean[j]):'—',ftr[2]]));$('summary').textContent='本级使用 '+z.used+'/'+v.size+' 码，有效码数 '+f(z.perplexity)+'；最大码占比 '+f(z.largest_fraction*100,1)+'%；单样本码 '+z.singleton_codes+'；当前类n='+r.count+'。开发条件检验可置换窗口 '+a.conditional.movable_windows+'/128；本级训练支持≥20的开发前缀覆盖 '+f(x.prefix_supported_fraction*100,1)+'%。'}fetch('small_analysis.json').then(x=>x.json()).then(x=>{d=x;$('variant').replaceChildren(...Object.entries(d.variants).map(([k,v])=>new Option(v.label,k)));$('variant').value='k16_l8';rows('books',d.books.map(x=>[x.label,x.bits==null?'连续':x.bits,f(x.codebook_mib,1),f(x.price_rmse),f(x.quantity_rmse),f(x.large_recall*100,1)+'%']));levels()});$('variant').onchange=levels;$('level').onchange=fill;$('split').onchange=fill;$('code').onchange=draw;</script></html>'''


def create_book_viewer(root,plan,labels=None):
    labels=labels or LABELS
    folder=root/'report';folder.mkdir(exist_ok=True)
    with np.load(root/'source_profiles.npz') as p:
        arrays={k:p[k] for k in ('truth','mask','time','indices')};arrays['source']=p['prediction']
    config=[dict(key='truth',label='真实订单簿',color='#2563eb'),dict(key='source',label='未压缩Cross',color='#64748b')]
    parent=Path(plan['parent']);selected=[(parent/'joint_l2/depth8','old256','旧8级×256码')]
    selected += [(root/lane/f"depth{spec['levels']}",lane,labels[lane]) for lane,spec in plan['lanes'].items()]
    for (source,key,label),color in zip(selected,['#94a3b8','#eab308','#2563eb','#9333ea','#16a34a']):
        with np.load(source/'profiles.npz') as p:
            np.testing.assert_array_equal(p['truth'],arrays['truth']);arrays[key]=p['prediction']
        config.append(dict(key=key,label=label,color=color))
    np.savez_compressed(folder/'profiles.npz',**arrays)
    (folder/'comparison.json').write_text(json.dumps(dict(viewer_variants=config,default_model=4,seed=42,
        common_step=plan['fit_iterations'],step_note='冻结Cross；小双矩阵码本；无语义约束；严格FP32。',
        comparison_label='小codebook分类与逐级特征',plan=plan),ensure_ascii=False))
    (folder/'index.html').write_text('<!doctype html><meta charset=utf-8><meta http-equiv=refresh content="0;url=../small.html">')
    viewer=root/'viewer';build(folder,viewer)
    return viewer


def main(root,labels=None,page=None,previous=None):
    labels=labels or LABELS
    root=root.resolve();plan=json.loads((root/'plan.json').read_text())
    if json.loads((root/'status.json').read_text())['state']!='complete':raise RuntimeError('Workers not complete')
    feature_source=Path(plan.get('features_source',str(Path(plan['parent'])/'analysis/market_states_20261025_140914')));folder=root/'analysis';folder.mkdir(exist_ok=True)
    shutil.copy2(__file__,folder/'analysis_source.py')
    raw={};splits={}
    for split in ('train','development'):
        z=dict(np.load(feature_source/(split+'_features.npz')));z['values']=extend_features(z);raw[split]=z
        np.savez_compressed(folder/(split+'_features.npz'),**z)
        splits[split]=dict(windows=len(z['values']),mean=z['values'].mean(0).tolist(),std=z['values'].std(0).tolist())
    trainy=raw['train']['values'];devy=raw['development']['values']
    months=raw['development']['times'].astype('datetime64[us]').astype('datetime64[M]').astype(str)
    variants={};pointers=[];pvalues=[];books=[]
    def book(label,folder,depth,bits,codebook_mib):
        value=json.loads((folder/(f'depth{depth}_evaluation.json' if depth else 'original_evaluation.json')).read_text())['result']
        books.append(dict(label=label,bits=bits,codebook_mib=codebook_mib,price_rmse=value['metrics']['price_usdt']['rmse'],
            quantity_rmse=value['metrics']['quantity_btc']['rmse'],large_recall=value['thresholds']['100']['recall']))
    first=next(iter(plan['lanes']));book('未压缩Cross',root/first,0,None,0.)
    book('旧8级×256码',Path(plan['parent'])/'joint_l2',8,64,520.)
    for lane,spec in plan['lanes'].items():
        stored=dict(np.load(root/lane/'codes.npz'))
        np.testing.assert_array_equal(stored['development_indices'],raw['development']['indices'])
        np.testing.assert_array_equal(np.load(root/'fit_indices.npy'),raw['train']['indices'])
        tc,dc=stored['train'],stored['development'];previous_pred=np.tile(trainy.mean(0),(len(devy),1));levels=[]
        prev_r2=np.asarray(r2(devy,previous_pred))
        for level in range(spec['levels']):
            row={split:describe(raw[split],stored[split],spec['size'],level) for split in raw}
            a=association(devy,dc[:,level],months);a['conditional']=conditional_association(devy,dc,months,level)
            row['association']=a
            for name in ('raw','within_month','conditional'):
                for j,p in enumerate(a[name]['permutation_p']):pointers.append((a[name],j));pvalues.append(p)
            means=np.tile(trainy.mean(0),(spec['size'],1))
            for code in np.unique(tc[:,level]):means[code]=trainy[tc[:,level]==code].mean(0)
            row['marginal_r2']=r2(devy,means[dc[:,level]])
            paths,inverse,counts=np.unique(tc[:,:level+1],axis=0,return_inverse=True,return_counts=True)
            sums=np.stack([np.bincount(inverse,weights=y,minlength=len(paths)) for y in trainy.T],1)
            mapping={tuple(paths[i]):sums[i]/counts[i] for i in np.flatnonzero(counts>=20)}
            pred=previous_pred.copy();supported=0
            for i,path in enumerate(dc[:,:level+1]):
                mean=mapping.get(tuple(path))
                if mean is not None:pred[i]=mean;supported+=1
            current_r2=np.asarray(r2(devy,pred));row['prefix_r2']=current_r2.tolist()
            row['prefix_delta_r2']=(current_r2-prev_r2).tolist();row['prefix_supported_fraction']=supported/len(devy)
            levels.append(row);previous_pred=pred;prev_r2=current_r2
            print(json.dumps(dict(lane=lane,level=level+1,development_used=row['development']['used'],
                perplexity=row['development']['perplexity'],conditional_test_windows=a['conditional']['movable_windows'])),flush=True)
        summary=json.loads((root/lane/'comparison.json').read_text())
        variants[lane]=dict(label=labels[lane],size=spec['size'],levels=levels)
        book(labels[lane],root/lane,spec['levels'],summary['logical_bits'],summary['codebook_bytes']/2**20)
    for (item,j),q in zip(pointers,bh(pvalues)):
        if 'bh_q' not in item:item['bh_q']=[0.]*len(FEATURES+EXTRA)
        item['bh_q'][j]=q
    result=dict(features=FEATURES+EXTRA,splits=splits,variants=variants,books=books,plan=plan,
        no_semantic_constraints=True,features_used_in_training=False,permutations=999,prefix_min_train_count=20,
        independent_test_evaluated=False,multiple_testing_family=len(pvalues))
    (folder/'small_analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False))
    (folder/'small.html').write_text(page or PAGE);freeze_sources(folder/'source_snapshot')
    viewer=create_book_viewer(root,plan,labels)
    for name in ('small.html','small_analysis.json'):(viewer/name).symlink_to(folder/name)
    selector=root.parents[1]/'.local/dual_viewer/current.json';previous=Path(previous) if previous else Path(json.loads(selector.read_text())['directory'])
    (viewer/'previous').symlink_to(previous,target_is_directory=True)
    tmp=selector.with_suffix('.tmp');tmp.write_text(json.dumps(dict(directory=str(viewer))));tmp.replace(selector)
    (root/'published.json').write_text(json.dumps(dict(directory=str(viewer))))
    print(folder,flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);main(p.parse_args().root)
