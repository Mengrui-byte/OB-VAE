"""Mechanical development gates for the recall80 reconstruction goal."""
import argparse
import json
from pathlib import Path


def evaluate_result(result,reference,*,recall_target=.80,price_ratio=1.10,min_precision=.50):
    m=result['metrics'];base=reference['metrics'];tail=result['thresholds']['100']
    recall=tail['recall'];precision=tail['precision']
    price=m['price_usdt']['rmse'];mid=m['temporal_mid_1_minutes_usdt_per_minute']['rmse']
    base_price=base['price_usdt']['rmse'];base_mid=base['temporal_mid_1_minutes_usdt_per_minute']['rmse']
    scope=bool(result.get('windows',0)>0 and result.get('windows')==reference.get('windows'))
    requested=bool(scope and recall is not None and recall>recall_target and price<=base_price*price_ratio and mid<=base_mid*price_ratio)
    quality=bool(precision is not None and precision>=min_precision and m['quantity_btc']['rmse']<=base['quantity_btc']['rmse']*price_ratio)
    return dict(pass_=requested and quality,user_criteria_pass=requested,quality_guard_pass=quality,equal_window_count=scope,
        score=recall or 0.,recall100=recall,precision100=precision,false_positives=tail['fp'],
        price_rmse=price,price_limit=base_price*price_ratio,mid_delta_rmse=mid,mid_delta_limit=base_mid*price_ratio,
        quantity_rmse=m['quantity_btc']['rmse'],quantity_limit=base['quantity_btc']['rmse']*price_ratio,
        note='Developmentgateonly. Completionadditionally requiresactual8192/no-bypassarchitectureaudit andfrozen-candidateconfirmation; trainingfitcannotcount.')


def assess_file(path,reference):
    result=json.loads(Path(path).read_text())['result']
    base=json.loads(Path(reference).read_text())['result']
    verdict=evaluate_result(result,base);verdict['pass']=verdict.pop('pass_')
    return verdict


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('result',type=Path);p.add_argument('--reference',required=True,type=Path);args=p.parse_args()
    print(json.dumps(assess_file(args.result,args.reference),allow_nan=False))
