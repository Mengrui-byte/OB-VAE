"""Report matched loss controls at a completed common checkpoint."""
import argparse
from datetime import datetime
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
import numpy as np


def main(root):
 root=root.resolve();plan=json.loads((root/'plan.json').read_text());labels=plan['labels'];ready=[n for n in plan['checkpoints'] if all((root/k/f'step{n}_evaluation.json').exists() for k in labels)];step=max(ready);folder=root/'results'/f'step{step}';folder.mkdir(parents=True,exist_ok=False)
 def compact(d):
  m=d['metrics'];return dict(price_rmse_usdt=m['price_usdt']['rmse'],quantity_rmse_btc=m['quantity_btc']['rmse'],quantity_change_correlation=m['temporal_log_quantity_1_minutes']['correlation'],mid_change_correlation=m['temporal_mid_1_minutes_usdt_per_minute']['correlation'],large10=d['thresholds']['10'],large100=d['thresholds']['100'],quantity_max_btc=d['prediction_max'],tail_quantity_rmse=d['tail_quantity_rmse'])
 records={};history={};hashes={};progress={}
 for lane in labels:
  history[lane]={}
  for n in [0,*ready]:
   p=root/lane/('initial_evaluation.json' if n==0 else f'step{n}_evaluation.json');d=json.loads(p.read_text())['result'];history[lane][str(n)]=compact(d)
   if n==step:hashes[str(p.relative_to(root))]=hashlib.sha256(p.read_bytes()).hexdigest();records[lane]=compact(d)
  progress[lane]=json.loads((root/lane/'progress.json').read_text())['step']
 baseline=records['baseline'];changes={k:dict(price_rmse_ratio=v['price_rmse_usdt']/baseline['price_rmse_usdt'],quantity_rmse_ratio=v['quantity_rmse_btc']/baseline['quantity_rmse_btc'],quantity_change_correlation_delta=v['quantity_change_correlation']-baseline['quantity_change_correlation'],price_guard_passed=v['price_rmse_usdt']<=1.10*baseline['price_rmse_usdt']) for k,v in records.items()}
 value=dict(created_at=datetime.now().isoformat(),run=root.name,additional_step=step,common_pretraining_steps=512,additional_epochs=step/16,evaluation_windows=16,training_steps=progress,records=records,changes_vs_matched_baseline=changes,history=history,source_sha256=hashes,scope='SameAE512initialweights+AdamWmoments,64trainingwindows,seed42,256frameinput,8192latent andnearestupsampler. Onlyonequantitylosstermvaries. Fixed2025Q1development, not pristine test. Earlycheckpoint is descriptive; full1024endpoint remains planned.')
 (folder/'summary.json').write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False))
 font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc';font_manager.fontManager.addfont(font);plt.rcParams.update({'font.family':font_manager.FontProperties(fname=font).get_name(),'axes.unicode_minus':False,'font.size':10})
 colors=['#366590','#ab6173','#337c70','#b27c33'];fig,axes=plt.subplots(2,2,figsize=(13,8),layout='constrained')
 for ax,key,title in zip(axes.flat,['price_rmse_usdt','quantity_rmse_btc','quantity_change_correlation','quantity_max_btc'],['全档价格RMSE USDT','挂量RMSE BTC','分钟挂量变化相关','预测最大挂量 BTC']):
  for (lane,label),c in zip(labels.items(),colors):
   h=history[lane];n=sorted(map(int,h));ax.plot(n,[h[str(i)][key] for i in n],marker='o',color=c,label=label)
  ax.set_title(title);ax.set_xlabel('共同AE512起点后的额外更新');ax.grid(alpha=.2);ax.legend(fontsize=8)
 fig.suptitle('损失控制变量实验｜同初始化、结构与训练预算｜16个开发窗',fontsize=14);fig.savefig(folder/'metrics.png',dpi=160);plt.close(fig)
 profiles_ready=all((root/k/f'step{step}_profiles.npz').exists() for k in labels)
 if profiles_ready:
  with np.load(root/'source_profiles.npz') as d:truth=d['truth'];times=d['time'];indices=d['indices']
  preds={}
  for lane in labels:
   with np.load(root/lane/f'step{step}_profiles.npz') as d:
    np.testing.assert_array_equal(truth,d['truth']);preds[lane]=d['prediction']
  fig,axes=plt.subplots(3,2,figsize=(15,10),layout='constrained');x=np.arange(1,257)
  for w in range(3):
   target=truth[w,:,:,0,0].mean(1);axes[w,0].plot(x,target,color='#243447',lw=1.6,label='真实中间价')
   for (lane,label),c in zip(labels.items(),colors):
    y=preds[lane][w,:,:,0,0].mean(1);axes[w,0].plot(x,y,color=c,lw=1.1,label=label);axes[w,1].plot(x,y-target,color=c,lw=1.1,label=label)
   for col in range(2):
    axes[w,col].set_title(f'固定窗口{w+1} · '+('中间价' if col==0 else '预测－真实'));axes[w,col].set_xlabel('窗口内分钟');axes[w,col].set_ylabel('USDT');axes[w,col].grid(alpha=.18);axes[w,col].set_xlim(1,256)
   axes[w,0].legend(fontsize=7,ncol=2)
  fig.suptitle(f'共同追加第{step}步｜完整256分钟｜价格未平移对齐',fontsize=15);fig.savefig(folder/'midprice.png',dpi=150);plt.close(fig)
  quantities={k:dict(mean_predicted=float(a[...,1].mean()),mean_truth=float(truth[...,1].mean())) for k,a in preds.items()};value['three_preview_window_quantity_means']=quantities;(folder/'summary.json').write_text(json.dumps(value,ensure_ascii=False,indent=2))
 rows=''
 for lane,label in labels.items():
  v=records[lane];p=v['large10']['precision'];rows+=f'<tr><td>{label}</td><td>{v["price_rmse_usdt"]:.2f}</td><td>{v["quantity_rmse_btc"]:.3f}</td><td>{v["quantity_change_correlation"]:.5f}</td><td>{v["large10"]["recall"]*100:.2f}%</td><td>{p*100:.2f}%' if p is not None else f'<tr><td>{label}</td><td>{v["price_rmse_usdt"]:.2f}</td><td>{v["quantity_rmse_btc"]:.3f}</td><td>{v["quantity_change_correlation"]:.5f}</td><td>{v["large10"]["recall"]*100:.2f}%</td><td>—'
  rows+=f'</td><td>{v["large100"]["recall"]*100:.1f}%</td><td>{v["quantity_max_btc"]:.2f}</td></tr>'
 css='body{font:15px/1.85 system-ui;color:#243447;max-width:1350px;margin:30px auto;padding:0 22px}table{border-collapse:collapse;width:100%;font-size:13px}th,td{padding:10px;text-align:left;border-bottom:1px solid #dbe2eb}th{background:#f5f8fb}img{width:100%}a{color:#366590}.note{padding:15px;background:#f5f8fb;border-left:3px solid #7e9ab4}.wrap{overflow:auto}'
 html=f'''<!doctype html><html lang=zh-CN><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>损失对照追加第{step}步</title><style>{css}</style><h1>损失控制变量实验 · 追加第{step}步（{step/16:g}个epoch）</h1><p>全部从同一AE512权重及AdamW动量开始，固定完整256分钟输入、8192latent、最近邻上采样、价格损失、训练数据和预算。只改变数量损失。报告创建时进度为{progress}。以下均为相同16个2025Q1开发窗口。</p><p><a href=../../public/>实时训练进度</a> · <a href=../../public/design.html>控制变量设计</a> · <a href=../../previews/step{step}/viewer/>逐档挂单线图（本检查点）</a> · <a href=summary.json>详细数值与来源哈希</a></p><div class=wrap><table><thead><tr><th>方案</th><th>价格RMSE USDT</th><th>挂量RMSE BTC</th><th>分钟挂量变化相关</th><th>≥10BTC召回</th><th>≥10BTC精确率</th><th>≥100BTC召回</th><th>预测最大挂量BTC</th></tr></thead><tbody>{rows}</tbody></table></div><div class=note>这是早期共同检查点，不能代替预先声明的1024步终点。数量MSE带来的阈值召回必须与假阳性、总体挂量误差和价格保持一起比较。空间/时间差分若只产生很小变化，不据此宣称已经有效或无效。各组实际总损失定义不同，跨组只比较共同基础损失或相同重建指标。</div><h2>检查点轨迹</h2><img src=metrics.png alt="相同评估方法下的四组指标">'''
 if profiles_ready:html+='<h2>固定三个窗口中间价</h2><img src=midprice.png alt="价格重建与误差">'
 (folder/'index.html').write_text(html);(root/'results/latest.json').write_text(json.dumps(dict(additional_step=step,directory=str(folder),url=f'http://172.16.30.28:8875/recons/{root.name}/results/step{step}/'),indent=2))
 p=root.parents[1]/'recons/index.html';s=p.read_text();link=f'{root.name}/results/step{step}/'
 if link not in s:p.write_text(s.replace('</main>',f'<p><a href="{link}">损失单因素对照：追加第{step}步结果</a></p></main>'))
 print(folder,flush=True)

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);main(p.parse_args().root)
