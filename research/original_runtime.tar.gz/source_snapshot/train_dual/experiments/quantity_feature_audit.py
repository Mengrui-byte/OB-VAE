"""Frozen decoded features: inspect bandwidth and fit only33quantity-head params."""
import argparse
import json
from pathlib import Path
import torch
from torch.nn import functional as F
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.unified_8192_run import call
from train_dual.util.checkpoint import load_for_inference,seed_everything
from train_dual.experiments.window_state_pilot import strict_precision


def run(root):
 torch.set_num_threads(4);seed_everything(42);strict_precision();folder=root/'feature_head_audit';folder.mkdir();model,norm=load_for_inference(root/'initial.pt','cuda:0');raw=torch.load(root/'small_train.pt',map_location='cpu',weights_only=False);q0=float(model.volume_decoder.q0);cache=[];features=[];handle=model.volume_decoder.spatial.up[3].register_forward_hook(lambda m,a,v:features.append(v.detach()))
 with torch.no_grad():
  for i in range(4):
   b=norm.prepare({k:v[i:i+1] for k,v in raw.items()},'cuda:0');o=call(model,b,False);h=features.pop();target=b['volume'].reshape(512,1,2048);mask=b['mask'].reshape(512,1,2048);idx=target.masked_fill(~mask,-torch.inf).topk(16,-1).indices
   cache.append(dict(h=h,target=target,mask=mask,idx=idx,original=o['volume'].reshape_as(target)))
 handle.remove();weight=model.volume_decoder.quantity.weight.detach().clone();bias=model.volume_decoder.quantity.bias.detach().clone();del model;torch.cuda.empty_cache()
 freq=torch.fft.rfftfreq(2048,device='cuda:0');hann=torch.hann_window(2048,periodic=False,device='cuda:0');spectra={}
 with torch.no_grad():
  for label in ['decoded_features','target_log_quantity']:
   total=high=0.
   for b in cache:
    x=b['h'] if label=='decoded_features' else torch.log1p(b['target']/q0);x=(x-x.mean(-1,keepdim=True))*hann;f=torch.fft.rfft(x,dim=-1,norm='ortho');p=f.abs().square();p[...,1:-1]*=2;total+=float(p[...,1:].sum());high+=float(p[...,freq>1/32].sum())
   spectra[label]=dict(high_frequency_energy_fraction=high/total,total_windowed_energy=total,high_frequency_definition='periods<32levels; per-channel demeaned, Hann window. Featurechannel fraction is not information capacity.')
 def objective(head,mode):
  value=0.
  for b in cache:
   pred=q0*F.softplus(head(b['h']));e=(pred-b['target'])/q0;p=.5*e.square() if mode=='mse' else F.huber_loss(e,torch.zeros_like(e),reduction='none');log=torch.log1p(pred/q0)-torch.log1p(b['target']/q0);log=F.huber_loss(log,torch.zeros_like(log),reduction='none');value=value+((p+log)*b['mask']).sum()/b['mask'].sum()/4+.25*p.gather(-1,b['idx']).mean()/4
  return value
 def metrics(head):
  se=zero=n=tp10=fp10=fn10=tp100=fp100=fn100=0;mx=0.
  with torch.no_grad():
   for b in cache:
    pred=q0*F.softplus(head(b['h']));v=b['mask'];se+=float(((pred-b['target'])[v]).square().sum());zero+=float(b['target'][v].square().sum());n+=int(v.sum());mx=max(mx,float(pred[v].max()))
    for threshold in [10,100]:
     a=(b['target']>=threshold)&v;c=(pred>=threshold)&v;tp=int((a&c).sum());fp=int((~a&c).sum());fn=int((a&~c).sum())
     if threshold==10:tp10+=tp;fp10+=fp;fn10+=fn
     else:tp100+=tp;fp100+=fp;fn100+=fn
  return dict(quantity_rmse_btc=(se/n)**.5,zero_quantity_rmse_btc=(zero/n)**.5,prediction_max=mx,thresholds={'10':dict(tp=tp10,fp=fp10,fn=fn10,recall=tp10/max(tp10+fn10,1),precision=tp10/max(tp10+fp10,1)),'100':dict(tp=tp100,fp=fp100,fn=fn100,recall=tp100/max(tp100+fn100,1),precision=tp100/max(tp100+fp100,1))})
 results={}
 for mode in ['huber','mse']:
  head=torch.nn.Conv1d(32,1,1).to('cuda:0');head.load_state_dict(dict(weight=weight,bias=bias));opt=torch.optim.AdamW(head.parameters(),lr=.001,weight_decay=0.);history=[];before=metrics(head)
  with torch.no_grad():replay=max(float((q0*F.softplus(head(b['h']))-b['original']).abs().max()) for b in cache)
  for step in range(257):
   opt.zero_grad(set_to_none=True);loss=objective(head,mode)
   if step in [0,32,128,256]:history.append(dict(step=step,objective=float(loss.detach()),metrics=metrics(head)));print(mode,history[-1],flush=True)
   if step==256:break
   loss.backward();torch.nn.utils.clip_grad_norm_(head.parameters(),1.,error_if_nonfinite=True);opt.step()
  results[mode]=dict(before=before,after=metrics(head),history=history,initial_head_replay_max_error=replay)
  torch.save(head.state_dict(),folder/(mode+'_head.pt'));atomic_json(folder/'progress.json',dict(completed=list(results),steps=256))
 atomic_json(folder/'summary.json',dict(spectra=spectra,results=results,scope='SameAE2048frozen decoded32channel highresolution features fromsame4complete256frame trainingwindows. Only33quantityhead parameters optimized, freshAdamW.001,256steps,globalclip1. PairedHuber/MSE loss control withsameinitialhead; sameTop16andlogterms. This diagnoses a fixed representation and readout, not whole-model capacity or generalization.'))
 atomic_json(folder/'status.json',dict(state='complete'))

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);run(p.parse_args().root)
