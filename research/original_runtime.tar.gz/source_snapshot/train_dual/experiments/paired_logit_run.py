"""Frozen native CNN feature pairs: tied/separate logits x local peak KL."""
import argparse
import os
from pathlib import Path
import time

import numpy as np
import torch

from model.autoencoder.paired_logit_vae import PairedLogitOrderBookVAE
from model.layers.paired_logit import PairedQuantityLogitReadout,log_quantity_residual
from model.layers.logit_readout import add_quantity_logit
from train_dual.experiments.confirm_recall_goal import require_matching_replay
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.local_peak_quantity_run import criterion
from train_dual.experiments.local_quant_reconstruction import CacheWindows
from train_dual.experiments.long_worker import atomic_json,evaluate
from train_dual.experiments.goal_evaluate import assess_file
from train_dual.experiments.phase_detail_report import read,STYLE
from train_dual.experiments.price_safe_readout import file_hash,price_replay,FROZEN
from train_dual.experiments.price_safe_logit_readout import attach_head_optimizer
from train_dual.experiments.recall_goal_run import record
from train_dual.experiments.region_task_run import safe_preview
from train_dual.experiments.time_logit_run import write_profiles
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import atomic_save,freeze_sources,load_for_inference,source_hashes
from train_dual.util.hint_training import restore_logit_readout_adam
from train_dual.util.phase_training import tensor_digest


LABELS=dict(shared='相邻两档共享修正',shared_kl='共享修正＋邻域KL',phase='相邻两档独立修正',phase_kl='独立修正＋邻域KL')
RESPONSE_LABELS=dict(logit='加性logit',logit_kl='加性logit＋邻域KL',log_quantity='乘性数量',log_quantity_kl='乘性数量＋邻域KL')


def render(root):
    plan=read(root/'plan.json');state=read(root/'status.json',{});progress=read(root/'progress.json',{})
    text='<h1>相邻两档读出：共享 / 独立 × 邻域KL</h1><p>完整256分钟、唯一Gaussian64×128、原空间上采样不变。冻结Encoder、价格/数量原Decoder与hint_adapter，只训练130个参数。拼接数量CNN最终相邻两档的32＋32维特征，共同输入64→2仿射头；共享组取两输出平均并同时作用于两档，独立组分别作用于对应档位。四组参数个数和初始输出相同，无Encoder跳接。</p><p>原生来源、原32训练窗、seed42、同一采样、FP32缓存/训练/评估、batch2、lr1e-3、clip1、2048步预算；损失仅比较原损失 / 额外局部KL权重1。缓存是同一Z下游的最终CNN特征，非额外latent；开发评估重新完整编码、双Decoder生成，必须重放来源价格。形态监督不放宽同档位召回。</p><p>状态：'+str(state.get('state'))+'，进度'+str(progress.get('step',0))+'/2048。</p><table><tr><th>组</th><th>步数</th><th>召回</th><th>精确率</th><th>价格RMSE</th><th>分钟变化RMSE</th><th>数量RMSE</th><th>通过</th></tr>'
    if plan.get('response_space_study'):
        text='<h1>相同130参数：加性logit / 乘性数量 × 邻域KL</h1><p>原CNN、Encoder与价格冻结；相同相邻两档最终特征、130个零初始化参数、32训练窗、采样、FP32、lr1e-3和2048步。仅改变输出响应空间与局部KL权重0/1。乘性数量为q_base×exp(4tanh(delta/4))，无新latent、不改上采样；原加性控制需精确重放上一轮phase/phase_kl权重与全部Adam。</p><p>进度：'+str(progress.get('step',0))+'/2048，状态：'+str(state.get('state'))+'</p><table><tr><th>组</th><th>步数</th><th>召回</th><th>精确率</th><th>价格RMSE</th><th>分钟变化RMSE</th><th>数量RMSE</th><th>通过</th></tr>'
        if plan.get('reproducible_head_training'):
            text=text.replace('原加性控制需精确重放上一轮phase/phase_kl权重与全部Adam。','四组统一使用确定性cuDNN头部训练。旧的非确定性训练仅作历史记录；另设两份同seed控制副本，检查点逐值核对130参数和全部头部Adam。推理保持原FP32设置。')
    for lane in plan['labels']:
        for step in [0,*plan['checkpoints']]:
            p=root/lane/f'step{step}_development.json'
            if not p.exists():continue
            row=assess_file(p,root.parent/'reference_evaluation.json');values=[plan['labels'][lane],step,row['recall100'],row['precision100'],row['price_rmse'],row['mid_delta_rmse'],row['quantity_rmse'],row['pass']]
            text+='<tr>'+''.join('<td>'+str(round(v,5) if isinstance(v,float) else v)+'</td>' for v in values)+'</tr>'
    text+='</table><p>固定16个Q1开发窗口已反复用于研究，不是独立测试。独立确认数据未用于本轮；目标尚需严格联合门槛和冻结后的确认。新头仅测试原CNN特征能否线性读出两档差异，不能单独证明上采样是唯一原因。</p><p><a href="plan.json">协议</a> · <a href="cache_audit.json">全尺寸审计</a> · <a href="frozen_backbone_audit.json">来源权重与Adam</a></p>'
    (root/'index.html').write_text('<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="30"><title>相邻两档logit读出</title><style>'+STYLE+'</style><main>'+text+'</main>')


def replay_checkpoint(root,plan,lane,step):
    parent=Path(plan['replay_control_root'])
    if not parent.is_absolute():parent=root.parent/parent
    return parent/lane/f'step{step}.pt'


def prepare(goal,response_space=False,suffix='',reproducible=False):
    if any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-' for c in suffix):raise ValueError('Invalid experiment suffix')
    if reproducible and not response_space:raise ValueError('Reproducible controls require response-space study')
    parent=goal/('paired_logit_readout' if response_space else 'frozen_price_quantity');root=goal/(('paired_response_space' if response_space else 'paired_logit_readout')+suffix);root.mkdir();project=Path(__file__).resolve().parents[2];labels=RESPONSE_LABELS if response_space else LABELS
    if response_space and read(parent/'status.json',{}).get('state')!='complete':raise ValueError('Finish original paired controls first')
    for name in ['data','logs',*labels]:(root/name).mkdir()
    for name in ['source.pt','source_development.json','train_indices.npy','train_order.npy','val_indices.npy','calibration.json','plotly.min.js']:os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    specs=({lane:dict(phase_specific=True,readout_space='log_quantity' if lane.startswith('log_quantity') else 'logit',local_peak_weight=float(lane.endswith('kl'))) for lane in labels} if response_space else {lane:dict(phase_specific=lane.startswith('phase'),local_peak_weight=float(lane.endswith('kl'))) for lane in labels})
    plan=dict(read(parent/'plan.json'));plan.update(experiment='Paired final CNN feature logit residual, tied/separate x local KL',labels=labels,lanes=specs,response_space_study=response_space,
        learning_rate=.001,weight_decay=0.,steps=2048,checkpoints=[512,2048],max_seconds=10800,seed=42,head_parameters=130,local_peak_radius=8,
        source_control='Same original source,32windows/order/seed/cache/initial130zeroheadparams/FP32/lr/budget/evaluation. Only tied/separate two-logit readout and declared local KL0/1 vary. Body and sourceAdam frozen; raw upsampling unchanged.',
        preview_descriptions={lane:'固定16个已用于研究的Q1开发窗口。完整256分钟、唯一8192原生Z。冻结骨干，仅训练130参数的相邻两档读出。非独立测试。' for lane in labels})
    if response_space:
        for name in ['train_cache.pt','cache_audit.json']:os.link(parent/name,root/name)
        assert file_hash(root/'train_cache.pt')==read(parent/'cache_audit.json')['cache_sha256']
        plan.update(experiment='Same paired130parameterhead, additive logit x multiplicative quantity response',reuse_cache=True,replay_control_root=parent.name,replay_controls=dict(logit='phase',logit_kl='phase_kl'),
            source_control='Only response_space logit/log_quantity and localKL0/1 vary. Same prior byteidenticalcache/body/data/order/seed/lr/budget/130params. Additive controls replay entire previousphase/phase_klmodelandAdam at0/512/2048.')
    if reproducible:
        plan['historical_controls']=plan.pop('replay_controls');plan['historical_control_root']=plan.pop('replay_control_root')
        plan.update(reproducible_head_training=True,duplicate_controls=['logit','logit_kl'],
            training_numeric_policy=dict(cudnn_deterministic=True,cudnn_benchmark=False,tf32=False,local_peak_kernel='gather'),
            inference_numeric_policy=dict(cudnn_deterministic=False,cudnn_benchmark=False,tf32=False),
            source_control='Fresh matched4armcohort with identical source/cache/data/seed/budget and deterministic cuDNN head training. Two same-seed numeric replicas of additive controls must match every head/Adam checkpoint exactly. Old nondeterministic controls remain historical, not bitwise replay gates.')
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot');render(root)
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export CUDA_VISIBLE_DEVICES=2 CUDA_DEVICE_ORDER=PCI_BUS_ID PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.paired_logit_run "{remote}" --worker >> "{remote}/logs/run.log" 2>&1\n')
    record(goal,'paired_logit_readout_prepared',root=root.name,hypothesis='87.5percent sourceFP within2ranks; test phase-specific final CNN readout at fixed130parameters, fixedprice and original8192Z',steps=2048);print(root,flush=True)


def make_model(payload,spec,device='cpu'):
    config=dict(payload['local_hint_config'],phase_specific=spec['phase_specific'],readout_space=spec.get('readout_space','logit'));model=PairedLogitOrderBookVAE(**config,**payload['unified_vae_config'])
    missing,extra=model.load_state_dict(payload['model'],strict=False)
    if missing!=['local_readout.weight','local_readout.bias'] or extra:raise ValueError('Unexpected source model layout')
    return model.to(device).eval(),config


def cache_gpu(root):
    plan=read(root/'plan.json');payload=torch.load(root/'source.pt',map_location='cpu',weights_only=False);model,_=make_model(payload,dict(phase_specific=True),'cuda:0');model.requires_grad_(False);model.return_readout_features=True
    source,norm=load_for_inference(root/'source.pt','cuda:0');source.eval();original=dataset(root,'train');cache=[];contracts=[]
    atomic_json(root/'status.json',dict(state='caching_final_CNN_features',pid=os.getpid()))
    for position,index in enumerate(np.load(root/'train_indices.npy')):
        raw={k:v.unsqueeze(0) for k,v in original[int(index)].items()};b=norm.prepare(raw,'cuda:0');start=int(original.base.starts[int(index)]);times=original.base.times[start:start+256]
        assert list(raw['data'].shape)==[1,256,2,2048,2] and np.all(np.diff(times//60_000_000)==1)
        seen=[];hooks=[d.register_forward_pre_hook(lambda m,a:seen.append(a[0])) for d in [model.price_decoder,model.volume_decoder]] if position==0 else []
        with torch.no_grad():out=call(model,b,False)
        assert all(list(out[k].shape)==[1,64,128] for k in ['mu','logvar','z']) and list(out['volume'].shape)==[1,256,2,2048]
        assert list(out['quantity_pair_features'].shape)==[512,64,1024];torch.testing.assert_close(out['volume'],out['base_volume'],rtol=0,atol=0)
        if position==0:
            assert seen[0] is seen[1] is out['z']
            for h in hooks:h.remove()
            with torch.no_grad():reference=call(source,b,False)
            for key in ['volume','price_norm','mu','logvar','z']:torch.testing.assert_close(out[key],reference[key],rtol=0,atol=0)
            for phase in [False,True]:
                fresh,_=make_model(payload,dict(phase_specific=phase),'cuda:0')
                def forbid_encoder(*args):raise AssertionError('Fresh decode accessed Encoder')
                hook=fresh.encoder.register_forward_pre_hook(forbid_encoder)
                with torch.no_grad():replay=fresh.decode(out['z'],b['mask'],b['tick_norm'],b['times'])
                hook.remove()
                for key in ['volume','price_norm']:torch.testing.assert_close(replay[key],out[key],rtol=0,atol=0)
                del fresh
        cache.append(dict(batch={k:b[k].detach().cpu() for k in ['price','volume','mask']},out={k:out[k].detach().cpu() for k in ['volume','base_quantity_logit','quantity_pair_features','price_norm','mid_norm','mu','logvar']}))
        contracts.append(dict(index=int(index),raw=[1,256,2,2048,2],posterior=[1,64,128],output=[1,256,2,2048],post_Z_feature_pairs=[512,64,1024],consecutive_minutes=True))
        atomic_json(root/'cache_progress.json',dict(windows=position+1,total=32))
    atomic_save(cache,root/'train_cache.pt');model.return_readout_features=False;dev=dataset(root,'val');selected=CacheWindows(dev,np.load(root/'val_indices.npy'));result=evaluate(model,norm,selected,len(selected),'cuda:0');require_matching_replay(result,read(root/'source_development.json')['result'])
    for lane in plan['labels']:atomic_json(root/lane/'step0_development.json',dict(result=result,scope='ActualGPU source16replay; both zero-head flags freshZ-onlydecodeexact'))
    atomic_json(root/'cache_audit.json',dict(passed=True,contracts=contracts,shared_Z=True,source_zero_identity=True,fresh_decode_both_flags_exact=True,source16replay=True,cache_sha256=file_hash(root/'train_cache.pt'),optimizer_updates=0));del model,source,cache;torch.cuda.empty_cache()


def predict(head,row,spec,q0):
    out=dict(row['out']);delta=head(out['quantity_pair_features'],phase_specific=spec['phase_specific']).reshape_as(out['volume'])
    if spec.get('readout_space','logit')=='logit':out['volume'],out['quantity_logit']=add_quantity_logit(out['base_quantity_logit'],delta,row['batch']['mask'],q0)
    else:out['volume']=log_quantity_residual(out['volume'],delta,row['batch']['mask'])
    return out


def cache_metrics(heads,cache,plan):
    rows={}
    with torch.no_grad():
        for lane,head in heads.items():
            tp=fp=fn=0;square=count=0.
            for row in cache:
                q=predict(head,row,plan['lanes'][lane],plan['normalization']['quantity_scale'])['volume'];target=row['batch']['volume'];mask=row['batch']['mask'];a=mask&(target>=100);b=mask&(q>=100)
                tp+=int((a&b).sum());fp+=int((~a&b).sum());fn+=int((a&~b).sum());square+=float(((q-target).square()*mask).sum());count+=int(mask.sum())
            rows[lane]=dict(tp=tp,fp=fp,fn=fn,recall=tp/max(1,tp+fn),precision=tp/max(1,tp+fp),quantity_rmse=(square/max(1,count))**.5,scope='32originaltrainingwindows,insamplecachedfeaturesonly')
    return rows


def evaluate_saved(root,step):
    strict_precision();plan=read(root/'plan.json');dev=dataset(root,'val');selected=CacheWindows(dev,np.load(root/'val_indices.npy'));reference=read(root/'source_development.json')['result']
    if plan.get('reproducible_head_training'):torch.backends.cudnn.deterministic=False
    atomic_json(root/'evaluation_status.json',dict(state='running',step=step,pid=os.getpid()))
    for lane in plan['labels']:
        model,norm=load_for_inference(root/lane/f'step{step}.pt','cuda:0');result=evaluate(model,norm,selected,len(selected),'cuda:0');price_replay(result,reference)
        atomic_json(root/lane/f'step{step}_development.json',dict(result=result,scope=plan['evaluation_scope'],head_steps=step));write_profiles(root/lane,step,model,norm,selected,dev);safe_preview(root,lane,step);del model;torch.cuda.empty_cache();render(root)
    rows=[dict(lane=lane,step=step,checkpoint=str(root/lane/f'step{step}.pt'),evaluation=str(root/lane/f'step{step}_development.json'),**assess_file(root/lane/f'step{step}_development.json',root.parent/'reference_evaluation.json')) for lane in plan['labels']]
    atomic_json(root/f'common{step}_analysis.json',dict(rows=rows,source_price_replay_passed=True,independent_data_read=False));passing=[r for r in rows if r['pass']]
    if passing:atomic_json(root/'eligible_candidate.json',max(passing,key=lambda r:(r['recall100'],-r['price_rmse'])))
    atomic_json(root/'evaluation_status.json',dict(state='complete',step=step))
    if plan.get('reproducible_head_training'):torch.backends.cudnn.deterministic=True


def verify_reused_source(root):
    plan=read(root/'plan.json');payload=torch.load(root/'source.pt',map_location='cpu',weights_only=False);model,_=make_model(payload,dict(phase_specific=True,readout_space='log_quantity'),'cuda:0');source,norm=load_for_inference(root/'source.pt','cuda:0');source.eval();original=dataset(root,'train');raw={k:v.unsqueeze(0) for k,v in original[int(np.load(root/'train_indices.npy')[0])].items()};b=norm.prepare(raw,'cuda:0')
    with torch.no_grad():out=call(model,b,False);baseline=call(source,b,False)
    assert list(raw['data'].shape)==[1,256,2,2048,2] and list(out['z'].shape)==[1,64,128]
    for key in ['price_norm','volume','mu','logvar','z']:torch.testing.assert_close(out[key],baseline[key],rtol=0,atol=0)
    fresh,_=make_model(payload,dict(phase_specific=True,readout_space='log_quantity'),'cuda:0')
    def no_encoder(*args):raise AssertionError('Fresh decode accessed Encoder')
    hook=fresh.encoder.register_forward_pre_hook(no_encoder)
    with torch.no_grad():replay=fresh.decode(out['z'],b['mask'],b['tick_norm'],b['times'])
    hook.remove()
    for key in ['price_norm','volume']:torch.testing.assert_close(out[key],replay[key],rtol=0,atol=0)
    del fresh,source;dev=dataset(root,'val');selected=CacheWindows(dev,np.load(root/'val_indices.npy'));result=evaluate(model,norm,selected,len(selected),'cuda:0');require_matching_replay(result,read(root/'source_development.json')['result'])
    for lane in plan['labels']:atomic_json(root/lane/'step0_development.json',dict(result=result,scope='Byteidenticalcache; new logquantity zero source and fresh decode actualGPUreplay; source16replay'))
    atomic_json(root/'response_space_preflight.json',dict(passed=True,cache_reused_byteidentical=True,input=[1,256,2,2048,2],posterior=[1,64,128],source_zero_and_fresh_decode_exact=True,source16replay=True,optimizer_updates=0))


def audit_replica(head,optimizer,replica,replica_optimizer):
    for name,value in head.state_dict().items():torch.testing.assert_close(value,replica.state_dict()[name],rtol=0,atol=0)
    a,b=optimizer.state_dict(),replica_optimizer.state_dict();assert a['param_groups']==b['param_groups'] and a['state'].keys()==b['state'].keys()
    for index,state in a['state'].items():
        assert state.keys()==b['state'][index].keys()
        for key,value in state.items():
            actual=b['state'][index][key];assert torch.equal(value.cpu(),actual.cpu()) if torch.is_tensor(value) else value==actual


def worker(root):
    torch.set_num_threads(4);torch.manual_seed(42);strict_precision();started=time.monotonic();plan=read(root/'plan.json')
    if read(root/'status.json')['state']!='prepared':raise ValueError('Fresh worker only; preserve interrupted runs')
    if plan.get('reuse_cache'):verify_reused_source(root)
    else:cache_gpu(root)
    torch.cuda.empty_cache();payload=torch.load(root/'source.pt',map_location='cpu',weights_only=False);hashes=source_hashes();frozen_source={}
    assert file_hash(root/'train_cache.pt')==read(root/'cache_audit.json')['cache_sha256']
    cached=torch.load(root/'train_cache.pt',map_location='cpu',weights_only=False,mmap=True);cache=[{outer:{k:v.to('cuda:0') for k,v in values.items()} for outer,values in row.items()} for row in cached];del cached
    if plan.get('reproducible_head_training'):torch.backends.cudnn.deterministic=True;torch.backends.cudnn.benchmark=False
    labels=plan['labels'];heads={lane:PairedQuantityLogitReadout().cuda() for lane in labels};optimizers={lane:torch.optim.AdamW(head.parameters(),lr=.001,weight_decay=0.) for lane,head in heads.items()};objectives={lane:criterion(root,lane).cuda() for lane in labels};order=np.load(root/'train_order.npy')
    replicas={lane:PairedQuantityLogitReadout().cuda() for lane in plan.get('duplicate_controls',[])};replica_optimizers={lane:torch.optim.AdamW(head.parameters(),lr=.001,weight_decay=0.) for lane,head in replicas.items()}
    def check_replicas(step):
        for lane,head in replicas.items():audit_replica(heads[lane],optimizers[lane],head,replica_optimizers[lane])
        if replicas:atomic_json(root/f'step{step}_replica_audit.json',dict(passed=True,lanes=list(replicas),same_seed_same_data_budget=True,all130parameters_and_head_Adam_exact=True))
    initial={}
    with torch.no_grad():
        for lane,head in heads.items():
            totals=dict(loss=0.,local_peak_kl=0.,pre_local_peak_loss=0.)
            for pos in order[:2]:
                row=cache[int(pos)];out=predict(head,row,plan['lanes'][lane],plan['normalization']['quantity_scale']);torch.testing.assert_close(out['volume'],row['out']['volume'],rtol=0,atol=0)
                values=objectives[lane](out,row['batch'])
                for key in totals:totals[key]+=float(values[key])/2
            initial[lane]=totals
    zero=next(lane for lane in labels if plan['lanes'][lane]['local_peak_weight']==0.);unit=next(lane for lane in labels if plan['lanes'][lane]['local_peak_weight']==1.)
    assert all(row==initial[unit if plan['lanes'][lane]['local_peak_weight'] else zero] for lane,row in initial.items())
    for lane,row in initial.items():
        expected=initial[zero]['loss']+plan['lanes'][lane]['local_peak_weight']*initial[zero]['local_peak_kl']
        assert abs(row['loss']-expected)<1e-5
    atomic_json(root/'startup_control_audit.json',dict(passed=True,initial=initial,first_two_cache_positions=order[:2].tolist(),all_zero_source_exact=True,same130parameters_and_initialization=True,optimizer_updates=0))
    def save(lane,step):
        model,config=make_model(payload,plan['lanes'][lane]);model.local_readout.load_state_dict(heads[lane].state_dict());frozen={name:tensor_digest(model.get_submodule(name)) for name in FROZEN}
        if not frozen_source:frozen_source.update(frozen)
        assert frozen==frozen_source
        full=restore_logit_readout_adam(model,payload['optimizer'],plan['original_parameter_names']);attach_head_optimizer(full,optimizers[lane],model)
        for index,state in payload['optimizer']['state'].items():
            for key,value in state.items():
                actual=full.state_dict()['state'][index][key];assert torch.equal(value,actual) if torch.is_tensor(value) else value==actual
        atomic_save(dict(format_version=1,model=model.state_dict(),unified_vae_config=payload['unified_vae_config'],paired_logit_config=config,local_hint_config=payload['local_hint_config'],config=payload['config'],
            optimizer=full.state_dict(),source_hashes=hashes,step=step,source_steps=plan['source_steps'],lane=lane,phase='head_only_price_frozen',backbone_optimizer_updates=0,
            training_numeric_policy=plan.get('training_numeric_policy'),inference_numeric_policy=plan.get('inference_numeric_policy'),
            head_optimizer_calls=step,frozen_module_hashes=frozen,training_data=payload['training_data'],training_data_scope='Inherited source exposures plus separately recorded130parameterheadexposures',
            head_training_data=dict(indices=np.load(root/'train_indices.npy'),windows=32,exposures=2*step,epochs_equivalent=2*step/32),head_loss_variant=plan['lanes'][lane]),root/lane/f'step{step}.pt')
        previous_lane=plan.get('replay_controls',{}).get(lane)
        if previous_lane:
            old=torch.load(replay_checkpoint(root,plan,previous_lane,step),map_location='cpu',weights_only=False)
            for name,value in model.state_dict().items():torch.testing.assert_close(value,old['model'][name],rtol=0,atol=0)
            new=full.state_dict();assert new['param_groups']==old['optimizer']['param_groups']
            for index,state in old['optimizer']['state'].items():
                for key,value in state.items():
                    actual=new['state'][index][key];assert torch.equal(value.cpu(),actual.cpu()) if torch.is_tensor(value) else value==actual
            atomic_json(root/lane/f'step{step}_parent_replay.json',dict(passed=True,all_model_and_Adam_exact=True,parent_lane=previous_lane))
    for lane in labels:save(lane,0)
    check_replicas(0)
    atomic_json(root/'train_cache_step0.json',cache_metrics(heads,cache,plan));atomic_json(root/'status.json',dict(state='GPU_head_training',pid=os.getpid()))
    for step in range(1,plan['steps']+1):
        if time.monotonic()-started>plan['max_seconds']:raise TimeoutError('Declared3hourpairedheadstudyceiling')
        losses={}
        for lane,head in heads.items():
            opt=optimizers[lane];opt.zero_grad(set_to_none=True);value=0.
            for micro in range(2):
                row=cache[int(order[((step-1)*2+micro)%len(order)])];out=predict(head,row,plan['lanes'][lane],plan['normalization']['quantity_scale']);loss=objectives[lane](out,row['batch'])['loss'];assert bool(torch.isfinite(loss));(loss/2).backward();value+=float(loss.detach())/2
            grad=float(torch.nn.utils.clip_grad_norm_(head.parameters(),1.,error_if_nonfinite=True));opt.step();losses[lane]=value
            if step in [1,8]:
                assert grad>0;atomic_json(root/lane/f'step{step}_gradient_audit.json',dict(passed=True,head_gradient_norm=grad))
        for lane,head in replicas.items():
            opt=replica_optimizers[lane];opt.zero_grad(set_to_none=True)
            for micro in range(2):
                row=cache[int(order[((step-1)*2+micro)%len(order)])];out=predict(head,row,plan['lanes'][lane],plan['normalization']['quantity_scale']);loss=objectives[lane](out,row['batch'])['loss'];assert bool(torch.isfinite(loss));(loss/2).backward()
            torch.nn.utils.clip_grad_norm_(head.parameters(),1.,error_if_nonfinite=True);opt.step()
        if step==1 or step%8==0:atomic_json(root/'progress.json',dict(step=step,total=2048,losses=losses,elapsed_seconds=time.monotonic()-started,pid=os.getpid()));render(root)
        if step in plan['checkpoints']:
            for lane in labels:save(lane,step)
            check_replicas(step)
            atomic_json(root/f'train_cache_step{step}.json',cache_metrics(heads,cache,plan));evaluate_saved(root,step)
    assert file_hash(root/'source.pt')==plan['source_sha256'];atomic_json(root/'frozen_backbone_audit.json',dict(passed=True,source_weights_and_Adam_unchanged=True,backbone_updates=0,module_hashes=frozen_source))
    atomic_json(root/'status.json',dict(state='complete',pid=os.getpid(),elapsed_seconds=time.monotonic()-started,goal_automatically_completed=False));render(root);record(root.parent,'paired_logit_readout_complete',root=root.name,steps=2048)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--response-space',action='store_true');p.add_argument('--suffix',default='');p.add_argument('--reproducible',action='store_true');p.add_argument('--worker',action='store_true');a=p.parse_args();root=a.root.resolve()
    try:
        if a.prepare:prepare(root,a.response_space,a.suffix,a.reproducible)
        elif a.worker:worker(root)
    except BaseException as error:
        if not a.prepare:atomic_json(root/'status.json',dict(state='failed',pid=os.getpid(),error=repr(error)))
        raise
