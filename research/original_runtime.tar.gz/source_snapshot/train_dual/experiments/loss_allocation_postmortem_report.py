"""Render the stopped allocation study's measured evidence and causal limits."""
import argparse
import html
import json
from pathlib import Path

import numpy as np


def main(root):
    root = root.resolve()
    folder = root / 'postmortem'
    d = json.loads((folder/'evidence.json').read_text())
    plan = json.loads((root/'plan.json').read_text())
    distribution = d['distributions']
    for role in ['train','development']:
        ref = distribution['train' if role=='train' else 'val']['rms']
        initial = json.loads((root/'baseline'/('initial_seen_evaluation.json' if role=='train' else 'initial_evaluation.json')).read_text())['result']
        np.testing.assert_allclose(ref,initial['metrics']['quantity_btc']['target_rms'],rtol=1e-10)
    for v in d['previews'].values():
        mse=v['price_error_decomposition_mse']
        np.testing.assert_allclose(mse['total'],mse['translation']+mse['shape']+mse['cross'],rtol=1e-10)
    titles = [
        ('证据最强：4窗重复拟合导致开发退化',
         '只有4个256分钟窗口，共17.07小时独立数据，每个窗口追加训练1024遍。组合组训练数量RMSE从7.254降至5.853、分钟变化相关性从0.0066升至0.314；开发数量RMSE从2.182升至3.881、分钟变化相关性仍约0。训练数量相关性0.646，开发仅0.003。与记忆少量窗口特有模式、而非学到可迁移恢复机制相符。此为拟合诊断，不是代表性数据上的正式训练。'),
        ('实际分布差异：不能只比较原始RMSE',
         '训练平均挂量1.184BTC、开发0.379BTC；数量RMS分别7.454和2.217BTC。>=100BTC档位比例为0.0904%和0.00319%，约28倍差异。这是本次抽样的实测差异，不代表已证明整个2022–2024与2025的总体变化。归一化参数全组相同、均来自原64训练窗；不是训练/评估临时换了一套数量单位。'),
        ('损失偏重会制造幅度/误报权衡',
         '基线的线性数量Huber中，2048有效档位时Top16点相对普通点约33倍权重（不含log/分布/总量项）。基线训练>=100BTC召回77.7%，精确率40.7%，全局数量RMSE却比起点更差。开发基线只有1个真阳性、38577个假阳性。去掉Top16数量或提高全局权重能够缓解，但组合开发RMSE3.881仍高于起点2.182。损失分配确实改变优化结果，不能由此声称已经修复泛化。'),
        ('不只是偏一两个档位',
         '在三个预选展示窗口上，四组的>=100BTC峰值即使容忍同帧同侧±16档位，真实峰值覆盖仍为0。放宽到±64档，组合组也仅0.8%，其他组为0。该结果只覆盖3展示窗，不能外推成16窗的宽容匹配指标；它足以否定这3窗只是少量档位错位的解释。'),
        ('梯度正常不等于优化目标和泛化正常',
         '终点四组梯度审计无非有限值。在同一个固定训练窗口上，Encoder量价梯度余弦均为正（约0.12–0.82），开发表现仍退化；因此持续整体梯度对立不能单独解释结果。数量/价格Encoder梯度范数比约40–170，提示共享表示受到很不均衡的训练压力，但该单窗范数不等于Adam更新大小，也不证明价格退化完全由数量导致。'),
        ('结构仍可能限制细节，当前实验未分离其因果作用',
         '整帧4096→512、四帧2048→256、最终64×128瓶颈连续压缩，很多档位细节必须先经过这些投影。LoG只提示输入尖峰，不保证信息通过瓶颈。当前仍未充分拟合训练数量，尚不能证明8192足够；也没有证据把责任全部推给最近邻上采样。所有组beta0、Z=mu，当前现象不能归因于VAE采样噪声或KL正则。'),
    ]
    text=['<!doctype html><html lang=zh-CN><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1">',
          '<title>数量重建退化：实验复盘</title><script src=../public/plotly.min.js></script>',
          '<style>body{font:16px/1.85 system-ui;max-width:1400px;margin:28px auto;padding:0 20px;color:#1e293b}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ddd;padding:9px;text-align:right}th:first-child,td:first-child{text-align:left}.note{padding:16px;background:#fff7ed}a{color:#2563eb}</style>',
          '<h1>数量重建退化：停止后的实验复盘</h1><p class=note>用户要求停止时，本轮已完成1024步；核对远端无本轮残留训练进程，GPU2–5均已释放。保留全部检查点和结果，不启动下一轮训练。本页仅使用已有结果及CPU原始数据统计。</p>',
          '<p>主要判断：极少训练窗口反复拟合，叠加训练/开发数量分布差异和大单损失偏重。出现部分训练拟合，但尚未学到可迁移的订单簿细节恢复机制。以下区分实测事实和仍待控制实验验证的解释。</p>',
          '<h2>共同起点与终点</h2><table><thead><tr><th>方案</th><th>训练数量RMSE BTC</th><th>训练分钟数量变化相关性</th><th>开发数量RMSE BTC</th><th>开发价格RMSE USDT</th></tr></thead><tbody>']
    initial=d['curves']['baseline'][0]
    def row(label, item):
        a,b=item['train'],item['development']
        return f'<tr><td>{html.escape(label)}</td><td>{a["quantity_rmse"]:.3f}</td><td>{a["quantity_change_correlation"]:.4f}</td><td>{b["quantity_rmse"]:.3f}</td><td>{b["price_rmse"]:.3f}</td></tr>'
    text.append(row('共同起点',initial))
    for lane,label in plan['labels'].items():
        text.append(row(label,d['curves'][lane][-1]))
    text.append('</tbody></table>')
    for title,body in titles:
        text += [f'<h2>{title}</h2><p>{body}</p>']
    text += ['<h2>下一步应如何分离原因（未启动）</h2><ol>'
             '<li>将小样本拟合与泛化训练分成两条流程。拟合诊断先验证单窗/4窗能否恢复幅度、档位和时间；正式训练应回到覆盖多个市场阶段的代表性训练集，不能用4窗反复训练代替。</li>'
             '<li>在代表性训练数据上做匹配的训练数据规模对照，固定结构、初始权重、目标和更新预算。比较同一起点的32/128/512/更充分数据，报告每窗曝光次数和完整训练/开发轨迹；不要只与本轮已经退化的基线比较。</li>'
             '<li>数量细节仍拟合不动时，先分离编码器信息丢失与解码器表达：固定真实/缓存特征只拟合解码器，或用独立训练变量直接优化latent。若能解码却编码不出，再改编码器；若仍无法拟合，再控制比较空间种子/残差解码器。固定8192设计，较宽latent只作为容量对照。</li>'
             '<li>价格与数量任务同时保留各自指标。以共同起点和匹配对照双重检查价格、数量和动力学；数量RMSE改善但精确率/召回或价格恶化要明确报告权衡。</li></ol>',
             '<p>限制：单种子42；16个2025Q1窗口已用于开发；邻域和中间价分解只涉及3预选展示窗。没有2026独立样本外结论。数据差异、过拟合和结构限制还没有被一个完整因子实验因果分离。</p>',
             '<p><a href=../results/step1024/>完整终点表格与训练曲线</a> · <a href=../previews/step1024/viewer/>完整256帧逐档图</a> · <a href=evidence.json>实测证据JSON</a></p></html>']
    (folder/'index.html').write_text('\n'.join(text))
    (folder/'conclusions.json').write_text(json.dumps(dict(findings=[dict(title=t,text=b) for t,b in titles],
        evidence='evidence.json',training_stopped=True,new_training_launched=False,
        raw_statistics_and_price_decomposition_checks='passed'),ensure_ascii=False,indent=2)+'\n')
    print(folder)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root',type=Path)
    main(parser.parse_args().root)
