"""Queued loss-only quantity-scale controls; protect the complete book."""
import argparse
import html
import math
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

import numpy as np
import torch

from model.losses.quantity_strata import StratifiedQuantityBookLoss
from train_dual.experiments import local_hint_run as shared
from train_dual.experiments.confirm_recall_goal import require_matching_replay
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.goal_evaluate import assess_file
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read, STYLE
from train_dual.experiments.price_safe_readout import file_hash
from train_dual.experiments.quantity_strata_setup import MULTIPLIERS
from train_dual.experiments.recall_goal_run import candidates, record, render as render_goal
from train_dual.experiments.region_task_run import gpu_free
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import atomic_save, freeze_sources, load_for_inference, seed_everything
from train_dual.util.hint_training import restore_regional_phase_adam
from train_dual.util.phase_training import tensor_digest
from train_dual.util.quantity_strata import evaluate_with_quantity_strata


LABELS=dict(control='原损失控制',quarter='分桶权重0.25倍',unit='分桶权重1倍',four='分桶权重4倍')


def owned_predecessor_live(parent, pid, proc_root=Path('/proc')):
    try: args=(proc_root/str(pid)/'cmdline').read_bytes().split(b'\0')
    except FileNotFoundError:return False
    return b'train_dual.experiments.fine_phase_run' in args and os.fsencode(str(parent)) in args and b'--controller' in args


def bound_small_order_review(goal,candidate):
    review=read(goal/'small_order_candidate_review.json',{})
    if not review or review.get('candidate_checkpoint_sha256')!=file_hash(Path(candidate['checkpoint'])):return None
    decision=review.get('whole_book_candidate_accepted')
    evidence=review.get('strata_evidence')
    if type(decision) is not bool or not evidence or not (goal/evidence).is_file():
        raise ValueError('Need an explicit review tied to existing quantity-strata evidence')
    return decision


def render(root):
    plan=read(root/'plan.json');state=read(root/'status.json',{})
    text='<h1>完整订单簿：分数量级均衡重建损失</h1><p>完整256分钟、双侧2048档、唯一64×128Gaussian。四组使用同一个region_shape/2048来源、原三组Adam与RNG、1024训练窗/增强/teacher/seed42和2048更新，仅改变新增分桶Huber权重0/.25/1/4。模型、输入特征、空间上采样和原损失均保留，没有新增模型参数。</p>'
    if not plan.get('queue_only'):
        text+='<table><tr><th>组</th><th>训练步</th><th>评估步</th><th>100BTC召回</th><th>精确率</th><th>价格RMSE</th><th>数量RMSE</th></tr>'
        for step in [0,*plan['checkpoints']]:
            for lane,label in LABELS.items():
                path=root/lane/f'step{step}_development.json'
                if not path.exists():continue
                d=assess_file(path,root.parent/'reference_evaluation.json')
                vals=[label,read(root/lane/'progress.json',{}).get('step',0),step,d['recall100'],d['precision100'],d['price_rmse'],d['quantity_rmse']]
                text+='<tr>'+''.join('<td>'+html.escape(f'{v:.6g}' if isinstance(v,float) else str(v))+'</td>' for v in vals)+'</tr>'
        text+='</table><h2>各真实数量区间：数量误差≤20%的比例</h2><table><tr><th>组</th><th>评估步</th><th>0–.01</th><th>.01–.1</th><th>.1–1</th><th>1–10</th><th>10–100</th><th>≥100BTC</th></tr>'
        for step in [0,*plan['checkpoints']]:
            for lane,label in LABELS.items():
                value=read(root/lane/f'step{step}_development.json',{}).get('result',{})
                if 'quantity_strata' not in value:continue
                vals=[label,step]+[f"{v['within20percent']:.2%}" if v['within20percent'] is not None else '无样本' for v in value['quantity_strata']]
                text+='<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in vals)+'</tr>'
        text+='</table>'
    text+='<p>六区间的归一化尺度仅由8个既有训练窗拟合；一个公共附加权重在实际GPU训练前用同8窗mu头梯度RMS校准并锁定。全部检查点保留分桶MAE/RMSE/log误差/幅度偏差及0.5–2倍比例。</p><p>Q1已反复用于开发，非独立测试。100BTC召回过线不能表示整本重建成功；小、中单恢复仍须单独审查，本程序不自动消耗Q2或宣布目标完成。</p><p>状态：'+html.escape(str(state))+'</p><p><a href="plan.json">协议</a> · <a href="quantity_calibration.json">训练集尺度与梯度校准</a> · <a href="../quantity_strata_audit_20261028_1333/">大小挂单诊断</a></p>'
    (root/'index.html').write_text('<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="30"><style>'+STYLE+'</style><main>'+text+'</main>')


def prepare_queue(goal,parent_pid):
    preparation=goal/'quantity_strata_preparation_v2';p=read(preparation/'plan.json');cal=read(preparation/'quantity_calibration.json')
    assert p['preparation_only'] and cal['neural_forward_calls']==cal['optimizer_updates']==0
    assert len(cal['training_indices'])==8 and len(cal['RMS_scales_BTC'])==6
    assert file_hash(preparation/'source.pt')==p['source_sha256']
    project=Path(__file__).resolve().parents[2]
    for name,digest in read(preparation/'source_snapshot/sha256.json').items():
        if name.startswith('model/') and file_hash(project/name)!=digest:raise ValueError('Loss/model changed since scale preparation: '+name)
    root=goal/'quantity_strata_after_fine';root.mkdir();(root/'logs').mkdir()
    atomic_json(root/'plan.json',dict(queue_only=True,parent_queue='fine_phase_after_v2',parent='round_006_fine_phase',parent_pid=parent_pid,
        preparation=preparation.name,source_sha256=p['source_sha256'],wait_seconds=13*3600,steps=2048,
        checkpoints=[256,512,1024,2048],max_seconds=43200,seed=42,
        controls='Loss-only continuation of one fixed regional shape source. No architecture/input/upsampling change.',
        candidate_policy='Any old-gate candidate needs explicit autonomous whole-book strata review before confirmation or new training; elapsed waiting is not approval.'))
    atomic_json(root/'status.json',dict(state='prepared_not_started'));freeze_sources(root/'source_snapshot');render(root)
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 CUDA_DEVICE_ORDER=PCI_BUS_ID OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.quantity_strata_run "{remote}" --controller >> "{remote}/logs/controller.log" 2>&1\n')
    record(goal,'quantity_strata_queue_prepared',root=root.name,parent_pid=parent_pid,source='Fixed region_shape2048,3Adam, no architecture change')
    print(root.resolve(),flush=True)


def prepare_actual(queue):
    goal=queue.parent;study=read(queue/'plan.json');prepared=goal/study['preparation'];plan=read(prepared/'plan.json')
    assert file_hash(prepared/'source.pt')==study['source_sha256']
    root=goal/'round_007_quantity_strata';root.mkdir()
    for name in ['data','logs','seen','unseen',*LABELS]:(root/name).mkdir()
    for split in ['seen','unseen']:
        for lane in LABELS:(root/split/lane).mkdir()
    for name in ['source.pt','teacher.pt','calibration.json','train_indices.npy','val_indices.npy','seen_indices.npy','unseen_indices.npy','quantity_calibration_indices.npy','plotly.min.js']:
        os.link(prepared/name,root/name)
    os.link(prepared/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    shutil.copy2(prepared/'quantity_calibration.json',root/'quantity_calibration.json')
    payload=torch.load(root/'source.pt',map_location='cpu',weights_only=False)
    assert payload['epoch_boundary'] and len(payload['optimizer']['param_groups'])==3
    model,_=load_for_inference(root/'source.pt','cpu')
    assert model.use_shape and not model.use_mass
    optimizer=restore_regional_phase_adam(model,payload['optimizer'],plan['original_parameter_names'])
    assert optimizer.state_dict()['param_groups']==payload['optimizer']['param_groups']
    plan.update(preparation_only=False,queue_only=False,initial_model_sha256=tensor_digest(model),
        source=str(root/'source.pt'),source_parent=str(goal/'round_005_regional_phase'),
        source_evaluation=str(goal/'round_005_regional_phase/shape/step2048_development.json'),goal_root=str(goal),
        steps=study['steps'],checkpoints=study['checkpoints'],max_seconds=study['max_seconds'],
        gpu_workers=[[g,l] for g,l in zip([2,3,4,5],LABELS)],worker_module='train_dual.experiments.quantity_strata_run',
        preview_descriptions={l:'完整256分钟、唯一8192Gaussian，同一来源继续训练，只改变分数量级损失权重。固定Q1开发样本，非独立测试。' for l in LABELS})
    atomic_save(dict(format_version=1,model=payload['model'],unified_vae_config=payload['unified_vae_config'],
        local_hint_config=payload['local_hint_config'],regional_phase_config=payload['regional_phase_config'],config=payload['config'],step=0),root/'initial.pt')
    atomic_json(root/'plan.json',plan)
    for split in ['seen','unseen']:
        atomic_json(root/split/'plan.json',dict(plan,preview_descriptions={l:'训练年代诊断，非独立测试。完整256分钟。' for l in LABELS}))
        os.link(root/'plotly.min.js',root/split/'plotly.min.js')
    atomic_json(root/'status.json',dict(state='prepared_requires_gradient_calibration'));freeze_sources(root/'source_snapshot');render(root)
    return root


def criterion(root,lane,device='cuda:0',*,calibrating=False):
    plan=read(root/'plan.json');old=read(root/'calibration.json');cal=read(root/'quantity_calibration.json')
    if not calibrating and (cal['state']!='complete' or not cal['weight_calibration_locked']):raise ValueError('Quantity weight calibration not locked')
    coefficient=0. if calibrating else cal['base_weight']*MULTIPLIERS[lane]
    return StratifiedQuantityBookLoss(plan['normalization']['quantity_scale'],bin_scales=cal['RMS_scales_BTC'],stratified_weight=coefficient,
        mode='shape_mass',use_hint=True,hint_weight=old['hint_weight'],hint_mean=old['channel_mean'],hint_scale=old['channel_scale'],
        use_tail=True,protect_mid=True,tail_weight=old['tail_weight'],mid_weight=old['mid_weight'],
        mid_delta_weight=plan['lanes'][lane]['mid_delta_weight'],add_wasserstein=False,add_multiscale=False,
        **plan['source_FP_rule'],**plan['objective']).to(device)


def calibrate(root):
    torch.set_num_threads(4);seed_everything(42);strict_precision()
    plan=read(root/'plan.json');cal=read(root/'quantity_calibration.json');assert not cal['weight_calibration_locked']
    assert file_hash(root/'source.pt')==plan['source_sha256']
    model,norm=load_for_inference(root/'source.pt','cuda:0');model.train();before=tensor_digest(model)
    teacher,tn=load_for_inference(root/'teacher.pt','cuda:0');teacher.eval().requires_grad_(False);teacher_hash=tensor_digest(teacher)
    objective=criterion(root,'control',calibrating=True);data=dataset(root,'train');indices=np.load(root/'quantity_calibration_indices.npy')
    assert indices.tolist()==cal['training_indices'] and set(indices.tolist())<=set(np.load(root/'train_indices.npy').tolist())
    parameters=list(model.encoder.mu.parameters());base2=[];new2=[];cosines=[]
    for number,index in enumerate(indices):
        raw={k:v.unsqueeze(0) for k,v in data[int(index)].items()};offset=int(data.base.starts[int(index)]);absolute=data.base.times[offset:offset+256]
        assert list(raw['data'].shape)==[1,256,2,2048,2] and np.all(np.diff(absolute//60_000_000)==1)
        target=shared.teacher_local(teacher,tn,raw);batch=norm.prepare(raw,'cuda:0');seen=[]
        hooks=[m.register_forward_pre_hook(lambda m,a:seen.append(a[0])) for m in [model.price_decoder,model.volume_decoder]]
        with torch.autocast('cuda',dtype=torch.bfloat16):out=call(model,batch,False)
        for hook in hooks:hook.remove()
        assert seen[0] is seen[1] is out['z'] and list(out['z'].shape)==[1,64,128]
        assert list(out['volume'].shape)==[1,256,2,2048]
        values=objective(out,batch,teacher_local=target)
        assert bool(torch.isfinite(values['loss']) and torch.isfinite(values['stratified_quantity']))
        a=torch.autograd.grad(values['pre_stratified_loss'],parameters,retain_graph=True)
        b=torch.autograd.grad(values['stratified_quantity'],parameters)
        aa=sum(float(v.float().square().sum()) for v in a);bb=sum(float(v.float().square().sum()) for v in b)
        base2.append(aa);new2.append(bb);dot=sum(float((x.float()*y.float()).sum()) for x,y in zip(a,b))
        cosines.append(dot/math.sqrt(aa*bb) if aa*bb else None)
        atomic_json(root/'gradient_calibration_progress.json',dict(windows=number+1,total=8,optimizer_updates=0))
    base_rms,new_rms=math.sqrt(float(np.mean(base2))),math.sqrt(float(np.mean(new2)))
    assert base_rms>0 and new_rms>0 and math.isfinite(base_rms+new_rms)
    assert tensor_digest(model)==before and tensor_digest(teacher)==teacher_hash and all(p.grad is None for p in model.parameters())
    cal.update(state='complete',base_weight=base_rms/new_rms,weight_calibration_locked=True,
        base_mu_gradient_RMS=base_rms,raw_stratified_mu_gradient_RMS=new_rms,per_window_gradient_cosines=cosines,
        student_forward_calls=8,teacher_feature_extractions=8,neural_forward_calls=16,optimizer_updates=0,source_model_and_teacher_unchanged=True,
        actual_raw=[1,256,2,2048,2],posterior=[1,64,128],output=[1,256,2,2048],shared_single_Z=True,
        scope='Eight fixed training windows only; BF16 neural forward and FP32 loss, zero optimizer updates, no development calibration.')
    atomic_json(root/'quantity_calibration.json',cal)
    assert file_hash(root/'source.pt')==plan['source_sha256']
    for lane in LABELS:plan['checkpoint_extras'][lane]['stratified_quantity_loss_config']=dict(
        lower_BTC=cal['lower_BTC'],scales_BTC=cal['RMS_scales_BTC'],weight=cal['base_weight']*MULTIPLIERS[lane],multiplier=MULTIPLIERS[lane])
    atomic_json(root/'plan.json',plan);render(root)


def audit_startup(root):
    rows={lane:read(root/lane/'step1_data_audit.json') for lane in LABELS}
    if not all(rows.values()) or not all((root/lane/'step8_gradient_audit.json').exists() for lane in LABELS):return False
    plan=read(root/'plan.json');cal=read(root/'quantity_calibration.json');base=rows['control']
    source=read(Path(plan['source_evaluation']))['result']
    for lane,row in rows.items():
        assert row['training_indices']==base['training_indices'] and row['edits']==base['edits']
        for key in ['pre_stratified_loss','stratified_quantity']:
            assert row['losses'][key]==base['losses'][key]
        expected=base['losses']['loss']+MULTIPLIERS[lane]*cal['base_weight']*base['losses']['stratified_quantity']
        assert math.isclose(row['losses']['loss'],expected,rel_tol=5e-6,abs_tol=5e-6)
        assert read(root/lane/'actual_shape_contract.json')['passed'] and read(root/lane/'restore_audit.json')['restored_groups']==3
        require_matching_replay(read(root/lane/'step0_development.json')['result'],source)
    # Full source state and all three Adam groups, without requiring a fresh optimizer.
    old=torch.load(root/'source.pt',map_location='cpu',weights_only=False,mmap=True)
    for lane in LABELS:
        new=torch.load(root/lane/'step0.pt',map_location='cpu',weights_only=False,mmap=True)
        assert new['model'].keys()==old['model'].keys()
        for name,value in old['model'].items():torch.testing.assert_close(new['model'][name],value,rtol=0,atol=0)
        assert new['optimizer']['param_groups']==old['optimizer']['param_groups']
        assert new['optimizer']['state'].keys()==old['optimizer']['state'].keys()
        for index,state in old['optimizer']['state'].items():
            for key,value in state.items():
                if torch.is_tensor(value):torch.testing.assert_close(new['optimizer']['state'][index][key],value,rtol=0,atol=0)
                else:assert new['optimizer']['state'][index][key]==value
    atomic_json(root/'startup_control_audit.json',dict(passed=True,same_source_weights_all_three_Adam_groups_exact=True,
        same_first_inputs_edits_and_unweighted_components=True,only_declared_weight_changes_loss=True,
        published_source_development_replayed=True,actual_full_shape_and_layer_gradients_passed=True))
    return True


def run_cohort(root):
    children=[];plan=read(root/'plan.json');begin=time.monotonic();audited=False
    try:
        for gpu,lane in plan['gpu_workers']:
            env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),PYTHONPATH=str(root/'source_snapshot'))
            with (root/'logs'/f'{lane}.log').open('ab',buffering=0) as log:
                child=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.quantity_strata_run',str(root),'--lane',lane],
                    cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            children.append(child)
        atomic_json(root/'status.json',dict(state='running',pids=[c.pid for c in children]))
        while any(c.poll() is None for c in children):
            if any(c.poll() not in [None,0] for c in children):raise RuntimeError('Owned quantity-strata worker failed')
            if time.monotonic()-begin>plan['max_seconds']+1800:raise TimeoutError('12hour training plus30min evaluation ceiling')
            if not audited:audited=audit_startup(root)
            render(root);time.sleep(10)
        if any(c.returncode for c in children) or not (audited or audit_startup(root)):raise RuntimeError('Missing completed worker/source audit')
        atomic_json(root/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-begin));render(root)
    finally:
        for c in children:
            if c.poll() is None:os.killpg(c.pid,signal.SIGTERM)


def controller(queue):
    config=read(queue/'plan.json');goal=queue.parent;parent=goal/config['parent_queue'];cohort=goal/config['parent'];begin=time.monotonic()
    while True:
        state=read(parent/'status.json',{});live=owned_predecessor_live(parent,config['parent_pid'])
        if state.get('state')=='failed':raise RuntimeError('Fine predecessor failed; preserve controls and inspect')
        if not live:
            if state.get('state')=='complete' and read(cohort/'status.json',{}).get('state')=='complete':break
            raise RuntimeError('Verified predecessor handle missing without successful terminal state')
        if time.monotonic()-begin>config['wait_seconds']:raise TimeoutError('13hour predecessor wait ceiling')
        atomic_json(queue/'status.json',dict(state='verified_wait_parent',pid=os.getpid(),parent_pid=config['parent_pid']));render(queue);time.sleep(20)
    qualified=[r for r in candidates(cohort,goal/'reference_evaluation.json') if r['pass']]
    if (goal/'candidate_for_confirmation.json').exists() or qualified:
        candidate=read(goal/'candidate_for_confirmation.json') if (goal/'candidate_for_confirmation.json').exists() else max(qualified,key=lambda row:row['recall100'])
        decision=bound_small_order_review(goal,candidate)
        while decision is None:
            if time.monotonic()-begin>config['wait_seconds']:raise TimeoutError('Whole-book candidate review pending')
            atomic_json(queue/'status.json',dict(state='waiting_small_order_candidate_review',pid=os.getpid(),checkpoint=candidate['checkpoint']));render(queue);time.sleep(20)
            decision=bound_small_order_review(goal,candidate)
        if decision:
            atomic_json(queue/'status.json',dict(state='not_run_candidate_requires_confirmation'));render(queue);return
    while any(gpu_free().get(g,0)<47000 for g in [2,3,4,5]):
        if time.monotonic()-begin>config['wait_seconds']:raise TimeoutError('GPU release wait ceiling')
        atomic_json(queue/'status.json',dict(state='verified_wait_GPU_release',pid=os.getpid()));render(queue);time.sleep(10)
    root=prepare_actual(queue)
    atomic_json(queue/'status.json',dict(state='training_only_GPU_gradient_calibration',pid=os.getpid(),wave=root.name));render(queue)
    env=dict(os.environ,CUDA_VISIBLE_DEVICES='2',PYTHONPATH=str(root/'source_snapshot'))
    with (root/'logs/gradient_calibration.log').open('ab',buffering=0) as log:
        result=subprocess.run([sys.executable,'-u','-m','train_dual.experiments.quantity_strata_run',str(root),'--calibrate'],
            cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=3600)
    if result.returncode or not read(root/'quantity_calibration.json').get('weight_calibration_locked'):raise RuntimeError('Training-only GPU calibration failed before updates')
    atomic_json(queue/'status.json',dict(state='running',pid=os.getpid(),wave=root.name));atomic_json(goal/'status.json',dict(state='running_loss_only_quantity_strata_cohort',wave=root.name));render(queue)
    run_cohort(root)
    rows=candidates(root,goal/'reference_evaluation.json');old=read(goal/'candidates.json',{}).get('rows',[])
    atomic_json(goal/'candidates.json',dict(rows=[r for r in old if r.get('experiment')!=root.name]+[dict(r,experiment=root.name) for r in rows]))
    atomic_json(goal/'status.json',dict(state='cohort_complete_requires_full_quantity_strata_review',wave=root.name,goal_achieved=False))
    atomic_json(queue/'status.json',dict(state='complete',wave=root.name,goal_automatically_completed=False));render(queue);render_goal(goal)
    record(goal,'quantity_strata_cohort_complete',root=root.name,independent_data_read=False,next='Review all quantity scales, price and large-order metrics; no automatic confirmation or success from100BTCrecall alone')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--parent-pid',type=int)
    p.add_argument('--controller',action='store_true');p.add_argument('--calibrate',action='store_true');p.add_argument('--lane',choices=list(LABELS));args=p.parse_args();root=args.root.resolve()
    def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        if args.prepare:
            if not args.parent_pid:p.error('--parent-pid required')
            prepare_queue(root,args.parent_pid)
        elif args.calibrate:calibrate(root)
        elif args.lane:
            shared.evaluate=evaluate_with_quantity_strata
            shared.worker(root,args.lane,objective_factory=criterion,optimizer_factory=restore_regional_phase_adam)
        elif args.controller:controller(root)
    except BaseException as error:
        if not args.prepare:atomic_json((root/args.lane if args.lane else root)/'status.json',dict(state='failed',pid=os.getpid(),error=repr(error)))
        raise
