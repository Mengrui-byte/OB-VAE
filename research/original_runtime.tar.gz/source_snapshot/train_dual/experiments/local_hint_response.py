"""After training, compare held-fixed quantity edits at a common saved endpoint."""
import argparse
import html
import json
import os
from pathlib import Path
import time

import numpy as np
import torch

from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read,fmt,STYLE
from train_dual.experiments.region_task_run import gpu_free
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import load_for_inference


def render(folder):
    status=read(folder/'status.json',{});result=read(folder/'results.json',{})
    parts=[f'<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta http-equiv="refresh" content="30"><title>大单输入响应：训练后核验</title><style>{STYLE}</style><main>',
        '<h1>训练后：大单位置、幅度与消失的响应</h1>',
        f'<div class="note">状态：{html.escape(status.get("state","waiting"))}。等待四组结束和GPU空闲后，只读评估，不训练、不使用2025Q2/2026。</div>',
        '<p>固定4个见过的训练窗口与4个未参与当前学生梯度训练的2022–2024窗口；教师历史可能见过后者，不是完整系统独立测试。每窗对最大挂量做位置交换、加倍、清除，价格和mask不变。增益=该位置预测增量/真实增量，1表示该位置增量准确，0表示没有响应；少量局部干预不代表全局能力。</p>',
        '<p>新学生使用四组共同保存的最大声明步数，报告同预算结果。初始模型与旧高容量教师另列为参考，不作为等历史成本对照。</p>',
        '<div class="wrap"><table><tr><th>模型</th><th>窗口类</th><th>编辑</th><th>窗口数</th><th>原位置增益中位数</th><th>新位置增益中位数</th></tr>']
    groups={}
    for row in result.get('records',[]):groups.setdefault((row['model'],row['split'],row['mode']),[]).append(row)
    for (model,split,mode),rows in groups.items():
        def median(position):
            values=[r['positions'][position]['gain'] for r in rows if r['positions'][position]['gain'] is not None]
            return float(np.median(values)) if values else None
        values=[model,split,mode,str(len(rows)),fmt(median(0)),fmt(median(1)) if mode=='swap' else '—']
        parts.append('<tr>'+''.join(f'<td>{html.escape(v)}</td>' for v in values)+'</tr>')
    parts.extend(['</table></div><p><a href="results.json">逐个响应、数量及全输出增量</a> · <a href="selection.json">预先固定的数据选择</a> · <a href="source_snapshot/sha256.json">独立评估源码哈希</a> · <a href="../">返回主训练报告</a></p></main></html>'])
    temporary=folder/'index.tmp';temporary.write_text(''.join(parts));temporary.replace(folder/'index.html')


def run(root):
    torch.set_num_threads(4);strict_precision();folder=root/'response_after';started=time.monotonic()
    selection=read(folder/'selection.json')
    while True:
        state=read(root/'status.json',{})
        if state.get('state')=='failed':
            atomic_json(folder/'status.json',dict(state='not_run_parent_failed',parent=state));render(folder);return
        if state.get('state')=='complete':break
        if time.monotonic()-started>13*3600:raise TimeoutError('13hour monitoring ceiling')
        atomic_json(folder/'status.json',dict(state='waiting_for_training_completion',parent_state=state.get('state')));render(folder);time.sleep(30)
    waiting=time.monotonic()
    while gpu_free().get(2,0)<47000:
        if time.monotonic()-waiting>1800:raise TimeoutError('GPU2 not idle after30minutes; no jobs displaced')
        time.sleep(20)
    lanes=['control','hint','augmentation','both'];plan=read(root/'plan.json')
    common=[step for step in [0,*plan['checkpoints']] if all((root/lane/f'step{step}.pt').exists() for lane in lanes)]
    endpoint=max(common)
    models=[('shared_initial',root/'source.pt'),('higher_latent_teacher',root/'teacher.pt'),*[(lane,root/lane/f'step{endpoint}.pt') for lane in lanes]]
    original=dataset(root,'train');records=[];evaluation_started=time.monotonic()
    for name,path in models:
        model,norm=load_for_inference(path,'cuda:0')
        for split,indices in selection['indices'].items():
            for index in indices:
                if time.monotonic()-evaluation_started>900:raise TimeoutError('Response evaluation15minute ceiling')
                item=original[int(index)];raw={k:v.unsqueeze(0) for k,v in item.items()}
                with torch.inference_mode():baseline=call(model,norm.prepare(raw,'cuda:0'),False)['volume'][0].cpu()
                q=item['data'][...,1];valid=torch.arange(q.shape[-1])<item['level_counts'][...,None]
                t,side,rank=np.unravel_index(int(q.masked_fill(~valid,-torch.inf).argmax()),q.shape)
                n=int(item['level_counts'][t,side]);destination=(int(rank)+17)%n
                if destination==rank:destination=(destination+1)%n
                for mode in ['swap','double','erase']:
                    changed={k:v.clone() for k,v in item.items()};d=changed['data']
                    if mode=='swap':d[t,side,rank,1],d[t,side,destination,1]=q[t,side,destination].clone(),q[t,side,rank].clone()
                    elif mode=='double':d[t,side,rank,1]*=2
                    else:d[t,side,rank,1]=0
                    with torch.inference_mode():prediction=call(model,norm.prepare({k:v.unsqueeze(0) for k,v in changed.items()},'cuda:0'),False)['volume'][0].cpu()
                    delta=prediction-baseline;truth=d[...,1]-q;positions=[]
                    for level in [int(rank),int(destination)]:
                        td=float(truth[t,side,level]);pd=float(delta[t,side,level])
                        positions.append(dict(level=level,true_before=float(q[t,side,level]),true_after=float(d[t,side,level,1]),prediction_before=float(baseline[t,side,level]),prediction_after=float(prediction[t,side,level]),target_delta=td,predicted_delta=pd,gain=pd/td if td else None))
                    records.append(dict(model=name,split=split,source_index=int(index),time=int(t),side=int(side),mode=mode,positions=positions,target_delta_l1=float(truth.abs().sum()),prediction_delta_l1=float(delta.abs().sum())))
                    atomic_json(folder/'results.json',dict(common_additional_step=endpoint,records=records,scope=selection['scope']))
                    atomic_json(folder/'status.json',dict(state='evaluating',model=name,records=len(records),common_additional_step=endpoint));render(folder)
        del model;torch.cuda.empty_cache()
    atomic_json(folder/'status.json',dict(state='complete',common_additional_step=endpoint,records=len(records),gpu_seconds=time.monotonic()-evaluation_started));render(folder)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('root',type=Path);args=parser.parse_args()
    root=args.root.resolve()
    try:run(root)
    except BaseException as error:
        atomic_json(root/'response_after/status.json',dict(state='failed',error=repr(error)));render(root/'response_after');raise
