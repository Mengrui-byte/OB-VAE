"""Matched training-coverage study:64/256/1024/all complete training windows."""
import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path

import numpy as np

from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.loss_control_run import campaign, worker
from train_dual.util.checkpoint import freeze_sources
from train_dual.util.experiment_sampling import nested_month_subsets


def prepare(parent):
    parent=parent.resolve()
    project=Path(__file__).resolve().parents[2]
    root=project/'recons'/('data_scale_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
    root.mkdir()
    for name in ['data','logs','indices']:(root/name).mkdir()
    for name in ['train_indices.npy','val_indices.npy']:
        os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    os.link(parent/'full/step512.pt',root/'initial.pt')
    os.link(parent/'full/step512_evaluation.json',root/'initial_expected.json')
    os.link(parent/'full/step512_seen_evaluation.json',root/'initial_seen_expected.json')
    os.link(parent/'full/step512_profiles.npz',root/'source_profiles.npz')
    plan=json.loads((parent/'plan.json').read_text())
    atomic_json(root/'plan.json',plan)
    train=dataset(root,'train')
    total=len(train)
    if total<1024:raise ValueError('Training pool smaller than declared1024-window group')
    base=np.load(root/'train_indices.npy')
    if len(base)!=64:raise ValueError('Source normalization/coverage control must contain64windows')
    starts=train.base.starts
    start_us=train.base.times[starts]
    end_us=train.base.times[starts+255]
    assert np.all(start_us>=np.datetime64('2022-01-01','us').astype(np.int64))
    assert np.all(end_us<np.datetime64('2025-01-01','us').astype(np.int64))
    months=start_us.astype('datetime64[us]').astype('datetime64[M]').astype(str)
    subsets=nested_month_subsets(months,base,[64,256,1024,total],seed=42)
    labels={'n64':'64训练窗·匹配对照','n256':'256训练窗','n1024':'1024训练窗','all':f'全部{total}训练窗'}
    sizes=dict(zip(labels,[64,256,1024,total]))
    files={}
    manifest={}
    for lane,n in sizes.items():
        indices=subsets[n]
        files[lane]=f'indices/{lane}.npy'
        np.save(root/files[lane],indices)
        month_names,counts=np.unique(months[indices],return_counts=True)
        manifest[lane]=dict(windows=n,monthly_counts=dict(zip(month_names.tolist(),counts.tolist())),
            first_window_start=str(start_us[indices].min().astype('datetime64[us]')),
            last_window_end=str(end_us[indices].max().astype('datetime64[us]')),
            indices_sha256=hashlib.sha256((root/files[lane]).read_bytes()).hexdigest(),
            planned_epochs_equivalent=2048*4/n,includes_source64=bool(np.isin(base,indices).all()))
    seen=base[np.unique(np.linspace(0,len(base)-1,8,dtype=int))]
    np.save(root/'seen_indices.npy',seen)
    previous=Path(Path('/tmp/loss_allocation_path').read_text().strip())
    plan.update(
        experiment='Training-data coverage control;64/256/1024/all;architecture and loss fixed',
        parent=str(parent), pretraining_steps=2816,
        source_checkpoint='gradient_route/full/step512: AE2048+shape_mass256+full-route512, before4-window fitting; matched control, not development-best lane',
        source_initial_sha256=hashlib.sha256((root/'initial.pt').read_bytes()).hexdigest(),
        labels=labels,lanes={lane:dict(mode='shape_mass') for lane in labels},
        loss_family='controlled',training_indices_files=files,training_windows_by_lane=sizes,
        fit_windows=64,seen_windows=8,seen_indices_file='seen_indices.npy',
        initial_seen_evaluation=True,track_data_exposures=True,
        steps=2048,checkpoints=[128,512,1024,2048],max_seconds=14400,queue_max_seconds=7200,
        wait_for_relative=str(parent.relative_to(project)),
        wait_for_relatives=[str(p.relative_to(project)) for p in [parent,previous]],
        objective=dict(price_weight=1.,quantity_weight=1.,log_weight=1.,pair_weight=.25,topk=16,shape_weight=1.,mass_weight=1.),
        default_variant='n64',viewer_default_model=2,viewer_route='data_scale',
        viewer_source_label='共同2816步起点·四窗口微调前·8192',
        initialization='Same2816-update source model+AdamWmoments, all prior pretraining on the common64-window pool. Identicalseed42 sampler restart, different nested training pools. Not a from-scratch comparison and not an exact continuation of source sampling.',
        hypothesis='If scarce distinct windows caused memorization, increasing training coverage at fixed updates should improve development quantity dynamics and reduce spurious large peaks, possibly while lowering repeated-fit performance on common seen windows.',
        control_contract=dict(
            fixed=['same2816-update source and optimizer state','complete256frames,2sides,2048levels,unique64x128latent',
                   'same nearest+conv decoder and full quantity-gradient routes','same shape_mass loss and all weights',
                   'same normalization fitted only on source64training windows; no refitting per group',
                   'same16development windows and same8seen training windows',
                   'seed42,AdamW1e-4,weight_decay0,clip1,batch1accum4,2048updates',
                   'BF16train,FP32eval,FP64 inverse prices,TF32off'],
            variable='Only the pool of distinct training windows: nested64/256/1024/all.',
            sampling='Keep original64; extend by balancing selected fractions of each UTC month, randomizing within each month withseed42. No quantity values or development errors used to select data.',
            budget='Equal8192 window presentations; epoch equivalents128/32/8/'+str(8192/total)+'. Larger groups receive fewer passes; failure at this budget does not prove enough training.',
            diagnostics='Same8original training indices are included in every pool. Different randomly spaced train diagnostics must not be compared as if identical data.',
            source_history='All groups share prior64-window training; this tests additional coverage after common pretraining, not total-history sample complexity.'),
        selection='Compare every checkpoint and fixed2048 endpoint to n64 at matched updates AND to common initial model. Exploratory candidate gate:development quantityRMSE>=5% below n64 and below initial;minute log-quantity change correlation>=.10;priceRMSE<=1.10x n64 AND<=1.10x initial. Always disclose >=10/100BTC precision/recall/falsepositives and train fit; gate is screening, not independent-test proof.',
        reference='Viewer source is the exact common8192 initialization. n64 is the same-budget matched control.',
        viewer_description=f'训练数据规模单因素对照：64/256/1024/全部{total}个2022–2024完整256分钟窗口，逐级包含。四组相同2816步起点（四窗微调之前）、相同AdamW动量、8192瓶颈、最近邻上采样、完整梯度回传和shape_mass损失，追加2048次更新。归一化固定为原64训练窗统计；相同8个训练诊断窗与16个2025Q1开发窗。记录不同窗口数量和实际曝光次数。2025Q1已反复用于开发，2026和独立测试未参与。',
        viewer_step_note='本轮追加更新步数；共同2816步起点，训练池大小是唯一因素。',
        authorization='User requested continue experiments after approving the64/256/1024/all data-scale plan; previous stop is superseded for this bounded cohort only.',
    )
    for key in ['gradient_routes','kl_warmup_steps']:
        plan.pop(key,None)
    atomic_json(root/'plan.json',plan)
    val=dataset(root,'val')
    vi=np.load(root/'val_indices.npy')
    assert len(vi)==16 and vi.max()<len(val)
    val_start=val.base.times[val.base.starts[vi]]
    assert end_us.max()<val_start.min()
    raw=train[int(base[0])]
    assert list(raw['data'].shape)==[256,2,2048,2]
    atomic_json(root/'data_contract.json',dict(input_shape=[1,256,2,2048,2],latent_shape=[1,64,128],
        reconstruction_shape=[1,256,2,2048],train_pool_windows=total,subsets=manifest,
        seen_training_indices=seen.tolist(),development_indices=vi.tolist(),
        train_end_before_development=True,normalization='Exact source64training-only statistics preserved',
        selection='Nested monthly coverage; no future-return labels or independent-test data'))
    atomic_json(root/'status.json',dict(state='prepared'))
    (root/'README.md').write_text(
        '# 训练数据规模控制实验\n\n'
        f'完整256分钟、每侧2048档、唯一64×128latent，64/256/1024/全部{total}个训练窗口逐级包含。'
        '共同起点是四窗微调前的full-route512检查点，累计2816更新；所有组保留相同AdamW状态，'
        '相同shape_mass损失、上采样、归一化和完整梯度回传。\n\n'
        '2048追加更新、batch1累积4，约8192次窗口展示。大数据组遍历次数更少，要把数据覆盖与训练充分程度分开解释。'
        '固定同8个训练诊断窗和16个2025Q1开发窗，不将不同训练样本RMSE直接比较。'
        '每组保存实际窗口曝光统计和检查点。\n\n'
        '相对匹配64窗组与共同起点双重比较价格/数量误差和数量动力学、大单精确率/召回。'
        '源模型此前只在64窗训练，此实验测试新增数据覆盖，非从零训练的样本复杂度实验。'
        '仅seed42，2026和独立测试未参与。配置、权重、结果、图及完整源码哈希快照均在本目录。\n')
    freeze_sources(root/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'
        f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\n'
        f'cd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.data_scale_run "{remote}"\n')
    Path('/tmp/data_scale_path').write_text(str(root))
    print(root,flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root',type=Path)
    parser.add_argument('--prepare',action='store_true')
    parser.add_argument('--lane')
    args=parser.parse_args()
    if args.prepare:prepare(args.root)
    elif args.lane:worker(args.root,args.lane)
    else:campaign(args.root)
