"""Frozen256minute sensitivity to the added global/local Cross fusion layer."""

import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import time

import numpy as np
import torch

from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import freeze_sources,load_for_inference,seed_everything
from train_dual.util.dynamics import DynamicsMetrics


LABELS={'baseline':'正常Cross融合','bypass':'旁路整个融合Cross','no_global_memory':'关闭Global记忆注意力',
        'no_local_memory':'关闭Local记忆注意力','update_global_only':'仅将融合更新写入Global','update_local_only':'仅将融合更新写入Local'}


def prepare(parent):
    parent=parent.resolve();root=parent.parent/('cross_ablation_256_'+datetime.now().strftime('%Y%m%d_%H%M%S'));root.mkdir();(root/'data').mkdir()
    for name in ('train_indices.npy','val_indices.npy'):os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz');os.link(parent/'reference/final.pt',root/'checkpoint.pt');os.link(parent/'reference/step512_evaluation.json',root/'expected_reference.json')
    plan=json.loads((parent/'plan.json').read_text());plan.update(experiment='Frozen global/local Cross-fusion sensitivity',parent=str(parent),labels=LABELS,no_training=True,
        checkpoint_source=str(parent/'reference/final.pt'),checkpoint_sha256=hashlib.sha256((root/'checkpoint.pt').read_bytes()).hexdigest(),
        intervention='The added UnifiedCrossLatent only; encoder bid/ask attention and temporal TCN are unchanged. Bypass passes encoder g/l to the existing generator. Memory ablations replace one attention output by zero, preserving the other0.5coefficient and output bias. Output-slot ablations retain the fused value for one branch and encoder value for the other.',
        limits='Fixed co-trained generator sensitivity, not a matched retraining estimate of architecture benefit. No causal/profit claim. Same16development windows; no future returns.')
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(parent.parents[1])
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.cross_fusion_ablation "{remote}"\n')
    Path('/tmp/cross_ablation_256_path').write_text(str(root));print(root,flush=True)


def memory_intervention(model,g,l,lm,times,name):
    def zero(module,args,output):return torch.zeros_like(output[0]),output[1]
    handles=[module.register_forward_hook(zero) for module in getattr(model.fusion,name)]
    try:return model.fusion([(g,l)],lm,times)
    finally:
        for handle in handles:handle.remove()


def run(root):
    torch.set_num_threads(4);seed_everything(42);strict_precision();started=time.monotonic();model,norm=load_for_inference(root/'checkpoint.pt','cuda:0')
    assert model.window_size==256 and not model.compress and not model.two_towers
    val=dataset(root,'val');indices=np.load(root/'val_indices.npy');stats={k:DynamicsMetrics(norm.tick_size) for k in LABELS};counts={k:np.zeros(3,dtype=np.int64) for k in LABELS};per_window={k:[] for k in LABELS}
    positions=np.linspace(0,255,6,dtype=int);chosen=set(np.unique(np.linspace(0,len(indices)-1,3,dtype=int)).tolist());books={k:[] for k in LABELS};truths=[];masks=[];shown=[];frame_times=[];curves=[];energy=np.zeros(4)
    atomic_json(root/'status.json',dict(state='running'))
    try:
        with torch.inference_mode():
            for i,index in enumerate(indices):
                raw={k:v.unsqueeze(0) for k,v in val[int(index)].items()};b=norm.prepare(raw,'cuda:0');assert list(raw['data'].shape)==[1,256,2,2048,2]
                p=model.encoder(b['price'],b['volume'],b['mask'],b['tick_norm'],times=b['times'],sample=False);g,l=p['z_global'],p['z_local'];lm=p['latent_mask']
                fused=model.fusion([(g,l)],lm,b['times']);fg,fl=fused['global_latent'],fused['local_latent']
                a=memory_intervention(model,g,l,lm,b['times'],'global_cross');c=memory_intervention(model,g,l,lm,b['times'],'local_cross')
                inputs={'baseline':(fg,fl),'bypass':(g,l),'no_global_memory':(a['global_latent'],a['local_latent']),
                    'no_local_memory':(c['global_latent'],c['local_latent']),'update_global_only':(fg,l),'update_local_only':(g,fl)}
                energy+=[float(g.double().square().sum()),float((fg-g).double().square().sum()),float(l.double().square().sum()),float((fl-l).double().square().sum())]
                truth=raw['data'][0].numpy().astype(np.float64);mask=b['mask'][0].cpu().numpy();q=truth[...,1];mid={};start=int(val.base.starts[int(index)]);times=val.base.times[start:start+256]
                for key,(gh,lh) in inputs.items():
                    out=model.decode_latents(gh,lh,b['mask'],b['tick_norm'],b['times']);pred=np.stack([norm.inverse_price(out['price_norm'],b)[0].cpu().numpy(),out['volume'][0].cpu().numpy()],-1)
                    if not np.isfinite(pred[mask]).all():raise FloatingPointError(key)
                    stats[key].update(truth,pred,mask);one=DynamicsMetrics(norm.tick_size);one.update(truth,pred,mask);per_window[key].append(one.finish())
                    ta=(q>=100)&mask;pa=(pred[...,1]>=100)&mask;counts[key]+=[int((ta&pa).sum()),int((~ta&pa&mask).sum()),int((ta&~pa).sum())]
                    mid[key]=pred[:,:,0,0].mean(1).tolist()
                    if i in chosen:books[key].append(pred[positions])
                curves.append(dict(index=int(index),time=times.tolist(),truth=truth[:,:,0,0].mean(1).tolist(),models=mid))
                if i in chosen:truths.append(truth[positions]);masks.append(mask[positions]);shown.append(int(index));frame_times.append(times[positions])
                atomic_json(root/'progress.json',dict(windows=i+1,total=len(indices),elapsed_seconds=time.monotonic()-started))
        rows={}
        for key,label in LABELS.items():
            result=stats[key].finish();tp,fp,fn=map(int,counts[key]);result['thresholds']={'100':dict(tp=tp,fp=fp,fn=fn,recall=tp/(tp+fn) if tp+fn else None,precision=tp/(tp+fp) if tp+fp else None)}
            rows[key]=dict(label=label,result=result,per_window=per_window[key])
        expected=json.loads((root/'expected_reference.json').read_text())['result']['metrics'];actual=rows['baseline']['result']['metrics'];delta={k:abs(expected[k]['rmse']-actual[k]['rmse']) for k in ('price_usdt','quantity_btc')}
        atomic_json(root/'baseline_replay.json',dict(differences=delta,passed=max(delta.values())<=1e-4))
        if max(delta.values())>1e-4:raise RuntimeError(f'Checkpoint replay mismatch:{delta}')
        np.savez_compressed(root/'frame_profiles.npz',truth=np.stack(truths),mask=np.stack(masks),time=np.stack(frame_times),indices=np.array(shown),positions=positions,**{k:np.stack(v) for k,v in books.items()})
        atomic_json(root/'results.json',dict(rows=rows,baseline_replay=delta,development_windows=len(indices),update_relative_rms=dict(global_branch=float(np.sqrt(energy[1]/energy[0])),local_branch=float(np.sqrt(energy[3]/energy[2]))),limits='Frozen co-trained decoder reliance; not retraining superiority or unique information fractions'))
        atomic_json(root/'mid_curves.json',dict(labels=LABELS,windows=curves));atomic_json(root/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started));print('Cross sensitivity complete',flush=True)
    except BaseException as error:atomic_json(root/'status.json',dict(state='failed',error=repr(error)));raise


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');args=p.parse_args()
    if args.prepare:prepare(args.root)
    else:run(args.root)
