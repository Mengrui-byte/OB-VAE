"""Full-shape read-only parity check of the decoder prototype; no training."""
import argparse
from contextlib import nullcontext
import json
from pathlib import Path

import torch

from model.decoders.phase_volume import PhaseDetailVolumeDecoder
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import load_for_inference, seed_everything


def main(root):
    plan=json.loads((root/'plan.json').read_text())
    parent=root.parents[1]/'recons'/Path(plan['parent']).name
    payload=torch.load(root/'checkpoint.pt',map_location='cpu',weights_only=False)
    model,norm=load_for_inference(root/'checkpoint.pt','cuda:0');model.eval().requires_grad_(False)
    old=model.volume_decoder
    new=PhaseDetailVolumeDecoder(detail_mode='independent',**payload['unified_vae_config']).to('cuda:0').eval()
    missing,unexpected=new.load_state_dict(old.state_dict(),strict=False)
    assert set(missing)=={'phase_head.weight','phase_head.bias'} and not unexpected
    new.requires_grad_(False)
    raw={k:v.unsqueeze(0) for k,v in dataset(parent,'train')[0].items()}
    b=norm.prepare(raw,'cuda:0')
    assert list(raw['data'].shape)==[1,256,2,2048,2]
    rows={}
    with torch.inference_mode():
        for precision in ['fp32','bf16']:
            ctx=torch.autocast('cuda',dtype=torch.bfloat16) if precision=='bf16' else nullcontext()
            with ctx:
                model.volume_decoder=old
                reference=call(model,b,False)
                model.volume_decoder=new
                seen=[]
                hooks=[m.register_forward_pre_hook(lambda m,args:seen.append(args[0])) for m in (model.price_decoder,new)]
                try:out=call(model,b,False)
                finally:
                    for hook in hooks:hook.remove()
                assert seen[0] is seen[1] and seen[0] is out['z']
                for key in ['price_norm','volume','z']:
                    torch.testing.assert_close(reference[key],out[key],rtol=0,atol=0)
                rows[precision]=dict(price_max_abs_delta=float((out['price_norm']-reference['price_norm']).abs().max()),
                    quantity_max_abs_delta=float((out['volume']-reference['volume']).abs().max()),
                    latent_shape=list(out['z'].shape),quantity_shape=list(out['volume'].shape),
                    same_latent_object_both_decoders=True,
                    nonnegative_and_padding_zero=bool((out['volume']>=0).all() and (out['volume'][~b['mask']]==0).all()))
    old_count=sum(p.numel() for p in old.parameters());new_count=sum(p.numel() for p in new.parameters())
    assert new_count-old_count==4112
    atomic_json(root/'preflight.json',dict(passed=True,input_shape=list(raw['data'].shape),
        rows=rows,extra_parameters=4112,original_parameter_names_and_order_preserved=True,
        missing_checkpoint_keys=missing,optimizer_updates=0,
        scope='Real complete256minute2048levelsper-side input. Initial forward parity only; no reconstruction improvement or training success claimed.'))
    atomic_json(root/'status.json',dict(state='prototype_validated_not_trained'))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('root',type=Path)
    args=parser.parse_args();torch.set_num_threads(4);seed_everything(42);strict_precision();main(args.root.resolve())
