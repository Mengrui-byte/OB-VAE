"""Joint continuous PCA audit of prequantization Global/Local; no training."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import time

import numpy as np
import torch

from model.experimental.dual_fusion import FusedOrderBookVAE
from train_dual.experiments.local_codebook_size_run import write
from train_dual.experiments.long_worker import datasets
from train_dual.util.data import DualNormalizer
from train_dual.util.dynamics import DynamicsMetrics
from util.model_sources import freeze_model_sources


def run(root):
    root=root.resolve();root.mkdir(parents=True,exist_ok=False);start=time.monotonic();torch.set_num_threads(4);torch.manual_seed(42)
    project=Path(__file__).resolve().parents[2];source=project/'checkpoints/pca_state_20261024_222656'
    def progress(**kw):
        v=dict(elapsed_seconds=time.monotonic()-start,**kw);write(root/'progress.json',v)
        with (root/'progress.jsonl').open('a') as stream:stream.write(json.dumps(v)+'\n')
        print(json.dumps(v),flush=True)
    write(root/'status.json',dict(state='running'));hashes=freeze_model_sources(root/'source_snapshot')
    for name in ['train_dual/experiments/unified_continuous_latent_audit.py','train_dual/experiments/local_codebook_size_run.py',
                 'train_dual/experiments/long_worker.py','train_dual/util/data.py','train_dual/util/dynamics.py','util/dataset.py']:
        p=root/'source_snapshot'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(project/name,p);hashes[name]=hashlib.sha256(p.read_bytes()).hexdigest()
    write(root/'source_snapshot/sha256.json',hashes)
    checkpoint=source/'reference/final.pt';saved=torch.load(checkpoint,map_location='cpu',weights_only=False)
    model=FusedOrderBookVAE(fusion_variant='cross',fusion_seed=42,**saved['model_config']).eval().requires_grad_(False)
    model.load_state_dict(saved['model'],strict=True)
    norm=DualNormalizer(**{k:saved['config']['normalization'][k] for k in ('tick_size','price_scale')})
    train=datasets(source,saved,'train');val=datasets(source,saved,'val')
    indices=np.array(json.loads((source/'reference/final_evaluation.json').read_text())['result']['window_indices'])
    cache=torch.load(source/'decoder_latents.pt',map_location='cpu',mmap=True,weights_only=False)
    g,l=cache['global'],cache['local'];assert list(g.shape)==[8192,16,64] and list(l.shape)==[8192,16,2,128,16]
    fit_positions=np.unique(np.linspace(0,8191,4096,dtype=int));left=np.setdiff1d(np.arange(8192),fit_positions)
    held_positions=left[np.linspace(0,len(left)-1,128,dtype=int)];fit_probe_positions=np.linspace(0,len(fit_positions)-1,128,dtype=int)
    fit_indices=np.load(source/'fit_indices.npy')
    for name,ix in [('pca_fit_cache_positions',fit_positions),('held_train_cache_positions',held_positions),('development_indices',indices)]:np.save(root/(name+'.npy'),ix)
    plan=dict(scope='Original PREQUANTIZATION continuous Global/Local of historical16minute source. No VQ indices or codebooks enter compression.',
        window_minutes=16,global_shape=[1,16,64],local_shape=[1,16,2,128,16],joint_flat_shape=[1,66560],
        source_checkpoint=str(checkpoint),source_sha256=hashlib.sha256(checkpoint.read_bytes()).hexdigest(),seed=42,
        pca_fit_windows=4096,fit_period=['2022-01-01','2025-01-01'],held_train_windows=128,development_windows=128,
        development_period=['2025-01-01','2025-04-01'],decoder_evaluation_windows=16,dimensions=[256,512,1024,2048,4095,66560],
        method='One joint affine PCA on concatenated G1024 and L65536. Fit featurewise mean using4096training windows; no branch rescaling or whitening. FP64 Gram eigendecomposition. Implicit dual-space projection, then FP32 decoder input.66560 is identity packing/unpacking control.',
        claim_limits='Finite-sample affine rank is only a lower bound for universal linear lossless dimension, not nonlinear intrinsic dimension. Numerical rank depends on tolerance. High explained variance and training interpolation are not losslessness on unseen windows.',
        numerical_near_exact_threshold=dict(relative_centered_frobenius_error=1e-6,max_absolute_latent_error=1e-5),
        frozen_encoder_and_decoders=True,no_future_returns=True,no_independent_test=True,source_hashes=hashes)
    write(root/'plan.json',plan)
    def encode(raw):
        b=norm.prepare(raw,'cpu');p=model.encoder(b['price'],b['volume'],b['mask'],b['tick_norm'],times=b['times'],sample=False)
        f=model.fusion([(p['z_global'],p['z_local'])],p['latent_mask'],b['times'])
        return torch.cat([f['global_latent'].flatten(1),f['local_latent'].flatten(1)],1),b
    with torch.inference_mode():
        for pos in (0,4096,8191):
            raw={k:v.unsqueeze(0) for k,v in train[int(fit_indices[pos])].items()};h,b=encode(raw)
            torch.testing.assert_close(h[:,:1024].reshape(1,16,64),g[pos:pos+1],rtol=1e-5,atol=1e-4)
            torch.testing.assert_close(h[:,1024:].reshape(1,16,2,128,16),l[pos:pos+1],rtol=1e-5,atol=1e-4)
        assert list(raw['data'].shape)==[1,16,2,2048,2]
        gh=g[0:1];lh=l[0:1];geo=model.price_decoder(gh,lh,b['mask'],b['tick_norm'],times=b['times'])
        assert list(geo['price_norm'].shape)==[1,16,2,2048]
    write(root/'actual_shape_contract.json',dict(raw_input=list(raw['data'].shape),global_latent=[1,16,64],local_latent=[1,16,2,128,16],joint_continuous=[1,66560],decoder_output=list(geo['price_norm'].shape),quantization=False))
    progress(phase='constructing_training_matrix')
    x=torch.empty((len(fit_positions),66560),dtype=torch.float64)
    for begin in range(0,len(x),128):
        sel=fit_positions[begin:begin+128]
        x[begin:begin+len(sel),:1024]=g[sel].reshape(len(sel),-1).double();x[begin:begin+len(sel),1024:]=l[sel].reshape(len(sel),-1).double()
    held=torch.cat([g[held_positions].flatten(1),l[held_positions].flatten(1)],1).double()
    fitprobe=x[fit_probe_positions].clone();mean=x.mean(0);x-=mean
    progress(phase='training_gram_matrix',shape=list(x.shape))
    gram=x@x.T
    progress(phase='training_symmetric_eigendecomposition',shape=list(gram.shape))
    ev,u=torch.linalg.eigh(gram);ev=ev.flip(0);u=u.flip(1)
    del gram
    tolerance=float(ev[0])*max(x.shape)*torch.finfo(torch.float64).eps
    keep=ev>tolerance;rank=int(keep.sum());ev=ev[keep];u=u[:,keep]
    total_energy=float(x.square().sum());positive_energy=float(ev.sum())
    spectrum=dict(centered_training_rows=len(x),feature_dimensions=66560,numerical_affine_rank=rank,
        covariance_eigenvalue_tolerance=tolerance,largest_eigenvalue=float(ev[0]),smallest_retained_eigenvalue=float(ev[-1]),
        singular_value_ratio=float(torch.sqrt(ev[-1]/ev[0])),total_centered_energy=total_energy,
        eigenvalue_sum=positive_energy,dimensions_for_training_energy={str(target):int(torch.searchsorted(ev.cumsum(0)/total_energy,torch.tensor(target,dtype=torch.float64)))+1 for target in [.9,.95,.99,.999,.9999]},
        caveat='Rank and energy refer only to4096fitted windows. Centered affine rank cannot exceed4095; this does not bound future windows or establish nonlinear intrinsic dimension.')
    write(root/'spectrum.json',spectrum);np.savez_compressed(root/'training_spectrum.npz',eigenvalues=ev.numpy(),fit_positions=fit_positions)
    torch.save(dict(mean=mean,eigenvalues=ev,eigenvectors_in_training_coordinates=u,fit_cache_positions=fit_positions,source=str(source/'decoder_latents.pt')),
               root/'dual_pca_analysis.pt')
    progress(phase='development_latent_extraction',training_rank=rank)
    dev=[];meta=[]
    with torch.inference_mode():
        for position,index in enumerate(indices):
            raw={k:v.unsqueeze(0) for k,v in val[int(index)].items()};h,b=encode(raw)
            assert list(h.shape)==[1,66560];dev.append(h[0].double());meta.append(raw)
            if position==0 or (position+1)%16==0:progress(phase='development_latent_extraction',windows=position+1,total=128)
    dev=torch.stack(dev);np.savez_compressed(root/'development_continuous_latents.npz',global_latent=dev[:,:1024].numpy().astype('float32').reshape(128,16,64),local_latent=dev[:,1024:].numpy().astype('float32').reshape(128,16,2,128,16),indices=indices)
    dimensions=[d for d in plan['dimensions'] if d==66560 or d<=rank]
    if rank not in dimensions:dimensions.insert(-1,rank)
    decoded_positions=set(np.linspace(0,127,16,dtype=int).tolist());errors={};decoder={};tails={}
    def reconstruction(y,d,kernel):
        if d==66560:return y.clone()
        ud=u[:,:d];alpha=((kernel@ud)/ev[:d])@ud.T
        return alpha@x+mean
    def error_stats(target,reconstructed,offset):
        a=target[:,offset];bb=reconstructed[:,offset];diff=bb-a;center=a-mean[offset]
        bits=(bb.float().contiguous().view(torch.int32)==a.float().contiguous().view(torch.int32))
        rel=float(torch.sqrt(diff.square().sum()/center.square().sum()))
        mx=float(diff.abs().max())
        return dict(rmse=float(torch.sqrt(diff.square().mean())),relative_centered_frobenius_error=rel,max_absolute_error=mx,
            float32_bitwise_equal_fraction=float(bits.double().mean()),all_float32_bitwise_equal=bool(bits.all()),
            near_exact_threshold_met=rel<=1e-6 and mx<=1e-5)
    for group,y in [('fitted_train_probe',fitprobe),('held_train',held),('development',dev)]:
        progress(phase='continuous_projection',group=group)
        kernel=(y-mean)@x.T
        for d in dimensions:
            rec=reconstruction(y,d,kernel);key=str(d);errors.setdefault(group,{})[key]=dict(global_latent=error_stats(y,rec,slice(0,1024)),local_latent=error_stats(y,rec,slice(1024,None)))
            if d==66560:assert torch.equal(y.float().view(torch.int32),rec.float().view(torch.int32))
            if group=='development':
                metrics=DynamicsMetrics(norm.tick_size);counts=np.zeros(3,dtype='int64')
                with torch.inference_mode():
                    for position in sorted(decoded_positions):
                        raw=meta[position];b=norm.prepare(raw,'cpu');g2=rec[position:position+1,:1024].float().reshape(1,16,64);l2=rec[position:position+1,1024:].float().reshape(1,16,2,128,16)
                        geo=model.price_decoder(g2,l2,b['mask'],b['tick_norm'],times=b['times'])
                        q=model.volume_decoder(g2,l2,geo,b['mask'],b['tick_norm'],times=b['times'])
                        q=model.volume_refinement(g2,l2,q,geo,b['mask'],b['tick_norm'],b['times'])
                        pred=np.stack([norm.inverse_price(geo['price_norm'],b)[0].numpy(),q[0].numpy()],-1);truth=raw['data'][0].numpy().astype('float64');mask=b['mask'][0].numpy()
                        metrics.update(truth,pred,mask);a=(truth[...,1]>=100)&mask;bb=(pred[...,1]>=100)&mask
                        counts+=[int((a&bb).sum()),int((~a&bb&mask).sum()),int((a&~bb).sum())]
                dd=metrics.finish();tp,fp,fn=map(int,counts);dd['threshold100']=dict(tp=tp,fp=fp,fn=fn,recall=tp/(tp+fn) if tp+fn else None,precision=tp/(tp+fp) if tp+fp else None)
                decoder[key]=dd;write(root/'decoder_results.json',decoder)
            write(root/'latent_errors.json',errors);progress(phase='continuous_projection',group=group,dimension=d)
    write(root/'verification.json',dict(identity_packing_bitwise_lossless=True,source_sha256_unchanged=hashlib.sha256(checkpoint.read_bytes()).hexdigest()==plan['source_sha256'],
        no_integer_codes_or_quantized_latents=True,training_only_fit=True,cache_alignment_checked=[0,4096,8191],
        physical_evaluation_positions=sorted(decoded_positions),linear_scope_only=True))
    write(root/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-start));progress(phase='complete')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);a=p.parse_args()
    try:run(a.root)
    except BaseException as error:
        if a.root.exists():write(a.root/'failure.json',dict(error=repr(error)))
        raise
