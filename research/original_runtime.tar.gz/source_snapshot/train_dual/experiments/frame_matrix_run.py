"""Small-sample 16x1024 continuous matrix compression from the best Cross model."""

import argparse
from datetime import datetime
import json
import os
from pathlib import Path
import time

import numpy as np
import torch
from torch.utils.data import DataLoader

from model.experimental.frame_matrix_state import FrameMatrixOrderBookVAE
from model.losses.quantized_book import QuantizedBookLoss
from train_dual.experiments.local_quant_reconstruction import CacheWindows
from train_dual.experiments.long_worker import atomic_json,datasets,evaluate
from train_dual.experiments.pca_run import examples
from train_dual.experiments.small_codebook_run import campaign
from train_dual.experiments.window_state_pilot import load_base,strict_precision
from train_dual.util.checkpoint import atomic_save,freeze_sources,seed_everything,source_hashes
from train_dual.util.resume_loader import epoch_resume_loader


def prepare(parent):
    parent=parent.resolve();root=parent.parent/('frame_matrix_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
    root.mkdir();(root/'logs').mkdir();(root/'data').mkdir()
    for name in ('initial.pt','source_profiles.npz'):os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    (root/'full_decoder_latents.pt').symlink_to(os.path.relpath((parent/'decoder_latents.pt').resolve(),root))
    full_indices=np.load(parent/'fit_indices.npy');positions=np.unique(np.linspace(0,len(full_indices)-1,512,dtype=int))
    np.save(root/'cache_positions.npy',positions);np.save(root/'fit_indices.npy',full_indices[positions])
    plan=dict(parent=str(parent),initial_checkpoint=str(parent/'initial.pt'),seed=42,fit_windows=512,
        train=['2022-01-01','2025-01-01'],development=['2025-01-01','2025-04-01'],independent_test_untouched=['2025-04-01','2025-07-01'],
        matrix_shape=[16,1024],packed_shape=[16,4160],source_global_shape=[16,64],source_local_shape=[16,2,128,16],
        lanes={'fixed_pca':dict(kind='linear',mode='fixed',steps=0),'linear':dict(kind='linear',mode='codec',steps=512),
               'nonlinear':dict(kind='nonlinear',mode='codec',steps=512),'nonlinear_joint':dict(kind='nonlinear',mode='joint',steps=512)},
        evaluation_windows=64,seen_evaluation_windows=64,example_indices=[0,5229,63],batch_size=4,accumulation=2,
        linear_lr=1e-5,residual_lr=.001,decoder_lr=1e-5,matrix_dim=1024,hidden_dim=512,
        pca_oversample=64,pca_iterations=3,no_quantization=True,no_semantic_constraints=True,no_future_returns=True,
        hypothesis='Retaining16time rows and compressing each fused4160-feature row to1024 may preserve details lost by a single1024-dimensional whole-window state.',
        initialization='Common train-only randomized raw PCA initializes learned encoder/decoder. Nonlinear residual outputs start at zero. No whitening, no per-coordinate scaling.',
        objective=dict(price=1.,volume_log=1.,volume_linear=.05,gap_log=.05,spread_log=.05,mid=.1,volume_tail=.25,
                       temporal_quantity=.5,temporal_price=.1,latent_mse=.01,kl=0.),
        comparison='All report the same64dev windows and64actual-seen windows. Original and losslessly-packed baselines are replayed first. Fixed-step endpoints only; source encoder/Cross always frozen.',
        storage='16384float32 elements=64KiB/window vs66560elements=260KiB effective source. This is continuous latent compression, not discrete quantization or a single1024-dimensional window vector.')
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(parent.parents[1])
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'
        f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=2\n'
        f'cd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.frame_matrix_run "{remote}"\n')
    Path('/tmp/frame_matrix_run_path').write_text(str(root));print(root,flush=True)


def prepare_basis(root):
    torch.set_num_threads(4);seed_everything(42);strict_precision();started=time.monotonic()
    plan=json.loads((root/'plan.json').read_text());source,norm=load_base(root)
    cache=torch.load(root/'full_decoder_latents.pt',map_location='cpu',mmap=True,weights_only=False)
    positions=torch.from_numpy(np.load(root/'cache_positions.npy'))
    g=cache['global'][positions].to('cuda:0');l=cache['local'][positions].to('cuda:0');del cache
    atomic_save(dict(global_latent=g.cpu(),local_latent=l.cpu()),root/'small_latents.pt')
    source_model=FrameMatrixOrderBookVAE(matrix_dim=1024,**source['model_config']).to('cuda:0').eval()
    source_model.load_cross_initial(source['model']);train=datasets(root,source,'train');indices=np.load(root/'fit_indices.npy')
    checks=[]
    with torch.inference_mode():
        for pos in (0,255,511):
            b=norm.prepare({k:v.unsqueeze(0) for k,v in train[int(indices[pos])].items()},'cuda:0')
            p=source_model.encoder(b['price'],b['volume'],b['mask'],b['tick_norm'],times=b['times'],sample=False)
            f=source_model.fusion([(p['z_global'],p['z_local'])],p['latent_mask'],b['times'])
            torch.testing.assert_close(f['global_latent'],g[pos:pos+1],atol=1e-4,rtol=1e-5)
            torch.testing.assert_close(f['local_latent'],l[pos:pos+1],atol=1e-4,rtol=1e-5);checks.append(pos)
    del source_model
    x=FrameMatrixOrderBookVAE.pack(g,l).reshape(-1,4160);mean=x.mean(0);centered=x-mean
    torch.manual_seed(42)
    _,s,v=torch.pca_lowrank(centered,q=plan['matrix_dim']+plan['pca_oversample'],center=False,niter=plan['pca_iterations'])
    basis=v[:,:plan['matrix_dim']].T.contiguous()
    retained=float((centered@basis.T).square().sum()/centered.square().sum())
    atomic_save(dict(mean=mean.cpu(),basis=basis.cpu()),root/'frame_basis.pt')
    atomic_json(root/'basis_fit.json',dict(train_windows=len(g),training_rows=len(x),input_width=4160,output_width=1024,
        retained_training_energy=retained,online_cache_positions_verified=checks,train_only=True,whitening=False,
        method='Randomized raw PCA with64oversampling,3poweriterations',elapsed_seconds=time.monotonic()-started))
    del g,l,x,centered,mean,basis,s,v;torch.cuda.empty_cache()


def worker(root,lane):
    torch.set_num_threads(4);seed_everything(42);strict_precision();started=time.monotonic()
    plan=json.loads((root/'plan.json').read_text());spec=plan['lanes'][lane];source,norm=load_base(root)
    folder=root/lane;folder.mkdir(exist_ok=True);atomic_json(folder/'status.json',dict(state='running'))
    def progress(**value):
        value=dict(value,elapsed_seconds=time.monotonic()-started,reserved_gib=torch.cuda.memory_reserved()/2**30)
        atomic_json(folder/'progress.json',value)
        with (folder/'progress.jsonl').open('a') as f:f.write(json.dumps(value)+'\n')
        print(json.dumps(value),flush=True)
    try:
        model=FrameMatrixOrderBookVAE(matrix_dim=plan['matrix_dim'],codec_kind=spec['kind'],
            codec_hidden=spec.get('hidden_dim',plan['hidden_dim']),codec_depth=spec.get('depth',0),**source['model_config'])
        model.load_cross_initial(source['model']);basis=torch.load(root/'frame_basis.pt',map_location='cpu',weights_only=False)
        model.frame_codec.initialize_pca(basis['mean'],basis['basis']);model.to('cuda:0').eval()
        val=datasets(root,source,'val');indices=np.load(root/'fit_indices.npy')
        subset_positions=np.arange(len(indices))
        if spec.get('train_windows',len(indices))<len(indices):
            subset_positions=np.unique(np.linspace(0,len(indices)-1,spec['train_windows'],dtype=int));indices=indices[subset_positions]
        train=CacheWindows(datasets(root,source,'train'),indices);np.save(folder/'training_indices.npy',indices)
        baseline={}
        for mode in ('original','flatten','compressed'):
            model.evaluation_mode=mode;value=evaluate(model,norm,val,64,'cuda:0');model.eval();baseline[mode]=value
            atomic_json(folder/(mode+'_evaluation.json'),dict(result=value))
        delta={k:abs(baseline['original']['metrics'][k]['rmse']-baseline['flatten']['metrics'][k]['rmse']) for k in ('price_usdt','quantity_btc')}
        if max(delta.values())>1e-4:raise RuntimeError(f'Lossless flattening changed generation {delta}')
        atomic_json(folder/'flatten_replay.json',dict(physical_rmse_differences=delta,lossless_values=True))
        if spec['mode']=='all':g=l=None
        else:
            cache=torch.load(root/'small_latents.pt',map_location='cpu',weights_only=False)
            g,l=cache['global_latent'][subset_positions].to('cuda:0'),cache['local_latent'][subset_positions].to('cuda:0');del cache
        model.configure_training(spec['mode']);criterion=QuantizedBookLoss(source['model_config'].get('quantity_scale',1.))
        groups={}
        for name,p in model.named_parameters():
            if not p.requires_grad:continue
            key='residual' if name.startswith('frame_codec.') and '_residual.' in name else 'linear' if name.startswith('frame_codec.') else 'encoder' if name.startswith(('encoder.','fusion.')) else 'decoder'
            groups.setdefault(key,[]).append(p)
        atomic_json(folder/'trainable_modules.json',{name:dict(parameters=sum(p.numel() for p in module.parameters()),
            trainable=sum(p.numel() for p in module.parameters() if p.requires_grad)) for name,module in
            [('encoder',model.encoder),('fusion',model.fusion),('codec',model.frame_codec),('price_decoder',model.price_decoder),
             ('volume_decoder',model.volume_decoder),('volume_refinement',model.volume_refinement)]})
        if spec['steps']:
            optimizer=torch.optim.AdamW([dict(params=ps,lr=spec.get(key+'_lr',plan[key+'_lr'])) for key,ps in groups.items()],weight_decay=0.)
            start_step=0;resume_file=root/'resume'/(lane+'.pt')
            if resume_file.exists():
                resumed=torch.load(resume_file,map_location='cpu',weights_only=False)
                if not resumed.get('epoch_boundary',False):raise RuntimeError('Resume requires an epoch-boundary checkpoint')
                if resumed['frame_matrix_config']!=model.frame_matrix_config:raise RuntimeError('Resume architecture differs')
                model.load_state_dict(resumed['model'],strict=True);optimizer.load_state_dict(resumed['optimizer'])
                start_step=int(resumed['step'])
                state=resumed.get('sampler_generator_state',resumed['loader_generator_state'])
                loader,sampler_generator=epoch_resume_loader(train,state,batch_size=plan['batch_size'])
                torch.set_rng_state(resumed['torch_rng_state'].cpu())
                torch.cuda.set_rng_state_all([x.cpu() for x in resumed['cuda_rng_state']])
                replay=evaluate(model,norm,val,64,'cuda:0');model.eval()
                expected=json.loads((folder/f'step{start_step}_evaluation.json').read_text())['result']
                delta={k:abs(replay['metrics'][k]['rmse']-expected['metrics'][k]['rmse']) for k in ('price_usdt','quantity_btc')}
                atomic_json(folder/'resume_replay.json',dict(step=start_step,differences=delta,epoch_boundary=True,
                    optimizer_restored=True,sampler_rng_restored=True,worker_seed_rng_separated=True))
                if max(delta.values())>1e-4:raise RuntimeError(f'Inference replay changed for saved checkpoint: {delta}')
                del resumed
            else:
                loader=DataLoader(train,batch_size=4,shuffle=True,num_workers=2,persistent_workers=True,pin_memory=True,
                    generator=torch.Generator().manual_seed(42));sampler_generator=loader.generator
            iterator=iter(loader)
            for step in range(start_step+1,spec['steps']+1):
                optimizer.zero_grad(set_to_none=True);record={}
                for _ in range(plan['accumulation']):
                    try:raw=next(iterator)
                    except StopIteration:iterator=iter(loader);raw=next(iterator)
                    b=norm.prepare(raw,'cuda:0')
                    if spec['mode']=='all':out=model(b['price'],b['volume'],b['mask'],b['tick_norm'],times=b['times'],sample=False)
                    else:
                        pos=raw['cache_position'].to('cuda:0');out=model.forward_latents(g[pos],l[pos],b['mask'],b['tick_norm'],b['times'])
                    values=criterion(out,b)
                    if not torch.isfinite(values['loss']):raise FloatingPointError('Nonfinite matrix compression loss')
                    (values['loss']/plan['accumulation']).backward()
                    for key in ('loss','volume_log','volume_tail','temporal_quantity','latent_mse'):
                        record[key]=record.get(key,0.)+float(values[key].detach())/plan['accumulation']
                if step==start_step+1:
                    norms={name:sum(float(p.grad.detach().square().sum()) for p in module.parameters() if p.grad is not None)**.5
                        for name,module in [('encoder',model.encoder),('fusion',model.fusion),('codec',model.frame_codec),
                                            ('price_decoder',model.price_decoder),('volume_decoder',model.volume_decoder),('volume_refinement',model.volume_refinement)]}
                    if spec['mode']=='all' and any(not np.isfinite(v) or v<=0 for v in norms.values()):raise RuntimeError(f'End-to-end gradient path missing: {norms}')
                    atomic_json(folder/'first_step_gradient_norms.json',norms)
                grad=torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad],1.)
                if not torch.isfinite(grad):raise FloatingPointError('Nonfinite matrix compression gradient')
                optimizer.step()
                if step==start_step+1 or step%32==0:progress(phase='small_sample_training',step=step,total=spec['steps'],**record)
                if step in plan.get('checkpoints',[256]):
                    value=evaluate(model,norm,val,64,'cuda:0');model.eval();atomic_json(folder/f'step{step}_evaluation.json',dict(result=value))
                    if plan.get('save_training_checkpoints',False):
                        seen_now=evaluate(model,norm,train,64,'cuda:0');model.eval()
                        atomic_json(folder/f'step{step}_seen_evaluation.json',dict(result=seen_now))
                        atomic_save(dict(format_version=1,model=model.state_dict(),model_config=source['model_config'],config=source['config'],
                            frame_matrix_config=model.frame_matrix_config,source_hashes=source_hashes(),step=step,
                            optimizer=optimizer.state_dict(),loader_generator_state=sampler_generator.get_state(),
                            sampler_generator_state=sampler_generator.get_state(),
                            torch_rng_state=torch.get_rng_state(),cuda_rng_state=torch.cuda.get_rng_state_all(),
                            epoch_boundary=bool((step*plan['batch_size']*plan['accumulation'])%len(train)==0)),folder/f'step{step}.pt')
                    if step==512 and plan.get('strict_replay_control')==lane:
                        expected=json.loads((root/'expected_control512.json').read_text())['result']
                        changes={k:abs(value['metrics'][k]['rmse']-expected['metrics'][k]['rmse']) for k in ('price_usdt','quantity_btc')}
                        atomic_json(folder/'control512_replay.json',dict(differences=changes))
                        if max(changes.values())>1e-4:raise RuntimeError(f'Duration-only control drifted: {changes}')
            del iterator,loader
        model.eval();dev=evaluate(model,norm,val,64,'cuda:0');model.eval();seen=evaluate(model,norm,train,64,'cuda:0');model.eval()
        atomic_json(folder/'final_evaluation.json',dict(result=dev));atomic_json(folder/'seen_evaluation.json',dict(result=seen))
        examples(root,folder,model,norm,source,plan);matrices=[]
        with torch.inference_mode():
            for index in plan['example_indices']:
                b=norm.prepare({k:v.unsqueeze(0) for k,v in val[index].items()},'cuda:0')
                out=model(b['price'],b['volume'],b['mask'],b['tick_norm'],times=b['times'],sample=False)
                decoded=model.decode_matrix(out['matrix_latent'],b['mask'],b['tick_norm'],b['times'])
                torch.testing.assert_close(decoded['volume'],out['volume'],atol=0,rtol=0)
                torch.testing.assert_close(decoded['price_norm'],out['price_norm'],atol=0,rtol=0)
                matrices.append(out['matrix_latent'].cpu().numpy())
        np.savez_compressed(folder/'matrix_examples.npz',matrix=np.concatenate(matrices),indices=np.array(plan['example_indices']))
        atomic_save(dict(format_version=1,model=model.state_dict(),model_config=source['model_config'],config=source['config'],
            frame_matrix_config=model.frame_matrix_config,source_hashes=source_hashes(),initial_checkpoint=plan['initial_checkpoint']),folder/'final.pt')
        atomic_json(folder/'comparison.json',dict(original=baseline['original'],flatten=baseline['flatten'],initial=baseline['compressed'],
            final=dev,seen=seen,matrix_shape=[16,1024],effective_source_shape=[16,4160],compression_ratio=4160/1024,
            matrix_decode_exact=True,train_windows=len(train),dev_windows=64,mode=spec['mode'],steps=spec['steps']))
        atomic_json(folder/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started))
    except BaseException as error:
        atomic_json(folder/'status.json',dict(state='failed',error=repr(error)));raise


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--lane');a=p.parse_args()
    if a.prepare:prepare(a.root)
    elif a.lane:worker(a.root,a.lane)
    else:
        prepare_basis(a.root);campaign(a.root,worker_module='train_dual.experiments.frame_matrix_run')
