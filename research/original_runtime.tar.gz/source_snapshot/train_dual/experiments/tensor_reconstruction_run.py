"""Fixed-rate full tensor-pair quantization with reconstruction feedback."""

import argparse
from datetime import datetime
import json
import os
from pathlib import Path
import time

import numpy as np
import torch
from torch.utils.data import DataLoader

from model.experimental.tensor_cluster_state import TensorClusterOrderBookVAE
from model.losses.quantized_book import QuantizedBookLoss
from train_dual.experiments.local_quant_reconstruction import CacheWindows
from train_dual.experiments.long_worker import atomic_json,datasets,evaluate
from train_dual.experiments.pca_run import examples
from train_dual.experiments.small_codebook_run import campaign
from train_dual.experiments.window_state_pilot import load_base,strict_precision
from train_dual.util.checkpoint import atomic_save,freeze_sources,seed_everything,source_hashes


def prepare(parent):
    parent=parent.resolve();root=parent.parent/('tensor_reconstruction_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
    root.mkdir();(root/'logs').mkdir();(root/'data').mkdir()
    for name in ('initial.pt','expected_reference.json','source_profiles.npz'):os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    for name in ('decoder_latents.pt','fit_indices.npy'):(root/name).symlink_to(os.path.relpath((parent/name).resolve(),root))
    os.link(parent/'kmeans_pp/final.pt',root/'quantized_initial.pt')
    os.link(parent/'kmeans_pp/depth8_evaluation.json',root/'expected_quantized.json')
    plan=json.loads((parent/'plan.json').read_text())
    plan.update(parent=str(parent),experiment='Fixed-rate full tensor reconstruction feedback',
        lanes={name:dict(mode=mode,steps=512) for name,mode in [('books','books'),('decoder','decoder'),('joint','joint'),('all','all')]},
        batch_size=4,accumulation=2,book_lr=.001,decoder_lr=.0001,encoder_lr=.00001,
        hypothesis='Feedback from observed-window reconstruction may preserve information that raw latent clustering does not prioritize.',
        method='Same complete CG[16,64],CL[16,2,128,16],8levels,16codes,32logicalbits. Train codebooks only, generator only, both, or all with a straight-through encoder gradient. Every forward uses hard integer-selected codewords. No raw latent bypass.',
        objective=dict(price=1.,volume_log=1.,volume_linear=.05,gap_log=.05,spread_log=.05,mid=.1,volume_tail=.25,
                       temporal_quantity=.5,temporal_price=.1,latent_mse=.01,kl=0.),
        selection='Report fixed512-step final checkpoints for all groups. Validation at128/256/512 is monitoring, not checkpoint selection.',
        no_semantic_constraints=True,no_future_returns=True)
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(parent.parents[1])
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'
        f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\n'
        f'cd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.tensor_reconstruction_run "{remote}"\n')
    Path('/tmp/tensor_reconstruction_run_path').write_text(str(root));print(root,flush=True)


def worker(root,lane):
    torch.set_num_threads(4);seed_everything(42);strict_precision();started=time.monotonic()
    plan=json.loads((root/'plan.json').read_text());spec=plan['lanes'][lane];source,norm=load_base(root)
    folder=root/lane;folder.mkdir(exist_ok=True);atomic_json(folder/'status.json',dict(state='running'))
    def progress(**value):
        value=dict(value,elapsed_seconds=time.monotonic()-started,reserved_gib=torch.cuda.memory_reserved()/2**30)
        atomic_json(folder/'progress.json',value)
        with (folder/'progress.jsonl').open('a') as f:f.write(json.dumps(value)+'\n')
        print(json.dumps(value),flush=True)
    try:
        initial=torch.load(root/'quantized_initial.pt',map_location='cpu',weights_only=False)
        model=TensorClusterOrderBookVAE(**initial['tensor_cluster_config'],trainable_codebooks=True,**source['model_config'])
        model.load_state_dict(initial['model'],strict=True);model.to('cuda:0').eval()
        val=datasets(root,source,'val');before=evaluate(model,norm,val,128,'cuda:0');model.eval()
        expected=json.loads((root/'expected_quantized.json').read_text())['result']
        for k in ('price_usdt','quantity_btc'):
            if abs(before['metrics'][k]['rmse']-expected['metrics'][k]['rmse'])>1e-4:raise RuntimeError('Initial full tensor quantized replay changed')
        atomic_json(folder/'initial_evaluation.json',dict(result=before))
        cache=torch.load(root/'decoder_latents.pt',map_location='cpu',mmap=True,weights_only=False)
        g,l=cache['global'].to('cuda:0'),cache['local'].to('cuda:0');del cache
        model.configure_training(spec['mode']);criterion=QuantizedBookLoss(source['model_config'].get('quantity_scale',1.))
        grouped={}
        for name,p in model.named_parameters():
            if not p.requires_grad:continue
            key='book' if name.startswith('matrix_quantizer.') else 'encoder' if name.startswith(('encoder.','fusion.')) else 'decoder'
            grouped.setdefault(key,[]).append(p)
        optimizer=torch.optim.AdamW([dict(params=ps,lr=plan[key+'_lr']) for key,ps in grouped.items()],weight_decay=0.)
        loader=DataLoader(CacheWindows(datasets(root,source,'train'),np.load(root/'fit_indices.npy')),batch_size=plan['batch_size'],shuffle=True,
            num_workers=2,persistent_workers=True,pin_memory=True,generator=torch.Generator().manual_seed(42))
        iterator=iter(loader)
        for step in range(1,spec['steps']+1):
            optimizer.zero_grad(set_to_none=True);record={}
            for micro in range(plan['accumulation']):
                try:raw=next(iterator)
                except StopIteration:iterator=iter(loader);raw=next(iterator)
                b=norm.prepare(raw,'cuda:0')
                if spec['mode']=='all':
                    out=model(b['price'],b['volume'],b['mask'],b['tick_norm'],times=b['times'],sample=False)
                else:
                    pos=raw['cache_position'].to('cuda:0');out=model.forward_tensor_latents(g[pos],l[pos],b['mask'],b['tick_norm'],b['times'])
                values=criterion(out,b)
                if not torch.isfinite(values['loss']):raise FloatingPointError('Nonfinite full-tensor reconstruction loss')
                (values['loss']/plan['accumulation']).backward()
                for key in ('loss','volume_log','volume_linear','volume_tail','temporal_quantity','latent_mse'):
                    record[key]=record.get(key,0.)+float(values[key].detach())/plan['accumulation']
            grad=torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad],1.)
            if not torch.isfinite(grad):raise FloatingPointError('Nonfinite full-tensor reconstruction gradient')
            optimizer.step()
            if step==1 or step%32==0:progress(phase='reconstruction_feedback',step=step,total=spec['steps'],**record)
            if step in (128,256):
                measured=evaluate(model,norm,val,128,'cuda:0');model.eval()
                atomic_json(folder/f'step{step}_evaluation.json',dict(result=measured))
        del iterator,loader,g,l;torch.cuda.empty_cache()
        final=evaluate(model,norm,val,128,'cuda:0');model.eval();atomic_json(folder/'final_evaluation.json',dict(result=final))
        examples(root,folder,model,norm,source,plan)
        with torch.inference_mode():
            b=norm.prepare({k:v.unsqueeze(0) for k,v in val[0].items()},'cuda:0')
            out=model(b['price'],b['volume'],b['mask'],b['tick_norm'],times=b['times'],sample=False)
            replay=model.decode_codes(out['matrix_codes'],b['mask'],b['tick_norm'],b['times'])
            torch.testing.assert_close(out['volume'],replay['volume'],atol=0,rtol=0)
            torch.testing.assert_close(out['price_norm'],replay['price_norm'],atol=0,rtol=0)
        np.savez_compressed(folder/'replay_codes.npz',codes=out['matrix_codes'].cpu().numpy())
        atomic_save(dict(format_version=1,model=model.state_dict(),model_config=source['model_config'],config=source['config'],
            tensor_cluster_config=model.tensor_cluster_config,source_hashes=source_hashes(),initial_checkpoint=str(root/'quantized_initial.pt')),folder/'final.pt')
        atomic_json(folder/'comparison.json',dict(initial=before,final=final,logical_bits=model.matrix_quantizer.logical_bits(),
            codebook_global_shape=list(model.matrix_quantizer.global_codebook.shape),codebook_local_shape=list(model.matrix_quantizer.local_codebook.shape),
            integer_replay_exact=True,steps=spec['steps'],mode=spec['mode']))
        atomic_json(folder/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started))
    except BaseException as error:
        atomic_json(folder/'status.json',dict(state='failed',error=repr(error)));raise


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--lane');a=p.parse_args()
    if a.prepare:prepare(a.root)
    elif a.lane:worker(a.root,a.lane)
    else:campaign(a.root,worker_module='train_dual.experiments.tensor_reconstruction_run')
