"""Inspect existing window latents, then fit and evaluate residual-quantized VAEs."""

import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

import numpy as np
import torch
from torch.utils.data import DataLoader, Subset

from model.experimental.rq_window_state import RQWindowStateVAE
from train_dual.experiments.long_worker import atomic_json, datasets, evaluate
from train_dual.experiments.pca_run import examples
from train_dual.experiments.window_state_pilot import load_base, market_features, FEATURE_NAMES, strict_precision
from train_dual.util.checkpoint import atomic_save, freeze_sources, load_for_inference, seed_everything, source_hashes


LANES=('direct','rq64','rq128','rq256')
SOURCE_LANES=('fixed','linear','nonlinear','attention')


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as file:
        for block in iter(lambda:file.read(8*1024*1024),b''):h.update(block)
    return h.hexdigest()


def spectrum(states):
    x=states.double();center=x.mean(0);std=x.std(0).clamp_min(1e-4)
    result={}
    components=None
    for name,value in [('raw',x-center),('standardized',(x-center)/std)]:
        covariance=value.T@value/(len(value)-1)
        eigen,basis=torch.linalg.eigh(covariance)
        eigen=eigen.flip(0).clamp_min(0);basis=basis.flip(1)
        cumulative=eigen.cumsum(0)/eigen.sum().clamp_min(1e-12)
        result[name]=dict(eigenvalues=eigen.cpu().tolist(),cumulative_variance=cumulative.cpu().tolist(),
            participation_rank=float(eigen.sum().square()/eigen.square().sum().clamp_min(1e-12)),
            numerical_rank=int((eigen>eigen[0]*1e-10).sum()),rank_tolerance='covariance eigenvalue > max * 1e-10',
            components_for_variance={str(p):int(torch.searchsorted(cumulative,torch.tensor(p,device=x.device,dtype=x.dtype)))+1 for p in (.9,.95,.99,.999)})
        if name=='standardized':components=basis[:,:2].float()
    result.update(shape=list(states.shape),per_dimension_std=std.cpu().tolist(),mean_norm=float(center.norm()),
        finite=bool(torch.isfinite(states).all()),note='Finite-sample covariance diagnostics, not an intrinsic manifold dimension estimate')
    return result,center.float(),std.float(),components


def extract(root):
    torch.set_num_threads(4);seed_everything(42);strict_precision()
    plan=json.loads((root/'plan.json').read_text());initial,norm=load_base(root)
    atomic_json(root/'status.json',dict(state='preparing',phase='latent_extraction'))
    cache=torch.load(root/'decoder_latents.pt',map_location='cpu',weights_only=False,mmap=True)
    g=cache['global'].to('cuda:0');l=cache['local'].to('cuda:0');mask=cache['mask'].to('cuda:0')
    val=datasets(root,initial,'val');train=datasets(root,initial,'train')
    val_indices=np.unique(np.linspace(0,len(val)-1,plan['evaluation_windows'],dtype=int))
    timeline_indices=np.arange(min(256,len(val)),dtype=int)
    combined=np.unique(np.concatenate([val_indices,timeline_indices]));lookup={int(i):j for j,i in enumerate(combined)}
    base,_=load_for_inference(root/'initial.pt','cuda:0');parts={key:[] for key in ('global','local','mask','features','time')}
    with torch.inference_mode():
        for raw in DataLoader(Subset(val,combined.tolist()),batch_size=8,shuffle=False,num_workers=2):
            batch=norm.prepare(raw,'cuda:0')
            posterior=base.encoder(batch['price'],batch['volume'],batch['mask'],batch['tick_norm'],times=batch['times'],sample=False)
            fused=base.fusion([(posterior['z_global'],posterior['z_local'])],posterior['latent_mask'],batch['times'])
            for name,value in [('global',fused['global_latent']),('local',fused['local_latent']),('mask',posterior['latent_mask'])]:parts[name].append(value)
            parts['features'].append(torch.from_numpy(market_features(raw)))
    vg,vl,vm=[torch.cat(parts[key]) for key in ('global','local','mask')]
    val_features=torch.cat(parts['features']).numpy()
    del base
    fit=np.load(root/'fit_indices.npy');plot_positions=np.unique(np.linspace(0,len(fit)-1,512,dtype=int))
    train_features=np.concatenate([market_features(raw) for raw in DataLoader(Subset(train,fit[plot_positions].tolist()),batch_size=16,shuffle=False,num_workers=2)])
    diagnostics={};projections={};target_data=None
    for lane in SOURCE_LANES:
        model,_=load_for_inference(root/'source_lanes'/lane/'final.pt','cuda:0')
        with torch.inference_mode():
            states=torch.cat([model.encode_latents(g[a:a+256],l[a:a+256],mask[a:a+256]).cpu() for a in range(0,len(g),256)])
            val_states=torch.cat([model.encode_latents(vg[a:a+64],vl[a:a+64],vm[a:a+64]).cpu() for a in range(0,len(vg),64)])
        diagnostic,center,scale,basis=spectrum(states.to('cuda:0'))
        diagnostics[lane]=diagnostic
        basis=basis.cpu();center=center.cpu();scale=scale.cpu()
        projections[lane]=dict(train=((states[plot_positions]-center)/scale@basis).numpy().tolist(),
            development=((val_states[[lookup[int(i)] for i in val_indices]]-center)/scale@basis).numpy().tolist())
        if lane==plan['target_lane']:
            target_data=dict(train=states,development=val_states[[lookup[int(i)] for i in val_indices]],
                timeline=val_states[[lookup[int(i)] for i in timeline_indices]])
        del model
        atomic_json(root/'latent_diagnostics.json',dict(models=diagnostics,projections=projections,
            feature_names=list(FEATURE_NAMES),train_features=train_features.tolist(),
            development_features=val_features[[lookup[int(i)] for i in val_indices]].tolist(),
            projection_fit='8192 training windows; training-only standardization and PCA2 for display',
            display_note='2D projections and covariance spectra do not establish a unique market state or intrinsic dimension'))
    target_data.update(train_indices=fit,development_indices=val_indices,timeline_indices=timeline_indices,
        timeline_end_time=np.array([val.base.times[int(val.base.starts[i])+15] for i in timeline_indices]),
        train_plot_positions=plot_positions,train_plot_features=train_features,
        development_features=val_features[[lookup[int(i)] for i in val_indices]])
    atomic_save(target_data,root/'states.pt')
    atomic_json(root/'preparation_status.json',dict(state='complete',train_windows=len(g),development_windows=len(val_indices),timeline_windows=len(timeline_indices)))
    del g,l,mask,vg,vl,vm
    torch.cuda.empty_cache()


def code_metrics(codec,states):
    codec.eval();parts=[];predictions=[];features=[];energies=[]
    with torch.inference_mode():
        for batch in states.split(512):
            output=codec(batch);parts.append(output['codes'].cpu());features.append(output['features'].cpu());energies.append(output['residual_energy'].cpu())
        codes=torch.cat(parts);energy=torch.cat(energies).mean(0)
        normalized=codec.normalize(states)
        result=dict(windows=len(states),code_shape=list(codes.shape),residual_energy=energy.tolist(),levels=[])
        for level in range(codec.quantizer.levels):
            counts=torch.bincount(codes[:,level],minlength=codec.quantizer.size).float();p=counts/counts.sum()
            entropy=float(-(p[p>0]*p[p>0].log2()).sum())
            result['levels'].append(dict(counts=counts.int().tolist(),used_codes=int((counts>0).sum()),
                codebook_size=codec.quantizer.size,entropy_bits=entropy,perplexity=2**entropy,
                skip_fraction=float(p[0]),note='Development usage is sample-limited; unused on development does not mean dead during training'))
        prefix={}
        for depth in (1,2,4,8):
            reconstructed=torch.cat([codec.decode_codes(chunk.to(states.device)) for chunk in codes[:,:depth].split(512)])
            error=(codec.normalize(reconstructed)-normalized).square().mean()
            raw=(reconstructed-states).square().mean()
            prefix[str(depth)]=dict(normalized_latent_mse=float(error),raw_latent_mse=float(raw),
                explained_variation_vs_train_mean=float(1-error/normalized.square().mean().clamp_min(1e-12)),
                unique_code_paths=int(torch.unique(codes[:,:depth],dim=0).shape[0]),logical_code_bits=depth*8)
        result['prefixes']=prefix
        continuous=codec.continuous(states)
        result['continuous_normalized_mse']=float((codec.normalize(continuous)-normalized).square().mean())
    return result,codes


def worker(root,lane):
    torch.set_num_threads(4);seed_everything(42);strict_precision()
    plan=json.loads((root/'plan.json').read_text());spec=plan['lanes'][lane]
    parent=torch.load(root/'initial.pt',map_location='cpu',weights_only=False)
    model=RQWindowStateVAE(rq_code_dim=spec['code_dim'],rq_kind=spec['kind'],rq_hidden_dim=plan['hidden_dim'],
        rq_levels=8,rq_codebook_size=256,rq_normalization=plan.get('normalization','per_dimension'),**parent['learned_state_config'],**parent['residual_pca_config'],
        **parent['pca_state_config'],**parent['model_config'])
    model.load_window_initial(parent['model']);model.to('cuda:0')
    _,norm=load_base(root);payload=torch.load(root/'states.pt',map_location='cpu',weights_only=False)
    states=payload['train'].to('cuda:0');development=payload['development'].to('cuda:0');codec=model.latent_codec
    codec.fit_normalization(states)
    folder=root/lane;folder.mkdir(exist_ok=True);started=time.monotonic();losses=[]
    atomic_json(folder/'status.json',dict(state='training',phase='warmup'))
    generator=torch.Generator(device='cuda:0').manual_seed(42)
    parameters=[p for p in codec.parameters() if p.requires_grad]
    optimizer=torch.optim.AdamW(parameters,lr=plan['learning_rate'],weight_decay=1e-4) if parameters else None
    def progress(phase,step,loss):
        value=dict(state='training',phase=phase,step=step,loss=float(loss),elapsed_seconds=time.monotonic()-started,
            reserved_gib=torch.cuda.memory_reserved()/2**30)
        atomic_json(folder/'progress.json',value)
        with (folder/'training.jsonl').open('a') as f:f.write(json.dumps(value)+'\n')
        print(json.dumps(value),flush=True)
    try:
        codec.train()
        if optimizer:
            for step in range(1,plan['warmup_steps']+1):
                batch=states[torch.randint(len(states),(plan['batch_size'],),generator=generator,device='cuda:0')]
                target=codec.normalize(batch);output=codec.decoder(codec.encode(batch));loss=(output-target).square().mean()
                optimizer.zero_grad(set_to_none=True);loss.backward()
                torch.nn.utils.clip_grad_norm_(parameters,1.,error_if_nonfinite=True);optimizer.step()
                if step==1 or step%64==0:progress('warmup',step,loss.detach())
        codec.eval()
        with torch.inference_mode():
            encoded=torch.cat([codec.encode(batch) for batch in states.split(512)])
            warm_continuous=float((codec.normalize(codec.continuous(development))-codec.normalize(development)).square().mean())
        initialization=codec.quantizer.initialize(encoded,iterations=plan['kmeans_iterations'])
        atomic_json(folder/'initialization.json',dict(residual_energy=initialization,warm_continuous_development_mse=warm_continuous,
            source_state_dim=1024,quantization_space_dim=spec['code_dim'],codebook_shape=list(codec.quantizer.embedding.shape)))
        if optimizer:
            codec.train()
            for step in range(1,plan['rq_steps']+1):
                batch=states[torch.randint(len(states),(plan['batch_size'],),generator=generator,device='cuda:0')]
                target=codec.normalize(batch);features=codec.encode(batch);quantized=codec.quantizer(features)
                reconstruction=torch.stack([(codec.decoder(quantized['partials'][depth-1])-target).square().mean() for depth in plan['depths']]).mean()
                continuous=(codec.decoder(features)-target).square().mean()
                loss=reconstruction+plan['commitment_weight']*quantized['commitment']+plan['continuous_weight']*continuous
                if not torch.isfinite(loss):raise FloatingPointError('Nonfinite RQ-VAE objective')
                optimizer.zero_grad(set_to_none=True);loss.backward()
                torch.nn.utils.clip_grad_norm_(parameters,1.,error_if_nonfinite=True);optimizer.step()
                if step==1 or step%64==0:progress('residual_quantization',step,loss.detach())
                if step%512==0:atomic_save(dict(codec=codec.state_dict(),step=step,optimizer=optimizer.state_dict()),folder/'codec_last.pt')
        codec.eval()
        train_metrics,train_codes=code_metrics(codec,states)
        dev_metrics,dev_codes=code_metrics(codec,development)
        timeline_metrics,timeline_codes=code_metrics(codec,payload['timeline'].to('cuda:0'))
        atomic_json(folder/'latent_metrics.json',dict(train=train_metrics,development=dev_metrics,
            warm_continuous_development_mse=warm_continuous,code_dim=spec['code_dim'],kind=spec['kind']))
        np.savez_compressed(folder/'codes.npz',train=train_codes.numpy(),development=dev_codes.numpy(),
            timeline=timeline_codes.numpy(),timeline_end_time=payload['timeline_end_time'],
            train_plot_positions=payload['train_plot_positions'],train_plot_features=payload['train_plot_features'])
        final=dict(format_version=1,model=model.state_dict(),model_config=parent['model_config'],
            config=parent['config'],pca_state_config=model.pca_state_config,
            residual_pca_config=model.residual_pca_config,learned_state_config=model.learned_state_config,
            rq_config=model.rq_config,source_hashes=source_hashes(),initial_checkpoint=plan['initial_checkpoint'])
        atomic_save(final,folder/'final.pt')
        val=datasets(root,parent,'val');rows={}
        for mode,depth in [('original',8),('continuous',8)]+[('quantized',depth) for depth in plan['depths']]:
            name=mode if mode!='quantized' else f'depth{depth}'
            model.evaluation_mode=mode;model.quantization_depth=depth
            progress('book_evaluation',depth,dev_metrics['prefixes'][str(depth)]['normalized_latent_mse'])
            value=evaluate(model,norm,val,plan['evaluation_windows'],'cuda:0')
            if mode=='original':
                expected=json.loads((root/'expected_baseline.json').read_text())['result']['metrics']
                delta=max(abs(value['metrics'][key]['rmse']-expected[key]['rmse']) for key in ('price_usdt','quantity_btc'))
                if delta>1e-4:raise RuntimeError(f'Original baseline replay changed: {delta}')
            rows[name]=value;atomic_json(folder/(name+'_evaluation.json'),dict(result=value,mode=mode,depth=depth))
            if mode!='original':
                outdir=folder/name;outdir.mkdir(exist_ok=True);examples(root,outdir,model,norm,parent,plan)
        # Verify that integer indices alone replay the quantized feature and book.
        model.eval();model.evaluation_mode='quantized';model.quantization_depth=8
        with torch.inference_mode():
            batch=development[:4];output=codec(batch)
            replay=codec.decode_codes(output['codes'])
            torch.testing.assert_close(replay,output['reconstruction'],rtol=1e-5,atol=1e-5)
        atomic_json(folder/'comparison.json',dict(latent=dict(train=train_metrics,development=dev_metrics),book=rows,
            replay_exact_within_tolerance=True,code_shape=[None,8],logical_bits=64,
            storage_note='Codes are saved as int64 arrays, not bit-packed; 64 bits excludes model/codebook and metadata costs'))
        atomic_json(folder/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started))
    except BaseException as error:
        atomic_json(folder/'status.json',dict(state='failed',error=repr(error)));raise


def campaign(root):
    started=time.monotonic();children=[]
    try:
        if (root/'states.pt').exists() and json.loads((root/'plan.json').read_text()).get('reuse_preparation'):
            atomic_json(root/'preparation_status.json',dict(state='complete',reused=True,source='Verified identical source checkpoint and training/dev latent cache'))
        else:extract(root)
        for gpu,lane in zip((2,3,4,5),LANES):
            env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),CUDA_DEVICE_ORDER='PCI_BUS_ID',PYTHONPATH=str(root/'source_snapshot'),
                PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4')
            with (root/'logs'/(lane+'.log')).open('ab',buffering=0) as log:
                p=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.rq_latent_run',str(root),'--lane',lane],
                    cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
            children.append((lane,p))
        atomic_json(root/'status.json',dict(state='running',phase='rq_training',children=[dict(lane=l,gpu=g,pid=p.pid) for g,(l,p) in zip((2,3,4,5),children)]))
        while any(p.poll() is None for _,p in children):
            if time.monotonic()-started>5400:raise TimeoutError('RQ pilot exceeded90minutes')
            if any(p.poll() not in (None,0) for _,p in children):raise RuntimeError('An RQ pilot worker failed')
            time.sleep(3)
        if any(p.returncode!=0 for _,p in children):raise RuntimeError('Nonzero RQ worker exit')
        atomic_json(root/'comparison.json',dict(rows={lane:json.loads((root/lane/'comparison.json').read_text()) for lane in LANES},
            seed=42,training_windows=8192,development_windows=128,independent_test_evaluated=False))
        atomic_json(root/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started))
    except BaseException as error:
        atomic_json(root/'status.json',dict(state='failed',error=repr(error)));raise
    finally:
        for _,p in children:
            if p.poll() is None:
                try:os.killpg(p.pid,signal.SIGTERM)
                except ProcessLookupError:pass
        for _,p in children:
            try:p.wait(timeout=10)
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL)


def prepare(project,normalization='per_dimension',reuse=None):
    parent=project/'checkpoints/learned_state_20261025_112037'
    root=project/'checkpoints'/('rq_latent_'+('global_' if normalization=='global' else '')+datetime.now().strftime('%Y%m%d_%H%M%S'))
    root.mkdir();(root/'logs').mkdir();(root/'data').mkdir()
    os.link(parent/'main/nonlinear/final.pt',root/'initial.pt')
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    for target,source in [('decoder_latents.pt',parent/'decoder_latents.pt'),('fit_indices.npy',parent/'fit_indices.npy'),('source_lanes',parent/'main')]:
        if not source.exists() and target=='decoder_latents.pt':source=project/'checkpoints/pca_state_20261024_222656/decoder_latents.pt'
        (root/target).symlink_to(os.path.relpath(source,root),target_is_directory=source.is_dir())
    shutil.copy2(parent/'main/nonlinear/final_evaluation.json',root/'expected_baseline.json')
    shutil.copy2(parent/'main/nonlinear/profiles.npz',root/'unquantized_profiles.npz')
    shutil.copy2(parent/'reference_profiles.npz',root/'original_cross_profiles.npz')
    old=json.loads((parent/'plan.json').read_text())
    plan=dict(seed=42,target_lane='nonlinear',initial_checkpoint=str(parent/'main/nonlinear/final.pt'),
        initial_sha256=sha(parent/'main/nonlinear/final.pt'),source_run=str(parent),input_dim=1024,
        lanes={'direct':dict(kind='direct',code_dim=1024),'rq64':dict(kind='ae',code_dim=64),
               'rq128':dict(kind='ae',code_dim=128),'rq256':dict(kind='ae',code_dim=256)},
        codebook_size=256,residual_levels=8,depths=[1,2,4,8],hidden_dim=512,batch_size=512,
        warmup_steps=512,rq_steps=2048,learning_rate=3e-4,commitment_weight=.25,continuous_weight=.1,
        kmeans_iterations=20,evaluation_windows=128,example_indices=old['example_indices'],
        train=old['train'],development=old['development'],independent_test_untouched=old['independent_test_untouched'],
        objective='Mean normalized latent MSE over prefixes1/2/4/8 + .25 cumulative commitment + .1 continuous AE MSE; no return targets',
        frozen='Existing source encoder, window compression and order-book generator; only new latent RQ-VAE learns',
        quantizer_variant='Separate EMA codebooks, kmeans initialization, fixedzero skip code at each level, unused EMA codes restarted every128updates belowcount0.1',
        rate='One residual code stack per whole window. Each index logically8bits; saved int64, not bit-packed. Model/codebook/metadata overhead excluded.',
        control='Direct RVQ has no learned AE and no Adam updates; true RQ-VAE arms share data/steps/loss and differ only in quantization-space width',
        reference_paper='https://arxiv.org/abs/2203.01941')
    plan['normalization']=normalization
    plan['objective']=plan['objective'].replace('normalized latent','training-normalized latent')
    if normalization=='global':plan['normalization_note']='Per-coordinate centering with a single training RMS scale; latent MSE is proportional to native raw-coordinate MSE, not per-coordinate whitening'
    if reuse:
        old_plan=json.loads((reuse/'plan.json').read_text())
        if old_plan['initial_sha256']!=plan['initial_sha256']:raise ValueError('Cannot reuse different source-state features')
        for name in ('states.pt','latent_diagnostics.json'):(root/name).symlink_to(os.path.relpath(reuse/name,root))
        plan['reuse_preparation']=str(reuse)
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'))
    freeze_sources(root/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'
        f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\n'
        f'export CUDA_VISIBLE_DEVICES=2 CUDA_DEVICE_ORDER=PCI_BUS_ID\ncd "{remote}/source_snapshot"\n'
        f'exec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.rq_latent_run "{remote}"\n')
    Path('/tmp/rq_latent_run_path').write_text(str(root));print(root,flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--lane',choices=LANES)
    p.add_argument('--normalization',choices=('per_dimension','global'),default='per_dimension');p.add_argument('--reuse',type=Path);a=p.parse_args()
    if a.prepare:prepare(a.root,a.normalization,a.reuse)
    elif a.lane:worker(a.root,a.lane)
    else:campaign(a.root)
