"""View existing physical order-book predictions; no new inference or fitting."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
import numpy as np


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def stems(ax, x, y, color, label, width=.7):
    segments = np.stack([np.stack([x, np.zeros_like(y)], -1), np.stack([x, y], -1)], 1)
    ax.add_collection(LineCollection(segments, colors=color, linewidths=width, label=label, alpha=.8))
    ax.autoscale_view()


def build(root):
    out = root / 'reconstruction_view2048_v2'
    out.mkdir(exist_ok=False)
    files = {lane: root / lane / 'step2048_profiles.npz' for lane in ['control', 'shape']}
    arrays = {}
    for lane, path in files.items():
        with np.load(path) as z:
            arrays[lane] = {key: z[key] for key in z.files}
    a, b = arrays['shape'], arrays['control']
    for key in ['truth', 'mask', 'time', 'indices']:
        np.testing.assert_array_equal(a[key], b[key])
    truth, pred, control, mask = a['truth'], a['prediction'], b['prediction'], a['mask']
    assert truth.shape == pred.shape == control.shape == (3, 256, 2, 2048, 2)
    assert a['indices'].tolist() == [0, 235, 505]
    frames = [0, 64, 128, 192, 255]
    mid = lambda x: x[:, :, :, 0, 0].mean(2)
    data = dict(indices=a['indices'].tolist(), frames=frames,
        utc=[[str(np.datetime64(int(t), 'us')) + 'Z' for t in w] for w in a['time']],
        mid_true=mid(truth).tolist(), mid_prediction=mid(pred).tolist(), mid_control=mid(control).tolist(),
        truth=truth[:, frames].tolist(), prediction=pred[:, frames].tolist(),
        control=control[:, frames].tolist(), mask=mask[:, frames].tolist())
    (out / 'data.json').write_text(json.dumps(data, separators=(',', ':'), allow_nan=False))
    # Fixed first preview window and its first frame; no best-frame selection.
    w, t = 0, 0
    q, qhat = truth[w, t, ..., 1], pred[w, t, ..., 1]
    valid = mask[w, t]
    positive, selected = (q >= 100) & valid, (qhat >= 100) & valid
    fig, axes = plt.subplots(3, 2, figsize=(16, 11), constrained_layout=True)
    for s, name in enumerate(['Bid', 'Ask']):
        ax = axes[0, s]
        k = np.arange(2048)[valid[s]]
        stems(ax, k, q[s, valid[s]], '#276b9b', 'True')
        stems(ax, k, qhat[s, valid[s]], '#d16a31', 'Reconstruction')
        ax.axhline(100, color='#777', ls=':', lw=.8)
        ax.set(title=f'{name}: all2048 ranks, one vertical line per rank', xlabel='Rank (0 = best)', ylabel='Quantity (BTC)')
        ax.legend()
    all_prices = np.concatenate([truth[w, t, ..., 0][valid], pred[w, t, ..., 0][valid]])
    lo, hi = all_prices.min(), all_prices.max()
    for col, (book, label) in enumerate([(truth, 'True book'), (pred, 'Reconstructed book')]):
        ax = axes[1, col]
        for s, name, color in [(0, 'Bid', '#247b66'), (1, 'Ask', '#b7475d')]:
            stems(ax, book[w, t, s, valid[s], 0], book[w, t, s, valid[s], 1], color, name)
        ax.set(xlim=(lo, hi), ylim=(0, max(q.max(), qhat.max()) * 1.05), title=label + ': price-quantity pairing', xlabel='Price (USDT)', ylabel='Quantity (BTC)')
        ax.legend()
    peaks = []
    for s, name in enumerate(['Bid', 'Ask']):
        center = int(np.argmax(np.where(valid[s], q[s], -np.inf)))
        ranks = np.arange(max(0, center - 8), min(2048, center + 9))
        ax = axes[2, s]
        stems(ax, ranks - .15, q[s, ranks], '#276b9b', 'True', 1.4)
        stems(ax, ranks + .15, qhat[s, ranks], '#d16a31', 'Reconstruction', 1.4)
        fp = ranks[(~positive[s] & selected[s])[ranks]]
        fn = ranks[(positive[s] & ~selected[s])[ranks]]
        ax.scatter(fp, qhat[s, fp], marker='^', c='#9338ad', label='False positive >=100BTC', zorder=4)
        ax.scatter(fn, q[s, fn], marker='x', c='#c82131', label='Missed true >=100BTC', zorder=4)
        ax.axhline(100, color='#777', ls=':', lw=.8)
        ax.set(title=f'{name}: largest true order, rank{center} +/-8', xlabel='Rank (small offsets only separate line colors)', ylabel='Quantity (BTC)')
        ax.legend(fontsize=8)
        peaks.append(dict(side=name, rank=center, true_btc=float(q[s, center]), predicted_btc=float(qhat[s, center])))
    fig.suptitle('Regional shape / step2048 | Fixed window0, frame0 | 2025-01-01 00:00:59 UTC | Reused development')
    fig.savefig(out / 'snapshot.png', dpi=140)
    plt.close(fig)
    evaluation = root / 'shape/step2048_development.json'
    results = json.loads(evaluation.read_text())['result']
    metrics = results['thresholds']['100']
    price_rmse = results['metrics']['price_usdt']['rmse']
    summary = dict(model='regional shape, step2048', exact100_development={**metrics, 'price_rmse_USDT': price_rmse},
        displayed_fixed_snapshot=dict(window_index=0, frame=0, utc=data['utc'][0][0], tp=int((positive & selected).sum()), fp=int((~positive & selected).sum()), fn=int((positive & ~selected).sum()), largest_true_by_side=peaks),
        preview_window_indices=a['indices'].tolist(), preview_frames=frames,
        input_sha256={str(p.relative_to(root)): digest(p) for p in [*files.values(), evaluation]},
        training_source_snapshot='../source_snapshot/sha256.json', optimizer_updates=0, new_inference_calls=0, independent_data_read=False)
    (out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    shutil.copy2(__file__, out / 'report_source.py')
    document = PAGE.replace('@@RECALL@@', f"{metrics['recall']:.2%}").replace('@@PRECISION@@', f"{metrics['precision']:.2%}").replace('@@PRICE@@', f'{price_rmse:.2f}')
    (out / 'index.html').write_text(document)
    print(json.dumps(summary, ensure_ascii=False))
    print(out / 'index.html')


PAGE = '''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>当前订单簿重建</title><script src="../plotly.min.js"></script><style>
body{background:#f4f6f9;color:#213549;font:15px/1.7 system-ui;margin:0}main{max-width:1400px;margin:24px auto;background:white;padding:25px}h1{font-size:27px}select{padding:7px;margin:6px}.note{background:#eef4fa;padding:15px}.grid{display:grid;grid-template-columns:1fr 1fr}.plot{height:390px}#mid{height:330px}#counts{padding:12px}a{color:#236fa1}img{width:100%}@media(max-width:800px){.grid{display:block}main{padding:14px}}</style><main>
<h1>订单簿真实值与重建值</h1><p class="note">区域形态模型，2048步终点。16个开发窗口的严格≥100BTC召回@@RECALL@@，精确率@@PRECISION@@，价格RMSE@@PRICE@@USDT。该开发集已反复用于调参，并非独立测试；尚未通过完整质量门槛。下面展示预先固定的3个窗口、每窗5帧，不能用单帧指标代替完整开发评估。</p>
<label>窗口<select id="window"></select></label><label>帧<select id="frame"></select></label><label>显示档位<select id="depth"><option>2048</option><option>512</option><option>128</option></select></label><label>快照横轴<select id="axis"><option value="price">价格</option><option value="rank">档位</option></select></label><label>数量纵轴<select id="scale"><option value="linear">线性</option><option value="log">对数</option></select></label>
<div id="counts"></div><div id="mid"></div><div class="grid"><div id="truth" class="plot"></div><div id="prediction" class="plot"></div></div><div class="grid"><div id="bid" class="plot"></div><div id="ask" class="plot"></div></div>
<p>上排快照保留预测价格与预测数量的对应关系，bid绿、ask红；下排按相同档位叠加真实值（蓝）、重建值（橙）与同预算对照（灰）。每档都是一条独立竖线。紫色三角表示误报，红色叉表示漏掉的真实大单；判定均为同帧、同侧、同档位≥100BTC。</p>
<p><a href="../shape/step2048_preview.html">原逐档预览</a> · <a href="../">完整控制变量结果</a> · <a href="summary.json">数值与来源哈希</a></p><details><summary>固定首窗口、首帧的静态快照</summary><img src="snapshot.png" alt="逐档订单簿与大单局部放大"></details>
<script>
const el=id=>document.getElementById(id);let D;
fetch('data.json').then(r=>{if(!r.ok)throw Error(r.status);return r.json()}).then(d=>{D=d;D.indices.forEach((v,i)=>el('window').add(new Option('窗口'+v+' · '+D.utc[i][0],i)));D.frames.forEach((v,i)=>el('frame').add(new Option('第'+v+'分钟',i)));draw()}).catch(e=>el('counts').textContent='加载失败：'+e);
function stem(book,m,n,name,color,axis){let x=[],y=[];for(let k=0;k<n;k++)if(m[k]){const v=axis==='price'?book[k][0]:k;x.push(v,v,null);y.push(0,book[k][1],null)}return{x,y,name,type:'scattergl',mode:'lines',line:{color,width:1},connectgaps:false}}
function draw(){const w=+el('window').value,f=+el('frame').value,t=D.frames[f],n=+el('depth').value,axis=el('axis').value,scale=el('scale').value;
let tp=0,fp=0,fn=0;for(let s=0;s<2;s++)for(let k=0;k<2048;k++)if(D.mask[w][f][s][k]){const a=D.truth[w][f][s][k][1]>=100,b=D.prediction[w][f][s][k][1]>=100;tp+=a&&b;fp+=!a&&b;fn+=a&&!b}
el('counts').textContent=D.utc[w][t]+' · 当前帧全2048档：命中'+tp+'，漏报'+fn+'，误报'+fp+'。整窗输入始终为256分钟。';
const x=Array.from({length:256},(_,i)=>i);Plotly.react('mid',[{x,y:D.mid_true[w],name:'真实中间价',line:{color:'#276b9b'}},{x,y:D.mid_prediction[w],name:'形态模型',line:{color:'#d16a31'}},{x,y:D.mid_control[w],name:'同预算对照',line:{color:'#9ba7b3',dash:'dot'}}],{title:{text:'完整256分钟中间价'},xaxis:{title:{text:'分钟'}},yaxis:{title:{text:'USDT'}},margin:{t:45,l:75,b:50,r:20}},{responsive:true});
const prices=[],quantities=[];for(let s=0;s<2;s++)for(let k=0;k<n;k++)if(D.mask[w][f][s][k]){prices.push(D.truth[w][f][s][k][0],D.prediction[w][f][s][k][0]);quantities.push(D.truth[w][f][s][k][1],D.prediction[w][f][s][k][1])}const range=axis==='price'?[Math.min(...prices),Math.max(...prices)]:[0,n-1],qmax=Math.max(...quantities,1e-3)*1.05,yrange=scale==='log'?[-3,Math.log10(qmax)]:[0,qmax];
for(const key of ['truth','prediction']){let traces=[];for(let s=0;s<2;s++)traces.push(stem(D[key][w][f][s],D.mask[w][f][s],n,s?'ask':'bid',s?'#b7475d':'#247b66',axis));Plotly.react(key,traces,{title:{text:(key==='truth'?'真实订单簿':'重建订单簿')+' · '+t+'分钟'},xaxis:{title:{text:axis==='price'?'USDT':'档位'},range},yaxis:{title:{text:'BTC'},type:scale,range:yrange},margin:{t:45,l:65,b:50,r:20}},{responsive:true})}
for(let s=0;s<2;s++){const m=D.mask[w][f][s],q=D.truth[w][f][s],p=D.prediction[w][f][s],c=D.control[w][f][s];let traces=[stem(q,m,n,'真实','#276b9b','rank'),stem(c,m,n,'对照','#a7afb8','rank'),stem(p,m,n,'形态模型','#d16a31','rank')];for(const miss of [true,false]){let x=[],y=[];for(let k=0;k<n;k++)if(m[k]&&(miss?(q[k][1]>=100&&p[k][1]<100):(q[k][1]<100&&p[k][1]>=100))){x.push(k);y.push(miss?q[k][1]:p[k][1])}traces.push({x,y,name:miss?'漏报≥100BTC':'误报≥100BTC',mode:'markers',type:'scattergl',marker:{symbol:miss?'x':'triangle-up',color:miss?'#c82131':'#9338ad',size:9}})}Plotly.react(s?'ask':'bid',traces,{title:{text:(s?'Ask':'Bid')+' · 同档位数量对比'},xaxis:{title:{text:'档位，0为最优档'}},yaxis:{title:{text:'BTC'},type:scale},shapes:[{type:'line',xref:'paper',x0:0,x1:1,y0:100,y1:100,line:{color:'#888',dash:'dot'}}],margin:{t:45,l:65,b:50,r:20}},{responsive:true})}}
for(const id of ['window','frame','depth','axis','scale'])el(id).addEventListener('change',()=>{if(D)draw()});
</script></main></html>'''


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    args = parser.parse_args()
    build(args.root.resolve())
