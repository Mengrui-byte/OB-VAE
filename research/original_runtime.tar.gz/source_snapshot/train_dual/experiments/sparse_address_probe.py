"""GPU test of a self-contained sparse-address code, not an output oracle."""
import argparse
from datetime import datetime
import hashlib
import html
import json
import os
from pathlib import Path
import shutil
import time

import numpy as np
import torch

from model.autoencoder.sparse_address_vae import SparseAddressOrderBookVAE
from model.layers.sparse_address import price_dimension
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.goal_evaluate import assess_file,evaluate_result
from train_dual.experiments.local_quant_reconstruction import CacheWindows
from train_dual.experiments.long_worker import atomic_json,evaluate
from train_dual.experiments.phase_detail_report import read,fmt,STYLE
from train_dual.experiments.region_task_run import safe_preview,gpu_free
from train_dual.experiments.time_logit_run import write_profiles
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import atomic_save,freeze_sources,load_for_inference
from train_dual.util.phase_training import tensor_digest


CASES={'dense0':(0,True),'m1024':(1024,True),'m1536':(1536,True),'m2048_off':(2048,False),'m2048':(2048,True),'m3072':(3072,True)}
LABELS={name:f'{M}窗口地址 · {price_dimension(M)}价格通道'+(' · 禁用稀疏输出' if not enabled else '') for name,(M,enabled) in CASES.items()}


def render(root):
    state=read(root/'status.json',{});parts=[f'<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta http-equiv="refresh" content="30"><title>8192维结构化稀疏瓶颈</title><style>{STYLE}</style><main>',
        '<h1>同8192标量：神经价格子空间＋全窗口稀疏地址</h1>',
        f'<div class="note">状态：{html.escape(state.get("state","prepared"))}。完整256分钟、双侧2048档、唯一64×128Gaussian，确定性μ重建。全部位置与数量均存储在Z内，无Encoder旁路。</div>',
        '<p>这是一种显式稀疏编码归纳偏置，不是宣称无约束神经网络自行学会了复制。Encoder用训练期价格投影和全窗口Top-M索引/挂量组成8192个数；Decoder仅从Z恢复价格与神经背景，再用Z内的地址/数量恢复保留位置。索引包含时间、买卖侧及档位；FP32可精确表示这些整数。</p>',
        '<p>价格仍由神经网络产生；没有额外真实逐帧mid或真实价格条件。M=2048时价格16×256=4096标量，索引2048及数量2048，共8192。原32维逐帧模型是无地址对照；m2048_off与m2048的权重及Z完全相同，只关闭稀疏数量输出作干预。</p>',
        '<p>继承旧逐帧模型第4096步权重，在8个固定训练窗的2048个帧表示上拟合PCA价格投影；本探针没有新增SGD更新，不宣称重新端到端训练。若价格投影不达标再检验完整训练适配。KL仍为0，地址/数量坐标是结构化物理数值，不宣称已学到标准正态先验或市场因子。</p>',
        '<div class="wrap"><table><tr><th>方案</th><th>窗口类</th><th>价格RMSE</th><th>分钟mid变化RMSE</th><th>数量RMSE</th><th>100BTC召回</th><th>精确率</th><th>误报</th><th>图</th></tr>']
    for name in CASES:
        for split in ['development','seen','unseen']:
            d=read(root/name/f'step0_{split}.json')
            if not d:continue
            r=d['result'];m=r['metrics'];t=r['thresholds']['100'];link=f'{name}/step0_preview.html'
            vals=[LABELS[name],split,fmt(m['price_usdt']['rmse']),fmt(m['temporal_mid_1_minutes_usdt_per_minute']['rmse']),fmt(m['quantity_btc']['rmse']),fmt(t['recall']),fmt(t['precision']),str(t['fp']),f'<a href="{link}">重建图</a>' if split=='development' else '—']
            parts.append('<tr>'+''.join(f'<td>{v}</td>' for v in vals)+'</tr>')
    parts.extend(['</table></div><p>development为反复使用的2025Q1；seen8参与学生训练，unseen32未参与该学生梯度训练。独立确认只在候选冻结后进行，不能把训练统计中的Top-M覆盖率当作模型成绩。</p>',
        '<p><a href="summary.json">结构/指标筛选</a> · <a href="confirmation/status.json">冻结候选确认</a> · <a href="plan.json">配置</a> · <a href="design.md">编码与容量说明</a> · <a href="source_snapshot/sha256.json">源码哈希</a> · <a href="../">持续目标</a></p></main></html>'])
    temp=root/'index.tmp';temp.write_text(''.join(parts));temp.replace(root/'index.html')


def prepare(goal):
    goal=goal.resolve();parent=goal.parent/read(goal/'contract.json')['predecessor']
    root=goal/'sparse_address_diagnostic';root.mkdir()
    for name in ['data','logs','confirmation',*CASES]:(root/name).mkdir()
    for name in ['train_indices.npy','val_indices.npy','seen_indices.npy','unseen_indices.npy','calibration_indices.npy','plotly.min.js']:
        os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    os.link(goal/'reference_model.pt',root/'source.pt')
    plan=read(parent/'plan.json');plan.update(experiment='8192scalar neuralprice subspace+explicitwindow sparse addresses',labels=LABELS,
        cases={n:dict(peak_slots=M,use_addresses=enabled,price_dim=price_dimension(M)) for n,(M,enabled) in CASES.items()},
        source='Original frame_huber/step4096; same weights forallcases. No SGD updates inthisprobe.',
        basis_fit='8preselected2022–2024trainingwindows only, one32x32covariance over2048framecodes; no whitening. ComposednewEncoderheadandDecoderinverse projection remainlearnable.',
        scalar_budget='256*price_dim+2*M=8192. Pricecodefirst, thenMflattened(time,side,level) addresses andMrawBTCamplitudes. SameoneGaussian/no rawdata atdecode. ExplicitTopM addresses area designedencoder, notunconstrainedlearnedmanifold.',
        primary_candidates=['m2048','m3072'],primary_reason='Training-only rawstatistics: windowTop2048covers80.65% of>=100BTCpositions, Top3072covers93.06%; lowerMareallocationcontrols andnotacceptedsolelyforfavorable2025sparsity.',
        admission='Diagnosticcomparisononly unlessuserexplicitlyacceptsstructuredhybridEncoderforfinalgoal. Purelearnedneuralmainline continues independently.',allow_confirmation=False,
        steps=0,checkpoints=[],wait_gpu='Wait untilownedparentcontrolworkercomplete andGPU2free>=47000MiB; runonlywhileotherparentworkers stillhave>=900updates. Otherwise markdeferredforrootagent toreschedule, avoidingracewith queuedresponse/newcohort.',
        wait_seconds=13*3600,gpu_probe_seconds=1800,
        preview_descriptions={n:'结构化8192维编码的固定2025Q1开发窗口重建；该开发期已反复用于研究，不是独立测试。大单位置/幅度必须先编码进Z，价格无真实mid旁路。' for n in CASES})
    atomic_json(root/'plan.json',plan)
    (root/'design.md').write_text('''# 结构化稀疏瓶颈对照

原始输入始终[B,256,2,2048,2]。单Encoder将神经价格表示与已观测挂量的Top-M位置及幅度拼入唯一Gaussian均值[B,64,128]；只输出一个mu/logvar/Z，两个Decoder读取同一个Z对象，无Encoder缓存或原始输入旁路。

每个全窗口地址为t*(2*2048)+side*2048+level，最大1048575，FP32可精确表示。M个地址与M个BTC数量也计入8192，余下256*d个数为逐帧神经价格表示，d=(8192-2M)/256。M2048对应d16；M3072对应d8。512等低M在训练高密度窗口不能保留足够大单，不能只凭2025开发稀疏性挑选成功，因此主要候选预先限定M2048/3072。

价格骨干和神经挂量背景来自原frame_huber/4096。源32维逐帧mu在固定8个训练窗上拟合PCA；Encoder均值头与投影合成，Decoder在各自独立时间展开前以线性逆投影恢复32维。价格仍由神经Decoder生成，未硬写真实逐帧mid。背景数量仍为原Softplus网络输出，在Z存储的M个位置写回Z的数量。它是显式稀疏编码，不声称无约束神经网络自行学会了这些地址。

此探针没有新SGD训练，报告源预训练成本与训练期投影拟合；全部神经参数仍可继续端到端适配。Gaussian地址/数量坐标使用物理单位、方差固定exp(-12)，KL=0，确定性推理用mu；不是已正则到标准正态、可直接采样的市场状态生成器，也不是实际比特率结论。

M0为原模型精确重放控制；M2048_off与M2048的参数和Z完全相同，唯一干预是关闭稀疏写回。先验证实际完整形状、单Z对象和decode-only重放，再做同16开发/8见过训练/32同年代未见训练窗口评价。主要候选需同时开发门槛及seen/unseen召回>80%，并核对数量与价格；通过后冻结候选，仅对一个候选在预先均匀选择的32个2025Q2窗口确认，比较冻结当前原模型在相同窗口的价格恢复。Q2不用于训练/校准/选择多个候选；失败不得称独立确认成功。

仅在当前control正常结束、GPU2空闲且另两组至少还差900步时使用该卡，其他训练继续；如任务接近结束，标记deferred交由主研究agent在后续空闲时重新调度，不与已有response或下一轮校准争卡。所有模型、配置、结果、投影、快照均保存在本实验目录，历史文件不改写。
''')
    atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot');render(root)
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e/recons')/goal.name/root.name
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=2\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.sparse_address_probe "{remote}"\n')
    print(root,flush=True)


def assert_contract(root,name,model,norm,data):
    raw={k:v.unsqueeze(0) for k,v in data[0].items()};b=norm.prepare(raw,'cuda:0');seen=[]
    hooks=[d.register_forward_pre_hook(lambda m,a:seen.append(a[0])) for d in [model.price_decoder,model.volume_decoder]]
    with torch.inference_mode():
        out=call(model,b,False);assert seen[0] is seen[1] and seen[0] is out['z']
        replay=model.decode(out['z'],b['mask'],b['tick_norm'],b['times'])
        for key in ['price_norm','volume']:torch.testing.assert_close(out[key],replay[key],rtol=0,atol=0)
    for h in hooks:h.remove()
    assert list(raw['data'].shape)==[1,256,2,2048,2] and list(out['mu'].shape)==list(out['logvar'].shape)==[1,64,128]
    assert list(out['volume'].shape)==list(out['price_norm'].shape)==[1,256,2,2048]
    atomic_json(root/name/'actual_shape_contract.json',dict(passed=True,raw=list(raw['data'].shape),mu=list(out['mu'].shape),logvar=list(out['logvar'].shape),z=list(out['z'].shape),reconstruction=list(out['volume'].shape),scalar_count=out['z'].numel(),single_z_object=True,decode_only_exact=True,posterior_count=1,encoder_bypass=False,all_address_amplitude_information_in_z=True))


def confirm(root,name,checkpoint):
    folder=root/'confirmation';plan=read(root/'plan.json');plan.update(development=['2025-04-01','2025-07-01'])
    (folder/'data').mkdir(exist_ok=True);os.link(root/'data/BTCUSDT.npz',folder/'data/BTCUSDT.npz')
    atomic_json(folder/'plan.json',plan)
    data=dataset(folder,'val');indices=np.unique(np.linspace(0,len(data)-1,32,dtype=np.int64))
    atomic_json(folder/'selection.json',dict(candidate=name,checkpoint_sha256=hashlib.sha256(checkpoint.read_bytes()).hexdigest(),indices=indices.tolist(),selection='32equallyspacedfullwindows in2025Q2, fixedaftercandidatefreezeandbeforeanyQ2metrics. Exactlyonecandidate, nooptimizerupdates.',dates=plan['development']))
    cached=CacheWindows(data,indices);atomic_json(folder/'status.json',dict(state='evaluating_frozen_models'))
    baseline,norm=load_for_inference(root/'source.pt','cuda:0');base_result=evaluate(baseline,norm,cached,len(cached),'cuda:0');del baseline;torch.cuda.empty_cache()
    model,norm=load_for_inference(checkpoint,'cuda:0');candidate=evaluate(model,norm,cached,len(cached),'cuda:0');del model;torch.cuda.empty_cache()
    atomic_json(folder/'baseline.json',dict(result=base_result));atomic_json(folder/'candidate.json',dict(result=candidate))
    verdict=evaluate_result(candidate,base_result);verdict['pass']=verdict.pop('pass_')
    atomic_json(folder/'verdict.json',verdict)
    atomic_json(folder/'status.json',dict(state='complete',candidate=name,passed=verdict['pass'],comparison='Same32Q2windows,frozenoriginalbaseline andonefrozencandidate. No modelselectiononQ2.'))
    if verdict['pass']:
        atomic_json(root.parent/'secondary_candidate_for_final_audit.json',dict(candidate=name,checkpoint=str(checkpoint),development=str(root/name/'step0_development.json'),confirmation=str(folder/'verdict.json'),shape_audit=str(root/name/'actual_shape_contract.json'),source_snapshot=str(root/'source_snapshot'),note='Goalnotautomaticallycomplete; rootagentmustauditallrequirementsbeforeupdate_goal.'))


def run(root):
    torch.set_num_threads(4);strict_precision();plan=read(root/'plan.json');goal=root.parent;parent=goal.parent/read(goal/'contract.json')['predecessor'];started=time.monotonic()
    while True:
        state=read(parent/'status.json',{});control=read(parent/'control/status.json',{})
        others=[read(parent/lane/'progress.json',{}) for lane in ['hint','both']]
        long_gap=all(p.get('total',8192)-p.get('step',0)>=900 for p in others)
        if control.get('state') in ['complete','budget_complete'] and gpu_free().get(2,0)>=47000 and long_gap:break
        if control.get('state') in ['complete','budget_complete'] and not long_gap:
            atomic_json(root/'status.json',dict(state='deferred_no_safe_idle_gap',note='RootagentwillrescheduleonlyafterverifiedexclusiveGPUavailability. No overlapwithownedresponse/newcohort.'));render(root);return
        if state.get('state')=='failed':raise RuntimeError('Parentfailed; inspectinstead ofsharingcards')
        if time.monotonic()-started>plan['wait_seconds']:raise TimeoutError('13hour waitceiling')
        atomic_json(root/'status.json',dict(state='waiting_for_owned_idle_gpu2',control_state=control.get('state'),long_gap=long_gap));render(root);time.sleep(20)
    began=time.monotonic();atomic_json(root/'status.json',dict(state='fitting_training_projection_gpu2'))
    source,norm=load_for_inference(root/'source.pt','cuda:0');source.eval().requires_grad_(False);payload=torch.load(root/'source.pt',map_location='cpu',weights_only=False)
    train=dataset(root,'train');rows=[]
    with torch.inference_mode():
        for index in np.load(root/'calibration_indices.npy'):
            b=norm.prepare({k:v.unsqueeze(0) for k,v in train[int(index)].items()},'cuda:0')
            mu,_=source.encoder(b['price'],b['volume'],b['mask'],b['tick_norm'],b['times']);rows.append(mu.reshape(-1,32).double())
    x=torch.cat(rows);mean=x.mean(0);centered=x-mean;values,vectors=torch.linalg.eigh(centered.T@centered/len(x));basis=vectors.flip(-1).float();mean=mean.float()
    atomic_save(dict(basis=basis.cpu(),mean=mean.cpu(),eigenvalues=values.flip(0).cpu(),training_indices=np.load(root/'calibration_indices.npy')),root/'price_basis.pt')
    del source,x,rows,centered;torch.cuda.empty_cache()
    original_val=dataset(root,'val');dev=CacheWindows(original_val,np.load(root/'val_indices.npy'));sets={'development':dev,'seen':CacheWindows(train,np.load(root/'seen_indices.npy')),'unseen':CacheWindows(train,np.load(root/'unseen_indices.npy'))};summaries={};hashes={}
    for name,(M,enabled) in CASES.items():
        if time.monotonic()-began>plan['gpu_probe_seconds']:raise TimeoutError('GPUprobe30minute ceiling')
        d=price_dimension(M);model=SparseAddressOrderBookVAE(peak_slots=M,use_addresses=enabled,**payload['unified_vae_config']).to('cuda:0').eval()
        state={k:v.to('cuda:0') for k,v in payload['model'].items()}
        model.load_dense_initial(state,torch.eye(32,device='cuda:0') if M==0 else basis[:,:d],torch.zeros(32,device='cuda:0') if M==0 else mean)
        assert_contract(root,name,model,norm,dev);hashes[name]=tensor_digest(model)
        atomic_save(dict(format_version=1,model=model.state_dict(),unified_vae_config=payload['unified_vae_config'],sparse_address_config=dict(peak_slots=M,use_addresses=enabled,frame_ffn=1536),config=payload['config'],step=0,initialization='Inheritedframe_huber4096+training8windowPCA; nonewSGD',source_checkpoint_sha256=hashlib.sha256((root/'source.pt').read_bytes()).hexdigest()),root/name/'model.pt')
        atomic_json(root/'status.json',dict(state='evaluating_gpu2',case=name))
        for split,data in sets.items():atomic_json(root/name/f'step0_{split}.json',dict(result=evaluate(model,norm,data,len(data),'cuda:0')))
        write_profiles(root/name,0,model,norm,dev,original_val);safe_preview(root,name,0)
        verdict=assess_file(root/name/'step0_development.json',goal/'reference_evaluation.json')
        seen=read(root/name/'step0_seen.json')['result']['thresholds']['100']['recall'];unseen=read(root/name/'step0_unseen.json')['result']['thresholds']['100']['recall']
        summaries[name]=dict(development=verdict,seen_recall=seen,unseen_recall=unseen,eligible_primary=name in plan['primary_candidates'],model_sha256=hashes[name],price_dim=d,peak_slots=M)
        atomic_json(root/'summary.json',summaries);render(root)
        del model,state;torch.cuda.empty_cache()
    if hashes['m2048']!=hashes['m2048_off']:raise RuntimeError('On/offcontrols weightinitialization mismatch')
    baseline=read(root/'dense0/step0_development.json')['result'];expected=read(goal/'reference_evaluation.json')['result']
    for key in ['price_usdt','quantity_btc']:
        if not np.isclose(baseline['metrics'][key]['rmse'],expected['metrics'][key]['rmse'],atol=1e-5,rtol=1e-5):raise RuntimeError('Originaldensemodel replaymismatch')
    passing=[n for n,s in summaries.items() if s['eligible_primary'] and s['development']['pass'] and (s['seen_recall'] or 0)>.8 and (s['unseen_recall'] or 0)>.8]
    if passing and plan.get('allow_confirmation',False):
        chosen=min(passing,key=lambda n:summaries[n]['development']['price_rmse'])
        confirm(root,chosen,root/chosen/'model.pt')
    else:atomic_json(root/'confirmation/status.json',dict(state='not_started_diagnostic_only' if passing else 'not_started_no_eligible_development_candidate',note='No Q2dataused. Hybridcodingcannotautomaticallycompletepurelearnedneuralgoal.'))
    atomic_json(root/'status.json',dict(state='complete',gpu_seconds=time.monotonic()-began,controlled_same_weights=hashes['m2048']==hashes['m2048_off'],eligible_candidates=passing));render(root)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');args=p.parse_args();root=args.root.resolve()
    try:
        if args.prepare:prepare(root)
        else:run(root)
    except BaseException as error:
        if not args.prepare:atomic_json(root/'status.json',dict(state='failed',error=repr(error)));render(root)
        raise
