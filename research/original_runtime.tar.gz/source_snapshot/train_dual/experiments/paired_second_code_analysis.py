"""Audit second residual-code occupancy and information beyond the first code."""

import argparse
from datetime import datetime
import json
from pathlib import Path
import shutil

import numpy as np

from train_dual.experiments.paired_state_analysis import FEATURES, group_profiles
from train_dual.util.checkpoint import freeze_sources


def entropy(labels):
    _, counts = np.unique(labels, axis=0, return_counts=True)
    p = counts / counts.sum()
    return float(-(p * np.log2(p)).sum())


def audit(codes):
    first, second = codes[:, 0], codes[:, 1]
    values, counts = np.unique(second, return_counts=True)
    order = np.argsort(counts)[::-1]
    conditional = entropy(codes[:, :2]) - entropy(first)
    assert conditional >= -1e-12
    levels = []
    for i in range(codes.shape[1]):
        v, n = np.unique(codes[:, i], return_counts=True)
        h = entropy(codes[:, i])
        levels.append(dict(level=i+1, used=len(v), entropy_bits=h, perplexity=2**h,
                           largest_fraction=float(n.max()/len(codes))))
    if len(values) == 1:
        assert len(np.unique(codes[:, :2], axis=0)) == len(np.unique(first))
        assert abs(conditional) < 1e-12
    return dict(windows=len(codes),second_counts=[dict(code=int(values[i]),count=int(counts[i])) for i in order],
                singleton_codes=int((counts == 1).sum()),first_used=len(np.unique(first)),
                first_second_pairs=len(np.unique(codes[:, :2],axis=0)),
                second_entropy_bits=entropy(second),conditional_entropy_bits=max(0.,conditional),
                levels=levels)


PAGE = '''<!doctype html><html lang=zh-CN><meta charset=utf-8><title>第二级残差码字审计</title><script src=plotly.min.js></script><style>body{font:16px system-ui;max-width:1450px;margin:30px auto;padding:0 20px;color:#182b43}p{line-height:1.8}table{border-collapse:collapse;width:100%}td,th{padding:9px;border:1px solid #ddd}select{font:inherit;padding:5px}.plots{display:grid;grid-template-columns:1fr 1fr}a{color:#2563eb}</style><h1>第二级码字：有没有新增的市场状态信息？</h1><p>固定已有码本，沿用8192个训练窗口、128个2025Q1开发窗口及同一批原始特征。没有重训、没有改变距离、没有未来收益；2025Q2未使用。开发集并非最终独立测试。</p><p><a href=states.html>第一级市场状态</a> · <a href=pair.html>重建指标</a> · <a href=second_code_analysis.json>全部审计数据</a></p><p><b>当前两种联合距离的第二级在128个开发窗口上都只选码227。</b>训练中7937/8192个窗口选227，其余255码各一个窗口。使用256码并不代表存在256种有效状态。开发条件熵H(C2|C1)=0，第一级与前两级组合均只有15种分组，没有新增区分。</p><p>第二级作用于第一级之后的残差：R1=(G−均值G−CG1, L−均值L−CL1)，再用相同的无权重距离选择(CG2,CL2)。固定码仍可加一个共同修正，但没有为不同开发窗口提供不同的第二级信息。不能因此推断残差没有信息，也不能断言修复后仍无法分类。</p><p>方法 <select id=method></select> 数据 <select id=split><option value=development>开发128窗口</option><option value=train>训练8192窗口</option></select> 第二级码 <select id=code></select></p><p id=summary></p><div class=plots><div id=usage></div><div id=entropy></div><div id=path></div><div id=profile></div></div><table><thead><tr><th>特征</th><th>选中第二级码均值</th><th>整体均值</th><th>单位</th></tr></thead><tbody id=features></tbody></table><h2>逐级码本使用情况</h2><table><thead><tr><th>残差级</th><th>使用码数</th><th>熵bit</th><th>有效码数2^H</th><th>最大码占比</th></tr></thead><tbody id=levels></tbody></table><p>单样本码的特征只用于检查，不赋予经济名称。独立码本对照可选Global和Local；它们有独立索引，不能视为联合码字效果。当前独立256码Global的第二级仍有多个有效码，联合与Local的退化不代表整个latent已无信息。</p><script>let d;const $=x=>document.getElementById(x),f=(x,n=4)=>Number.isFinite(x)?x.toFixed(n):'—';function rows(id,a){$(id).replaceChildren(...a.map(v=>{let r=document.createElement('tr');for(let x of v){let c=document.createElement('td');c.textContent=x;r.append(c)}return r}))}function plot(id,traces,title){Plotly.react(id,traces,{height:380,title,template:'plotly_white',margin:{t:55,b:65,l:70}},{responsive:true,displaylogo:false})}function fill(){let z=d.methods[$('method').value][$('split').value];$('code').replaceChildren(...z.groups.map(x=>new Option(x.code+'（n='+x.count+'）',x.code)));draw()}function draw(){let v=d.methods[$('method').value],s=$('split').value,z=v[s],r=z.groups.find(x=>x.code==$('code').value);$('summary').textContent='第二级使用 '+z.second_counts.length+' 码；单样本码 '+z.singleton_codes+' 个；H(C2)='+f(z.second_entropy_bits)+'bit；H(C2|C1)='+f(z.conditional_entropy_bits)+'bit；一级类别 '+z.first_used+'，两级组合 '+z.first_second_pairs+'。';plot('usage',[{type:'bar',x:z.second_counts.map(x=>x.code),y:z.second_counts.map(x=>x.count)}],'第二级各码窗口数');plot('entropy',['train','development'].map(k=>({x:v[k].levels.map(x=>x.level),y:v[k].levels.map(x=>x.perplexity),name:k==='train'?'训练':'开发',mode:'lines+markers'})),'各级有效码数（困惑度）');plot('path',[{x:Array.from({length:16},(_,i)=>i),y:r.mean_curves[0],mode:'lines+markers'}],'第二级码 '+r.code+' 的类内平均中间价路径（bp）');plot('profile',[0,1].map(k=>({x:Array.from({length:32},(_,i)=>i*64+32),y:r.profile[k],name:k?'卖盘':'买盘',mode:'lines+markers'})),'原始挂量轮廓（每64档平均BTC）');rows('features',d.features.map((x,j)=>[x[1],f(r.mean[j]),f(d.splits[s].mean[j]),x[2]]));rows('levels',z.levels.map(x=>[x.level,x.used,f(x.entropy_bits),f(x.perplexity),f(x.largest_fraction*100,2)+'%']))}fetch('second_code_analysis.json').then(x=>x.json()).then(x=>{d=x;$('method').replaceChildren(...Object.keys(d.methods).map(k=>new Option(k,k)));fill()});$('method').onchange=fill;$('split').onchange=fill;$('code').onchange=draw;</script></html>'''


def main(root, previous):
    root, previous = root.resolve(), previous.resolve()
    folder = root/'analysis'/('second_code_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
    folder.mkdir(parents=True)
    shutil.copy2(__file__,folder/'analysis_source.py')
    old = json.loads((previous/'state_analysis.json').read_text())
    raw = {s:dict(np.load(previous/(s+'_features.npz'))) for s in ('train','development')}
    methods = {}
    for lane in ('joint_l2','joint_max','independent16','independent256'):
        stored = dict(np.load(root/lane/'codes.npz'))
        np.testing.assert_array_equal(stored['development_indices'],raw['development']['indices'])
        np.testing.assert_array_equal(np.load(root/'fit_indices.npy'),raw['train']['indices'])
        branches = [('pair',None)] if lane.startswith('joint') else [('global',0),('local',1)]
        for branch,axis in branches:
            result = {}
            for split in raw:
                codes = stored[split] if axis is None else stored[split][:,:,axis]
                z=raw[split];value=audit(codes)
                value['groups']=group_profiles(z['values'],codes[:,1],z['profiles'],z['curves'])
                for g in value['groups']:
                    if g['count'] == len(codes):
                        np.testing.assert_allclose(g['mean'],z['values'].mean(0),rtol=0,atol=0)
                result[split]=value
            methods[lane+'/'+branch]=result
    books={}
    for lane in ('joint_l2','joint_max'):
        metrics=json.loads((root/lane/'latent_metrics.json').read_text())
        books[lane]=dict(latent_energy={s:metrics[s]['residual_energy'][:3] for s in raw},book={})
        for level in (1,2):
            value=json.loads((root/lane/f'depth{level}_evaluation.json').read_text())['result']
            books[lane]['book'][str(level)]={k:value['metrics'][k]['rmse'] for k in ('price_usdt','quantity_btc')}
    value=dict(features=FEATURES,splits=old['splits'],methods=methods,books=books,
               feature_source=str(previous),model_source=str(root),model_and_codes_unchanged=True,
               no_future_returns=True,independent_test_evaluated=False,
               limitation='Occupancy audit identifies degeneration, not its causal mechanism. No unmeasured class semantics asserted.')
    (folder/'second_code_analysis.json').write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False))
    (folder/'second.html').write_text(PAGE)
    freeze_sources(folder/'source_snapshot')
    for name in ('second.html','second_code_analysis.json'):
        target=root/'viewer'/name;temporary=target.with_suffix(target.suffix+'.tmp')
        temporary.symlink_to(folder/name);temporary.replace(target)
    Path('/tmp/paired_second_analysis_path').write_text(str(folder))
    print(folder,flush=True)


if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('features',type=Path)
    a=p.parse_args();main(a.root,a.features)
