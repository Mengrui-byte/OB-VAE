"""Summarize paired training-code changes without treating them as candidates."""
import argparse
import hashlib
import html
from pathlib import Path
import shutil

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read, STYLE
from train_dual.experiments.recall_goal_run import record


def analyze(root, step):
    output = root / f'analysis_step{step}'
    output.mkdir()
    source = root / 'step0_fit_evaluation.json'
    fitted = root / f'step{step}_fit_evaluation.json'
    a, b = read(source), read(fitted)
    assert read(root / f'step{step}_frozen_audit.json')['passed']
    assert len(a['per_window']) == len(b['per_window']) == 8
    rows = []
    for old, new in zip(a['per_window'], b['per_window']):
        assert old['training_index'] == new['training_index']
        rows.append(dict(index=old['training_index'], true_events=old['tp'] + old['fn'],
            source_recall=old['recall'], fitted_recall=new['recall'], source_precision=old['precision'], fitted_precision=new['precision'],
            price_ratio=new['price_rmse'] / old['price_rmse'], mid_delta_ratio=new['mid_delta_rmse'] / old['mid_delta_rmse'],
            quantity_ratio=new['quantity_rmse'] / old['quantity_rmse'], relative_z_drift=new['relative_z_drift'], price_guard_passed=new['price_guard_passed']))
    summary = dict(step_per_window=step, rows=rows, source_pooled=a['pooled'], fitted_pooled=b['pooled'],
        recall_improved_windows=sum(v['fitted_recall'] > v['source_recall'] for v in rows),
        precision_improved_windows=sum(v['fitted_precision'] > v['source_precision'] for v in rows),
        price_guard_passed_windows=sum(v['price_guard_passed'] for v in rows),
        individual_training_windows_meeting_recall_precision_and_relative_price=sum(v['fitted_recall'] > .8 and v['fitted_precision'] >= .5 and v['price_guard_passed'] for v in rows),
        largest_window_event_share=max(v['true_events'] for v in rows) / sum(v['true_events'] for v in rows),
        independent_data_read=False, is_goal_candidate=False,
        interpretation='Target-assisted training-only code fitting. Improvements show accessible fixed-Decoder reconstructions for these cases; a failed finite fit does not prove impossibility. Do not infer Encoder or out-of-sample performance.',
        input_sha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in [source, fitted]})
    atomic_json(output / 'summary.json', summary)
    shutil.copy2(__file__, output / 'report_source.py')
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.2))
    x = np.arange(len(rows))
    for ax, name, label in zip(axes[:2], ['recall', 'precision'], ['Same-rank recall (%)', 'Same-rank precision (%)']):
        ax.bar(x - .18, [100*v['source_' + name] for v in rows], width=.36, label='Source code', color='#4477AA')
        ax.bar(x + .18, [100*v['fitted_' + name] for v in rows], width=.36, label=f'Fitted code: {step} updates', color='#CC6677')
        ax.set(ylim=(0, 105), ylabel=label)
        ax.set_xticks(x, [str(v['index']) for v in rows], rotation=55)
        ax.grid(axis='y', alpha=.2)
    axes[0].legend(fontsize=8)
    axes[2].plot(x, [v['price_ratio'] for v in rows], 'o-', label='Price RMSE / source')
    axes[2].plot(x, [v['mid_delta_ratio'] for v in rows], 's-', label='Mid-change RMSE / source')
    axes[2].axhline(1.1, linestyle='--', color='gray', label='Relative price limit')
    axes[2].set_xticks(x, [str(v['index']) for v in rows], rotation=55)
    axes[2].set(ylabel='Training-window error ratio', ylim=(0, 1.2))
    axes[2].legend(fontsize=8)
    fig.suptitle('Training-target-assisted latent fitting; fixed native Decoder; NOT out-of-sample')
    fig.tight_layout()
    fig.savefig(output / 'per_window.png', dpi=160)
    plt.close(fig)
    text = f'<h1>自由代码训练诊断：每窗{step}次更新</h1><p>固定8个训练窗口、完整256分钟、每窗唯一8192维代码；所有模型参数不变。目标参与代码优化，不能当作Encoder推理或样本外结果。</p><p>召回改善{summary["recall_improved_windows"]}/8窗，精确率改善{summary["precision_improved_windows"]}/8窗，价格两项相对门槛通过{summary["price_guard_passed_windows"]}/8窗。最大窗口占真实大单事件{100*summary["largest_window_event_share"]:.2f}%，因此同时查看逐窗与汇总。</p><img src="per_window.png" style="max-width:100%"><p><a href="summary.json">逐窗结果与输入哈希</a> · <a href="../">诊断进度</a></p>'
    (output / 'index.html').write_text('<!doctype html><meta charset="utf-8"><style>' + STYLE + '</style><main>' + text + '<p>' + html.escape(summary['interpretation']) + '</p></main>')
    record(root.parent, 'native_latent_fit_analysis', root=root.name, step=step, summary=summary, goal_candidate=False)
    print(output, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    parser.add_argument('--step', type=int, required=True)
    args = parser.parse_args()
    analyze(args.root.resolve(), args.step)
