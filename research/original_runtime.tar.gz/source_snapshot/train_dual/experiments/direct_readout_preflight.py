"""Full2048 GPU functional checks after the owned512-step pilot releases GPU2."""
import argparse
import gc
import os
from pathlib import Path
import time

import numpy as np
import torch

from model.layers.direct_quantity_readout import FrameQuantityLogitMLP
from train_dual.experiments import local_hint_run as shared
from train_dual.experiments.branch_precision_run import criterion
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read
from train_dual.experiments.price_safe_readout import file_hash
from train_dual.experiments.region_task_run import gpu_free
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import freeze_sources, load_for_inference, seed_everything
from train_dual.util.direct_readout_training import restore_direct_readout_adam
from train_dual.util.phase_training import tensor_digest

MODULE = 'train_dual.experiments.direct_readout_preflight'


def pilot_released(parent, workers, proc=Path('/proc')):
    for lane, pid in workers.items():
        status = read(parent / lane / 'status.json', {})
        if status.get('state') == 'failed': raise RuntimeError('Owned pilot worker failed')
        try: args = (proc / str(pid) / 'cmdline').read_bytes().split(b'\0')
        except FileNotFoundError: args = []
        live = (b'train_dual.experiments.idle_aggregation_pilot' in args
                and str(parent).encode() in args and lane.encode() in args and b'--lane' in args)
        if live: return False
        if status.get('state') != 'complete' or status.get('step') != 512:
            raise RuntimeError('Missing pilot worker without completed512')
    return True


def prepare(goal):
    prep = goal / 'direct_readout_preparation_20261029'
    assert read(prep / 'preparation_audit.json')['state'] == 'passed_CPU_preparation_only'
    root = goal / 'direct_readout_full_gpu_preflight_20261029'
    root.mkdir(); (root / 'logs').mkdir()
    atomic_json(root / 'plan.json', dict(preparation=prep.name,
        released_parent='relative_aggregation_early_pilot_20261028', source_branch='round_010_branch_precision',
        workers=dict(control=47724, per_position=47725), source_sha256=read(prep / 'plan.json')['source_sha256'],
        scope='One fixed training window, full256frames/two2048level sides. Source native forward, '
              'two candidate native/shared-Z/fresh-decode checks, two disposable functional optimizer steps per activation. '
              '4functional updates,0production updates; no saved trained candidate and no Q2. '
              'This single-window check cannot replace subsequent full16 source replay or quality evaluation.'))
    atomic_json(root / 'status.json', dict(state='prepared_not_started'))
    freeze_sources(root / 'source_snapshot')
    project = Path(__file__).resolve().parents[2]
    remote = Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e') / root.relative_to(project)
    (root / 'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'
        + f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 CUDA_DEVICE_ORDER=PCI_BUS_ID CUDA_VISIBLE_DEVICES=2 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\n'
        + f'cd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m {MODULE} "{remote}" --run >> "{remote}/logs/run.log" 2>&1\n')
    return root


def frozen_audit(model, optimizer, source, names):
    state = model.state_dict(); current = optimizer.state_dict(); tensors = moments = 0
    assert current['param_groups'][:3] == source['optimizer']['param_groups']
    for name, value in source['model'].items():
        if name.startswith(('encoder.', 'price_decoder.')):
            torch.testing.assert_close(state[name].cpu(), value, rtol=0, atol=0); tensors += 1
    for index, name in zip(source['optimizer']['param_groups'][0]['params'], names):
        if not name.startswith(('encoder.', 'price_decoder.')): continue
        old, new = source['optimizer']['state'].get(index, {}), current['state'].get(index, {})
        assert old.keys() == new.keys()
        for key, value in old.items():
            if torch.is_tensor(value): torch.testing.assert_close(new[key].cpu(), value, rtol=0, atol=0)
            else: assert new[key] == value
            moments += 1
    assert all(p.grad is None for name, p in model.named_parameters() if name.startswith(('encoder.', 'price_decoder.')))
    return dict(passed=True, frozen_model_tensors=tensors, frozen_Adam_values=moments)


def run(root):
    p = read(root / 'plan.json'); goal = root.parent
    parent = goal / p['released_parent']; prep = goal / p['preparation']; branch = goal / p['source_branch']
    assert pilot_released(parent, p['workers']), 'Wait for both exact512workers to finish and exit'
    assert read(branch / 'status.json')['state'] == 'running', 'Formal main queue retains priority after parent ends'
    assert os.environ.get('CUDA_VISIBLE_DEVICES') == '2' and gpu_free().get(2, 0) >= 47000
    assert file_hash(prep / 'source.pt') == p['source_sha256']
    torch.set_num_threads(4); seed_everything(42); strict_precision(); started = time.monotonic()
    def status(phase): atomic_json(root / 'status.json', dict(state='running', phase=phase, pid=os.getpid()))
    status('training_window_and_teacher')
    data = dataset(parent, 'train'); index = int(np.load(parent / 'quantity_calibration_indices.npy')[0])
    raw = {key: value.unsqueeze(0) for key, value in data[index].items()}
    assert list(raw['data'].shape) == [1, 256, 2, 2048, 2]
    offset = int(data.base.starts[index]); assert np.all(np.diff(data.base.times[offset:offset + 256] // 60000000) == 1)
    teacher, teacher_norm = load_for_inference(parent / 'teacher.pt', 'cuda:0')
    teacher.eval().requires_grad_(False); digest = tensor_digest(teacher)
    teacher_target = shared.teacher_local(teacher, teacher_norm, raw).detach().cpu()
    assert tensor_digest(teacher) == digest
    del teacher, teacher_norm, data; gc.collect(); torch.cuda.empty_cache()
    status('source_native_forward')
    source_model, norm = load_for_inference(prep / 'source.pt', 'cuda:0')
    batch = norm.prepare(raw, 'cuda:0')
    with torch.inference_mode(): native = call(source_model, batch, False)
    expected = {key: native[key].cpu().clone() for key in ['mu', 'logvar', 'z', 'price_norm', 'volume', 'hint_local']}
    del native, source_model; gc.collect(); torch.cuda.empty_cache()
    before_cpu, before_cuda = torch.get_rng_state(), torch.cuda.get_rng_state_all()
    probe = FrameQuantityLogitMLP()
    assert torch.equal(before_cpu, torch.get_rng_state())
    assert all(torch.equal(a, b) for a, b in zip(before_cuda, torch.cuda.get_rng_state_all()))
    del probe
    source = torch.load(prep / 'source.pt', map_location='cpu', mmap=True, weights_only=False)
    original_names = read(branch / 'plan.json')['original_parameter_names']; results = {}
    for activation in ['identity', 'gelu']:
        status(activation + '_native_replay')
        model, _ = load_for_inference(prep / f'initial_{activation}.pt', 'cuda:0')
        for name in ['encoder', 'price_decoder']: model.get_submodule(name).requires_grad_(False).eval()
        optimizer, groups = restore_direct_readout_adam(model, source['optimizer'], original_names)
        assert len(groups) == 4 and all(q not in optimizer.state for q in model.direct_quantity_readout.parameters())
        received = []
        hooks = [d.register_forward_pre_hook(lambda m, args: received.append(args[0])) for d in [model.price_decoder, model.volume_decoder]]
        with torch.inference_mode(): native = call(model, batch, False)
        for hook in hooks: hook.remove()
        assert received[0] is received[1] is native['z']
        assert list(native['z'].shape) == [1, 64, 128] and list(native['volume'].shape) == [1, 256, 2, 2048]
        for key, value in expected.items(): torch.testing.assert_close(native[key].cpu(), value, rtol=0, atol=0)
        def no_encoder(*args): raise AssertionError('Fresh Z-only decode touched Encoder')
        hook = model.encoder.register_forward_pre_hook(no_encoder)
        with torch.inference_mode(): decoded = model.decode(native['z'], batch['mask'], batch['tick_norm'], batch['times'])
        hook.remove()
        for key in ['price_norm', 'volume', 'hint_local']: torch.testing.assert_close(decoded[key], native[key], rtol=0, atol=0)
        del native, decoded, received
        objective = criterion(branch, 'both_fp32'); target = teacher_target.to('cuda:0')
        gradients = []; durations = []; torch.cuda.reset_peak_memory_stats()
        for step in [1, 2]:
            status(activation + f'_disposable_optimizer_step{step}')
            model.train()
            for name in ['encoder', 'price_decoder']: model.get_submodule(name).eval()
            optimizer.zero_grad(set_to_none=True); torch.cuda.synchronize(); begin = time.monotonic()
            dtypes = {}
            def observe(name):
                def hook(module, args, output): dtypes[name] = str(output.dtype)
                return hook
            hooks = [module.register_forward_hook(observe(name)) for name, module in dict(
                encoder_mu=model.encoder.mu, price=model.price_decoder.gap,
                quantity=model.volume_decoder.quantity, direct_input=model.direct_quantity_readout.input_projection,
                direct_output=model.direct_quantity_readout.output_projection).items()]
            with torch.autocast('cuda', dtype=torch.bfloat16): output = call(model, batch, False)
            for hook in hooks: hook.remove()
            assert all(dtype == 'torch.float32' for dtype in dtypes.values())
            assert not output['z'].requires_grad and not output['price_norm'].requires_grad and output['volume'].requires_grad
            torch.testing.assert_close(output['price_norm'].detach().cpu(), expected['price_norm'], rtol=0, atol=0)
            values = objective(output, batch, teacher_local=target); values['loss'].backward()
            assert all(torch.isfinite(q.grad).all() for q in model.parameters() if q.grad is not None)
            first = float(model.direct_quantity_readout.input_projection.weight.grad.norm())
            last = float(model.direct_quantity_readout.output_projection.weight.grad.norm())
            assert last > 0 and (first == 0 if step == 1 else first > 0)
            norm = float(torch.nn.utils.clip_grad_norm_(model.parameters(), 1.))
            optimizer.step(); torch.cuda.synchronize(); durations.append(time.monotonic() - begin)
            gradients.append(dict(step=step, input_weight_gradient_L2=first, output_weight_gradient_L2=last,
                                  global_preclip_gradient_L2=norm, actual_dtypes=dtypes))
            del output, values
        audit = frozen_audit(model, optimizer, source, original_names)
        assert all(q in optimizer.state for q in model.direct_quantity_readout.parameters())
        results[activation] = dict(native_source_replay_exact=True, shared_single8192Z=True,
            fresh_Z_only_decode_exact=True, actual_input=[1, 256, 2, 2048, 2], actual_output=[1, 256, 2, 2048],
            private_step_gradients=gradients, frozen_state_audit=audit,
            max_reserved_gib=torch.cuda.max_memory_reserved() / 2 ** 30, two_step_seconds=durations,
            functional_optimizer_updates=2, production_optimizer_updates=0)
        atomic_json(root / 'partial_results.json', results)
        del model, optimizer, objective, target; gc.collect(); torch.cuda.empty_cache()
    assert file_hash(prep / 'source.pt') == p['source_sha256']
    result = dict(state='passed_full2048_functional_preflight', arms=results, training_index=index,
        continuous_one_minute_frames=True, added_layer_preserves_CPU_and_CUDA_RNG=True,
        elapsed_seconds=time.monotonic() - started, teacher_feature_extractions=1,
        student_forwards=7, extra_fresh_decoder_calls=2, functional_optimizer_updates=4,
        production_optimizer_updates=0, trained_weights_saved=False, independent_test_used=False,
        scope=p['scope'], next='Declare matched training protocol after original512 review; full16 native source replay remains required at actual training startup. Goal admission is still withheld pending that audit.')
    atomic_json(root / 'result.json', result); atomic_json(root / 'status.json', dict(state='complete', pid=os.getpid()))
    print(result, flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path); parser.add_argument('--prepare', action='store_true'); parser.add_argument('--run', action='store_true')
    args = parser.parse_args(); root = args.root.resolve()
    try:
        if args.prepare: print(prepare(root), flush=True)
        elif args.run: run(root)
        else: parser.error('Specify --prepare or --run')
    except BaseException as error:
        if not args.prepare: atomic_json(root / 'status.json', dict(state='failed', pid=os.getpid(), error=repr(error)))
        raise


if __name__ == '__main__': main()
