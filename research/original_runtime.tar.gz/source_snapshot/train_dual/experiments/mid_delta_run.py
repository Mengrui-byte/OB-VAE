"""End-to-end one-minute price-difference weight control after the FP study."""
import argparse
import html
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import numpy as np
import torch

from model.losses.recall_guard import RecallGuardBookLoss
from train_dual.experiments import local_hint_run as shared
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.goal_evaluate import assess_file
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read,fmt,STYLE
from train_dual.experiments.recall_goal_run import candidates,record,render as render_goal
from train_dual.experiments.region_task_run import gpu_free
from train_dual.util.checkpoint import atomic_save,freeze_sources,load_for_inference
from train_dual.util.phase_training import tensor_digest


ALPHAS={'delta1':1.,'delta4':4.,'delta16':16.,'delta64':64.}
LABELS={lane:f'分钟差分权重α={value:g}' for lane,value in ALPHAS.items()}
PARENT_LANES=('legacy','fixed_count','smooth','recall')


def violation_key(row):
    gaps=[.8/max(row['recall100'] or 0.,1e-12),.5/max(row['precision100'] or 0.,1e-12),
          row['price_rmse']/row['price_limit'],row['mid_delta_rmse']/row['mid_delta_limit'],row['quantity_rmse']/row['quantity_limit']]
    gaps=[max(1.,x) if math.isfinite(x) else math.inf for x in gaps]
    return max(gaps),sum(gaps),-(row['recall100'] or 0.),row['price_rmse']


def select_source(rows):
    common=set.intersection(*[{r['step'] for r in rows if r['lane']==lane} for lane in PARENT_LANES])
    if not common:raise ValueError('No endpoint shared by all four FP lanes')
    step=max(common);pool=[r for r in rows if r['step']==step]
    return min(pool,key=violation_key)


def predecessor_pids(goal,proc_root=Path('/proc')):
    target=str(goal/'fp_rule_after').encode();found=[]
    for f in proc_root.glob('[0-9]*/cmdline'):
        try:args=f.read_bytes().split(b'\0')
        except OSError:continue
        if b'train_dual.experiments.fp_rule_run' in args and target in args:found.append(int(f.parent.name))
    return found


def render(root):
    plan=read(root/'plan.json');status=read(root/'status.json',{})
    page=f'<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="30"><title>分钟差分权重单因素对照</title><style>{STYLE}</style><main><h1>完整模型训练：分钟差分权重1 / 4 / 16 / 64</h1><p>状态：{html.escape(status.get("state","prepared"))}。完整256分钟、双侧2048档、单Encoder、唯一64×128 Gaussian、价格与挂量共用Z，无Encoder跳接。Encoder和双Decoder全部训练。</p>'
    page+='<p>四组共用同一来源权重、Adam两组状态、数据与增强顺序、教师及公共损失系数；只改变mid水平＋α×分钟差分MSE中的α。α=1保留来源目标，数量/原价格/提示及所选误报规则均保持一致。不改上采样，不新增参数。每组2048次更新，检查点256/512/1024/2048，seed42。</p>'
    if 'labels' in plan:
        page+='<table><tr><th>方案</th><th>进度</th><th>检查点</th><th>召回</th><th>精确率</th><th>价格RMSE</th><th>分钟变化RMSE</th><th>挂量RMSE</th><th>门槛</th></tr>'
        for lane,label in plan['labels'].items():
            progress=read(root/lane/'progress.json',{})
            for step in [0,*plan['checkpoints']]:
                f=root/lane/f'step{step}_development.json'
                if not f.exists():continue
                v=assess_file(f,Path(plan['goal_root'])/'reference_evaluation.json')
                cells=[label,f'{progress.get("step",0)}/{plan["steps"]}',step,fmt(v['recall100']),fmt(v['precision100']),fmt(v['price_rmse']),fmt(v['mid_delta_rmse']),fmt(v['quantity_rmse']),v['pass']]
                page+='<tr>'+''.join('<td>'+html.escape(str(x))+'</td>' for x in cells)+'</tr>'
        page+='</table><p>共同来源：'+html.escape(str(plan['source_selection']))+'。来源可能未过完整门槛，原参考价格与召回验收标准不重置。</p>'
    page+='<p>之前116.3权重的小实验冻结Encoder且结果为负；本轮训练整个模型，不预设改善。两个训练窗口的CPU梯度诊断不用于拟合训练系数。Q1开发集已反复用于研究；出现合格神经候选优先冻结并独立确认，本队列不读取Q2，也不自动宣布目标完成。</p><p><a href="plan.json">协议与预算</a> · <a href="../">研究目标</a></p></main>'
    temporary=root/'index.tmp';temporary.write_text(page);temporary.replace(root/'index.html')


def prepare_queue(goal):
    proposal=read(goal/'mid_delta_proposal_v2.json');assert proposal['values']==list(ALPHAS.values()) and proposal['seed']==42
    proposal=dict(proposal);proposal.pop('state',None)
    root=goal/'mid_delta_after';root.mkdir();(root/'logs').mkdir()
    atomic_json(root/'plan.json',dict(goal_root=str(goal),parent='round_002_fp_rule',wait_seconds=13*3600,study=proposal,protocol_filename='mid_delta_proposal_v2.json',
        policy='Wait for complete FP cohort and its scheduling controller exit. Qualified native candidate has priority over new training. Otherwise select one largest-common-endpoint source by the recorded source policy.'))
    atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot');render(root)
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(Path(__file__).resolve().parents[2])
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 CUDA_DEVICE_ORDER=PCI_BUS_ID OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.mid_delta_run "{remote}" >> "{remote}/logs/controller.log" 2>&1\n')
    print(root,flush=True)


def prepare_cohort(queue,parent,selected):
    goal=queue.parent;root=goal/'round_003_mid_delta';root.mkdir();study=read(queue/'plan.json')['study'];old=read(parent/'plan.json')
    assert old['input_shape']==[1,256,2,2048,2] and old['latent_shape']==[1,64,128] and old['output_shape']==[1,256,2,2048]
    for name in ['data','logs','seen','unseen',*LABELS]:(root/name).mkdir()
    for split in ['seen','unseen']:
        for lane in LABELS:(root/split/lane).mkdir()
    for name in ['train_indices.npy','val_indices.npy','seen_indices.npy','unseen_indices.npy','calibration_indices.npy','plotly.min.js','teacher.pt']:os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz');os.link(selected['checkpoint'],root/'source.pt')
    payload=torch.load(root/'source.pt',map_location='cpu',weights_only=False);assert payload['epoch_boundary'] and not payload.get('frozen_module_hashes')
    model,_=load_for_inference(root/'source.pt','cpu');source_spec=old['lanes'][selected['lane']]
    assert source_spec['hint'] and source_spec['augmentation'] and source_spec['protect_mid'] and source_spec['use_tail']
    rule={k:source_spec[k] for k in ['fp_normalization','fp_error','fp_weight']}
    plan=dict(old);plan.update(experiment='Endtoend singlefactor one-minute mid-difference weight',labels=LABELS,
        lanes={lane:dict(hint=True,augmentation=True,protect_mid=True,use_tail=True,mid_delta_weight=alpha,**rule) for lane,alpha in ALPHAS.items()},
        source_FP_rule=rule,source_selection=selected,source=str(root/'source.pt'),source_steps=payload['source_steps']+payload['step'],
        steps=study['steps_per_lane'],checkpoints=study['checkpoints'],max_seconds=study['max_seconds_per_lane'],seed=42,
        initial_model_sha256=tensor_digest(model),gpu_workers=[[g,l] for g,l in zip([2,3,4,5],LABELS)],loss_variant='mid_delta_weight',goal_root=str(goal),
        frozen_modules=[],checkpoint_extras={},controls=study['controls'],
        predeclared_selection=study['source_policy'],additional_controls='Only mid_delta_weight varies. Every source FP rule, tail/mid/hint/base coefficient and architecture setting is common. No new coefficient fitting.',
        budget=f"Additional {study['steps_per_lane']} optimizer updates per lane; same source/data/seed/evaluation, each worker at most {study['max_seconds_per_lane']} seconds. Actual capped endpoints reported if reached.",
        primary='Original fixed-reference goal contract: exact100BTCrecall>80%, precision>=50%, price<=82.17456597783033, minuteDelta<=22.040599589131354, quantity<=2.3973941907786807. Native-only frozen-candidate independent confirmation required.',
        preview_descriptions={lane:f'完整256分钟、唯一8192神经Z，全部模型训练，仅分钟差分权重α={alpha:g}不同；固定Q1开发集已用于调参，非独立测试。' for lane,alpha in ALPHAS.items()})
    atomic_save(dict(format_version=1,model=payload['model'],unified_vae_config=payload['unified_vae_config'],local_hint_config=payload['local_hint_config'],config=payload['config'],step=0),root/'initial.pt')
    atomic_json(root/'plan.json',plan);atomic_json(root/'calibration.json',read(parent/'calibration.json'))
    training=dataset(root,'train');index=int(np.load(root/'train_indices.npy')[0]);raw=training[index];start=int(training.base.starts[index]);absolute=training.base.times[start:start+256]
    assert list(raw['data'].shape)==[256,2,2048,2] and len(absolute)==256 and np.all(np.diff(absolute//60_000_000)==1)
    atomic_json(root/'data_contract.json',dict(passed=True,raw_input=[1,*raw['data'].shape],consecutive_minute_buckets=True,first_training_index=index,
        first_utc=str(np.datetime64(int(absolute[0]),'us')),last_utc=str(np.datetime64(int(absolute[-1]),'us')),latent_and_full_output_runtime_checks_pending=True))
    for split in ['seen','unseen']:
        atomic_json(root/split/'plan.json',dict(plan,preview_descriptions={lane:'训练年代诊断，非独立测试；Encoder和双Decoder全部训练，固定同一数据。' for lane in LABELS}));os.link(root/'plotly.min.js',root/split/'plotly.min.js')
    atomic_json(root/'status.json',dict(state='prepared',source=selected));freeze_sources(root/'source_snapshot');render(root)
    return root


def criterion(root,lane,device='cuda:0'):
    plan=read(root/'plan.json');cal=read(root/'calibration.json')
    return RecallGuardBookLoss(plan['normalization']['quantity_scale'],mode='shape_mass',use_hint=True,
        hint_weight=cal['hint_weight'],hint_mean=cal['channel_mean'],hint_scale=cal['channel_scale'],
        use_tail=True,protect_mid=True,tail_weight=cal['tail_weight'],mid_weight=cal['mid_weight'],
        mid_delta_weight=plan['lanes'][lane]['mid_delta_weight'],add_wasserstein=False,add_multiscale=False,
        **plan['source_FP_rule'],**plan['objective']).to(device)


def audit_startup(root):
    rows={lane:read(root/lane/'step1_data_audit.json') for lane in LABELS}
    if not all(rows.values()):return False
    plan=read(root/'plan.json');cal=read(root/'calibration.json');base=rows['delta1']
    for lane,row in rows.items():
        assert row['training_indices']==base['training_indices'] and row['edits']==base['edits']
        for key in ['pre_guard_loss','tail_balanced','mid_level_mse','mid_delta_mse']:
            assert row['losses'][key]==base['losses'][key],(lane,key)
        expected=base['losses']['loss']+cal['mid_weight']*(plan['lanes'][lane]['mid_delta_weight']-1)*base['losses']['mid_delta_mse']
        assert math.isclose(row['losses']['loss'],expected,rel_tol=5e-6,abs_tol=5e-6)
        assert read(root/lane/'actual_shape_contract.json')['passed']
    atomic_json(root/'startup_control_audit.json',dict(passed=True,same_inputs_edits_base_tail_and_mid_components=True,only_declared_delta_weight_changes_total_loss=True))
    return True


def run_cohort(root):
    plan=read(root/'plan.json');children=[];started=time.monotonic();audited=False
    try:
        for gpu,lane in plan['gpu_workers']:
            env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),PYTHONPATH=str(root/'source_snapshot'))
            with (root/'logs'/f'{lane}.log').open('ab',buffering=0) as log:
                p=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.mid_delta_run',str(root),'--lane',lane],cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            children.append(p)
        atomic_json(root/'status.json',dict(state='running',pids=[p.pid for p in children]))
        while any(p.poll() is None for p in children):
            if time.monotonic()-started>plan['max_seconds']+1800:raise TimeoutError('12hour training plus evaluation ceiling')
            if any(p.poll() not in [None,0] for p in children):raise RuntimeError('Owned delta worker failed')
            if not audited:audited=audit_startup(root)
            render(root);time.sleep(10)
        if any(p.returncode for p in children):raise RuntimeError('Owned delta worker failed')
        if not audited:audited=audit_startup(root)
        if not audited:raise RuntimeError('No verified first-step controls')
        atomic_json(root/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started));render(root)
    finally:
        for p in children:
            if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)


def candidate_ready(goal,queue,rows,lanes):
    common=set.intersection(*[{r['step'] for r in rows if r['lane']==lane} for lane in lanes])
    passing=[r for r in rows if r['step'] in common and r['pass']]
    if not passing:return False
    chosen=max(passing,key=lambda r:(r['recall100'],-r['price_rmse']))
    atomic_json(goal/'candidate_for_confirmation.json',chosen);atomic_json(goal/'status.json',dict(state='development_pass_requires_independent_confirmation',candidate=chosen))
    atomic_json(queue/'status.json',dict(state='not_run_candidate_for_confirmation'));render(queue);return True


def controller(queue):
    goal=queue.parent;config=read(queue/'plan.json');parent=goal/config['parent'];reference=goal/'reference_evaluation.json';started=time.monotonic()
    while True:
        state=read(parent/'status.json',{});live=predecessor_pids(goal)
        if state.get('state')=='failed':raise RuntimeError('FP predecessor failed; inspect before continuing')
        if state.get('state')=='complete' and not live:break
        if len(live)!=1:raise RuntimeError(f'Cannot verify unique FP controller: {live}')
        if time.monotonic()-started>config['wait_seconds']:raise TimeoutError('13hour predecessor wait ceiling')
        atomic_json(queue/'status.json',dict(state='verified_wait_parent',controller_pids=live,predecessor_state=state.get('state')));render(queue);time.sleep(20)
    rows=candidates(parent,reference)
    if candidate_ready(goal,queue,rows,PARENT_LANES):return
    selected=select_source(rows)
    while any(gpu_free().get(g,0)<47000 for g in [2,3,4,5]):
        if time.monotonic()-started>config['wait_seconds']:raise TimeoutError('Shared GPU availability wait ceiling')
        atomic_json(queue/'status.json',dict(state='verified_wait_GPU_release'));render(queue);time.sleep(10)
    root=prepare_cohort(queue,parent,selected);atomic_json(queue/'status.json',dict(state='running',wave=root.name));atomic_json(goal/'status.json',dict(state='running_mid_delta_controlled_cohort',wave=root.name));render(queue)
    record(goal,'mid_delta_cohort_started',root=root.name,source=selected,alphas=ALPHAS,additional_updates=read(root/'plan.json')['steps'])
    run_cohort(root)
    new=candidates(root,reference);old=read(goal/'candidates.json',{}).get('rows',[])
    for r in rows:r['experiment']=parent.name
    for r in new:r['experiment']=root.name
    old=[r for r in old if r.get('experiment') not in [parent.name,root.name]];atomic_json(goal/'candidates.json',dict(rows=old+rows+new))
    if not candidate_ready(goal,queue,new,LABELS):
        atomic_json(goal/'status.json',dict(state='cohort_complete_next_hypothesis_required',wave=root.name,goal_achieved=False))
        atomic_json(queue/'status.json',dict(state='complete',wave=root.name,goal_automatically_completed=False));render(queue)
    render_goal(goal)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--lane',choices=list(LABELS));args=p.parse_args();root=args.root.resolve()
    def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        if args.prepare:prepare_queue(root)
        elif args.lane:shared.worker(root,args.lane,objective_factory=criterion)
        else:controller(root)
    except BaseException as error:
        if not args.prepare:atomic_json((root/args.lane if args.lane else root)/'status.json',dict(state='failed',error=repr(error)))
        raise
