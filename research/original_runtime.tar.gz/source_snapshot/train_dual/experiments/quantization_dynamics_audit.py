"""Locate lost book dynamics using existing continuous/quantized branch controls."""

import argparse
from datetime import datetime
import hashlib
import html
import json
from pathlib import Path
import shutil


LABELS={'original':'连续Global+Local','global_only':'量化Global，保留连续Local',
        'local_only':'量化Local，保留连续Global','quantized':'两路均量化'}


def main(root,lane):
    root=root.resolve();plan=json.loads((root/'plan.json').read_text());depth=plan['lanes'][lane]['levels']
    folder=root/'analysis'/('dynamics_audit_'+datetime.now().strftime('%Y%m%d_%H%M%S'));folder.mkdir()
    shutil.copy2(__file__,folder/'analysis_source.py')
    rows={};hashes={}
    keys=('quantity_btc','temporal_log_quantity_1_minutes',
          'temporal_shape_1_minutes_after_mid_removal','temporal_mid_1_minutes_usdt_per_minute')
    for mode,label in LABELS.items():
        source=root/lane/(('depth'+str(depth) if mode=='quantized' else mode)+'_evaluation.json')
        value=json.loads(source.read_text())['result'];hashes[str(source.relative_to(root))]=hashlib.sha256(source.read_bytes()).hexdigest()
        rows[mode]=dict(label=label,metrics={k:value['metrics'][k] for k in keys},
            quantity_prediction_max=value['prediction_max'],quantity_target_max=value['target_max'],
            tail_target_mean=value['tail_target_mean'],tail_prediction_mean=value['tail_prediction_mean'],
            large_recall=value['thresholds']['100']['recall'],
            diagnostic_only=mode in ('global_only','local_only'))
    latent=json.loads((root/lane/'latent_metrics.json').read_text());energy={}
    for split in ('train','development'):
        e=latent[split]['residual_energy'];energy[split]=dict(initial=e[0],final=e[depth],
            remaining_fraction=[e[depth][i]/e[0][i] for i in (0,1)])
    result=dict(lane=lane,depth=depth,rows=rows,latent_energy=energy,evaluation_source_sha256=hashes,
        new_model_training=False,new_data_inference=False,independent_test_evaluated=False,
        dynamics_definition='Differences of log1p(quantity) at the same side and sorted depth rank between consecutive minute frames, not identified orders or same-price order flow.',
        conclusions=dict(supported='Original source retains substantial minute-scale book changes. Holding Local continuous preserves quantity dynamics despite Global quantization; quantizing Local removes most of them.',
            known_design='Whole-window shared matrix codes fitted to raw latent distance, with source encoder and generator frozen; book-space reconstruction does not update the codebooks.',
            untested_mechanisms=['Latent centroid averaging may erase location-specific features.','Generator sensitivity to individual latent directions may differ from raw Euclidean distance.'],
            interpretation_limit='Weak class means for coarse summary features do not prove all dynamics are absent from continuous latents or even from every possible code combination.'))
    (folder/'audit.json').write_text(json.dumps(result,indent=2,ensure_ascii=False,allow_nan=False))
    body=[]
    for mode,row in rows.items():
        m=row['metrics']['temporal_log_quantity_1_minutes']
        cells=[row['label'],f"{row['metrics']['quantity_btc']['rmse']:.4f}",f"{m['correlation']:.6f}",
               f"{m['centered_amplitude_ratio']:.4f}",f"{row['quantity_prediction_max']:.2f}",f"{row['large_recall']*100:.1f}%"]
        body.append('<tr>'+''.join('<td>'+html.escape(x)+'</td>' for x in cells)+'</tr>')
    page='''<!doctype html><meta charset=utf-8><title>Local量化与盘口动力学</title><style>body{font:17px system-ui;max-width:1300px;margin:35px auto;line-height:1.8}table{border-collapse:collapse}td,th{padding:10px;border:1px solid #ccc}</style><h1>细节主要在哪里丢失？</h1><p>同128个2025Q1开发窗口，沿用已有严格FP32评估；未重训、未新增推理、未使用未来收益。单路对照保留另一支原始连续latent，只用于定位问题，不是完整压缩模型。</p><p>一分钟挂量变化指同侧、同排序档位的log1p数量差，不是相同价格/订单身份的逐笔流量。</p><table><thead><tr><th>模式</th><th>挂量RMSE BTC</th><th>分钟挂量变化相关</th><th>变化幅度比</th><th>预测最大挂量BTC</th><th>≥100BTC召回</th></tr></thead><tbody>'''+''.join(body)+'''</tbody></table><p>变化幅度比=预测变化的中心化标准差/真实变化的中心化标准差。原始目标最大挂量约900.14BTC；极端峰值即使在连续源模型中也有低估。Local量化后细节明显退化；这不等于所有潜在信息或所有连续表征均不存在。</p><p>当前码本只拟合整窗latent距离，没有通过生成器反馈订单簿重建误差。大矩阵被一个整窗索引选中，未给局部时空位置独立的码。潜在原型平均与解码器敏感度不匹配是候选机制，尚未做独立因果消融。</p><p><a href=small.html>小codebook分类</a> · <a href=./>逐档重建</a> · <a href=dynamics_audit.json>完整审计</a></p>'''
    (folder/'dynamics.html').write_text(page)
    for source,name in [('dynamics.html','dynamics.html'),('audit.json','dynamics_audit.json')]:
        target=root/'viewer'/name;temp=target.with_suffix(target.suffix+'.tmp');temp.symlink_to(folder/source);temp.replace(target)
    Path('/tmp/quantization_dynamics_audit_path').write_text(str(folder));print(folder)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--lane',default='k16_l8');a=p.parse_args();main(a.root,a.lane)
