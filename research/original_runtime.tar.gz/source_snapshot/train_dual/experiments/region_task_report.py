"""Separate small-sample training fit, synthetic diagnostics and development."""
import html
from train_dual.experiments.phase_detail_report import read,fmt,STYLE


def metric_row(label,step,result,link):
    m=result['metrics'];tail=result['thresholds']['100']
    values=[label,str(step),fmt(m['price_usdt']['rmse']),fmt(m['quantity_btc']['rmse']),
            fmt(m['temporal_log_quantity_1_minutes']['correlation']),fmt(tail['recall']),
            fmt(tail['precision']),str(tail['fp']),fmt(result['prediction_max']),
            f'<a href="{link}">完整中间价＋逐档线图</a>']
    return '<tr>'+''.join(f'<td>{v}</td>' for v in values)+'</tr>'


def render(root):
    plan=read(root/'plan.json');state=read(root/'status.json',{})
    parts=[f'<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="refresh" content="30"><title>区域瓶颈 × 监督任务</title><style>{STYLE}</style><main>',
        '<h1>8192维区域瓶颈 × 仅挂量/价量联合</h1>',
        f'<div class="note">状态：{html.escape(state.get("state","prepared"))}。完整256分钟，双侧各2048档，一个64×128 Gaussian，无Encoder跳接。等待上一轮预定终点后，使用GPU2–5。</div>',
        '<p>四组从头初始化，全部模块可训练。frame是上一轮每帧32维对照；region按64时间位置×2侧×8区域×8通道组织同一个8192维latent，保持区域到空间种子的对应关系。参数量分别为11735444与11609220，相差−1.08%；这是整套组织结构对比，不是仅reshape的对比。</p>',
        '<p>仅挂量组只移除显式价格及Top16价格监督，原数量Huber、log数量、Top16数量、分布KL和总量项完全相同；数量条件仍来自预测价格，允许数量梯度进入价格Decoder。这组不保证价格恢复能力。</p>',
        '<h2>进度</h2><div class="wrap"><table><tr><th>组</th><th>状态</th><th>阶段</th><th>更新</th><th>当前阶段窗口重复次数</th><th>训练目标</th><th>梯度范数</th></tr>']
    for lane,label in plan['labels'].items():
        p=read(root/lane/'progress.json',{});s=read(root/lane/'status.json',{})
        parts.append('<tr>'+''.join(f'<td>{html.escape(str(v))}</td>' for v in [label,s.get('state','等待'),p.get('phase','—'),f'{p.get("step",0)}/{plan["steps"]}',fmt(p.get('epochs_equivalent')),fmt(p.get('loss')),fmt(p.get('gradient_norm'))])+'</tr>')
    parts.append('</table></div>')
    header='<div class="wrap"><table><tr><th>组</th><th>步数</th><th>价格RMSE/USDT</th><th>挂量RMSE/BTC</th><th>分钟Δlog挂量相关</th><th>100BTC召回</th><th>精确率</th><th>误报</th><th>预测最大量</th><th>重建图</th></tr>'
    for phase,title,note in [
        ('moving','合成移动峰：4窗训练拟合','背景0.02BTC，每侧移动200/400BTC峰，每16帧出现/消失。训练目标参与拟合，不是实际市场或未见轨迹泛化。固定2048步后丢弃模型、Adam和随机状态，再恢复初始模型训练真实数据。'),
        ('real','真实订单簿：4窗训练拟合','四个固定2022–2024训练窗，256分钟完整输入。这是训练拟合诊断，不能解释为样本外重建或可部署结果。')]:
        parts.extend([f'<h2>{title}</h2><div class="note">{note}</div>',header])
        for step in [0,*plan['checkpoints']]:
            for lane,label in plan['labels'].items():
                value=read(root/phase/lane/f'step{step}_evaluation.json')
                if value:parts.append(metric_row(label,step,value['result'],f'{phase}/{lane}/step{step}_preview.html'))
        parts.append('</table></div>')
    parts.extend(['<h2>真实阶段：固定16窗开发指标</h2><p>仅在初始及2048步评价；2025Q1反复用于开发，2025Q2及2026未使用。开发结果与训练拟合分开。</p>',header])
    for step in [0,plan['steps']]:
        for lane,label in plan['labels'].items():
            value=read(root/'development'/lane/f'step{step}_evaluation.json')
            if value:parts.append(metric_row(label,step,value['result'],f'development/{lane}/step{step}_preview.html'))
    parts.append('</table></div>')
    replay=read(root/'reference/replay_audit.json',{})
    parts.append(f'<h2>旧高质量参考重放</h2><p>{html.escape(str(replay))}</p>')
    summary=read(root/'endpoint_summary.json')
    if summary:parts.append(f'<h2>预定终点汇总</h2><pre>{html.escape(__import__("json").dumps(summary,ensure_ascii=False,indent=2))}</pre>')
    parts.extend(['<p>优先检验同位置大单精确率/召回、原单位误差、分钟变化；联合模型价格误差超过匹配对照1.10倍时需明确报告取舍。小样本成功不证明泛化，失败不证明低维流形不存在。仅seed42，不报告跨种子方差。不会自动扩展到1024窗训练。</p>',
        '<p><a href="design.md">结构及实验说明</a> · <a href="plan.json">配置与预定判据</a> · <a href="data_contract.json">数据/形状</a> · <a href="source_snapshot/sha256.json">源码快照哈希</a> · <a href="../">全部实验</a></p>'])
    if state.get('error'):parts.append(f'<p>{html.escape(state["error"])}</p>')
    parts.append('</main></html>')
    temp=root/'report.tmp';temp.write_text(''.join(parts));temp.replace(root/'index.html')
