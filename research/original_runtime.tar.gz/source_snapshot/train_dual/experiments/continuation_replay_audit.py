"""Read-only replay of a continued control against its historical trajectory."""
import argparse
from pathlib import Path
import os
import signal
import time

import numpy as np
import torch

from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read
from train_dual.experiments.price_safe_readout import file_hash
from train_dual.experiments.recall_goal_run import record
from train_dual.util.checkpoint import freeze_sources

MODULE='train_dual.experiments.continuation_replay_audit'


def tree_difference(a,b,path='root'):
    """Exact value/dtype/shape comparison, including optimizer and RNG trees."""
    bad=[]
    def compare(x,y,where):
        if torch.is_tensor(x) or torch.is_tensor(y):
            if not (torch.is_tensor(x) and torch.is_tensor(y)) or x.shape!=y.shape or x.dtype!=y.dtype:
                bad.append(dict(path=where,kind='tensor_type_shape_dtype'));return
            if not torch.equal(x,y):
                bad.append(dict(path=where,kind='tensor_value',max_absolute_difference=float((x.double()-y.double()).abs().max())))
        elif isinstance(x,np.ndarray) or isinstance(y,np.ndarray):
            if not (isinstance(x,np.ndarray) and isinstance(y,np.ndarray)) or x.shape!=y.shape or x.dtype!=y.dtype or not np.array_equal(x,y):
                bad.append(dict(path=where,kind='array_value_shape_dtype'))
        elif isinstance(x,dict) or isinstance(y,dict):
            if not (isinstance(x,dict) and isinstance(y,dict)) or x.keys()!=y.keys():
                bad.append(dict(path=where,kind='mapping_keys'));return
            for key in x:compare(x[key],y[key],where+'.'+str(key))
        elif isinstance(x,(tuple,list)) or isinstance(y,(tuple,list)):
            if type(x) is not type(y) or len(x)!=len(y):bad.append(dict(path=where,kind='sequence_type_length'));return
            for i,(v,w) in enumerate(zip(x,y)):compare(v,w,f'{where}[{i}]')
        elif type(x) is not type(y) or x!=y:bad.append(dict(path=where,kind='scalar_value_type'))
    compare(a,b,path)
    return dict(exact=not bad,differences=len(bad),first_differences=bad[:20])


def control_live(root,pid,proc=Path('/proc')):
    try:args=(proc/str(pid)/'cmdline').read_bytes().split(b'\0')
    except FileNotFoundError:return False
    return b'train_dual.experiments.branch_precision_run' in args and str(root).encode() in args and b'--lane' in args and b'control' in args


def prepare(goal,pid):
    parent=goal/'round_010_branch_precision';plan=read(parent/'plan.json');assert read(parent/'startup_control_audit.json')['passed']
    assert plan['source_checkpoint_relative']=='round_008_auxiliary/control/step512.pt'
    assert plan['source_steps']==25088 and plan['sample'] is False and not plan['lanes']['control']['augmentation']
    reference=goal/'round_008_auxiliary/control/step1024.pt';evaluation=reference.with_name('step1024_development.json')
    root=goal/'branch_precision_continuation_replay_20261028';root.mkdir();(root/'logs').mkdir()
    p=dict(parent=parent.name,parent_pid=pid,lane='control',checkpoint_step=512,historical_checkpoint='round_008_auxiliary/control/step1024.pt',
        historical_checkpoint_sha256=file_hash(reference),historical_evaluation_sha256=file_hash(evaluation),source_checkpoint=plan['source_checkpoint_relative'],source_sha256=plan['source_sha256'],
        cumulative_updates=25600,wait_seconds=7200,
        scope='CPU read-only comparison of model buffers/parameters, all3Adam, sampler/augmentation RNG, exposure counts and fixed16 native metrics. No model forward, no training update, no new data.',
        rng_scope='Global RNG is recorded separately: the continued run adds an evaluation at cumulative25344 that the historical schedule omitted. No augmentation/dropout/sampling is enabled; exact model/Adam/sampler comparison remains required. Do not treat a global CPU-RNG difference alone as a failed training replay.')
    atomic_json(root/'plan.json',p);atomic_json(root/'status.json',dict(state='prepared_not_started'));freeze_sources(root/'source_snapshot')
    project=Path(__file__).resolve().parents[2];remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m {MODULE} "{remote}" --worker >> "{remote}/logs/run.log" 2>&1\n')
    atomic_json(root/'observer.json',dict(neural_forward_calls=0,optimizer_updates=0,independent_data_used=False));return root


def worker(root):
    torch.set_num_threads(2);p=read(root/'plan.json');goal=root.parent;parent=goal/p['parent'];folder=parent/p['lane']
    checkpoint=folder/f"step{p['checkpoint_step']}.pt";evaluation=checkpoint.with_name(checkpoint.stem+'_development.json');start=time.monotonic()
    while not (checkpoint.exists() and evaluation.exists()):
        if not control_live(parent,p['parent_pid']):raise RuntimeError('Exact control missing before requested checkpoint/evaluation')
        if read(parent/'status.json',{}).get('state')=='failed':raise RuntimeError('Parent training failed')
        if time.monotonic()-start>p['wait_seconds']:raise TimeoutError('Twohour observer wait ceiling')
        atomic_json(root/'status.json',dict(state='verified_wait_control_checkpoint',pid=os.getpid(),parent_pid=p['parent_pid']));time.sleep(20)
    reference=goal/p['historical_checkpoint'];refeval=reference.with_name(reference.stem+'_development.json')
    assert file_hash(reference)==p['historical_checkpoint_sha256'] and file_hash(refeval)==p['historical_evaluation_sha256']
    assert read(parent/'plan.json')['source_sha256']==p['source_sha256']
    a=torch.load(checkpoint,map_location='cpu',weights_only=False,mmap=True);b=torch.load(reference,map_location='cpu',weights_only=False,mmap=True)
    assert a['source_steps']+a['step']==b['source_steps']+b['step']==p['cumulative_updates']
    groups={name:tree_difference(a[name],b[name],name) for name in ['model','optimizer','sampler_generator_state','augmentation_generator_state','training_data']}
    groups['native_metrics']=tree_difference(read(evaluation)['result'],read(refeval)['result'],'native_metrics')
    rng=tree_difference(a.get('rng_state'),b.get('rng_state'),'global_rng')
    result=dict(state='comparison_complete',exact_replay=all(x['exact'] for x in groups.values()),groups=groups,global_rng_separate=rng,
        global_rng_scope=p['rng_scope'],actual_cumulative_updates=p['cumulative_updates'],checkpoint_relative=str(checkpoint.relative_to(goal)),
        actual_checkpoint_sha256=file_hash(checkpoint),historical_checkpoint=p['historical_checkpoint'],historical_checkpoint_sha256=p['historical_checkpoint_sha256'],
        actual_evaluation_sha256=file_hash(evaluation),historical_evaluation_sha256=p['historical_evaluation_sha256'],
        neural_forward_calls=0,optimizer_updates=0,independent_data_used=False,note='A deterministic continuation replay is not another seed or a new model improvement. Differences are evidence for investigation, never grounds to rewrite historical results or restart training.')
    atomic_json(root/'result.json',result);atomic_json(root/'status.json',dict(state='complete',pid=os.getpid(),exact_replay=result['exact_replay']))
    record(goal,'continued_control_trajectory_replay',wave=p['parent'],step=p['checkpoint_step'],exact_replay=result['exact_replay'],groups=groups,next='Continue matched precision experiment; investigate any required replay differences separately without altering live/frozen controls.')
    print(result,flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('root',type=Path);parser.add_argument('--prepare',action='store_true');parser.add_argument('--parent-pid',type=int);parser.add_argument('--worker',action='store_true');a=parser.parse_args();root=a.root.resolve()
    def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        if a.prepare:
            if not a.parent_pid:parser.error('--parent-pid required')
            print(prepare(root,a.parent_pid),flush=True)
        elif a.worker:worker(root)
        else:parser.error('Specify a mode')
    except BaseException as error:
        if not a.prepare:atomic_json(root/'status.json',dict(state='failed',pid=os.getpid(),error=repr(error)))
        raise


if __name__=='__main__':main()
