"""2x2quantity-distribution shape andtotal-mass loss control,8192bottleneck fixed."""
import argparse
from datetime import datetime
import json
import os
from pathlib import Path
from train_dual.experiments.long_worker import atomic_json
from train_dual.util.checkpoint import freeze_sources
from train_dual.experiments.loss_control_run import campaign,worker

LABELS={'baseline':'原损失匹配对照','shape_kl':'仅加挂量分布KL','mass':'仅加总挂量约束','shape_mass':'分布KL＋总量（交互对照）'}

def prepare(parent):
 parent=parent.resolve();project=Path(__file__).resolve().parents[2];root=project/'recons'/('distribution_control_'+datetime.now().strftime('%Y%m%d_%H%M%S'));root.mkdir();(root/'data').mkdir();(root/'logs').mkdir()
 for name in ['train_indices.npy','val_indices.npy','source_profiles.npz']:os.link(parent/name,root/name)
 os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz');os.link(parent/'ae/step2048.pt',root/'initial.pt');os.link(parent/'ae/step2048_evaluation.json',root/'initial_expected.json')
 previous=Path(Path('/tmp/loss_control_path').read_text().strip());diagnostic=Path(Path('/tmp/gradient_capacity_path').read_text().strip());plan=json.loads((parent/'plan.json').read_text())
 plan.update(experiment='2x2quantitydistribution andtotalmass losses;8192architecturefixed',parent=str(parent),pretraining_steps=2048,wait_for_relative=str(previous.relative_to(project)),wait_for_relatives=[str(p.relative_to(project)) for p in [previous,diagnostic]],
  lanes={k:dict(mode=k) for k in LABELS},labels=LABELS,default_variant='baseline',viewer_default_model=2,viewer_route='distribution_control',steps=512,checkpoints=[32,128,256,512],max_seconds=7200,queue_max_seconds=21600,beta=0.,sample=False,
  objective=dict(price_weight=1.,quantity_weight=1.,log_weight=1.,pair_weight=.25,topk=16,shape_weight=1.,mass_weight=1.),
  control_contract=dict(fixed=['sameAE2048weights andAdamWmoments','same8192latent andnearestupsampling','sameprice andbasequantitylosses','same64trainingindices and16developmentindices','same8seen trainingdiagnostics','seed42,batch1accum4,AdamW1e-4,clip1','512additionalupdates,declaredcheckpoints','BF16trainingFP32evaluation,TF32off'],
   factors=['AddKLbetween true andpredicted per-frame-side normalizedquantity distributions','AddHuber log1p totalquantity error per-frame-side'],
   factorial='Baseline,shapeonly,massonly,both. Combinedcase is aninteraction control, not attributed to onefactor.',
   weights='shape1,mass1 fixed before newresults; no validation-based coefficient fitting.',
   shape='p=q/sum_levels(q),phat=(qhat/q0+1e-6*mask)/sum_levels(qhat/q0+1e-6*mask). KL(p||phat) sum over levels,mean over valid positive-target-mass sides. Zero-target-mass side excluded only fromKL.',
   mass='Huber(log1p(sum_levels(qhat/q0))-log1p(sum_levels(q/q0))),mean over valid frame-sides.',
   interpretation='Distributionterm constrains allocation, mass constrains scale. Neither guarantees peak localization; same-indexprecision/recall, falsepositives andtemporal dynamics must be evaluated.'),
  initialization='SameAE2048weights+restoredAdamWmoments for all4; shared2048pretraining cost. Restart sampler identicallyseed42, not exact continuation of source data trajectory.',
  evidence='Gradientaudit found finite nonzero propagation andfinite-differenceagreement, littleoveralltaskconflict. MSE/head-only probes mainlyraisebackgroundandfalsepositives; distribution-vs-totalmass constraints are a falsifiable nexttest, not a provenfix.',
  selection='Fixed512additionalupdateendpoint andallintermediatecheckpoints; quantityRMSE,minutequantitychangecorrelation,large10/100precision&recall; priceRMSE<=1.10xmatchedbaseline guard.2025Q1isdevelopment; no independent-test or2026selection.',
  viewer_source_label='旧大latent参考·非匹配对照',viewer_description='8192维模型的挂量分布形状×总量2×2损失对照。四组同一AE2048权重和AdamW动量，固定最近邻上采样、价格损失、64训练窗/16开发窗、seed42及512次追加更新。基线、仅分布KL、仅总量Huber、两者组合。2025Q1是重复使用的开发期，2026和独立测试未参与。',viewer_step_note='追加步数；共同AE2048起点，8192瓶颈与结构固定。')
 atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='queued',waiting_for=plan['wait_for_relatives']));freeze_sources(root/'source_snapshot')
 remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
 (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.distribution_control_run "{remote}"\n')
 Path('/tmp/distribution_control_path').write_text(str(root));print(root,flush=True)

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--lane');a=p.parse_args()
 if a.prepare:prepare(a.root)
 elif a.lane:worker(a.root,a.lane)
 else:campaign(a.root)
