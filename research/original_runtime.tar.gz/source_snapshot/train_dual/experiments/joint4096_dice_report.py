"""Compare quantity Dice with the matched original4096decoder adaptation."""
import argparse
import csv
from dataclasses import asdict
import hashlib
import json
from pathlib import Path

import torch

from model.losses.dual import DualLossConfig
from model.losses.quantity_dice import DiceOrderBookLoss


def main(root):
    read=lambda p:json.loads(p.read_text());plan=read(root/'plan.json');parent=Path(plan['comparison_parent']);baseline=read(parent/'comparison.json')
    lane=root/'compressed4096';dice=read(lane/'final_evaluation.json');initial=read(lane/'initial_evaluation.json')
    objective=DiceOrderBookLoss(config=DualLossConfig(**plan['loss']),dice_weight=plan['dice_weight'],epsilon=plan['dice_epsilon'])
    effective=asdict(objective.price_config)
    for k,v in plan['loss'].items():
        if k not in ('volume_log','volume_linear','volume_tail'):assert effective[k]==v
    # Preserve all executed snapshots/checkpoints. Export a separate inference
    # artifact with the resolved Dice objective rather than inherited source loss.
    source=lane/'final.pt';saved=torch.load(source,map_location='cpu',weights_only=False)
    cfg=dict(saved['config'],loss=effective,quantity_objective='squared_dice',dice_weight=plan['dice_weight'],dice_epsilon=plan['dice_epsilon'],
        training_experiment=dict(seed=42,steps=128,batch_size=2,learning_rate=plan['learning_rate'],weight_decay=plan['weight_decay']))
    export={k:v for k,v in saved.items() if k!='optimizer'}
    export.update(format_version=2,config=cfg,artifact_kind='inference_weights',executed_checkpoint_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
        quantity_objective=dict(type='continuous_squared_dice',weight=plan['dice_weight'],epsilon=plan['dice_epsilon'],reduction=plan['dice_reduction']),
        provenance='Same trained neural tensors as final.pt; explicit objective metadata added in a separate inference export. Original checkpoint and frozen source preserved.')
    torch.save(export,lane/'final_with_objective.pt')
    data=dict(initial=initial,original=baseline['compressed4096']['final'],dice=dice,source=baseline['uncompressed']['initial'],
        uncompressed_adapted=baseline['uncompressed']['final'],plan=plan,price_config=effective,
        initial_verification=read(lane/'initial_reference_verification.json'),verification=read(lane/'verification.json'),history={},seen={},monitor={})
    for name,path in [('original',parent/'compressed4096'),('dice',lane)]:
        data['history'][name]=[json.loads(line) for line in (path/'progress.jsonl').read_text().splitlines() if json.loads(line).get('phase')=='decoder_adaptation']
        data['seen'][name]=[read(path/f'train_step{step}_16windows.json') for step in (0,32,64,128)]
        data['monitor'][name]=[read(path/f'development_step{step}_16windows.json') for step in (32,64)]
    rows=[]
    for label,dd in [('未压缩·原模型',data['source']),('4096维·共同初始Decoder',initial),('4096维·原挂量损失128步',data['original']),('4096维·Dice挂量损失128步',dice)]:
        m=dd['metrics'];t=dd['threshold100'];rows.append([label,m['price_usdt']['rmse'],m['quantity_btc']['rmse'],m['temporal_log_quantity_1_minutes']['correlation'],t['recall'],t['precision']])
    with (root/'comparison.csv').open('w') as f:
        w=csv.writer(f);w.writerow(['variant','price_rmse_usdt','quantity_rmse_btc','minute_log_quantity_correlation','recall100','precision100']);w.writerows(rows)
    (root/'comparison.json').write_text(json.dumps(data,ensure_ascii=False,indent=2))
    html=r'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Dice监督挂量 · 4096维Decoder适配对照</title><style>*{box-sizing:border-box}body{margin:0;background:#f3f7fa;color:#183345;font:15px/1.75 system-ui,-apple-system,"Microsoft YaHei",sans-serif}main{max-width:1200px;margin:auto;padding:32px 22px 60px}h1{font-size:31px;line-height:1.35}h2{font-size:22px;margin:0 0 12px}h3{font-size:17px}a{color:#146e98}.eyebrow{font-size:12px;letter-spacing:.1em;color:#087d77;font-weight:700}.lead{font-size:17px;max-width:960px}.badge{display:inline-block;font-size:12px;background:#e1f1f1;color:#08665f;padding:3px 10px;border-radius:6px;margin:4px 6px 4px 0}.warn{background:#fff1d7;color:#81561e}.note{font-size:13px;color:#536d7e}section{background:white;border:1px solid #dce7ee;padding:25px;border-radius:13px;margin:22px 0}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}.card{background:#f6fafc;border:1px solid #e0eaf0;border-radius:9px;padding:17px}.number{font-size:28px;color:#146e98;font-weight:750}.scroll{overflow-x:auto}table{width:100%;border-collapse:collapse;font-size:13px}th,td{white-space:nowrap;text-align:right;padding:9px 11px;border-bottom:1px solid #dce7ee}th:first-child,td:first-child{text-align:left}th{background:#f4f8fa}.target{background:#e6f5f3}.callout{border-left:4px solid #087d77;background:#edf8f5;padding:13px 17px;margin:17px 0}.warning{border-left-color:#bf8834;background:#fff8eb}.plots{display:grid;grid-template-columns:1fr 1fr;gap:20px}svg{width:100%;height:auto}code{background:#edf3f7;padding:2px 5px;border-radius:4px}pre{background:#f5f9fb;padding:17px;border-radius:8px;overflow:auto}nav{display:flex;gap:24px;flex-wrap:wrap;margin:24px 0}details{margin:17px 0}summary{font-weight:650;cursor:pointer}ul{padding-left:23px}button{font:inherit;padding:6px 10px;border:1px solid #c7d7e1;border-radius:6px;background:white;color:#183345;cursor:pointer}footer{font-size:12px;color:#536d7e;margin-top:25px}@media(max-width:740px){main{padding:20px 12px}section{padding:17px}.grid,.plots{grid-template-columns:1fr}h1{font-size:26px}}@media print{body{background:white}nav,button{display:none}main{padding:0}section{break-inside:avoid}}</style></head><body><main>
<header><div class="eyebrow">QUANTITY DICE · MATCHED DECODER ADAPTATION</div><h1>用Dice监督挂量，价格仍保留原损失</h1><p class="lead">只改变4096维模型的挂量监督：原log挂量误差与大单项，替换为连续squared Dice。编码器、PCA、Decoder初始化、训练批次、优化器和预算均保持一致。</p><span class="badge warn">历史16分钟架构</span><span class="badge">单连续latent [B,4096]</span><span class="badge">128步 × 每批2窗口 · seed42</span><span class="badge">无挂量二值化</span><p class="note">这是固定256次训练窗口访问的有界适配试验，尚非训练至收敛；2025 Q1为已反复使用的开发集，未使用独立测试期。</p></header>
<nav><a href="#result">重建结果</a><a href="#loss">Dice定义</a><a href="#curves">训练与监控</a><a href="#repro">验证与权重</a></nav>
<section id="result"><h2>同128个开发窗口的最终比较</h2><div class="grid" id="cards"></div><div class="callout" id="effect"></div><div class="scroll"><table><thead><tr><th>方案</th><th>价格RMSE / USDT ↓</th><th>挂量RMSE / BTC ↓</th><th>分钟挂量变化相关 ↑</th><th>≥100BTC召回 ↑</th><th>精确率 ↑</th></tr></thead><tbody id="rows"></tbody></table></div><p class="note">挂量变化为同排名档位的log1p数量差分，不是同价格或同订单的逐笔增撤单流。对照既包含匹配原损失组，也包含共同初始模型，避免把相对退化对照的改善误认为恢复原能力。</p><div class="callout warning">Dice的优化目标是每帧每侧挂量向量的相似性；它不直接等于BTC误差、大单召回或latent无损性。判断效果仍以这些实际重建指标为准。</div></section>
<section id="loss"><h2>本次Dice的精确定义</h2><pre>L_Dice = 1 − (2Σ(q̂·q) + ε) / (Σq̂² + Σq² + ε)
L_total = L_original_price + 1.0 × L_Dice
ε = 10⁻⁶；沿档位轴求和，再对有效的batch×分钟×买卖侧取平均。</pre><ul><li>q与q̂保留原连续挂量幅度，使用原训练quantity_scale；没有阈值化或占用标签。</li><li>分母使用平方和，适用于可大于1的BTC挂量；不使用会因挂量幅度而超过1的线性分母形式。</li><li>无效档位在计算前屏蔽。目标与预测均为空时Dice损失为0；有预测而目标为空时受到惩罚。</li><li>原价格、mid、spread、gap、空间斜率和时间价格项的权重保持一致；原volume_log、volume_linear、volume_tail的监督权重均置零。</li><li>只有价格Decoder、数量Decoder和原数量幅度修正头训练；编码器、融合模块和4096维PCA均冻结。</li></ul><p class="note">Dice与原损失的绝对数值不可直接比较。下面只对比相同物理指标，并单独展示Dice自己的优化曲线。</p></section>
<section id="curves"><h2>训练过程与同批样本监控</h2><div class="plots" id="plots"></div><h3>中途开发监控：同16个窗口</h3><div class="scroll"><table><thead><tr><th>损失组</th><th>步数</th><th>价格RMSE</th><th>挂量RMSE</th><th>挂量变化相关</th><th>≥100BTC召回</th></tr></thead><tbody id="monitorRows"></tbody></table></div><p class="note">32/64步监控为固定16窗口，最终主表为完整128窗口；两种口径不混成一条开发曲线。训练窗口曲线始终使用相同16个已见窗口，不代表开发集泛化。</p></section>
<section id="repro"><h2>控制变量与核查</h2><ul><li>原损失组与Dice组共享同一PCA基底与状态文件，完整训练顺序逐元素一致；每批2窗口、128次更新、AdamW3e−5、weight decay0.01、梯度裁剪1。</li><li>验证Dice组的初始网络权重与原损失组逐位相同，再精确重放3个已保存的完整订单簿样本后，复用共同128窗口初始评价。</li><li>Dice单元测试覆盖大于1的BTC幅度、幅度偏差、完美重建、空挂量、互斥位置、无效档位、梯度和价格监督保持一致；模型测试覆盖单Z解码与冻结编码器梯度。</li><li>本次4096维基底由8192个2022–2024训练窗口拟合，状态为float32。仍为16分钟源模型，不代表256分钟主线。</li><li>固定seed42，不报告跨种子方差；当前预算只访问256个训练窗口，结论限于这次有界适配与所选损失权重。</li></ul><ul id="checks"></ul><details><summary>下载权重与分析记录</summary><ul><li><a href="compressed4096/final_with_objective.pt">Dice适配后的推理权重（含明确损失元数据）</a> · <a href="joint_pca_basis.pt">共享固定PCA基底，约1.1GB</a></li><li><a href="comparison.csv">比较CSV</a> · <a href="comparison.json">完整比较与训练曲线JSON</a> · <a href="plan.json">实验计划及Dice约定</a></li><li><a href="compressed4096/initial_reference_verification.json">共同初始化与重放核查</a> · <a href="compressed4096/verification.json">冻结参数核查</a> · <a href="compressed4096/first_step_gradients.json">首步梯度</a></li><li><a href="source_snapshot/model/losses/quantity_dice.py">Dice模型损失源码</a> · <a href="source_snapshot/train_dual/experiments/joint4096_dice_run.py">实验入口快照</a> · <a href="source_snapshot/sha256.json">源码哈希</a></li><li><a href="../joint4096_decoder_20261026/">原损失Decoder适配完整报告</a></li></ul><p class="note">推理权重不重复保存固定PCA基底，需同时加载其codec_file引用。原始训练检查点与执行源码保留；单独推理导出补充了精确Dice目标元数据，神经网络张量未变。</p></details></section><footer>Joint4096 · Continuous squared Dice · 2026-10-26 <button onclick="window.print()">打印 / 保存PDF</button></footer></main>
<script id="data" type="application/json">__DATA__</script><script>
'use strict';const D=JSON.parse(document.getElementById('data').textContent),$=id=>document.getElementById(id),f=(v,n=3)=>Number(v).toFixed(n),pct=v=>v===null?'—':f(v*100,2)+'%';const metric=(d,key)=>key==='price'?d.metrics.price_usdt.rmse:key==='quantity'?d.metrics.quantity_btc.rmse:key==='dynamics'?d.metrics.temporal_log_quantity_1_minutes.correlation:d.threshold100.recall;
function row(name,d,target=false){return `<tr class="${target?'target':''}"><td>${name}</td><td>${f(metric(d,'price'))}</td><td>${f(metric(d,'quantity'),4)}</td><td>${f(metric(d,'dynamics'),4)}</td><td>${pct(d.threshold100.recall)}</td><td>${pct(d.threshold100.precision)}</td></tr>`}
$('cards').innerHTML=[['Dice组·挂量RMSE',f(metric(D.dice,'quantity'),4)+' BTC'],['Dice组·大单召回',pct(D.dice.threshold100.recall)],['Dice组·价格RMSE',f(metric(D.dice,'price'))+' USDT']].map(([a,b])=>`<article class="card"><div class="note">${a}</div><div class="number">${b}</div></article>`).join('');$('rows').innerHTML=row('未压缩·原模型',D.source)+row('4096维·共同初始Decoder',D.initial)+row('4096维·原挂量损失128步',D.original)+row('4096维·Dice128步',D.dice,true);$('effect').textContent=`相同128步后，原挂量损失组与Dice组的挂量RMSE分别为${f(metric(D.original,'quantity'),4)}与${f(metric(D.dice,'quantity'),4)}BTC，大单召回分别为${pct(D.original.threshold100.recall)}与${pct(D.dice.threshold100.recall)}。共同初始挂量RMSE为${f(metric(D.initial,'quantity'),4)}BTC；同时检查价格变化，避免只看单一指标。`;
function chart(title,series){let W=500,H=230,L=55,R=15,T=20,B=34,all=series.flatMap(s=>s.values),xmax=Math.max(...all.map(p=>p[0]),1),lo=Math.min(0,...all.map(p=>p[1])),hi=Math.max(...all.map(p=>p[1]))*1.1||1,x=v=>L+v/xmax*(W-L-R),y=v=>H-B-(v-lo)/(hi-lo)*(H-T-B);return `<div><h3>${title}</h3><svg role="img" aria-label="${title}" viewBox="0 0 ${W} ${H}">${Array.from({length:5},(_,i)=>{let v=lo+(hi-lo)*i/4;return `<line x1="${L}" x2="${W-R}" y1="${y(v)}" y2="${y(v)}" stroke="#e0e9ef"/><text x="${L-7}" y="${y(v)+4}" text-anchor="end" font-size="10">${f(v,2)}</text>`}).join('')}${series.map((s,i)=>`<polyline points="${s.values.map(p=>x(p[0])+','+y(p[1])).join(' ')}" fill="none" stroke="${i===0?'#146e98':'#c17c45'}" stroke-width="2.5"/><text x="${W-130}" y="${15+i*15}" font-size="11" fill="${i===0?'#146e98':'#c17c45'}">${s.label}</text>`).join('')}${[0,32,64,128].map(v=>`<text x="${x(v)}" y="${H-10}" font-size="11" text-anchor="middle">${v}</text>`).join('')}</svg></div>`}
const groups=[['dice','Dice'],['original','原挂量损失']];$('plots').innerHTML=chart('Dice组自身的挂量Dice优化项',[{label:'quantity Dice',values:D.history.dice.filter(v=>v.quantity_dice!==null).map(v=>[v.step,v.quantity_dice])}])+chart('同16个已见训练窗·挂量RMSE',groups.map(([k,label])=>({label,values:D.seen[k].map(v=>[v.step,metric(v,'quantity')])})))+chart('同16个已见训练窗·价格RMSE',groups.map(([k,label])=>({label,values:D.seen[k].map(v=>[v.step,metric(v,'price')])})))+chart('同16个已见训练窗·大单召回',groups.map(([k,label])=>({label,values:D.seen[k].map(v=>[v.step,v.threshold100.recall||0])})));$('monitorRows').innerHTML=groups.flatMap(([k,label])=>D.monitor[k].map(v=>`<tr><td>${label}</td><td>${v.step}</td><td>${f(metric(v,'price'))}</td><td>${f(metric(v,'quantity'),4)}</td><td>${f(metric(v,'dynamics'),4)}</td><td>${pct(v.threshold100.recall)}</td></tr>`)).join('');$('checks').innerHTML=`<li>${D.initial_verification.neural_weights_exact?'✓':'未通过'} 共同初始权重精确一致。</li><li>${D.initial_verification.same_training_order?'✓':'未通过'} 批次顺序一致。</li><li>${D.initial_verification.three_saved_reconstructions_exact?'✓':'未通过'} 三个完整重建样本精确重放。</li><li>${D.verification.encoder_and_fusion_bitwise_unchanged?'✓':'未通过'} 编码器与融合模块逐位未变，实际完成${D.verification.steps}步。</li>`;
</script></body></html>'''
    (root/'index.html').write_text(html.replace('__DATA__',json.dumps(data,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c')))
    report=dict(url='http://172.16.30.28:8875/recons/'+root.name+'/',live_url_verified=False)
    (root/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(report)
    for row in rows:print(row)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);main(p.parse_args().root)
