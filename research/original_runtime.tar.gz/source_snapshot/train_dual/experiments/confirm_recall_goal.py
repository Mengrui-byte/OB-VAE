"""Freeze one eligible neural candidate; replay development before reserved Q2."""
import argparse
import hashlib
import html
import json
import math
import os
from pathlib import Path

import numpy as np
import torch

from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.goal_evaluate import assess_file,evaluate_result
from train_dual.experiments.local_quant_reconstruction import CacheWindows
from train_dual.experiments.long_worker import atomic_json,evaluate
from train_dual.experiments.phase_detail_report import read
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import freeze_sources,load_for_inference


def file_hash(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(4*1024*1024),b''):digest.update(block)
    return digest.hexdigest()


def admit_neural_payload(payload):
    """A codec can pass metrics without satisfying the learned-model task."""
    if 'direct_readout_config' in payload:
        raise ValueError('Direct quantity readout requires a full2048 GPU architecture audit before goal admission')
    if 'branch_precision_config' in payload:
        policy=payload['branch_precision_config']
        if not isinstance(policy,dict) or set(policy)!=set(['encoder_fp32','decoders_fp32']) or any(type(v) is not bool for v in policy.values()):
            raise ValueError('Need two explicit audited branch precision switches')
        layer_policy=payload.get('precision_policy_config',{})
        if isinstance(layer_policy,dict) and any(layer_policy.values()):raise ValueError('Mixed layer and branch precision policies are not admitted')
        config=payload.get('regional_phase_config',{})
        if any(config.get(k,False) for k in ['use_shape','use_mass']):raise ValueError('External phase readout precision needs an audit')
    if 'precision_policy_config' in payload:
        policy=payload['precision_policy_config']
        if not isinstance(policy,dict) or set(policy)!=set(['encoder_input_fp32','quantity_head_fp32']) or any(type(v) is not bool for v in policy.values()):
            raise ValueError('Need two explicit audited sensitive-layer precision switches')
    forbidden=['sparse_address_config','window_matrix_config','global_local_merge_config',
               'region_grid_config','gradient_route_config','peak_aux_config','query_decoder_config']
    if any(k in payload for k in forbidden):raise ValueError('Candidate requires a separate model-class audit; engineered codecs cannot satisfy the neural goal')
    if payload.get('format_version')!=1 or payload.get('unified_vae_config',{}).get('levels')!=2048:
        raise ValueError('Need the full 2048-level format1 model')
    config=payload.get('quantity_context_config',payload.get('fine_phase_config',payload.get('paired_logit_config',payload.get('logit_readout_config',payload.get('regional_phase_config',payload.get('local_phase_config',payload.get('shape_mass_config',payload.get('local_hint_config'))))))))
    if config is None or config.get('layout')!='frame1':raise ValueError('Unsupported candidate family; audit before extending this admission rule')
    if 'quantity_context_config' in payload:
        if any(k in payload for k in ['fine_phase_config','paired_logit_config','logit_readout_config','regional_phase_config','local_phase_config','shape_mass_config']):
            raise ValueError('Unaudited quantity context extension combination')
        if type(config.get('context_frames')) is not int or config['context_frames'] not in [0,5,17,256]:
            raise ValueError('Explicit audited quantity context span required')
        return 'quantity_context'
    if 'fine_phase_config' in payload:
        if any(k in payload for k in ['paired_logit_config','logit_readout_config','regional_phase_config','local_phase_config','shape_mass_config']):
            raise ValueError('Unaudited fine Encoder/Decoder extension combination')
        if type(config.get('fine_enabled')) is not bool or config.get('fine_transform') not in ['linear','log1p']:
            raise ValueError('Explicit fine Encoder feature switches required')
        if type(config.get('fine_hidden')) is not int or config['fine_hidden']!=256:
            raise ValueError('Only the audited256hidden fine Encoder is admitted')
        return 'fine_phase'
    if 'paired_logit_config' in payload:
        if type(config.get('phase_specific')) is not bool:raise ValueError('Explicit paired phase flag required')
        if config.get('readout_space','logit') not in ['logit','log_quantity']:raise ValueError('Unknown paired response space')
        return 'paired_logit'
    if 'logit_readout_config' in payload:
        if config.get('feature_source') not in ['seed','frame']:raise ValueError('Unknown logit readout source')
        return 'logit_readout'
    if 'regional_phase_config' in payload or 'local_phase_config' in payload:
        if any(type(config.get(name)) is not bool for name in ['use_shape','use_mass']):
            raise ValueError('Local phase switches must be explicitly serialized')
        if 'regional_phase_config' in payload and config.get('readout_kernel','einsum') not in ['einsum','linear']:
            raise ValueError('Unknown regional readout kernel')
        return 'regional_phase' if 'regional_phase_config' in payload else 'local_phase'
    return 'shape_mass' if 'shape_mass_config' in payload else 'local_hint'


def require_development_pass(candidate,reference):
    checkpoint=Path(candidate['checkpoint']);evaluation=Path(candidate['evaluation'])
    if evaluation.resolve()!=(checkpoint.parent/(checkpoint.stem+'_development.json')).resolve():
        raise ValueError('Evaluation must belong to this checkpoint')
    verdict=assess_file(evaluation,reference)
    if not verdict['pass']:raise ValueError('Candidate has not passed the fixed development gates; reserved data stays unread')
    return verdict


def require_matching_replay(actual,published):
    if actual['windows']!=published['windows'] or actual['window_indices']!=published['window_indices']:
        raise ValueError('Development replay used different windows')
    for key in ['price_usdt','quantity_btc','temporal_mid_1_minutes_usdt_per_minute']:
        if not math.isclose(actual['metrics'][key]['rmse'],published['metrics'][key]['rmse'],rel_tol=1e-7,abs_tol=1e-8):
            raise ValueError(f'Development replay mismatch: {key}')
    for key in ['tp','fp','fn']:
        if actual['thresholds']['100'][key]!=published['thresholds']['100'][key]:raise ValueError(f'Large-order replay mismatch: {key}')


def reserve_once(root,reservation):
    path=root/'reserved_data_consumed.json'
    try:
        with path.open('x') as f:json.dump(reservation,f,indent=2)
        return False
    except FileExistsError:
        if read(path)!=reservation:raise ValueError('Reserved quarter was consumed by a different frozen comparison')
        return True # Resume the same frozen comparison, never a new candidate.


def prepare(goal):
    candidate=read(goal/'candidate_for_confirmation.json')
    if not candidate:raise ValueError('No eligible frozen candidate yet; no confirmation data read')
    verdict=require_development_pass(candidate,goal/'reference_evaluation.json')
    source=Path(candidate['checkpoint']).resolve();experiment=source.parent.parent;snapshot=experiment/'source_snapshot'
    payload=torch.load(source,map_location='cpu',weights_only=False);family=admit_neural_payload(payload)
    hashes=payload['source_hashes']
    for name,digest in hashes.items():
        if file_hash(snapshot/name)!=digest:raise ValueError(f'Candidate source snapshot mismatch: {name}')
    parent_plan=read(experiment/'plan.json')
    if parent_plan['train']!=['2022-01-01','2025-01-01'] or parent_plan['development']!=['2025-01-01','2025-04-01']:
        raise ValueError('Unexpected training/development split; audit required before reserved evaluation')
    root=goal/'confirmation';root.mkdir() # Never overwrite/reuse a consumed confirmation.
    for name in ['data','development_replay','logs','candidate','reference']:(root/name).mkdir()
    (root/'development_replay/data').mkdir()
    for folder in [root,root/'development_replay']:
        os.link(experiment/'data/BTCUSDT.npz',folder/'data/BTCUSDT.npz')
    for src,name in [(source,'candidate.pt'),(goal/'reference_model.pt','reference.pt'),(experiment/'val_indices.npy','development_indices.npy')]:os.link(src,root/name)
    os.link(experiment/'plotly.min.js',root/'plotly.min.js')
    plan=dict(parent_plan);plan.update(development=['2025-04-01','2025-07-01'],confirmation_windows=32,
        goal_root=str(goal),candidate=candidate,candidate_family=family,candidate_sha256=file_hash(source),reference_sha256=file_hash(root/'reference.pt'),candidate_source_snapshot=str(snapshot),
        confirmation_role='Onefrozencandidate,32preselectedfullQ2windows;notraining/nohyperparameterselection. Failedconfirmationmustnotbereusedasfreshholdout.',development_verdict=verdict,
        labels=dict(candidate='冻结候选',reference='冻结原参考'),preview_descriptions={lane:'预先固定的32个2025Q2独立确认窗口中的均匀抽样；完整256分钟。只比较一个冻结候选和原参考，未用于训练或本轮开发选型。' for lane in ['candidate','reference']})
    atomic_json(root/'plan.json',plan);atomic_json(root/'development_replay/plan.json',parent_plan)
    atomic_json(root/'status.json',dict(state='prepared_no_reserved_data_read'))
    freeze_sources(root/'driver_source_snapshot')
    # Use the candidate's exact architecture and evaluator, plus this external
    # driver. A later working-tree refactor cannot silently change its outputs.
    driver=root/'driver_source_snapshot/train_dual/experiments/confirm_recall_goal.py'
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{snapshot}" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\ncd "{snapshot}"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u "{driver}" "{root}" --worker\n')
    print(root,flush=True)


def architecture_audit(root,model,norm,data):
    raw={k:v.unsqueeze(0) for k,v in data[0].items()};batch=norm.prepare(raw,'cuda:0');seen=[]
    hooks=[d.register_forward_pre_hook(lambda m,a:seen.append(a[0])) for d in [model.price_decoder,model.volume_decoder]]
    model.eval()
    with torch.inference_mode():out=call(model,batch,False)
    for hook in hooks:hook.remove()
    if list(raw['data'].shape)!=[1,256,2,2048,2]:raise AssertionError('Incomplete input')
    for key in ['mu','logvar','z']:
        if list(out[key].shape)!=[1,64,128] or not bool(torch.isfinite(out[key]).all()):raise AssertionError(f'Invalid posterior {key}')
    assert seen[0] is seen[1] and seen[0] is out['z']
    torch.testing.assert_close(out['z'],out['mu'],rtol=0,atol=0)
    fresh,_=load_for_inference(root/'candidate.pt','cuda:0');fresh.eval()
    def forbid_encode(module,args):raise AssertionError('Decode called Encoder')
    hook=fresh.encoder.register_forward_pre_hook(forbid_encode)
    with torch.inference_mode():replay=fresh.decode(out['z'],batch['mask'],batch['tick_norm'],batch['times'])
    hook.remove()
    for key in ['volume','price_norm']:
        assert list(out[key].shape)==[1,256,2,2048]
        torch.testing.assert_close(out[key],replay[key],rtol=0,atol=0)
    mask=batch['mask'];q=out['volume'];p=out['price_norm'];adjacent=mask[...,1:]&mask[...,:-1]
    assert bool(torch.isfinite(q).all() and torch.isfinite(p).all() and (q>=0).all())
    assert bool((q[~mask]==0).all())
    assert bool(((p[...,1:]-p[...,:-1])*p.new_tensor([-1,1])[None,None,:,None])[adjacent].gt(0).all())
    assert bool((p[:,:,0,0]<p[:,:,1,0]).all())
    atomic_json(root/'architecture_audit.json',dict(passed=True,model_class=type(model).__module__+'.'+type(model).__name__,input=[1,256,2,2048,2],posterior=[1,64,128],latent_scalars=8192,shared_z_object=True,deterministic_z_is_mu=True,fresh_model_decode_without_encoder_exact=True,price_ordered=True,quantity_nonnegative=True,teacher_required=False,scope='FullsizeGPUforwardandfreshinstanceZ-onlydecodeonknown developmentinput;notaconfirmationscore.'))


def worker(root):
    torch.set_num_threads(4);strict_precision();plan=read(root/'plan.json');goal=Path(plan['goal_root'])
    numeric=torch.load(root/'candidate.pt',map_location='cpu',weights_only=False).get('inference_numeric_policy')
    if numeric is not None:
        if set(numeric)!={'cudnn_deterministic','cudnn_benchmark','tf32'} or type(numeric['cudnn_deterministic']) is not bool or numeric['cudnn_benchmark'] is not False or numeric['tf32'] is not False:raise ValueError('Unsupported inference numeric policy')
        torch.backends.cudnn.deterministic=numeric['cudnn_deterministic'];torch.backends.cudnn.benchmark=False
    assert file_hash(root/'candidate.pt')==plan['candidate_sha256'] and file_hash(root/'reference.pt')==plan['reference_sha256']
    for name,digest in torch.load(root/'candidate.pt',map_location='cpu',weights_only=False)['source_hashes'].items():
        if file_hash(Path(plan['candidate_source_snapshot'])/name)!=digest:raise ValueError(f'Frozen source changed: {name}')
    atomic_json(root/'status.json',dict(state='architecture_and_development_replay',reserved_data_read=False))
    dev=CacheWindows(dataset(root/'development_replay','val'),np.load(root/'development_indices.npy'))
    model,norm=load_for_inference(root/'candidate.pt','cuda:0');architecture_audit(root,model,norm,dev)
    replay=evaluate(model,norm,dev,len(dev),'cuda:0');atomic_json(root/'development_replay/result.json',dict(result=replay))
    require_matching_replay(replay,read(plan['candidate']['evaluation'])['result'])
    verdict=evaluate_result(replay,read(goal/'reference_evaluation.json')['result'])
    if not verdict['pass_']:raise ValueError('Replayed candidate failed development; reserved data stays unread')
    baseline,bn=load_for_inference(root/'reference.pt','cuda:0')
    reference_replay=evaluate(baseline,bn,dev,len(dev),'cuda:0')
    atomic_json(root/'development_replay/reference_result.json',dict(result=reference_replay))
    require_matching_replay(reference_replay,read(goal/'reference_evaluation.json')['result'])
    del baseline;torch.cuda.empty_cache()
    # This exclusive marker is the boundary after which Q2 is consumed. Never
    # overwrite it to call another candidate an independent confirmation.
    reservation=dict(candidate_sha256=plan['candidate_sha256'],reference_sha256=plan['reference_sha256'],dates=plan['development'],windows=32,selection='Equallyspacedfullwindows,chosenwithoutlookingatvalues',consumed=True)
    reserve_once(root,reservation)
    original=dataset(root,'val');indices=np.unique(np.linspace(0,len(original)-1,32,dtype=np.int64))
    if len(indices)!=32:raise ValueError('Need exactly32 confirmation windows')
    np.save(root/'indices.npy',indices)
    times=[]
    for index in indices:
        begin=int(original.base.starts[int(index)]);t=original.base.times[begin:begin+256]
        assert len(t)==256 and (np.diff(t//60_000_000)==1).all()
        assert t[0]>=np.datetime64(plan['development'][0],'us').astype(np.int64) and t[-1]<np.datetime64(plan['development'][1],'us').astype(np.int64)
        times.append([int(t[0]),int(t[-1])])
    atomic_json(root/'selection.json',dict(indices=indices.tolist(),timestamps_us=times,dates=plan['development'],fixed_before_metrics=True))
    data=CacheWindows(original,indices)
    atomic_json(root/'status.json',dict(state='evaluating_frozen_candidate_q2',reserved_data_read=True))
    candidate=evaluate(model,norm,data,len(data),'cuda:0');atomic_json(root/'candidate_result.json',dict(result=candidate))
    from train_dual.experiments.time_logit_run import write_profiles
    from train_dual.experiments.region_task_run import safe_preview
    write_profiles(root/'candidate',0,model,norm,data,original);safe_preview(root,'candidate',0)
    del model;torch.cuda.empty_cache()
    baseline,bn=load_for_inference(root/'reference.pt','cuda:0');reference=evaluate(baseline,bn,data,len(data),'cuda:0')
    atomic_json(root/'reference_result.json',dict(result=reference))
    write_profiles(root/'reference',0,baseline,bn,data,original);safe_preview(root,'reference',0)
    del baseline;torch.cuda.empty_cache()
    verdict=evaluate_result(candidate,reference);verdict['pass']=verdict.pop('pass_')
    assert file_hash(root/'candidate.pt')==plan['candidate_sha256'] and file_hash(root/'reference.pt')==plan['reference_sha256']
    atomic_json(root/'verdict.json',dict(verdict,scope='Same32previouslyreserved2025Q2windows;onefrozencandidateandoriginalreference;requiresfinalrootauditbeforegoalcompletion'))
    atomic_json(root/'status.json',dict(state='complete',passed=verdict['pass'],goal_automatically_completed=False))
    text='<h1>冻结候选：2025Q2独立确认</h1><p>完整256分钟、每侧2048档、唯一8192神经Z。仅比较一个冻结候选与原参考模型；本季度已消费，后续不能重复声称为独立确认。</p>'
    text+='<pre>'+html.escape(json.dumps(verdict,ensure_ascii=False,indent=2))+'</pre><p><a href="architecture_audit.json">实际结构审计</a> · <a href="development_replay/result.json">开发重放</a> · <a href="selection.json">固定窗口</a> · <a href="candidate_result.json">候选</a> · <a href="reference_result.json">参考</a></p>'
    for lane in ['candidate','reference']:
        if (root/lane/'step0_preview.html').exists():text+=f'<p><a href="{lane}/step0_preview.html">{plan["labels"][lane]}：中间价曲线与逐档挂量线</a></p>'
    (root/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>独立确认</title>'+text)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--worker',action='store_true');args=p.parse_args();root=args.root.resolve()
    if args.worker:
        try:worker(root)
        except BaseException as error:
            atomic_json(root/'status.json',dict(state='failed',error=repr(error),reserved_data_consumed=(root/'reserved_data_consumed.json').exists()));raise
    else:prepare(root)
