"""CPU full-window identity/Adam audit for a future Encoder-only factor study."""
import argparse
import os
from pathlib import Path
import time

import numpy as np
import torch

from model.autoencoder.fine_phase_vae import FinePhaseOrderBookVAE
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read, STYLE
from train_dual.experiments.price_safe_readout import file_hash
from train_dual.experiments.recall_goal_run import record
from train_dual.experiments.unified_8192_run import call
from train_dual.util.checkpoint import freeze_sources, load_for_inference, atomic_save
from train_dual.util.hint_training import restore_fine_phase_adam
from train_dual.util.phase_training import tensor_digest


SWITCHES = dict(control_linear=(False,'linear'), linear=(True,'linear'), control_log=(False,'log1p'), log=(True,'log1p'))


def prepare(goal):
    root = goal / 'fine_phase_preflight'
    root.mkdir()
    (root/'logs').mkdir()
    (root/'data').mkdir()
    parent = goal/'round_004_local_phase'
    os.link(parent/'source.pt',root/'source.pt')
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    np.save(root/'train_indices.npy',np.load(parent/'train_indices.npy')[:1])
    plan = read(parent/'plan.json')
    plan.update(experiment='Future ordered fine-phase Encoder full-window CPU preflight',
        source_sha256=file_hash(root/'source.pt'), switches=SWITCHES,
        source_control='Same exact original round004/source.pt, never a selected trained shared/regional endpoint.',
        hypothesis='The original stride16 regional route and ordered reductions may lose fine quantity phase. Add a zero-output ordered raw/log quantity MLP INSIDE the existing Encoder mean; no Decoder/upsampling/loss change.',
        architecture='Each frame ordered side/rank4096 -> LayerNorm -> Linear4096x256 -> GELU -> zeroLinear256x32. Add to original256x32mean and reshape64x128. Same original logvar and sole Gaussian draw; both Decoders consume only that Z.',
        intended_control='2x2 fine route disabled/enabled x linear/log1p features, four arms same new1065248parameters and zero initial output, source weights/Adam/RNG, original1024windows/augmentation/teacher/loss and2048updates. Same-budget control must replay round004/control. No candidate train run until existing full shared/regional studies finish without eligible candidate.',
        scope='CPU implementation preflight only: no optimizer updates, no development or independent data, no proof of GPU backward or reconstruction benefit.')
    atomic_json(root/'plan.json',plan)
    atomic_json(root/'status.json',dict(state='prepared'))
    freeze_sources(root/'source_snapshot')
    print(root,flush=True)


def run(root):
    torch.set_num_threads(4)
    started=time.monotonic()
    plan=read(root/'plan.json')
    atomic_json(root/'status.json',dict(state='CPU_full_window_identity',pid=os.getpid()))
    assert file_hash(root/'source.pt')==plan['source_sha256']
    payload=torch.load(root/'source.pt',map_location='cpu',weights_only=False)
    original,norm=load_for_inference(root/'source.pt','cpu')
    original.eval()
    data=dataset(root,'train');index=int(np.load(root/'train_indices.npy')[0])
    raw={k:v.unsqueeze(0) for k,v in data[index].items()}
    start=int(data.base.starts[index]);times=data.base.times[start:start+256]
    assert list(raw['data'].shape)==[1,256,2,2048,2] and bool((np.diff(times//60_000_000)==1).all())
    batch=norm.prepare(raw,'cpu')
    with torch.no_grad():reference=call(original,batch,False)
    original_names=[n for n,p in original.named_parameters()]
    audits=[];common_hash=None
    for lane,(enabled,transform) in SWITCHES.items():
        config=dict(payload['local_hint_config'],fine_enabled=enabled,fine_transform=transform,fine_hidden=256)
        model=FinePhaseOrderBookVAE(**config,**payload['unified_vae_config']).eval()
        missing,extra=model.load_state_dict(payload['model'],strict=False)
        assert len(missing)==6 and all(n.startswith('encoder.fine_phase.') for n in missing) and not extra
        assert [n for n,p in model.named_parameters() if not n.startswith('encoder.fine_phase.')]==original_names
        digest=tensor_digest(model)
        common_hash=digest if common_hash is None else common_hash
        assert common_hash==digest
        for name,value in payload['model'].items():torch.testing.assert_close(model.state_dict()[name],value,rtol=0,atol=0)
        seen=[];hooks=[m.register_forward_pre_hook(lambda m,a:seen.append(a[0])) for m in [model.price_decoder,model.volume_decoder]]
        with torch.no_grad():out=call(model,batch,False)
        for hook in hooks:hook.remove()
        assert seen[0] is seen[1] and seen[0] is out['z']
        for key in ['mu','logvar','z']:
            assert list(out[key].shape)==[1,64,128]
        for key in ['mu','logvar','z','volume','price_norm']:
            torch.testing.assert_close(out[key],reference[key],rtol=0,atol=0)
        assert list(out['volume'].shape)==[1,256,2,2048]
        if lane=='log':
            optimizer=restore_fine_phase_adam(model,payload['optimizer'],plan['original_parameter_names'])
            saved=optimizer.state_dict()
            assert saved['param_groups'][:2]==payload['optimizer']['param_groups']
            for i,state in payload['optimizer']['state'].items():
                for key,value in state.items():
                    if torch.is_tensor(value):torch.testing.assert_close(value,saved['state'][i][key],rtol=0,atol=0)
                    else:assert value==saved['state'][i][key]
            assert all(p not in optimizer.state for p in model.encoder.fine_phase.parameters())
            # Check an actually nonzero new route, not only its zero identity.
            with torch.random.fork_rng(devices=[]),torch.no_grad():
                torch.manual_seed(42);model.encoder.fine_phase.output.weight.normal_(0,.001)
                changed=call(model,batch,False)
            assert not torch.equal(changed['mu'],reference['mu'])
            checkpoint=dict(format_version=1,model=model.state_dict(),fine_phase_config=config,
                local_hint_config=payload['local_hint_config'],unified_vae_config=payload['unified_vae_config'],config=payload['config'])
            atomic_save(checkpoint,root/'nonzero_route_replay.pt')
            fresh,_=load_for_inference(root/'nonzero_route_replay.pt','cpu');fresh.eval()
            def forbidden(*args):raise AssertionError('Fresh decode accessed Encoder')
            hook=fresh.encoder.register_forward_pre_hook(forbidden)
            with torch.no_grad():decoded=fresh.decode(changed['z'],batch['mask'],batch['tick_norm'],batch['times'])
            hook.remove()
            for key in ['volume','price_norm']:torch.testing.assert_close(decoded[key],changed[key],rtol=0,atol=0)
            added=sum(p.numel() for p in model.encoder.fine_phase.parameters())
            assert added==1065248
            del fresh,optimizer,checkpoint,changed,decoded
        audits.append(dict(lane=lane,source_outputs_exact=True,old_parameter_values_and_relative_order_exact=True,shared_Z_object=True))
        atomic_json(root/'progress.json',dict(lanes_completed=len(audits),total=4,elapsed_seconds=time.monotonic()-started))
        del model,out
    assert file_hash(root/'source.pt')==plan['source_sha256']
    atomic_json(root/'audit.json',dict(passed=True,raw_shape=[1,256,2,2048,2],posterior_shape=[1,64,128],output_shape=[1,256,2,2048],
        original_parameter_values_and_Adam_exact=True,new_Adam_state_empty=True,new_parameters=added,
        common_initial_state_hash=common_hash,source_controls=audits,fresh_nonzero_route_Z_only_decode_exact=True,
        optimizer_updates=0,scope=plan['scope'],independent_data_read=False))
    atomic_json(root/'status.json',dict(state='complete',pid=os.getpid(),elapsed_seconds=time.monotonic()-started))
    text='<h1>Encoder逐档数量残差路径：实现预检</h1><p>完整256分钟、唯一64×128Gaussian不变。新1065248模型参数位于Encoder内部，只修正现有均值；logvar和双Decoder不变。尚未进行模型训练或开发评估，不宣称重建改善。</p><p>CPU真实2048档4开关来源输出逐值重放，来源参数/相对顺序和原两组Adam完整保留；新组空。非零残差下，全新实例仍只用Z解码，禁止访问Encoder。相关GPU训练核验仍需执行。</p><p><a href="audit.json">实际审计</a> · <a href="plan.json">假设与控制协议</a></p>'
    (root/'index.html').write_text('<!doctype html><meta charset="utf-8"><style>'+STYLE+'</style><main>'+text+'</main>')
    record(root.parent,'fine_phase_Encoder_CPU_preflight',root=root.name,passed=True,new_parameters=added,optimizer_updates=0,goal_candidate=False,GPU_training_not_run=True)
    print(root,flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--worker',action='store_true');args=p.parse_args();root=args.root.resolve()
    try:
        if args.prepare:prepare(root)
        elif args.worker:run(root)
    except BaseException as error:
        if not args.prepare:atomic_json(root/'status.json',dict(state='failed',pid=os.getpid(),error=repr(error)))
        raise
