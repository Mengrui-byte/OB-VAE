"""Real-data factorial comparison, separated from discarded synthetic pilots."""
from pathlib import Path
import html
from train_dual.experiments.phase_detail_report import render as base_render,read,fmt,STYLE


def render(root):
    base_render(root);plan=read(root/'plan.json');rows=[]
    for lane,label in plan['labels'].items():
        reset=read(root/lane/'pilot_reset_audit.json',{})
        for step in [0,*plan['pilot']['checkpoints']]:
            value=read(root/'pilot'/lane/f'step{step}_evaluation.json')
            if not value:continue
            result=value['result'];m=result['metrics'];t=result['thresholds']['100']
            path=f'pilot/{lane}/step{step}_preview.html'
            link=f'<a href="{path}">合成训练拟合图</a>' if (root/path).exists() else '生成中'
            rows.append(f'<tr><td>{label}</td><td>{step}</td><td>{fmt(m["quantity_btc"]["rmse"])}</td><td>{fmt(t["recall"])}</td><td>{fmt(t["precision"])}</td><td>{t["fp"]}</td><td>{"已重置" if reset.get("passed") else "诊断中"}</td><td>{link}</td></tr>')
    table='<h2>独立移动峰诊断：权重不带入主训练</h2><div class="note">这些是4个训练价格模板上构造的合成挂量：背景0.02BTC，移动大单200/400BTC，每16分钟切换出现/消失。目标参与小样本拟合，不是实际市场的开发集或样本外结果。诊断后恢复初始模型并清空Adam状态，再开始真实训练。</div><div class="wrap"><table><tr><th>组</th><th>诊断更新</th><th>数量RMSE</th><th>≥100BTC召回</th><th>精确率</th><th>误报</th><th>恢复初始化</th><th>图</th></tr>'+''.join(rows)+'</table></div>'
    table+='<p>200/400BTC目标与100BTC评估阈值留有幅度余量，避免接近100BTC的良好预测仅因略低于阈值而被全部判漏。诊断只检查可拟合性；未见移动轨迹泛化需要另行验证。</p>'
    index=root/'index.html';page=index.read_text().replace('</main>',table+'<p><a href="design.md">完整结构、损失及实验说明</a> · <a href="startup_control_audit.json">启动核验</a></p></main>')
    temp=root/'time_logit_report.tmp';temp.write_text(page);temp.replace(index)
    pilot_page=f'<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>移动峰诊断</title><style>{STYLE}</style><main><p><a href="../">返回真实训练主实验</a></p>'+table.replace('href="pilot/','href="')+'</main></html>'
    temp=root/'pilot/index.tmp';temp.write_text(pilot_page);temp.replace(root/'pilot/index.html')
