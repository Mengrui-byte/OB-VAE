"""1024/512/256-dimensional whole-window state ablation, one seed only."""

import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import numpy as np
import torch
from torch.utils.data import DataLoader, Subset

from model.experimental.dual_fusion import FusedOrderBookVAE
from model.experimental.window_state import WindowStateVAE
from model.losses.dual import DualLossConfig, DualVAELoss
from train_dual.experiments.long_worker import atomic_json, datasets, evaluate, forward, rng_state
from train_dual.util.checkpoint import atomic_save, seed_everything, source_hashes
from train_dual.util.data import DualNormalizer


LANES = ("reference", "d1024", "d512", "d256")
FEATURE_NAMES = ("mean_spread_bps", "last_spread_bps", "log_mean_bid_depth", "log_mean_ask_depth",
                 "mean_imbalance_10", "last_imbalance_10", "mean_imbalance_100", "last_imbalance_100",
                 "window_return_bps", "realized_return_rms_bps", "mid_range_bps", "large_quantity_share")


def utc():
    return datetime.now(timezone.utc).isoformat()


def strict_precision():
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False


def market_features(raw):
    """Descriptive features available by the end of the observed window."""
    data = raw['data'].numpy().astype(np.float64)
    counts = raw['level_counts'].numpy()
    mask = np.arange(data.shape[-2]) < counts[..., None]
    price, quantity = data[..., 0], np.where(mask, data[..., 1], 0)
    mid = price[..., 0].mean(2)
    spread = (price[:, :, 1, 0] - price[:, :, 0, 0]) / mid * 10000
    total = quantity.sum(-1)
    columns = [spread.mean(1), spread[:, -1], np.log1p(total[:, :, 0].mean(1)), np.log1p(total[:, :, 1].mean(1))]
    for levels in (10, 100):
        depth = quantity[..., :levels].sum(-1)
        imbalance = (depth[:, :, 0] - depth[:, :, 1]) / depth.sum(2).clip(1e-12)
        columns.extend([imbalance.mean(1), imbalance[:, -1]])
    returns = np.diff(np.log(mid), axis=1) * 10000
    columns.extend([np.log(mid[:, -1] / mid[:, 0]) * 10000,
                    np.sqrt(np.square(returns).mean(1)), (mid.max(1) - mid.min(1)) / mid[:, 0] * 10000,
                    np.where(quantity >= 100, quantity, 0).sum((1, 2, 3)) / quantity.sum((1, 2, 3)).clip(1e-12)])
    return np.stack(columns, 1)


def load_base(root):
    saved = torch.load(root / 'initial.pt', map_location='cpu', weights_only=False)
    cfg = saved['config']['normalization']
    norm = DualNormalizer(tick_size=cfg['tick_size'], price_scale=cfg['price_scale'])
    return saved, norm


def prepare_cache(root):
    plan = json.loads((root / 'plan.json').read_text())
    seed_everything(plan['seed']); strict_precision(); torch.set_num_threads(4)
    initial, normalizer = load_base(root)
    teacher = FusedOrderBookVAE(fusion_variant='cross', fusion_seed=42, **initial['model_config']).to('cuda:0')
    teacher.load_state_dict(initial['model'], strict=True); teacher.eval()
    train = datasets(root, initial, 'train')
    indices = np.load(root / 'cache_indices.npy')
    loader = DataLoader(Subset(train, indices.tolist()), batch_size=8, shuffle=False, num_workers=2)
    parts = {key: [] for key in ('global', 'local', 'mask', 'times', 'features')}
    gs, ls, gm, lm, gn, ln = None, None, None, None, 0, 0
    with torch.inference_mode():
        for raw in loader:
            batch = normalizer.prepare(raw, 'cuda:0')
            p = teacher.encoder(batch['price'], batch['volume'], batch['mask'], batch['tick_norm'], times=batch['times'], sample=False)
            fused = teacher.fusion([(p['z_global'], p['z_local'])], p['latent_mask'], batch['times'])
            g = fused['global_latent'].double().cpu().reshape(-1, teacher.encoder.global_stats.out_features // 2)
            l = fused['local_latent'].double().cpu()[p['latent_mask'].cpu()]
            ag, al, bg, bl = g.sum(0), l.sum(0), g.square().sum(0), l.square().sum(0)
            gs = ag if gs is None else gs + ag; ls = al if ls is None else ls + al
            gm = bg if gm is None else gm + bg; lm = bl if lm is None else lm + bl
            gn += len(g); ln += len(l)
            for key, value in [('global', p['z_global']), ('local', p['z_local']), ('mask', p['latent_mask']), ('times', batch['times'])]:
                parts[key].append(value.cpu())
            parts['features'].append(torch.from_numpy(market_features(raw)))
    statistics = dict(global_mean=(gs / gn).tolist(), global_scale=(gm / gn - (gs / gn).square()).clamp_min(.0025).sqrt().tolist(),
                      local_mean=(ls / ln).tolist(), local_scale=(lm / ln - (ls / ln).square()).clamp_min(.0025).sqrt().tolist())
    atomic_save({key: torch.cat(values) for key, values in parts.items()}, root / 'training_latents.pt')
    atomic_json(root / 'latent_statistics.json', dict(**statistics, fit_split='2022-2024 training only', windows=len(indices), indices=indices.tolist()))
    print(json.dumps(dict(cache_windows=len(indices), train_only=True)), flush=True)
    del teacher
    torch.cuda.empty_cache()


def probe(root, model, normalizer, initial, lane, plan):
    """Train-only standardized ridge probes for observed-window attributes."""
    if lane == 'reference':
        return
    model.eval()
    arrays = {}
    with torch.inference_mode():
        for split, windows in [('train', plan['probe_train_windows']), ('val', plan['evaluation_windows'])]:
            data = datasets(root, initial, split)
            indices = np.unique(np.linspace(0, len(data) - 1, windows, dtype=int))
            states, features, endpoints = [], [], []
            for index in indices:
                raw = {k: v.unsqueeze(0) for k, v in data[int(index)].items()}
                b = normalizer.prepare(raw, 'cuda:0')
                state = model.extract_market_state(b['price'], b['volume'], b['mask'], b['tick_norm'], b['times'])
                states.append(state.cpu().numpy()[0]); features.append(market_features(raw)[0])
                start = int(data.base.starts[int(index)])
                endpoints.append(int(data.base.times[start + 15]))
            arrays[split] = (np.stack(states).astype(np.float64), np.stack(features), np.array(endpoints))
    x, y, _ = arrays['train']; xv, yv, _ = arrays['val']
    mean, scale = x.mean(0), x.std(0).clip(1e-6)
    a, b = (x - mean) / scale, (xv - mean) / scale
    center, ys = y.mean(0), y.std(0).clip(1e-6)
    weights = np.linalg.solve(a.T @ a + plan['probe_ridge_alpha'] * np.eye(a.shape[1]), a.T @ ((y - center) / ys))
    prediction = b @ weights * ys + center
    error = np.square(prediction - yv).mean(0)
    variance = np.square(yv - yv.mean(0)).mean(0)
    rows = {name: dict(rmse=float(np.sqrt(error[i])), r2=float(1 - error[i] / variance[i]) if variance[i] > 1e-12 else None)
            for i, name in enumerate(FEATURE_NAMES)}
    folder = root / lane
    np.savez_compressed(folder / 'market_states.npz', train_states=x, development_states=xv,
                        train_targets=y, development_targets=yv, development_predictions=prediction,
                        train_end_time=arrays['train'][2], development_end_time=arrays['val'][2])
    atomic_json(folder / 'state_probe.json', dict(features=rows, state_dim=x.shape[1],
                train_windows=len(x), development_windows=len(xv), ridge_alpha=plan['probe_ridge_alpha'],
                scaler_fit='training only', interpretation='Observed-window attributes, not future prediction or regime identification'))


def worker(root, lane):
    plan = json.loads((root / 'plan.json').read_text()); seed_everything(plan['seed']); strict_precision(); torch.set_num_threads(4)
    folder = root / lane; folder.mkdir(exist_ok=True)
    initial, normalizer = load_base(root)
    compressed = lane != 'reference'
    if compressed:
        model = WindowStateVAE(state_dim=int(lane[1:]), state_slots=16, state_width=64, state_seed=42, **initial['model_config'])
        model.load_cross_initial(initial['model'])
        model.window_codec.calibrate(json.loads((root / 'latent_statistics.json').read_text()))
    else:
        model = FusedOrderBookVAE(fusion_variant='cross', fusion_seed=42, **initial['model_config'])
        model.load_state_dict(initial['model'], strict=True)
    model.to('cuda:0')
    train, val = datasets(root, initial, 'train'), datasets(root, initial, 'val')
    criterion = DualVAELoss(config=DualLossConfig(**plan['loss']))
    started = time.monotonic(); params = sum(p.numel() for p in model.parameters()); hashes = source_hashes()

    def save(path, step, optimizer=None):
        payload = dict(format_version=1, model=model.state_dict(), model_config=initial['model_config'],
                       config=dict(initial['config'], loss=plan['loss']), fusion_variant='cross', refinement_seed=42,
                       source_checkpoint=plan['initial_checkpoint'], source_hashes=hashes, step=step,
                       rng=rng_state(), parameters=params, epoch_completed=False)
        if compressed:
            payload['window_state_config'] = model.state_config
        if optimizer is not None:
            payload['optimizer'] = optimizer.state_dict()
        atomic_save(payload, path)

    def evaluate_stage(stage):
        result = evaluate(model, normalizer, val, plan['evaluation_windows'], 'cuda:0')
        atomic_json(folder / (stage + '_evaluation.json'), dict(stage=stage, utc=utc(), result=result,
                    parameters=params, evaluation_backend='strict_fp32', elapsed_seconds=time.monotonic() - started))

    try:
        evaluate_stage('initial')
        if compressed:
            cached = torch.load(root / 'training_latents.pt', map_location='cpu', weights_only=False)
            indices = np.load(root / 'warmup_batches.npy')
            for p in model.parameters(): p.requires_grad_(False)
            for p in model.window_codec.parameters(): p.requires_grad_(True)
            model.eval(); model.window_codec.train()
            optimizer = torch.optim.AdamW(model.window_codec.parameters(), lr=plan['warmup_lr'], weight_decay=1e-4)
            for step, selected in enumerate(indices, 1):
                idx = torch.from_numpy(selected)
                zg, zl, mask, times = [cached[k][idx].to('cuda:0') for k in ('global', 'local', 'mask', 'times')]
                optimizer.zero_grad(set_to_none=True)
                with torch.no_grad(), torch.autocast('cuda', dtype=torch.bfloat16):
                    target = model.fusion([(zg, zl)], mask, times)
                with torch.autocast('cuda', dtype=torch.bfloat16):
                    encoded = model.window_codec.compress(target['unified'], mask, times)
                    gh, lh = model.window_codec.expand(encoded['state'], mask, times)
                gmse = ((gh.float() - target['global_latent'].float()) / model.window_codec.global_scale).square().mean()
                lmse = (((lh.float() - target['local_latent'].float()) / model.window_codec.local_scale).square().mean(-1))[mask].mean()
                loss = .5 * (gmse + lmse)
                if not torch.isfinite(loss): raise FloatingPointError('Nonfinite codec warmup')
                loss.backward(); torch.nn.utils.clip_grad_norm_(model.window_codec.parameters(), 1., error_if_nonfinite=True); optimizer.step()
                if step == 1 or step % 32 == 0:
                    row = dict(state='codec_warmup', utc=utc(), lane=lane, step=step, loss=float(loss.detach()),
                               global_mse=float(gmse.detach()), local_mse=float(lmse.detach()), elapsed_seconds=time.monotonic() - started)
                    atomic_json(folder / 'progress.json', row); print(json.dumps(row), flush=True)
            save(folder / 'warmup.pt', 0, optimizer); evaluate_stage('warmup')
            del cached, optimizer
        for p in model.parameters(): p.requires_grad_(True)
        groups = [dict(params=[p for n, p in model.named_parameters() if not n.startswith('window_codec.')], lr=plan['lr'])]
        if compressed: groups.append(dict(params=model.window_codec.parameters(), lr=plan['codec_joint_lr']))
        optimizer = torch.optim.AdamW(groups, weight_decay=.01)
        seed_everything(plan['seed']); strict_precision()
        loader = DataLoader(Subset(train, np.load(root / 'train_indices.npy').tolist()), batch_size=plan['physical_batch'],
                            shuffle=False, num_workers=2, pin_memory=True, generator=torch.Generator().manual_seed(plan['seed']))
        accumulation = plan['effective_batch'] // plan['physical_batch']
        optimizer.zero_grad(set_to_none=True); model.train(); total_loss = 0.; step = 0
        torch.cuda.reset_peak_memory_stats()
        for micro, raw in enumerate(loader, 1):
            batch = normalizer.prepare(raw, 'cuda:0')
            with torch.autocast('cuda', dtype=torch.bfloat16): out = forward(model, batch, True)
            loss = criterion(out, batch)['loss']
            if not torch.isfinite(loss): raise FloatingPointError('Nonfinite reconstruction loss')
            (loss / accumulation).backward(); total_loss += loss.item() / accumulation
            if micro % accumulation: continue
            norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1., error_if_nonfinite=True)
            optimizer.step(); optimizer.zero_grad(set_to_none=True); step += 1
            if step == 1 or step % 8 == 0:
                row = dict(state='joint_training', utc=utc(), lane=lane, step=step, loss=total_loss, gradient_norm=float(norm),
                           samples_seen=step * plan['effective_batch'], elapsed_seconds=time.monotonic() - started,
                           peak_allocated_gib=torch.cuda.max_memory_allocated()/2**30, reserved_gib=torch.cuda.memory_reserved()/2**30)
                atomic_json(folder / 'progress.json', row); print(json.dumps(row), flush=True)
            total_loss = 0.
            if step % 64 == 0: save(folder / 'last.pt', step, optimizer)
            if step == plan['joint_steps']: break
        if step != plan['joint_steps']: raise RuntimeError('Training sample budget ended early')
        save(folder / 'final.pt', step, optimizer); evaluate_stage('final')
        predictions, truths, masks, vectors = [], [], [], []
        model.eval()
        with torch.inference_mode():
            for index in plan['example_indices']:
                raw = {k: v.unsqueeze(0) for k, v in val[index].items()}; b = normalizer.prepare(raw, 'cuda:0'); out = forward(model, b, False)
                predictions.append(np.stack([normalizer.inverse_price(out['price_norm'], b)[0].cpu().numpy(), out['volume'][0].cpu().numpy()], -1))
                truths.append(raw['data'][0].numpy()); masks.append(b['mask'][0].cpu().numpy())
                if compressed: vectors.append(out['market_state'][0].cpu().numpy())
        np.savez_compressed(folder / 'profiles.npz', prediction=np.stack(predictions), truth=np.stack(truths), mask=np.stack(masks),
                            **({'market_state': np.stack(vectors)} if compressed else {}))
        probe(root, model, normalizer, initial, lane, plan)
        atomic_json(folder / 'status.json', dict(state='complete', utc=utc(), step=step, elapsed_seconds=time.monotonic() - started))
    except BaseException as error:
        atomic_json(folder / 'status.json', dict(state='failed', utc=utc(), error=repr(error)))
        raise


def campaign(root):
    plan = json.loads((root / 'plan.json').read_text()); started = time.monotonic()
    status = dict(state='preparing_training_cache', utc=utc(), children=[])
    atomic_json(root / 'status.json', status)
    children = []; logs = root / 'logs'; logs.mkdir(exist_ok=True)
    try:
        if not (root/'training_latents.pt').exists():
            prepare_cache(root)
        for gpu, lane in zip((2, 3, 4, 5), LANES):
            env = dict(os.environ, CUDA_VISIBLE_DEVICES=str(gpu), CUDA_DEVICE_ORDER='PCI_BUS_ID', PYTHONPATH=str(root/'source_snapshot'),
                       PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='4', MKL_NUM_THREADS='4', OPENBLAS_NUM_THREADS='4')
            with (logs / (lane+'.log')).open('ab', buffering=0) as log:
                p = subprocess.Popen([sys.executable, '-u', '-m', 'train_dual.experiments.window_state_pilot', str(root), '--lane', lane],
                                     cwd=root/'source_snapshot', env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            children.append((lane, p)); status['children'].append(dict(lane=lane, gpu=gpu, pid=p.pid))
        status['state']='running'; atomic_json(root/'status.json', status)
        while any(p.poll() is None for _, p in children):
            if time.monotonic()-started > plan['wall_clock_limit_seconds']: raise TimeoutError('Ablation wall-clock limit reached')
            if any(p.poll() not in (None, 0) for _, p in children): raise RuntimeError('A worker failed; stop paired ablation')
            time.sleep(3)
        codes={name:p.returncode for name,p in children}
        if any(code!=0 for code in codes.values()): raise RuntimeError(f'Worker failures: {codes}')
        rows={}
        for lane,_ in children:
            rows[lane]={stage:json.loads((root/lane/(stage+'_evaluation.json')).read_text()) for stage in ['initial','final']}
            if lane!='reference':
                rows[lane]['warmup']=json.loads((root/lane/'warmup_evaluation.json').read_text())
                rows[lane]['state_probe']=json.loads((root/lane/'state_probe.json').read_text())
        base=rows['reference']['initial']['result']; qualified=[]
        for lane in LANES[1:]:
            value=rows[lane]['final']['result'];a,b=value['metrics'],base['metrics']
            checks={key:a[key]['rmse']<=factor*b[key]['rmse'] for key,factor in plan['quality_limits'].items()}
            checks['large_recall']=value['thresholds']['100']['recall']>=base['thresholds']['100']['recall']-plan['large_recall_tolerance']
            rows[lane]['quality_checks']=checks;rows[lane]['qualified']=all(checks.values())
            if all(checks.values()): qualified.append(int(lane[1:]))
        atomic_json(root/'comparison.json', dict(rows=rows, selected_minimum_dimension=min(qualified) if qualified else None,
                    reference='Frozen initial cross checkpoint, not a potentially degraded fine-tuned control', seed=42,
                    limitation='Single-seed finite-budget screen; reconstruction failures do not establish an information-theoretic minimum'))
        status.update(state='complete', finished_utc=utc(), elapsed_seconds=time.monotonic()-started)
    except BaseException as error:
        status.update(state='failed', finished_utc=utc(), error=repr(error));raise
    finally:
        for _,p in children:
            if p.poll() is None:
                try: os.killpg(p.pid,signal.SIGTERM)
                except ProcessLookupError: pass
        for _,p in children:
            try:p.wait(timeout=10)
            except subprocess.TimeoutExpired:
                try:os.killpg(p.pid,signal.SIGKILL)
                except ProcessLookupError:pass
        atomic_json(root/'status.json',status)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('root',type=Path);parser.add_argument('--lane',choices=LANES);parser.add_argument('--prepare-only',action='store_true')
    args=parser.parse_args()
    if args.prepare_only:prepare_cache(args.root)
    elif args.lane:worker(args.root,args.lane)
    else:campaign(args.root)
