"""Own four remote GPU workers for a strict twelve-hour wall-clock budget."""

import argparse
from datetime import datetime,timezone
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import numpy as np

from train_dual.experiments.long_worker import atomic_json


VARIANTS=('control','spatial','volume','temporal')
SEEDS=(42,43,44)


def iso(timestamp):
    return datetime.fromtimestamp(timestamp,timezone.utc).isoformat()


def owned_stop(process):
    if process.poll() is None:
        os.killpg(process.pid,signal.SIGTERM)


def aggregate(root):
    """Compare all available seeds at one identical evaluated update count."""
    records={}
    complete=[]
    for seed in SEEDS:
        group={}
        for variant in VARIANTS:
            path=root/'runs'/f'{variant}_s{seed}'/'evaluations.jsonl'
            values={}
            if path.exists():
                for line in path.read_text().splitlines():
                    try:
                        row=json.loads(line);values[row['step']]=row
                    except (ValueError,KeyError):pass
            group[variant]=values
        if all(group.values()):
            complete.append(seed)
            for variant,values in group.items():records[(variant,seed)]=values
    if not complete:return dict(state='waiting_for_common_evaluation',seeds=[])
    common=set.intersection(*(set(values) for values in records.values()))
    if not common:return dict(state='waiting_for_common_evaluation',seeds=complete)
    step=max(common)
    table={}
    for variant in VARIANTS:
        rows=[records[(variant,seed)][step] for seed in complete]
        controls=[records[('control',seed)][step] for seed in complete]
        fields=dict(score=[r['score'] for r in rows],
            price_rmse=[r['result']['metrics']['price_usdt']['rmse'] for r in rows],
            quantity_rmse=[r['result']['metrics']['quantity_btc']['rmse'] for r in rows],
            tail_log_rmse=[r['result']['tail_log_rmse'] for r in rows],
            slope64_rmse=[r['result']['metrics']['spatial_slope_64_levels_usdt_per_level']['rmse'] for r in rows],
            mid_change_rmse=[r['result']['metrics']['temporal_mid_1_minutes_usdt_per_minute']['rmse'] for r in rows])
        values={name:dict(mean=float(np.mean(v)),std=float(np.std(v,ddof=1)) if len(v)>1 else None,
                          per_seed=dict(zip(map(str,complete),v))) for name,v in fields.items()}
        guards=[]
        for row,control in zip(rows,controls):
            a,b=row['result']['metrics'],control['result']['metrics']
            guards.append(a['price_usdt']['rmse']<=1.20*b['price_usdt']['rmse'] and
                          a['quantity_btc']['rmse']<=1.10*b['quantity_btc']['rmse'])
        table[variant]=dict(metrics=values,guardrails_pass=all(guards))
    baseline=table['control']['metrics']['score']['mean']
    eligible=[name for name,item in table.items() if item['guardrails_pass'] and
              (name=='control' or item['metrics']['score']['mean']<=baseline+math.log(.95))]
    winner=min(eligible,key=lambda name:table[name]['metrics']['score']['mean'])
    return dict(state='complete' if len(complete)==3 else 'partial',seeds=complete,
                common_step=step,winner=winner,variants=table,
                limitation='Common pretrained backbone; three seeds measure fine-tuning and added-head variation.')


def launch(root,gpu,variant,seed,stop_at,physical_batch,mode='train',step=None):
    folder=root/'logs';folder.mkdir(exist_ok=True)
    command=[sys.executable,'-u','-m','train_dual.experiments.long_worker',str(root),
             '--mode',mode,'--variant',variant,'--seed',str(seed),'--physical-batch',str(physical_batch)]
    if mode=='train':command+=['--stop-at',str(stop_at)]
    if step is not None:command+=['--step',str(step)]
    env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),CUDA_DEVICE_ORDER='PCI_BUS_ID',
             OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',PYTHONDONTWRITEBYTECODE='1',
             PYTHONPATH=str(root/'source_snapshot'))
    for name in ('RANK','LOCAL_RANK','WORLD_SIZE','LOCAL_WORLD_SIZE','GROUP_RANK','MASTER_ADDR','MASTER_PORT'):
        env.pop(name,None)
    path=folder/f'{mode}_{variant}_s{seed}.log'
    with path.open('ab',buffering=0) as log:
        process=subprocess.Popen(command,cwd=root/'source_snapshot',env=env,stdin=subprocess.DEVNULL,
                                 stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    return process,dict(pid=process.pid,gpu=gpu,variant=variant,seed=seed,mode=mode,
                        stop_at=stop_at,log=str(path),command=command)


def run(root,duration_seconds=43200,physical_batch=32):
    root=root.resolve()
    for name in ('common_config.json','reference.json'):
        if not (root/name).exists():raise FileNotFoundError(root/name)
    for variant in VARIANTS:
        result=json.loads((root/f'resource_{variant}.json').read_text())
        if result['physical_batch']!=physical_batch or result['peak_reserved_gib']>=45:
            raise RuntimeError(f'Unsafe resource preflight: {variant}')
    # Refuse accidental double submission of this campaign.
    import fcntl
    lock=(root/'controller.lock').open('w')
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    start=time.time();monotonic_start=time.monotonic();deadline=start+duration_seconds
    reserve=min(300,duration_seconds*.05)
    manifest=dict(state='running',controller_pid=os.getpid(),started_utc=iso(start),deadline_utc=iso(deadline),
        duration_seconds=duration_seconds,final_evaluation_reserve_seconds=reserve,
        variants=list(VARIANTS),seeds=list(SEEDS),gpu_ids=[2,3,4,5],physical_batch=physical_batch,
        effective_batch=256,precision='bf16',children=[])
    atomic_json(root/'campaign_status.json',manifest)
    all_owned=[]
    try:
        for phase,seed in enumerate(SEEDS):
            phase_end=start+(phase+1)*duration_seconds/3
            if phase==2:phase_end-=reserve
            if time.time()>=phase_end:continue
            active={};restarts={name:0 for name in VARIANTS}
            for gpu,variant in zip((2,3,4,5),VARIANTS):
                process,info=launch(root,gpu,variant,seed,phase_end,physical_batch)
                active[variant]=(process,info);all_owned.append(process)
            last_aggregate=last_smi=0.
            while time.time()<phase_end and time.monotonic()-monotonic_start<duration_seconds-reserve:
                now=time.time()
                for variant,(process,info) in list(active.items()):
                    code=process.poll()
                    if code is not None and now<phase_end-90:
                        if code!=0 and restarts[variant]<2:
                            restarts[variant]+=1
                            with (root/'events.jsonl').open('a') as stream:
                                stream.write(json.dumps(dict(utc=iso(now),event='worker_restart',
                                    returncode=code,attempt=restarts[variant],**info))+'\n')
                            process,info=launch(root,info['gpu'],variant,seed,phase_end,physical_batch)
                            active[variant]=(process,info);all_owned.append(process)
                        elif code!=0:
                            info['failed_returncode']=code
                manifest.update(phase=phase+1,current_seed=seed,phase_deadline_utc=iso(phase_end),
                    elapsed_seconds=time.monotonic()-monotonic_start,
                    children=[dict(**info,alive=process.poll() is None,restarts=restarts[name])
                              for name,(process,info) in active.items()])
                atomic_json(root/'campaign_status.json',manifest)
                if now-last_aggregate>=60:
                    atomic_json(root/'leaderboard.json',aggregate(root));last_aggregate=now
                if now-last_smi>=30:
                    capture=subprocess.run(['nvidia-smi','--query-gpu=index,name,utilization.gpu,memory.used',
                                            '--format=csv,noheader'],capture_output=True,text=True,timeout=10)
                    atomic_json(root/'gpu_status.json',dict(utc=iso(now),output=capture.stdout))
                    last_smi=now
                time.sleep(5)
            for process,_ in active.values():owned_stop(process)
            for process,_ in active.values():
                try:process.wait(timeout=20)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid,signal.SIGKILL);process.wait()
            atomic_json(root/'leaderboard.json',aggregate(root))
        selection=aggregate(root)
        atomic_json(root/'selection_frozen.json',dict(utc=iso(time.time()),**selection))
        if selection.get('state')=='complete' and time.time()<deadline-30:
            final=[]
            for gpu,seed in zip((2,3,4),SEEDS):
                process,info=launch(root,gpu,selection['winner'],seed,deadline,physical_batch,
                                    mode='final',step=selection['common_step'])
                final.append((process,info));all_owned.append(process)
            process,info=launch(root,5,selection['winner'],42,deadline,physical_batch,
                                mode='final-extra',step=selection['common_step'])
            final.append((process,info));all_owned.append(process)
            manifest.update(state='final_holdout',children=[info for _,info in final])
            atomic_json(root/'campaign_status.json',manifest)
            while any(p.poll() is None for p,_ in final) and time.monotonic()-monotonic_start<duration_seconds:
                time.sleep(2)
            for process,_ in final:owned_stop(process)
        # Consume no further training budget once all slots and final evaluation finish.
        manifest.update(state='complete',finished_utc=iso(time.time()),
                        elapsed_seconds=time.monotonic()-monotonic_start,selection=selection,
                        holdout_files=[str(p) for p in sorted((root/'holdout').glob('*.json'))]
                        if (root/'holdout').exists() else [])
        atomic_json(root/'campaign_status.json',manifest)
        atomic_json(root/'leaderboard.json',selection)
    except BaseException as error:
        manifest.update(state='failed',error=repr(error),finished_utc=iso(time.time()))
        atomic_json(root/'campaign_status.json',manifest)
        raise
    finally:
        for process in all_owned:owned_stop(process)
        for process in all_owned:
            try:process.wait(timeout=15)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid,signal.SIGKILL);process.wait()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root',type=Path)
    parser.add_argument('--duration-seconds',type=float,default=43200)
    parser.add_argument('--physical-batch',type=int,default=32)
    args=parser.parse_args()
    if args.duration_seconds<=0 or args.duration_seconds>43200:
        parser.error('Duration must be within (0,43200] seconds')
    run(args.root,args.duration_seconds,args.physical_batch)


if __name__=='__main__':main()
