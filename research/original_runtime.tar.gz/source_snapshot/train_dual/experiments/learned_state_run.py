"""Matched full-input encoder ablation, with a small-fit gate and frozen sources."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

import numpy as np
import torch
from torch.utils.data import DataLoader

from model.experimental.learned_window_state import LearnedWindowStateVAE
from model.losses.dual import DualLossConfig, DualVAELoss
from train_dual.experiments.long_worker import atomic_json, datasets, evaluate, rng_state, score
from train_dual.experiments.pca_run import CachedWindows, examples
from train_dual.experiments.window_state_pilot import load_base, strict_precision
from train_dual.util.checkpoint import atomic_save, freeze_sources, load_for_inference, seed_everything, source_hashes


LANES = ('fixed', 'linear', 'nonlinear', 'attention')
GENERATOR = ('price_decoder.', 'volume_decoder.', 'volume_refinement.')


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as file:
        for block in iter(lambda: file.read(8 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def make_model(root, lane):
    plan = json.loads((root / 'plan.json').read_text())
    initial, normalizer = load_base(root)
    model = LearnedWindowStateVAE(encoding_kind=lane, encoding_hidden_dim=plan['encoding_hidden_dim'],
        attention_dim=plan['attention_dim'], hidden_dim=plan['inverse_hidden_dim'],
        state_dim=plan['state_dim'], global_components=plan['global_components'], **initial['model_config'])
    missing, unexpected = model.load_state_dict(initial['model'], strict=False)
    allowed = ('state_codec.', 'latent_residual.', 'encoding_residual.')
    if unexpected or any(not name.startswith(allowed) for name in missing):
        raise ValueError(f'Source initialization mismatch: {missing}, {unexpected}')
    model.state_codec.load_basis(torch.load(root / 'pca_basis.pt', map_location='cpu', weights_only=False))
    scale = torch.load(root / 'train_states.pt', map_location='cpu', weights_only=False)['states'].std(0).clamp_min(1e-4)
    model.encoding_residual.state_scale.copy_(scale)
    model.latent_residual.state_scale.copy_(scale)
    return model, normalizer, initial, plan


def cached_forward(model, batch, raw, cache):
    positions = raw['cache_position']
    g = cache['global'][positions].to('cuda:0')
    l = cache['local'][positions].to('cuda:0')
    mask = cache['mask'][positions].to('cuda:0')
    state = model.encode_latents(g, l, mask)
    return model.decode_state(state, batch['mask'], batch['tick_norm'], batch['times'])


def worker(root, lane, phase):
    torch.set_num_threads(4)
    seed_everything(42)
    strict_precision()
    model, norm, initial, plan = make_model(root, lane)
    model.to('cuda:0')
    folder = root / ('small_fit' if phase == 'small' else 'main') / lane
    folder.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    cache = torch.load(root / 'decoder_latents.pt', map_location='cpu', mmap=True, weights_only=False)
    train = datasets(root, initial, 'train')
    indices = np.load(root / 'fit_indices.npy')
    criterion = DualVAELoss(config=DualLossConfig(**plan['loss']))
    is_small = phase == 'small'
    steps = plan['small_steps'] if is_small else plan['steps']
    physical = plan['small_physical_batch'] if is_small else plan['physical_batch']
    effective = plan['small_effective_batch'] if is_small else plan['effective_batch']
    accumulation = effective // physical
    order = np.load(root / ('small_order.npy' if is_small else 'train_order.npy'))
    loader = DataLoader(CachedWindows(train, indices, order), batch_size=physical, shuffle=False,
        num_workers=2, pin_memory=True, generator=torch.Generator().manual_seed(42))
    generator_parameters = [p for name, p in model.named_parameters() if name.startswith(GENERATOR)]
    for p in generator_parameters:
        p.requires_grad_(False)
    new_parameters = [p for name, p in model.named_parameters()
                      if name.startswith(('encoding_residual.', 'latent_residual.')) and p.requires_grad]
    optimizer = torch.optim.AdamW([dict(params=new_parameters, lr=plan['small_lr'] if is_small else plan['codec_lr'])], weight_decay=.01)
    gradient_parameters = list(new_parameters)
    hashes = source_hashes()

    def save(name, step):
        atomic_save(dict(format_version=1, model=model.state_dict(), model_config=initial['model_config'],
            config=dict(initial['config'], loss=plan['loss']), pca_state_config=model.pca_state_config,
            residual_pca_config=model.residual_pca_config, learned_state_config=model.learned_state_config,
            step=step, source_hashes=hashes, optimizer=optimizer.state_dict(), rng=rng_state(),
            initial_checkpoint=plan['initial_checkpoint'], phase=phase, epoch_completed=False), folder / name)

    def validate(stage, step):
        value = evaluate(model, norm, datasets(root, initial, 'val'), plan['evaluation_windows'], 'cuda:0')
        row = dict(stage=stage, step=step, result=value, elapsed_seconds=time.monotonic() - started,
            state_dim=plan['state_dim'], encoding_kind=lane, evaluation_backend='strict_fp32')
        atomic_json(folder / (stage + '_evaluation.json'), row)
        with (folder / 'evaluations.jsonl').open('a') as file:
            file.write(json.dumps(row) + '\n')
        return row

    def small_measure():
        model.eval()
        subset = CachedWindows(train, indices, np.load(root / 'small_positions.npy'))
        total, count, states, price_sse, quantity_sse, levels, tp, positives = 0., 0, [], 0., 0., 0, 0, 0
        with torch.inference_mode():
            for raw in DataLoader(subset, batch_size=physical, shuffle=False):
                batch = norm.prepare(raw, 'cuda:0')
                out = cached_forward(model, batch, raw, cache)
                loss = criterion(out, batch)['loss']
                total += float(loss) * len(raw['data'])
                count += len(raw['data'])
                states.append(out['market_state'].cpu())
                mask = batch['mask']
                levels += int(mask.sum())
                price_error = ((out['price_norm'].double() - batch['price'].double())
                               * batch['price_factor'][:, None, None, None])
                price_sse += float((price_error.square() * mask).sum())
                quantity_sse += float(((out['volume'] - batch['volume']).square() * mask).sum())
                large = (batch['volume'] >= 100) & mask
                positives += int(large.sum())
                tp += int(((out['volume'] >= 100) & large).sum())
        states = torch.cat(states)
        singular = torch.linalg.svdvals(states - states.mean(0))
        energy = singular.square()
        model.train()
        return dict(loss=total / count, price_rmse=(price_sse / levels) ** .5,
            quantity_rmse=(quantity_sse / levels) ** .5, large_recall=tp / positives if positives else None,
            participation_rank=float(energy.sum().square() / energy.square().sum().clamp_min(1e-12)),
            finite=bool(torch.isfinite(states).all())), states

    try:
        atomic_json(folder / 'progress.json', dict(state='initial_validation', step=0, phase=phase))
        # Verify that cached and online features refer to exactly the same window.
        raw0 = next(iter(DataLoader(CachedWindows(train, indices, np.array([0])), batch_size=1)))
        batch0 = norm.prepare(raw0, 'cuda:0')
        with torch.inference_mode():
            direct = model.extract_market_state(batch0['price'], batch0['volume'], batch0['mask'],
                batch0['tick_norm'], batch0['times'])
            cached = model.encode_latents(cache['global'][:1].to('cuda:0'), cache['local'][:1].to('cuda:0'),
                cache['mask'][:1].to('cuda:0'))
            torch.testing.assert_close(direct, cached, atol=1e-4, rtol=1e-5)
        atomic_json(folder / 'cache_replay.json', dict(max_state_difference=float((direct-cached).abs().max()),
            index=int(indices[0]), device=torch.cuda.get_device_name(), state_shape=list(direct.shape)))
        if is_small:
            initial_small, initial_states = small_measure()
            atomic_json(folder / 'initial_evaluation.json', initial_small)
            if lane == 'fixed':
                teacher, _ = load_for_inference(root / 'initial.pt', 'cuda:0')
                result = evaluate(teacher, norm, datasets(root, initial, 'val'), plan['evaluation_windows'], 'cuda:0')
                expected = json.loads((root / 'expected_reference.json').read_text())['result']
                differences = {key: abs(result['metrics'][key]['rmse'] - expected['metrics'][key]['rmse'])
                               for key in plan['quality_limits']}
                if max(differences.values()) > 1e-4:
                    raise RuntimeError(f'Strong reference replay mismatch: {differences}')
                atomic_json(root / 'source_reference.json', dict(result=result, replay_difference=differences))
                del teacher
        else:
            validate('initial', 0)
            save('initial.pt', 0)
            examples(root, folder, model, norm, initial, plan)
            (folder / 'profiles.npz').replace(folder / 'initial_profiles.npz')
        step, loss_sum, codec_gradient_max, encoder_gradient_max = 0, 0., 0., 0.
        optimizer.zero_grad(set_to_none=True)
        torch.cuda.reset_peak_memory_stats()
        model.train()
        for micro, raw in enumerate(loader, 1):
            batch = norm.prepare(raw, 'cuda:0')
            with torch.autocast('cuda', dtype=torch.bfloat16):
                out = cached_forward(model, batch, raw, cache)
            loss = criterion(out, batch)['loss']
            if not torch.isfinite(loss):
                raise FloatingPointError('Nonfinite learned-encoder loss')
            (loss / accumulation).backward()
            loss_sum += float(loss.detach()) / accumulation
            if micro % accumulation:
                continue
            encoder_grad = sum(float(p.grad.detach().float().norm().square()) for p in model.encoding_residual.parameters() if p.grad is not None) ** .5
            encoder_gradient_max = max(encoder_gradient_max, encoder_grad)
            grad = torch.nn.utils.clip_grad_norm_(gradient_parameters, 1., error_if_nonfinite=True)
            codec_gradient_max = max(codec_gradient_max, float(grad))
            optimizer.step()
            optimizer.zero_grad(set_to_none=True)
            step += 1
            if step == 1 or step % 8 == 0:
                progress = dict(state='training', phase=phase, step=step, total_steps=steps, loss=loss_sum,
                    gradient_norm=float(grad), encoder_gradient_norm=encoder_grad,
                    generator_frozen=is_small or step <= plan['frozen_steps'],
                    elapsed_seconds=time.monotonic() - started,
                    reserved_gib=torch.cuda.memory_reserved() / 2**30,
                    peak_allocated_gib=torch.cuda.max_memory_allocated() / 2**30)
                atomic_json(folder / 'progress.json', progress)
                with (folder / 'training.jsonl').open('a') as file:
                    file.write(json.dumps(progress) + '\n')
                print(json.dumps(progress), flush=True)
            loss_sum = 0.
            if not is_small and step == plan['frozen_steps']:
                save('frozen.pt', step)
                validate('frozen', step)
                for p in generator_parameters:
                    p.requires_grad_(True)
                optimizer.add_param_group(dict(params=generator_parameters, lr=plan['decoder_lr']))
                gradient_parameters.extend(generator_parameters)
            elif not is_small and step % plan['evaluation_every'] == 0:
                save('last.pt', step)
                validate('latest', step)
            if step >= steps:
                break
        if step != steps:
            raise RuntimeError('Insufficient cached training order')
        if is_small:
            final_small, final_states = small_measure()
            final_small.update(relative_loss=final_small['loss'] / initial_small['loss'],
                state_change_rms=float((final_states - initial_states).square().mean().sqrt()),
                codec_gradient_max=codec_gradient_max, encoder_gradient_max=encoder_gradient_max,
                windows=plan['small_windows'], steps=step)
            if not final_small['finite'] or codec_gradient_max <= 0:
                raise RuntimeError('Small-fit numerical/gradient check failed')
            if lane != 'fixed' and (encoder_gradient_max <= 0 or final_small['state_change_rms'] <= 1e-8):
                raise RuntimeError('Learned encoding has no gradient or state update')
            atomic_json(folder / 'final_evaluation.json', final_small)
            save('final.pt', step)
        else:
            save('final.pt', step)
            validate('final', step)
            examples(root, folder, model, norm, initial, plan)
            # A portable replay must produce the same state and book.
            restored, _ = load_for_inference(folder / 'final.pt', 'cuda:0')
            raw = {k: v.unsqueeze(0) for k, v in datasets(root, initial, 'val')[plan['example_indices'][0]].items()}
            batch = norm.prepare(raw, 'cuda:0')
            args = [batch[k] for k in ('price', 'volume', 'mask', 'tick_norm')]
            with torch.inference_mode():
                a = model(*args, times=batch['times'])
                b = restored(*args, times=batch['times'])
                torch.testing.assert_close(a['market_state'], b['market_state'], rtol=0, atol=0)
                torch.testing.assert_close(a['volume'], b['volume'], rtol=0, atol=0)
            atomic_json(folder / 'checkpoint_replay.json', dict(exact=True, state_shape=list(a['market_state'].shape)))
        atomic_json(folder / 'status.json', dict(state='complete', phase=phase, step=step,
            parameter_count=sum(p.numel() for p in model.parameters()),
            encoding_parameters=sum(p.numel() for p in model.encoding_residual.parameters()),
            elapsed_seconds=time.monotonic() - started))
    except BaseException as error:
        atomic_json(folder / 'status.json', dict(state='failed', phase=phase, error=repr(error)))
        raise


def launch_phase(root, phase, plan, started):
    children = []
    try:
        for gpu, lane in zip(plan['gpus'], LANES):
            env = dict(os.environ, CUDA_VISIBLE_DEVICES=str(gpu), CUDA_DEVICE_ORDER='PCI_BUS_ID',
                PYTHONPATH=str(root / 'source_snapshot'), PYTHONDONTWRITEBYTECODE='1',
                OMP_NUM_THREADS='4', MKL_NUM_THREADS='4', OPENBLAS_NUM_THREADS='4')
            with (root / 'logs' / f'{phase}_{lane}.log').open('ab', buffering=0) as log:
                process = subprocess.Popen([sys.executable, '-u', '-m', 'train_dual.experiments.learned_state_run',
                    str(root), '--lane', lane, '--phase', phase], cwd=root / 'source_snapshot', env=env,
                    stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            children.append((lane, process))
        atomic_json(root / 'status.json', dict(state='running', phase=phase,
            started_utc=datetime.now(timezone.utc).isoformat(),
            children=[dict(lane=lane, gpu=gpu, pid=p.pid) for gpu, (lane, p) in zip(plan['gpus'], children)]))
        while any(p.poll() is None for _, p in children):
            if time.monotonic() - started > plan['timeout_seconds']:
                raise TimeoutError('Encoder experiment wall-time budget exhausted')
            if any(p.poll() not in (None, 0) for _, p in children):
                raise RuntimeError(f'A {phase} worker failed; inspect lane status and log')
            time.sleep(3)
        if any(p.returncode != 0 for _, p in children):
            raise RuntimeError(f'Nonzero {phase} worker exit')
    finally:
        for _, p in children:
            if p.poll() is None:
                try:
                    os.killpg(p.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
        for _, p in children:
            try:
                p.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid, signal.SIGKILL)


def campaign(root):
    plan = json.loads((root / 'plan.json').read_text())
    started = time.monotonic()
    try:
        launch_phase(root, 'small', plan, started)
        small = {lane: {stage: json.loads((root / 'small_fit' / lane / (stage + '_evaluation.json')).read_text())
                       for stage in ('initial', 'final')} for lane in LANES}
        first = small['fixed']['initial']
        for lane in LANES:
            for key in ('loss', 'price_rmse', 'quantity_rmse'):
                if abs(small[lane]['initial'][key] - first[key]) > 1e-4:
                    raise RuntimeError('Paired small-fit initialization mismatch')
        fitting = [lane for lane in LANES if lane != 'fixed' and small[lane]['final']['relative_loss'] <= plan['small_gate_ratio']]
        gate_passed = len(fitting) == len(LANES) - 1
        gate = dict(passed=gate_passed, fitting_learned_lanes=fitting, rows=small,
            criterion=f"Every learned encoder reduces the fixed32-window loss by {1-plan['small_gate_ratio']:.0%}; all workers finite with nonzero codec gradients")
        atomic_json(root / 'small_fit_gate.json', gate)
        if not gate_passed:
            atomic_json(root / 'status.json', dict(state='diagnostic_failed', reason='Small-fit loss gate did not pass', elapsed_seconds=time.monotonic()-started))
            return
        launch_phase(root, 'main', plan, started)
        rows = {lane: {stage: json.loads((root / 'main' / lane / (stage + '_evaluation.json')).read_text())
                       for stage in ('initial', 'frozen', 'final')} for lane in LANES}
        baseline = json.loads((root / 'source_reference.json').read_text())['result']
        control = rows['fixed']['final']['result']['metrics']
        for lane, row in rows.items():
            result = row['final']['result']
            metrics = result['metrics']
            checks = {key: metrics[key]['rmse'] <= factor * baseline['metrics'][key]['rmse']
                      for key, factor in plan['quality_limits'].items()}
            checks['large_recall'] = result['thresholds']['100']['recall'] >= baseline['thresholds']['100']['recall'] - plan['large_recall_tolerance']
            row['quality_checks'] = checks
            row['qualified'] = all(checks.values())
            row['score_vs_strong_reference'] = score(result, baseline)
            row['quantity_improvement_vs_control'] = 1 - metrics['quantity_btc']['rmse'] / control['quantity_btc']['rmse']
        atomic_json(root / 'comparison.json', dict(rows=rows, reference=baseline, seed=42, common_step=plan['steps'],
            limitation='Single seed; development selection only; no dimensional impossibility conclusion',
            hypothesis=plan['hypothesis']))
        atomic_json(root / 'status.json', dict(state='complete', phase='main', elapsed_seconds=time.monotonic()-started))
    except BaseException as error:
        atomic_json(root / 'status.json', dict(state='failed', error=repr(error), elapsed_seconds=time.monotonic()-started))
        raise


def prepare(project):
    parent = project / 'checkpoints/pca_state_20261024_222656'
    name = 'learned_state_' + datetime.now().strftime('%Y%m%d_%H%M%S')
    root = project / 'checkpoints' / name
    root.mkdir()
    (root / 'logs').mkdir()
    (root / 'data').mkdir()
    old = json.loads((parent / 'plan.json').read_text())
    a = torch.load(parent / 'initial.pt', map_location='cpu', weights_only=False)
    b = torch.load(parent / 'reference/final.pt', map_location='cpu', weights_only=False)
    source_keys = [key for key in a['model'] if key.startswith(('encoder.', 'fusion.'))]
    if not all(torch.equal(a['model'][key], b['model'][key]) for key in source_keys):
        raise RuntimeError('Cached source encoder/fusion no longer matches strong baseline')
    os.link(parent / 'reference/final.pt', root / 'initial.pt')
    os.link(parent / 'data/BTCUSDT.npz', root / 'data/BTCUSDT.npz')
    for source, target in [('decoder_latents.pt', 'decoder_latents.pt'), ('pca_basis_qr.pt', 'pca_basis.pt'),
                           ('fit_indices.npy', 'fit_indices.npy'), ('train_states_qr_1024.pt', 'train_states.pt')]:
        (root / target).symlink_to(os.path.relpath(parent / source, root))
    shutil.copy2(parent / 'reference/final_evaluation.json', root / 'expected_reference.json')
    shutil.copy2(parent / 'reference/profiles.npz', root / 'reference_profiles.npz')
    fit = json.loads((parent / 'pca_fit.json').read_text())
    plan = dict(seed=42, gpus=[2,3,4,5], state_dim=1024, global_components=fit['global_components'],
        encoding_hidden_dim=256, attention_dim=64, inverse_hidden_dim=128,
        initial_checkpoint=str(parent / 'reference/final.pt'), initial_sha256=digest(parent / 'reference/final.pt'),
        source_cache_parent=str(parent), source_cache_equal_tensors=len(source_keys),
        train=old['train'], development=old['development'], independent_test_untouched=old['independent_test_untouched'],
        small_windows=32, small_steps=96, small_physical_batch=16, small_effective_batch=32, small_lr=3e-4,
        small_gate_ratio=.98, physical_batch=32, effective_batch=64, steps=1024, frozen_steps=128,
        codec_lr=1e-4, decoder_lr=3e-5, evaluation_windows=128, evaluation_every=128,
        example_indices=old['example_indices'], timeout_seconds=10800, loss=old['loss'],
        quality_limits=old['quality_limits'], large_recall_tolerance=old['large_recall_tolerance'],
        hypothesis='Task-trained full-input compression can preserve liquidity directions discarded by variance-only PCA',
        lanes={lane: dict(gpu=gpu, encoding=lane) for lane,gpu in zip(LANES,(2,3,4,5))},
        controlled='Identical initial books/states, frozen source, train indices/order, loss, inverse network, updates and generator schedule; only encoding residual changes',
        encoding_conditioning='Linear residual input uses fixed 1/sqrt(66560) gain to avoid zero-initialized full-width Adam overshoot; expressivity remains linear',
        scope='Phase1 encoder screening at D1024. No future labels, no independent test, no raw-feature decoder bypass. All states represent one complete window.',
        objective_note='Deterministic frozen teacher source; original reconstruction losses unchanged, constant teacher KL excluded',
        stage_note='Small-fit diagnostic weights are discarded before matched main training. 128 codec-only + 896 codec/generator steps.',
        next_stage='After reviewing common-step results, select encoding and run D1024/512/256; quantity-loss ablations remain separate')
    atomic_json(root / 'plan.json', plan)
    rng = np.random.default_rng(42)
    positions = np.unique(np.linspace(0,8191,32,dtype=int))
    np.save(root / 'small_positions.npy', positions)
    np.save(root / 'small_order.npy', np.concatenate([rng.permutation(positions) for _ in range(plan['small_steps'])]))
    rng = np.random.default_rng(42)
    np.save(root / 'train_order.npy', np.concatenate([rng.permutation(8192) for _ in range(8)]))
    atomic_json(root / 'cache_audit.json', dict(source_encoder_and_fusion_exact=True,
        matched_tensors=len(source_keys), basis_sha256=digest(parent/'pca_basis_qr.pt'),
        fit_indices_sha256=digest(parent/'fit_indices.npy'), source_fit_windows=8192,
        fit_period=old['train'], cache_precision='strict_fp32', independent_test_used=False))
    freeze_sources(root / 'source_snapshot')
    for file in (project/'tests').glob('test_*.py'):
        target=root/'source_snapshot/tests'/file.name
        target.parent.mkdir(exist_ok=True)
        shutil.copy2(file,target)
    remote='/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e/checkpoints/'+name
    (root/'train.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\nROOT="'+remote+'"\n'
        'export PYTHONPATH="$ROOT/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\n'
        'cd "$ROOT/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.learned_state_run "$ROOT"\n')
    atomic_json(root/'status.json', dict(state='prepared', phase='small'))
    Path('/tmp/learned_state_run_path').write_text(str(root))
    print(root,flush=True)


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root',type=Path)
    parser.add_argument('--prepare',action='store_true')
    parser.add_argument('--lane',choices=LANES)
    parser.add_argument('--phase',choices=('small','main'),default='main')
    args=parser.parse_args()
    if args.prepare:prepare(args.root)
    elif args.lane:worker(args.root,args.lane,args.phase)
    else:campaign(args.root)
