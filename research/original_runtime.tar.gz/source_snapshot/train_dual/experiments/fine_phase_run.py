"""Conditional full-model ordered-quantity Encoder controls after Decoder studies."""
import argparse
import html
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import numpy as np
import torch
from torch.nn import functional as F

from model.autoencoder.fine_phase_vae import FinePhaseOrderBookVAE
from train_dual.experiments import local_hint_run as shared
from train_dual.experiments.fine_phase_preflight import SWITCHES
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.goal_evaluate import assess_file
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.mid_delta_run import criterion
from train_dual.experiments.phase_detail_report import read, STYLE
from train_dual.experiments.price_safe_readout import file_hash
from train_dual.experiments.recall_goal_run import candidates, record, render as render_goal
from train_dual.experiments.region_task_run import gpu_free
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import atomic_save, freeze_sources, load_for_inference, seed_everything
from train_dual.util.hint_training import restore_fine_phase_adam
from train_dual.util.phase_training import tensor_digest


LABELS=dict(control_linear='路径关·linear控制',linear='路径开·linear',control_log='路径关·log控制',log='路径开·log1p')


def render(root):
    plan=read(root/'plan.json');state=read(root/'status.json',{})
    text='<h1>Encoder内部逐档数量路径：开关 × 数量变换</h1><p>完整256分钟、唯一64×128Gaussian不变。新路径4096→256→32仅加入原Encoder均值，两个Decoder、上采样与损失保持原样。全部原模型模块继续训练，无Encoder→Decoder旁路。</p><p>四组使用相同原始round004/source.pt、原Adam/RNG、1024训练窗/抽样/增强/teacher、seed42及2048更新。新增1065248参数初始输出为0，全部来源输出相同；原两组Adam完整保留，新第三组初始为空。禁用的两个控制是同种子重复实现核验，不用于估计跨种子方差。</p>'
    if plan.get('queue_only'):
        text+='<p>等待共享与区域Decoder对照正常完成。已有合格原生候选则跳过并优先确认。CPU预检已过；实际GPU零初始化、BF16反向和非零路径新实例Z-only解码仍需在生产训练前通过。</p>'
    else:
        text+='<table><tr><th>组</th><th>进度</th><th>评估步</th><th>召回</th><th>精确率</th><th>价格RMSE</th><th>分钟变化RMSE</th><th>通过</th></tr>'
        for step in [0,*plan['checkpoints']]:
            for lane,label in LABELS.items():
                path=root/lane/f'step{step}_development.json'
                if not path.exists():continue
                d=assess_file(path,root.parent/'reference_evaluation.json');progress=read(root/lane/'progress.json',{})
                values=[label,progress.get('step',0),step,d['recall100'],d['precision100'],d['price_rmse'],d['mid_delta_rmse'],d['pass']]
                text+='<tr>'+''.join('<td>'+html.escape(f'{v:.6g}' if isinstance(v,float) else str(v))+'</td>' for v in values)+'</tr>'
        text+='</table><p>两个禁用控制在每个共同检查点，须逐值重放已完成round004/control的原参数、原两组Adam和开发指标。Q1开发已反复用于选型，不是独立测试；本轮不读取Q2。</p>'
    text+='<p>状态：'+html.escape(str(state))+'</p><p><a href="plan.json">协议</a> · <a href="status.json">进度</a> · <a href="../fine_phase_preflight/">CPU预检</a></p>'
    (root/'index.html').write_text('<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="30"><style>'+STYLE+'</style><main>'+text+'</main>')


def owned_controller_live(parent,pid,proc_root=Path('/proc')):
    try:args=(proc_root/str(pid)/'cmdline').read_bytes().split(b'\0')
    except FileNotFoundError:return False
    return b'train_dual.experiments.regional_phase_run' in args and os.fsencode(str(parent)) in args


def prepare_queue(goal,parent_pid,name='fine_phase_after'):
    audit=read(goal/'fine_phase_preflight/audit.json')
    if not audit or not audit['passed'] or audit['raw_shape']!=[1,256,2,2048,2] or audit['optimizer_updates']!=0:
        raise ValueError('Need complete actual full-window CPU preflight')
    project=Path(__file__).resolve().parents[2]
    for source_name,digest in read(goal/'fine_phase_preflight/source_snapshot/sha256.json').items():
        if source_name.startswith('model/') and file_hash(project/source_name)!=digest:
            raise ValueError('Model implementation changed since actual CPU preflight: '+source_name)
    if Path(name).name!=name or not name.startswith('fine_phase_after'):
        raise ValueError('Need a simple owned fine_phase_after queue name')
    root=goal/name;root.mkdir();(root/'logs').mkdir()
    atomic_json(root/'plan.json',dict(queue_only=True,parent_queue='regional_phase_linear_after',parent_pid=parent_pid,
        parent='round_005_regional_phase',matched_source='round_004_local_phase',wait_seconds=39*3600,
        steps=2048,checkpoints=[256,512,1024,2048],max_seconds=43200,seed=42,
        source_sha256=read(goal/'fine_phase_preflight/plan.json')['source_sha256'],
        controls='Only Encoder fine route gate x linear/log1p features; same initial source/Adam/RNG/data/augmentation/teacher/loss/budget. Both disabled controls replay round004/control original states and metrics at0/256/512/1024/2048.',
        skip_if='Any qualified native development candidate; confirmation takes priority. Predecessor skipped or failed is not permission to launch.') )
    atomic_json(root/'status.json',dict(state='prepared_not_started'))
    freeze_sources(root/'source_snapshot');render(root)
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 CUDA_DEVICE_ORDER=PCI_BUS_ID OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.fine_phase_run "{remote}" --controller >> "{remote}/logs/controller.log" 2>&1\n')
    record(goal,'fine_phase_queue_prepared',root=root.name,parent_pid=parent_pid,steps=2048,source='Unchanged original shared source; source Adam/RNG and controls retained')
    print(root,flush=True)


def prepare_actual(queue):
    goal=queue.parent;study=read(queue/'plan.json');parent=goal/study['matched_source'];old=read(parent/'plan.json')
    if file_hash(parent/'source.pt')!=study['source_sha256']:raise ValueError('Changed declared original source')
    root=goal/'round_006_fine_phase';root.mkdir()
    for name in ['data','logs','seen','unseen',*LABELS]:(root/name).mkdir()
    for split in ['seen','unseen']:
        for lane in LABELS:(root/split/lane).mkdir()
    for name in ['source.pt','teacher.pt','calibration.json','train_indices.npy','val_indices.npy','seen_indices.npy','unseen_indices.npy','calibration_indices.npy','plotly.min.js']:os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    payload=torch.load(root/'source.pt',map_location='cpu',weights_only=False)
    assert payload['epoch_boundary'] and len(payload['optimizer']['param_groups'])==2
    extra={};digest=None
    for lane,(enabled,transform) in SWITCHES.items():
        config=dict(payload['local_hint_config'],fine_enabled=enabled,fine_transform=transform,fine_hidden=256)
        model=FinePhaseOrderBookVAE(**config,**payload['unified_vae_config'])
        missing,unexpected=model.load_state_dict(payload['model'],strict=False)
        assert len(missing)==6 and all(n.startswith('encoder.fine_phase.') for n in missing) and not unexpected
        actual=tensor_digest(model);digest=actual if digest is None else digest;assert digest==actual
        optimizer=restore_fine_phase_adam(model,payload['optimizer'],old['original_parameter_names'])
        assert len(optimizer.param_groups)==3 and all(p not in optimizer.state for p in model.encoder.fine_phase.parameters())
        policy=dict(cudnn_deterministic=True,cudnn_benchmark=False,tf32=False)
        extra[lane]=dict(fine_phase_config=config,training_numeric_policy=policy,inference_numeric_policy=policy)
        atomic_save(dict(format_version=1,model=model.state_dict(),unified_vae_config=payload['unified_vae_config'],local_hint_config=payload['local_hint_config'],fine_phase_config=config,config=payload['config'],step=0),root/lane/'initial.pt')
    base=dict(old['lanes']['control']);base.pop('gradient_module_flags',None);base.pop('gradient_parameter_flags',None)
    plan=dict(old);plan.update(experiment='Single Encoder ordered quantity mean residual: enabled x linear/log1p',labels=LABELS,
        lanes={lane:dict(base,gradient_module_flags={'encoder.fine_phase':enabled},gradient_parameter_flags={}) for lane,(enabled,transform) in SWITCHES.items()},
        initial_model_sha256=digest,checkpoint_extras=extra,source=str(root/'source.pt'),source_sha256=study['source_sha256'],
        source_steps=payload['source_steps']+payload['step'],steps=study['steps'],checkpoints=study['checkpoints'],max_seconds=study['max_seconds'],
        loss_variant='fine_Encoder_route_2x2',gpu_workers=[[g,l] for g,l in zip([2,3,4,5],LABELS)],worker_module='train_dual.experiments.fine_phase_run',
        goal_root=str(goal),matched_shared_root=str(parent),controls=study['controls'],readout_family='original_no_extension',
        fine_Encoder_parameters=1065248,readout_parameters=0,
        additional_controls='All1065248newparameters belong toEncoder; both disabled controls have no active extension. OriginalDecoder andoriginal loss retained. Only fine route gate andlinear/log1p features vary.',
        report=dict(title='Encoder内部逐档数量路径：开关 × 特征变换',scope='唯一8192Gaussian，全部原模块训练，仅Encoder有序数量残差路径不同。'),
        preview_descriptions={lane:'固定反复使用的Q1开发窗；完整256分钟、唯一8192神经Z。仅Encoder逐档数量路径开关/特征变换对照，无独立测试。' for lane in LABELS})
    atomic_json(root/'plan.json',plan)
    for split in ['seen','unseen']:
        atomic_json(root/split/'plan.json',dict(plan,preview_descriptions={lane:'训练年代诊断，非独立样本外测试。完整256分钟、唯一8192神经Z。' for lane in LABELS}));os.link(root/'plotly.min.js',root/split/'plotly.min.js')
    atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot');render(root)
    return root


def gpu_preflight(root):
    torch.set_num_threads(4);seed_everything(42);strict_precision();plan=read(root/'plan.json');folder=root/'gpu_preflight';folder.mkdir()
    original,norm=load_for_inference(root/'source.pt','cuda:0');original.eval();data=dataset(root,'train');index=int(np.load(root/'train_indices.npy')[0])
    raw={k:v.unsqueeze(0) for k,v in data[index].items()};b=norm.prepare(raw,'cuda:0')
    offset=int(data.base.starts[index]);times=data.base.times[offset:offset+256]
    assert list(raw['data'].shape)==[1,256,2,2048,2] and np.all(np.diff(times//60_000_000)==1)
    model,_=load_for_inference(root/'log/initial.pt','cuda:0');model.eval()
    seen=[];hooks=[m.register_forward_pre_hook(lambda m,a:seen.append(a[0])) for m in [model.price_decoder,model.volume_decoder]]
    with torch.no_grad():reference=call(original,b,False);out=call(model,b,False)
    for hook in hooks:hook.remove()
    assert seen[0] is seen[1] is out['z'] and list(out['z'].shape)==[1,64,128] and list(out['volume'].shape)==[1,256,2,2048]
    for key in ['mu','logvar','z','price_norm','volume']:torch.testing.assert_close(out[key],reference[key],rtol=0,atol=0)
    model.train()
    with torch.autocast('cuda',dtype=torch.bfloat16):training=call(model,b,False)
    loss=F.smooth_l1_loss(training['volume'][b['mask']]/plan['normalization']['quantity_scale'],b['volume'][b['mask']]/plan['normalization']['quantity_scale'])+F.smooth_l1_loss(training['price_norm'][b['mask']],b['price'][b['mask']])
    assert bool(torch.isfinite(loss));loss.backward()
    grad=float(model.encoder.fine_phase.output.weight.grad.float().norm());assert grad>0 and np.isfinite(grad)
    for name,param in original.named_parameters():torch.testing.assert_close(model.get_parameter(name).detach(),param.detach(),rtol=0,atol=0)
    # Deliberate nonzero private test weights; never used as production init.
    with torch.no_grad():model.encoder.fine_phase.output.weight.add_(.001)
    model.eval()
    with torch.no_grad():changed=call(model,b,False)
    assert not torch.equal(changed['mu'],reference['mu'])
    payload=torch.load(root/'log/initial.pt',map_location='cpu',weights_only=False);payload.update(model=model.state_dict(),diagnostic_only=True)
    atomic_save(payload,folder/'nonzero_route.pt');fresh,_=load_for_inference(folder/'nonzero_route.pt','cuda:0');fresh.eval()
    def forbidden(*args):raise AssertionError('Fresh decode called Encoder')
    hook=fresh.encoder.register_forward_pre_hook(forbidden)
    with torch.no_grad():decoded=fresh.decode(changed['z'],b['mask'],b['tick_norm'],b['times'])
    hook.remove()
    for key in ['price_norm','volume']:torch.testing.assert_close(decoded[key],changed[key],rtol=0,atol=0)
    atomic_json(folder/'audit.json',dict(passed=True,raw=[1,256,2,2048,2],posterior=[1,64,128],output=[1,256,2,2048],shared_Z=True,source_zero_exact=True,BF16_full_model_branch_gradient=grad,fresh_nonzero_Z_only_decode_exact=True,optimizer_updates=0,production_initials_not_modified=True))


def audit_controls(root):
    plan=read(root/'plan.json');parent=Path(plan['matched_shared_root'])
    for lane in ['control_linear','control_log']:
        for step in [0,*plan['checkpoints']]:
            marker=root/lane/f'step{step}_source_control_audit.json';path=root/lane/f'step{step}.pt';evaluation=root/lane/f'step{step}_development.json'
            if marker.exists() or not path.exists() or not evaluation.exists():continue
            old=torch.load(parent/'control'/f'step{step}.pt',map_location='cpu',weights_only=False)
            new=torch.load(path,map_location='cpu',weights_only=False)
            expected={n:v for n,v in old['model'].items() if not n.startswith('local_readout.')}
            actual={n:v for n,v in new['model'].items() if not n.startswith('encoder.fine_phase.')}
            assert actual.keys()==expected.keys()
            for name,value in expected.items():torch.testing.assert_close(actual[name],value,rtol=0,atol=0)
            assert new['optimizer']['param_groups'][:2]==old['optimizer']['param_groups'][:2]
            assert new['optimizer']['state'].keys()==old['optimizer']['state'].keys()
            for index,state in old['optimizer']['state'].items():
                for key,value in state.items():
                    if torch.is_tensor(value):torch.testing.assert_close(new['optimizer']['state'][index][key],value,rtol=0,atol=0)
                    else:assert new['optimizer']['state'][index][key]==value
            from train_dual.experiments.confirm_recall_goal import require_matching_replay
            require_matching_replay(read(evaluation)['result'],read(parent/'control'/f'step{step}_development.json')['result'])
            atomic_json(marker,dict(passed=True,source_model_and_original_Adam_exact=True,development_metrics_replayed=True,ignored_inactive_extension_parameters_only=True,
                checkpoint_sha256=file_hash(path),source_control_checkpoint_sha256=file_hash(parent/'control'/f'step{step}.pt')))


def audit_startup(root):
    rows={lane:read(root/lane/'step1_data_audit.json') for lane in LABELS}
    if not all(rows.values()) or not all((root/lane/'step8_gradient_audit.json').exists() for lane in LABELS):return False
    first=rows['control_linear']
    for lane,row in rows.items():
        assert row==first
        assert read(root/lane/'actual_shape_contract.json')['passed']
        assert read(root/lane/'restore_audit.json')['restored_groups']==3
    old=read(Path(read(root/'plan.json')['matched_shared_root'])/'control/step1_data_audit.json')
    assert first==old
    atomic_json(root/'startup_control_audit.json',dict(passed=True,source_model_Adam_RNG_data_replayed=True,all_first_losses_inputs_and_edits_exact=True,full_single_Z_shape_and_enabled_branch_gradients_passed=True))
    return True


def run_cohort(root):
    children=[];plan=read(root/'plan.json');start=time.monotonic();audited=False
    try:
        for gpu,lane in plan['gpu_workers']:
            env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),PYTHONPATH=str(root/'source_snapshot'))
            with (root/'logs'/f'{lane}.log').open('ab',buffering=0) as log:
                child=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.fine_phase_run',str(root),'--lane',lane],cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            children.append(child)
        atomic_json(root/'status.json',dict(state='running',pids=[p.pid for p in children]))
        while any(p.poll() is None for p in children):
            if any(p.poll() not in [None,0] for p in children):raise RuntimeError('Owned fine Encoder worker failed; preserve all controls')
            if time.monotonic()-start>plan['max_seconds']+1800:raise TimeoutError('12hourtraining plus30minevaluation ceiling')
            if not audited:audited=audit_startup(root)
            audit_controls(root);render(root);time.sleep(10)
        if any(p.returncode for p in children) or not (audited or audit_startup(root)):raise RuntimeError('Missing completed fine Encoder startup/worker audit')
        audit_controls(root)
        for lane in ['control_linear','control_log']:
            assert all((root/lane/f'step{step}_source_control_audit.json').exists() for step in [0,*plan['checkpoints']])
        atomic_json(root/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-start));render(root)
    finally:
        for child in children:
            if child.poll() is None:os.killpg(child.pid,signal.SIGTERM)


def controller(queue):
    config=read(queue/'plan.json');goal=queue.parent;parent=goal/config['parent'];parent_queue=goal/config['parent_queue'];start=time.monotonic()
    while True:
        state=read(parent_queue/'status.json',{});live=owned_controller_live(parent_queue,config['parent_pid'])
        if state.get('state')=='failed':raise RuntimeError('Regional predecessor failed; do not launch new cohort')
        if not live:
            if state.get('state','').startswith('not_run_'):
                atomic_json(queue/'status.json',dict(state='not_run_predecessor_skipped',predecessor=state));render(queue);return
            if state.get('state')=='complete' and read(parent/'status.json',{}).get('state')=='complete':break
            raise RuntimeError('Verified predecessor handle missing without terminal completion')
        if time.monotonic()-start>config['wait_seconds']:raise TimeoutError('Declared predecessor wait ceiling')
        atomic_json(queue/'status.json',dict(state='verified_wait_parent',pid=os.getpid(),parent_pid=config['parent_pid'],predecessor_state=state.get('state')));render(queue);time.sleep(20)
    if (goal/'candidate_for_confirmation.json').exists() or any(row['pass'] for row in candidates(parent,goal/'reference_evaluation.json')):
        atomic_json(queue/'status.json',dict(state='not_run_candidate_for_confirmation'));render(queue);return
    while any(gpu_free().get(g,0)<47000 for g in [2,3,4,5]):
        if time.monotonic()-start>config['wait_seconds']:raise TimeoutError('GPU release wait ceiling')
        atomic_json(queue/'status.json',dict(state='verified_wait_GPU_release',pid=os.getpid()));render(queue);time.sleep(10)
    root=prepare_actual(queue);atomic_json(queue/'status.json',dict(state='GPU_preflight',pid=os.getpid(),wave=root.name));render(queue)
    env=dict(os.environ,CUDA_VISIBLE_DEVICES='2',PYTHONPATH=str(root/'source_snapshot'))
    with (root/'logs/gpu_preflight.log').open('ab',buffering=0) as log:
        result=subprocess.run([sys.executable,'-u','-m','train_dual.experiments.fine_phase_run',str(root),'--gpu-preflight'],cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=3600)
    if result.returncode or not read(root/'gpu_preflight/audit.json',{}).get('passed'):raise RuntimeError('Fine Encoder actual GPU preflight failed before production updates')
    atomic_json(queue/'status.json',dict(state='running',pid=os.getpid(),wave=root.name));atomic_json(goal/'status.json',dict(state='running_fine_Encoder_controlled_cohort',wave=root.name));render(queue)
    run_cohort(root)
    rows=candidates(root,goal/'reference_evaluation.json');old=read(goal/'candidates.json',{}).get('rows',[])
    atomic_json(goal/'candidates.json',dict(rows=[r for r in old if r.get('experiment')!=root.name]+[dict(row,experiment=root.name) for row in rows]))
    common=set.intersection(*[{row['step'] for row in rows if row['lane']==lane} for lane in LABELS]);passing=[row for row in rows if row['step'] in common and row['pass']]
    if passing:
        chosen=max(passing,key=lambda row:(row['recall100'],-row['price_rmse']));atomic_json(goal/'candidate_for_confirmation.json',chosen)
        atomic_json(goal/'status.json',dict(state='development_pass_requires_independent_confirmation',candidate=chosen))
    else:atomic_json(goal/'status.json',dict(state='cohort_complete_next_hypothesis_required',wave=root.name,goal_achieved=False))
    atomic_json(queue/'status.json',dict(state='complete',wave=root.name,goal_automatically_completed=False));render(queue);render_goal(goal)
    record(goal,'fine_phase_cohort_complete',root=root.name,qualified_development_candidates=len(passing),independent_confirmation_not_automatic=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--name',default='fine_phase_after');p.add_argument('--parent-pid',type=int);p.add_argument('--controller',action='store_true');p.add_argument('--gpu-preflight',action='store_true');p.add_argument('--lane',choices=list(LABELS));args=p.parse_args();root=args.root.resolve()
    def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        if args.prepare:
            if not args.parent_pid:p.error('--parent-pid required for verified queue')
            prepare_queue(root,args.parent_pid,args.name)
        elif args.gpu_preflight:gpu_preflight(root)
        elif args.lane:shared.worker(root,args.lane,objective_factory=criterion,optimizer_factory=restore_fine_phase_adam)
        elif args.controller:controller(root)
    except BaseException as error:
        if not args.prepare:atomic_json((root/args.lane if args.lane else root)/'status.json',dict(state='failed',pid=os.getpid(),error=repr(error)))
        raise
