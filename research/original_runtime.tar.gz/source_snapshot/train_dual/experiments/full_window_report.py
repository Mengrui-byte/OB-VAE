"""Live256minute experiment monitor and automatic common-step book previews."""

import argparse
from datetime import datetime,timezone
import json
from pathlib import Path
import time
import zipfile

import numpy as np

from train_dual.experiments.book_stem_viewer import build
from train_dual.experiments.long_worker import atomic_json


PAGE='''<!doctype html><html lang=zh-CN><meta charset=utf-8><title>256分钟双分支实验</title><script src=plotly.min.js></script><style>body{font:16px system-ui;max-width:1500px;margin:28px auto;padding:0 20px;line-height:1.8}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ddd;padding:8px}.plots{display:grid;grid-template-columns:1fr 1fr}a{color:#2563eb}</style><h1>完整256分钟：双分支与整窗矩阵压缩</h1><p>实际输入[B,256,2,2048,2]，每分钟一帧；三个压缩组整窗latent均为[B,16,1024]，完整输出256帧。编码器与Cross先处理完整窗口，再学习通道压缩和有序16帧分组投影，生成时恢复256帧。全窗仅使用首帧mid锚点，没有每16分钟重新初始化锚点。</p><p>源权重曾在16分钟窗口训练，本轮仅作为初始化，所有模块在256分钟数据上端到端更新。64个抽样训练窗、同16个2025Q1开发窗、seed42、每卡batch1×累积4、512次更新；BF16训练，FP32评估。32/128/256/512步保存并报告，2026不参与本轮训练或选型。开发集已用于研究，不能当作最终独立测试。未量化、未用未来收益。</p><p id=status>加载</p><p><a href=books/>查看已发布的256分钟逐档重建</a> · <a href=previous/>上一轮16分钟结果</a> · <a href=plan.json>完整配置</a> · <a href=progress.json>完整进度</a></p><p id=preview>尚无共同检查点重建图；此链接在首个共同检查点就绪后启用。</p><h2>实时训练</h2><table><thead><tr><th>GPU</th><th>方案</th><th>状态</th><th>进度</th><th>已用秒</th><th>实际输入帧</th><th>实际矩阵</th></tr></thead><tbody id=lanes></tbody></table><h2>同一批16个开发窗口</h2><table><thead><tr><th>方案</th><th>步数</th><th>价格RMSE USDT</th><th>挂量RMSE BTC</th><th>分钟挂量变化相关</th><th>≥100BTC召回</th></tr></thead><tbody id=results></tbody></table><div class=plots><div id=quantity></div><div id=loss></div></div><h2>首步实际梯度范数</h2><table><thead><tr><th>模型</th><th>模块</th><th>梯度范数（裁剪前）</th></tr></thead><tbody id=gradients></tbody></table><script>const f=(x,n=3)=>Number.isFinite(x)?x.toFixed(n):'—';function row(xs){let r=document.createElement('tr');for(let x of xs){let c=document.createElement('td');c.textContent=x;r.append(c)}return r}async function refresh(){let d=await(await fetch('progress.json?t='+Date.now())).json();document.getElementById('status').textContent='状态：'+d.status.state+(d.basis?'；256分钟初始化样本 '+d.basis.windows+'/'+d.basis.total:'');document.getElementById('preview').textContent=d.preview?'当前逐档图：共同'+d.preview.step+'步，完整256帧可播放。':'共同检查点尚未就绪，暂不展示旧短窗口作为当前结果。';let lanes=[],results=[],gradients=[],q=[],loss=[],gpu=2;for(let [key,label] of Object.entries(d.labels)){let x=d.lanes[key],p=x.progress||{},s=x.shapes||{};lanes.push(row([gpu++,label,x.status?.state||'等待',p.step?p.step+'/'+p.total:'初始化',f(p.elapsed_seconds,1),s.raw_input?.[1]||'待实测',s.matrix?JSON.stringify(s.matrix):key==='reference'?'未压缩参考':'待实测']));let history=Object.entries(x.evaluations).sort((a,b)=>+a[0]-+b[0]);for(let [step,v] of history){let m=v.metrics,t=v.thresholds['100'];results.push(row([label,step,f(m.price_usdt.rmse),f(m.quantity_btc.rmse),f(m.temporal_log_quantity_1_minutes.correlation),f(t.recall===null?null:t.recall*100,1)+'%']))}q.push({name:label,x:history.map(x=>+x[0]),y:history.map(x=>x[1].metrics.quantity_btc.rmse),mode:'lines+markers'});loss.push({name:label,x:x.history.map(x=>x.step),y:x.history.map(x=>x.loss),mode:'lines'});for(let [k,v] of Object.entries(x.gradients||{}))gradients.push(row([label,k,f(v)]))}document.getElementById('lanes').replaceChildren(...lanes);document.getElementById('results').replaceChildren(...results);document.getElementById('gradients').replaceChildren(...gradients);for(let [id,data,title] of [['quantity',q,'开发集挂量RMSE BTC'],['loss',loss,'训练损失']])Plotly.react(id,data,{title,height:360,template:'plotly_white',xaxis:{title:'优化步数'}},{responsive:true,displaylogo:false})}refresh().catch(console.error);setInterval(()=>refresh().catch(console.error),10000)</script></html>'''


def publish(root,step,previous):
    plan=json.loads((root/'plan.json').read_text());folder=root/'previews'/f'step{step}';folder.mkdir(parents=True)
    arrays={};variants=[dict(key='truth',label='真实订单簿',color='#2563eb')]
    with np.load(root/'source_profiles.npz') as p:
        arrays.update({k:p[k] for k in ('truth','mask','time','indices')});arrays['source']=p['prediction']
    variants.append(dict(key='source',label=plan.get('viewer_source_label','原Cross权重·256分钟直接推理'),color='#64748b'))
    for (lane,label),color in zip(plan['labels'].items(),['#eab308','#db2777','#2563eb','#16a34a']):
        with np.load(root/lane/f'step{step}_profiles.npz') as p:
            np.testing.assert_array_equal(p['truth'],arrays['truth']);np.testing.assert_array_equal(p['time'],arrays['time']);arrays[lane]=p['prediction']
        variants.append(dict(key=lane,label=label+f'·{step}步',color=color))
    np.savez_compressed(folder/'profiles.npz',**arrays)
    description=plan.get('viewer_description','完整256分钟订单簿重建：训练2022–2024，展示2025Q1开发窗口。输入256帧，三个压缩模型的整窗latent为16×1024，重建全部256帧；未压缩参考保留原全长latent。本轮全模型训练，源16分钟权重仅用于初始化。样本已用于开发选型，不能视为最终独立测试；任务是输入窗口重建。')
    atomic_json(folder/'comparison.json',dict(viewer_variants=variants,default_model=plan.get('viewer_default_model',4),seed=42,common_step=step,chunk_windows=True,
        step_note=f'共同{step}步；'+plan.get('viewer_step_note','完整256分钟输入及输出；三个压缩组latent16×1024。'),comparison_label='256分钟训练指标与进度',evaluation_period=['2025-01-01','2025-04-01'],evaluation_description=description,evaluation_role='256minute development reconstruction',used_for_model_selection=True))
    (folder/'index.html').write_text('<!doctype html><meta charset=utf-8><meta http-equiv=refresh content="0;url=../full256/">')
    viewer=folder/'viewer';build(folder,viewer);(viewer/'full256').symlink_to(root/'public',target_is_directory=True);(viewer/'previous').symlink_to(previous,target_is_directory=True)
    if 'local_shape' in plan:(viewer/'merge_local').symlink_to(root/'public',target_is_directory=True)
    if plan.get('viewer_route'):(viewer/plan['viewer_route']).symlink_to(root/'public',target_is_directory=True)
    public=root/'public';old=public/'books';temp=public/'books.tmp'
    if temp.is_symlink():temp.unlink()
    temp.symlink_to(viewer,target_is_directory=True);temp.replace(old)
    selector=root.parents[1]/'.local/dual_viewer/current.json';atomic_json(selector,dict(directory=str(viewer)))
    value=dict(step=step,directory=str(viewer));atomic_json(root/'preview_published.json',value);return value


def monitor(root,page=None):
    from plotly.offline import get_plotlyjs
    root=root.resolve();plan=json.loads((root/'plan.json').read_text());public=root/'public';public.mkdir(exist_ok=True)
    selector=root.parents[1]/'.local/dual_viewer/current.json';previous=Path(json.loads(selector.read_text())['directory'])
    (public/'index.html').write_text(page or PAGE);(public/'plotly.min.js').write_text(get_plotlyjs());(public/'plan.json').symlink_to(root/'plan.json');(public/'previous').symlink_to(previous,target_is_directory=True)
    link=previous/plan.get('viewer_route','full256')
    if not link.exists() and not link.is_symlink():link.symlink_to(public,target_is_directory=True)
    else:
        link=previous/'merge_local'
        if not link.exists() and not link.is_symlink():link.symlink_to(public,target_is_directory=True)
    preview=None
    while True:
        status=json.loads((root/'status.json').read_text());lanes={}
        for lane in plan['lanes']:
            data=dict(evaluations={},history=[])
            for key,name in [('status','status.json'),('progress','progress.json'),('gradients','first_step_gradient_norms.json'),('shapes','actual_shape_contract.json')]:
                p=root/lane/name
                if p.exists():data[key]=json.loads(p.read_text())
            for step in [0,*plan['checkpoints']]:
                p=root/lane/('initial_evaluation.json' if step==0 else f'step{step}_evaluation.json')
                if p.exists():data['evaluations'][str(step)]=json.loads(p.read_text())['result']
            p=root/lane/'progress.jsonl'
            if p.exists():
                for line in p.read_text().splitlines():
                    try:data['history'].append(json.loads(line))
                    except ValueError:pass
            lanes[lane]=data
        basis=root/'basis_progress.json'
        if not basis.exists():basis=root/'teacher_progress.json'
        def complete(path):
            try:
                with zipfile.ZipFile(path) as archive:return 'prediction.npy' in archive.namelist()
            except (OSError,zipfile.BadZipFile):return False
        ready=[step for step in plan['checkpoints'] if (preview is None or step>preview['step']) and all(complete(root/lane/f'step{step}_profiles.npz') for lane in plan['lanes'])]
        if ready:preview=publish(root,max(ready),previous)
        atomic_json(public/'progress.json',dict(utc=datetime.now(timezone.utc).isoformat(),status=status,labels=plan['labels'],lanes=lanes,basis=json.loads(basis.read_text()) if basis.exists() else None,preview=preview))
        if status['state'] in ('complete','failed','partial_failure','stopped_by_user'):break
        time.sleep(10)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);monitor(p.parse_args().root)
