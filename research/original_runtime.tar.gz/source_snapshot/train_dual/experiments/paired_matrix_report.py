"""Browser report for unweighted ordered-pair matrix quantization."""

import argparse
from datetime import datetime,timezone
import json
from pathlib import Path
import time

import numpy as np

from train_dual.experiments.book_stem_viewer import build


LABELS={'joint_l2':'共享索引·乘积L2','joint_max':'共享索引·乘积L∞','independent16':'独立16码·同64位','independent256':'独立256码·128位参考'}
PAGE='''<!doctype html><html lang=zh-CN><meta charset=utf-8><title>双矩阵码字：无权重乘积距离</title><script src=plotly.min.js></script><style>body{font:16px system-ui;max-width:1500px;margin:30px auto;padding:0 20px;color:#162235}p{line-height:1.8}table{border-collapse:collapse;width:100%}td,th{padding:9px;border:1px solid #ddd;text-align:left}.plots{display:grid;grid-template-columns:1fr 1fr}select{font:inherit;padding:5px}a{color:#2563eb}</style>
<h1>双矩阵码字：Global和Local共享同一个索引</h1><p>从恢复最好的未压缩Cross模型出发，直接量化进入解码器的G[16,64]与L[16,4096]。每级码字为有序对(CG,CL)，两个矩阵形状不同，同一索引同时选出两者。没有1024维聚合或新的连续自编码器瓶颈。</p>
<p><b>无权重、无逐路缩放。</b> Eg=||G−CG||F²，El=||L−CL||F²；乘积L2距离=sqrt(Eg+El)，乘积L∞距离=max(sqrt(Eg),sqrt(El))。训练期均值仅作为所有窗口共享的平移，不按维数/方差归一化。矩阵大小和原始尺度的影响保留并单独展示。</p>
<p id=status>准备中</p><p><a href=./>逐档重建线图</a> · <a href=previous/>上一轮量化</a> · <a href=pair_plan.json>完整配置</a></p>
<table><thead><tr><th>GPU</th><th>方法</th><th>阶段</th><th>残差级</th><th>迭代</th><th>总索引位数</th><th>显存GiB</th></tr></thead><tbody id=progress></tbody></table>
<p>共享256码：8级共64位；独立16码：每级两路各4位，同样64位，但码本小16倍；独立256码：码本标量数与共享256相同，但索引128位。均未位打包，码本、源模型和元数据开销另计。源模型权重固定，所有码本仅用8192个训练窗口拟合，种子42。</p>
<h2>两路残差</h2><p>先看未经缩放的原始能量；归一到各自初始能量的曲线仅用于展示，没有参与距离计算。没有额外零码，开发窗口的某一级误差可能上升，照实显示。</p><div class=plots><div id=globalEnergy></div><div id=localEnergy></div><div id=globalRatio></div><div id=localRatio></div></div>
<h2>同一批128个开发窗口的重建</h2><p>2025年一季度开发数据，严格FP32。独立测试未使用。只量化G/L的行保留另一支原始连续latent，用于定位问题，不能视为完全压缩的模型。</p><table><thead><tr><th>方法</th><th>模式</th><th>索引位</th><th>价格RMSE USDT</th><th>数量RMSE BTC</th><th>64档斜率</th><th>分钟变化</th><th>≥100BTC召回</th></tr></thead><tbody id=book></tbody></table>
<h2>查看一个码字中的两个矩阵</h2><p><select id=variant><option value=joint_l2>共享索引·L2</option><option value=joint_max>共享索引·L∞</option><option value=independent16>独立16码</option><option value=independent256>独立256码</option></select></p><p id=prototypeNote></p><div class=plots><div id=globalCode></div><div id=localCode></div></div><p>Local图将每个深度位置的16通道取范数，横轴为买侧128个位置后接卖侧128个位置；这是latent码字的幅度，不是BTC挂量。</p>
<h2>码本使用</h2><table><thead><tr><th>方法</th><th>级别</th><th>路</th><th>训练使用数</th><th>训练困惑度</th><th>开发使用数</th><th>开发困惑度</th></tr></thead><tbody id=usage></tbody></table><small id=updated></small>
<script>const labels={joint_l2:'共享·L2',joint_max:'共享·L∞',independent16:'独立16',independent256:'独立256'},colors={joint_l2:'#2563eb',joint_max:'#9333ea',independent16:'#16a34a',independent256:'#f59e0b'};let d={};const n=(x,k=4)=>x==null?'—':x.toFixed(k);function row(a){let r=document.createElement('tr');for(let x of a){let c=document.createElement('td');c.textContent=x;r.append(c)}return r}function plot(id,traces,title,x,y){Plotly.react(id,traces,{template:'plotly_white',height:360,title,xaxis:{title:x},yaxis:{title:y},margin:{t:55,l:65,r:20,b:55}},{responsive:true,displaylogo:false})}
function draw(){for(let [idx,name] of [[0,'global'],[1,'local']])for(let ratio of [false,true]){let traces=[];for(let [lane,x] of Object.entries(d.lanes||{}))if(x.metrics){for(let [split,label,dash] of [['train','训练','solid'],['development','开发','dash']]){let e=x.metrics[split].residual_energy;traces.push({x:e.map((_,i)=>i),y:e.map(v=>ratio?v[idx]/Math.max(e[0][idx],1e-12):v[idx]),name:labels[lane]+label,mode:'lines+markers',line:{color:colors[lane],dash}})}}plot(name+(ratio?'Ratio':'Energy'),traces,(idx?'Local':'Global')+(ratio?' 剩余比例':' 原始Frobenius平方能量'),'级数',ratio?'相对初始能量':'平方能量')}
let lane=document.getElementById('variant').value,p=d.lanes?.[lane]?.preview;if(p){document.getElementById('prototypeNote').textContent=lane.startsWith('joint')?'第一级训练期最常见的联合码字，编号 '+p.code+'；左右两矩阵属于同一个码字。':'独立对照：展示两码本的编号0，它们不是共享索引的联合码字。';plot('globalCode',[{z:p.global,type:'heatmap',colorscale:'RdBu',zmid:0}],'Global码字矩阵','通道','窗口内时间');plot('localCode',[{z:p.local,type:'heatmap',colorscale:'Viridis'}],'Local码字的通道范数','侧/深度位置','窗口内时间')}}
async function refresh(){d=await(await fetch('pair_progress.json?t='+Date.now())).json();document.getElementById('status').textContent='状态：'+d.status.state+(d.status.error?'；'+d.status.error:'');let a=[],b=[],u=[];let i=2;for(let [lane,label] of Object.entries(labels)){let x=d.lanes[lane]||{},p=x.progress||{},bits=lane==='independent256'?128:64;a.push(row([i++,label,x.status?.state==='complete'?'已完成':p.phase||'等待',p.level??'—',p.iteration??'—',bits,n(p.reserved_gib,2)]));for(let [mode,r] of Object.entries(x.book||{})){let m=r.result.metrics,depth=r.depth||0,rate=mode==='original'?'连续':mode.endsWith('only')?'诊断':depth*(lane==='independent256'?16:8);b.push(row([label,mode,rate,n(m.price_usdt.rmse,3),n(m.quantity_btc.rmse),n(m.spatial_slope_64_levels_usdt_per_level.rmse,6),n(m.temporal_mid_1_minutes_usdt_per_minute.rmse,3),n(r.result.thresholds['100'].recall)]))}if(x.metrics)x.metrics.train.code_usage.forEach((v,j)=>Object.entries(v).forEach(([branch,z])=>{let q=x.metrics.development.code_usage[j][branch];u.push(row([label,j+1,branch,z.used_codes+'/'+z.size,n(z.perplexity,2),q.used_codes+'/'+q.size,n(q.perplexity,2)]))}))}document.getElementById('progress').replaceChildren(...a);document.getElementById('book').replaceChildren(...b);document.getElementById('usage').replaceChildren(...u);draw();document.getElementById('updated').textContent='更新：'+new Date(d.utc).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai'})}document.getElementById('variant').onchange=draw;refresh().catch(console.error);setInterval(()=>refresh().catch(console.error),10000)</script></html>'''


def final_report(root):
    plan=json.loads((root/'plan.json').read_text());results=json.loads((root/'comparison.json').read_text())
    folder=root/'report';folder.mkdir(exist_ok=True)
    with np.load(root/'source_profiles.npz') as p:
        arrays={k:p[k] for k in ('truth','mask','time','indices')};arrays['source']=p['prediction']
    config=[dict(key='truth',label='真实订单簿',color='#2563eb'),dict(key='source',label='未压缩Cross参考',color='#64748b')]
    selected=[('joint_l2','depth1','双矩阵L2·1级'),('joint_l2','depth2','双矩阵L2·2级'),('joint_l2','depth4','双矩阵L2·4级'),
        ('joint_l2','depth8','双矩阵L2·8级'),('joint_max','depth8','双矩阵L∞·8级'),('independent16','depth8','独立16码·同64位'),('independent256','depth8','独立256码·128位')]
    for (lane,stage,label),color in zip(selected,['#f97316','#eab308','#ef4444','#2563eb','#9333ea','#16a34a','#f59e0b']):
        key=lane+'_'+stage
        with np.load(root/lane/stage/'profiles.npz') as p:
            if not np.array_equal(p['truth'],arrays['truth']):raise ValueError('Matrix comparison windows differ')
            arrays[key]=p['prediction']
        config.append(dict(key=key,label=label,color=color))
    np.savez_compressed(folder/'profiles.npz',**arrays)
    (folder/'comparison.json').write_text(json.dumps(dict(seed=42,common_step=plan['fit_iterations'],viewer_variants=config,default_model=5,
        plan=plan,results=results,comparison_label='查看双矩阵距离、码字和指标',
        step_note='未压缩Cross被冻结；直接量化Global/Local有序对；无权重或逐路缩放。码本12轮/级，8个残差级。'),ensure_ascii=False))
    (folder/'index.html').write_text('<!doctype html><meta charset=utf-8><meta http-equiv=refresh content="0;url=../pair.html">')
    viewer=root/'viewer';build(folder,viewer)
    for name in ('pair.html','pair_plan.json','pair_progress.json'):(viewer/name).symlink_to(root/'public'/name)
    (viewer/'previous').symlink_to(root/'public/previous',target_is_directory=True)
    return viewer


def monitor(root):
    public=root/'public';public.mkdir(exist_ok=True)
    selector=root.parents[1]/'.local/dual_viewer/current.json';previous=Path(json.loads(selector.read_text())['directory'])
    (public/'pair.html').write_text(PAGE);(public/'pair_plan.json').symlink_to(root/'plan.json')
    (public/'previous').symlink_to(previous,target_is_directory=True)
    for name in ('index.html','book.f64','mask.u8','viewer.json','plotly.min.js','comparison'):
        source=previous/name
        if source.exists():(public/name).symlink_to(source,target_is_directory=source.is_dir())
    tmp=selector.with_suffix('.tmp');tmp.write_text(json.dumps(dict(directory=str(public))));tmp.replace(selector)
    while True:
        try:
            status=json.loads((root/'status.json').read_text());lanes={}
            for lane in LABELS:
                values={}
                for key,name in [('status','status.json'),('progress','progress.json'),('metrics','latent_metrics.json')]:
                    p=root/lane/name
                    if p.exists():values[key]=json.loads(p.read_text())
                values['book']={}
                for mode in ('original','depth1','depth2','depth4','depth8','global_only','local_only'):
                    p=root/lane/(mode+'_evaluation.json')
                    if p.exists():values['book'][mode]=json.loads(p.read_text())
                p=root/lane/'matrix_preview.npz'
                if p.exists():
                    with np.load(p) as v:values['preview']={'global':v['global_code'].tolist(),'local':v['local_code_norm'].reshape(16,256).tolist(),'code':int(v['code'])}
                lanes[lane]=values
            payload=dict(utc=datetime.now(timezone.utc).isoformat(),status=status,lanes=lanes)
            tmp=public/'pair_progress.json.tmp';tmp.write_text(json.dumps(payload));tmp.replace(public/'pair_progress.json')
            if status['state']=='complete':
                viewer=final_report(root);tmp=selector.with_suffix('.tmp');tmp.write_text(json.dumps(dict(directory=str(viewer))));tmp.replace(selector)
                (root/'published.json').write_text(json.dumps(dict(directory=str(viewer))));break
            if status['state'] in ('failed','stopped_by_user'):break
        except (FileNotFoundError,ValueError):pass
        except Exception as error:
            (root/'report_error.json').write_text(json.dumps(dict(error=repr(error))));raise
        time.sleep(10)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);monitor(p.parse_args().root)
