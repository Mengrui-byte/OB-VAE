"""Monitor/final analysis for full-tensor paired clustering controls."""

import argparse
from datetime import datetime,timezone
import json
from pathlib import Path
import time

from train_dual.experiments import small_codebook_analysis as analysis


LABELS={'kmeans_random':'K-means·随机初始化','kmeans_pp':'K-means++·均值原型',
        'pam_squared':'PAM·平方距离和','pam_distance':'PAM·距离和'}
PAGE='''<!doctype html><meta charset=utf-8><title>完整张量对聚类对照</title><style>body{font:17px system-ui;max-width:1400px;margin:30px auto;line-height:1.8}table{border-collapse:collapse;width:100%}td,th{padding:9px;border:1px solid #ddd}</style><h1>完整张量对：聚类方法对照</h1><p>每个码字CG[16,64]、CL[16,2,128,16]。每级一个整窗共享索引，8级×16码=32逻辑bit，码本32.5MiB；均值/模型/元数据另计。没有局部拆分、白化、分支距离权重、语义头或未来收益。PAM选择同一训练窗口的真实残差对，做全局最佳单次交换，最多12次/级；原型更新目标为距离和或平方距离和，选码最近邻一致。</p><p>种子42、同8192训练窗口、同128个2025Q1开发窗口；2025Q2未用。源模型冻结。所有预算终点都报告，不挑选未来收益。</p><p><a href=./>逐档挂单重建</a> · <a href=small.html>逐级自然分类分析（完成后）</a> · <a href=previous/>上一轮</a> · <a href=cluster_plan.json>配置</a></p><p id=status>加载</p><table><thead><tr><th>GPU</th><th>方法</th><th>状态</th><th>阶段</th><th>级别</th><th>轮数/交换数</th></tr></thead><tbody id=progress></tbody></table><h2>完整量化后的重建</h2><table><thead><tr><th>方法</th><th>前缀级数</th><th>价格RMSE USDT</th><th>数量RMSE BTC</th><th>分钟挂量变化相关</th><th>≥100BTC召回</th></tr></thead><tbody id=book></tbody></table><script>const labels={kmeans_random:'随机K-means',kmeans_pp:'K-means++',pam_squared:'平方距离PAM',pam_distance:'距离PAM'},f=x=>Number.isFinite(x)?x.toFixed(4):'—';function row(a){let r=document.createElement('tr');for(let x of a){let c=document.createElement('td');c.textContent=x;r.append(c)}return r}async function refresh(){let d=await(await fetch('cluster_progress.json?t='+Date.now())).json();document.getElementById('status').textContent='训练状态：'+d.status.state+'；分析：'+(d.analysis||'等待');let p=[],b=[],i=2;for(let [lane,label] of Object.entries(labels)){let x=d.lanes[lane]||{},g=x.progress||{};p.push(row([i++,label,x.status?.state||'等待',g.phase||'—',g.level||'—',g.iteration||g.swap||'—']));for(let [depth,v] of Object.entries(x.books||{})){let m=v.metrics;b.push(row([label,depth,f(m.price_usdt.rmse),f(m.quantity_btc.rmse),f(m.temporal_log_quantity_1_minutes.correlation),f(v.thresholds['100'].recall)]))}}document.getElementById('progress').replaceChildren(...p);document.getElementById('book').replaceChildren(...b)}refresh().catch(console.error);setInterval(()=>refresh().catch(console.error),10000)</script>'''


def analysis_page():
    page=analysis.PAGE.replace('小codebook自然分类','完整张量对聚类自然分类').replace('小codebook自然分出了什么？','完整张量对聚类：各级自然分出了什么？')
    page=page.replace('随机成对样本初始化、每级12轮、种子42保持一致','种子42保持一致；均值法12轮，PAM至多12次全局改善交换')
    page=page.replace('8级×8/16/32码分别24/32/40bit；16级×16码为64bit，与旧8级×256码索引码率相同，但码本大小、深度和计算路径不同。',
        '四组均为8级×16码，32逻辑bit/窗口，码字保持完整Global/Local形状；区别为初始化、均值或真实残差medoid，以及聚类优化目标。')
    return page.replace("$('variant').value='k16_l8'","$('variant').value='kmeans_pp'")


def monitor(root):
    root=root.resolve();public=root/'public';public.mkdir(exist_ok=True)
    selector=root.parents[1]/'.local/dual_viewer/current.json';previous=Path(json.loads(selector.read_text())['directory'])
    (public/'clustering.html').write_text(PAGE);(public/'cluster_plan.json').symlink_to(root/'plan.json')
    (public/'previous').symlink_to(previous,target_is_directory=True)
    for name in ('index.html','book.f64','mask.u8','viewer.json','plotly.min.js','comparison','audit.json'):
        source=previous/name
        if source.exists():(public/name).symlink_to(source,target_is_directory=source.is_dir())
    temp=selector.with_suffix('.tmp');temp.write_text(json.dumps(dict(directory=str(public))));temp.replace(selector)
    while True:
        status=json.loads((root/'status.json').read_text());lanes={}
        for lane in LABELS:
            value={};value['books']={}
            for key in ('status','progress'):
                p=root/lane/(key+'.json')
                if p.exists():value[key]=json.loads(p.read_text())
            for depth in ('original',1,2,4,8):
                p=root/lane/(('original' if depth=='original' else 'depth'+str(depth))+'_evaluation.json')
                if p.exists():value['books'][str(depth)]=json.loads(p.read_text())['result']
            lanes[lane]=value
        payload=dict(utc=datetime.now(timezone.utc).isoformat(),status=status,lanes=lanes)
        p=public/'cluster_progress.json';temp=p.with_suffix('.tmp');temp.write_text(json.dumps(payload));temp.replace(p)
        if status['state']=='complete':
            payload['analysis']='计算中';p.write_text(json.dumps(payload))
            analysis.main(root,labels=LABELS,page=analysis_page(),previous=previous)
            viewer=root/'viewer'
            for name in ('clustering.html','cluster_plan.json','cluster_progress.json'):(viewer/name).symlink_to(public/name)
            payload['analysis']='完成';p.write_text(json.dumps(payload));break
        if status['state']=='failed':break
        time.sleep(10)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);monitor(p.parse_args().root)
