"""Prepare a loss-only continuation and fit quantity scales on train data."""
import argparse
from copy import deepcopy
import os
from pathlib import Path
import time

import numpy as np
import torch

from model.losses.quantity_strata import QUANTITY_LOWER_BOUNDS
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read, STYLE
from train_dual.experiments.price_safe_readout import file_hash
from train_dual.util.checkpoint import freeze_sources
from train_dual.util.data import DualNormalizer
from train_dual.util.quantity_strata import quantity_bin_mask_numpy, QUANTITY_STRATA_SCHEMA_VERSION


MULTIPLIERS = dict(control=0., quarter=.25, unit=1., four=4.)


def prepare(goal):
    root=goal/'quantity_strata_preparation_v3';root.mkdir()
    (root/'logs').mkdir();(root/'data').mkdir()
    parent=goal/'round_005_regional_phase';source=parent/'shape/step2048.pt'
    os.link(source,root/'source.pt')
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    for name in ['teacher.pt','calibration.json','train_indices.npy','val_indices.npy','seen_indices.npy','unseen_indices.npy','plotly.min.js']:
        os.link(parent/name,root/name)
    indices=np.load(root/'seen_indices.npy');training=set(np.load(root/'train_indices.npy').tolist())
    assert len(indices)==8 and all(int(i) in training for i in indices)
    np.save(root/'quantity_calibration_indices.npy',indices)
    payload=torch.load(source,map_location='cpu',weights_only=False,mmap=True)
    assert payload['format_version']==1 and payload['unified_vae_config']['levels']==2048
    assert payload['epoch_boundary'] and len(payload['optimizer']['param_groups'])==3
    config=payload['regional_phase_config'];assert config['use_shape'] and not config['use_mass']
    parent_plan=read(parent/'plan.json')
    required=['train','development','window_size','stride','normalization','model_config',
        'local_hint_config','original_parameter_names','objective','source_FP_rule','augmentation',
        'lr','weight_decay','clip_grad','batch_size','accumulation','seed','beta','sample',
        'input_shape','latent_shape','output_shape','precision']
    plan={key:deepcopy(parent_plan[key]) for key in required if key in parent_plan}
    assert plan['input_shape']==[1,256,2,2048,2] and plan['latent_shape']==[1,64,128] and plan['output_shape']==[1,256,2,2048]
    plan.update(preparation_only=True,quantity_bin_membership_schema=QUANTITY_STRATA_SCHEMA_VERSION,source_parent=str(parent.resolve()),experiment='Loss-only quantity-scale-balanced reconstruction after user small-order correction',
        labels=dict(control='原损失控制',quarter='分桶梯度权重0.25倍',unit='分桶梯度权重1倍',four='分桶梯度权重4倍'),
        lanes={lane:dict(deepcopy(parent_plan['lanes']['shape']),stratified_multiplier=value) for lane,value in MULTIPLIERS.items()},
        source=str((root/'source.pt').resolve()),source_sha256=file_hash(source),
        source_steps=payload['source_steps']+payload['step'],source_regional_config=config,
        checkpoint_extras={lane:dict(regional_phase_config=config,
            training_numeric_policy=dict(cudnn_deterministic=True,cudnn_benchmark=False,tf32=False),
            inference_numeric_policy=dict(cudnn_deterministic=True,cudnn_benchmark=False,tf32=False)) for lane in MULTIPLIERS},
        source_selection='Fixed regional shape step2048: price-safe80.37percent large recall but poor small/middle quantity. Same source for all arms, preserving all three source Adam groups and RNG.',
        quantity_bins_lower_BTC=list(QUANTITY_LOWER_BOUNDS),quantity_scale_floor_BTC=.0001,
        quantity_calibration_indices=indices.tolist(),stratified_multipliers=MULTIPLIERS,
        calibration_policy='Fit RMS by true physical quantity bin on eight existing training windows only. A separate actualGPU gradient-RMS calibration must lock one base coefficient before workers; no optimizer updates or development-based coefficient tuning.',
        steps=2048,checkpoints=[256,512,1024,2048],max_seconds=43200,
        only_changed_factor='Multiplier of new quantity-bin normalized Huber; original model,8192Z,loss components,Adam,data,sampling,augmentation,teacher,seed42,budget and evaluation fixed.',
        loss_variant='stratified_quantity_huber',goal_root=str(goal.resolve()),
        source_readout_parameters=36992,new_model_parameters=0,
        scheduling='No training launched here. Wait current fine Encoder cohort; do not queue quantity-context or relative-log architecture changes in this loss-only study.',
        quantity_validation='Full16window per-bin errors/within20percent/withinFactor2 must be reported. Large recall alone does not establish whole-book success; any candidate requires separate small/middle quantity review before independent confirmation.')
    atomic_json(root/'plan.json',plan)
    atomic_json(root/'status.json',dict(state='prepared_not_training'))
    freeze_sources(root/'source_snapshot')
    print(root.resolve(),flush=True)


def fit(root):
    torch.set_num_threads(4);start=time.monotonic();plan=read(root/'plan.json')
    if plan.get('quantity_bin_membership_schema')!=2:raise ValueError('Legacy scale fit is immutable; prepare a freshv3 capsule before fitting corrected membership')
    atomic_json(root/'status.json',dict(state='fitting_train_only_quantity_scales',pid=os.getpid()))
    assert file_hash(root/'source.pt')==plan['source_sha256']
    config=plan['normalization'];norm=DualNormalizer(tick_size=config['tick_size'],price_scale=config['price_scale'])
    original=dataset(root,'train');indices=np.load(root/'quantity_calibration_indices.npy')
    counts=np.zeros(6,dtype=np.int64);squares=np.zeros(6,dtype=np.float64)
    for n,index in enumerate(indices):
        raw={k:v.unsqueeze(0) for k,v in original[int(index)].items()}
        offset=int(original.base.starts[int(index)]);times=original.base.times[offset:offset+256]
        assert list(raw['data'].shape)==[1,256,2,2048,2] and np.all(np.diff(times//60_000_000)==1)
        batch=norm.prepare(raw,'cpu');q=batch['volume'].double().numpy();mask=batch['mask'].numpy()
        for i,lower in enumerate(QUANTITY_LOWER_BOUNDS):
            selected=mask&quantity_bin_mask_numpy(q,i)
            values=q[selected];counts[i]+=len(values);squares[i]+=float((values**2).sum())
        atomic_json(root/'progress.json',dict(training_windows=n+1,total=8,elapsed_seconds=time.monotonic()-start))
    assert (counts>0).all()
    scales=np.maximum(np.sqrt(squares/counts),plan['quantity_scale_floor_BTC'])
    atomic_json(root/'quantity_calibration.json',dict(state='scales_fit_requires_GPU_gradient_calibration',
        lower_BTC=list(QUANTITY_LOWER_BOUNDS),counts=counts.tolist(),RMS_scales_BTC=scales.tolist(),membership_schema_version=QUANTITY_STRATA_SCHEMA_VERSION,
        training_indices=indices.tolist(),scale_floor_BTC=plan['quantity_scale_floor_BTC'],
        base_weight=None,weight_calibration_locked=False,neural_forward_calls=0,optimizer_updates=0,
        scope='Only eight predeclared2022-2024training windows, all in fixed1024training index. No development or independent data.'))
    assert file_hash(root/'source.pt')==plan['source_sha256']
    atomic_json(root/'status.json',dict(state='train_scales_complete_not_training',pid=os.getpid(),elapsed_seconds=time.monotonic()-start))
    rows=''.join('<tr><td>'+str(QUANTITY_LOWER_BOUNDS[i])+'</td><td>'+str(int(counts[i]))+'</td><td>'+f'{scales[i]:.8g}'+'</td></tr>' for i in range(6))
    page='<h1>分数量级均衡损失：训练集尺度统计</h1><p>固定原region_shape/2048权重，单Encoder/唯一8192Gaussian及双Decoder不变。下一轮仅比较分桶Huber附加权重0/0.25/1/4；原大单与价格损失保留。</p><p>这里只读取8个既有训练窗口，0神经前向、0优化器更新。实际GPU梯度校准、来源重放和正式训练尚未执行。没有质量收益成绩。</p><table><tr><th>区间下限BTC</th><th>有效档位数</th><th>训练数量RMS BTC</th></tr>'+rows+'</table><p><a href="quantity_calibration.json">尺度与训练索引</a> · <a href="plan.json">控制协议</a></p>'
    (root/'index.html').write_text('<!doctype html><meta charset="utf-8"><style>'+STYLE+'</style><main>'+page+'</main>')
    print(dict(counts=counts.tolist(),scales=scales.tolist()),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('root',type=Path)
    parser.add_argument('--prepare',action='store_true');parser.add_argument('--fit',action='store_true')
    args=parser.parse_args();root=args.root.resolve()
    try:
        if args.prepare:prepare(root)
        elif args.fit:fit(root)
    except BaseException as error:
        if not args.prepare and read(root/'plan.json',{}).get('quantity_bin_membership_schema')==2:atomic_json(root/'status.json',dict(state='failed',pid=os.getpid(),error=repr(error)))
        raise
