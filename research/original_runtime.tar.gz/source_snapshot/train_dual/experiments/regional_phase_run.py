"""Region-specific readout matched to the shared study's original source."""
import argparse
import hashlib
import os
from pathlib import Path
import signal
import time

from train_dual.experiments import local_phase_run as base
from train_dual.experiments import local_hint_run as shared
from train_dual.experiments.local_phase_run import LABELS,render
from train_dual.experiments.mid_delta_run import criterion,candidate_ready
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read
from train_dual.experiments.recall_goal_run import candidates,record,render as render_goal
from train_dual.experiments.region_task_run import gpu_free
from train_dual.util.checkpoint import freeze_sources
from train_dual.util.hint_training import restore_regional_phase_adam


def file_hash(path):
    value=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(4*1024*1024),b''):value.update(block)
    return value.hexdigest()


def predecessor_pids(goal,proc_root=Path('/proc')):
    target=str(goal/'local_phase_after').encode();found=[]
    for f in proc_root.glob('[0-9]*/cmdline'):
        try:args=f.read_bytes().split(b'\0')
        except OSError:continue
        if b'train_dual.experiments.local_phase_run' in args and target in args:found.append(int(f.parent.name))
    return found


def matched_source(parent):
    plan=read(parent/'plan.json')
    if plan.get('readout_family','shared')!='shared':raise ValueError('Need the shared study as the matched parent')
    selected=plan['source_selection']
    if file_hash(parent/'source.pt')!=file_hash(selected['checkpoint']):
        raise ValueError('Shared source.pt differs from its original selected checkpoint')
    if plan['steps']!=2048 or plan['seed']!=42:raise ValueError('Unexpected shared study budget/seed; new protocol required')
    return selected,dict(plan['lanes']['control'])


def prepare_cohort(queue,parent):
    selected,spec=matched_source(parent)
    return base.prepare_cohort(queue,parent,selected,dict(scope='Same original source as shared study; no reselection or new inference.'),
        regional=True,source_spec=spec,plan_extras=dict(matched_shared_root=str(parent),matched_initial_source_sha256=file_hash(parent/'source.pt'),
            sharing_control='Same original shared-study source.pt/2Adamgroups/RNG, data, augmentation, teacher, loss/alpha and2048stepbudget. Change only shared289vsregion-specific36992readout capacity; shape/mass2x2 in both. Do not continue a trained shared arm.'))


def audit_startup(root):
    if not base.audit_startup(root):return False
    plan=read(root/'plan.json');parent=Path(plan['matched_shared_root'])
    if file_hash(root/'source.pt')!=file_hash(parent/'source.pt') or file_hash(root/'source.pt')!=plan['matched_initial_source_sha256']:
        raise ValueError('Original shared/regional source mismatch')
    for name in ['train_indices.npy','val_indices.npy','seen_indices.npy','unseen_indices.npy','teacher.pt','calibration.json']:
        if file_hash(root/name)!=file_hash(parent/name):raise ValueError(f'Matched artifact changed: {name}')
    for lane in LABELS:
        old=read(parent/lane/'step1_data_audit.json');new=read(root/lane/'step1_data_audit.json')
        if not old:raise ValueError('No actual shared first-step controls to compare')
        if new!=old:raise ValueError(f'Shared/regional first inputs, augmentation or initial losses differ: {lane}')
    atomic_json(root/'sharing_control_startup_audit.json',dict(passed=True,same_original_checkpoint_Adam_RNG=True,
        same_indices_teacher_calibration=True,first_samples_augmentation_and_losses_exact=True,
        separate_full_model_step0_source_replay_and_head_gradient_audits=True))
    return True


def prepare_queue(goal,name='regional_phase_after',readout_kernel='einsum'):
    preflight='regional_linear_phase_preflight' if readout_kernel=='linear' else 'regional_phase_preflight'
    audit=read(goal/preflight/'audit.json')
    if not audit or not audit['passed'] or audit['raw_shape']!=[1,256,2,2048,2] or audit['added_parameters']!=36992:
        raise ValueError('Regional full-window preflight must pass')
    if readout_kernel=='linear' and audit.get('readout_kernel')!='linear':raise ValueError('Need the matching linear-kernel preflight')
    if readout_kernel=='linear':
        precision=read(goal/preflight/'gpu_precision_audit.json')
        implementation=Path(__file__).resolve().parents[2]/'model/layers/regional_linear.py'
        if not precision or not precision['passed'] or precision['shared_Linear_dtype']!=precision['regional_fused_dtype']:
            raise ValueError('Matching shared/regional GPU autocast audit required')
        if precision['implementation_sha256']!=file_hash(implementation):raise ValueError('Precision audit implementation changed')
    root=goal/name;root.mkdir();(root/'logs').mkdir()
    study=dict(steps_per_lane=2048,checkpoints=[256,512,1024,2048],max_seconds_per_lane=43200,seed=42,
        source_policy='Exactly round004/source.pt from before shared head training. Never select a better trained shared endpoint. Same source2Adamgroups/RNG/loss/data/budget as shared study.',
        controls='Region-specific shape/mass2x2,all36992zeroheadparameterspresentin4arms;EncoderandbothDecoderstrain. Source/sharedstudyinitialreplayandfirstsample/augmentation/lossmustmatch. No loss or upsampling changes.',
        eligibility='Only after shared full-model cohort completes with no qualified native candidate. If shared cohort was skipped, skip this matched study too.',
        regional_model_config=dict(readout_kernel=readout_kernel),
        arithmetic_control='linear kernel uses fused baddbmm so autocast logits including bias match shared Linear BF16; old einsum+FP32bias version is diagnostic-only, its waiting queue was cancelled before GPU use.' if readout_kernel=='linear' else 'Original einsum diagnostic implementation')
    atomic_json(root/'plan.json',dict(goal_root=str(goal),parent='round_004_local_phase',parent_queue='local_phase_after',
        readout_family='regional',readout_parameters=36992,readout_kernel=readout_kernel,wait_seconds=39*3600,study=study))
    atomic_json(root/'status.json',dict(state='prepared_not_started'));freeze_sources(root/'source_snapshot');render(root)
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(Path(__file__).resolve().parents[2])
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 CUDA_DEVICE_ORDER=PCI_BUS_ID OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.regional_phase_run "{remote}" >> "{remote}/logs/controller.log" 2>&1\n')
    print(root,flush=True)


def controller(queue):
    goal=queue.parent;config=read(queue/'plan.json');parent=goal/config['parent'];parent_queue=goal/config['parent_queue'];started=time.monotonic()
    while True:
        state=read(parent/'status.json',{});qstate=read(parent_queue/'status.json',{});live=predecessor_pids(goal)
        if qstate.get('state')=='failed' or state.get('state')=='failed':raise RuntimeError('Shared predecessor failed; inspect before proceeding')
        if not live and qstate.get('state','').startswith('not_run_'):
            atomic_json(queue/'status.json',dict(state='not_run_no_matched_shared_study',predecessor=qstate));render(queue);return
        if state.get('state')=='complete' and not live:break
        if len(live)!=1:raise RuntimeError(f'Cannot verify unique shared controller: {live}')
        if time.monotonic()-started>config['wait_seconds']:raise TimeoutError('Shared predecessor wait ceiling')
        atomic_json(queue/'status.json',dict(state='verified_wait_parent',controller_pids=live,predecessor_state=state.get('state'),predecessor_queue_state=qstate.get('state')));render(queue);time.sleep(20)
    reference=goal/'reference_evaluation.json';rows=candidates(parent,reference)
    if candidate_ready(goal,queue,rows,LABELS):render(queue);return
    while any(gpu_free().get(g,0)<47000 for g in [2,3,4,5]):
        if time.monotonic()-started>config['wait_seconds']:raise TimeoutError('GPU release wait ceiling')
        atomic_json(queue/'status.json',dict(state='verified_wait_GPU_release'));render(queue);time.sleep(10)
    root=prepare_cohort(queue,parent);atomic_json(queue/'status.json',dict(state='running',wave=root.name))
    atomic_json(goal/'status.json',dict(state='running_regional_phase_controlled_cohort',wave=root.name));render(queue)
    record(goal,'regional_phase_cohort_started',root=root.name,same_original_shared_source=True,additional_updates=2048)
    base.run_cohort(root,audit_factory=audit_startup)
    new=candidates(root,reference);old=read(goal/'candidates.json',{}).get('rows',[])
    for row in new:row['experiment']=root.name
    atomic_json(goal/'candidates.json',dict(rows=[r for r in old if r.get('experiment')!=root.name]+new))
    if not candidate_ready(goal,queue,new,LABELS):
        atomic_json(goal/'status.json',dict(state='cohort_complete_next_hypothesis_required',wave=root.name,goal_achieved=False))
        atomic_json(queue/'status.json',dict(state='complete',wave=root.name,goal_automatically_completed=False))
    render(queue);render_goal(goal)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--lane',choices=list(LABELS));p.add_argument('--name',default='regional_phase_after');p.add_argument('--readout-kernel',choices=['einsum','linear'],default='einsum');a=p.parse_args();root=a.root.resolve()
    def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        if a.prepare:prepare_queue(root,a.name,a.readout_kernel)
        elif a.lane:shared.worker(root,a.lane,objective_factory=criterion,optimizer_factory=restore_regional_phase_adam)
        else:controller(root)
    except BaseException as error:
        if not a.prepare:atomic_json((root/a.lane if a.lane else root)/'status.json',dict(state='failed',error=repr(error)))
        raise
