"""Matched false-positive-rule study, conditionally replacing a collapsed cohort."""
import argparse
import html
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import numpy as np
import torch

from model.losses.recall_guard import RecallGuardBookLoss
from train_dual.experiments import local_hint_run as shared
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.goal_evaluate import assess_file
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read,fmt,STYLE
from train_dual.experiments.recall_goal_run import candidates,record,render as render_goal
from train_dual.experiments.region_task_run import gpu_free
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import atomic_save,freeze_sources,load_for_inference
from train_dual.util.phase_training import tensor_digest


LABELS={'legacy':'原误报规则','fixed_count':'仅固定目标分母','smooth':'再平滑阈值边界','recall':'再降低误报相对权重'}
RULES={'legacy':dict(fp_normalization='active',fp_error='full',fp_weight=1.),
       'fixed_count':dict(fp_normalization='positive',fp_error='full',fp_weight=1.),
       'smooth':dict(fp_normalization='positive',fp_error='margin_excess',fp_weight=1.),
       'recall':dict(fp_normalization='positive',fp_error='margin_excess',fp_weight=.25)}


def persistent_collapse(parent):
    """Predeclared at512; require a second common evaluation before stopping."""
    for step in [512,1024]:
        rows={lane:read(parent/lane/f'step{step}_development.json') for lane in ['mid','tail','both']}
        if not all(rows.values()):return False
        r={k:v['result']['thresholds']['100']['recall'] for k,v in rows.items()}
        seen=read(parent/'tail'/f'step{step}_seen.json')
        if not seen:return False
        if not (r['mid']>=.25 and r['tail']<=.05 and r['both']<.5*r['mid'] and seen['result']['thresholds']['100']['recall']<=.01):return False
    return True


def select_source(rows):
    common=set.intersection(*[{r['step'] for r in rows if r['lane']==lane} for lane in ['baseline','mid','tail','both']])
    step=max(common);pool=[r for r in rows if r['step']==step]
    safe=[r for r in pool if r['price_rmse']<=r['price_limit'] and r['mid_delta_rmse']<=r['mid_delta_limit']]
    if safe:return max(safe,key=lambda r:(r['recall100'] or 0.,-r['price_rmse']))
    return next(r for r in pool if r['lane']=='mid') # Retain price-protection learning, no pathological tail.


def render(root):
    plan=read(root/'plan.json');state=read(root/'status.json',{})
    text=f'<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="30"><title>误报罚项修正对照</title><style>{STYLE}</style><main><h1>误报罚项：固定分母、连续边界与召回权重</h1><p>状态：{html.escape(state.get("state","prepared"))}。完整256分钟、双侧2048档、唯一8192神经Z，Encoder和双Decoder训练；原始价格门槛不变。</p>'
    text+='<p>四组是逐项单因素链：原active-FP均值；只把分母改为真实≥100BTC个数；再把负例罚项改为从阈值下方一个q0开始的连续Huber余量；再将该误报项乘0.25。相邻方案只有声明因素不同，不声称是完整2×2交互实验。正例Huber及mid保护、原量价/Local提示/相同增强、初值/Adam/RNG/数据和预算一致。共同tail权重只按8训练窗的正例项μ梯度RMS与原目标1:1校准，避免用病态FP项决定正例强度。</p>'
    if 'labels' in plan:
        text+='<table><tr><th>方案</th><th>进度</th><th>检查点</th><th>召回</th><th>精确率</th><th>价格RMSE</th><th>分钟mid变化RMSE</th><th>门槛</th></tr>'
        for lane,label in plan['labels'].items():
            progress=read(root/lane/'progress.json',{})
            for step in [0,*plan['checkpoints']]:
                f=root/lane/f'step{step}_development.json'
                if not f.exists():continue
                v=assess_file(f,Path(plan['goal_root'])/'reference_evaluation.json')
                vals=[label,f'{progress.get("step",0)}/{plan["steps"]}',step,fmt(v['recall100']),fmt(v['precision100']),fmt(v['price_rmse']),fmt(v['mid_delta_rmse']),v['pass']]
                text+='<tr>'+''.join(f'<td>{html.escape(str(x))}</td>' for x in vals)+'</tr>'
        text+='</table>'
    text+='<p>开发Q1已复用，不当作独立确认。若前置1024步未确认持续塌缩，则保留原4096步完整预算；若两次共同评估均显示tail召回≤5%、其训练seen召回≤1%、组合召回低于mid一半，才按已声明条件在1024共同检查点后结束旧队列。所有旧权重、评估、快照及停止原因保留。出现合格候选优先冻结确认，本任务不自动宣布goal完成，也不读取Q2。</p><p><a href="plan.json">配置/条件</a> · <a href="../">研究目标</a></p></main>'
    tmp=root/'index.tmp';tmp.write_text(text);tmp.replace(root/'index.html')


def prepare_queue(goal):
    root=goal/'fp_rule_after';root.mkdir();(root/'logs').mkdir()
    atomic_json(root/'plan.json',dict(goal_root=str(goal),parent='round_001_mid_tail',wait_seconds=13*3600,
        policy='Atcommon1024,passcandidatefirst;stopownedcohortonlyifpredeclaredpersistent_collapseholds. Otherwisewaitoriginal4096cohortcompletion. ThenFPfour-armstudy.',steps=2048,max_seconds=43200))
    atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot');render(root)
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(Path(__file__).resolve().parents[2])
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 CUDA_DEVICE_ORDER=PCI_BUS_ID OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.fp_rule_run "{remote}"\n')
    print(root,flush=True)


def controller_pids(goal):
    found=[]
    for f in Path('/proc').glob('[0-9]*/cmdline'):
        try:args=f.read_bytes().split(b'\0')
        except (FileNotFoundError,PermissionError,ProcessLookupError):continue
        if b'train_dual.experiments.recall_goal_run' in args and str(goal).encode() in args:found.append(int(f.parent.name))
    return found


def stop_owned_after_common(goal,parent):
    for lane in ['baseline','mid','tail','both']:
        assert read(parent/lane/'evaluation_status.json')['step']>=1024
        assert (parent/lane/'step1024.pt').exists()
    pids=controller_pids(goal)
    if len(pids)!=1:raise RuntimeError(f'Cannot identify unique owned scheduling controller: {pids}')
    atomic_json(parent/'controlled_stop_note.json',dict(reason='Persistent512and1024tailcollapseplusverifiedFPthresholdcliff/dilution;matched1024retained,planned4096notcompleted.',controller_pid=pids[0],common_step=1024,source_snapshots_unchanged=True))
    os.kill(pids[0],signal.SIGTERM)
    started=time.monotonic()
    while controller_pids(goal) or any(gpu_free().get(g,0)<47000 for g in [2,3,4,5]):
        if time.monotonic()-started>180:raise TimeoutError('Owned predecessor did not release GPUs')
        time.sleep(3)
    record(goal,'controlled_stop_after_common1024',wave=parent.name,evidence='Both512and1024:tailR<=5%,seenR<=1%,combinedR<halfmidR;actualcheckpointsandevaluationsretained. OriginalfailurestatusfromSIGTERMisnotanumerictrainingfailure.',next='StartFP-rulematchedcohortfromhealthyprotectedsource.')


def prepare_cohort(queue,parent,selected):
    goal=queue.parent;root=goal/'round_002_fp_rule';root.mkdir()
    for name in ['data','logs','seen','unseen',*LABELS]:(root/name).mkdir()
    for split in ['seen','unseen']:
        for lane in LABELS:(root/split/lane).mkdir()
    for name in ['train_indices.npy','val_indices.npy','seen_indices.npy','unseen_indices.npy','calibration_indices.npy','plotly.min.js','teacher.pt']:
        os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz');os.link(selected['checkpoint'],root/'source.pt')
    payload=torch.load(root/'source.pt',map_location='cpu',weights_only=False);assert payload['epoch_boundary']
    model,_=load_for_inference(root/'source.pt','cpu')
    plan=dict(read(parent/'plan.json'));plan.update(experiment='Falsepositiveobjectivecontrolledchain',labels=LABELS,
        lanes={lane:dict(hint=True,augmentation=True,protect_mid=True,use_tail=True,**rule) for lane,rule in RULES.items()},
        steps=2048,checkpoints=[256,512,1024,2048],max_seconds=43200,source=str(root/'source.pt'),source_steps=payload['source_steps']+payload['step'],
        initial_model_sha256=tensor_digest(model),gpu_workers=[[g,l] for g,l in zip([2,3,4,5],LABELS)],loss_variant='fp_rule',goal_root=str(goal),
        controls='Allsourceweights/Adam/RNG/data/augmentation/teacher/originallossesandcommoncoefficientsfixed. Adjacentchainonlychangesnormalizer,thenpenaltydefinition,thenFPweight. Noarchitecture/latentcapacitychange.',
        preview_descriptions={lane:'完整256分钟、唯一8192神经Z。误报罚项控制变量实验，Q1已用于研究，不是独立测试。' for lane in LABELS})
    atomic_save(dict(format_version=1,model=payload['model'],unified_vae_config=payload['unified_vae_config'],local_hint_config=payload['local_hint_config'],config=payload['config'],step=0),root/'initial.pt')
    atomic_json(root/'plan.json',plan);atomic_json(root/'calibration.json',dict(read(parent/'calibration.json'),tail_weight=1.,mid_weight=1.,new_weights_state='pending_positive_and_mid_gradient_calibration'))
    for split in ['seen','unseen']:
        atomic_json(root/split/'plan.json',dict(plan,preview_descriptions={lane:'训练年代诊断；seen参与学生训练，unseen排除学生索引但教师可能见过；非独立测试。' for lane in LABELS}));os.link(root/'plotly.min.js',root/split/'plotly.min.js')
    atomic_json(root/'status.json',dict(state='prepared',source=selected));freeze_sources(root/'source_snapshot');render(root)
    return root


def criterion(root,lane):
    plan=read(root/'plan.json');cal=read(root/'calibration.json');rule={k:plan['lanes'][lane][k] for k in ['fp_error','fp_normalization','fp_weight']}
    return RecallGuardBookLoss(plan['normalization']['quantity_scale'],mode='shape_mass',use_hint=True,hint_weight=cal['hint_weight'],hint_mean=cal['channel_mean'],hint_scale=cal['channel_scale'],use_tail=True,protect_mid=True,tail_weight=cal['tail_weight'],mid_weight=cal['mid_weight'],add_wasserstein=False,add_multiscale=False,**rule,**plan['objective']).to('cuda:0')


def calibrate(root):
    torch.set_num_threads(4);strict_precision();model,norm=load_for_inference(root/'initial.pt','cuda:0');model.train()
    teacher,tn=load_for_inference(root/'teacher.pt','cuda:0');teacher.eval().requires_grad_(False)
    loss=criterion(root,'legacy');params=list(model.encoder.mu.parameters());data=dataset(root,'train')
    squares={k:[] for k in ['pre_guard_loss','tail_positive_huber','tail_false_positive_huber','tail_balanced','mid_protection']};dots=[]
    for index in np.load(root/'calibration_indices.npy'):
        raw={k:v.unsqueeze(0) for k,v in data[int(index)].items()};target=shared.teacher_local(teacher,tn,raw);b=norm.prepare(raw,'cuda:0')
        with torch.autocast('cuda',dtype=torch.bfloat16):out=call(model,b,False)
        values=loss(out,b,teacher_local=target);vectors={}
        for key in squares:
            grads=torch.autograd.grad(values[key],params,retain_graph=key!='mid_protection');vectors[key]=grads;squares[key].append(sum(float(g.float().square().sum()) for g in grads))
        dots.append(sum(float((a.float()*b.float()).sum()) for a,b in zip(vectors['tail_positive_huber'],vectors['tail_false_positive_huber'])))
    rms={k:math.sqrt(float(np.mean(v))) for k,v in squares.items()}
    if any(not math.isfinite(rms[k]) or rms[k]<=0 for k in ['pre_guard_loss','tail_positive_huber','mid_protection']):raise ValueError(f'Invalidcalibration:{rms}')
    cal=read(root/'calibration.json');cal.update(tail_weight=rms['pre_guard_loss']/rms['tail_positive_huber'],mid_weight=rms['pre_guard_loss']/rms['mid_protection'],new_weights_state='locked',new_gradient_rms=rms,
        positive_fp_gradient_cosine=float(np.mean(dots))/(rms['tail_positive_huber']*rms['tail_false_positive_huber']) if rms['tail_false_positive_huber'] else None,
        scope_new_weights='8fixedtrainingwindows,positive-onlymu-gradientRMS1xbaseandmidRMS1xbase;commonall4,nooptimizerupdate/noQ2.')
    atomic_json(root/'calibration.json',cal)


def run_cohort(root):
    plan=read(root/'plan.json');children=[];started=time.monotonic();audited=False
    def spawn(gpu,args,role):
        env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),PYTHONPATH=str(root/'source_snapshot'))
        with (root/'logs'/f'{role}.log').open('ab',buffering=0) as log:
            p=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.fp_rule_run',str(root),*args],cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        children.append(p);return p
    try:
        p=spawn(2,['--calibrate'],'calibrate');p.wait(timeout=1800)
        if p.returncode:raise RuntimeError('FPcalibrationfailed')
        children=[]
        for gpu,lane in plan['gpu_workers']:spawn(gpu,['--lane',lane],lane)
        atomic_json(root/'status.json',dict(state='running',pids=[p.pid for p in children]))
        while any(p.poll() is None for p in children):
            if time.monotonic()-started>plan['max_seconds']+1800:raise TimeoutError('12hour+calibration/evaluation ceiling')
            if any(p.poll() not in [None,0] for p in children):raise RuntimeError('OwnedFPworkerfailed')
            if not audited:
                rows=[read(root/lane/'step1_data_audit.json') for lane in LABELS]
                if all(rows):
                    assert all(r['training_indices']==rows[0]['training_indices'] and r['edits']==rows[0]['edits'] and r['losses']['pre_guard_loss']==rows[0]['losses']['pre_guard_loss'] for r in rows)
                    atomic_json(root/'startup_control_audit.json',dict(passed=True,same_inputs_edits_original_loss=True));audited=True
            render(root);time.sleep(10)
        if any(p.returncode for p in children):raise RuntimeError('FPworkerfailed')
        atomic_json(root/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started));render(root)
    finally:
        for p in children:
            if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)


def controller(queue):
    goal=queue.parent;parent=goal/read(queue/'plan.json')['parent'];reference=goal/'reference_evaluation.json';started=time.monotonic();checked1024=False
    while True:
        state=read(parent/'status.json',{})
        if state.get('state')=='failed':raise RuntimeError('Unexpectedparentfailure;investigatebeforecontinuing')
        ready=all(read(parent/lane/'evaluation_status.json',{}).get('state')=='complete' and read(parent/lane/'evaluation_status.json',{}).get('step',0)>=1024 for lane in ['baseline','mid','tail','both'])
        if ready and not checked1024:
            rows=candidates(parent,reference);passing=[r for r in rows if r['pass']]
            if passing:
                chosen=max(passing,key=lambda r:(r['recall100'],-r['price_rmse']));atomic_json(goal/'candidate_for_confirmation.json',chosen);atomic_json(goal/'status.json',dict(state='development_pass_requires_independent_confirmation',candidate=chosen));atomic_json(queue/'status.json',dict(state='not_run_candidate_for_confirmation'));render(queue);return
            checked1024=True
            if persistent_collapse(parent):stop_owned_after_common(goal,parent);break
        if state.get('state')=='complete':break
        if time.monotonic()-started>read(queue/'plan.json')['wait_seconds']:raise TimeoutError('13hourparentwaitceiling')
        live=controller_pids(goal)
        if not live:raise RuntimeError('Ownedparentcontrollerhandlemissing')
        atomic_json(queue/'status.json',dict(state='verified_wait_parent',controller_pids=live,checked1024=checked1024));render(queue);time.sleep(20)
    rows=candidates(parent,reference);passing=[r for r in rows if r['pass']]
    if passing:
        chosen=max(passing,key=lambda r:(r['recall100'],-r['price_rmse']));atomic_json(goal/'candidate_for_confirmation.json',chosen);atomic_json(goal/'status.json',dict(state='development_pass_requires_independent_confirmation',candidate=chosen));atomic_json(queue/'status.json',dict(state='not_run_candidate_for_confirmation'));render(queue);return
    selected=select_source(rows)
    while any(gpu_free().get(g,0)<47000 for g in [2,3,4,5]):time.sleep(10)
    root=prepare_cohort(queue,parent,selected);atomic_json(goal/'status.json',dict(state='running_fp_rule_controlled_cohort',wave=root.name));atomic_json(queue/'status.json',dict(state='running',wave=root.name));render(queue)
    run_cohort(root)
    old=read(goal/'candidates.json',{}).get('rows',[]);new=candidates(root,reference)
    for r in new:r['experiment']=root.name
    for r in rows:r['experiment']=parent.name
    old=[r for r in old if r.get('experiment') not in [parent.name,root.name]];atomic_json(goal/'candidates.json',dict(rows=old+rows+new))
    passing=[r for r in new if r['pass']]
    if passing:
        chosen=max(passing,key=lambda r:(r['recall100'],-r['price_rmse']));atomic_json(goal/'candidate_for_confirmation.json',chosen);state=dict(state='development_pass_requires_independent_confirmation',candidate=chosen)
    else:state=dict(state='cohort_complete_next_hypothesis_required',wave=root.name,goal_achieved=False)
    atomic_json(goal/'status.json',state);atomic_json(queue/'status.json',dict(state='complete',wave=root.name,goal_automatically_completed=False));render(queue);render_goal(goal)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--calibrate',action='store_true');p.add_argument('--lane',choices=list(LABELS));args=p.parse_args();root=args.root.resolve()
    def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        if args.prepare:prepare_queue(root)
        elif args.calibrate:calibrate(root)
        elif args.lane:shared.worker(root,args.lane,objective_factory=criterion)
        else:controller(root)
    except BaseException as error:
        atomic_json((root/args.lane if args.lane else root)/'status.json',dict(state='failed',error=repr(error)));raise
