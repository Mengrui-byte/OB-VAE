"""Post-Cross global/local generator dependence on actual256minute windows."""

import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import time

import numpy as np
import torch
from torch.nn import functional as F

from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import atomic_save,freeze_sources,load_for_inference,seed_everything
from train_dual.util.dynamics import DynamicsMetrics


LABELS={'baseline':'原Global＋原Local','mean_global':'Global替换训练均值，保留Local','mean_local':'Local替换训练均值，保留Global',
        'both_mean':'两路均替换训练均值','swap_global':'Global错配其他窗口，保留Local','swap_local':'Local错配其他窗口，保留Global'}


def prepare(parent):
    parent=parent.resolve();root=parent.parent/('global_local_256_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
    root.mkdir();(root/'data').mkdir();(root/'logs').mkdir()
    for name in ('train_indices.npy','val_indices.npy'):os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz');os.link(parent/'reference/final.pt',root/'checkpoint.pt')
    os.link(parent/'reference/step512_evaluation.json',root/'expected_reference.json')
    plan=json.loads((parent/'plan.json').read_text())
    plan.update(experiment='Frozen post-Cross global/local dependence',parent=str(parent),labels=LABELS,
        checkpoint_source=str(parent/'reference/final.pt'),checkpoint_sha256=hashlib.sha256((root/'checkpoint.pt').read_bytes()).hexdigest(),
        no_training=True,means_fit='Per-relative-time Global[256,64] and per-time/side/depth Local[256,2,128,16] on the same64training windows only; valid-local-position mean.',
        intervention='Replace post-Cross decoder inputs; encoders and Cross remain unchanged. Hold masks,times,tick and normalizer fixed. Window-swap controls use the next member of a cyclic permutation of the16dev windows.',
        limits='Frozen-generator reliance under a missing/mismatched branch, not retrained standalone branch capacity, unique information, or market-state semantic importance. Post-Cross branches already exchange context.')
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(parent.parents[1])
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.global_local_ablation "{remote}"\n')
    Path('/tmp/global_local_256_path').write_text(str(root));print(root,flush=True)


def run(root):
    torch.set_num_threads(4);seed_everything(42);strict_precision();started=time.monotonic()
    plan=json.loads((root/'plan.json').read_text());model,norm=load_for_inference(root/'checkpoint.pt','cuda:0')
    assert not model.compress and model.window_size==256
    train=dataset(root,'train');val=dataset(root,'val');train_ids=np.load(root/'train_indices.npy');val_ids=np.load(root/'val_indices.npy')
    atomic_json(root/'status.json',dict(state='fitting_training_means'))
    try:
        with torch.inference_mode():
            sg=sl=counts=None
            for index in train_ids:
                b=norm.prepare({k:v.unsqueeze(0) for k,v in train[int(index)].items()},'cuda:0')
                g,l=model.encode_fused(b['price'],b['volume'],b['mask'],b['tick_norm'],b['times'])
                lm=F.adaptive_max_pool1d(b['mask'].reshape(512,1,2048).float(),128).reshape(1,256,2,128,1).double()
                sg=g.double() if sg is None else sg+g.double();sl=l.double()*lm if sl is None else sl+l.double()*lm;counts=lm if counts is None else counts+lm
            mean_g=(sg/len(train_ids)).float();mean_l=(sl/counts.clamp_min(1)).float()
            atomic_save(dict(global_mean=mean_g.cpu(),local_mean=mean_l.cpu(),valid_local_counts=counts.cpu(),fit_indices=torch.from_numpy(train_ids)),root/'training_means.pt')
            cache=[]
            for index in val_ids:
                raw={k:v.unsqueeze(0) for k,v in val[int(index)].items()};b=norm.prepare(raw,'cuda:0')
                g,l=model.encode_fused(b['price'],b['volume'],b['mask'],b['tick_norm'],b['times'])
                assert list(raw['data'].shape)==[1,256,2,2048,2] and list(g.shape)==[1,256,64] and list(l.shape)==[1,256,2,128,16]
                cache.append((raw,b,g,l))
            metrics={k:DynamicsMetrics(norm.tick_size) for k in LABELS};thresholds={k:{q:np.zeros(3,dtype=np.int64) for q in (10,100)} for k in LABELS};windows={k:[] for k in LABELS}
            atomic_json(root/'status.json',dict(state='evaluating'))
            for i,(raw,b,g,l) in enumerate(cache):
                dg,dl=cache[(i+1)%len(cache)][2:]
                inputs={'baseline':(g,l),'mean_global':(mean_g,l),'mean_local':(g,mean_l),'both_mean':(mean_g,mean_l),'swap_global':(dg,l),'swap_local':(g,dl)}
                truth=raw['data'][0].numpy().astype(np.float64);mask=b['mask'][0].cpu().numpy();quantity=truth[...,1]
                for key,(gh,lh) in inputs.items():
                    out=model.decode_latents(gh,lh,b['mask'],b['tick_norm'],b['times'])
                    pred=np.stack([norm.inverse_price(out['price_norm'],b)[0].cpu().numpy(),out['volume'][0].cpu().numpy()],-1)
                    if not np.isfinite(pred[mask]).all():raise FloatingPointError(key)
                    metrics[key].update(truth,pred,mask);one=DynamicsMetrics(norm.tick_size);one.update(truth,pred,mask);windows[key].append(one.finish())
                    for q in thresholds[key]:
                        a=(quantity>=q)&mask;c=(pred[...,1]>=q)&mask
                        thresholds[key][q]+=[int((a&c).sum()),int((~a&c&mask).sum()),int((a&~c).sum())]
                atomic_json(root/'progress.json',dict(windows=i+1,total=len(cache),elapsed_seconds=time.monotonic()-started))
        rows={}
        for key,label in LABELS.items():
            value=metrics[key].finish();value['thresholds']={str(q):dict(tp=int(v[0]),fp=int(v[1]),fn=int(v[2]),recall=float(v[0]/(v[0]+v[2])) if v[0]+v[2] else None,precision=float(v[0]/(v[0]+v[1])) if v[0]+v[1] else None) for q,v in thresholds[key].items()}
            rows[key]=dict(label=label,result=value,per_window=windows[key])
        expected=json.loads((root/'expected_reference.json').read_text())['result'];actual=rows['baseline']['result']
        delta={k:abs(expected['metrics'][k]['rmse']-actual['metrics'][k]['rmse']) for k in ('price_usdt','quantity_btc')}
        atomic_json(root/'baseline_replay.json',dict(rmse_differences=delta,passed=max(delta.values())<=1e-4))
        if max(delta.values())>1e-4:raise RuntimeError(f'Frozen checkpoint baseline replay changed:{delta}')
        atomic_json(root/'results.json',dict(plan=plan,rows=rows,baseline_replay=delta,training_windows=len(train_ids),development_windows=len(val_ids)))
        atomic_json(root/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started));print(json.dumps({k:v['result']['metrics']['quantity_btc']['rmse'] for k,v in rows.items()}),flush=True)
    except BaseException as error:atomic_json(root/'status.json',dict(state='failed',error=repr(error)));raise


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');args=p.parse_args()
    if args.prepare:prepare(args.root)
    else:run(args.root)
