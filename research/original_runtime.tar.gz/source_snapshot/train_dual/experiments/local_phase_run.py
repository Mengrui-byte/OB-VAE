"""Conditional local phase/mass architecture factorial after loss controls."""
import argparse
import html
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import numpy as np
import torch

from model.autoencoder.local_phase_vae import LocalPhaseOrderBookVAE
from model.autoencoder.regional_phase_vae import RegionalPhaseOrderBookVAE
from train_dual.experiments import local_hint_run as shared
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.goal_evaluate import assess_file
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.mid_delta_run import ALPHAS,criterion,candidate_ready,violation_key
from train_dual.experiments.peak_error_diagnostics import analyze
from train_dual.experiments.phase_detail_report import read,fmt,STYLE
from train_dual.experiments.recall_goal_run import candidates,record,render as render_goal
from train_dual.experiments.region_task_run import gpu_free
from train_dual.util.checkpoint import atomic_save,freeze_sources
from train_dual.util.hint_training import restore_local_phase_adam,restore_regional_phase_adam
from train_dual.util.phase_training import tensor_digest


SWITCHES={'control':(False,False),'shape':(True,False),'mass':(False,True),'both':(True,True)}
LABELS=dict(control='原路径控制',shape='仅局部形状',mass='仅局部总量',both='局部形状＋总量')


def select_source(rows):
    common=set.intersection(*[{r['step'] for r in rows if r['lane']==lane} for lane in ALPHAS])
    if not common:raise ValueError('No matched endpoint of all four delta-weight lanes')
    pool=[r for r in rows if r['step']==max(common)]
    return min(pool,key=violation_key)


def predecessor_pids(goal,proc_root=Path('/proc')):
    target=str(goal/'mid_delta_after').encode();found=[]
    for f in proc_root.glob('[0-9]*/cmdline'):
        try:args=f.read_bytes().split(b'\0')
        except OSError:continue
        if b'train_dual.experiments.mid_delta_run' in args and target in args:found.append(int(f.parent.name))
    return found


def source_spillover(parent,selected):
    path=parent/selected['lane']/f"step{selected['step']}_profiles.npz"
    with np.load(path) as data:
        val=np.load(parent/'val_indices.npy');expected=val[np.unique(np.linspace(0,len(val)-1,3,dtype=int))]
        if not np.array_equal(data['indices'],expected):raise ValueError('Unexpected cached development windows')
        result=analyze(data['truth'][...,1],data['prediction'][...,1],data['mask'])
    result.update(eligible=result['fp']>=10 and result['fp_near_true_same_frame_rank']['2']>=.5*result['fp'],
                  scope='Three existing Q1 profile windows, subset of fixed16development. Descriptive proximity only; exact same-rank recall remains unchanged. No new inference or independent data.')
    return result


def render(root):
    plan=read(root/'plan.json',{});status=read(root/'status.json',{})
    regional=plan.get('readout_family')=='regional';description='分区域权重，36992个参数' if regional else '共享权重，289个参数'
    page='<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="30"><title>局部挂单解码头控制实验</title><style>'+STYLE+'</style><main><h1>局部16档形状 × 总量：2×2控制实验</h1>'
    page+='<p>状态：'+html.escape(status.get('state','prepared'))+'。先等既有对照完整预算结束；若已有合格候选，优先独立确认并跳过本轮。是否启动及共同来源以协议为准。</p><p>完整256分钟、双侧2048档、唯一64×128 Gaussian Z。新增两个小线性头读取Z解码后的空间种子，'+description+'。无Encoder跳接。四组包含相同零初始化参数，仅形状/总量开关不同；全模型训练，上采样、来源损失、价格差分权重、数据、抽样、seed42、Adam来源状态和2048步预算固定。每组最长12小时。β=0，训练和评估使用μ。</p>'
    if regional:page+='<p>与共享版本保持完全相同的最初source.pt、Adam和RNG，不从其训练末端继续。两轮共同检查点可用于比较权重共享方式；区域参数是全局模型参数，不增加每窗口latent。</p>'
    if 'labels' in plan:
        page+='<table><tr><th>方案</th><th>进度</th><th>检查点</th><th>召回</th><th>精确率</th><th>价格RMSE</th><th>分钟变化RMSE</th><th>通过联合门槛</th></tr>'
        for lane,label in LABELS.items():
            progress=read(root/lane/'progress.json',{})
            for step in [0,*plan['checkpoints']]:
                f=root/lane/f'step{step}_development.json'
                if not f.exists():continue
                verdict=assess_file(f,Path(plan['goal_root'])/'reference_evaluation.json')
                values=[label,f'{progress.get("step",0)}/{plan["steps"]}',step,fmt(verdict['recall100']),fmt(verdict['precision100']),fmt(verdict['price_rmse']),fmt(verdict['mid_delta_rmse']),verdict['pass']]
                page+='<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in values)+'</tr>'
        page+='</table>'
    page+='<p>Q1固定开发窗口反复用于选型，不是新测试集。此队列不读取Q2，也不自动完成目标。CPU全尺寸预检仅验证结构和迁移，不证明重建收益。</p><p><a href="plan.json">完整协议</a> · <a href="../">目标进度</a></p></main>'
    temporary=root/'index.tmp';temporary.write_text(page);temporary.replace(root/'index.html')


def prepare_queue(goal):
    audit=read(goal/'local_phase_preflight_v2/audit.json')
    if not audit or not audit['passed'] or audit['raw_shape']!=[1,256,2,2048,2] or audit['optimizer_updates']!=0:
        raise ValueError('Actual full-window preflight must pass before queue freeze')
    root=goal/'local_phase_after';root.mkdir();(root/'logs').mkdir()
    study=dict(steps_per_lane=2048,checkpoints=[256,512,1024,2048],max_seconds_per_lane=43200,seed=42,
        source_policy='Largest endpoint common to all4delta lanes; minimize maximum fixed-reference gate violation, then sum, higher recall, lower price. Never reset original reference.',
        eligibility='No qualified native candidate; cached3profile FP>=10 and at least50% within2ranks of a true>=100BTClevel in same frame/side. Descriptive proximity, not relaxed recall.',
        controls='2x2 localshape/localmass flags only; same289zeroheadparameters, entire original model and two Adam groups inherited, new third group empty. Source loss and deltaalpha unchanged across4arms; same input/data/augmentation/seed42/budget/eval. No upsampling change.')
    atomic_json(root/'plan.json',dict(goal_root=str(goal),parent='round_003_mid_delta',parent_queue='mid_delta_after',wait_seconds=26*3600,study=study))
    atomic_json(root/'status.json',dict(state='prepared_not_started'));freeze_sources(root/'source_snapshot');render(root)
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(Path(__file__).resolve().parents[2])
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 CUDA_DEVICE_ORDER=PCI_BUS_ID OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.local_phase_run "{remote}" >> "{remote}/logs/controller.log" 2>&1\n')
    print(root,flush=True)


def prepare_cohort(queue,parent,selected,spillover,*,regional=False,source_spec=None,plan_extras=None):
    goal=queue.parent;study=read(queue/'plan.json')['study'];old=read(parent/'plan.json')
    assert old['input_shape']==[1,256,2,2048,2] and old['latent_shape']==[1,64,128] and old['output_shape']==[1,256,2,2048]
    payload=torch.load(selected['checkpoint'],map_location='cpu',weights_only=False)
    assert payload['epoch_boundary'] and not payload.get('frozen_module_hashes') and len(payload['optimizer']['param_groups'])==2
    if any(key in payload for key in ['regional_phase_config','local_phase_config','shape_mass_config']):raise ValueError('Expected unchanged local_hint source')
    spec=old['lanes'][selected['lane']] if source_spec is None else source_spec
    assert all(spec[k] for k in ['hint','augmentation','protect_mid','use_tail'])
    root=goal/('round_005_regional_phase' if regional else 'round_004_local_phase');root.mkdir()
    for name in ['data','logs','seen','unseen',*LABELS]:(root/name).mkdir()
    for split in ['seen','unseen']:
        for lane in LABELS:(root/split/lane).mkdir()
    for name in ['train_indices.npy','val_indices.npy','seen_indices.npy','unseen_indices.npy','calibration_indices.npy','plotly.min.js','teacher.pt']:os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz');os.link(selected['checkpoint'],root/'source.pt')
    configs={};model_hash=None
    config_key='regional_phase_config' if regional else 'local_phase_config'
    model_type=RegionalPhaseOrderBookVAE if regional else LocalPhaseOrderBookVAE
    restore=restore_regional_phase_adam if regional else restore_local_phase_adam
    extra_names=(['local_readout.shape_weight','local_readout.shape_bias','local_readout.mass_weight','local_readout.mass_bias'] if regional else
                 ['local_readout.shape.weight','local_readout.shape.bias','local_readout.mass.weight','local_readout.mass.bias'])
    for lane,(shape,mass) in SWITCHES.items():
        cfg=dict(payload['local_hint_config'],use_shape=shape,use_mass=mass)
        if regional:cfg.update(study.get('regional_model_config',{}))
        configs[lane]={config_key:cfg}
        model=model_type(**cfg,**payload['unified_vae_config'])
        missing,extra=model.load_state_dict(payload['model'],strict=False)
        assert missing==extra_names and not extra
        digest=tensor_digest(model)
        if model_hash is None:model_hash=digest
        assert digest==model_hash
        optimizer=restore(model,payload['optimizer'],old['original_parameter_names'])
        assert len(optimizer.param_groups)==3 and all(p not in optimizer.state for p in optimizer.param_groups[2]['params'])
        atomic_save(dict(format_version=1,model=model.state_dict(),unified_vae_config=payload['unified_vae_config'],
            local_hint_config=payload['local_hint_config'],**{config_key:cfg},config=payload['config'],step=0),root/lane/'initial.pt')
    plan=dict(old);plan.update(experiment=('Regional' if regional else 'Shared')+' local16phase shape/mass architecture factorial',labels=LABELS,
        lanes={lane:dict(spec,use_shape=shape,use_mass=mass,
            gradient_module_flags={} if regional else {'local_readout.shape':shape,'local_readout.mass':mass},
            gradient_parameter_flags={name:(shape if 'shape' in name else mass) for name in extra_names} if regional else {}) for lane,(shape,mass) in SWITCHES.items()},
        source_selection=selected,source_spillover=spillover,source=str(root/'source.pt'),source_steps=payload['source_steps']+payload['step'],
        steps=study['steps_per_lane'],checkpoints=study['checkpoints'],max_seconds=study['max_seconds_per_lane'],seed=42,
        initial_model_sha256=model_hash,gpu_workers=[[g,l] for g,l in zip([2,3,4,5],LABELS)],loss_variant='regional_phase_2x2' if regional else 'local_phase_2x2',goal_root=str(goal),
        readout_family='regional' if regional else 'shared',readout_parameters=36992 if regional else 289,
        worker_module='train_dual.experiments.regional_phase_run' if regional else 'train_dual.experiments.local_phase_run',
        frozen_modules=[],checkpoint_extras=configs,controls=study['controls'],predeclared_selection=study['source_policy'],
        additional_controls=f'Architecture flags only. Source objective including FP and deltaalpha unchanged. All new{36992 if regional else 289}parameters present and zero in all4 arms.',
        budget='Additional2048updates perarm; max43200seconds each. Report actual capped endpoints.',
        preview_descriptions={lane:'完整256分钟、唯一8192神经Z，局部形状/总量2x2；来源损失和上采样固定；Q1开发集已反复用于选型，非独立测试。' for lane in LABELS})
    plan.update(plan_extras or {})
    atomic_json(root/'plan.json',plan);atomic_json(root/'calibration.json',read(parent/'calibration.json'))
    data=dataset(root,'train');index=int(np.load(root/'train_indices.npy')[0]);raw=data[index];start=int(data.base.starts[index]);times=data.base.times[start:start+256]
    assert list(raw['data'].shape)==[256,2,2048,2] and len(times)==256 and np.all(np.diff(times//60_000_000)==1)
    atomic_json(root/'data_contract.json',dict(passed=True,raw_input=[1,*raw['data'].shape],consecutive_minute_buckets=True,first_training_index=index,latent_and_full_output_runtime_checks_pending=True))
    for split in ['seen','unseen']:
        atomic_json(root/split/'plan.json',dict(plan,preview_descriptions={lane:'训练年代诊断，非独立测试；完整256分钟局部形状/总量控制。' for lane in LABELS}));os.link(root/'plotly.min.js',root/split/'plotly.min.js')
    atomic_json(root/'status.json',dict(state='prepared',source=selected));freeze_sources(root/'source_snapshot');render(root)
    return root


def audit_startup(root):
    rows={lane:read(root/lane/'step1_data_audit.json') for lane in LABELS}
    gradients={lane:read(root/lane/'step8_gradient_audit.json') for lane in LABELS}
    if not all(rows.values()) or not all(gradients.values()):return False
    plan=read(root/'plan.json');base=rows['control']
    source_result=read(Path(plan['source_selection']['evaluation']))['result']
    from train_dual.experiments.confirm_recall_goal import require_matching_replay
    for lane,row in rows.items():
        assert row['training_indices']==base['training_indices'] and row['edits']==base['edits']
        assert row['losses']==base['losses']
        assert read(root/lane/'actual_shape_contract.json')['passed']
        assert read(root/lane/'restore_audit.json')['restored_groups']==3
        require_matching_replay(read(root/lane/'step0_development.json')['result'],source_result)
        for name,enabled in {**plan['lanes'][lane].get('gradient_module_flags',{}),**plan['lanes'][lane].get('gradient_parameter_flags',{})}.items():
            assert (gradients[lane]['gradients'][name]>0)==enabled
    atomic_json(root/'startup_control_audit.json',dict(passed=True,identical_first_inputs_edits_losses=True,all_initial_evaluations_replay_source_exact=True,
        shared_single_z_full_shape_verified=True,enabled_head_gradients_verified=True,restored_three_Adam_groups=True))
    return True


def run_cohort(root,audit_factory=None):
    plan=read(root/'plan.json');children=[];started=time.monotonic();audited=False
    audit=audit_factory or audit_startup
    try:
        for gpu,lane in plan['gpu_workers']:
            env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),PYTHONPATH=str(root/'source_snapshot'))
            with (root/'logs'/f'{lane}.log').open('ab',buffering=0) as log:
                p=subprocess.Popen([sys.executable,'-u','-m',plan.get('worker_module','train_dual.experiments.local_phase_run'),str(root),'--lane',lane],cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            children.append(p)
        atomic_json(root/'status.json',dict(state='running',pids=[p.pid for p in children]))
        while any(p.poll() is None for p in children):
            if time.monotonic()-started>plan['max_seconds']+1800:raise TimeoutError('12hour training plus evaluation ceiling')
            if any(p.poll() not in [None,0] for p in children):raise RuntimeError('Owned local phase worker failed')
            if not audited:audited=audit(root)
            render(root);time.sleep(10)
        if any(p.returncode for p in children):raise RuntimeError('Owned local phase worker failed')
        if not audited:audited=audit(root)
        if not audited:raise RuntimeError('No verified first-step control')
        atomic_json(root/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started));render(root)
    finally:
        for p in children:
            if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)


def controller(queue):
    goal=queue.parent;config=read(queue/'plan.json');parent=goal/config['parent'];parent_queue=goal/config['parent_queue'];started=time.monotonic()
    while True:
        state=read(parent/'status.json',{});qstate=read(parent_queue/'status.json',{});live=predecessor_pids(goal)
        if qstate.get('state')=='failed' or state.get('state')=='failed':raise RuntimeError('Delta predecessor failed; inspect first')
        if not live and qstate.get('state')=='not_run_candidate_for_confirmation':
            atomic_json(queue/'status.json',dict(state='not_run_candidate_for_confirmation'));render(queue);return
        if state.get('state')=='complete' and not live:break
        if len(live)!=1:raise RuntimeError(f'Cannot verify unique delta controller: {live}')
        if time.monotonic()-started>config['wait_seconds']:raise TimeoutError('Predecessor wait ceiling')
        atomic_json(queue/'status.json',dict(state='verified_wait_parent',controller_pids=live,predecessor_state=state.get('state'),predecessor_queue_state=qstate.get('state')));render(queue);time.sleep(20)
    reference=goal/'reference_evaluation.json';rows=candidates(parent,reference)
    if candidate_ready(goal,queue,rows,ALPHAS):
        render(queue);return
    selected=select_source(rows);spillover=source_spillover(parent,selected);atomic_json(queue/'eligibility.json',dict(source=selected,spillover=spillover))
    if not spillover['eligible']:
        atomic_json(queue/'status.json',dict(state='not_run_spillover_condition_absent',source=selected));render(queue);return
    while any(gpu_free().get(g,0)<47000 for g in [2,3,4,5]):
        if time.monotonic()-started>config['wait_seconds']:raise TimeoutError('GPU release wait ceiling')
        atomic_json(queue/'status.json',dict(state='verified_wait_GPU_release'));render(queue);time.sleep(10)
    root=prepare_cohort(queue,parent,selected,spillover);atomic_json(queue/'status.json',dict(state='running',wave=root.name))
    atomic_json(goal/'status.json',dict(state='running_local_phase_controlled_cohort',wave=root.name));render(queue)
    record(goal,'local_phase_cohort_started',root=root.name,source=selected,additional_updates=2048)
    run_cohort(root)
    new=candidates(root,reference);old=read(goal/'candidates.json',{}).get('rows',[])
    for row in new:row['experiment']=root.name
    atomic_json(goal/'candidates.json',dict(rows=[r for r in old if r.get('experiment')!=root.name]+new))
    if not candidate_ready(goal,queue,new,LABELS):
        atomic_json(goal/'status.json',dict(state='cohort_complete_next_hypothesis_required',wave=root.name,goal_achieved=False))
        atomic_json(queue/'status.json',dict(state='complete',wave=root.name,goal_automatically_completed=False));render(queue)
    else:render(queue)
    render_goal(goal)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--lane',choices=list(LABELS));a=p.parse_args();root=a.root.resolve()
    def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        if a.prepare:prepare_queue(root)
        elif a.lane:shared.worker(root,a.lane,objective_factory=criterion,optimizer_factory=restore_local_phase_adam)
        else:controller(root)
    except BaseException as error:
        if not a.prepare:atomic_json((root/a.lane if a.lane else root)/'status.json',dict(state='failed',error=repr(error)))
        raise
