"""Fit common-index global/local matrix codewords with unweighted metrics."""

import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

import numpy as np
import torch

from model.experimental.paired_matrix_state import PairedMatrixOrderBookVAE
from model.experimental.tensor_cluster_state import TensorClusterOrderBookVAE
from train_dual.experiments.long_worker import atomic_json,datasets,evaluate
from train_dual.experiments.pca_run import examples
from train_dual.experiments.window_state_pilot import load_base,strict_precision
from train_dual.util.checkpoint import atomic_save,freeze_sources,load_for_inference,seed_everything,source_hashes


LANES=('joint_l2','joint_max','independent16','independent256')


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
    return h.hexdigest()


def latent_audit(quantizer,g,l):
    quantizer.eval();codes=[];energies=[]
    with torch.inference_mode():
        for start in range(0,len(g),256):
            out=quantizer(g[start:start+256],l[start:start+256]);codes.append(out['codes'].cpu());energies.append(out['residual_energy'].cpu())
    codes=torch.cat(codes);energy=torch.cat(energies);mean=energy.mean(0)
    total=energy.sum(-1);worst=energy.max(-1).values
    result=dict(windows=len(g),code_shape=list(codes.shape),global_shape=list(g.shape[1:]),local_shape=list(l.shape[1:]),
        residual_energy=mean.tolist(),l2_product_squared_mean=total.mean(0).tolist(),max_product_squared_mean=worst.mean(0).tolist(),
        branch_error_increase_fraction=(energy[:,1:]>energy[:,:-1]+energy[:,:1].clamp_min(1)*1e-6).float().mean(0).tolist(),
        distance_note='Raw Frobenius sums; no per-branch or per-coordinate normalization; mean energy reported separately, not used to scale distance',
        code_usage=[],prefixes={})
    for level in range(quantizer.levels):
        row={}
        for branch in (['pair'] if quantizer.mode=='joint' else ['global','local']):
            values=codes[:,level] if quantizer.mode=='joint' else codes[:,level,0 if branch=='global' else 1]
            counts=torch.bincount(values,minlength=quantizer.size).float();p=counts/counts.sum();entropy=float(-(p[p>0]*p[p>0].log2()).sum())
            row[branch]=dict(used_codes=int((counts>0).sum()),size=quantizer.size,counts=counts.int().tolist(),entropy_bits=entropy,perplexity=2**entropy)
        result['code_usage'].append(row)
    for depth in sorted({d for d in (1,2,4,8,16,quantizer.levels) if d<=quantizer.levels}):
        result['prefixes'][str(depth)]=dict(logical_bits=quantizer.logical_bits(depth),
            global_error_ratio=float(mean[depth,0]/mean[0,0].clamp_min(1e-12)),
            local_error_ratio=float(mean[depth,1]/mean[0,1].clamp_min(1e-12)),
            unique_code_paths=int(torch.unique(codes[:,:depth].reshape(len(codes),-1),dim=0).shape[0]))
    return result,codes


def worker(root,lane):
    torch.set_num_threads(4);seed_everything(42);strict_precision();started=time.monotonic()
    plan=json.loads((root/'plan.json').read_text());spec=plan['lanes'][lane];source,norm=load_base(root)
    levels=spec.get('levels',plan['residual_levels'])
    depths=spec.get('depths',plan['depths'])
    if 'tensor_method' in spec:
        model=TensorClusterOrderBookVAE(cluster_method=spec['tensor_method'],cluster_swaps=plan.get('pam_swaps',12),
            matrix_size=spec['size'],matrix_levels=levels,**source['model_config'])
    else:
        model=PairedMatrixOrderBookVAE(matrix_metric=spec['metric'],matrix_mode=spec['mode'],matrix_size=spec['size'],matrix_levels=levels,**source['model_config'])
    model.load_cross_initial(source['model']);model.to('cuda:0').eval()
    folder=root/lane;folder.mkdir(exist_ok=True)
    atomic_json(folder/'status.json',dict(state='running',phase='source_replay'))
    val=datasets(root,source,'val');rows={}

    def progress(value):
        value=dict(value,elapsed_seconds=time.monotonic()-started,reserved_gib=torch.cuda.memory_reserved()/2**30)
        atomic_json(folder/'progress.json',value)
        with (folder/'progress.jsonl').open('a') as f:f.write(json.dumps(value)+'\n')
        print(json.dumps(value),flush=True)

    try:
        model.evaluation_mode='original'
        replay=evaluate(model,norm,val,plan['evaluation_windows'],'cuda:0')
        model.eval()
        expected=json.loads((root/'expected_reference.json').read_text())['result']['metrics']
        delta={key:abs(replay['metrics'][key]['rmse']-expected[key]['rmse']) for key in ('price_usdt','quantity_btc')}
        if max(delta.values())>1e-4:raise RuntimeError(f'Frozen best source replay changed: {delta}')
        rows['original']=replay;atomic_json(folder/'original_evaluation.json',dict(result=replay,differences=delta))
        cache=torch.load(root/'decoder_latents.pt',map_location='cpu',mmap=True,weights_only=False)
        g=cache['global'].to('cuda:0');l=cache['local'].reshape(-1,*model.matrix_quantizer.local_shape).to('cuda:0')
        # Verify actual cached feature alignment before fitting the dictionaries.
        train=datasets(root,source,'train');fit_indices=np.load(root/'fit_indices.npy');positions=[0,4096,8191]
        differences=[]
        with torch.inference_mode():
            for pos in positions:
                raw={k:v.unsqueeze(0) for k,v in train[int(fit_indices[pos])].items()};b=norm.prepare(raw,'cuda:0')
                p=model.encoder(b['price'],b['volume'],b['mask'],b['tick_norm'],times=b['times'],sample=False)
                f=model.fusion([(p['z_global'],p['z_local'])],p['latent_mask'],b['times'])
                torch.testing.assert_close(f['global_latent'],g[pos:pos+1],atol=1e-4,rtol=1e-5)
                torch.testing.assert_close(f['local_latent'].reshape_as(l[pos:pos+1]),l[pos:pos+1],atol=1e-4,rtol=1e-5)
                differences.append(dict(position=pos,global_max=float((f['global_latent']-g[pos:pos+1]).abs().max()),
                    local_max=float((f['local_latent'].reshape_as(l[pos:pos+1])-l[pos:pos+1]).abs().max())))
        atomic_json(folder/'cache_alignment.json',dict(checks=differences,source='decoder-input global/local matrices after Cross Attention'))
        history=model.matrix_quantizer.fit(g,l,iterations=plan['fit_iterations'],max_inner_steps=plan['max_inner_steps'],seed=42,
            callback=lambda value:progress(dict(state='fitting',phase='codebook_fit',**value)))
        atomic_json(folder/'fit_history.json',dict(levels=history))
        train_metrics,train_codes=latent_audit(model.matrix_quantizer,g,l)
        del g,l,cache
        torch.cuda.empty_cache()
        eval_indices=np.unique(np.linspace(0,len(val)-1,plan['evaluation_windows'],dtype=int));vg=[];vl=[]
        with torch.inference_mode():
            for index in eval_indices:
                raw={k:v.unsqueeze(0) for k,v in val[int(index)].items()};b=norm.prepare(raw,'cuda:0')
                p=model.encoder(b['price'],b['volume'],b['mask'],b['tick_norm'],times=b['times'],sample=False)
                f=model.fusion([(p['z_global'],p['z_local'])],p['latent_mask'],b['times'])
                vg.append(f['global_latent']);vl.append(f['local_latent'].reshape(-1,*model.matrix_quantizer.local_shape))
        vg,vl=torch.cat(vg),torch.cat(vl)
        dev_metrics,dev_codes=latent_audit(model.matrix_quantizer,vg,vl)
        atomic_json(folder/'latent_metrics.json',dict(train=train_metrics,development=dev_metrics))
        np.savez_compressed(folder/'codes.npz',train=train_codes.numpy(),development=dev_codes.numpy(),development_indices=eval_indices)
        # Visualize a real paired codeword, not two independently chosen prototypes.
        if spec['mode']=='joint':
            counts=torch.bincount(train_codes[:,0],minlength=spec['size']);popular=int(counts.argmax())
        else:popular=0
        q=model.matrix_quantizer
        np.savez_compressed(folder/'matrix_preview.npz',global_mean=q.global_mean.cpu().numpy(),
            global_code=q.global_codebook[0,popular].cpu().numpy(),local_mean_norm=q.local_mean.reshape(16,2,128,16).square().sum(-1).sqrt().cpu().numpy(),
            local_code_norm=q.local_codebook[0,popular].reshape(16,2,128,16).square().sum(-1).sqrt().cpu().numpy(),code=popular)
        atomic_save(dict(format_version=1,model=model.state_dict(),model_config=source['model_config'],config=source['config'],
            paired_matrix_config=model.paired_matrix_config,source_hashes=source_hashes(),initial_checkpoint=plan['initial_checkpoint'],
            **({'tensor_cluster_config':model.tensor_cluster_config} if hasattr(model,'tensor_cluster_config') else {})),folder/'final.pt')
        for name,mode,depth in [(f'depth{depth}','quantized',depth) for depth in depths]+[('global_only','global_only',levels),('local_only','local_only',levels)]:
            model.evaluation_mode=mode;model.matrix_depth=depth
            progress(dict(state='evaluating',phase='book_reconstruction',evaluation=name,level=depth))
            value=evaluate(model,norm,val,plan['evaluation_windows'],'cuda:0')
            rows[name]=value;atomic_json(folder/(name+'_evaluation.json'),dict(result=value,mode=mode,depth=depth,
                diagnostic_only=mode in ('global_only','local_only')))
            if mode=='quantized':
                target=folder/name;target.mkdir(exist_ok=True);examples(root,target,model,norm,source,plan)
        with torch.inference_mode():
            out=model.matrix_quantizer(vg[:2],vl[:2]);gr,lr=model.matrix_quantizer.decode_codes(out['codes'])
            torch.testing.assert_close(gr,out['global_latent'],atol=0,rtol=0);torch.testing.assert_close(lr,out['local_latent'],atol=0,rtol=0)
        atomic_json(folder/'comparison.json',dict(book=rows,latent=dict(train=train_metrics,development=dev_metrics),
            codebook_global_shape=list(q.global_codebook.shape),codebook_local_shape=list(q.local_codebook.shape),
            codebook_bytes=(q.global_codebook.numel()+q.local_codebook.numel())*4,logical_bits=q.logical_bits(),
            integer_replay_exact=True,metric=spec['metric'],mode=spec['mode'],no_distance_weights=True,
            diagnostic_note='global_only/local_only preserve one original continuous branch; not fully compressed alternatives'))
        atomic_json(folder/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started))
    except BaseException as error:
        atomic_json(folder/'status.json',dict(state='failed',error=repr(error)));raise


def campaign(root):
    children=[];started=time.monotonic()
    try:
        for gpu,lane in zip((2,3,4,5),LANES):
            env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),CUDA_DEVICE_ORDER='PCI_BUS_ID',PYTHONPATH=str(root/'source_snapshot'),
                PYTHONDONTWRITEBYTECODE='1',OMP_NUM_THREADS='4',MKL_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4')
            with (root/'logs'/(lane+'.log')).open('ab',buffering=0) as log:
                p=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.paired_matrix_run',str(root),'--lane',lane],
                    cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True)
            children.append((lane,p))
        atomic_json(root/'status.json',dict(state='running',children=[dict(lane=l,gpu=g,pid=p.pid) for g,(l,p) in zip((2,3,4,5),children)]))
        while any(p.poll() is None for _,p in children):
            if any(p.poll() not in (None,0) for _,p in children):raise RuntimeError('A paired-matrix worker failed')
            if time.monotonic()-started>7200:raise TimeoutError('Paired matrix pilot exceeded two hours')
            time.sleep(3)
        if any(p.returncode!=0 for _,p in children):raise RuntimeError('Nonzero paired-matrix worker exit')
        atomic_json(root/'comparison.json',dict(rows={lane:json.loads((root/lane/'comparison.json').read_text()) for lane in LANES},
            seed=42,source='best uncompressed Cross',independent_test_evaluated=False))
        atomic_json(root/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started))
    except BaseException as error:
        atomic_json(root/'status.json',dict(state='failed',error=repr(error)));raise
    finally:
        for _,p in children:
            if p.poll() is None:
                try:os.killpg(p.pid,signal.SIGTERM)
                except ProcessLookupError:pass
        for _,p in children:
            try:p.wait(timeout=10)
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL)


def prepare(project):
    parent=project/'checkpoints/pca_state_20261024_222656'
    root=project/'checkpoints'/('paired_matrix_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
    root.mkdir();(root/'logs').mkdir();(root/'data').mkdir()
    os.link(parent/'reference/final.pt',root/'initial.pt');os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    for name in ('decoder_latents.pt','fit_indices.npy'):(root/name).symlink_to(os.path.relpath(parent/name,root))
    shutil.copy2(parent/'reference/final_evaluation.json',root/'expected_reference.json')
    shutil.copy2(parent/'reference/profiles.npz',root/'source_profiles.npz')
    old=torch.load(parent/'initial.pt',map_location='cpu',weights_only=False)['model']
    strong=torch.load(parent/'reference/final.pt',map_location='cpu',weights_only=False)['model']
    keys=[k for k in old if k.startswith(('encoder.','fusion.'))]
    if not all(torch.equal(old[k],strong[k]) for k in keys):raise ValueError('Source cache no longer matches frozen encoder/fusion')
    plan=dict(seed=42,initial_checkpoint=str(parent/'reference/final.pt'),initial_sha256=sha(parent/'reference/final.pt'),
        source_cache_exact_tensors=len(keys),fit_windows=8192,global_matrix_shape=[16,64],local_matrix_shape=[16,4096],
        train=['2022-01-01','2025-01-01'],development=['2025-01-01','2025-04-01'],independent_test_untouched=['2025-04-01','2025-07-01'],
        fit_iterations=12,max_inner_steps=2,residual_levels=8,depths=[1,2,4,8],evaluation_windows=128,example_indices=[0,5229,63],
        lanes={'joint_l2':dict(mode='joint',metric='l2',size=256), 'joint_max':dict(mode='joint',metric='max',size=256),
            'independent16':dict(mode='independent',metric='l2',size=16),'independent256':dict(mode='independent',metric='l2',size=256)},
        distance='Unweighted product l2: sqrt(Eg+El); product linfinity: max(sqrt(Eg),sqrt(El)); Eg/El are raw Frobenius sums',
        normalization='None. Training coordinate means are shared translations; no branch variance/size/channel normalization or adjustable weights.',
        hypothesis='A shared index for a pair of matrix prototypes may retain cross-branch consistency better than independent codes',
        source='Post-Cross decoder-input G[16,64] and L[16,2,128,16], reshaped to L[16,4096]. No1024 PCA/window-vector bottleneck.',
        method='Frozen source and book generator; residual codebooks fitted on training matrices. l2 uses means; max uses objective-checked paired prototype updates. No neural encoder training.',
        rate_note='joint256:64 index bits at8levels; independent16:64bits with16x smaller codebooks; independent256:128bits with same codebook scalar count as joint256. No bitpacking, model/codebook/metadata overhead excluded.',
        residual_note='No extra fixedzero skip code; held-out residuals can increase at a level and are reported without clipping.',
        diagnostic_note='Only-global/only-local quantization keeps one original branch; diagnostic, not a fully compressed model.')
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'))
    freeze_sources(root/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'
        f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\n'
        f'cd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.paired_matrix_run "{remote}"\n')
    Path('/tmp/paired_matrix_run_path').write_text(str(root));print(root,flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--lane',choices=LANES);a=p.parse_args()
    if a.prepare:prepare(a.root)
    elif a.lane:worker(a.root,a.lane)
    else:campaign(a.root)
