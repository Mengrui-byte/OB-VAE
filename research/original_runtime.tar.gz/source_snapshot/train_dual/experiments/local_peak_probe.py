"""Read-only Q parameter/output gradient probe for local conditional shape KL."""
import argparse
import math
import os
from pathlib import Path

import numpy as np
import torch

from model.losses.local_peak import peak_neighborhood_kl
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read
from train_dual.experiments.price_safe_readout import file_hash,head_criterion
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import freeze_sources,load_for_inference
from train_dual.util.frozen_quantity import configure_quantity_training,decode_cached_quantity
from train_dual.util.phase_training import tensor_digest


def squared_norm(values):return sum(float(v.detach().float().square().sum()) for v in values if v is not None)


def prepare(goal):
    parent=goal/'frozen_price_quantity'
    if not read(parent/'cache_audit.json',{}).get('passed'):raise ValueError('Need verified source cache')
    root=goal/'local_peak_gradient_probe';root.mkdir();(root/'logs').mkdir()
    for name in ['source.pt','train_cache.pt','train_indices.npy','calibration.json']:os.link(parent/name,root/name)
    plan=dict(read(parent/'plan.json'),probe_parent=str(parent),cache_sha256=read(parent/'cache_audit.json')['cache_sha256'],probe_positions=np.unique(np.linspace(0,31,8,dtype=int)).tolist(),
        probe_scope='Read-only original source on8fixedtrainingwindows. Parameter gradients measured for native Q temporal/spatial groups; not optimization, Adam step, development or independent score.',local_peak_radius=8)
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot')
    project=Path(__file__).resolve().parents[2];remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export CUDA_VISIBLE_DEVICES=2 CUDA_DEVICE_ORDER=PCI_BUS_ID PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.local_peak_probe "{remote}" --worker >> "{remote}/logs/run.log" 2>&1\n')
    print(root,flush=True)


def worker(root):
    torch.set_num_threads(4);strict_precision();plan=read(root/'plan.json');atomic_json(root/'status.json',dict(state='running',pid=os.getpid()))
    assert file_hash(root/'train_cache.pt')==plan['cache_sha256'] and file_hash(root/'source.pt')==plan['source_sha256']
    model,_=load_for_inference(root/'source.pt','cuda:0');configure_quantity_training(model,temporal=True,spatial=True);before=tensor_digest(model)
    cache=torch.load(root/'train_cache.pt',map_location='cpu',weights_only=False);indices=np.load(root/'train_indices.npy');criterion=head_criterion(plan,read(root/'calibration.json')).cuda();params=[(n,p) for n,p in model.named_parameters() if p.requires_grad];rows=[]
    for position in plan['probe_positions']:
        row={name:{k:v.to('cuda:0') for k,v in values.items()} for name,values in cache[position].items()}
        with torch.autocast('cuda',dtype=torch.bfloat16):out=decode_cached_quantity(model,row)
        base=criterion(out,row['batch'])['loss'];local=peak_neighborhood_kl(out['volume'],row['batch']['volume'],row['batch']['mask'],plan['normalization']['quantity_scale'],radius=plan['local_peak_radius'])
        ga=torch.autograd.grad(base,[out['volume'],*[p for n,p in params]],retain_graph=True,allow_unused=True)
        gb=torch.autograd.grad(local,[out['volume'],*[p for n,p in params]],allow_unused=True)
        q0=plan['normalization']['quantity_scale'];dq=q0*torch.sigmoid(out['quantity_logit'].detach())*row['batch']['mask'];a,b=ga[0]*dq,gb[0]*dq
        mask=row['batch']['mask'];target=row['batch']['volume'];q=out['volume'].detach();positive=mask&(target>=100);fn=positive&(q<100);fp=mask&(target<100)&(q>=100)
        B,T,S,L=mask.shape;near=torch.zeros_like(mask);bi,ti,si,li=positive.nonzero(as_tuple=True)
        idx=li[:,None]+torch.arange(-8,9,device=q.device)[None,:];valid=(idx>=0)&(idx<L);idx=idx.clamp(0,L-1)
        near[bi[:,None].expand_as(idx)[valid],ti[:,None].expand_as(idx)[valid],si[:,None].expand_as(idx)[valid],idx[valid]]=True
        groups={}
        for group in ['temporal','spatial','both']:
            selected=[i+1 for i,(name,p) in enumerate(params) if group=='both' or name.startswith('volume_decoder.temporal.')==(group=='temporal')]
            aa=[ga[i] for i in selected];bb=[gb[i] for i in selected];an=squared_norm(aa)**.5;bn=squared_norm(bb)**.5
            dot=sum(float((x.detach().float()*y.detach().float()).sum()) for x,y in zip(aa,bb) if x is not None and y is not None)
            groups[group]=dict(base_norm=an,local_norm=bn,cosine=dot/max(an*bn,1e-12))
        def signs(g):return dict(fn_negative=int((g[fn]<0).sum()),fn_count=int(fn.sum()),near_fp_positive=int((g[fp&near]>0).sum()),near_fp_count=int((fp&near).sum()),norm=float(g.norm()))
        rows.append(dict(position=position,index=int(indices[position]),base_loss=float(base.detach()),local_peak_kl=float(local.detach()),parameter_gradients=groups,raw_output_logit_gradient=dict(base=signs(a),local=signs(b)),scope='Raw logit gradient is via physical quantity Jacobian; does not assert actual Adam step direction.'))
        atomic_json(root/'progress.json',dict(windows=len(rows),total=8,pid=os.getpid()));del out,row,ga,gb
    scales={}
    for group in ['temporal','spatial','both']:
        an=math.sqrt(sum(r['parameter_gradients'][group]['base_norm']**2 for r in rows)/len(rows));bn=math.sqrt(sum(r['parameter_gradients'][group]['local_norm']**2 for r in rows)/len(rows))
        if not math.isfinite(an+bn) or bn<=0:raise ValueError('Local KL has no finite Q parameter gradient')
        scales[group]=dict(base_gradient_rms=an,local_gradient_rms=bn,unit_weight=an/bn,gradient_budget_factors=[0.,.25,1.,4.],proposed_weights=[factor*an/bn for factor in [0.,.25,1.,4.]])
    assert tensor_digest(model)==before and all(p.grad is None for p in model.parameters())
    atomic_json(root/'result.json',dict(rows=rows,gradient_calibration=scales,model_unchanged=True,optimizer_updates=0,independent_data_read=False))
    atomic_json(root/'status.json',dict(state='complete',pid=os.getpid(),model_unchanged=True,optimizer_updates=0));print('Read-only8windowparametergradientprobecomplete',flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--worker',action='store_true');args=p.parse_args();root=args.root.resolve()
    try:
        if args.prepare:prepare(root)
        elif args.worker:worker(root)
    except BaseException as error:
        if not args.prepare:atomic_json(root/'status.json',dict(state='failed',pid=os.getpid(),error=repr(error)))
        raise
