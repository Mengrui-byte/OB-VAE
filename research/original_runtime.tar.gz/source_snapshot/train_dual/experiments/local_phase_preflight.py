"""Read-only full-window architecture smoke; no quality claim or training."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import time

import numpy as np
import torch

from model.autoencoder.local_phase_vae import LocalPhaseOrderBookVAE
from model.autoencoder.regional_phase_vae import RegionalPhaseOrderBookVAE
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.unified_8192_run import call
from train_dual.util.checkpoint import freeze_sources,load_for_inference
from train_dual.util.hint_training import restore_local_phase_adam,restore_regional_phase_adam
from train_dual.util.phase_training import tensor_digest


def file_hash(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(4*1024*1024),b''):digest.update(block)
    return digest.hexdigest()


def prepare(goal,name='local_phase_preflight',regional=False,readout_kernel='einsum'):
    parent=goal/'round_002_fp_rule';source=parent/'source.pt'
    payload=torch.load(source,map_location='cpu',weights_only=False)
    if len(payload.get('optimizer',{}).get('param_groups',[]))!=2:
        raise ValueError('Preflight requires a complete two-group training checkpoint, not inference-only initial.pt')
    root=goal/name;root.mkdir()
    os.link(source,root/'source.pt')
    atomic_json(root/'plan.json',dict(parent=str(parent),index=0,seed=42,threads=8,readout_family='regional' if regional else 'shared',readout_kernel=readout_kernel,
        source_sha256=file_hash(root/'source.pt'),
        scope='CPU FP32 full2048level/256minute architecture and Adam migration preflight. One training window only; no development, confirmation, optimizer updates or candidate quality scores. Does not start the architecture ablation.'))
    atomic_json(root/'status.json',dict(state='prepared'))
    freeze_sources(root/'source_snapshot')
    print(root,flush=True)


def run(root):
    plan=json.loads((root/'plan.json').read_text());parent=Path(plan['parent']);started=time.monotonic()
    torch.set_num_threads(plan['threads']);torch.manual_seed(plan['seed'])
    atomic_json(root/'status.json',dict(state='running',pid=os.getpid()))
    path=root/'source.pt';before=file_hash(path)
    assert before==plan['source_sha256']
    payload=torch.load(path,map_location='cpu',weights_only=False)
    _,norm=load_for_inference(path,'cpu')
    phase=dict(payload['local_hint_config'],use_shape=True,use_mass=True)
    regional=plan.get('readout_family')=='regional'
    if regional:phase['readout_kernel']=plan.get('readout_kernel','einsum')
    model_type=RegionalPhaseOrderBookVAE if regional else LocalPhaseOrderBookVAE
    model=model_type(**phase,**payload['unified_vae_config']).eval()
    missing,extra=model.load_state_dict(payload['model'],strict=False)
    expected=(['local_readout.shape_weight','local_readout.shape_bias','local_readout.mass_weight','local_readout.mass_bias'] if regional else
              ['local_readout.shape.weight','local_readout.shape.bias','local_readout.mass.weight','local_readout.mass.bias'])
    assert missing==expected and not extra
    for name,value in payload['model'].items():torch.testing.assert_close(value,model.state_dict()[name],rtol=0,atol=0)
    named=[name for name,p in model.named_parameters() if not name.startswith(('hint_adapter.','local_readout.'))]
    optimizer=(restore_regional_phase_adam if regional else restore_local_phase_adam)(model,payload['optimizer'],named)
    states=sum(p in optimizer.state for p in model.parameters())
    assert len(optimizer.param_groups)==3 and all(p not in optimizer.state for p in optimizer.param_groups[2]['params'])
    data=dataset(parent,'train');index=plan['index'];raw={k:v.unsqueeze(0) for k,v in data[index].items()}
    assert list(raw['data'].shape)==[1,256,2,2048,2]
    start=int(data.base.starts[index]);times=data.base.times[start:start+256]
    assert len(times)==256 and np.all(np.diff(times//60_000_000)==1)
    batch=norm.prepare(raw,'cpu');seen=[]
    hooks=[d.register_forward_pre_hook(lambda m,a:seen.append(a[0])) for d in [model.price_decoder,model.volume_decoder]]
    with torch.inference_mode():out=call(model,batch,False)
    for h in hooks:h.remove()
    assert seen[0] is seen[1] is out['z']
    assert all(list(out[k].shape)==[1,64,128] for k in ['mu','logvar','z'])
    assert all(list(out[k].shape)==[1,256,2,2048] for k in ['volume','price_norm'])
    torch.testing.assert_close(out['volume'],out['base_volume'],rtol=0,atol=0)
    # Head-only backward on detached post-Z decoder tensors. No optimizer step,
    # no additional label and no claim about full encoder gradient strengths.
    q=out['base_volume'].clone();seed=out['quantity_seed'].clone()
    target=batch['volume'].float();mask=batch['mask']
    with torch.enable_grad():
        predicted=model.local_readout(q,seed,mask,use_shape=True,use_mass=True)
        loss=((predicted-target).square()*mask).sum()/mask.sum()
        loss.backward()
    gradients={n:float(p.grad.norm()) for n,p in model.local_readout.named_parameters()}
    assert all(np.isfinite(v) and v>0 for v in gradients.values())
    with torch.no_grad():
        for name in (['shape_weight','mass_weight'] if regional else ['shape.weight','mass.weight']):
            model.local_readout.get_parameter(name).normal_(0,.01)
    # Verify a fresh decoder can reconstruct from this Z, without Encoder state.
    state=model.state_dict();fresh=model_type(**phase,**payload['unified_vae_config']).eval();fresh.load_state_dict(state)
    def no_encoder(*args):raise AssertionError('Decode-only attempted to use Encoder')
    hook=fresh.encoder.register_forward_pre_hook(no_encoder)
    with torch.inference_mode():
        expected_q=model.local_readout(out['base_volume'],out['quantity_seed'],mask,use_shape=True,use_mass=True)
        decoded=fresh.decode(out['z'],mask,batch['tick_norm'],batch['times'])
        torch.testing.assert_close(decoded['volume'],expected_q,rtol=0,atol=0)
        torch.testing.assert_close(decoded['price_norm'],out['price_norm'],rtol=0,atol=0)
    hook.remove()
    assert file_hash(path)==before
    atomic_json(root/'audit.json',dict(passed=True,scope=plan['scope'],raw_shape=list(raw['data'].shape),
        mu_shape=list(out['mu'].shape),logvar_shape=list(out['logvar'].shape),z_shape=list(out['z'].shape),
        price_shape=list(out['price_norm'].shape),quantity_shape=list(out['volume'].shape),
        seed_shape=list(out['quantity_seed'].shape),consecutive_minute_buckets=True,
        first_utc=str(np.datetime64(int(times[0]),'us')),last_utc=str(np.datetime64(int(times[-1]),'us')),
        source_sha256=before,source_weights_exact=True,zero_head_quantity_exact=True,shared_z=True,
        fresh_decode_no_encoder_exact=True,added_parameters=sum(p.numel() for p in model.local_readout.parameters()),readout_family=plan.get('readout_family','shared'),readout_kernel=plan.get('readout_kernel','einsum'),optimizer_groups=3,inherited_adam_states=states,
        new_adam_states_empty=True,head_only_gradients=gradients,optimizer_updates=0,
        candidate_metrics=None,reserved_data_read=False,elapsed_seconds=time.monotonic()-started))
    atomic_json(root/'status.json',dict(state='complete',passed=True,elapsed_seconds=time.monotonic()-started))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--name',default='local_phase_preflight');p.add_argument('--regional',action='store_true');p.add_argument('--readout-kernel',choices=['einsum','linear'],default='einsum');a=p.parse_args()
    root=a.root.resolve()
    try:
        if a.prepare:prepare(root,a.name,a.regional,a.readout_kernel)
        else:run(root)
    except BaseException as error:
        if not a.prepare:atomic_json(root/'status.json',dict(state='failed',error=repr(error)))
        raise
