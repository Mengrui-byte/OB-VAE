"""Only change relative mid-difference weight, with frozen learned Encoder."""
import argparse
import html
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import torch

from train_dual.experiments import local_hint_run as shared
from train_dual.experiments.decoder_readout_pilot import objective
from train_dual.experiments.goal_evaluate import assess_file
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read,fmt,STYLE
from train_dual.experiments.recall_goal_run import record
from train_dual.experiments.region_task_run import gpu_free
from train_dual.util.checkpoint import freeze_sources
from train_dual.util.hint_training import restore_shape_mass_adam


LABELS={'unscaled':'水平＋1×差分','scaled':'水平＋训练RMS平方比×差分'}


def render(root):
    plan=read(root/'plan.json');status=read(root/'status.json',{})
    text=f'<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="30"><title>价格斜率权重对照</title><style>{STYLE}</style><main><h1>价格水平与一分钟差分：权重单因素</h1><p>状态：{html.escape(status.get("state","prepared"))}。完整256分钟、每侧2048档、唯一8192神经Z。冻结同一个Encoder，价格和数量Decoder训练；所有组数量到价格的几何梯度已截断。</p>'
    text+=f'<p>唯一因素为mid_delta_weight=1或{plan["delta_ratio"]:.6g}，比例仅由之前预选8个训练窗的E[mid²]/E[差分²]计算，是未中心化RMS平方比，未用开发指标选权重。mid水平系数、原损失、32窗、初值、原Adam、样本顺序、seed42和256步预算相同。新数量头均关闭。目标统计的尺度差异不证明梯度或表示不足，必须看实测对照。</p>'
    text+='<table><tr><th>方案</th><th>进度</th><th>检查点</th><th>召回</th><th>精确率</th><th>价格RMSE</th><th>分钟mid变化RMSE</th><th>开发门槛</th><th>图</th></tr>'
    for lane,label in LABELS.items():
        progress=read(root/lane/'progress.json',{})
        for step in [0,128,256]:
            f=root/lane/f'step{step}_development.json'
            if not f.exists():continue
            v=assess_file(f,root.parent/'reference_evaluation.json');link=f'{lane}/step{step}_preview.html'
            vals=[label,progress.get('step',0),step,fmt(v['recall100']),fmt(v['precision100']),fmt(v['price_rmse']),fmt(v['mid_delta_rmse']),v['pass']]
            text+='<tr>'+''.join(f'<td>{html.escape(str(x))}</td>' for x in vals)+(f'<td><a href="{link}">量价线</a></td>' if (root/link).exists() else '<td>—</td>')+'</tr>'
    text+='</table><p>256更新或10分钟，以实际共同完成检查点比较；16个Q1窗仅为已复用开发集，不读取Q2。普通权重组还须与前一试验price组的同128步权重/事件数重放一致，防止实现变化影响归因。目标依旧要求召回严格超过80%并保留原参考价格能力，不能只降低某个损失。</p><p><a href="plan.json">配置</a> · <a href="training_statistics.json">预先锁定训练统计</a> · <a href="replay_audit.json">普通权重重放核验</a> · <a href="../">研究目标</a></p></main>'
    tmp=root/'index.tmp';tmp.write_text(text);tmp.replace(root/'index.html')


def prepare(goal):
    parent=goal/'decoder_readout_pilot';root=goal/'frequency_price_pilot';root.mkdir()
    for name in ['data','logs','seen','unseen',*LABELS]:(root/name).mkdir()
    for split in ['seen','unseen']:
        for lane in LABELS:(root/split/lane).mkdir()
    for name in ['train_indices.npy','val_indices.npy','seen_indices.npy','unseen_indices.npy','calibration_indices.npy','plotly.min.js','teacher.pt','source.pt']:
        os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    stats=read(goal/'price_frequency_statistics.json');ratio=stats['variance_ratio_level_over_delta']
    plan=dict(read(parent/'plan.json'));plan.update(experiment='Onefactor:mid-differencetrainingRMSnormalization',labels=LABELS,
        lanes={lane:dict(hint=False,augmentation=False,use_shape=False,use_mass=False,frozen_modules=['encoder'],mid_delta_weight=ratio if lane=='scaled' else 1.) for lane in LABELS},
        steps=256,checkpoints=[128,256],max_seconds=600,wait_seconds=1800,delta_ratio=ratio,checkpoint_extras={},gpu_workers=[[2,'unscaled'],[4,'scaled']],
        controls='Onlymid_delta_weight1vslockedtrainingRMSsquare_ratio;allotherweights/data/RNG/Adam/model/freeze/geometryroutefixed. Same32-windownewpopulationasreadoutpilot.',delta_ratio_definition='E[c^2]/E[(delta_c)^2],uncenteredsecondmomentsfrom8preselectedtrainingwindows;legacyinputfieldiscalledvariance_ratio,butnoprecomputednumberwaschanged.',
        preview_descriptions={lane:'完整256分钟、唯一8192神经Z。32训练窗固定Encoder的斜率权重单因素实验；Q1已用于研究，不是独立测试。' for lane in LABELS})
    for lane in LABELS:
        os.link(parent/'price/initial.pt',root/lane/'initial.pt')
        plan['checkpoint_extras'][lane]=read(parent/'plan.json')['checkpoint_extras']['price']
    os.link(parent/'price/initial.pt',root/'initial.pt')
    atomic_json(root/'plan.json',plan);(root/'calibration.json').write_bytes((parent/'calibration.json').read_bytes());(root/'training_statistics.json').write_bytes((goal/'price_frequency_statistics.json').read_bytes())
    for split in ['seen','unseen']:
        atomic_json(root/split/'plan.json',dict(plan,preview_descriptions={lane:'训练年代诊断，seen参与预训练，仅部分参与当前32窗；unseen排除原1024索引，非最终独立测试。' for lane in LABELS}));os.link(root/'plotly.min.js',root/split/'plotly.min.js')
    atomic_json(root/'status.json',dict(state='prepared_waiting_owned_pilot'));freeze_sources(root/'source_snapshot');render(root)
    project=Path(__file__).resolve().parents[2];remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 CUDA_DEVICE_ORDER=PCI_BUS_ID OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.frequency_price_pilot "{remote}"\n')
    print(root,flush=True)


def replay_audit(root):
    old=root.parent/'decoder_readout_pilot/price/step128.pt';new=root/'unscaled/step128.pt'
    if not new.exists():return False
    a=torch.load(old,map_location='cpu',weights_only=False);b=torch.load(new,map_location='cpu',weights_only=False)
    assert list(a['model'])==list(b['model'])
    same=all(torch.equal(a['model'][k],b['model'][k]) for k in a['model'])
    atomic_json(root/'replay_audit.json',dict(passed=same,scope='Exact128updatemodelweightsvspriorpricearm,sameoriginalweights+Adam+RNG+32indices',reference=str(old),candidate=str(new)))
    if not same:raise AssertionError('Unscaled control did not reproduce previous model; investigate before attributing frequency effect')
    return True


def campaign(root):
    plan=read(root/'plan.json');parent=root.parent/'decoder_readout_pilot';waiting=time.monotonic();children=[];audited=False
    while True:
        state=read(parent/'status.json',{})
        if state.get('state')=='failed':raise RuntimeError('Predecessor pilot failed')
        if state.get('state')=='complete' and all(gpu_free().get(g,0)>=47000 for g in [2,4]):break
        if time.monotonic()-waiting>plan['wait_seconds']:raise TimeoutError('30minute owned predecessor/idle wait ceiling')
        live=[]
        for pid in state.get('pids',[]):
            try:
                command=Path(f'/proc/{pid}/cmdline').read_bytes().replace(b'\0',b' ').decode()
                if str(parent) in command and 'decoder_readout_pilot' in command:live.append(pid)
            except (FileNotFoundError,ProcessLookupError):pass
        atomic_json(root/'status.json',dict(state='waiting_owned_predecessor',parent_state=state.get('state'),live_worker_pids=live));render(root);time.sleep(10)
    started=time.monotonic()
    try:
        for gpu,lane in plan['gpu_workers']:
            env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),PYTHONPATH=str(root/'source_snapshot'))
            with (root/'logs'/f'{lane}.log').open('ab',buffering=0) as log:
                p=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.frequency_price_pilot',str(root),'--lane',lane],cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            children.append(p)
        atomic_json(root/'status.json',dict(state='running',pids=[p.pid for p in children]))
        while any(p.poll() is None for p in children):
            if time.monotonic()-started>900:raise TimeoutError('15minute frequency pilot ceiling')
            if any(p.poll() not in [None,0] for p in children):raise RuntimeError('Owned frequency worker failed')
            if not audited:audited=replay_audit(root)
            render(root);time.sleep(10)
        if any(p.returncode for p in children):raise RuntimeError('Worker failed')
        if not audited:audited=replay_audit(root)
        common=set.intersection(*[{int(p.stem[4:]) for p in (root/lane).glob('step*.pt') if int(p.stem[4:]) in plan['checkpoints']} for lane in LABELS])
        atomic_json(root/'status.json',dict(state='complete',common_declared_checkpoints=sorted(common),elapsed_seconds=time.monotonic()-started,replay_passed=audited));render(root)
        record(root.parent,'frequency_pilot_complete',wave=root.name,next='Distinguishfrequencylossallocationfromfrozenrepresentation;inspectactualpriceandquantitygates,notmidlossalone.')
    finally:
        for p in children:
            if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--lane',choices=list(LABELS));args=p.parse_args();root=args.root.resolve()
    def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        if args.prepare:prepare(root)
        elif args.lane:shared.worker(root,args.lane,objective_factory=objective,optimizer_factory=restore_shape_mass_adam)
        else:campaign(root)
    except BaseException as error:
        atomic_json(root/'status.json',dict(state='failed',error=repr(error)));raise
