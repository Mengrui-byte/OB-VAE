"""Summarize completed native readout controls without running a model."""
import argparse
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

from train_dual.experiments.goal_evaluate import assess_file
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read
from train_dual.experiments.price_safe_logit_readout import LABELS,file_hash


def report(root):
    if read(root/'status.json',{}).get('state')!='complete':raise ValueError('Wait for the declared common final endpoint')
    steps=[0,512,2048];training={s:read(root/f'train_cache_step{s}.json') for s in steps};rows=[]
    for step in steps:
        for lane in LABELS:
            row=assess_file(root/lane/f'step{step}_development.json',root.parent/'reference_evaluation.json')
            rows.append(dict(lane=lane,step=step,training=training[step][lane],development=row))
    folder=root/'analysis';folder.mkdir(exist_ok=True)
    atomic_json(folder/'metrics.json',dict(rows=rows,scope='32trainingwindowsand16reusedQ1developmentwindows;neitherscoreisanindependentconfirmation',independent_data_read=False))
    fig,axes=plt.subplots(2,2,figsize=(11,7),layout='constrained')
    for lane in LABELS:
        items=[r for r in rows if r['lane']==lane]
        for side,kind in enumerate(['training','development']):
            axes[0,side].plot(steps,[100*r[kind]['recall' if side==0 else 'recall100'] for r in items],marker='o',label=lane)
            axes[1,side].plot(steps,[100*r[kind]['precision' if side==0 else 'precision100'] for r in items],marker='o',label=lane)
    for side,name in enumerate(['32 training windows (in-sample)','16 Q1 development windows (reused)']):
        axes[0,side].set(title=name,ylabel='Same-rank >=100 BTC recall (%)')
        axes[1,side].set(xlabel='Head optimizer updates',ylabel='Precision (%)')
        for row in range(2):
            axes[row,side].set_ylim(0,100);axes[row,side].axhline(80 if row==0 else 50,color='black',ls='--',lw=.8)
            axes[row,side].grid(alpha=.2);axes[row,side].legend(fontsize=8)
    fig.savefig(folder/'fit.png',dpi=180);plt.close(fig)
    final=[r for r in rows if r['step']==2048];baseline=rows[0]['development']
    assert all(r['development']['price_rmse']==baseline['price_rmse'] and r['development']['mid_delta_rmse']==baseline['mid_delta_rmse'] for r in rows)
    verdict=dict(goal_achieved=False,final_native_development_passes=[r['lane'] for r in final if r['development']['pass']],
        price_source_replay_passed=True,source_price_rmse=baseline['price_rmse'],source_mid_delta_rmse=baseline['mid_delta_rmse'],
        interpretation='Frame features improve in-sample linear readout modestly; evaluate paired development results before generalizing. This study does not test full Decoder or Encoder finetuning. Positive threshold loss is not sufficient for joint goal.',
        next='Complete running full-model mid-delta cohort and matched full-model local/regional controls. If investigating fixed-Z capacity, unfreeze quantity Decoder rather than scaling only a linear readout.')
    atomic_json(folder/'conclusion.json',verdict)
    (folder/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>逐档logit读出：最终控制结果</title><style>body{font:17px/1.8 system-ui;max-width:1150px;margin:40px auto}img{width:100%}</style><h1>逐档logit读出：完整2048步结果</h1><p>价格分支保持来源逐值重放。四组固定同一原生8192骨干和训练窗，仅改变读出特征/容量及声明的阈值损失。训练32窗口与开发16窗口不同，不能用两者绝对召回差直接推断过拟合；开发集已用于选型，不是独立测试。</p><img src="fit.png"><p>完整帧特征对样本内拟合有所帮助，不能据此声称开发泛化改善。本轮没有检验完整数量Decoder或Encoder微调，不足以证明latent没有保存细节。</p><p><a href="metrics.json">全部指标</a> · <a href="conclusion.json">结论与边界</a> · <a href="../">完整模型开发集评估表</a></p>')
    inputs=[root/f'train_cache_step{s}.json' for s in steps]+[root/lane/f'step{s}_development.json' for lane in LABELS for s in steps]
    atomic_json(folder/'input_hashes.json',{str(p.relative_to(root)):file_hash(p) for p in inputs})
    print(folder,flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);report(p.parse_args().root.resolve())
