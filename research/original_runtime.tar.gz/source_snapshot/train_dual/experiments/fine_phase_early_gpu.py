"""One training-window GPU implementation check on a completed arm's free GPU."""
import argparse
import os
from pathlib import Path
import subprocess
import sys
import time

import numpy as np
import torch

from model.autoencoder.fine_phase_vae import FinePhaseOrderBookVAE
from train_dual.experiments.fine_phase_run import gpu_preflight
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read, STYLE
from train_dual.experiments.price_safe_readout import file_hash
from train_dual.experiments.recall_goal_run import record
from train_dual.experiments.region_task_run import gpu_free
from train_dual.util.checkpoint import atomic_save, freeze_sources


def prepare(goal,probe_name='fine_phase_early_gpu_v2'):
    if Path(probe_name).name!=probe_name or not probe_name.startswith('fine_phase_early_gpu'):
        raise ValueError('Need a simple owned early GPU probe name')
    root=goal/probe_name;root.mkdir()
    for name in ['data','logs','log']:(root/name).mkdir()
    parent=goal/'round_004_local_phase';parent_plan=read(parent/'plan.json');cpu=read(goal/'fine_phase_preflight/audit.json')
    plan={key:parent_plan[key] for key in ['train','development','window_size','stride','normalization','input_shape','latent_shape','output_shape']}
    assert cpu['passed'] and cpu['optimizer_updates']==0
    # Use the exact architecture already scheduled; this probe cannot quietly
    # validate a later working implementation instead of the queued one.
    queue=goal/'fine_phase_after_v2'
    for source_name,digest in read(queue/'source_snapshot/sha256.json').items():
        if source_name.startswith('model/') or source_name=='train_dual/experiments/fine_phase_run.py':
            if file_hash(Path(__file__).resolve().parents[2]/source_name)!=digest:raise ValueError('Queued implementation changed: '+source_name)
    assert file_hash(parent/'source.pt')==read(queue/'plan.json')['source_sha256']
    os.link(parent/'source.pt',root/'source.pt');os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    os.link(parent/'plan.json',root/'source_parent_plan.json')
    np.save(root/'train_indices.npy',np.load(parent/'train_indices.npy')[:1])
    payload=torch.load(root/'source.pt',map_location='cpu',weights_only=False)
    config=dict(payload['local_hint_config'],fine_enabled=True,fine_transform='log1p',fine_hidden=256)
    model=FinePhaseOrderBookVAE(**config,**payload['unified_vae_config'])
    missing,unexpected=model.load_state_dict(payload['model'],strict=False)
    assert len(missing)==6 and all(n.startswith('encoder.fine_phase.') for n in missing) and not unexpected
    atomic_save(dict(format_version=1,model=model.state_dict(),unified_vae_config=payload['unified_vae_config'],local_hint_config=payload['local_hint_config'],fine_phase_config=config,config=payload['config'],step=0,diagnostic_only=True),root/'log/initial.pt')
    pids=read(parent/'status.json')['pids'];assert len(pids)==4
    plan.update(experiment='Early GPU implementation probe for queued fine Encoder',source_sha256=file_hash(root/'source.pt'),
        parent=parent.name,owned_workers={lane:dict(pid=pid,gpu=gpu) for (gpu,lane),pid in zip(parent_plan['gpu_workers'],pids)},
        fine_phase_config=config,added_Encoder_parameters=sum(p.numel() for p in model.encoder.fine_phase.parameters()),added_Decoder_parameters=0,
        max_wait_seconds=3600,max_probe_seconds=900,
        eligibility='Only a completed round004 treatment arm with step2048/evaluation saved, exact worker handle gone, GPU>=47000MiBfree, original control still live and below1952. If the window closes, skip; production preflight remains required.',
        scope='One predeclared2022trainingwindow,actual256minute/2048level/8192Gaussian GPUzero-source/BF16backward/nonzeroZ-only check. No optimizer updates, no development or independent inference. Not a reconstruction experiment or eligible model.')
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot')
    project=Path(__file__).resolve().parents[2];remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.fine_phase_early_gpu "{remote}" --controller >> "{remote}/logs/controller.log" 2>&1\n')
    (root/'index.html').write_text('<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="30"><style>'+STYLE+'</style><main><h1>新Encoder：空闲尾部显卡上的GPU实现核验</h1><p>仅使用已完成组释放的GPU3/4/5和原训练窗口；不读取开发或独立数据，不执行优化器更新。检查新路径的全尺寸来源重放、BF16反向和非零路径的新实例Z-only解码。这不构成模型效果结论，后续完整训练仍须重新核验自己的初始权重。</p><p><a href="status.json">状态</a> · <a href="gpu_preflight/audit.json">实际GPU核验</a> · <a href="plan.json">预先协议</a></p></main>')
    print(root,flush=True)


def worker_live(parent,lane,pid,proc_root=Path('/proc')):
    try:args=(proc_root/str(pid)/'cmdline').read_bytes().split(b'\0')
    except FileNotFoundError:return False
    return b'train_dual.experiments.local_phase_run' in args and os.fsencode(str(parent)) in args and b'--lane' in args and lane.encode() in args


def controller(root):
    plan=read(root/'plan.json');goal=root.parent;parent=goal/plan['parent'];start=time.monotonic();control=plan['owned_workers']['control']
    while True:
        step=read(parent/'control/progress.json',{}).get('step',0)
        if (goal/'candidate_for_confirmation.json').exists() or not worker_live(parent,'control',control['pid']) or step>=1952:
            atomic_json(root/'status.json',dict(state='not_run_tail_window_closed',pid=os.getpid(),control_step=step));return
        if time.monotonic()-start>plan['max_wait_seconds']:raise TimeoutError('Declared early preflight wait ceiling')
        free=gpu_free();selected=None
        for lane in ['shape','mass','both']:
            spec=plan['owned_workers'][lane];state=read(parent/lane/'status.json',{})
            if state.get('state')=='complete' and state.get('step')==2048 and (parent/lane/'step2048_development.json').exists() and not worker_live(parent,lane,spec['pid']) and free.get(spec['gpu'],0)>=47000:
                selected=dict(lane=lane,**spec);break
        if selected:break
        atomic_json(root/'status.json',dict(state='verified_wait_owned_treatment_finish',pid=os.getpid(),control_pid=control['pid'],control_step=step));time.sleep(20)
    atomic_json(root/'status.json',dict(state='GPU_preflight',pid=os.getpid(),gpu=selected['gpu'],released_owned_worker=selected['pid']))
    env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(selected['gpu']),PYTHONPATH=str(root/'source_snapshot'))
    with (root/'logs/gpu.log').open('ab',buffering=0) as log:
        result=subprocess.run([sys.executable,'-u','-m','train_dual.experiments.fine_phase_early_gpu',str(root),'--gpu'],cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=plan['max_probe_seconds'])
    if result.returncode or not read(root/'gpu_preflight/audit.json',{}).get('passed'):raise RuntimeError('Early fine Encoder GPU implementation check failed')
    atomic_json(root/'status.json',dict(state='complete',pid=os.getpid(),gpu=selected['gpu'],optimizer_updates=0,independent_data_read=False))
    record(goal,'fine_phase_early_GPU_preflight',root=root.name,passed=True,gpu=selected['gpu'],actual_train_window=int(np.load(root/'train_indices.npy')[0]),optimizer_updates=0,not_a_goal_candidate=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--name',default='fine_phase_early_gpu_v2');p.add_argument('--prepare',action='store_true');p.add_argument('--controller',action='store_true');p.add_argument('--gpu',action='store_true');args=p.parse_args();root=args.root.resolve()
    try:
        if args.prepare:prepare(root,args.name)
        elif args.controller:controller(root)
        elif args.gpu:gpu_preflight(root)
    except BaseException as error:
        if not args.prepare:atomic_json(root/'status.json',dict(state='failed',pid=os.getpid(),error=repr(error)))
        raise
