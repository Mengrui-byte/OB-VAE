"""Livegradient-route experiment report with per-checkpoint path audits."""
import argparse
import json
from pathlib import Path
import threading
from train_dual.experiments.full_window_report import PAGE,monitor
from train_dual.experiments.long_worker import atomic_json


def read(path,default=None):
 try:return json.loads(path.read_text())
 except (OSError,ValueError):return default


def audit_data(root):
 plan=read(root/'plan.json');preflight=read(root/'route_preflight.json');rows={}
 for lane in plan['lanes']:
  files=sorted((root/lane).glob('step*_route_audit.json'),key=lambda p:int(p.name.split('_')[0][4:]));latest=read(files[-1]) if files else (preflight or {}).get('rows',{}).get(lane)
  rows[lane]=dict(label=plan['labels'][lane],flags=plan['gradient_routes'][lane],latest=latest)
 if (root/'public').exists():atomic_json(root/'public/route_audits.json',dict(preflight=preflight,rows=rows))


def main(root):
 root=root.resolve();page=PAGE.replace('256分钟双分支实验','8192梯度路径对照').replace('完整256分钟：双分支与整窗矩阵压缩','8192瓶颈：数量梯度路径2×2控制实验')
 begin=page.index('<p>实际输入');end=page.index('<p id=status>',begin)
 text=('<p>四组共同起点：此前已诊断的分布KL＋总量模型第256追加步（AE2048＋256），完全相同的权重和AdamW动量。保持完整256分钟输入、64×128唯一Z、结构、损失权重、64训练窗/16开发窗、seed42、batch1累积4与512次追加更新，只改变数量梯度路径。</p>'
 '<p>2×2因素：是否阻断数量Decoder读取Z时的直接梯度；是否阻断预测价格/gap进入数量几何编码器时的梯度。detach只改反向图，Z和预测数值不变；Encoder及价格Decoder仍由价格损失更新。仅阻断Z时，数量梯度仍能经价格条件间接回到Encoder。数量Decoder的几何处理器在四组中均训练。</p>'
 '<p>全局clip1及共同历史Adam动量保留，所以阻断直接数量梯度不等于去除所有优化耦合。训练图统一显示原基础损失base_loss，各组实际目标另存。2025Q1为重复使用的开发期，2026与独立测试未参与。步数为本轮追加更新。</p>')
 page=page[:begin]+text+page[end:];page=page.replace('实际矩阵','实际唯一latent').replace("'训练损失'","'共同基础损失'")
 table='<h2>数量梯度路径的实际审计</h2><p id=routeNote>预检进行中</p><table><thead><tr><th>方案</th><th>阻断直接Z</th><th>阻断价格条件</th><th>审计步数</th><th>Encoder数量梯度L2</th><th>价格Decoder数量梯度L2</th><th>数量几何层梯度L2</th><th>帧汇总层量价cos</th></tr></thead><tbody id=routeRows></tbody></table><p>全阻断组预期Encoder和价格Decoder的数量梯度为零；它们的价格梯度仍保留。这是控制条件，不解释为断梯度故障。</p>'
 page=page.replace('<h2>首步实际梯度范数</h2>',table+'<h2>首步实际梯度范数</h2>')
 js='''<script>(function(){async function audit(){let d=await(await fetch('route_audits.json?t='+Date.now())).json(),rows=[];let fmt=x=>Number.isFinite(x)?x.toPrecision(5):'—';for(let [k,v] of Object.entries(d.rows)){let a=v.latest,g=a?.groups||{},tr=document.createElement('tr');for(let x of [v.label,v.flags.detach_quantity_latent?'是':'否',v.flags.detach_quantity_geometry?'是':'否',a?.after_optimizer_update??(a?0:'待检查'),fmt(g.encoder?.quantity_gradient_l2),fmt(g.price_decoder?.quantity_gradient_l2),fmt(g['volume_decoder.geometry']?.quantity_gradient_l2),fmt(g['encoder.frame']?.cosine)]){let td=document.createElement('td');td.textContent=x;tr.append(td)}rows.push(tr)}document.getElementById('routeRows').replaceChildren(...rows);document.getElementById('routeNote').textContent=d.preflight?.passed?'真实256×2048预检通过：四组价格、挂量、Z前向数值一致；价格损失梯度一致；两条数量路径的梯度与开关一致。':'真实尺寸预检尚在进行'}audit().catch(console.error);setInterval(()=>audit().catch(console.error),15000)})()</script>'''
 page=page.replace('</html>',js+'</html>')
 stop=threading.Event()
 def watch():
  while not stop.is_set():audit_data(root);stop.wait(10)
 thread=threading.Thread(target=watch,daemon=True);thread.start()
 try:monitor(root,page)
 finally:stop.set();thread.join(timeout=2);audit_data(root)

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);main(p.parse_args().root)
