"""Training-only fixed-output controls: does simple adjacent-rank sharpening help?"""
import argparse
import os
from pathlib import Path

import numpy as np
import torch

from model.layers.quantity_sharpen import sharpen_quantity
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read, STYLE
from train_dual.experiments.recall_goal_run import record
from train_dual.util.checkpoint import freeze_sources


def run(goal):
    torch.set_num_threads(4)
    parent = goal / 'paired_logit_readout'
    root = goal / 'quantity_sharpen_training_probe'
    root.mkdir()
    coefficients = [0., .125, .25, .5, 1., 2., 4.]
    for name in ['train_cache.pt', 'train_indices.npy']:
        os.link(parent / name, root / name)
    atomic_json(root / 'plan.json', dict(coefficients=coefficients, radius=1, seed=42, windows=32,
        source='Byte-identical original paired_logit_readout training cache',
        factor='Fixed qhat + gamma*(2qhat_l-qhat_(l-1)-qhat_(l+1)), clamped nonnegative; full valid triplets only. No time/side mixing.',
        control='gamma0 uses exact source outputs, same32trainingtargets. All model optimizer updates0; no precision/architecture/loss selection on development.',
        selection='Keep a hypothesis only if same coefficient improves BOTH pooled R100 and P100, withqRMSE<=1.1source. Compare fixed coefficients before reading any new development data.',
        scope='Training-only output feasibility check. No Encoder inference, no independent data, no goalcandidate.',
        raw_input_contract=[1,256,2,2048,2], latent_contract=[1,64,128], full_output_contract=[1,256,2,2048]))
    freeze_sources(root / 'source_snapshot')
    atomic_json(root / 'status.json', dict(state='training_cache_analysis', pid=os.getpid()))
    cache = torch.load(root / 'train_cache.pt', map_location='cpu', weights_only=False, mmap=True)
    indices = np.load(root / 'train_indices.npy')
    results = []
    for coefficient in coefficients:
        rows = []
        for index, item in zip(indices, cache):
            target, mask = item['batch']['volume'], item['batch']['mask']
            original = item['out']['volume']
            assert list(target.shape) == [1,256,2,2048]
            prediction = sharpen_quantity(original, mask, coefficient)
            if coefficient == 0:
                torch.testing.assert_close(prediction, original, rtol=0, atol=0)
            positive, predicted = (target >= 100.) & mask, (prediction >= 100.) & mask
            rows.append(dict(index=int(index), tp=int((positive & predicted).sum()), fp=int((~positive & predicted & mask).sum()), fn=int((positive & ~predicted).sum()),
                q_sse=float((prediction.double() - target.double()).masked_select(mask).square().sum()), count=int(mask.sum())))
        pooled = {key: sum(row[key] for row in rows) for key in ['tp','fp','fn','q_sse','count']}
        pooled.update(recall=pooled['tp'] / (pooled['tp'] + pooled['fn']), precision=pooled['tp'] / (pooled['tp'] + pooled['fp']), quantity_rmse=(pooled['q_sse']/pooled['count'])**.5)
        results.append(dict(coefficient=coefficient, pooled=pooled, per_window=rows))
    base = results[0]['pooled']
    for row in results:
        m = row['pooled']
        row['training_hypothesis_pass'] = m['recall'] > base['recall'] and m['precision'] > base['precision'] and m['quantity_rmse'] <= 1.1*base['quantity_rmse']
    passing = [row for row in results if row['training_hypothesis_pass']]
    atomic_json(root / 'result.json', dict(rows=results, hypothesis_supported=bool(passing), independent_data_read=False, optimizer_updates=0, is_goal_candidate=False))
    table = '<table><tr><th>锐化系数</th><th>训练召回</th><th>训练精确率</th><th>数量RMSE</th><th>训练筛选通过</th></tr>'
    for row in results:
        m = row['pooled']
        table += f'<tr><td>{row["coefficient"]}</td><td>{m["recall"]:.6f}</td><td>{m["precision"]:.6f}</td><td>{m["quantity_rmse"]:.6f}</td><td>{row["training_hypothesis_pass"]}</td></tr>'
    text = '<h1>训练缓存：相邻档位固定锐化对照</h1><p>相同32个既有训练窗、相同来源输出、0次模型更新，仅改变一阶邻域Laplacian残差系数。只分析训练缓存，未读取开发/独立集；不能当作模型或目标成绩。mask边缘保持原值，非负截断可能改变总量，因此同时约束数量误差。</p>'
    (root/'index.html').write_text('<!doctype html><meta charset="utf-8"><style>'+STYLE+'</style><main>'+text+table+'</table><p><a href="result.json">逐窗结果</a> · <a href="plan.json">预先协议</a></p></main>')
    atomic_json(root/'status.json', dict(state='complete', pid=os.getpid()))
    record(goal,'quantity_sharpen_training_probe',root=root.name,hypothesis_supported=bool(passing),rows=[dict(coefficient=x['coefficient'],**x['pooled']) for x in results],goal_candidate=False)
    print(root, flush=True)
    for row in results:
        print(row['coefficient'],row['pooled'],row['training_hypothesis_pass'],flush=True)


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('goal',type=Path)
    args=parser.parse_args()
    run(args.goal.resolve())
