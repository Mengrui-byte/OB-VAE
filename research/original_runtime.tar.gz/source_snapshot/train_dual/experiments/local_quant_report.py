"""Live/final browser report for reconstruction-first local quantization."""

import argparse
from datetime import datetime,timezone
import json
from pathlib import Path
import time

import numpy as np

from train_dual.experiments.book_stem_viewer import build


LABELS={'local4_frozen':'局部4级·冻结生成器','local8_frozen':'局部8级·冻结生成器',
        'local8_books':'局部8级·重建训练码本','local8_joint':'局部8级·码本和生成器联合适配'}
PAGE='''<!doctype html><html lang=zh-CN><meta charset=utf-8><title>量化后的订单簿重建</title><script src=plotly.min.js></script><style>body{font:16px system-ui;max-width:1500px;margin:30px auto;padding:0 20px;color:#182b43}p{line-height:1.8}td,th{padding:9px;border:1px solid #ddd}table{border-collapse:collapse;width:100%}.plots{display:grid;grid-template-columns:1fr 1fr}a{color:#2563eb}</style><h1>量化后保住订单簿重建</h1><p>小码本K=16保持不变，在16个时间×128个深度位置分别选一个双矩阵码字：Global片段[1,64]、Local买卖两侧片段[2,16]共享索引，使用原始无权重乘积L2。Global由各深度位置的码字重建值作固定平均；Local按原位置恢复。解码只依赖整数码、固定训练均值及原模型已有mask/tick/anchor元数据，没有连续latent旁路。</p><p><b>码率增加已单独列出。</b>4级为4KiB/窗口，8级为8KiB/窗口；旧整窗8级×16码只有4字节。每级小码本不等于整窗索引很少。码本分别24/48KiB；共享位置均值260KiB，源模型和元数据成本另计。码尚未位打包。原float32双矩阵latent为260KiB/窗口。</p><p>训练2022—2024，原8192窗口；开发2025Q1固定128窗口，已用于研究选型；2025Q2未使用。单种子42，GPU2—5。没有语义头、未来收益或分支距离权重。冻结源编码器与Cross，只在指定组用订单簿价量、尾部挂量、分钟变化及latent重建误差更新码本/生成器。</p><p id=status>加载进度</p><p><a href=./>逐档挂单重建</a> · <a href=previous/>上一轮整窗量化</a> · <a href=reconstruction_plan.json>配置和损失系数</a> · <a href=reconstruction_progress.json>完整数据</a></p><table><thead><tr><th>GPU</th><th>方案</th><th>状态</th><th>阶段</th><th>步数</th><th>耗时秒</th></tr></thead><tbody id=progress></tbody></table><h2>同128个开发窗口的重建</h2><table><thead><tr><th>方案/阶段</th><th>索引KiB/窗口</th><th>价格RMSE USDT</th><th>数量RMSE BTC</th><th>分钟log挂量变化相关</th><th>变化幅度比</th><th>≥100BTC召回</th><th>≥100BTC精确率</th><th>预测最大挂量BTC</th></tr></thead><tbody id=results></tbody></table><p>预先设定的试验目标：价格RMSE≤10USDT、数量RMSE≤1BTC、分钟挂量变化相关≥0.9、大单召回≥80%；这是试验门槛，不是已实现承诺。分钟变化按同侧排序档位计算，不等于逐笔增撤单流量。</p><div class=plots><div id=loss></div><div id=tail></div></div><script>const labels={local4_frozen:'局部4级·冻结',local8_frozen:'局部8级·冻结',local8_books:'局部8级·训练码本',local8_joint:'局部8级·联合适配'},f=(x,n=3)=>Number.isFinite(x)?x.toFixed(n):'—';function row(a){let r=document.createElement('tr');for(let v of a){let c=document.createElement('td');c.textContent=v;r.append(c)}return r}function result(label,x,bits){let m=x.metrics,t=x.thresholds['100'],q=m.temporal_log_quantity_1_minutes;return row([label,bits==null?'连续':f(bits/8192,3),f(m.price_usdt.rmse),f(m.quantity_btc.rmse),f(q.correlation),f(q.centered_amplitude_ratio),f(t.recall*100,1)+'%',f(t.precision*100,1)+'%',f(x.prediction_max,1)])}async function refresh(){let d=await(await fetch('reconstruction_progress.json?t='+Date.now())).json();document.getElementById('status').textContent='状态：'+d.status.state;let p=[],r=[];if(d.reference)r.push(result('未压缩Cross',d.reference,null));if(d.old)r.push(result('旧整窗8级×16码',d.old,32));let i=2;for(let [lane,label] of Object.entries(labels)){let v=d.lanes[lane]||{},g=v.progress||{};p.push(row([i++,label,v.status?.state||'等待',g.phase||'—',g.step?g.step+'/'+g.total:'—',f(g.elapsed_seconds,1)]));let depth=lane.startsWith('local4')?4:8,bits=16*128*depth*4;if(v.initial)r.push(result(label+'·适配前',v.initial,bits));if(v.final)r.push(result(label+'·最终',v.final,bits))}document.getElementById('progress').replaceChildren(...p);document.getElementById('results').replaceChildren(...r);for(let [id,key,title] of [['loss','loss','重建适配训练损失'],['tail','volume_tail','训练窗口大单log重建误差']]){let traces=[];for(let [lane,v] of Object.entries(d.lanes)){let h=(v.history||[]).filter(x=>x.step);if(h.length)traces.push({x:h.map(x=>x.step),y:h.map(x=>x[key]),name:labels[lane],mode:'lines+markers'})}Plotly.react(id,traces,{height:360,title,template:'plotly_white',xaxis:{title:'优化步数'}},{responsive:true,displaylogo:false})}}refresh().catch(console.error);setInterval(()=>refresh().catch(console.error),10000);</script></html>'''


def final_viewer(root,previous):
    folder=root/'report';folder.mkdir(exist_ok=True)
    with np.load(root/'source_profiles.npz') as p:
        arrays={k:p[k] for k in ('truth','mask','time','indices')};arrays['source']=p['prediction']
    config=[dict(key='truth',label='真实订单簿',color='#2563eb'),dict(key='source',label='未压缩Cross',color='#64748b')]
    old=root.parent/'small_codebook_20261025_143930/k16_l8/depth8'
    selected=[(old,'old','旧整窗8级×16码')]+[(root/lane,lane,label) for lane,label in LABELS.items()]
    for (source,key,label),color in zip(selected,['#94a3b8','#eab308','#9333ea','#16a34a','#ef4444']):
        with np.load(source/'profiles.npz') as p:
            np.testing.assert_array_equal(p['truth'],arrays['truth']);arrays[key]=p['prediction']
        config.append(dict(key=key,label=label,color=color))
    np.savez_compressed(folder/'profiles.npz',**arrays)
    rows=json.loads((root/'comparison.json').read_text())['rows']
    eligible=[lane for lane,x in rows.items() if x['pilot_gates']['price']]
    best=min(eligible or list(rows),key=lambda lane:rows[lane]['final']['metrics']['quantity_btc']['rmse'])
    (folder/'comparison.json').write_text(json.dumps(dict(viewer_variants=config,default_model=[x['key'] for x in config].index(best),
        seed=42,common_step=512,step_note='局部双矩阵整数码重建；完整码率与适配对照见报告。',comparison_label='量化重建指标与训练进度',results=rows),ensure_ascii=False))
    (folder/'index.html').write_text('<!doctype html><meta charset=utf-8><meta http-equiv=refresh content="0;url=../reconstruction.html">')
    viewer=root/'viewer';build(folder,viewer)
    for name in ('reconstruction.html','reconstruction_progress.json','reconstruction_plan.json'):(viewer/name).symlink_to(root/'public'/name)
    (viewer/'previous').symlink_to(previous,target_is_directory=True)
    return viewer


def monitor(root):
    root=root.resolve();public=root/'public';public.mkdir(exist_ok=True)
    selector=root.parents[1]/'.local/dual_viewer/current.json';previous=Path(json.loads(selector.read_text())['directory'])
    (public/'reconstruction.html').write_text(PAGE);(public/'reconstruction_plan.json').symlink_to(root/'plan.json')
    (public/'previous').symlink_to(previous,target_is_directory=True)
    for name in ('index.html','book.f64','mask.u8','viewer.json','plotly.min.js','comparison','audit.json'):
        source=previous/name
        if source.exists():(public/name).symlink_to(source,target_is_directory=source.is_dir())
    temp=selector.with_suffix('.tmp');temp.write_text(json.dumps(dict(directory=str(public))));temp.replace(selector)
    while True:
        try:
            status=json.loads((root/'status.json').read_text());lanes={};reference=None
            for lane in LABELS:
                value={}
                for key in ('status','progress'):
                    p=root/lane/(key+'.json')
                    if p.exists():value[key]=json.loads(p.read_text())
                for key in ('initial','final','original'):
                    p=root/lane/(key+'_evaluation.json')
                    if p.exists():
                        evaluation=json.loads(p.read_text())['result']
                        if key=='original':reference=evaluation
                        else:value[key]=evaluation
                p=root/lane/'progress.jsonl';value['history']=[]
                if p.exists():
                    for line in p.read_text().splitlines():
                        try:value['history'].append(json.loads(line))
                        except ValueError:pass
                lanes[lane]=value
            old=json.loads((root.parent/'small_codebook_20261025_143930/k16_l8/depth8_evaluation.json').read_text())['result']
            payload=dict(utc=datetime.now(timezone.utc).isoformat(),status=status,lanes=lanes,reference=reference,old=old)
            temp=public/'reconstruction_progress.json.tmp';temp.write_text(json.dumps(payload));temp.replace(public/'reconstruction_progress.json')
            if status['state']=='complete':
                viewer=final_viewer(root,previous);temp=selector.with_suffix('.tmp');temp.write_text(json.dumps(dict(directory=str(viewer))));temp.replace(selector)
                (root/'published.json').write_text(json.dumps(dict(directory=str(viewer))));break
            if status['state']=='failed':break
        except FileNotFoundError:pass
        time.sleep(10)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);monitor(p.parse_args().root)
