"""Matched direct quantity readout: identical affine/GELU residual parameters."""
import argparse
from copy import deepcopy
import html
import math
import os
from pathlib import Path
import time

import numpy as np
import torch

from train_dual.experiments import local_hint_run as shared
from train_dual.experiments.confirm_recall_goal import require_matching_replay
from train_dual.experiments.direct_readout_preflight import pilot_released
from train_dual.experiments.goal_evaluate import assess_file
from train_dual.experiments.log_relative_detail_run import run_cohort
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read, STYLE
from train_dual.experiments.price_safe_readout import file_hash
from train_dual.experiments.recall_goal_run import record
from train_dual.experiments.region_task_run import gpu_free
from train_dual.util.checkpoint import freeze_sources
from train_dual.util.direct_readout_training import restore_direct_readout_adam
from train_dual.util.inherited_book_loss import inherited_book_loss
from train_dual.util.quantity_strata import evaluate_with_quantity_strata

MODULE = 'train_dual.experiments.direct_readout_run'
LABELS = dict(identity='直接逐档线性控制', gelu='直接逐档GELU')


def first_batch_equal(rows):
    a, b = rows['identity'], rows['gelu']
    assert a['training_indices'] == b['training_indices'] and a['edits'] == b['edits']
    assert a['losses'] == b['losses'], 'Zero-initialized branches must have identical first losses'


def resources_ready(root, *, free=None, proc=Path('/proc')):
    p = read(root / 'plan.json'); goal = root.parent; branch = goal / p['reference_parent']
    if read(branch / 'status.json', {}).get('state') != 'running': return False
    if not pilot_released(goal / p['completed_pilot'], p['completed_pilot_workers'], proc): return False
    for lane, pid in p['slow_workers'].items():
        try: args = (proc / str(pid) / 'cmdline').read_bytes().split(b'\0')
        except FileNotFoundError: args = []
        if not (b'train_dual.experiments.branch_precision_run' in args and str(branch).encode() in args and lane.encode() in args):
            raise RuntimeError('Exact slow precision worker missing before direct readout run')
        progress = read(branch / lane / 'progress.json')
        if progress['total'] - progress['step'] < p['minimum_slow_remaining_steps']: return False
    available = gpu_free() if free is None else free
    return all(available.get(gpu, 0) >= 47000 for gpu in [2, 3])


def prepare(goal):
    previous = goal / 'relative_aggregation_early_pilot_20261028'
    assert read(previous / 'status.json')['state'] == 'complete'
    assert read(previous / 'common512_analysis.json')['Encoder_price_tensors_and_native_price_metrics_unchanged']
    prep = goal / 'direct_readout_preparation_20261029'
    functional = goal / 'direct_readout_full_gpu_preflight_20261029'
    assert read(functional / 'result.json')['state'] == 'passed_full2048_functional_preflight'
    old = read(previous / 'plan.json'); prepared = read(prep / 'plan.json')
    assert old['source_sha256'] == prepared['source_sha256'] == file_hash(prep / 'source.pt')
    root = goal / 'direct_readout_activation_pilot_20261029'; root.mkdir()
    for name in ['data', 'logs', 'seen', 'unseen', *LABELS]: (root / name).mkdir()
    for split in ['seen', 'unseen']:
        for lane in LABELS: (root / split / lane).mkdir()
    os.link(prep / 'source.pt', root / 'source.pt')
    for name in ['teacher.pt', 'calibration.json', 'quantity_calibration.json', 'detail_calibration.json',
                 'train_indices.npy', 'val_indices.npy', 'seen_indices.npy', 'unseen_indices.npy',
                 'quantity_calibration_indices.npy', 'plotly.min.js']:
        if (previous / name).exists(): os.link(previous / name, root / name)
    os.link(previous / 'data/BTCUSDT.npz', root / 'data/BTCUSDT.npz')
    p = deepcopy(old)
    for key in ['relative_aggregation_pilot', 'relative_aggregation_ablation', 'calibration_gradient_module',
                'calibration_relative_arm', 'reference_bindings', 'reference_control_policy']:
        p.pop(key, None)
    extras = {}
    for lane in LABELS:
        os.link(prep / f'initial_{lane}.pt', root / lane / 'initial.pt')
        extras[lane] = deepcopy(old['checkpoint_extras']['per_position'])
        extras[lane]['direct_readout_config'] = dict(readout_activation=lane, readout_hidden=2048, readout_seed=42)
    weight = extras['identity']['relative_detail_loss_config']['relative_weight']
    assert weight == read(previous / 'aggregation_calibration.json')['shared_relative_weight']
    p.update(experiment='同参数直接逐档读出：两层线性vsGELU', direct_readout_activation_pilot=True,
        labels=LABELS, lanes={lane: deepcopy(old['lanes']['control']) for lane in LABELS},
        checkpoint_extras=extras, initial_model_sha256=prepared['records']['identity']['initial_model_sha256'],
        source_selection='Fixed original strong source25088, not a trained512endpoint. Prepared initializations contain no functional-preflight updates.',
        source_checkpoint_relative='direct_readout_preparation_20261029/source.pt',
        steps=512, checkpoints=[128, 256, 512], max_seconds=4200, gpu_workers=[[2, 'identity'], [3, 'gelu']],
        worker_module=MODULE, new_model_parameters=8919040, frozen_modules=['encoder', 'price_decoder'],
        completed_pilot=previous.name, completed_pilot_workers=dict(control=47724, per_position=47725),
        reference_parent='round_010_branch_precision', slow_workers=dict(decoders_fp32=41251, both_fp32=41252),
        minimum_slow_remaining_steps=640, loss_variant='inherited_global_relative_fixed_both',
        fixed_relative_weight=weight, beta=0., sample=False,
        controls='Same1024trainingwindows, source/all3Adam/RNG/order/noaugmentation/teacher/oldobjectives plus locked per-position relative term, '
                 'FP32/seed42/lr1e-4/clip1/batch1accum4/512updates and same8,919,040extra weights. '
                 'Only Identity versus GELU between the extra two affine layers changes. Source Encoder/price frozen, Q/hint and new head train. '
                 'Extra fourthAdam starts empty. Historical no-head pilot is context, not the matched activation control.',
        resource_policy='GPU2/3 only, after exact prior512workers exited and cards free. Require both slow precision workers live '
                        'with>=640updates remaining. Both new workers have70minute ceilings; preserve pending formal fourcard queue priority.',
        scope='Full256minute input and output, same one64x128Gaussian, no Encoder skip. Secondary diagnostics do not change goal gates.',
        training_policy='Budget counts512new updates per arm; inference-only initial files never substitute for source optimizer. '
                        'No early endpoint or budget-limited result can be called512. No seeds or reserved-data selection.',
        preview_descriptions={lane:'完整256分钟、唯一8192Gaussian；同参数直接逐档读出仅比较Identity/GELU。'
            '固定Q1开发窗已反复用于研究，非独立确认。' for lane in LABELS})
    for spec in p['lanes'].values():
        spec.setdefault('gradient_module_flags', {})['direct_quantity_readout'] = True
    atomic_json(root / 'plan.json', p); atomic_json(root / 'status.json', dict(state='prepared_not_started'))
    freeze_sources(root / 'source_snapshot'); render(root)
    project = Path(__file__).resolve().parents[2]
    remote = Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e') / root.relative_to(project)
    (root / 'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'
        + f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 CUDA_DEVICE_ORDER=PCI_BUS_ID OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\n'
        + f'cd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m {MODULE} "{remote}" --controller >> "{remote}/logs/controller.log" 2>&1\n')
    return root


def criterion(root, lane, device='cuda:0'):
    p = read(root / 'plan.json')
    return inherited_book_loss(p['checkpoint_extras'][lane], p, lane, read(root / 'calibration.json'),
        read(root / 'quantity_calibration.json'), read(root / 'detail_calibration.json', {})).to(device)


def optimizer_factory(root, lane, model, saved, names):
    optimizer, _ = restore_direct_readout_adam(model, saved, names)
    seen = {}; done = False; steps = [0]
    modules = dict(encoder_mu=model.encoder.mu, price=model.price_decoder.gap,
        quantity=model.volume_decoder.quantity, direct_input=model.direct_quantity_readout.input_projection,
        direct_output=model.direct_quantity_readout.output_projection)
    def observe(name):
        def hook(module, args, output):
            nonlocal done
            if done or not model.training: return
            seen[name] = str(output.dtype)
            if set(seen) == set(modules):
                assert all(value == 'torch.float32' for value in seen.values())
                atomic_json(root / lane / 'actual_direct_precision_audit.json', dict(passed=True, actual_dtypes=seen))
                done = True
        return hook
    for name, module in modules.items(): module.register_forward_hook(observe(name))
    def before_step(opt, args, kwargs):
        steps[0] += 1
        if steps[0] not in [1, 8]: return
        first = float(model.direct_quantity_readout.input_projection.weight.grad.norm())
        last = float(model.direct_quantity_readout.output_projection.weight.grad.norm())
        assert math.isfinite(first + last) and last > 0 and (first == 0 if steps[0] == 1 else first > 0)
        assert all(parameter.grad is None for name, parameter in model.named_parameters() if name.startswith(('encoder.', 'price_decoder.')))
        atomic_json(root / lane / f'direct_step{steps[0]}_gradient_audit.json', dict(passed=True,
            input_weight_gradient_L2=first, output_weight_gradient_L2=last,
            scope='Post global clipping, before Adam; first input gradient0 is expected for zero last layer.'))
    optimizer.register_step_pre_hook(before_step)
    return optimizer


def audit_startup(root):
    if not all((root / lane / 'direct_step8_gradient_audit.json').exists() for lane in LABELS): return False
    p = read(root / 'plan.json'); rows = {lane: read(root / lane / 'step1_data_audit.json') for lane in LABELS}
    first_batch_equal(rows)
    previous = root.parent / p['completed_pilot']
    old = read(previous / 'per_position/step1_data_audit.json')
    for row in rows.values():
        assert row['training_indices'] == old['training_indices'] and row['edits'] == old['edits']
        assert row['losses'] == old['losses']
    source = torch.load(root / 'source.pt', map_location='cpu', mmap=True, weights_only=False)
    reference = read(root.parent / p['reference_parent'] / 'control/step0_development.json')['result']
    head = None
    for lane in LABELS:
        assert read(root / lane / 'actual_shape_contract.json')['passed']
        assert read(root / lane / 'actual_direct_precision_audit.json')['passed']
        require_matching_replay(read(root / lane / 'step0_development.json')['result'], reference)
        current = torch.load(root / lane / 'step0.pt', map_location='cpu', mmap=True, weights_only=False)
        assert current['direct_readout_config']['readout_activation'] == lane
        for name, value in source['model'].items(): torch.testing.assert_close(current['model'][name], value, rtol=0, atol=0)
        extra = {name: value for name, value in current['model'].items() if name.startswith('direct_quantity_readout.')}
        if head is not None:
            for name, value in extra.items(): torch.testing.assert_close(head[name], value, rtol=0, atol=0)
        head = extra
        assert len(current['optimizer']['param_groups']) == 4
        assert current['optimizer']['param_groups'][:3] == source['optimizer']['param_groups']
        assert current['optimizer']['state'].keys() == source['optimizer']['state'].keys()
        for index, state in source['optimizer']['state'].items():
            for key, value in state.items():
                if torch.is_tensor(value): torch.testing.assert_close(current['optimizer']['state'][index][key], value, rtol=0, atol=0)
                else: assert current['optimizer']['state'][index][key] == value
    atomic_json(root / 'startup_control_audit.json', dict(passed=True, actual_full256_unique8192Z=True,
        full16_native_source_replay_exact=True, same_source_and_extra_weights=True, same3Adam_plus_empty_fourth=True,
        first_batch_old_relative_objective_exact=True, direct_gradients_and_actual_FP32=True,
        only_declared_hidden_activation_changes=True, independent_test_used=False))
    return True


def checkpoint_analysis(root, step):
    output = root / f'common{step}_analysis.json'
    if output.exists() or not all((root / lane / f'step{step}_development.json').exists() for lane in LABELS): return
    p = read(root / 'plan.json'); source = torch.load(root / 'source.pt', map_location='cpu', mmap=True, weights_only=False)
    reference = read(root.parent / p['reference_parent'] / 'control/step0_development.json')['result']
    baseline = None; rows = []
    for lane in LABELS:
        current = torch.load(root / lane / f'step{step}.pt', map_location='cpu', mmap=True, weights_only=False)
        assert current['step'] == step and current['source_steps'] == 25088
        if baseline is not None:
            for key in ['sampler_generator_state', 'augmentation_generator_state']:
                torch.testing.assert_close(current[key], baseline[key], rtol=0, atol=0)
            np.testing.assert_array_equal(current['training_data']['exposure_counts'], baseline['training_data']['exposure_counts'])
        baseline = current
        assert current['optimizer']['param_groups'][:3] == source['optimizer']['param_groups']
        for name, value in source['model'].items():
            if name.startswith(('encoder.', 'price_decoder.')): torch.testing.assert_close(current['model'][name], value, rtol=0, atol=0)
        for index, name in zip(source['optimizer']['param_groups'][0]['params'], p['original_parameter_names']):
            if not name.startswith(('encoder.', 'price_decoder.')): continue
            old, new = source['optimizer']['state'].get(index, {}), current['optimizer']['state'].get(index, {})
            assert old.keys() == new.keys()
            for key, value in old.items():
                if torch.is_tensor(value): torch.testing.assert_close(new[key], value, rtol=0, atol=0)
                else: assert new[key] == value
        result = read(root / lane / f'step{step}_development.json')['result']
        for key in ['price_usdt', 'temporal_mid_1_minutes_usdt_per_minute']:
            assert result['metrics'][key] == reference['metrics'][key]
        rows.append(dict(lane=lane, **assess_file(root / lane / f'step{step}_development.json', root.parent / 'reference_evaluation.json')))
    atomic_json(output, dict(step=step, rows=rows, frozen_weights_and_historical_Adam_exact=True,
        native_price_exact=True, sampler_and_exposures_exact=True, only_hidden_activation_changes=True))
    record(root.parent, 'direct_readout_activation_common_checkpoint', wave=root.name, step=step, rows=rows)


def render(root):
    p = read(root / 'plan.json'); status = read(root / 'status.json', {})
    parts = ['<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="30"><title>直接逐档读出激活对照</title><style>' + STYLE + '</style><main>',
        '<h1>同参数直接逐档读出：线性与GELU</h1><p>完整256分钟、双侧2048档、唯一64×128Gaussian。'
        '两组相同8,919,040新增参数、同初始化/四组Adam/1024训练窗/顺序/原目标加锁定相对项/FP32/seed42/512更新；'
        '仅额外两层线性之间的Identity或GELU不同。Encoder与价格冻结，数量Decoder、hint与新增读出训练。'
        '新增分支读取post-Z数量帧特征，不增加Encoder跳接。开发集反复使用，非独立确认。</p>',
        '<table><tr><th>组</th><th>训练进度</th><th>共同评估步</th><th>召回</th><th>精确率</th><th>价格RMSE USDT</th></tr>']
    common = [step for step in [0, *p['checkpoints']] if all((root / lane / f'step{step}_development.json').exists() for lane in LABELS)]
    step = max(common) if common else None
    for lane, label in LABELS.items():
        row = [label, f"{read(root / lane / 'progress.json', {}).get('step', 0)}/{p['steps']}"]
        if step is None: row += ['待评估'] * 4
        else:
            a = assess_file(root / lane / f'step{step}_development.json', root.parent / 'reference_evaluation.json')
            row += [step, f"{a['recall100']:.2%}", f"{a['precision100']:.2%}", f"{a['price_rmse']:.4f}"]
        parts.append('<tr>' + ''.join('<td>' + html.escape(str(v)) + '</td>' for v in row) + '</tr>')
    parts += ['</table><p>相对误差系数固定为' + str(p['fixed_relative_weight']) + '，复用先前仅训练窗校准值，不重新拟合。'
              '首批损失须复现原相对项模型，同步检查冻结权重、Adam状态、价格及完整16窗初始化回放。'
              '每组70分钟上限；未完成512不得标为512结果。仅用已释放GPU2/3，原4/5实验及后续正式队列保留优先级。</p>',
              '<p>状态：' + html.escape(str(status)) + '</p><p><a href="plan.json">协议</a> · <a href="startup_control_audit.json">启动审核</a> · '
              '<a href="../direct_readout_full_gpu_preflight_20261029/result.json">完整GPU预检</a></p></main>']
    temp = root / 'index.html.tmp'; temp.write_text(''.join(parts)); temp.replace(root / 'index.html')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path); parser.add_argument('--prepare', action='store_true'); parser.add_argument('--controller', action='store_true'); parser.add_argument('--lane', choices=list(LABELS))
    args = parser.parse_args(); root = args.root.resolve()
    try:
        if args.prepare: print(prepare(root), flush=True)
        elif args.controller:
            if not resources_ready(root):
                atomic_json(root / 'status.json', dict(state='not_run_main_queue_priority_or_cards_busy')); render(root); return
            run_cohort(root, worker_module=MODULE, startup_auditor=audit_startup, renderer=render, analyzer=checkpoint_analysis)
        elif args.lane:
            shared.evaluate = evaluate_with_quantity_strata
            shared.worker(root, args.lane, objective_factory=criterion,
                optimizer_factory=lambda model, state, names: optimizer_factory(root, args.lane, model, state, names))
        else: parser.error('Specify mode')
    except BaseException as error:
        if not args.prepare: atomic_json((root / args.lane if args.lane else root) / 'status.json', dict(state='failed', pid=os.getpid(), error=repr(error)))
        raise


if __name__ == '__main__': main()
