"""Read-only attribution of a weak quantity response; no parameter updates."""
import argparse
import hashlib
import json
from pathlib import Path

import torch

from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import load_for_inference, seed_everything


def scalar(value):return float(value.detach().cpu())


def fingerprint(model):
    result=hashlib.sha256()
    for key,value in model.state_dict().items():
        result.update(key.encode());result.update(value.detach().cpu().contiguous().numpy().tobytes())
    return result.hexdigest()


def main(root):
    plan=json.loads((root/'plan.json').read_text())
    parent=root.parents[1]/'recons'/Path(plan['parent']).name
    raw={k:v.unsqueeze(0) for k,v in dataset(parent,'train')[plan['training_index']].items()}
    model,norm=load_for_inference(root/'checkpoint.pt','cuda:0');model.eval();model.requires_grad_(False)
    before=fingerprint(model)
    base=norm.prepare(raw,'cuda:0');t,s,k=plan['frame'],plan['side'],plan['rank'];flat=t*2+s
    captures={};references={};flags=set();head={};zero_numeric_price=[False]
    handles=[]

    def ln_hook(name):
        def hook(module,args,out):
            inp=args[0][t,s] if name=='region_ln' else args[0][0,t]
            value=out[t,s] if name=='region_ln' else out[0,t]
            if name in flags:
                ref=references[name]
                x0=ref['input'].to(inp);y0=ref['output'].to(inp)
                std=(x0.var(-1,unbiased=False,keepdim=True)+module.eps).sqrt()
                value=y0+(inp-x0)/std*module.weight
                out=out.clone()
                if name=='region_ln':out[t,s]=value
                else:out[0,t]=value
            captures[name]=dict(input=inp.detach().cpu(),output=value.detach().cpu())
            return out
        return hook
    handles.append(model.encoder.region[0].register_forward_hook(ln_hook('region_ln')))
    handles.append(model.encoder.frame[0].register_forward_hook(ln_hook('frame_ln')))

    def stage_hook(name,kind):
        def hook(module,args,out):
            if kind=='row':value=out[flat]
            elif kind=='region':value=out[t,s]
            elif kind=='frame':value=out[0,t]
            elif kind=='patch':value=out[0,t//4]
            else:value=out[0]
            captures[name]=value.detach().cpu()
        return hook
    stages=[('spatial',model.encoder.spatial[-1],'row'),('region',model.encoder.region,'region'),
            ('frame',model.encoder.frame,'frame'),('patch',model.encoder.patch,'patch'),
            ('mu',model.encoder.mu,'all')]
    for name,module,kind in stages:handles.append(module.register_forward_hook(stage_hook(name,kind)))

    def head_hook(module,args,out):
        head['feature']=args[0][flat,:,k].detach().cpu()
        head['logit']=out[flat,0,k]
    handles.append(model.volume_decoder.quantity.register_forward_hook(head_hook))
    def geometry_hook(module,args):
        if not zero_numeric_price[0]:return None
        geometry=args[0].clone();geometry[:,:2]=0
        return (geometry,)
    handles.append(model.volume_decoder.geometry.register_forward_pre_hook(geometry_hook))

    def forward(amount,freeze=()):
        flags.clear();flags.update(freeze)
        b=dict(base,volume=base['volume'].clone())
        b['volume'][0,t,s,k]+=amount
        captures.clear();head.clear()
        with torch.no_grad():out=call(model,b,False)
        saved=dict(captures)
        return dict(z=out['z'].detach(),price={key:out[key].detach() for key in ['price_norm','gap_norm','mid_norm','spread_norm']},
                    q=out['volume'].detach(),stages=saved,head_feature=head['feature'],logit=scalar(head['logit']))

    def stats(q,ref):
        a=q[0,t,s];b=ref[0,t,s]
        pa=a/a.sum().clamp_min(1e-12);pb=b/b.sum().clamp_min(1e-12)
        ac=a-a.mean();bc=b-b.mean();den=ac.norm()*bc.norm()
        return dict(target_quantity_btc=scalar(q[0,t,s,k]),
            global_relative_l2=scalar((q-ref).norm()/ref.norm().clamp_min(1e-12)),
            frame_side_mass_ratio=scalar(a.sum()/b.sum()),
            frame_side_shape_l1=scalar((pa-pb).abs().sum()),
            frame_side_centered_correlation=scalar((ac*bc).sum()/den) if den>1e-20 else None)

    def volume(z,price):
        head.clear()
        with torch.no_grad():q=model.volume_decoder(z,price,base['mask'],base['tick_norm'],base['times'])
        return q.detach(),dict(feature=head['feature'],logit=scalar(head['logit']))

    try:
        ref=forward(0)
        references.update({key:ref['stages'][key] for key in ['region_ln','frame_ln']})
        peak=forward(1000)
        delta=peak['z']-ref['z']
        results=dict(source_z_l2=scalar(ref['z'].norm()),peak_delta_z_l2=scalar(delta.norm()))

        sweep=[]
        for amount in plan['amplitudes']:
            sample=peak if amount==1000 else forward(amount)
            row=dict(amount_btc=amount,target_output_delta=scalar(sample['q'][0,t,s,k]-ref['q'][0,t,s,k]),stage_changes={})
            for key in ['spatial','region','frame','patch','mu']:
                a=sample['stages'][key];b=ref['stages'][key]
                row['stage_changes'][key]=dict(delta_l2=float((a-b).norm()),relative_l2=float((a-b).norm()/b.norm().clamp_min(1e-12)))
            sweep.append(row)
        results['encoder_amplitude_sweep']=sweep
        frozen=[]
        for names in [(),('region_ln',),('frame_ln',),('region_ln','frame_ln')]:
            unchanged=forward(0,names)
            baseline_error=scalar((unchanged['q']-ref['q']).abs().max())
            assert baseline_error<2e-6,('FrozenLN altered the basepoint',names,baseline_error)
            sample=forward(1000,names)
            frozen.append(dict(frozen_normalizers=list(names),baseline_max_abs_error=baseline_error,
                output_delta=scalar(sample['q'][0,t,s,k]-ref['q'][0,t,s,k]),
                delta_z_l2=scalar((sample['z']-ref['z']).norm()),
                logit_delta=sample['logit']-ref['logit'],output_stats=stats(sample['q'],ref['q'])))
        flags.clear()
        results['fixed_stat_LN_interventions']=frozen
        atomic_json(root/'partial_encoder.json',results)

        q00,h00=volume(ref['z'],ref['price']);q10,h10=volume(peak['z'],ref['price'])
        q01,h01=volume(ref['z'],peak['price']);q11,h11=volume(peak['z'],peak['price'])
        assert scalar((q00-ref['q']).abs().max())<2e-6
        actual=scalar(q11[0,t,s,k]-q00[0,t,s,k]);direct=scalar(q10[0,t,s,k]-q00[0,t,s,k]);geometry=scalar(q01[0,t,s,k]-q00[0,t,s,k])
        results['forward_route_decomposition']=dict(total=actual,direct_z_fixed_geometry=direct,
            geometry_fixed_z=geometry,interaction=actual-direct-geometry,
            logit_total=h11['logit']-h00['logit'],logit_direct=h10['logit']-h00['logit'])

        gradients={}
        for route in ['direct','joint']:
            z=ref['z'].clone().requires_grad_(True)
            price=ref['price'] if route=='direct' else model.price_decoder(z,base['mask'],base['tick_norm'],base['times'])
            q=model.volume_decoder(z,price,base['mask'],base['tick_norm'],base['times'])
            logit=head['logit'];raw_gradient=torch.autograd.grad(logit,z)[0].detach()
            slope=float(model.volume_decoder.q0)*float(torch.sigmoid(logit.detach()))
            gradient=raw_gradient*slope
            product=gradient.norm()*delta.norm()
            gradients[route]=dict(q_gradient=gradient,raw_gradient=raw_gradient,
                q_gradient_l2=scalar(gradient.norm()),logit_gradient_l2=scalar(raw_gradient.norm()),
                delta_dot_gradient=scalar((gradient*delta).sum()),
                aligned_norm_bound=scalar(product),
                actual_delta_readout_cosine=scalar((gradient*delta).sum()/product) if product>1e-25 else None,
                softplus_derivative_physical=slope,softplus_sigmoid_factor=float(torch.sigmoid(logit.detach())),
                grad_mode_quantity=scalar(q[0,t,s,k]))
            del q,z,price,raw_gradient
            head.clear()
        gg=gradients['joint']['q_gradient']-gradients['direct']['q_gradient']
        results['decoder_jacobian']={route:{key:value for key,value in item.items() if not isinstance(value,torch.Tensor)} for route,item in gradients.items()}
        results['decoder_jacobian']['geometry_gradient_l2']=scalar(gg.norm())
        results['decoder_jacobian']['geometry_directional_derivative']=scalar((gg*delta).sum())
        g=gradients['direct']['q_gradient']
        direction=g/g.norm().clamp_min(1e-25)*delta.norm()
        positive,_=volume(ref['z']+direction,ref['price'])
        results['equal_norm_decoder_positive_control']=dict(actual_delta_z_l2=scalar(delta.norm()),
            actual_direct_delta=direct,gradient_aligned_delta=scalar(positive[0,t,s,k]-q00[0,t,s,k]),
            note='Same latent perturbation norm, oracle readout-gradient direction; diagnostic only, not valid encoded input.')
        scales=[]
        for alpha in [1.,10.,100.,1000.]:
            q,_=volume(ref['z']+alpha*delta,ref['price'])
            scales.append(dict(alpha=alpha,output_delta=scalar(q[0,t,s,k]-q00[0,t,s,k])))
        results['latent_direction_amplification_fixed_geometry']=scales

        ablations=[]
        for use_zero_z in [False,True]:
            for zero_price in [False,True]:
                zero_numeric_price[0]=zero_price
                z=torch.zeros_like(ref['z']) if use_zero_z else ref['z']
                q,_=volume(z,ref['price'])
                ablations.append(dict(zero_direct_z=use_zero_z,zero_numeric_geometry=zero_price,
                                      statistics=stats(q,q00)))
        zero_numeric_price[0]=False
        results['decoder_forward_ablations']=ablations
        weight=model.volume_decoder.quantity.weight.detach().flatten().cpu()
        dh=peak['head_feature']-ref['head_feature']
        dot=float(weight.dot(dh));bound=float(weight.norm()*dh.norm())
        results['head_and_activation']=dict(weight_l2=float(weight.norm()),feature_delta_l2=float(dh.norm()),
            weight_dot_delta_feature=dot,raw_logit_delta=peak['logit']-ref['logit'],
            logit_dot_product_abs_error=abs(dot-(peak['logit']-ref['logit'])),
            channel_alignment_cosine=dot/bound if bound>1e-25 else None,
            logit_norm_bound=bound,base_logit=ref['logit'],
            softplus_sigmoid=float(torch.sigmoid(torch.tensor(ref['logit']))),
            physical_output_slope=float(model.volume_decoder.q0)*float(torch.sigmoid(torch.tensor(ref['logit']))))
        after=fingerprint(model)
        assert before==after
        results.update(weights_unchanged=True,state_sha256=before,optimizer_updates=0,
            scope='One realtrainingwindow, baseline1024checkpoint,FP32. Interventions and ablations are diagnostics, not productionmodel changes. Cross-stage L2 ratios do not measure information loss.')
        atomic_json(root/'attribution.json',results)
    finally:
        for handle in handles:handle.remove()


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root',type=Path)
    args=parser.parse_args();torch.set_num_threads(4);seed_everything(42);strict_precision()
    main(args.root.resolve())
