"""Live report for the equal-budget residual compression depth experiment."""

import argparse
import json
from pathlib import Path

from train_dual.experiments.frame_matrix_e2e_report import PAGE,monitor


def main(root):
    plan=json.loads((root/'plan.json').read_text())
    page=PAGE.replace('16×1024全模型端到端训练','16×1024残差压缩实验').replace('16×1024：训练完整模型','16×1024：残差MLP深度对照')
    page=page.replace('端到端组更新','所有组更新')
    start=page.index('<p>主组仍只用');end=page.index('</p>',start)+4
    page=page[:start]+('<p>所有组使用同512个训练窗口、同64个2025Q1开发窗口、seed42、相同学习率与2048个优化步。'
        '对照为原浅层非线性分支；残差组在压缩和解压两侧增加2或4个LayerNorm→Linear→GELU→Linear残差块。'
        '宽512的深度对照共享初始输入权重；宽1024组同时改变宽度，单列为容量试验。新增块初始化为恒等映射，所有组初始压缩结果一致。'
        '128/256/512/1024/2048步保存并评估；开发集已用于研究选型，独立2025Q2未用。</p>')+page[end:]
    start=page.index('const labels=');end=page.index(',f=(x',start)
    page=page[:start]+'const labels='+json.dumps(plan['labels'],ensure_ascii=False)+page[end:]
    page=page.replace('32窗口组为诊断','同512窗口').replace('上一轮冻结源试验','上一轮试验')
    monitor(root,page=page)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);main(p.parse_args().root)
