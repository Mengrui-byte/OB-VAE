"""Separate linear invertibility from the learned window pooling/readout fit."""

import argparse
import json
from pathlib import Path

import torch

from model.experimental.window_state import WindowStateVAE


def audit(root):
    torch.set_num_threads(4)
    cached = torch.load(root / 'training_latents.pt', map_location='cpu', weights_only=False)
    rows = {}
    for dimension in (1024, 512, 256):
        saved = torch.load(root / f'd{dimension}/warmup.pt', map_location='cpu', weights_only=False)
        model = WindowStateVAE(**saved['window_state_config'], **saved['model_config']).eval()
        model.load_state_dict(saved['model'], strict=True)
        codec = model.window_codec
        p, q = codec.to_state.weight.detach().double(), codec.from_state.weight.detach().double()
        left, singular, right = torch.linalg.svd(p, full_matrices=False)
        inverse = (right.T / singular) @ left.T
        output = {}
        with torch.inference_mode():
            g, l, mask, times = [cached[key][:8] for key in ('global', 'local', 'mask', 'times')]
            target = model.fusion([(g, l)], mask, times)
            encoded = codec.compress(target['unified'], mask, times)
            tokens = encoded['aggregation_tokens'].reshape(8, -1).double()
            state = tokens @ p.T
            learned = state @ q.T
            pinv = state @ inverse.T
            gh, lh = codec.expand(encoded['state'], mask, times)
            gmse = ((gh-target['global_latent'])/codec.global_scale).square().mean()
            lmse = (((lh-target['local_latent'])/codec.local_scale).square().mean(-1))[mask].mean()
            output.update(sample_windows=8, learned_linear_roundtrip_mse=float((learned-tokens).square().mean()),
                          pseudoinverse_roundtrip_mse=float((pinv-tokens).square().mean()),
                          normalized_global_readout_mse=float(gmse), normalized_local_readout_mse=float(lmse))
        rows[str(dimension)] = dict(matrix_shape=list(p.shape), rank=int((singular>singular.max()*1e-10).sum()),
                                   minimum_nonzero_singular_value=float(singular.min()),
                                   condition_number=float(singular.max()/singular.min()), **output)
    result = dict(checkpoint_stage='codec warmup, before joint updates', rows=rows,
                  conclusion='Full-rank square projection is invertible. Learned expansion need not be its inverse. Whole-window attention pooling and learned readout are separate possible sources of distortion.',
                  caveat='A rectangular pseudoinverse residual is an ambient-space projection error, not proof that a low-dimensional data manifold cannot be decoded.')
    (root/'linear_projection_audit.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('root',type=Path)
    audit(parser.parse_args().root)
