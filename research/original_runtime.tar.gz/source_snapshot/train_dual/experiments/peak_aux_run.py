"""Matched2x2 large-order location and positive-amplitude auxiliary losses."""
import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import numpy as np
import torch
from torch.utils.data import DataLoader

from model.autoencoder.peak_book_vae import PeakAuxOrderBookVAE
from model.losses.peak_book import PeakAuxBookLoss
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.local_quant_reconstruction import CacheWindows
from train_dual.experiments.long_worker import atomic_json,evaluate
from train_dual.experiments.peak_aux_eval import evaluate_peak_aux
from train_dual.experiments.phase_detail_report import render,preview
from train_dual.experiments.probability_eval import evaluate_probability
from train_dual.experiments.unified_8192_run import call
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import atomic_save,freeze_sources,load_for_inference,seed_everything,source_hashes
from train_dual.util.phase_training import restore_original_adam,tensor_digest

LABELS={'baseline':'原损失·匹配对照','location':'仅加位置监督','amplitude':'仅加大单幅度监督','both':'位置＋大单幅度监督'}


def read(path,default=None):
    return json.loads(path.read_text()) if path.exists() else default


def prepare(parent):
    parent=parent.resolve();project=Path(__file__).resolve().parents[2]
    root=project/'recons'/('peak_aux_'+datetime.now().strftime('%Y%m%d_%H%M%S'));root.mkdir()
    for name in ['data','logs',*LABELS]:(root/name).mkdir()
    for name in ['initial.pt','initial_expected.json','train_indices.npy','val_indices.npy','seen_indices.npy','plotly.min.js']:
        os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    old=read(parent/'plan.json')
    plan={k:old[k] for k in ['train','development','independent_test_untouched','normalization','model_config','objective','window_size','stride','input_shape','latent_shape','output_shape','fit_windows','seen_windows','evaluation_windows','batch_size','accumulation','steps','checkpoints','max_seconds','lr','weight_decay','clip_grad','beta','sample','precision']}
    lanes={lane:dict(add_location=lane in ['location','both'],add_amplitude=lane in ['amplitude','both']) for lane in LABELS}
    plan.update(parent=str(parent),experiment='2x2 explicit peak location x positive-only quantity loss',labels=LABELS,lanes=lanes,
        seed=42,freeze=['encoder','price_decoder'],loss_family='peak_aux',inline_evaluation=True,
        peak_threshold=10.,location_weight=1.,amplitude_weight=1.,extra_parameters=33,
        source_checkpoint=old['source_checkpoint'],gpu_workers=[[g,l] for g,l in zip([2,3,4,5],LABELS)],
        initialization='Same predeclared probability_shape/baseline/step1024 source weights+original Adam. Do not use prior per-lane endpoints. New33parameter peak head zero with fresh Adam state in all4; disabled location head frozen. Same source geometry and quantities.',
        objective_definition='Original shape_mass retained exactly; no newW1/multiscaleKL. Add weight1 balanced BCE and/or weight1 positive-only normalized-quantity Huber. Constants locked before data/evaluation; no calibration or development tuning.',
        location_definition='Label1 at valid q>=10BTC. For each window separately average positive and negative BCEWithLogits, then average existing classes. Missing classes excluded from class denominator; empty windows ignored. Auxiliary logit never gates quantity.',
        amplitude_definition='Huber((qhat-q)/sourceq0), averaged only over valid q>=10BTC within each window; then over windows with positives. Empty-positive batches yield differentiable0. No output gating or price changes.',
        control_contract='Same original volume upsampler and Softplus formula, same8192latent/frozen Encoder+price, same data/order,seed42,AdamW1e-4,clip1,batch1accum4,2048updates. All4 allocate identical peak head; only loss flags change. Classification labels derive from same-window input, no future returns.',
        primary='Fixed2048endpoint quantityRMSE and actual10/100BTCprecision/recall/FP on16development+8seen. Auxiliary location AP andprecision/recall are diagnostic, not reconstruction success. Retain all checkpoints andtradeoffs.',
        location_evaluation='4096score-bin approximate average precision, prevalence reference, fixed score thresholds0.1/0.5/0.9. Zero untrained logits imply all-tied0.5 scores andAP=prevalence. Balanced-class scores need not be calibrated probabilities.',
        selection='seed42 exploratory only; reused2025Q1 development;2025Q2 and2026 untouched.',
        queue='Start each assigned GPU only when free memory>47000MiB; preserve previous owned Encoder experiment andall external jobs. Per-worker4hour ceiling; global4hour cohort ceiling includes anyqueue time.',
        authorization='User continued after proposed location x amplitude2x2. No Encoder unfreeze, temporal-attention change orFocalLoss in this cohort.',
        report=dict(title='大单位置监督 × 大单幅度监督',scope='四组2×2控制；Encoder和价格Decoder固定，只训练原数量Decoder及启用的辅助分类头。',
            introduction='四组从同一原始起点重新训练，使用相同1024训练窗、seed42、有效batch4、2048更新。只改变位置BCE和大单幅度Huber是否加入，两项权重均预先固定为1。新增33参数分类头在所有组中相同，分类分数不参与数量输出。',
            hardware='GPU2–5各一组；等待旧任务释放对应卡后自动启动，不中止旧实验。各卡采用相同FP32评估。',
            future='位置标签为同位真实数量≥10BTC。位置分类指标与实际数量重建指标分开报告；位置分数提高不等于大单恢复。Decoder时间注意力、Encoder解冻和FocalLoss留给单独对照。'))
    assert len(np.load(root/'train_indices.npy'))==1024
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'))
    atomic_json(root/'data_contract.json',dict(input_shape=plan['input_shape'],latent_shape=plan['latent_shape'],output_shape=plan['output_shape'],
        train_indices=np.load(root/'train_indices.npy').tolist(),seen_indices=np.load(root/'seen_indices.npy').tolist(),development_indices=np.load(root/'val_indices.npy').tolist(),
        train_indices_sha256=hashlib.sha256((root/'train_indices.npy').read_bytes()).hexdigest(),initial_checkpoint_sha256=hashlib.sha256((root/'initial.pt').read_bytes()).hexdigest()))
    (root/'README.md').write_text('# 大单位置 × 幅度监督2×2\n\n'+plan['report']['introduction']+'\n\n'+plan['location_definition']+'\n\n'+plan['amplitude_definition']+'\n\n'+plan['control_contract']+'\n')
    freeze_sources(root/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'
        f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\n'
        f'cd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.peak_aux_run "{remote}"\n')
    render(root);Path('/tmp/peak_aux_path').write_text(str(root));print(root,flush=True)


def criterion_for(plan,lane):
    return PeakAuxBookLoss(plan['normalization']['quantity_scale'],mode='shape_mass',add_wasserstein=False,add_multiscale=False,
        peak_threshold=plan['peak_threshold'],location_weight=plan['location_weight'],amplitude_weight=plan['amplitude_weight'],
        **plan['objective'],**plan['lanes'][lane])


def profiles(folder,step,model,norm,original,indices):
    values={key:[] for key in ['truth','prediction','mask','time','peak_probability','mu']}
    positions=np.unique(np.linspace(0,len(indices)-1,3,dtype=int));model.eval()
    with torch.inference_mode():
        for pos in positions:
            idx=int(indices[pos]);raw={k:v.unsqueeze(0) for k,v in original[idx].items()};b=norm.prepare(raw,'cuda:0');out=call(model,b,False)
            values['truth'].append(raw['data'][0].numpy());values['mask'].append(b['mask'][0].cpu().numpy())
            values['prediction'].append(np.stack((norm.inverse_price(out['price_norm'],b)[0].cpu().numpy(),out['volume'][0].cpu().numpy()),-1))
            values['peak_probability'].append(out['peak_logits'][0].sigmoid().cpu().numpy());values['mu'].append(out['mu'][0].cpu().numpy())
            start=int(original.base.starts[idx]);values['time'].append(original.base.times[start:start+256])
    temp=folder/f'step{step}_profiles.tmp'
    with temp.open('wb') as stream:np.savez_compressed(stream,**{k:np.stack(v) for k,v in values.items()},indices=indices[positions])
    temp.replace(folder/f'step{step}_profiles.npz')


def assess(root,folder,step,model,norm,dev,seen,original,indices,criterion):
    atomic_json(folder/'evaluation_status.json',dict(state='evaluating',step=step))
    result=evaluate(model,norm,dev,len(dev),'cuda:0')
    if step==0:
        expected=read(root/'initial_expected.json')['result']
        delta={k:abs(result['metrics'][k]['rmse']-expected['metrics'][k]['rmse']) for k in ['price_usdt','quantity_btc']}
        atomic_json(folder/'initial_replay.json',delta)
        if max(delta.values())>1e-3:raise RuntimeError(f'Initial replay mismatch:{delta}')
    atomic_json(folder/f'step{step}_evaluation.json',dict(result=result))
    atomic_json(folder/f'step{step}_seen_evaluation.json',dict(result=evaluate(model,norm,seen,len(seen),'cuda:0')))
    atomic_json(folder/f'step{step}_probability.json',dict(development=evaluate_probability(model,norm,dev,len(dev),'cuda:0',criterion),seen=evaluate_probability(model,norm,seen,len(seen),'cuda:0',criterion)))
    atomic_json(folder/f'step{step}_peak_aux.json',dict(development=evaluate_peak_aux(model,norm,dev,'cuda:0',criterion.peak_threshold),seen=evaluate_peak_aux(model,norm,seen,'cuda:0',criterion.peak_threshold),location_head_trained=criterion.add_location))
    profiles(folder,step,model,norm,original,indices);preview(root,folder.name,step)
    atomic_json(folder/'evaluation_status.json',dict(state='complete',step=step))


def worker(root,lane):
    torch.set_num_threads(4);seed_everything(42);strict_precision();started=time.monotonic();plan=read(root/'plan.json');spec=plan['lanes'][lane]
    folder=root/lane;folder.mkdir(exist_ok=True);atomic_json(folder/'status.json',dict(state='initial_validation'))
    initial=torch.load(root/'initial.pt',map_location='cpu',weights_only=False)
    old,norm=load_for_inference(root/'initial.pt','cuda:0');old.eval().requires_grad_(False)
    if any(getattr(old,'gradient_route_config',{}).values()):raise ValueError('Require original full routes')
    original_names=[n for n,_ in old.named_parameters()]
    model=PeakAuxOrderBookVAE(**plan['model_config']).to('cuda:0')
    missing,unexpected=model.load_state_dict(initial['model'],strict=False)
    assert missing==['volume_decoder.peak_head.weight','volume_decoder.peak_head.bias'] and not unexpected
    model.requires_grad_(False);model.volume_decoder.requires_grad_(True)
    model.volume_decoder.peak_head.requires_grad_(spec['add_location'])
    opt,param_names=restore_original_adam(model,initial['optimizer'],original_names,plan['lr'],plan['weight_decay'],head_prefix='volume_decoder.peak_head.')
    frozen={name:tensor_digest(getattr(model,name)) for name in plan['freeze']}
    train_original=dataset(root,'train');dev_original=dataset(root,'val');ti=np.load(root/'train_indices.npy');vi=np.load(root/'val_indices.npy')
    train=CacheWindows(train_original,ti);dev=CacheWindows(dev_original,vi);seen=CacheWindows(train_original,np.load(root/'seen_indices.npy'))
    raw={k:v.unsqueeze(0) for k,v in train[0].items()};b=norm.prepare(raw,'cuda:0');model.eval();parity={}
    for precision in ['fp32','bf16']:
        with torch.no_grad(),torch.autocast('cuda',dtype=torch.bfloat16,enabled=precision=='bf16'):
            reference=call(old,b,False);candidate=call(model,b,False)
            for key in ['price_norm','volume','z']:torch.testing.assert_close(reference[key],candidate[key],rtol=0,atol=0)
            assert candidate['peak_logits'].shape==candidate['volume'].shape
        parity[precision]=dict(quantity_max_abs_delta=0.,price_max_abs_delta=0.,latent_max_abs_delta=0.)
    assert list(raw['data'].shape)==plan['input_shape'] and list(candidate['z'].shape)==plan['latent_shape'] and list(candidate['volume'].shape)==plan['output_shape']
    atomic_json(folder/'initial_parity.json',dict(passed=True,rows=parity,frozen_digests=frozen,raw_input=list(raw['data'].shape),latent=list(candidate['z'].shape),quantity=list(candidate['volume'].shape),extra_parameters=33,missing_keys=missing))
    source_config=initial['config'];del old,initial,reference,candidate,raw,b
    criterion=criterion_for(plan,lane);hashes=source_hashes();exposures=np.zeros(len(train),dtype=np.int64)
    loader=DataLoader(train,batch_size=1,shuffle=True,num_workers=2,persistent_workers=True,pin_memory=True,generator=torch.Generator().manual_seed(42));iterator=iter(loader)
    atomic_json(folder/'trainable_modules.json',{n:sum(p.numel() for p in getattr(model,n).parameters() if p.requires_grad) for n in ['encoder','price_decoder','volume_decoder']})
    def save(step):
        actual={n:tensor_digest(getattr(model,n)) for n in plan['freeze']}
        if actual!=frozen:raise RuntimeError('Frozen module changed')
        atomic_json(folder/f'step{step}_frozen_audit.json',dict(passed=True,digests=actual))
        atomic_save(dict(format_version=1,model=model.state_dict(),unified_vae_config=plan['model_config'],peak_aux_config=dict(version=1),
            config=dict(source_config,loss_family='peak_aux',loss=dict(plan['objective'],**spec,peak_threshold=plan['peak_threshold'],location_weight=plan['location_weight'],amplitude_weight=plan['amplitude_weight'])),
            step=step,lane=lane,beta=0.,training_sample=False,freeze=plan['freeze'],optimizer=opt.state_dict(),optimizer_parameter_names=param_names,
            source_hashes=hashes,torch_rng_state=torch.get_rng_state(),cuda_rng_state=torch.cuda.get_rng_state_all(),sampler_generator_state=loader.generator.get_state(),
            epoch_boundary=step*plan['accumulation']%len(train)==0,training_data=dict(exposure_counts=exposures.copy(),windows=len(train),epochs_equivalent=step*plan['accumulation']/len(train))),folder/f'step{step}.pt')
    save(0);assess(root,folder,0,model,norm,dev,seen,dev_original,vi,criterion)
    atomic_json(folder/'status.json',dict(state='training',step=0))
    for step in range(1,plan['steps']+1):
        if time.monotonic()-started>plan['max_seconds']:raise TimeoutError('Four-hour worker ceiling')
        model.train();model.encoder.eval();model.price_decoder.eval();opt.zero_grad(set_to_none=True);record={};order=[]
        for micro in range(plan['accumulation']):
            try:raw=next(iterator)
            except StopIteration:iterator=iter(loader);raw=next(iterator)
            pos=int(raw['cache_position'][0]);exposures[pos]+=1;order.append(int(ti[pos]));b=norm.prepare(raw,'cuda:0')
            assert list(raw['data'].shape)==plan['input_shape']
            with torch.autocast('cuda',dtype=torch.bfloat16):out=call(model,b,False)
            assert list(out['z'].shape)==plan['latent_shape'] and list(out['volume'].shape)==plan['output_shape']
            values=criterion(out,b,beta=0.)
            if not bool(torch.isfinite(values['loss'])):raise FloatingPointError('Nonfinite loss')
            (values['loss']/plan['accumulation']).backward()
            for key,value in values.items():record[key]=record.get(key,0.)+float(value.detach())/plan['accumulation']
            if step==1 and micro==0:atomic_json(folder/'actual_shape_contract.json',dict(raw_input=list(raw['data'].shape),latent=list(out['z'].shape),quantity_output=list(out['volume'].shape),price_output=list(out['price_norm'].shape),peak_logits=list(out['peak_logits'].shape),posterior_count=1,encoder_skip=False,probability_gates_quantity=False))
        if step==1:
            gradients={n:float(p.grad.float().norm()) if p.grad is not None else None for n,p in model.named_parameters()}
            if any(p.grad is not None for name in plan['freeze'] for p in getattr(model,name).parameters()):raise RuntimeError('Frozen module has gradient')
            head_grad=gradients['volume_decoder.peak_head.weight']
            if spec['add_location'] and not head_grad>0:raise RuntimeError('Active location head has no gradient')
            if not spec['add_location'] and head_grad is not None:raise RuntimeError('Disabled location head has gradient')
            atomic_json(folder/'first_step_gradient_norms.json',gradients);atomic_json(folder/'first_step_data.json',dict(training_indices=order,losses=record))
        grad=torch.nn.utils.clip_grad_norm_(model.parameters(),plan['clip_grad'],error_if_nonfinite=True);opt.step()
        if step==1:
            unchanged={n:tensor_digest(getattr(model,n))==frozen[n] for n in plan['freeze']}
            if not all(unchanged.values()):raise RuntimeError('Frozen parameters changed onfirstupdate')
            atomic_json(folder/'first_update_audit.json',dict(passed=True,frozen_unchanged=unchanged,location_head_weight_norm=float(model.volume_decoder.peak_head.weight.detach().float().norm())))
        if step==1 or step%8==0:
            row=dict(step=step,total=plan['steps'],phase='quantity_decoder_only',elapsed_seconds=time.monotonic()-started,gradient_norm=float(grad),reserved_gib=torch.cuda.memory_reserved()/2**30,epochs_equivalent=float(exposures.mean()),unique_windows_seen=int((exposures>0).sum()),training_indices=order,**record)
            atomic_json(folder/'progress.json',row)
            with (folder/'progress.jsonl').open('a') as stream:stream.write(json.dumps(row)+'\n')
            print(json.dumps(row),flush=True)
        if step in plan['checkpoints']:save(step);assess(root,folder,step,model,norm,dev,seen,dev_original,vi,criterion)
    atomic_json(folder/'status.json',dict(state='complete',step=step,elapsed_seconds=time.monotonic()-started))


def campaign(root):
    plan=read(root/'plan.json');started=time.monotonic();pending=[tuple(v) for v in plan['gpu_workers']];children=[]
    def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        while pending or any(child.poll() is None for _,_,child in children):
            if time.monotonic()-started>plan['max_seconds']:raise TimeoutError('Four-hour cohort ceiling')
            failures={lane:p.returncode for lane,_,p in children if p.poll() not in [None,0]}
            if failures:raise RuntimeError(f'Owned worker failed:{failures}')
            rows=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.free','--format=csv,noheader,nounits'],text=True).splitlines()
            free={int(row.split(',')[0]):int(row.split(',')[1]) for row in rows}
            for gpu,lane in pending[:]:
                if free.get(gpu,0)<=47000:
                    atomic_json(root/lane/'status.json',dict(state='queued',waiting_for_gpu=gpu,free_mib=free.get(gpu)));continue
                env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),CUDA_DEVICE_ORDER='PCI_BUS_ID',PYTHONPATH=str(root/'source_snapshot'))
                with (root/'logs'/f'{lane}.log').open('ab',buffering=0) as log:
                    child=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.peak_aux_run',str(root),'--lane',lane],cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
                children.append((lane,gpu,child));pending.remove((gpu,lane))
            atomic_json(root/'status.json',dict(state='running' if children else 'queued',elapsed_seconds=time.monotonic()-started,pending=[dict(gpu=g,lane=l) for g,l in pending],children=[dict(role=l,gpu=g,pid=p.pid) for l,g,p in children]))
            render(root);time.sleep(10)
        failures={l:p.returncode for l,_,p in children if p.returncode!=0}
        if failures:raise RuntimeError(f'Owned worker failed:{failures}')
        atomic_json(root/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started))
    except BaseException as error:
        atomic_json(root/'status.json',dict(state='failed',error=repr(error),elapsed_seconds=time.monotonic()-started));raise
    finally:
        for _,_,child in children:
            if child.poll() is None:os.killpg(child.pid,signal.SIGTERM)
        render(root)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('root',type=Path);parser.add_argument('--prepare',action='store_true');parser.add_argument('--lane',choices=list(LABELS));args=parser.parse_args();root=args.root.resolve()
    try:
        if args.prepare:prepare(root)
        elif args.lane:worker(root,args.lane)
        else:campaign(root)
    except BaseException as error:
        if args.lane:atomic_json(root/args.lane/'status.json',dict(state='failed',error=repr(error)))
        raise
