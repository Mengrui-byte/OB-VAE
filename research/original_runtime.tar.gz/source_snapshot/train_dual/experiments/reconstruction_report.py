"""Replay fixed development examples and render the established HTML comparison."""

import argparse
from datetime import datetime, timezone
import hashlib
import html
import json
from pathlib import Path

import numpy as np


VARIANTS = ("control", "spatial", "volume", "temporal")
LABELS = dict(control="增强损失对照", spatial="价格空间修正", volume="数量幅度修正", temporal="时间演变修正")
COLORS = dict(original="#2563eb", control="#ef4444", spatial="#16a34a", volume="#9333ea", temporal="#f59e0b")


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def infer(root, output, previous):
    import torch
    from train_dual.experiments.long_worker import datasets, forward
    from train_dual.util.checkpoint import load_for_inference

    torch.set_num_threads(4)
    seed = 42
    records = {}
    for variant in VARIANTS:
        records[variant] = {
            row["step"]: row for row in (
                json.loads(line) for line in (root / "runs" / f"{variant}_s{seed}" / "evaluations.jsonl").read_text().splitlines()
            )
        }
    step = max(set.intersection(*(set(rows) for rows in records.values())))
    # The examples were selected yesterday, before this campaign's outputs existed.
    with np.load(previous / "unchanged_loss/evaluation/profiles.npz") as old:
        truth, mask, times, indices = (old[key].copy() for key in ("truth", "mask", "time", "indices"))
    initial = torch.load(root / "initial.pt", map_location="cpu", weights_only=False)
    dataset = datasets(root, initial, "val")
    batches = []
    for w, index in enumerate(indices):
        raw = {key: value.unsqueeze(0) for key, value in dataset[int(index)].items()}
        assert np.array_equal(raw["data"][0].numpy()[mask[w]], truth[w][mask[w]]), "Yesterday's example no longer matches dataset"
        batches.append(raw)
    arrays = dict(truth=truth, mask=mask, time=times, indices=indices)
    metadata = dict(
        utc=datetime.now(timezone.utc).isoformat(), seed=seed, common_step=step,
        split=["2025-01-01", "2025-04-01"], evaluation_windows=256,
        window_indices=indices.tolist(), checkpoint_selection="seed 42, latest common evaluated step; no visual selection",
        example_selection="Reuse yesterday's unchanged_loss profiles, including its largest-motion case",
        interpretation="Single-seed reconstruction of the input window, not forecasting or final holdout evaluation",
        variants={},
    )
    output.mkdir(parents=True, exist_ok=True)
    for variant in VARIANTS:
        checkpoint = root / "runs" / f"{variant}_s{seed}" / f"evaluation_step_{step:07d}.pt"
        model, normalizer = load_for_inference(checkpoint, "cuda:0")
        values = []
        with torch.inference_mode():
            for w, raw in enumerate(batches):
                batch = normalizer.prepare(raw, "cuda:0")
                assert np.array_equal(batch["mask"][0].cpu().numpy(), mask[w])
                prediction = forward(model, batch, False)
                value = np.stack([
                    normalizer.inverse_price(prediction["price_norm"], batch)[0].cpu().numpy(),
                    prediction["volume"][0].float().cpu().numpy(),
                ], -1)
                assert np.isfinite(value[mask[w]]).all() and (value[..., 1][mask[w]] >= 0).all()
                values.append(value)
        arrays[variant] = np.stack(values)
        metadata["variants"][variant] = dict(
            checkpoint=str(checkpoint), sha256=hashlib.sha256(checkpoint.read_bytes()).hexdigest(),
            validation=records[variant][step],
        )
        print(json.dumps(dict(inferred=variant, step=step, windows=len(indices))), flush=True)
        del model
        torch.cuda.empty_cache()
    np.savez_compressed(output / "profiles.npz", **arrays)
    write_json(output / "comparison.json", metadata)


def render(output, previous):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import plotly.graph_objects as go
    from plotly.subplots import make_subplots

    with np.load(output / "profiles.npz") as data:
        truth, mask, times, indices = (data[key] for key in ("truth", "mask", "time", "indices"))
        series = [("original", "Original", truth, COLORS["original"])] + [
            (v, dict(control="Control", spatial="Spatial", volume="Volume", temporal="Temporal")[v], data[v], COLORS[v])
            for v in VARIANTS
        ]
    info = json.loads((output / "comparison.json").read_text())
    w, t = 1 if len(truth) > 1 else 0, truth.shape[1] // 2
    T, L = truth.shape[1], truth.shape[-2]
    minute = np.arange(T)
    stamp = lambda a: str(np.datetime64(int(a), "us")) + "Z"
    fig, axes = plt.subplots(3, 2, figsize=(15, 11), constrained_layout=True)
    for key, name, values, color in series:
        for side in range(2):
            valid = mask[w, t, side]
            price = values[w, t, side, :, 0]
            axes[0, side].plot(np.arange(L)[valid], price[valid], label=name, color=color, lw=1)
            slope_mask = valid[64:] & valid[:-64]
            slope = (price[64:] - price[:-64]) / 64 * (-1 if side == 0 else 1)
            axes[1, side].plot((np.arange(L - 64) + 32)[slope_mask], slope[slope_mask], color=color, lw=1)
        mid = values[w, :, :, 0, 0].mean(1)
        axes[2, 0].plot(minute, mid, label=name, color=color, marker=".")
        axes[2, 1].plot(minute[1:], np.diff(mid), color=color, marker=".")
    for side in range(2):
        axes[0, side].set(title=("Bid" if side == 0 else "Ask") + " price profile", xlabel="Rank", ylabel="USDT")
        axes[1, side].set(title=("Bid" if side == 0 else "Ask") + " 64-level slope", xlabel="Rank", ylabel="USDT per level")
    axes[2, 0].set(title="Midpoint evolution", xlabel="Minute in window", ylabel="USDT")
    axes[2, 1].set(title="One-minute midpoint change", xlabel="Minute in window", ylabel="USDT per minute")
    for ax in axes.flat:
        ax.grid(alpha=.2)
    axes[0, 0].legend()
    fig.suptitle(f"Same example as yesterday | {stamp(times[w, 0])} | seed 42, step {info['common_step']}")
    fig.savefig(output / "slope_and_time.png", dpi=130)
    plt.close(fig)

    low = np.floor(min(values[w, ..., 0][mask[w]].min() for _, _, values, _ in series))
    high = max(values[w, ..., 0][mask[w]].max() for _, _, values, _ in series)
    nbins = int(np.ceil(high - low)) + 1
    price_grids, rank_grids = [], []
    for _, _, values, _ in series:
        grid = np.zeros((T, nbins))
        for frame in range(T):
            p, q = values[w, frame, ..., 0][mask[w, frame]], values[w, frame, ..., 1][mask[w, frame]]
            bins = np.floor(p - low).astype(int).clip(0, nbins - 1)
            grid[frame] = np.bincount(bins, weights=q, minlength=nbins)
        price_grids.append(np.log1p(grid))
        quantity = np.where(mask[w], values[w, ..., 1], 0)
        rank_grids.append(np.log1p(np.concatenate([quantity[:, 0, ::-1], quantity[:, 1]], axis=1)))
    vmax, rankmax = max(a.max() for a in price_grids), max(a.max() for a in rank_grids)
    fig, axes = plt.subplots(2, len(series), figsize=(5 * len(series), 9), sharex=True, constrained_layout=True)
    for col, (_, name, values, _) in enumerate(series):
        im = axes[0, col].imshow(price_grids[col].T, origin="lower", aspect="auto", extent=[-.5, T - .5, low, low + nbins], vmin=0, vmax=vmax, cmap="magma")
        axes[0, col].plot(minute, truth[w, :, :, 0, 0].mean(1), color="cyan", lw=.8)
        axes[0, col].set(title=name + ": price aligned", ylabel="USDT; cyan = true midpoint")
        rank_im = axes[1, col].imshow(rank_grids[col].T, origin="lower", aspect="auto", extent=[-.5, T - .5, -L, L], vmin=0, vmax=rankmax, cmap="magma")
        axes[1, col].set(title=name + ": rank aligned", ylabel="Signed rank", xlabel="Minute in window")
    fig.colorbar(im, ax=axes[0, :].tolist(), label="log1p(BTC / 1-USDT bin)", shrink=.8)
    fig.colorbar(rank_im, ax=axes[1, :].tolist(), label="log1p(BTC / level)", shrink=.8)
    fig.suptitle("Identical window, axes and color scales across all models")
    fig.savefig(output / "liquidity_evolution.png", dpi=120)
    plt.close(fig)

    # An unchanged y scale preserves amplitude differences during each 16-minute playback.
    def layout_ranges(window):
        result = {}
        for side, axis in ((0, "xaxis"), (1, "xaxis2")):
            prices = [v[window, :, side, :, 0][mask[window, :, side]] for _, _, v, _ in series]
            lo, hi = min(p.min() for p in prices), max(p.max() for p in prices)
            pad = max((hi - lo) * .02, 1.)
            result[axis] = dict(range=[lo - pad, hi + pad], autorange=False)
        ymax = max(v[window, ..., 1][mask[window]].max() for _, _, v, _ in series) * 1.05
        result.update(yaxis=dict(range=[0, ymax], autorange=False), yaxis2=dict(range=[0, ymax], autorange=False))
        mids = [v[window, :, :, 0, 0].mean(1) for _, _, v, _ in series]
        lo, hi = min(m.min() for m in mids), max(m.max() for m in mids)
        result['yaxis3'] = dict(range=[lo - 2, hi + 2], autorange=False)
        totals = [np.where(mask[window], v[window, ..., 1], 0).sum((1, 2)) for _, _, v, _ in series]
        result['yaxis4'] = dict(range=[0, max(q.max() for q in totals) * 1.05], autorange=False)
        return result

    def traces(window, frame):
        curves = []
        for side in range(2):
            valid = mask[window, frame, side]
            for key, name, values, color in series:
                curves.append(go.Scatter(x=values[window, frame, side, valid, 0], y=values[window, frame, side, valid, 1], mode="lines", name=name, legendgroup=key, showlegend=side == 0, line=dict(color=color, width=1.2)))
        for key, name, values, color in series:
            curves.append(go.Scatter(x=minute, y=values[window, :, :, 0, 0].mean(1), mode="lines+markers", name=name, legendgroup=key, showlegend=False, line=dict(color=color)))
        curves.append(go.Scatter(x=[frame], y=[truth[window, frame, :, 0, 0].mean()], mode="markers", name="Current frame", showlegend=False, marker=dict(color="black", size=10)))
        for key, name, values, color in series:
            totals = np.where(mask[window], values[window, ..., 1], 0).sum((1, 2))
            curves.append(go.Scatter(x=minute, y=totals, mode="lines+markers", name=name, legendgroup=key, showlegend=False, line=dict(color=color)))
        return curves

    fig = make_subplots(rows=2, cols=2, subplot_titles=["Bid quantity vs price", "Ask quantity vs price", "Midpoint through time", "Total visible quantity through time"], vertical_spacing=.16)
    n = len(series)
    for i, curve in enumerate(traces(0, 0)):
        panel = 0 if i < n else 1 if i < 2 * n else 2 if i < 3 * n + 1 else 3
        fig.add_trace(curve, row=panel // 2 + 1, col=panel % 2 + 1)
    for trace in fig.data:
        if trace.legendgroup in ("spatial", "temporal"):
            trace.visible = "legendonly"
    frames, steps = [], []
    for window in range(len(truth)):
        for frame in range(T):
            name = f"w{window}_t{frame}"
            frames.append(go.Frame(name=name, data=traces(window, frame), layout=go.Layout(title_text=f"Window {int(indices[window])} | {stamp(times[window, frame])}", **layout_ranges(window))))
            steps.append(dict(label=f"W{window + 1} t{frame}", method="animate", args=[[name], dict(mode="immediate", frame=dict(duration=0, redraw=True), transition=dict(duration=0))]))
    fig.frames = frames
    fig.update_layout(height=850, template="plotly_white", title_text=f"Window {int(indices[0])} | {stamp(times[0, 0])}", legend=dict(groupclick="togglegroup"), sliders=[dict(steps=steps, currentvalue=dict(prefix="Frame: "))], updatemenus=[dict(type="buttons", buttons=[dict(label="Play", method="animate", args=[None, dict(frame=dict(duration=550, redraw=True), transition=dict(duration=0), fromcurrent=True, mode="immediate")]), dict(label="Pause", method="animate", args=[[None], dict(frame=dict(duration=0, redraw=False), mode="immediate")])], x=0, y=-.15)], **layout_ranges(0))
    for col in (1, 2):
        fig.update_xaxes(title_text="Price (USDT)", row=1, col=col)
        fig.update_yaxes(title_text="Quantity (BTC)", row=1, col=col)
        fig.update_xaxes(title_text="Minute in window", row=2, col=col)
    fig.update_yaxes(title_text="Midpoint (USDT)", row=2, col=1)
    fig.update_yaxes(title_text="Quantity (BTC)", row=2, col=2)

    rows = []
    for variant in VARIANTS:
        result = info["variants"][variant]["validation"]["result"]
        m, threshold = result["metrics"], result["thresholds"]["100"]
        precision = "—" if threshold["precision"] is None else f"{threshold['precision']:.1%}"
        recall = "—" if threshold["recall"] is None else f"{threshold['recall']:.1%}"
        rows.append(f"<tr><td>{LABELS[variant]}</td><td>{m['price_usdt']['rmse']:.3f}</td><td>{m['spatial_slope_64_levels_usdt_per_level']['rmse']:.5f}</td><td>{m['temporal_mid_1_minutes_usdt_per_minute']['rmse']:.3f}</td><td>{m['quantity_btc']['rmse']:.3f}</td><td>{result['tail_log_rmse']:.3f}</td><td>{precision}</td><td>{recall}</td></tr>")
    peak_rows = []
    for window in range(len(truth)):
        quantity = np.where(mask[window], truth[window, ..., 1], -1)
        frame, side, rank = np.unravel_index(np.argmax(quantity), quantity.shape)
        values = [f"{v[window, frame, side, rank, 1]:.2f}" for _, _, v, _ in series]
        peak_rows.append(f"<tr><td>W{window+1} / {int(indices[window])}</td><td>{stamp(times[window,frame])}</td><td>{'Bid' if side==0 else 'Ask'} #{rank+1}</td>" + ''.join(f'<td>{x}</td>' for x in values) + '</tr>')
    page = f"""<!doctype html><html lang="zh"><meta charset="utf-8"><title>最新订单簿重建对比</title>
<style>body{{font:16px system-ui;margin:24px auto;max-width:1500px;padding:0 20px;color:#162235}}img{{width:100%;height:auto}}p{{line-height:1.7}}a{{color:#2563eb}}table{{border-collapse:collapse;width:100%;text-align:right}}th,td{{border:1px solid #d8dfe9;padding:9px}}.scroll{{overflow-x:auto}}.heat{{min-width:1800px}}small{{color:#526276}}</style>
<h1>最新订单簿重建：价格斜率、大额档位与时间演变</h1>
<p>训练已按要求停止。沿用昨天的三个验证窗口，蓝色 Original 为真实订单簿，红色 Control 为增强损失对照，绿色 Spatial 为价格空间修正，紫色 Volume 为数量幅度修正，橙色 Temporal 为时间演变修正。</p>
<p>四个方案统一使用种子 <b>42</b>、相同 <b>{info['common_step']} 次更新</b>的不可变权重，FP32 确定性推理。下表使用相同的 256 个开发验证窗口；动画只展示昨天已选定的三个样本。这里展示输入窗口内的重建。</p>
<h2>同一步数验证对比（单种子）</h2><div class="scroll"><table><tr><th>方案</th><th>价格 RMSE<br>USDT</th><th>64档斜率 RMSE<br>USDT/档</th><th>分钟中间价变化 RMSE<br>USDT/分</th><th>数量 RMSE<br>BTC</th><th>≥100 BTC 对数数量 RMSE</th><th>≥100 BTC 精确率</th><th>≥100 BTC 召回率</th></tr>{''.join(rows)}</table></div>
<p>大额档位指一个价位上聚合的挂单量；精确率和召回率按同一档位匹配。三个样本不能代表总体，指标表来自完整的固定验证样本集。</p>
<p><a href="comparison.json">下载指标和权重信息</a> · <a href="profiles.npz">下载重建数组</a> · <a href="yesterday/">查看昨天的对比页</a> · <a href="long_run.html">已停止实验的进度记录</a></p>
<h2>价格斜率与中间价演变</h2><p>使用昨天变化最大的同一窗口，快照时刻为窗口第 {t+1} 分钟；下方两图覆盖全部16分钟。</p><img src="slope_and_time.png" alt="Price profile, slope and midpoint evolution">
<h2>流动性随时间演变</h2><p>上排按真实价格每 1 USDT 聚合数量，下排按档位对齐。同一排所有方案共享色阶和坐标；横向滚动查看全部方案。</p><div class="scroll"><img class="heat" src="liquidity_evolution.png" alt="Shared-scale liquidity evolution"></div>
<h2>同一窗口逐分钟播放</h2><p>点击 Play 播放，拖动滑块切换 W1/W2/W3 与分钟。默认显示真实、对照和数量修正；点击图例切换其他方案，同色曲线一起显示或隐藏。买卖两侧共用数量坐标，窗口内保持固定范围，可直接比较峰值幅度。</p>
""" + fig.to_html(full_html=False, include_plotlyjs="directory", auto_play=False, div_id="book-animation")
    page += f"""<h2>三个窗口各自最大真实挂单的恢复情况</h2><p>位置由真实数量的最大值确定，表中比较同一时刻、同一侧、同一档位的数量（BTC），可在动画中查看对应位置。</p><div class="scroll"><table><tr><th>窗口</th><th>UTC</th><th>位置</th><th>Original</th><th>Control</th><th>Spatial</th><th>Volume</th><th>Temporal</th></tr>{''.join(peak_rows)}</table></div><p><small>生成时间 {html.escape(info['utc'])}；验证区间 2025-01-01 至 2025-04-01；此次展示没有使用最终留出集。</small></p></html>"""
    # to_html's directory option references this local asset without needing a CDN.
    from plotly.offline import get_plotlyjs
    (output / "plotly.min.js").write_text(get_plotlyjs())
    (output / "index.html").write_text(page)
    write_json(output / "manifest.json", dict(seed=42, common_step=info['common_step'], window_indices=indices.tolist(), frames=len(frames), trace_count=len(fig.data), source="Yesterday's fixed examples", report_precision="fp32"))
    print(output / "index.html", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("infer", "render"))
    parser.add_argument("root", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("previous", type=Path)
    args = parser.parse_args()
    if args.mode == "infer":
        infer(args.root, args.output, args.previous)
    else:
        render(args.output, args.previous)


if __name__ == "__main__":
    main()
