"""Fresh end-to-end2x2: temporal bottleneck organization x quantity coordinates."""
import argparse
from datetime import datetime
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import numpy as np
import torch
from torch.utils.data import DataLoader

from model.autoencoder.time_layout_vae import TimeLayoutOrderBookVAE
from model.losses.logit_book import LogitBookLoss,inverse_softplus
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.local_quant_reconstruction import CacheWindows
from train_dual.experiments.long_worker import atomic_json,evaluate
from train_dual.experiments.phase_detail_report import read,preview
from train_dual.experiments.probability_eval import evaluate_probability
from train_dual.experiments.unified_8192_run import call,group_gradients
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import atomic_save,freeze_sources,load_for_inference,seed_everything,source_hashes
from train_dual.util.moving_peak import moving_peak_window,MovingPeakWindows
from train_dual.util.phase_training import tensor_digest

LABELS={'patch_huber':'四帧打包·原数量监督','patch_logit':'四帧打包·logit监督','frame_huber':'每帧32维·原数量监督','frame_logit':'每帧32维·logit监督'}


def calibrate_heads(model,scales):
    def inv(value):return float(inverse_softplus(torch.tensor(max(value,1e-4))))
    with torch.no_grad():
        model.price_decoder.gap.weight.zero_()
        model.price_decoder.gap.bias.fill_(inv(scales['median_gap_ticks']-1))
        model.price_decoder.mid_spread[-1].weight.zero_();model.price_decoder.mid_spread[-1].bias.zero_()
        model.price_decoder.mid_spread[-1].bias[1]=inv(scales['median_spread_ticks']-1)
        model.volume_decoder.quantity.weight.zero_();model.volume_decoder.quantity.bias.fill_(inv(scales['mean_quantity']/scales['quantity_scale']))


def prepare(parent):
    project=Path(__file__).resolve().parents[2];parent=parent.resolve()
    root=project/'recons'/('time_logit_'+datetime.now().strftime('%Y%m%d_%H%M%S'));root.mkdir()
    for name in ['data','logs','pilot',*LABELS]:(root/name).mkdir()
    for lane in LABELS:(root/'pilot'/lane).mkdir()
    for name in ['train_indices.npy','val_indices.npy','seen_indices.npy','plotly.min.js','latent_fit_indices.npy']:
        os.link(parent/name,root/name)
    os.link(parent/'plotly.min.js',root/'pilot/plotly.min.js');os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    old=read(parent/'plan.json')
    plan={k:old[k] for k in ['train','development','independent_test_untouched','normalization','model_config','objective','window_size','stride','input_shape','latent_shape','output_shape','fit_windows','seen_windows','evaluation_windows','batch_size','accumulation','lr','weight_decay','clip_grad']}
    lanes={k:dict(layout='frame1' if k.startswith('frame') else 'patch4',use_logit=k.endswith('logit')) for k in LABELS}
    plan.update(parent=str(parent),experiment='Fresh end-to-end time layout x pre-Softplus quantity supervision2x2',labels=LABELS,lanes=lanes,
        steps=4096,checkpoints=[128,512,1024,2048,4096],max_seconds=21600,seed=42,beta=0.,sample=False,
        inline_evaluation=True,time_layout_config=dict(frame_ffn=1536),quantity_floor=1e-4,
        gpu_workers=[[g,l] for g,l in zip([2,3,4,5],LABELS)],
        pilot=dict(steps=256,checkpoints=[128,256],windows=4,reset_after=True,
            quantity='Synthetic valid background0.02BTC, one moving peak per side at200/400BTC, alternating16frame on/off; preserve training-template prices/masks.',
            note='Training-only fit diagnosis, not real-market evaluation. No pilotweights orAdamstate enter maintraining. No development-based groupselection.'),
        initialization='Fresh seed42 models, not historical weights. Same-layout loss pairs share byte-identical initial checkpoints. Shared shape-compatible spatial/side/price/volume parameters match acrosslayouts. Zero output weights andsame training-only gap/spread/quantity biases give identical initial price/quantity functions.',
        coordinate_factor='Replace only all-valid andTop16 normalized-quantityHuber with Huber(rawlogit - inverseSoftplus(max(q/q0,1e-4))). Keep price,logquantity,fineKL,mass,allcoefficients unchanged. No newW1,multiscaleKL,auxiliarylocation orlarge-only weighting.',
        temporal_factor='patch4:64tokens128channels. frame1:256time-attended32channel means/logvars serialized to64x128; decode byinverse reshape into256frames. Encoder temporalFFN1536 vs1024 andframe decoderMLP32->2048->256 vs128->512->1024 keep totalparameters close. Whole temporal organization isone architecture factor; no claim of isolatingreshapealone.',
        control_contract='Allmodules train end-to-end, same256frames,unique8192Gaussian,mask/noEncoderbypass,seed42,data/order,normalization,4096real updates,batch1accum4,AdamW1e-4,clip1. Four256update synthetic pilots discarded before reset. BF16neural/FP32loss+evaluation,TF32off,6hour ceiling.',
        primary='Fixed4096realupdateendpoint quantityRMSE,actual10/100BTCprecision/recall/FP,dynamics on16development+8seen; allcheckpoints retained. Report priceRMSE tradeoff andrequire<=1.10matched baseline forunqualified jointreconstruction gain.',
        selection='Exploratory seed42only; reused2025Q1development,2025Q2 and2026 untouched. Synthetic pilot isnot a development score.',
        authorization='User requested proposed temporal organization x preactivation supervision factorial; bounded4GPUs2–5,each256discardedpilot+4096realupdates.',
        report=dict(title='端到端重训：时间组织 × 激活前数量监督',scope='唯一64×128Gaussian，Encoder与价格/数量Decoder全部训练。',
            introduction='四组从头初始化，完整256分钟。先做相同256步移动峰小样本诊断，再丢弃诊断权重及Adam状态，重新从初始模型训练4096步真实数据。两项因素为时间瓶颈组织和数量Huber的监督坐标。',
            hardware='GPU2–5各一组，固定seed42、1024训练窗、有效batch4、最多6小时。',
            reference_note='这是从头训练的新对照，初始量价为相同的训练统计基线；未加载历史模型权重。',
            future='每帧32维先整窗注意力再形成posterior，之后无损重排为64×128，不增加latent数量。logit目标对零量使用固定归一化下限1e-4，最终输出仍为q0·Softplus。'))
    atomic_json(root/'plan.json',plan)
    original=dataset(root,'train');chosen=np.load(root/'latent_fit_indices.npy');windows=[];times=[]
    for i,index in enumerate(chosen):
        raw=original[int(index)];windows.append(moving_peak_window(raw,i))
        start=int(original.base.starts[int(index)]);times.append(original.base.times[start:start+256])
    atomic_save(dict(windows=windows,source_indices=chosen,absolute_times=np.stack(times)),root/'data/moving_peak_windows.pt')
    contracts={};config=dict(normalization=dict(tick_size=plan['normalization']['tick_size'],price_scale=plan['normalization']['price_scale']),arguments=dict(window_size=256,stride=256,levels=2048,batch_size=1,accumulation_steps=4,precision='bf16'),loss=plan['objective'])
    for layout in ['patch4','frame1']:
        seed_everything(42);model=TimeLayoutOrderBookVAE(layout=layout,**plan['time_layout_config'],**plan['model_config']);calibrate_heads(model,plan['normalization'])
        contracts[layout]=dict(parameters=sum(p.numel() for p in model.parameters()),model_sha256=tensor_digest(model),
            shared_modules={name:tensor_digest(module) for name,module in [('encoder_space',model.encoder.input_proj),('encoder_cross',model.encoder.cross),('encoder_frame',model.encoder.frame),('price_space',model.price_decoder.spatial),('volume_space',model.volume_decoder.spatial)]})
        atomic_save(dict(format_version=1,model=model.state_dict(),unified_vae_config=plan['model_config'],time_layout_config=dict(layout=layout,**plan['time_layout_config']),config=config,step=0,fresh_seed=42),root/f'initial_{layout}.pt')
    assert contracts['patch4']['shared_modules']==contracts['frame1']['shared_modules']
    plan['initial_contracts']=contracts;plan['parameters_relative_difference']=(contracts['frame1']['parameters']/contracts['patch4']['parameters']-1)
    atomic_json(root/'plan.json',plan)
    pilot_plan=dict(plan,steps=plan['pilot']['steps'],checkpoints=plan['pilot']['checkpoints'],preview_descriptions={l:'合成移动峰训练窗口；价格来自训练模板，数量由规则构造，目标参与拟合。此结果不是实际市场开发集或样本外成绩；诊断权重不带入主训练。' for l in LABELS})
    atomic_json(root/'pilot/plan.json',pilot_plan)
    atomic_json(root/'data_contract.json',dict(raw_input=plan['input_shape'],posterior=plan['latent_shape'],price_output=plan['output_shape'],quantity_output=plan['output_shape'],real_training_indices=np.load(root/'train_indices.npy').tolist(),seen_indices=np.load(root/'seen_indices.npy').tolist(),development_indices=np.load(root/'val_indices.npy').tolist(),synthetic_training_template_indices=chosen.tolist(),normalization_reused_training_only=True))
    atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'
        f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\n'
        f'cd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.time_logit_run "{remote}"\n')
    refresh(root);Path('/tmp/time_logit_path').write_text(str(root));print(root,flush=True)


def criterion_for(plan,lane):
    return LogitBookLoss(plan['normalization']['quantity_scale'],mode='shape_mass',use_logit=plan['lanes'][lane]['use_logit'],quantity_floor=plan['quantity_floor'],add_wasserstein=False,add_multiscale=False,**plan['objective'])


def write_profiles(folder,step,model,norm,data,original=None):
    positions=np.unique(np.linspace(0,len(data)-1,min(3,len(data)),dtype=int));values={k:[] for k in ['truth','prediction','mask','time']};indices=[];model.eval()
    with torch.inference_mode():
        for pos in positions:
            raw={k:v.unsqueeze(0) for k,v in data[int(pos)].items()};b=norm.prepare(raw,'cuda:0');out=call(model,b,False)
            values['truth'].append(raw['data'][0].numpy());values['mask'].append(b['mask'][0].cpu().numpy())
            values['prediction'].append(np.stack((norm.inverse_price(out['price_norm'],b)[0].cpu().numpy(),out['volume'][0].cpu().numpy()),-1))
            if original is None:idx=int(data.indices[int(pos)]);absolute=data.absolute_times[int(pos)]
            else:
                idx=int(data.indices[int(pos)]);start=int(original.base.starts[idx]);absolute=original.base.times[start:start+256]
            values['time'].append(absolute);indices.append(idx)
    temp=folder/f'step{step}_profiles.tmp'
    with temp.open('wb') as f:np.savez_compressed(f,**{k:np.stack(v) for k,v in values.items()},indices=indices)
    temp.replace(folder/f'step{step}_profiles.npz')


def assess(root,lane,step,phase,model,norm,criterion,train,dev,seen,original):
    folder=root/lane if phase=='main' else root/'pilot'/lane
    atomic_json(root/lane/'evaluation_status.json',dict(state='evaluating',phase=phase,step=step))
    if phase=='pilot':
        atomic_json(folder/f'step{step}_evaluation.json',dict(result=evaluate(model,norm,train,len(train),'cuda:0')))
        write_profiles(folder,step,model,norm,train);preview(root/'pilot',lane,step)
    else:
        atomic_json(folder/f'step{step}_evaluation.json',dict(result=evaluate(model,norm,dev,len(dev),'cuda:0')))
        atomic_json(folder/f'step{step}_seen_evaluation.json',dict(result=evaluate(model,norm,seen,len(seen),'cuda:0')))
        atomic_json(folder/f'step{step}_probability.json',dict(development=evaluate_probability(model,norm,dev,len(dev),'cuda:0',criterion),seen=evaluate_probability(model,norm,seen,len(seen),'cuda:0',criterion)))
        write_profiles(folder,step,model,norm,dev,original);preview(root,lane,step)
    atomic_json(root/lane/'evaluation_status.json',dict(state='complete',phase=phase,step=step))


def train_phase(root,lane,phase,started):
    plan=read(root/'plan.json');spec=plan['lanes'][lane];seed_everything(42);strict_precision()
    model,norm=load_for_inference(root/f'initial_{spec["layout"]}.pt','cuda:0');model.train().requires_grad_(True)
    initial_hash=tensor_digest(model)
    if initial_hash!=plan['initial_contracts'][spec['layout']]['model_sha256']:raise RuntimeError('Initial model changed')
    folder=root/lane if phase=='main' else root/'pilot'/lane
    opt=torch.optim.AdamW(model.parameters(),lr=plan['lr'],weight_decay=plan['weight_decay']);criterion=criterion_for(plan,lane)
    if phase=='main':
        atomic_json(root/lane/'pilot_reset_audit.json',dict(passed=True,restored_model_sha256=initial_hash,optimizer_state_entries=len(opt.state),pilot_optimizer_reused=False))
        original=dataset(root,'train');train=CacheWindows(original,np.load(root/'train_indices.npy'))
        dev_original=dataset(root,'val');dev=CacheWindows(dev_original,np.load(root/'val_indices.npy'));seen=CacheWindows(original,np.load(root/'seen_indices.npy'))
    else:train=MovingPeakWindows(root/'data/moving_peak_windows.pt');dev=seen=dev_original=None
    total=plan['steps'] if phase=='main' else plan['pilot']['steps'];checks=plan['checkpoints'] if phase=='main' else plan['pilot']['checkpoints']
    loader=DataLoader(train,batch_size=1,shuffle=True,num_workers=2,persistent_workers=True,pin_memory=True,generator=torch.Generator().manual_seed(42));iterator=iter(loader)
    exposures=np.zeros(len(train),dtype=np.int64);hashes=source_hashes()
    atomic_json(root/lane/'status.json',dict(state=f'{phase}_training',step=0))
    if phase=='pilot':
        raw={k:v.unsqueeze(0) for k,v in train[0].items()};b=norm.prepare(raw,'cuda:0');model.eval();seen_z=[]
        hooks=[d.register_forward_pre_hook(lambda m,a:seen_z.append(a[0])) for d in [model.price_decoder,model.volume_decoder]]
        with torch.inference_mode():
            out=call(model,b,False);replay=model.decode(out['z'],b['mask'],b['tick_norm'],b['times'])
            for key in ['price_norm','volume','quantity_logit']:torch.testing.assert_close(out[key],replay[key],rtol=0,atol=0)
        for hook in hooks:hook.remove()
        assert seen_z[0] is seen_z[1] and seen_z[0] is out['z']
        assert list(raw['data'].shape)==plan['input_shape'] and list(out['z'].shape)==plan['latent_shape']
        assert list(out['price_norm'].shape)==plan['output_shape'] and list(out['volume'].shape)==plan['output_shape']
        atomic_json(root/lane/'actual_shape_contract.json',dict(passed=True,raw_input=list(raw['data'].shape),mu=list(out['mu'].shape),logvar=list(out['logvar'].shape),latent=list(out['z'].shape),price=list(out['price_norm'].shape),quantity=list(out['volume'].shape),raw_quantity_logit=list(out['quantity_logit'].shape),shared_z_object=True,decode_only_replay_exact=True,posterior_count=1,encoder_skip=False,all_model_parameters_trainable=True))
        del raw,b,out,replay,seen_z
    source_config=torch.load(root/f'initial_{spec["layout"]}.pt',map_location='cpu',weights_only=False)['config']
    def save(step):
        atomic_save(dict(format_version=1,model=model.state_dict(),unified_vae_config=plan['model_config'],time_layout_config=dict(layout=spec['layout'],**plan['time_layout_config']),config=dict(source_config,loss_family='logit',loss=dict(plan['objective'],use_logit=spec['use_logit'],quantity_floor=plan['quantity_floor'])),step=step,phase=phase,lane=lane,beta=0.,training_sample=False,optimizer=opt.state_dict(),source_hashes=hashes,torch_rng_state=torch.get_rng_state(),cuda_rng_state=torch.cuda.get_rng_state_all(),sampler_generator_state=loader.generator.get_state(),epoch_boundary=step*plan['accumulation']%len(train)==0,training_data=dict(exposure_counts=exposures.copy(),windows=len(train),epochs_equivalent=step*plan['accumulation']/len(train))),folder/f'step{step}.pt')
    save(0);assess(root,lane,0,phase,model,norm,criterion,train,dev,seen,dev_original)
    for step in range(1,total+1):
        if time.monotonic()-started>plan['max_seconds']:raise TimeoutError('Six-hour worker ceiling')
        model.train();opt.zero_grad(set_to_none=True);record={};order=[]
        for micro in range(plan['accumulation']):
            try:raw=next(iterator)
            except StopIteration:iterator=iter(loader);raw=next(iterator)
            pos=int(raw['cache_position'][0]);exposures[pos]+=1;order.append(int(train.indices[pos]));b=norm.prepare(raw,'cuda:0')
            assert list(raw['data'].shape)==plan['input_shape']
            with torch.autocast('cuda',dtype=torch.bfloat16):out=call(model,b,False)
            assert list(out['z'].shape)==plan['latent_shape'] and list(out['volume'].shape)==plan['output_shape']
            values=criterion(out,b,beta=0.)
            if not bool(torch.isfinite(values['loss'])):raise FloatingPointError('Nonfinite loss')
            (values['loss']/plan['accumulation']).backward()
            for key,v in values.items():record[key]=record.get(key,0.)+float(v.detach())/plan['accumulation']
        if step in [1,8]:
            gradients=group_gradients(model)
            if any(not math.isfinite(v) for v in gradients.values()):raise FloatingPointError('Nonfinite module gradient')
            if step==8 and any(v<=0 for n,v in gradients.items() if n!='posterior_logvar'):raise RuntimeError(f'Missing end-to-end gradient:{gradients}')
            atomic_json(folder/f'step{step}_gradient_audit.json',dict(passed=True,gradients=gradients,logvar_zero_expected_beta0=True,zero_output_weights_allow_zero_encoder_gradient_at_step1=True))
        if step==1:atomic_json(folder/'first_step_data.json',dict(training_indices=order,losses=record))
        grad=torch.nn.utils.clip_grad_norm_(model.parameters(),plan['clip_grad'],error_if_nonfinite=True);opt.step()
        if step==1 or step%8==0:
            row=dict(phase=phase,step=step,total=total,elapsed_seconds=time.monotonic()-started,gradient_norm=float(grad),reserved_gib=torch.cuda.memory_reserved()/2**30,epochs_equivalent=float(exposures.mean()),unique_windows_seen=int((exposures>0).sum()),training_indices=order,**record)
            atomic_json(root/lane/'progress.json',row)
            with (folder/'progress.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
            print(json.dumps(row),flush=True)
        if step in checks:save(step);assess(root,lane,step,phase,model,norm,criterion,train,dev,seen,dev_original)
    if phase=='pilot':atomic_json(folder/'status.json',dict(state='complete',step=total,weights_discarded_before_main=True))
    del iterator,loader,opt,model,criterion
    torch.cuda.empty_cache()


def worker(root,lane):
    torch.set_num_threads(4);started=time.monotonic()
    train_phase(root,lane,'pilot',started);train_phase(root,lane,'main',started)
    atomic_json(root/lane/'status.json',dict(state='complete',step=read(root/'plan.json')['steps'],elapsed_seconds=time.monotonic()-started))


def refresh(root):
    from train_dual.experiments.time_logit_report import render
    try:render(root)
    except Exception as error:
        import traceback
        atomic_json(root/'report_status.json',dict(state='failed_retry_pending',error=repr(error)))
        with (root/'logs/report_errors.log').open('a') as f:f.write(traceback.format_exc()+'\n')
        return False
    atomic_json(root/'report_status.json',dict(state='complete'));return True


def campaign(root):
    plan=read(root/'plan.json');started=time.monotonic();children=[]
    def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        rows=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.free','--format=csv,noheader,nounits'],text=True).splitlines();free={int(r.split(',')[0]):int(r.split(',')[1]) for r in rows}
        if any(free.get(g,0)<47000 for g in [2,3,4,5]):raise RuntimeError('Need idle GPUs2–5; no external job displacement')
        for gpu,lane in plan['gpu_workers']:
            env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),CUDA_DEVICE_ORDER='PCI_BUS_ID',PYTHONPATH=str(root/'source_snapshot'))
            with (root/'logs'/f'{lane}.log').open('ab',buffering=0) as log:
                child=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.time_logit_run',str(root),'--lane',lane],cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            children.append((lane,gpu,child))
        atomic_json(root/'status.json',dict(state='running',children=[dict(role=l,gpu=g,pid=p.pid) for l,g,p in children]))
        while any(p.poll() is None for _,_,p in children):
            if time.monotonic()-started>plan['max_seconds']:raise TimeoutError('Six-hour campaign ceiling')
            failed={l:p.returncode for l,_,p in children if p.poll() not in [None,0]}
            if failed:raise RuntimeError(f'Owned worker failed:{failed}')
            refresh(root);time.sleep(10)
        failed={l:p.returncode for l,_,p in children if p.returncode!=0}
        if failed:raise RuntimeError(f'Owned worker failed:{failed}')
        atomic_json(root/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started))
    except BaseException as error:atomic_json(root/'status.json',dict(state='failed',error=repr(error)));raise
    finally:
        for _,_,p in children:
            if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)
        refresh(root)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--lane',choices=list(LABELS));args=p.parse_args();root=args.root.resolve()
    try:
        if args.prepare:prepare(root)
        elif args.lane:worker(root,args.lane)
        else:campaign(root)
    except BaseException as error:
        if args.lane:atomic_json(root/args.lane/'status.json',dict(state='failed',error=repr(error)))
        raise
