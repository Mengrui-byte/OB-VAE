"""Live data-coverage report with matched seen windows and initial-model guards."""
import argparse
import json
from pathlib import Path
import threading

from train_dual.experiments.full_window_report import PAGE, monitor
from train_dual.experiments.long_worker import atomic_json


def read(path):
    try:return json.loads(path.read_text())
    except (OSError,ValueError):return None


def diagnostics(root):
    plan=read(root/'plan.json')
    rows={}
    for lane,label in plan['labels'].items():
        seen={}
        dev={}
        for step in [0,*plan['checkpoints']]:
            prefix='initial' if step==0 else f'step{step}'
            a=read(root/lane/(prefix+'_seen_evaluation.json'))
            b=read(root/lane/(prefix+'_evaluation.json'))
            if a:seen[str(step)]=a['result']
            if b:dev[str(step)]=b['result']
        rows[lane]=dict(label=label,training_windows=plan['training_windows_by_lane'][lane],
                        exposures=read(root/lane/'data_exposures.json'),seen=seen,development=dev)
    common=[s for s in [0,*plan['checkpoints']] if all(str(s) in row['development'] and str(s) in row['seen'] for row in rows.values())]
    latest=max(common) if common else None
    comparison={}
    if latest is not None and '0' in rows['n64']['development']:
        initial=rows['n64']['development']['0']['metrics']
        control=rows['n64']['development'][str(latest)]['metrics']
        for lane,row in rows.items():
            dev=row['development'][str(latest)]
            m=dev['metrics']
            p,q=m['price_usdt']['rmse'],m['quantity_btc']['rmse']
            corr=m['temporal_log_quantity_1_minutes']['correlation']
            q_initial=q/initial['quantity_btc']['rmse']
            q_control=q/control['quantity_btc']['rmse']
            price_guard=(p<=1.1*initial['price_usdt']['rmse'] and p<=1.1*control['price_usdt']['rmse'])
            comparison[lane]=dict(step=latest,quantity_rmse_ratio_to_initial=q_initial,
                quantity_rmse_ratio_to_n64=q_control,price_guard_vs_initial_and_n64=price_guard,
                quantity_change_correlation=corr,
                exploratory_screen_pass=latest>0 and lane!='n64' and q_control<=.95 and q_initial<1
                    and corr is not None and corr>=.10 and price_guard,
                development=dev,common_seen=row['seen'][str(latest)])
        atomic_json(root/'latest_comparison.json',dict(common_step=latest,rows=comparison,
            interpretation='Both shared-initial and same-update n64 guards; screening only, not independent-test validation.'))
    payload=dict(status=read(root/'status.json'),rows=rows,common_step=latest,
                 comparison=comparison,data_contract=read(root/'data_contract.json'))
    atomic_json(root/'public/diagnostics.json',payload)
    if latest==plan['steps']:
        atomic_json(root/'endpoint_summary.json',dict(step=latest,rows=comparison,
            training_coverage={lane:row['exposures'] for lane,row in rows.items()},
            scope='Single seed42;16reused2025Q1development windows;common2816-update64-window pretraining;no2026orindependenttestselection.'))


def main(root):
    root=root.resolve()
    plan=read(root/'plan.json')
    total=plan['training_windows_by_lane']['all']
    page=PAGE.replace('256分钟双分支实验','8192训练数据规模对照').replace(
        '完整256分钟：双分支与整窗矩阵压缩','8192瓶颈：训练数据覆盖规模对照')
    begin,end=page.index('<p>实际输入'),page.index('<p id=status>')
    text=(f'<p>四个训练池：64、256、1024、全部{total}个完整256分钟窗口。逐级包含，保留原64窗，'
          '新增数据按2022–2024各UTC月份覆盖抽样。每侧2048档、唯一64×128latent，两个Decoder共用Z=μ，beta0。</p>'
          '<p>共同起点为四窗口微调前full-route512权重和AdamW状态（此前累计2816更新）。'
          '相同shape_mass损失及权重、最近邻上采样、完整数量梯度回传、原64训练窗归一化；'
          'seed42、batch1累积4、AdamW1e−4、clip1，每组追加2048更新。只改变不同训练窗口的数量。</p>'
          '<p>相同8个训练诊断窗、16个2025Q1开发窗；训练池自身的随机batch损失仅作轨迹，跨组拟合比较使用固定8窗。'
          '相同更新预算下，大池遍历次数更少，不能把短期未改善直接解释为容量不足。'
          '源模型此前只见过原64窗，本轮检验新增覆盖收益。2025Q1反复用于开发，2026和独立测试未参与。</p>'
          '<p>评价同时对照本轮64窗组和共同起点，检查价格误差、数量误差、数量变化和大单精确率/召回。'
          '图中的共同起点是同一个8192模型。</p>')
    page=page[:begin]+text+page[end:]
    page=page.replace('实际矩阵','实际唯一latent').replace('上一轮16分钟结果','上一轮实验结果')
    page=page.replace("'训练损失'","'各训练池基础损失（同8窗拟合见下表）'")
    tables=('<h2>训练覆盖与重复次数</h2><table><thead><tr><th>方案</th><th>训练池窗口数</th>'
            '<th>已见不同窗口</th><th>累计窗口展示</th><th>等效遍历次数</th><th>最少/最多曝光</th>'
            '<th>计划总遍历</th></tr></thead><tbody id=coverageRows></tbody></table>'
            '<h2>同8个训练窗口的拟合</h2><table><thead><tr><th>方案</th><th>步数</th>'
            '<th>价格RMSE USDT</th><th>数量RMSE BTC</th><th>分钟数量变化相关</th>'
            '<th>≥100BTC精确率</th><th>≥100BTC召回</th></tr></thead><tbody id=seenRows></tbody></table>'
            '<h2>最新共同检查点：对照共同起点与64窗组</h2><p>筛选标准预先固定：开发数量RMSE比64窗组低至少5%且低于起点；'
            '分钟数量变化相关性≥0.10；价格RMSE同时不超过64窗组和起点的1.10倍。仅用于候选筛选，不是独立测试结论。</p>'
            '<table><thead><tr><th>方案</th><th>共同步数</th><th>数量误差/起点</th><th>数量误差/64窗组</th>'
            '<th>量变化相关性</th><th>价格双重约束</th><th>≥10BTC精确率/召回</th><th>≥100BTC精确率/召回</th>'
            '<th>通过初筛</th></tr></thead><tbody id=comparisonRows></tbody></table>')
    page=page.replace('<h2>首步实际梯度范数</h2>',tables+'<h2>首步实际梯度范数</h2>')
    js='''<script>(function(){let fmt=(x,n=4)=>Number.isFinite(x)?x.toFixed(n):'—',pct=x=>Number.isFinite(x)?(x*100).toFixed(2)+'%':'—';
async function aux(){let d=await(await fetch('diagnostics.json?t='+Date.now())).json(),coverage=[],seen=[],comparison=[];
for(let [lane,v] of Object.entries(d.rows)){let e=v.exposures||{};
coverage.push(row([v.label,v.training_windows,e.unique_windows_seen??'待实测',e.presentations??'—',fmt(e.epochs_equivalent,2),e.min_presentations===undefined?'—':e.min_presentations+'/'+e.max_presentations,fmt(8192/v.training_windows,2)]));
for(let [step,t] of Object.entries(v.seen)){let m=t.metrics,b=t.thresholds['100'];seen.push(row([v.label,step,fmt(m.price_usdt.rmse,2),fmt(m.quantity_btc.rmse),fmt(m.temporal_log_quantity_1_minutes.correlation),pct(b.precision),pct(b.recall)]))}
let c=d.comparison[lane];if(c){let a=c.development.thresholds['10'],b=c.development.thresholds['100'];comparison.push(row([v.label,c.step,fmt(c.quantity_rmse_ratio_to_initial),fmt(c.quantity_rmse_ratio_to_n64),fmt(c.quantity_change_correlation),c.price_guard_vs_initial_and_n64?'满足':'未满足',pct(a.precision)+' / '+pct(a.recall),pct(b.precision)+' / '+pct(b.recall),c.step===0||lane==='n64'?'起点/对照':c.exploratory_screen_pass?'是':'否']))}}
document.getElementById('coverageRows').replaceChildren(...coverage);document.getElementById('seenRows').replaceChildren(...seen);document.getElementById('comparisonRows').replaceChildren(...comparison)}
aux().catch(console.error);setInterval(()=>aux().catch(console.error),10000)})()</script>'''
    page=page.replace('</html>',js+'</html>')
    (root/'public').mkdir(exist_ok=True)
    stop=threading.Event()
    def watch():
        while not stop.is_set():
            diagnostics(root)
            stop.wait(10)
    thread=threading.Thread(target=watch,daemon=True)
    thread.start()
    try:monitor(root,page)
    finally:
        stop.set();thread.join(timeout=2);diagnostics(root)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root',type=Path)
    main(parser.parse_args().root)
