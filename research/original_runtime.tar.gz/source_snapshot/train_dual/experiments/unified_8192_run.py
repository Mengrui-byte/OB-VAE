"""From-scratch 256-minute single-posterior8192 experiments, seed42 only."""
import argparse
from datetime import datetime
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import numpy as np
import torch
from torch.utils.data import DataLoader

from model.autoencoder.unified_book_vae import UnifiedOrderBookVAE
from model.losses.unified_book import UnifiedBookLoss
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.local_quant_reconstruction import CacheWindows
from train_dual.experiments.long_worker import atomic_json,evaluate
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import atomic_save,freeze_sources,load_for_inference,seed_everything,source_hashes
from train_dual.util.data import DualNormalizer

LABELS={'ae':'确定性AE·8192','vae_1e6':'VAE·β=1e−6','vae_1e5':'VAE·β=1e−5','vae_1e4':'VAE·β=1e−4'}


def fit_training_scales(root):
    train=dataset(root,'train');indices=np.load(root/'train_indices.npy');sq=np.zeros(2);count=0;gaps=[];spreads=[];qsum=0.
    for n,index in enumerate(indices):
        raw=train[int(index)];a=raw['data'].numpy().astype(np.float64);mask=np.arange(2048)<raw['level_counts'].numpy()[...,None]
        p,q=a[...,0],a[...,1];anchor=(p[0,0,0]+p[0,1,0])/2
        v=(p-anchor)/anchor*1e4
        sq += [np.square(v[mask]).sum(),np.square(q[mask]).sum()];count+=int(mask.sum());qsum+=q[mask].sum()
        adjacent=mask[...,1:]&mask[...,:-1];d=(p[...,1:]-p[...,:-1])*np.array([-1,1])[None,:,None]
        gaps.extend((d[adjacent][::128]/.01).tolist());spreads.extend(((p[:,1,0]-p[:,0,0])/.01).tolist())
        atomic_json(root/'normalization_progress.json',dict(windows=n+1,total=len(indices)))
    scales=np.sqrt(sq/count)
    if not np.isfinite(scales).all() or (scales<=0).any():raise ValueError('Invalid training RMS')
    return dict(price_scale=float(scales[0]),quantity_scale=float(scales[1]),tick_size=.01,fit_windows=len(indices),fit_split='64 selected training windows only,2022-2024',valid_values=count,mean_quantity=float(qsum/count),median_gap_ticks=float(np.median(gaps)),median_spread_ticks=float(np.median(spreads)))


def prepare(parent):
    torch.set_num_threads(4);seed_everything(42);strict_precision();parent=parent.resolve()
    root=parent.parent/('unified8192_'+datetime.now().strftime('%Y%m%d_%H%M%S'));root.mkdir();(root/'logs').mkdir();(root/'data').mkdir()
    for name in ('train_indices.npy','val_indices.npy'):os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    old=parent.parent/'merge_global_local_256_20261026_105211'
    os.link(old/'source_profiles.npz',root/'source_profiles.npz')
    os.link(parent/'reference/step512_evaluation.json',root/'reference_evaluation.json')
    plan=dict(parent=str(parent),experiment='One8192-scalar Gaussian window state; price and quantity dual decoder',seed=42,
        train=['2022-01-01','2025-01-01'],development=['2025-01-01','2025-04-01'],independent_test_untouched=['2025-04-01','2025-07-01'],
        window_size=256,stride=256,input_shape=[1,256,2,2048,2],matrix_shape=[64,128],latent_scalars=8192,fit_windows=64,evaluation_windows=16,seen_windows=8,
        labels=LABELS,lanes={'ae':dict(beta=0.,sample=False),'vae_1e6':dict(beta=1e-6,sample=True),'vae_1e5':dict(beta=1e-5,sample=True),'vae_1e4':dict(beta=1e-4,sample=True)},
        default_variant='ae',batch_size=1,accumulation=4,steps=2048,checkpoints=[32,128,512,1024,2048],max_seconds=43200,lr=.0001,weight_decay=0.,kl_warmup_steps=256,
        objective=dict(price_weight=1.,quantity_weight=1.,log_weight=1.,pair_weight=.25,topk=16),
        loss_delta='Price Huber in train-RMS normalized coordinates (including Top-k price), not tick-scaled training objective. Raw USDT and tick RMSE are both reported. Other terms follow proposed same-index Huber+log quantity+Top-k+single summed KL.',
        initialization='Fresh seed42 identical model weights across all4 lanes; no old-model weights, no distillation or encoder freezing. Training-only gap/spread/quantity bias calibration; output weights N(0,.001). Logvar weight0,bias-4,clamp[-12,8]. Preflight is discarded; fresh initial.pt is used for every lane.',
        architecture_details='4spatial down blocks, bid/ask8head Cross, ordered4096->512 LN+Linear+GELU;4frame patches2048->256;2PreLN Transformers8heads FFN1024 dropout0;mu/logvar256->128. Two independent128->512->1024 temporal expanders, one temporal residual each. Spatial nearest2x+conv+oneResidual with dilations2,2,2,1. Spatial side/rank/time32 code concatenated with16seed channels then1x1 projected. Predicted-price geometry34->32->32 conditions quantity at seed and all4scales. No encoder skips.',
        precision='FP32 fixed features/LoG; BF16 neural training with spatial activation checkpointing; FP32 evaluation/cumsum, FP64 inverse prices; TF32 disabled',
        no_future_returns=True,no_quantization=True,selection='All declared endpoints, fixed seed42. Reused2025Q1 is development, not pristine out-of-sample.2026 and independent test are not used. This64window run is architecture screening, not full-data training.',
        hypothesis='A single learned8192-scalar window posterior can preserve useful price/quantity reconstruction; compare deterministic capacity with actual sampling and increasingly strong summed-KL constraints.',
        reference='Frozen former full256minute Cross model at512steps, evaluated on identical development windows; its larger latent and different historical optimization budget are disclosed. AE is the matched8192 control.',
        viewer_route='unified8192',viewer_default_model=2,viewer_source_label='旧256分钟大latent参考·512步',
        viewer_description='完整256分钟重建。新模型均为从头训练的单Gaussian窗口瓶颈[64,128]=8192标量，价格与挂量共用同一Z，无Encoder跳接。AE和三档KL对照，推理均用μ。旧Cross大latent仅为外部参考，训练成本和容量不同。64个2022–2024训练窗、16个2025Q1开发窗、seed42，开发数据已重复用于研究；非最终独立测试。2026未参与。',
        viewer_step_note='唯一64×128整窗瓶颈，确定性μ重建，完整256分钟。')
    atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='fitting_training_normalization'))
    scales=fit_training_scales(root);plan['normalization']=scales;atomic_json(root/'normalization.json',scales)
    model_config=dict(levels=2048,quantity_scale=scales['quantity_scale'],activation_checkpointing=True)
    seed_everything(42);model=UnifiedOrderBookVAE(**model_config)
    def invsp(v):return math.log(math.expm1(v)) if v<20 else v
    with torch.no_grad():
        model.price_decoder.gap.bias.fill_(invsp(max(scales['median_gap_ticks']-1,.001)))
        model.price_decoder.mid_spread[-1].bias[1]=invsp(max(scales['median_spread_ticks']-1,.001))
        model.volume_decoder.quantity.bias.fill_(invsp(max(scales['mean_quantity']/scales['quantity_scale'],.001)))
    config=dict(normalization=dict(tick_size=scales['tick_size'],price_scale=scales['price_scale']),arguments=dict(window_size=256,stride=256,levels=2048,batch_size=1,accumulation_steps=4,precision='bf16'),loss=plan['objective'])
    atomic_save(dict(format_version=1,model=model.state_dict(),unified_vae_config=model_config,config=config,step=0),root/'initial.pt')
    plan['model_config']=model_config;plan['parameters']=sum(p.numel() for p in model.parameters());atomic_json(root/'plan.json',plan)
    freeze_sources(root/'source_snapshot');atomic_json(root/'status.json',dict(state='prepared'))
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(parent.parents[1])
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.unified_8192_run "{remote}"\n')
    Path('/tmp/unified8192_path').write_text(str(root));print(root,flush=True)


def call(model,b,sample):return model(*[b[k] for k in ('price','volume','mask','tick_norm','times')],sample=sample)


def group_gradients(model):
    modules=dict(encoder=model.encoder,posterior_mu=model.encoder.mu,posterior_logvar=model.encoder.logvar,price_decoder=model.price_decoder,volume_decoder=model.volume_decoder)
    return {k:sum(float(p.grad.detach().float().square().sum()) for p in m.parameters() if p.grad is not None)**.5 for k,m in modules.items()}


def preflight(root):
    model,norm=load_for_inference(root/'initial.pt','cuda:0');plan=json.loads((root/'plan.json').read_text());model.train()
    raw=dataset(root,'train')[int(np.load(root/'train_indices.npy')[0])];raw={k:v.unsqueeze(0) for k,v in raw.items()};b=norm.prepare(raw,'cuda:0')
    seen=[];hooks=[m.register_forward_pre_hook(lambda m,args:seen.append(args[0])) for m in (model.price_decoder,model.volume_decoder)]
    with torch.autocast('cuda',dtype=torch.bfloat16):out=call(model,b,True)
    for h in hooks:h.remove()
    assert seen[0] is seen[1] and seen[0] is out['z']
    assert list(raw['data'].shape)==[1,256,2,2048,2] and list(out['z'].shape)==[1,64,128]
    assert list(out['price_norm'].shape)==[1,256,2,2048]
    values=UnifiedBookLoss(plan['normalization']['quantity_scale'],**plan['objective'])(out,b,beta=1e-5)
    values['loss'].backward();grads=group_gradients(model)
    if any(not np.isfinite(v) or v<=0 for v in grads.values()):raise RuntimeError(f'Missing real full-window gradients:{grads}')
    # Decode-only replay at matched BF16 precision, with no original book features.
    model.eval()
    with torch.inference_mode(),torch.autocast('cuda',dtype=torch.bfloat16):
        replay=model.decode(out['z'],b['mask'],b['tick_norm'],b['times'])
        for key in ('price_norm','volume'):torch.testing.assert_close(replay[key],out[key],rtol=0,atol=0)
    sign=out['price_norm'].new_tensor([-1,1])[None,None,:,None];adjacent=b['mask'][...,1:]&b['mask'][...,:-1]
    gaps=(out['price_norm'][...,1:]-out['price_norm'][...,:-1])*sign
    assert bool((gaps[adjacent]>0).all()) and bool((out['volume'][b['mask']]>=0).all())
    atomic_json(root/'preflight.json',dict(passed=True,raw_input=list(raw['data'].shape),latent=list(out['z'].shape),price_output=list(out['price_norm'].shape),quantity_output=list(out['volume'].shape),shared_z_object=True,decode_only_replay_exact=True,gradients=grads,loss={k:float(v.detach()) for k,v in values.items()},peak_allocated_gib=torch.cuda.max_memory_allocated()/2**30))
    del model,out,replay,values;torch.cuda.empty_cache()


def detailed_evaluate(model,norm,val,windows,device):
    result=evaluate(model,norm,val,windows,device);model.eval()
    result['price_rmse_ticks']=result['metrics']['price_usdt']['rmse']/norm.tick_size
    indices=np.unique(np.linspace(0,len(val)-1,windows,dtype=int));kl=[];mus=[];var=[]
    with torch.inference_mode():
        for index in indices:
            b=norm.prepare({k:v.unsqueeze(0) for k,v in val[int(index)].items()},device)
            mu,lv=model.encoder(*[b[k] for k in ('price','volume','mask','tick_norm','times')])
            kl.append(float(.5*(mu.square()+lv.exp()-1-lv).sum()))
            mus.append(mu.flatten().cpu());var.append(float(lv.exp().mean()))
    means=torch.stack(mus)
    result['posterior']=dict(kl_per_window_mean=float(np.mean(kl)),kl_per_window_min=float(np.min(kl)),kl_per_window_max=float(np.max(kl)),mean_variance=float(np.mean(var)),mean_std_across_windows=float(means.std(0).mean()),active_coordinates_variance_gt_001=int((means.var(0)>.01).sum()),active_dimension_note='Descriptive coordinate-wise variance over16 development windows, not intrinsic dimension or independent bits.')
    return result


def write_profiles(root,folder,step,model,norm,original,indices):
    truth=[];pred=[];mask=[];times=[];latent=[];positions=np.unique(np.linspace(0,len(indices)-1,3,dtype=int));model.eval()
    with torch.inference_mode():
        for pos in positions:
            idx=int(indices[pos]);raw={k:v.unsqueeze(0) for k,v in original[idx].items()};b=norm.prepare(raw,'cuda:0');out=call(model,b,False)
            truth.append(raw['data'][0].numpy());pred.append(np.stack((norm.inverse_price(out['price_norm'],b)[0].cpu().numpy(),out['volume'][0].cpu().numpy()),-1));mask.append(b['mask'][0].cpu().numpy());latent.append(out['z'][0].cpu().numpy())
            start=int(original.base.starts[idx]);times.append(original.base.times[start:start+256])
        # One actual sampled reconstruction as well as posterior-mean quality.
        with torch.random.fork_rng(devices=[0]):
            torch.manual_seed(42000+step);sample=call(model,b,True)
            sampled=dict(price_rmse_ticks=float((((sample['price_norm']-b['price'])/b['tick_norm'][:,None,None,None])[b['mask']].square().mean()).sqrt()),quantity_rmse_btc=float(((sample['volume']-b['volume'])[b['mask']].square().mean()).sqrt()))
    temp=folder/f'step{step}_profiles.tmp'
    with temp.open('wb') as f:np.savez_compressed(f,truth=np.stack(truth),prediction=np.stack(pred),mask=np.stack(mask),time=np.stack(times),indices=indices[positions])
    temp.replace(folder/f'step{step}_profiles.npz')
    np.savez_compressed(folder/f'step{step}_latents.npz',mu=np.stack(latent),indices=indices[positions])
    atomic_json(folder/f'step{step}_sampled_example.json',dict(result=sampled,development_window_index=idx,samples=1,seed=42000+step,note='One reproducible stochastic draw on last of3 preview windows; descriptive, not a selection metric.'))


def worker(root,lane):
    torch.set_num_threads(4);seed_everything(42);strict_precision();started=time.monotonic();plan=json.loads((root/'plan.json').read_text());folder=root/lane;folder.mkdir(exist_ok=True)
    initial=torch.load(root/'initial.pt',map_location='cpu',weights_only=False);model,norm=load_for_inference(root/'initial.pt','cuda:0');case=plan['lanes'][lane]
    train_original=dataset(root,'train');val_original=dataset(root,'val');ti=np.load(root/'train_indices.npy');vi=np.load(root/'val_indices.npy');train=CacheWindows(train_original,ti);val=CacheWindows(val_original,vi)
    criterion=UnifiedBookLoss(plan['normalization']['quantity_scale'],**plan['objective'])
    opt=torch.optim.AdamW(model.parameters(),lr=plan['lr'],weight_decay=plan['weight_decay'])
    loader=DataLoader(train,batch_size=1,shuffle=True,num_workers=2,persistent_workers=True,pin_memory=True,generator=torch.Generator().manual_seed(42));iterator=iter(loader)
    hashes=source_hashes()
    def progress(step,**values):
        row=dict(phase='end_to_end',step=step,total=plan['steps'],elapsed_seconds=time.monotonic()-started,reserved_gib=torch.cuda.memory_reserved()/2**30,**values);atomic_json(folder/'progress.json',row)
        with (folder/'progress.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
        print(json.dumps(row),flush=True)
    def save(path,step):
        atomic_save(dict(format_version=1,model=model.state_dict(),unified_vae_config=plan['model_config'],config=initial['config'],step=step,lane=lane,beta=case['beta'],training_sample=case['sample'],optimizer=opt.state_dict(),source_hashes=hashes,torch_rng_state=torch.get_rng_state(),cuda_rng_state=torch.cuda.get_rng_state_all(),sampler_generator_state=loader.generator.get_state(),epoch_boundary=step*plan['accumulation']%len(train)==0),path)
    try:
        atomic_json(folder/'status.json',dict(state='initial_validation'));dev=detailed_evaluate(model,norm,val,len(val),'cuda:0');atomic_json(folder/'initial_evaluation.json',dict(result=dev))
        atomic_json(folder/'trainable_modules.json',{k:sum(p.numel() for p in m.parameters() if p.requires_grad) for k,m in [('encoder',model.encoder),('price_decoder',model.price_decoder),('volume_decoder',model.volume_decoder)]})
        atomic_json(folder/'status.json',dict(state='training'))
        for step in range(1,plan['steps']+1):
            if time.monotonic()-started>plan['max_seconds']:raise TimeoutError('Declared12hour worker ceiling')
            model.train();opt.zero_grad(set_to_none=True);record={};beta=case['beta']*min(step/plan['kl_warmup_steps'],1.)
            for micro in range(plan['accumulation']):
                try:raw=next(iterator)
                except StopIteration:iterator=iter(loader);raw=next(iterator)
                assert list(raw['data'].shape)==[1,256,2,2048,2];b=norm.prepare(raw,'cuda:0')
                with torch.autocast('cuda',dtype=torch.bfloat16):out=call(model,b,case['sample'])
                values=criterion(out,b,beta)
                if not bool(torch.isfinite(values['loss'])):raise FloatingPointError('Nonfinite objective')
                (values['loss']/plan['accumulation']).backward()
                for k,v in values.items():record[k]=record.get(k,0.)+float(v.detach())/plan['accumulation']
                if step==1 and micro==0:atomic_json(folder/'actual_shape_contract.json',dict(raw_input=list(raw['data'].shape),matrix=list(out['z'].shape),posterior_mu=list(out['mu'].shape),posterior_logvar=list(out['logvar'].shape),price_output=list(out['price_norm'].shape),quantity_output=list(out['volume'].shape),posterior_count=1,latent_draws=1 if case['sample'] else 0,encoder_skip=False))
            if step==1:
                grads=group_gradients(model);atomic_json(folder/'first_step_gradient_norms.json',grads)
                required={k:v for k,v in grads.items() if case['sample'] or k!='posterior_logvar'}
                if any(not np.isfinite(v) or v<=0 for v in required.values()):raise RuntimeError(f'Missing trainable gradients:{grads}')
            grad=torch.nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True);opt.step()
            if step==1 or step%8==0:progress(step,beta=beta,gradient_norm=float(grad),**record)
            if step in plan['checkpoints']:
                save(folder/f'step{step}.pt',step);save(folder/'latest.pt',step)
                dev=detailed_evaluate(model,norm,val,len(val),'cuda:0');atomic_json(folder/f'step{step}_evaluation.json',dict(result=dev))
                seen=evaluate(model,norm,train,plan['seen_windows'],'cuda:0');atomic_json(folder/f'step{step}_seen_evaluation.json',dict(result=seen));write_profiles(root,folder,step,model,norm,val_original,vi)
        save(folder/'final.pt',step);atomic_json(folder/'final_evaluation.json',dict(result=dev));atomic_json(folder/'status.json',dict(state='complete',step=step,elapsed_seconds=time.monotonic()-started))
    except BaseException as error:atomic_json(folder/'status.json',dict(state='failed',error=repr(error)));raise


def campaign(root):
    torch.set_num_threads(4);seed_everything(42);strict_precision();plan=json.loads((root/'plan.json').read_text());started=time.monotonic();children=[]
    def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        atomic_json(root/'status.json',dict(state='preflight'));preflight(root)
        for gpu,lane in zip((2,3,4,5),plan['lanes']):
            env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),CUDA_DEVICE_ORDER='PCI_BUS_ID',PYTHONPATH=str(root/'source_snapshot'))
            with (root/'logs'/f'{lane}.log').open('ab',buffering=0) as log:p=subprocess.Popen([sys.executable,'-u','-m','train_dual.experiments.unified_8192_run',str(root),'--lane',lane],cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            children.append((lane,gpu,p))
        atomic_json(root/'status.json',dict(state='running',children=[dict(lane=l,gpu=g,pid=p.pid) for l,g,p in children]))
        while any(p.poll() is None for _,_,p in children):
            if time.monotonic()-started>plan['max_seconds']:raise TimeoutError('Campaign12hour ceiling')
            time.sleep(5)
        failures={l:p.returncode for l,_,p in children if p.returncode!=0};atomic_json(root/'status.json',dict(state='partial_failure' if failures else 'complete',failures=failures,elapsed_seconds=time.monotonic()-started))
    except BaseException as error:atomic_json(root/'status.json',dict(state='failed',error=repr(error)));raise
    finally:
        for _,_,p in children:
            if p.poll() is None:os.killpg(p.pid,signal.SIGTERM)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--lane');a=p.parse_args()
    if a.prepare:prepare(a.root)
    elif a.lane:worker(a.root,a.lane)
    else:campaign(a.root)
