"""Layerwise gradient flow, objective conflict, precision and descent diagnostics."""
import json
import math
from pathlib import Path
import statistics
import torch
from torch.nn import functional as F
from model.losses.controlled_book import ControlledBookLoss
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.unified_8192_run import call
from train_dual.util.checkpoint import load_for_inference,seed_everything
from train_dual.experiments.window_state_pilot import strict_precision


def flatnorm(gs):return math.sqrt(sum(float(g.double().square().sum()) for g in gs if g is not None))
def dot(gs,hs):return sum(float((g.double()*h.double()).sum()) for g,h in zip(gs,hs) if g is not None and h is not None)
def cos(gs,hs):
 a,b=flatnorm(gs),flatnorm(hs)
 return dot(gs,hs)/(a*b) if a*b>1e-30 else None

def add(gs,hs):return [(g if h is None else h if g is None else g+h) for g,h in zip(gs,hs)]
def mean_grad(groups):
 result=[]
 for values in zip(*groups):
  valid=[x for x in values if x is not None];result.append(sum(valid)/len(groups) if valid else None)
 return result

def stat(gs,params):
 return dict(l2=flatnorm(gs),rms=flatnorm(gs)/math.sqrt(sum(p.numel() for p,g in zip(params,gs) if g is not None) or 1),nonfinite=sum(int((~torch.isfinite(g)).sum()) for g in gs if g is not None),zero_fraction=sum(int((g==0).sum()) for g in gs if g is not None)/max(1,sum(g.numel() for g in gs if g is not None)))

def price_component(out,b):
 mask=b['mask'];p=F.huber_loss(out['price_norm'].float(),b['price'].float(),reduction='none');idx=b['volume'].masked_fill(~mask,-torch.inf).topk(16,-1).indices;chosen=mask.gather(-1,idx)
 return (p*mask).sum()/mask.sum()+.25*(p.gather(-1,idx)*chosen).sum()/chosen.sum()


def grouped_rows(names,params,gp,gq):
 groups={}
 for i,name in enumerate(names):groups.setdefault(name.rsplit('.',1)[0],[]).append(i)
 result=[]
 for name,idx in groups.items():
  a=[gp[i] for i in idx];b=[gq[i] for i in idx];g=add(a,b);ps=[params[i].detach().cpu() for i in idx];n=sum(p.numel() for p in ps);pn=flatnorm(ps);gn=flatnorm(g)
  result.append(dict(layer=name,parameters=n,weight_l2=pn,price_grad_l2=flatnorm(a),quantity_grad_l2=flatnorm(b),total_grad_l2=gn,total_grad_rms=gn/math.sqrt(n),grad_to_weight=gn/max(pn,1e-30),price_quantity_cosine=cos(a,b),nonfinite=stat(g,ps)['nonfinite'],zero_fraction=stat(g,ps)['zero_fraction'],expected_inactive=name.startswith('encoder.logvar')))
 return result


def audit(root):
 torch.set_num_threads(4);seed_everything(42);strict_precision();folder=root/'gradient_audit';folder.mkdir();plan=json.loads((root/'plan.json').read_text());raw=torch.load(root/'small_train.pt',map_location='cpu',weights_only=False);model,norm=load_for_inference(root/'initial.pt','cuda:0');model.train()
 # Disable activation checkpoint recomputation only for instrumentation.
 model.encoder.activation_checkpointing=False;model.price_decoder.spatial.activation_checkpointing=False;model.volume_decoder.spatial.activation_checkpointing=False
 names,params=zip(*model.named_parameters());params=list(params);payload=torch.load(root/'initial.pt',map_location='cpu',weights_only=False)
 criteria={k:ControlledBookLoss(plan['normalization']['quantity_scale'],mode=k) for k in ['baseline','quantity_mse','spatial_difference','temporal_difference']}
 batches=[norm.prepare({k:v[i:i+1] for k,v in raw.items()},'cuda:0') for i in range(raw['data'].shape[0])]
 captures={};hooks=[];capture=[False]
 targets=['encoder.input_proj',*[f'encoder.down.{i}' for i in range(4)],*[f'encoder.spatial.{i}' for i in range(4)],'encoder.cross','encoder.region','encoder.frame','encoder.patch','encoder.temporal.layers.0','encoder.temporal.layers.1','encoder.mu','encoder.logvar']
 for prefix in ['price_decoder','volume_decoder']:
  targets += [prefix+'.temporal.mlp.0',prefix+'.temporal.mlp.2',prefix+'.temporal.refine',prefix+'.spatial.seed',prefix+'.spatial.proj',*[prefix+f'.spatial.up.{i}' for i in range(4)]]
 targets += ['price_decoder.mid_spread.2','price_decoder.gap','volume_decoder.geometry.0','volume_decoder.geometry.2','volume_decoder.quantity']
 def make_hook(name):
  def hook(module,args,value):
   if not capture[0]:return
   if isinstance(value,tuple):value=value[0]
   if not isinstance(value,torch.Tensor) or not value.requires_grad:return
   value.retain_grad();captures.setdefault(name,[]).append(value)
  return hook
 for name,module in model.named_modules():
  if name in targets:hooks.append(module.register_forward_hook(make_hook(name)))
 def grads(loss):return [g.detach().cpu() if g is not None else None for g in torch.autograd.grad(loss,params,retain_graph=True,allow_unused=True)]
 gps=[];gqs=[];windows=[];variant_stats={};activation_rows=[]
 for i,b in enumerate(batches):
  capture[0]=i==0;model.zero_grad(set_to_none=True);out=call(model,b,False);capture[0]=False;lp=price_component(out,b);values=criteria['baseline'](out,b);lq=values['loss']-lp
  gp,gq=grads(lp),grads(lq);gps.append(gp);gqs.append(gq)
  zp=torch.autograd.grad(lp,out['z'],retain_graph=True)[0].detach().cpu();zq=torch.autograd.grad(lq,out['z'],retain_graph=True)[0].detach().cpu()
  windows.append(dict(position=i,loss=float(values['loss'].detach()),price_objective=float(lp.detach()),quantity_objective=float(lq.detach()),price_grad=stat(gp,params),quantity_grad=stat(gq,params),cosine=cos(gp,gq),z_price_grad_l2=float(zp.norm()),z_quantity_grad_l2=float(zq.norm()),z_cosine=cos([zp],[zq])))
  if i==0:
   for mode,criterion in criteria.items():
    vv=criterion(out,b);g=grads(vv['loss']-lp);variant_stats[mode]=dict(quantity_objective=float((vv['loss']-lp).detach()),quantity_grad_l2=flatnorm(g),encoder_quantity_grad_l2=flatnorm([v for n,v in zip(names,g) if n.startswith('encoder.')]),price_quantity_cosine=cos(gp,g),total_grad_l2=flatnorm(add(gp,g)))
   for group in captures.values():
    for v in group:v.grad=None
   values['loss'].backward()
   for name,ts in captures.items():
    for j,t in enumerate(ts):
     g=t.grad;activation_rows.append(dict(layer=name,call=j,shape=list(t.shape),activation_rms=float(t.detach().float().square().mean().sqrt()),gradient_rms=float(g.detach().float().square().mean().sqrt()) if g is not None else None,gradient_l2=float(g.detach().float().norm()) if g is not None else None,nonfinite=int((~torch.isfinite(g)).sum()) if g is not None else None))
   logits=captures['volume_decoder.quantity'][0].detach().float();derivative=logits.sigmoid();e=((out['volume']-b['volume'])/plan['normalization']['quantity_scale']).abs();idx=b['volume'].topk(16,-1).indices
   gates=dict(logit_min=float(logits.min()),logit_max=float(logits.max()),softplus_derivative_mean=float(derivative.mean()),softplus_derivative_lt_1e4_fraction=float((derivative<1e-4).float().mean()),huber_linear_all_fraction=float((e[b['mask']]>1).float().mean()),huber_linear_top16_fraction=float((e.gather(-1,idx)>1).float().mean()))
   atomic_json(folder/'activation_gradients.json',activation_rows)
   atomic_json(folder/'first_window_variants.json',variant_stats)
  atomic_json(folder/'window_progress.json',dict(completed=i+1,total=len(batches)))
  del out,lp,lq,values;captures.clear();model.zero_grad(set_to_none=True);torch.cuda.empty_cache()
 for h in hooks:h.remove()
 gp,gq=mean_grad(gps),mean_grad(gqs);total=add(gp,gq);gn=flatnorm(total);clip=min(1.,1./(gn+1e-6));layers=grouped_rows(names,params,gp,gq)
 for row in layers:row['clipped_grad_l2']=row['total_grad_l2']*clip
 atomic_json(folder/'layer_gradients.json',layers)
 module_stats={}
 for prefix in ['encoder','encoder.mu','encoder.frame','encoder.patch','price_decoder','volume_decoder','volume_decoder.temporal','volume_decoder.spatial','volume_decoder.geometry','volume_decoder.quantity']:
  ii=[i for i,n in enumerate(names) if n.startswith(prefix+'.')];a=[gp[i] for i in ii];b=[gq[i] for i in ii];module_stats[prefix]=dict(price_l2=flatnorm(a),quantity_l2=flatnorm(b),total_l2=flatnorm(add(a,b)),price_quantity_cosine=cos(a,b))
 # Matched FP32 / BF16 gradient diagnostic, fixed first window.
 with torch.autocast('cuda',dtype=torch.bfloat16):out=call(model,batches[0],False)
 value=criteria['baseline'](out,batches[0]);bg=grads(value['loss']);fp=add(gps[0],gqs[0]);precision=dict(fp32_l2=flatnorm(fp),bf16_l2=flatnorm(bg),cosine=cos(fp,bg),difference_relative_l2=flatnorm([None if a is None and b is None else (torch.zeros_like(b) if a is None else a)-(torch.zeros_like(a) if b is None else b) for a,b in zip(fp,bg)])/max(flatnorm(fp),1e-30))
 del out,value;model.zero_grad(set_to_none=True);torch.cuda.empty_cache()
 theta=[p.detach().clone() for p in params]
 def restore():
  with torch.no_grad():
   for p,v in zip(params,theta):p.copy_(v)
 def losses():
  sums=dict(total=0.,price=0.,quantity=0.)
  with torch.no_grad():
   for b in batches:
    o=call(model,b,False);p=price_component(o,b);v=criteria['baseline'](o,b)['loss'];sums['total']+=float(v)/len(batches);sums['price']+=float(p)/len(batches);sums['quantity']+=float(v-p)/len(batches)
  return sums
 before=losses();fd=[]
 for eps in [.001,.01]:
  ends={}
  for sign in [-1,1]:
   restore()
   with torch.no_grad():
    for p,g in zip(params,total):
     if g is not None:p.add_(g.to(p.device),alpha=sign*eps/max(gn,1e-30))
   ends[str(sign)]=losses()
  derivative=(ends['1']['total']-ends['-1']['total'])/(2*eps);fd.append(dict(epsilon_parameter_l2=eps,predicted_derivative=gn,central_finite_difference=derivative,relative_error=abs(derivative-gn)/max(gn,1e-30),negative_gradient_losses=ends['-1'],positive_gradient_losses=ends['1']))
  print('finite_difference',fd[-1],flush=True)
 restore();adam={}
 for label,warm in [('restored_adam',True),('fresh_adam',False)]:
  restore();optimizer=torch.optim.AdamW(model.parameters(),lr=1e-4,weight_decay=0.)
  if warm:optimizer.load_state_dict(payload['optimizer'])
  optimizer.zero_grad(set_to_none=True)
  for p,g in zip(params,total):p.grad=g.to(p.device).clone() if g is not None else None
  torch.nn.utils.clip_grad_norm_(params,1.,error_if_nonfinite=True);optimizer.step();delta=[(p.detach()-v).cpu() for p,v in zip(params,theta)]
  module_updates={}
  for prefix in ['encoder','price_decoder','volume_decoder']:
   ii=[i for i,n in enumerate(names) if n.startswith(prefix+'.')];ds=[delta[i] for i in ii];ps=[theta[i].detach().cpu() for i in ii];module_updates[prefix]=dict(update_l2=flatnorm(ds),relative_update_l2=flatnorm(ds)/max(flatnorm(ps),1e-30),cosine_with_negative_quantity_gradient=-cos(ds,[gq[i] for i in ii]) if cos(ds,[gq[i] for i in ii]) is not None else None)
  adam[label]=dict(losses_after=losses(),delta_l2=flatnorm(delta),cosine_with_negative_total_gradient=-cos(delta,total),cosine_with_negative_quantity_gradient=-cos(delta,gq),module_updates=module_updates)
  del optimizer;model.zero_grad(set_to_none=True)
 restore()
 observed_logs={}
 for relative in ['checkpoints/unified8192_20261026_112402/ae','recons/loss_control_20261026_120833/baseline','recons/loss_control_20261026_120833/quantity_mse']:
  f=root.parents[1]/relative/'progress.jsonl'
  if not f.exists():continue
  rows=[json.loads(s) for s in f.read_text().splitlines() if s.strip()];v=[x['gradient_norm'] for x in rows if 'gradient_norm' in x]
  observed_logs[relative]=dict(recorded_updates=len(v),clipped_fraction=sum(x>1 for x in v)/len(v),median_preclip_l2=statistics.median(v),median_clip_coefficient=statistics.median(min(1.,1./(x+1e-6)) for x in v))
 summary=dict(checkpoint='OriginalAE2048',windows=windows,effective_batch4=dict(price_grad_l2=flatnorm(gp),quantity_grad_l2=flatnorm(gq),total_grad_l2=gn,price_quantity_cosine=cos(gp,gq),global_clip_coefficient=clip,price_task_derivative_under_negative_total=-dot(gp,total)/max(gn,1e-30),quantity_task_derivative_under_negative_total=-dot(gq,total)/max(gn,1e-30),price_microbatch_alignment=flatnorm(gp)/(sum(flatnorm(g) for g in gps)/len(gps)),quantity_microbatch_alignment=flatnorm(gq)/(sum(flatnorm(g) for g in gqs)/len(gqs))),modules=module_stats,precision=precision,output_gate=gates,finite_difference=fd,base_losses=before,adam_one_step=adam,training_clipping_logs=observed_logs,expected_inactive='encoder.logvar: deterministicAE andbeta0. This is expected, not broken backprop.',scope='4fixed trainingwindows, full256frames/2048levels, sameAE2048weights. Layer/task audit FP32; activationcheckpointing disabled only for audit, compared withBF16. Finite differences on normalized fullparameter-gradient direction; optimizer intervention on same fixed4window mean. One-step diagnostics do not establish long-run improvements.',peak_allocated_gib=torch.cuda.max_memory_allocated()/2**30)
 atomic_json(folder/'summary.json',summary);atomic_json(folder/'status.json',dict(state='complete'));print('gradient_audit complete',json.dumps(summary['effective_batch4']),flush=True)
