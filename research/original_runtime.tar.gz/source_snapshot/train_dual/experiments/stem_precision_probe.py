"""Small-quantity sensitivity of actual GPU input projection, no training."""
import argparse
import json
import os
from pathlib import Path
import time

import numpy as np
import torch

from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.price_safe_readout import file_hash
from train_dual.util.checkpoint import freeze_sources,load_for_inference
from train_dual.util.phase_training import tensor_digest

DELTAS=(.001,.01,1.,100.)


def prepare(goal):
    parent=goal/'round_007_quantity_factorial';root=goal/'stem_precision_probe_20261028';root.mkdir();(root/'data').mkdir();(root/'logs').mkdir()
    for name in ['source.pt','seen_indices.npy','train_indices.npy']:os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    old=json.loads((parent/'plan.json').read_text());p={k:old[k] for k in ['train','development','window_size','stride','input_shape','latent_shape','output_shape']}
    p.update(source_sha256=file_hash(root/'source.pt'),training_indices=np.load(root/'seen_indices.npy').tolist(),
        scope='Eight previously used full256minute training windows; fixed first frame, two valid small-quantity positions per side. Only feature extractor and firstConv are evaluated, not a shortened-window model. No latent/whole-model reconstruction claims.',
        deltas_BTC=list(DELTAS),site_policy='Per side, eligible ranks96..1951 with0<q<.01; choose deterministic one-third/two-thirds positions. Change only one quantity at a time.',
        numerical_policy='Actual A6000 FP32 and BF16-autocast Conv1d; fixed feature extractor explicitly FP32. TF32off, deterministic cuDNN. Source weights frozen; mask/price fixed.',
        batch_scope='First-frame submodule batch2sides; numerical equality for this probe is not a full production-batch training comparison.',
        neural_full_model_forwards=0,optimizer_updates=0,training_launched=False)
    assert set(p['training_indices'])<=set(np.load(root/'train_indices.npy').tolist())
    atomic_json(root/'plan.json',p);atomic_json(root/'status.json',dict(state='prepared_GPU_submodule_only'));freeze_sources(root/'source_snapshot')
    project=Path(__file__).resolve().parents[2];remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 CUDA_DEVICE_ORDER=PCI_BUS_ID\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.stem_precision_probe "{remote}" --run >> "{remote}/logs/run.log" 2>&1\n')
    print(root.resolve(),flush=True)


def run(root):
    torch.set_num_threads(2);begin=time.monotonic();p=json.loads((root/'plan.json').read_text());assert file_hash(root/'source.pt')==p['source_sha256']
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False;torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
    model,norm=load_for_inference(root/'source.pt','cpu');model.eval().requires_grad_(False);before=tensor_digest(model)
    assert model.encoder.__class__.__name__=='FrameAlignedEncoder'
    feature=model.encoder.features.to('cuda:0');stem=model.encoder.input_proj.to('cuda:0');data=dataset(root,'train');records=[]
    def project(x,bf):
        with torch.autocast('cuda',dtype=torch.bfloat16,enabled=bf):return stem(x).float()
    atomic_json(root/'status.json',dict(state='running_GPU_submodule_only',pid=os.getpid()))
    with torch.inference_mode():
        for number,index in enumerate(p['training_indices']):
            raw={k:v.unsqueeze(0) for k,v in data[index].items()};offset=int(data.base.starts[index]);times=data.base.times[offset:offset+256]
            assert list(raw['data'].shape)==[1,256,2,2048,2] and bool(np.all(np.diff(times//60000000)==1))
            b=norm.prepare(raw,'cpu');price=b['price'][:,:1].cuda();q=b['volume'][:,:1].cuda();mask=b['mask'][:,:1].cuda();tick=b['tick_norm'].cuda()
            f0=feature(price,q,mask,tick);h32=project(f0,False);hb=project(f0,True)
            assert torch.equal(h32,project(f0,False)) and torch.equal(hb,project(f0,True))
            for side in range(2):
                eligible=torch.nonzero((q[0,0,side]>0)&(q[0,0,side]<.01)&mask[0,0,side],as_tuple=False).flatten()
                eligible=eligible[(eligible>=96)&(eligible<1952)]
                assert len(eligible)>3
                chosen=eligible[[len(eligible)//3,2*len(eligible)//3]].tolist()
                for rank in chosen:
                    for change in DELTAS:
                        edited=q.clone();edited[0,0,side,rank]+=change
                        f1=feature(price,edited,mask,tick);a=project(f1,False)-h32;c=project(f1,True)-hb
                        aa=float(a.square().sum());cc=float(c.square().sum());dot=float((a*c).sum())
                        assert aa>0 and bool(torch.isfinite(a).all() and torch.isfinite(c).all())
                        quantized=project(f1,False).to(torch.bfloat16).float()-h32.to(torch.bfloat16).float()
                        records.append(dict(training_index=index,frame=0,side=side,rank_zero_based=rank,
                            quantity_before_BTC=float(q[0,0,side,rank]),delta_BTC=change,
                            FP32_changed_elements=int(torch.count_nonzero(a)),BF16_changed_elements=int(torch.count_nonzero(c)),
                            BF16_input_features_identical=bool(torch.equal(f0.to(torch.bfloat16),f1.to(torch.bfloat16))),
                            FP32_delta_norm=aa**.5,BF16_delta_norm=cc**.5,
                            delta_cosine=dot/(aa*cc)**.5 if aa*cc else None,
                            BF16_to_FP32_delta_norm_ratio=(cc/aa)**.5,
                            relative_delta_error_norm=float((a-c).square().sum())**.5/(aa**.5),
                            FP32_output_cast_BF16_changed_elements=int(torch.count_nonzero(quantized))))
            atomic_json(root/'progress.json',dict(windows=number+1,total=8,case_count=len(records),neural_full_model_forwards=0,optimizer_updates=0,elapsed_seconds=time.monotonic()-begin))
    assert tensor_digest(model)==before and file_hash(root/'source.pt')==p['source_sha256']
    summary={}
    for delta in DELTAS:
        rows=[r for r in records if r['delta_BTC']==delta];cos=[r['delta_cosine'] for r in rows if r['delta_cosine'] is not None]
        summary[str(delta)]=dict(cases=len(rows),BF16_whole_stem_unchanged=sum(r['BF16_changed_elements']==0 for r in rows),
            BF16_input_features_identical=sum(r['BF16_input_features_identical'] for r in rows),
            median_delta_cosine=float(np.median(cos)) if cos else None,
            median_relative_delta_error_norm=float(np.median([r['relative_delta_error_norm'] for r in rows])),
            median_FP32_changed_elements=float(np.median([r['FP32_changed_elements'] for r in rows])),
            median_BF16_changed_elements=float(np.median([r['BF16_changed_elements'] for r in rows])))
    output=dict(state='complete_GPU_stem_diagnostic_only',device=torch.cuda.get_device_name(0),summary=summary,records=records,
                source_encoder_type=model.encoder.__class__.__name__,source_model_unchanged=True,
                actual_original_window=[1,256,2,2048,2],submodule_frame_input=[1,1,2,2048],
                neural_full_model_forwards=0,optimizer_updates=0,new_training_started=False,elapsed_seconds=time.monotonic()-begin,
                scope=p['scope'],batch_scope=p['batch_scope'],interpretation='Numerical input-projection sensitivity only; not evidence that BF16 causes all reconstruction errors. A matched training precision ablation is required before causal claims.')
    atomic_json(root/'result.json',output);atomic_json(root/'status.json',dict(state='complete',pid=os.getpid(),elapsed_seconds=time.monotonic()-begin));print(json.dumps(summary),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('root',type=Path);parser.add_argument('--prepare',action='store_true');parser.add_argument('--run',action='store_true');args=parser.parse_args();root=args.root.resolve()
    try:
        if args.prepare:prepare(root)
        elif args.run:run(root)
        else:parser.error('Specify --prepare or --run')
    except BaseException as e:
        if args.run:atomic_json(root/'status.json',dict(state='failed',pid=os.getpid(),error=repr(e)))
        raise
