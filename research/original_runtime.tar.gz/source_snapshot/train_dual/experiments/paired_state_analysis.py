"""Post-hoc interpretation of frozen matrix codes using only their input windows."""

import argparse
from datetime import datetime
import json
from pathlib import Path
import shutil

import numpy as np

from train_dual.util.data import DualWindowDataset


FEATURES = [
    ('anchor_usdt', '起点中间价', 'USDT'),
    ('spread_bps', '平均买卖价差', 'bp'),
    ('depth_btc', '双侧总挂量', 'BTC'),
    ('imbalance', '买卖深度不平衡', ''),
    ('near_imbalance', '前10档不平衡', ''),
    ('wall_btc', '最大单档挂量', 'BTC'),
    ('large_count', '每帧≥100BTC档数', '档'),
    ('width_bps', '平均单侧价格覆盖宽度', 'bp'),
    ('volatility_bps', '窗口已实现波动', 'bp'),
    ('move_bps', '窗口首尾价格变化', 'bp'),
    ('trend_bps_min', '窗口价格线性斜率', 'bp/min'),
    ('depth_change', '窗口首尾深度变化比例', ''),
]


def extract(root, split, indices):
    start, end = ('2022-01-01', '2025-01-01') if split == 'train' else ('2025-01-01', '2025-04-01')
    ds = DualWindowDataset(asset='BTCUSDT', npz_dir=root/'data/BTCUSDT.npz', start=start, end=end,
                           levels=2048, window_size=16, stride=16)
    b = ds.base
    mapped = np.memmap(b.index_path, dtype=np.float32, mode='r', offset=b._data_offset, shape=b._shape)
    values, times, profiles, curves = [], [], [], []
    t = np.arange(16, dtype=float); tc = t-t.mean()
    for n, index in enumerate(indices):
        start = int(b.starts[int(index)])
        raw = np.array(mapped[b._source_start+start:b._source_start+start+16], dtype=np.float64)
        count = b.level_counts[start:start+16]
        mask = np.arange(2048)[None,None,:] < count[...,None]
        p = raw[...,0]; q = np.where(mask, raw[...,1], 0.)
        mid = p[:,:,0].mean(1); logmid = np.log(mid)
        side = q.sum(-1); depth = side.sum(1)
        near = q[:,:,:10].sum(-1)
        width = np.abs(np.take_along_axis(p,(count-1)[...,None],axis=-1)[...,0]-p[:,:,0])/mid[:,None]*1e4
        values.append([mid[0], np.mean((p[:,1,0]-p[:,0,0])/mid*1e4), depth.mean(),
                       np.mean((side[:,0]-side[:,1])/np.maximum(depth,1e-12)),
                       np.mean((near[:,0]-near[:,1])/np.maximum(near.sum(1),1e-12)),
                       q.max(), np.mean(((q>=100)&mask).sum((1,2))), width.mean(),
                       np.sqrt(np.square(np.diff(logmid)).sum())*1e4,
                       (logmid[-1]-logmid[0])*1e4,
                       np.sum(tc*(logmid-logmid.mean()))/np.sum(tc*tc)*1e4,
                       (depth[-1]-depth[0])/max(depth[0],1e-12)])
        times.append(b.times[start])
        # Mean quantity in 32 fixed level bands, both sides, averaged within window.
        profiles.append(q.reshape(16,2,32,64).mean((0,3)))
        curves.append(np.stack([(logmid-logmid[0])*1e4, side[:,0], side[:,1]]))
        if n%1024==0: print(json.dumps(dict(split=split,processed=n,total=len(indices))),flush=True)
    return np.asarray(values), np.asarray(times), np.asarray(profiles), np.asarray(curves)


def eta(values, labels, size=256):
    centered = values-values.mean(0)
    count = np.bincount(labels, minlength=size)
    sums = np.stack([np.bincount(labels,weights=x,minlength=size) for x in centered.T],1)
    between = (sums*sums/np.maximum(count[:,None],1)).sum(0)
    return between/np.maximum((centered*centered).sum(0),1e-30)


def association(values, labels, months, permutations=999):
    observed=eta(values,labels);rng=np.random.default_rng(42)
    null=np.array([eta(values,rng.permutation(labels)) for _ in range(permutations)])
    # Remove calendar-month means; permute labels only within the same month.
    residual=values.copy();groups=[np.flatnonzero(months==m) for m in np.unique(months)]
    for ix in groups:residual[ix]-=residual[ix].mean(0)
    within=eta(residual,labels);restricted=[]
    for _ in range(permutations):
        shuffled=labels.copy()
        for ix in groups:shuffled[ix]=rng.permutation(labels[ix])
        restricted.append(eta(residual,shuffled))
    restricted=np.asarray(restricted)
    def pack(obs,base):
        mean=base.mean(0)
        return dict(eta_squared=obs.tolist(),null_mean=mean.tolist(),
                    excess_eta_squared=((obs-mean)/np.maximum(1-mean,1e-12)).tolist(),
                    permutation_p=((1+(base>=obs).sum(0))/(len(base)+1)).tolist())
    return dict(raw=pack(observed,null),within_month=pack(within,restricted))


def group_profiles(x, labels, qprofile, curves):
    rows=[]
    for code in np.unique(labels):
        z=labels==code
        move=x[z,9]
        rows.append(dict(code=int(code),count=int(z.sum()),mean=x[z].mean(0).tolist(),
                         median=np.median(x[z],axis=0).tolist(),profile=qprofile[z].mean(0).tolist(),
                         mean_curves=curves[z].mean(0).tolist(),
                         window_move_fractions=dict(up=float((move>=5).mean()),down=float((move<=-5).mean()),
                                                    flat=float((np.abs(move)<5).mean()))))
    return sorted(rows,key=lambda r:r['count'],reverse=True)


def bh(values):
    a=np.asarray(values);order=np.argsort(a);q=np.empty_like(a)
    q[order]=np.minimum.accumulate((a[order]*len(a)/np.arange(1,len(a)+1))[::-1])[::-1]
    return np.minimum(q,1).tolist()


PAGE='''<!doctype html><html lang=zh-CN><meta charset=utf-8><title>矩阵码字与市场状态</title><script src=plotly.min.js></script><style>body{font:16px system-ui;max-width:1500px;margin:28px auto;padding:0 20px;color:#182b43}p{line-height:1.8}select{font:inherit;padding:5px}table{border-collapse:collapse;width:100%}td,th{padding:8px;border:1px solid #ddd}a{color:#2563eb}.plots{display:grid;grid-template-columns:1fr 1fr}</style><h1>当前码字在区分什么？</h1><p>冻结已有模型和码本，读取8192个训练窗口、128个2025Q1开发窗口的原始订单簿。所有指标均来自被编码的16分钟窗口，没有未来收益，也未重训模型。开发集已用于此前模型选择，不是最终独立测试。</p><p><a href=./>逐档重建</a> · <a href=pair.html>双矩阵量化结果</a> · <a href=state_analysis.json>全部数据</a></p><p>第一级是粗分类；第2—8级是逐步残差修正。类别编号没有固有经济含义，完整8级组合也不自动构成稳定状态。以下优先解释第一级。</p><p>方法 <select id=method></select> 数据 <select id=split><option value=development>开发集128窗口</option><option value=train>训练集8192窗口</option></select> 类别 <select id=code></select></p><p id=counts></p><div id=heat></div><div class=plots><div id=usage></div><div id=profile></div><div id=path></div><div id=depthPath></div></div><h2>所选类别的原始单位特征</h2><table><thead><tr><th>特征</th><th>类别均值</th><th>全部均值</th><th>训练期同码均值</th><th>单位</th></tr></thead><tbody id=features></tbody></table><h2>开发集：类别对各特征的区分程度</h2><p>η²为组间方差占比；类别多、样本少时会虚高。超出随机基线的η²扣除了相同类别频数下999次置换的期望值；负值也保留。按月检验先移除月均值，只在月内置换，排查简单的月份效应。BH q对所有方法、特征和两种检验统一校正。显著关联不等于预测能力或因果关系。</p><table><thead><tr><th>特征</th><th>原始η²</th><th>超随机η²</th><th>原始BH q</th><th>按月超随机η²</th><th>按月BH q</th><th>训练类均值预测开发特征R²</th></tr></thead><tbody id=assoc></tbody></table><p>最后一列仅检验同一码字的语义能否跨期复现：使用训练期类别均值估计开发窗口内已发生的特征；负值表示不如开发集整体均值。不是未来收益预测。数量轮廓为每64档一组的平均挂量，图中两侧分别显示。</p><script>let d;const $=x=>document.getElementById(x),f=(x,n=3)=>Number.isFinite(x)?x.toFixed(n):'—';function rows(id,a){$(id).replaceChildren(...a.map(r=>{let t=document.createElement('tr');r.forEach(x=>{let c=document.createElement('td');c.textContent=x;t.append(c)});return t}))}function plot(id,a,title){Plotly.react(id,a,{height:410,title,template:'plotly_white',margin:{t:60,b:100,l:90}},{responsive:true,displaylogo:false})}function fill(){let v=d.methods[$('method').value],s=$('split').value;let g=v[s].groups;$('code').replaceChildren(...g.map(r=>new Option(r.code+'（n='+r.count+'）',r.code)));draw()}function draw(){let v=d.methods[$('method').value],s=$('split').value,g=v[s].groups,r=g.find(x=>x.code==$('code').value),train=v.train.groups.find(x=>x.code===r.code),base=d.splits[s].mean;let supported=g.filter(x=>x.count>=(s==='train'?20:3));plot('heat',[{type:'heatmap',x:d.features.map(x=>x[1]),y:supported.map(x=>x.code+' n='+x.count),z:supported.map(x=>x.mean.map((a,j)=>(a-base[j])/Math.max(d.splits[s].std[j],1e-12))),colorscale:'RdBu',zmid:0}],'有足够样本类别的特征偏离（整体标准差单位）');plot('usage',[{type:'bar',x:v.train.groups.map(x=>x.code),y:v.train.groups.map(x=>x.count/d.splits.train.windows),name:'训练'},{type:'bar',x:v.development.groups.map(x=>x.code),y:v.development.groups.map(x=>x.count/d.splits.development.windows),name:'开发'}],'第一级类别占比');plot('profile',[0,1].map((k)=>({x:Array.from({length:32},(_,i)=>i*64+32),y:r.profile[k],name:k?'卖盘':'买盘',mode:'lines+markers'})),'类别 '+r.code+' 的原始挂量轮廓');plot('path',[{x:Array.from({length:16},(_,i)=>i),y:r.mean_curves[0],mode:'lines+markers',name:'类内平均'}],'类别 '+r.code+' 的窗口中间价路径（起点归零，bp）');plot('depthPath',[1,2].map((k)=>({x:Array.from({length:16},(_,i)=>i),y:r.mean_curves[k],mode:'lines+markers',name:k===1?'买盘BTC':'卖盘BTC'})),'类别 '+r.code+' 的双侧深度演变');rows('features',d.features.map((x,j)=>[x[1],f(r.mean[j]),f(base[j]),train?f(train.mean[j]):'—',x[2]]));let a=v.development.association;rows('assoc',d.features.map((x,j)=>[x[1],f(a.raw.eta_squared[j]),f(a.raw.excess_eta_squared[j]),f(a.raw.bh_q[j]),f(a.within_month.excess_eta_squared[j]),f(a.within_month.bh_q[j]),f(v.train_to_development_r2[j])]));$('counts').textContent='训练使用 '+v.train.groups.length+' 类；开发使用 '+v.development.groups.length+' 类；占比总变差距离 '+f(v.total_variation)+'。当前选中类别样本数 '+r.count+'；窗口首尾变化：上涨≥5bp '+f(r.window_move_fractions.up*100,1)+'%，下跌≥5bp '+f(r.window_move_fractions.down*100,1)+'%，其余 '+f(r.window_move_fractions.flat*100,1)+'%。小样本类别只作展示，不赋予确定状态名称。'}fetch('state_analysis.json').then(x=>x.json()).then(x=>{d=x;$('method').replaceChildren(...Object.keys(d.methods).map(k=>new Option(k,k)));fill()});$('method').onchange=fill;$('split').onchange=fill;$('code').onchange=draw;</script></html>'''


def main(root):
    root=root.resolve()
    folder=root/'analysis'/('market_states_'+datetime.now().strftime('%Y%m%d_%H%M%S'));folder.mkdir(parents=True)
    shutil.copy2(__file__,folder/'analysis_source.py')
    plan=json.loads((root/'plan.json').read_text())
    indices={'train':np.load(root/'fit_indices.npy'),
             'development':np.load(root/'joint_l2/codes.npz')['development_indices']}
    splits={};raw={}
    for split in indices:
        values,times,profiles,curves=extract(root,split,indices[split])
        if not np.isfinite(values).all():raise ValueError('Nonfinite raw-window features')
        months=times.astype('datetime64[us]').astype('datetime64[M]').astype(str)
        raw[split]=(values,months,profiles,curves)
        splits[split]=dict(windows=len(values),mean=values.mean(0).tolist(),std=values.std(0).tolist(),
                           month_counts={m:int((months==m).sum()) for m in np.unique(months)})
        np.savez_compressed(folder/(split+'_features.npz'),values=values,times=times,indices=indices[split],profiles=profiles,curves=curves)
    methods={};pointers=[];pvalues=[]
    for lane in ('joint_l2','joint_max','independent16','independent256'):
        stored=np.load(root/lane/'codes.npz')
        branches=[('pair',None)] if lane.startswith('joint') else [('global',0),('local',1)]
        for branch,axis in branches:
            name=lane+'/'+branch;value={};counts={};labels={}
            for split in raw:
                c=stored[split];label=c[:,0] if axis is None else c[:,0,axis];labels[split]=label
                x,months,profiles,curves=raw[split];counts[split]=np.bincount(label,minlength=256)
                value[split]=dict(groups=group_profiles(x,label,profiles,curves))
                if split=='development':
                    a=association(x,label,months);value[split]['association']=a
                    for test in ('raw','within_month'):
                        for j,p in enumerate(a[test]['permutation_p']):pointers.append((a[test],j));pvalues.append(p)
            trainx=raw['train'][0];devx=raw['development'][0]
            means=np.tile(trainx.mean(0),(256,1))
            for code in np.unique(labels['train']):means[code]=trainx[labels['train']==code].mean(0)
            pred=means[labels['development']]
            value['train_to_development_r2']=(1-np.square(devx-pred).sum(0)/np.maximum(np.square(devx-devx.mean(0)).sum(0),1e-30)).tolist()
            value['total_variation']=float(np.abs(counts['train']/len(trainx)-counts['development']/len(devx)).sum()/2)
            methods[name]=value
            print(json.dumps(dict(method=name,classes=[int((counts[s]>0).sum()) for s in raw])),flush=True)
    for (item,j),q in zip(pointers,bh(pvalues)):
        if 'bh_q' not in item:item['bh_q']=[0.]*len(FEATURES)
        item['bh_q'][j]=q
    result=dict(features=FEATURES,splits=splits,methods=methods,source=str(root),seed=42,permutations=999,
                no_future_returns=True,model_and_codes_unchanged=True,independent_test_evaluated=False,
                notes=['Frozen post-hoc analysis; all economic features measured within the encoded window.',
                       'Train/dev window and code alignment uses the original stored index lists.',
                       'Raw grouping association is descriptive; permutation null and month-restricted tests reduce chance/calendar artifacts.',
                       'No multi-seed retraining. No class naming based on future returns. No independent Q2 evaluation.'])
    (folder/'state_analysis.json').write_text(json.dumps(result,indent=2,ensure_ascii=False,allow_nan=False))
    (folder/'states.html').write_text(PAGE)
    for name in ('states.html','state_analysis.json'):
        target=root/'viewer'/name
        temporary=target.with_suffix(target.suffix+'.tmp')
        temporary.symlink_to(folder/name);temporary.replace(target)
    Path('/tmp/paired_state_analysis_path').write_text(str(folder))
    print(folder,flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);main(p.parse_args().root)
