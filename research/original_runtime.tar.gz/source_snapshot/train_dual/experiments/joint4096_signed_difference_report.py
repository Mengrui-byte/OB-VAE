"""Static test report for the fixed-endpoint signed-difference experiment."""
import argparse
import base64
import csv
import hashlib
import html
import json
import os
from pathlib import Path

import numpy as np


def main(root):
    read = lambda p: json.loads((root / p).read_text())
    assert read('status.json')['state'] == 'complete'
    complete, access = read('training_complete.json'), read('test_access.json')
    assert complete['test_accesses'] == 0 and access['training_step'] == 128
    assert access['elapsed_seconds'] >= complete['elapsed_seconds']
    assert (root / 'final.pt').stat().st_mtime <= (root / 'test_access.json').stat().st_mtime
    plan, comparison = read('plan.json'), read('comparison.json')
    parent = Path(plan['baseline_parent'])
    labels = dict(initial='共同初始模型', dice_control='Dice对照', unsigned_morphology='Dice＋无符号形态', signed_difference='Dice＋有方向差分')
    profiles = {
        'initial': np.load(parent / 'common/compressed4096/development_step0_128windows_profiles.npz'),
        'dice_control': np.load(parent / 'dice_control/compressed4096/development_step128_128windows_profiles.npz'),
        'unsigned_morphology': np.load(parent / 'dice_morphology/compressed4096/development_step128_128windows_profiles.npz'),
        'signed_difference': np.load(root / 'test_profiles.npz'),
    }
    truth = profiles['initial']['truth'][..., 1]
    top = np.argsort(truth, axis=-1)[..., -16:]
    td = np.diff(np.log1p(truth), axis=-1).ravel()
    examples = {}
    for key, p in profiles.items():
        assert np.array_equal(p['indices'], profiles['initial']['indices'])
        assert np.array_equal(p['truth'], profiles['initial']['truth'])
        q = p['prediction'][..., 1]
        pd = np.diff(np.log1p(q), axis=-1).ravel()
        selected = np.argsort(q, axis=-1)[..., -16:]
        overlap = np.mean([len(set(a) & set(b)) / 16 for a, b in zip(top.reshape(-1,16), selected.reshape(-1,16))])
        examples[key] = dict(slope_correlation=float(np.corrcoef(td,pd)[0,1]), slope_std_ratio=float(pd.std()/td.std()),
            top16_overlap=float(overlap), true_top16_amplitude_ratio=float(np.take_along_axis(q,top,-1).sum()/np.take_along_axis(truth,top,-1).sum()))
    (root/'example_shape_metrics.json').write_text(json.dumps(dict(windows=3,indices=profiles['initial']['indices'].tolist(),metrics=examples),indent=2))
    rows = []
    for key in labels:
        d = comparison[key]
        rows.append([key,d['metrics']['price_usdt']['rmse'],d['metrics']['quantity_btc']['rmse'],
            d['metrics']['temporal_log_quantity_1_minutes']['correlation'],d['threshold100']['recall'],
            d['shape_metrics']['morphology'],d['shape_metrics']['quantity_dice']])
    with (root/'comparison.csv').open('w') as f:
        w=csv.writer(f);w.writerow(['variant','price_rmse_usdt','quantity_rmse_btc','quantity_change_correlation','recall100','unsigned_morphology_loss','dice_loss']);w.writerows(rows)
    os.environ['MPLCONFIGDIR']=str(root/'.mpl-cache')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    figures=root/'figures';figures.mkdir(exist_ok=True)
    images=''
    for window in range(3):
        images+=f'<details><summary>测试窗口索引 {profiles["initial"]["indices"][window]}：第0、7、15分钟</summary>'
        for log in (False,True):
            fig,axs=plt.subplots(3,2,figsize=(13,9),layout='constrained')
            for row,t in enumerate((0,7,15)):
                for side in (0,1):
                    ax=axs[row,side]
                    curves=[('Truth',truth[window,t,side],'#182f41'),
                        ('Dice',profiles['dice_control']['prediction'][window,t,side,:,1],'#126c96'),
                        ('Unsigned morphology',profiles['unsigned_morphology']['prediction'][window,t,side,:,1],'#d07832'),
                        ('Signed difference',profiles['signed_difference']['prediction'][window,t,side,:,1],'#15816a')]
                    for label,y,color in curves:
                        ax.plot(np.arange(len(y)),np.log1p(y) if log else y,label=label,color=color,lw=.8,alpha=.9)
                    ax.set(title=f'Minute {t} / '+('Bid' if side==0 else 'Ask'),xlabel='Ranked level',ylabel='log1p(quantity BTC)' if log else 'Quantity BTC');ax.grid(alpha=.18)
            axs[0,0].legend(fontsize=8);fig.suptitle(f'Test window {profiles["initial"]["indices"][window]} / complete 2048 levels')
            name=f'window{window}_'+('log' if log else 'linear')+'.png';fig.savefig(figures/name,dpi=140);plt.close(fig)
            images+=f'<h3>{"log1p挂量" if log else "原始BTC挂量"}</h3><a href="figures/{name}"><img alt="完整2048档测试集挂量对比" src="data:image/png;base64,'+base64.b64encode((figures/name).read_bytes()).decode()+'"></a>'
        images+='</details>'
    fmt=lambda x:f'{x:.5f}'
    table=''.join('<tr><td>'+labels[r[0]]+'</td>'+''.join('<td>'+ (f'{v:.2%}' if i==4 else fmt(v))+'</td>' for i,v in enumerate(r[1:],1))+'</tr>' for r in rows)
    aux=''.join('<tr><td>'+labels[k]+'</td>'+''.join('<td>'+fmt(v)+'</td>' for v in examples[k].values())+'</tr>' for k in labels)
    a,b=comparison['signed_difference'],comparison['dice_control']
    change=a['metrics']['quantity_btc']['rmse']/b['metrics']['quantity_btc']['rmse']-1
    verdict=f'相对同预算Dice对照，测试集挂量RMSE{"上升" if change>=0 else "下降"}{abs(change):.2%}。≥100 BTC大单召回为{a["threshold100"]["recall"]:.2%}。'
    trainrows=''
    for step in (0,32,64,128):
        d=read(f'train_step{step}_16windows.json')
        trainrows+=f'<tr><td>{step}</td><td>{fmt(d["metrics"]["quantity_btc"]["rmse"])}</td><td>{fmt(d["shape_metrics"]["signed_difference"])}</td><td>{fmt(d["shape_metrics"]["morphology"])}</td></tr>'
    shape=read('actual_shape_contract.json')
    text=f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>订单簿有方向形态监督 · 测试集结果</title><style>
    *{{box-sizing:border-box}}body{{margin:0;background:#f3f7fa;color:#183345;font:15px/1.75 system-ui,sans-serif}}main{{max-width:1200px;margin:auto;padding:30px 20px}}section{{background:white;border:1px solid #dce7ee;border-radius:12px;padding:24px;margin:22px 0}}h1{{line-height:1.3}}h2{{font-size:22px}}table{{border-collapse:collapse;width:100%;font-size:13px}}th,td{{padding:10px;border-bottom:1px solid #dce7ee;text-align:right;white-space:nowrap}}th:first-child,td:first-child{{text-align:left}}.scroll{{overflow:auto}}.callout{{background:#edf8f5;padding:16px;border-left:4px solid #15816a}}.note{{font-size:13px;color:#536d7e}}a{{color:#146e98}}img{{width:100%;height:auto}}summary{{cursor:pointer;font-weight:bold}}details{{margin:20px 0}}pre{{overflow:auto;background:#f3f7fa;padding:16px}}</style></head><body><main>
    <h1>生成订单簿：有方向的多尺度差分监督</h1><p>历史16分钟模型 · 固定4096维连续latent · seed42 · 128步 × batch2</p>
    <p class="callout">{verdict} 以下同时报告价格、动态与大单恢复，避免仅凭新损失下降判断有效。</p>
    <section><h2>同128个2025Q1测试窗口</h2><div class="scroll"><table><thead><tr><th>配置</th><th>价格RMSE USDT ↓</th><th>挂量RMSE BTC ↓</th><th>分钟挂量变化相关 ↑</th><th>≥100 BTC召回 ↑</th><th>旧无符号形态误差 ↓</th><th>Dice误差 ↓</th></tr></thead><tbody>{table}</tbody></table></div>
    <p>从上一轮共同Dice起点重新训练，保留价格和Dice监督，仅将无符号形态梯度项替换为有方向差分；系数仍为1。复用两个历史对照的完全相同初始化、训练顺序、优化器设置与128步预算。</p><p class="note">旧无符号形态指标对应旧损失；不能将它作为唯一形态标准。新差分在全128窗口上的误差为{a['shape_metrics']['signed_difference']:.6f}，未对历史对照重新计算这一全量指标。</p></section>
    <section><h2>监督定义与范围</h2><pre>x = log1p(q / q0)
Δᵣx[i] = x[i+r] − x[i], r ∈ {{1,4,16}}
L = L_original_price + L_Dice + meanᵣ Huber(Δᵣx_pred, Δᵣx_true)</pre><p>保留差分方向，使峰和谷不再得到相同表示。沿每分钟、每侧的排序档位计算，完整有效区间才参与；不除以间距r，各尺度等权，Huber beta=1。它不等于按真实价格间距计算的流动性墙监督。</p><pre>{html.escape(json.dumps(shape,ensure_ascii=False,indent=2))}</pre><p>冻结原编码器、融合模块及PCA，只训练双Decoder和挂量修正头。4096维状态为连续浮点数；本轮不是256分钟主线实验，也不证明4096维的最终容量上限。</p></section>
    <section><h2>训练集检查</h2><p>以下始终使用相同16个训练窗口；训练中不读取测试集。</p><div class="scroll"><table><tr><th>步数</th><th>挂量RMSE BTC</th><th>有方向差分误差</th><th>旧无符号形态误差</th></tr>{trainrows}</table></div></section>
    <section><h2>测试集完整挂量曲线</h2><p>固定3个保存案例，全部16分钟用于下表辅助诊断；不是128窗口总体统计。Top16为同档位重合率；幅度比为真实Top16位置预测总量/真实总量。</p><div class="scroll"><table><tr><th>仅3例辅助诊断</th><th>相邻log差分相关 ↑</th><th>差分标准差/真实</th><th>Top16重合</th><th>真实Top16幅度比</th></tr>{aux}</table></div><p>黑：真实；蓝：Dice；橙：旧无符号形态；绿：有方向差分。每图保留完整2048档，同时展示BTC与log高度。</p>{images}</section>
    <section><h2>评价规则与复现</h2><p>训练前固定128步终点；最终权重保存且训练完成后才首次读取本轮测试数据，无中途测试监控或按测试成绩选择权重。2025Q1此前已被历史实验查看，本轮不将其称为全新未见测试数据。单seed结果不报告跨种子方差；128步属于固定预算实验，不代表训练收敛。</p><ul>
    <li><a href="final.pt">最终模型权重</a> · <a href="joint_pca_basis.pt">必需的共享PCA基底</a></li>
    <li><a href="comparison.csv">结果CSV</a> · <a href="comparison.json">完整测试指标</a> · <a href="example_shape_metrics.json">3例辅助诊断</a></li>
    <li><a href="plan.json">实验计划</a> · <a href="verification.json">控制变量核查</a> · <a href="test_policy.json">测试规则</a> · <a href="training_complete.json">训练完成记录</a> · <a href="test_access.json">首次测试访问</a></li>
    <li><a href="source_snapshot/model/losses/quantity_signed_difference.py">损失源码快照</a> · <a href="source_snapshot/sha256.json">源码哈希</a> · <a href="report_source.py">报告生成代码</a></li></ul><p class="note">14项模型和损失测试已通过。原实验权重、配置、结果和历史文件名保留。网页静态文件已生成，报告URL的实时网络可达性未验证。</p></section></main></body></html>'''
    assert '开发集' not in text
    (root/'index.html').write_text(text)
    source=Path(__file__);(root/'report_source.py').write_bytes(source.read_bytes())
    report=dict(url='http://172.16.30.28:8875/recons/'+root.name+'/',live_url_verified=False,verdict=verdict,report_source_sha256=hashlib.sha256(source.read_bytes()).hexdigest())
    (root/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(json.dumps(report,ensure_ascii=False))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);main(p.parse_args().root.resolve())
