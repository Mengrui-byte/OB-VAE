"""Read-only cross-cohort control audit; ignore inactive readout tensors only."""
import argparse
from pathlib import Path

import torch

from train_dual.experiments.confirm_recall_goal import require_matching_replay
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read
from train_dual.experiments.price_safe_readout import file_hash


def audit(root,parent,step):
    output=root/'control'/f'step{step}_shared_source_replay_audit.json'
    if output.exists():return read(output)
    if file_hash(root/'source.pt')!=file_hash(parent/'source.pt'):
        raise ValueError('Control cohorts did not start from the same original source')
    for name in ['train_indices.npy','val_indices.npy','seen_indices.npy','unseen_indices.npy','calibration.json','teacher.pt']:
        if file_hash(root/name)!=file_hash(parent/name):raise ValueError('Changed control data/teacher: '+name)
    new_path=root/'control'/f'step{step}.pt';old_path=parent/'control'/f'step{step}.pt'
    new=torch.load(new_path,map_location='cpu',weights_only=False,mmap=True)
    old=torch.load(old_path,map_location='cpu',weights_only=False,mmap=True)
    actual={name:value for name,value in new['model'].items() if not name.startswith('local_readout.')}
    expected={name:value for name,value in old['model'].items() if not name.startswith('local_readout.')}
    assert actual.keys()==expected.keys()
    for name,value in expected.items():torch.testing.assert_close(actual[name],value,rtol=0,atol=0,msg=lambda text:'Control tensor '+name+': '+text)
    assert new['optimizer']['param_groups'][:2]==old['optimizer']['param_groups'][:2]
    assert new['optimizer']['state'].keys()==old['optimizer']['state'].keys()
    for index,state in old['optimizer']['state'].items():
        for key,value in state.items():
            other=new['optimizer']['state'][index][key]
            if torch.is_tensor(value):torch.testing.assert_close(other,value,rtol=0,atol=0)
            else:assert other==value
    for key in ['sampler_generator_state','augmentation_generator_state']:
        torch.testing.assert_close(new[key],old[key],rtol=0,atol=0)
    for key in ['torch','cuda']:
        a,b=new['rng_state'][key],old['rng_state'][key]
        if torch.is_tensor(a):torch.testing.assert_close(a,b,rtol=0,atol=0)
        else:
            assert len(a)==len(b)
            for one,two in zip(a,b):torch.testing.assert_close(one,two,rtol=0,atol=0)
    require_matching_replay(read(new_path.with_name(new_path.stem+'_development.json'))['result'],read(old_path.with_name(old_path.stem+'_development.json'))['result'])
    result=dict(passed=True,step=step,original_model_tensors_exact=len(expected),original_Adam_states_exact=True,
        sampler_augmentation_torch_CUDA_RNG_exact=True,development_replayed=True,only_inactive_readout_parameters_excluded=True,
        checkpoint_sha256=file_hash(new_path),shared_checkpoint_sha256=file_hash(old_path),optimizer_updates=0,independent_data_read=False)
    atomic_json(output,result)
    return result


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--parent',type=Path,required=True);p.add_argument('--steps',type=int,nargs='+',required=True);a=p.parse_args()
    torch.set_num_threads(4)
    for step in a.steps:
        if not (a.root/'control'/f'step{step}_development.json').exists():continue
        print(audit(a.root.resolve(),a.parent.resolve(),step),flush=True)
