"""Window-vector ablation results, state diagnostics and actual book profiles."""

import argparse
import json
from pathlib import Path

import numpy as np

from train_dual.experiments.book_stem_viewer import build
from train_dual.util.checkpoint import freeze_sources


def render(root):
    result=json.loads((root/'comparison.json').read_text());plan=json.loads((root/'plan.json').read_text())
    source=Path(plan['initial_checkpoint']).parent.parent/'strict_fp32/report/profiles.npz'
    data=root/'report';data.mkdir(exist_ok=False)
    with np.load(source) as old:
        arrays={key:old[key] for key in ('truth','mask','time','indices')};arrays['frozen']=old['cross']
    for lane in ('d1024','d512','d256'):
        with np.load(root/lane/'profiles.npz') as p:
            assert np.array_equal(p['truth'],arrays['truth']) and np.array_equal(p['mask'],arrays['mask'])
            assert p['market_state'].shape==(3,int(lane[1:]))
            arrays[lane]=p['prediction']
        (data/(lane+'_market_states.npz')).symlink_to(root/lane/'market_states.npz')
    np.savez_compressed(data/'profiles.npz',**arrays)
    config=[dict(key='truth',label='真实订单簿',color='#2563eb'),dict(key='frozen',label='冻结的原cross参考',color='#ef4444')]
    config += [dict(key=lane,label=f'窗口状态 {lane[1:]}维',color=color) for lane,color in zip(('d1024','d512','d256'),('#16a34a','#9333ea','#f59e0b'))]
    info=dict(seed=42,common_step=plan['joint_steps'],viewer_variants=config,default_model=2,
              step_note='窗口级单向量；压缩组预热512步后联合训练192步，红色为冻结cross参考。',
              comparison_label='查看压缩维度、完整指标与流形诊断',plan=plan,results=result)
    (data/'comparison.json').write_text(json.dumps(info,ensure_ascii=False,indent=2))
    def cells(r):
        m=r['metrics'];v=[f"{m['price_usdt']['rmse']:.3f}",f"{m['quantity_btc']['rmse']:.4f}",f"{m['spatial_slope_64_levels_usdt_per_level']['rmse']:.6f}",f"{m['temporal_mid_1_minutes_usdt_per_minute']['rmse']:.3f}",f"{r['thresholds']['100']['recall']:.1%}"]
        return ''.join('<td>'+x+'</td>' for x in v)
    rows=result['rows'];reference=rows['reference']['initial']['result']
    table='<table><tr><th>方案</th><th>价格RMSE / USDT</th><th>数量RMSE / BTC</th><th>64档斜率RMSE</th><th>分钟价格变化RMSE</th><th>≥100 BTC同档召回率</th><th>达到保真阈值</th></tr>'
    table+='<tr><td>冻结原cross参考</td>'+cells(reference)+'<td>参照</td></tr>'
    table+='<tr><td>原cross继续训练192步</td>'+cells(rows['reference']['final']['result'])+'<td>优化对照</td></tr>'
    for lane in ('d1024','d512','d256'):
        table+='<tr><td>'+lane[1:]+'维窗口向量</td>'+cells(rows[lane]['final']['result'])+'<td>'+('通过' if rows[lane]['qualified'] else '未通过')+'</td></tr>'
    table+='</table>'
    source_a=json.loads((root/'source_dimension_audit.json').read_text()) if (root/'source_dimension_audit.json').exists() else None
    agg=json.loads((root/'aggregation_dimension_audit.json').read_text()) if (root/'aggregation_dimension_audit.json').exists() else None
    diagnostic=''
    if source_a:
        diagnostic='<h2>原表示的线性方差结构（1024个训练窗口）</h2><table><tr><th>表示</th><th>99%方差需要的主成分</th><th>256个主成分保留方差</th></tr>'
        for key,label in [('global_only','原global序列'),('full_source','原global＋local序列')]:
            d=source_a[key];diagnostic+=f"<tr><td>{label}</td><td>{d['principal_components']['0.99']}</td><td>{d['variance_retained']['256']:.2%}</td></tr>"
        diagnostic+='</table><p>这些是线性方差结构，不等于非线性流形的精确维度。全量local细节包含更多高维变化，不能据此认定市场状态本身也必须高维。</p>'
    if agg:
        d=agg['linear_inverse'];diagnostic+=f"<h2>256维的可恢复性诊断</h2><p>用1024个训练窗口拟合线性逆映射，从最终256维向量恢复上游1024维聚合表示；在128个开发窗口上解释方差为 <b>{d['development_explained_variance']:.6%}</b>。聚合表示只需{agg['aggregation_tokens']['principal_components']['0.99']}个主成分就能覆盖99%方差。这说明最终投影不是当前主要可恢复性瓶颈，但不证明更早的聚合保留了所有订单簿信息。</p>"
    probes='<h2>窗口市场特征的线性探针（开发集R²）</h2><table><tr><th>特征</th><th>1024维</th><th>512维</th><th>256维</th></tr>'
    for feature in ('window_return_bps','realized_return_rms_bps','log_mean_bid_depth','log_mean_ask_depth','mean_imbalance_10','large_quantity_share'):
        probes+='<tr><td>'+feature+'</td>'+''.join(f"<td>{rows[lane]['state_probe']['features'][feature]['r2']:.4f}</td>" for lane in ('d1024','d512','d256'))+'</tr>'
    probes+='</table><p>只用512个训练窗口拟合标准化及ridge权重，128个开发窗口评估。探针反映能否线性读出窗口已有属性，不是未来预测测试；线性探针读不出也不严格证明非线性信息不存在。</p>'
    page='''<!doctype html><meta charset=utf-8><title>窗口状态压缩与流形诊断</title><style>body{font:17px system-ui;max-width:1450px;margin:30px auto;padding:0 20px;color:#162235}p{line-height:1.8}table{border-collapse:collapse;width:100%}th,td{padding:10px;border:1px solid #d8dfe9;text-align:right}a{color:#2563eb}</style><h1>1024 / 512 / 256维窗口状态消融</h1><p><a href=../>打开每档一条竖线的真实/重建订单簿</a> · <a href=../window_state.html>查看本轮运行记录</a></p><p>整个16分钟窗口聚合成一个 [B,D] 向量，16×64是内部聚合槽，不与分钟一一对应。生成仅使用最终向量。只运行种子42，压缩组512步预热后各做192步联合训练；验证采用严格FP32。</p>'''+table
    page+='<p><b>本轮三个压缩维度均未达到预先设定的完整重建阈值。</b>这只能说明当前聚合器、生成器和训练预算的组合没有达到要求，不能证明1024/512/256维在数据流形上不可行。完整重建与市场状态表征需要分开判断。</p>'+diagnostic+probes
    page+='<h2>向量和数据下载</h2><p>'+ ' · '.join(f'<a href="{lane}_market_states.npz">{lane[1:]}维窗口向量</a>' for lane in ('d1024','d512','d256'))+' · <a href="comparison.json">完整指标与配置</a></p><p>训练期为2022–2024年，开发验证为2025年一季度，独立测试期未使用。这些向量只在窗口结束时可用；窗口内部重建不是未来预测。</p>'
    (data/'index.html').write_text(page)
    viewer=root/'state_viewer';freeze_sources(viewer/'source_snapshot');build(data,viewer)
    p=viewer/'index.html';text=p.read_text().replace('逐档挂单线图：真实订单簿与模型重建','窗口状态向量的订单簿重建')
    text=text.replace('<div class="controls">','<p><b>当前三个压缩版本均未达到完整重建阈值。</b>可切换维度查看实际恢复情况；最终向量是整个窗口的 [B,D]，不是逐分钟向量。</p><div class="controls">');p.write_text(text)
    for name in ('window_state.html','window_state.json'):(viewer/name).symlink_to(root/'public'/name)
    return viewer


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);a=p.parse_args();print(render(a.root))
