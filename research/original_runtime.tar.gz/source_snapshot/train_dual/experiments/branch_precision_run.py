"""Matched Encoder x post-Z precision continuation after the quantity objectives."""
import argparse
from copy import deepcopy
import html
import os
from pathlib import Path
import signal
import sys
import time

import numpy as np
import torch

from model.layers.branch_precision import branch_precision_policy
from train_dual.experiments import local_hint_run as shared
from train_dual.experiments.auxiliary_reconstruction_run import reviewed_candidate_decision
from train_dual.experiments.confirm_recall_goal import require_matching_replay
from train_dual.experiments.goal_evaluate import assess_file
from train_dual.experiments.log_relative_detail_run import run_cohort
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.mid_delta_run import violation_key
from train_dual.experiments.phase_detail_report import read,STYLE
from train_dual.experiments.price_safe_readout import file_hash
from train_dual.experiments.recall_goal_run import candidates,record,render as render_goal
from train_dual.experiments.region_task_run import gpu_free
from train_dual.util.checkpoint import atomic_save,freeze_sources,load_for_inference
from train_dual.util.hint_training import restore_regional_phase_adam
from train_dual.util.inherited_book_loss import inherited_book_loss
from train_dual.util.phase_training import tensor_digest
from train_dual.util.quantity_strata import evaluate_with_quantity_strata

MODULE='train_dual.experiments.branch_precision_run'
FACTORS=dict(control=(False,False),encoder_fp32=(True,False),decoders_fp32=(False,True),both_fp32=(True,True))
LABELS=dict(control='原BF16训练',encoder_fp32='完整Encoder FP32',decoders_fp32='完整post-Z路径FP32',both_fp32='完整Encoder＋post-Z FP32')
LOSS_KEYS=['regional_phase_config','stratified_quantity_loss_config','mid_lowpass_loss_config','local_detail_loss_config','relative_detail_loss_config','precision_policy_config']


def choose_precision_source(parent_rows,parent_lanes,parent_name,reference_row):
    common=set.intersection(*[{row['step'] for row in parent_rows if row['lane']==lane} for lane in parent_lanes])
    if not common or max(common)==0:raise ValueError('Need trained parent checkpoints shared by all four arms')
    pool=[dict(row,source_origin=parent_name) for row in parent_rows if row['step'] in common and (row['step']>0 or row['lane']=='control')]
    pool.append(dict(reference_row))
    guard=1.1*reference_row['price_rmse']
    def key(row):
        old=violation_key(row);extra=max(1.,row['price_rmse']/guard)
        return max(old[0],extra),old[1]+extra,old[2],old[3]
    return min(pool,key=key),max(common),guard


def predecessor_live(queue,pid,proc=Path('/proc')):
    try:args=(proc/str(pid)/'cmdline').read_bytes().split(b'\0')
    except FileNotFoundError:return False
    return b'train_dual.experiments.log_relative_detail_run' in args and str(queue).encode() in args and b'--controller' in args


def prepare_queue(goal,pid):
    root=goal/'branch_precision_after_relative_20261028';root.mkdir();(root/'logs').mkdir()
    audit=read(goal/'branch_precision_full_gpu_preflight_20261028/audit.json');assert audit['state']=='passed' and audit['policy_scope']=='branches'
    assert len(audit['cases'])==4 and all(c['original_FP32_inference_exact'] and c['fresh_checkpoint_Z_only_decode_exact'] for c in audit['cases'])
    reference_root=goal/'round_008_auxiliary/control';reference_eval=reference_root/'step512_development.json';reference_checkpoint=reference_root/'step512.pt'
    reference=assess_file(reference_eval,goal/'reference_evaluation.json')
    p=dict(queue_only=True,parent='round_009_relative_detail',parent_queue='log_relative_detail_after_auxiliary_20261028',parent_pid=pid,
        steps=2048,checkpoints=[256,512,1024,2048],max_seconds=43200,wait_seconds=46800,seed=42,factors=FACTORS,
        parent_not_created_yet_is_allowed_only_while_exact_controller_is_live=True,
        source_policy='After normal parent completion: all shared parent checkpoints with matched controls, one original source0 fallback, plus frozen round008/control512 price reference. Minimize fixed joint-gate violations with an additional1.10x reference-price violation. Original score fields/contract unchanged. Source selection is exploratory; new4arms share one selected source.',
        price_reference_origin='round_008_auxiliary',price_reference_lane='control',price_reference_step=512,
        price_reference_checkpoint_sha256=file_hash(reference_checkpoint),price_reference_evaluation_sha256=file_hash(reference_eval),
        price_reference_rmse_USDT=reference['price_rmse'],source_selection_price_guard_USDT=1.1*reference['price_rmse'],
        controls='Same source tensors/all3Adam/RNG/data/order/augmentation/teacher/actual source objective and all coefficients/LR/clip/batch/accumulation4/seed42/2048updates. Only two branch precision flags differ. No new loss, activation, upsampling, input transform, latent, or parameter changes.',
        inference_policy='Native evaluation stays FP32 in all arms; every step0 must exactly replay the source with the same weights. Training precision differences are the only intervention.',
        candidate_policy='Original-gate native candidates need SHA-bound whole-book review with schema2 full16 evidence; accepted candidates take confirmation priority. Never automatically read Q2 or complete the goal.',
        shape_contract=dict(input=[1,256,2,2048,2],latent=[1,64,128],output=[1,256,2,2048]),original_goal_contract_unchanged=True)
    atomic_json(root/'plan.json',p);atomic_json(root/'status.json',dict(state='prepared_not_started'));freeze_sources(root/'source_snapshot')
    project=Path(__file__).resolve().parents[2];remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 CUDA_DEVICE_ORDER=PCI_BUS_ID OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m {MODULE} "{remote}" --controller >> "{remote}/logs/controller.log" 2>&1\n')
    render(root);record(goal,'branch_precision_queue_prepared',wave=root.name,parent_pid=pid);print(root.resolve(),flush=True)


def criterion(root,lane,device='cuda:0'):
    p=read(root/'plan.json')
    return inherited_book_loss(p['source_loss_metadata'],p,lane,read(root/'calibration.json'),read(root/'quantity_calibration.json'),read(root/'detail_calibration.json',{})).to(device)


def prepare_actual(queue,selected,endpoint):
    goal=queue.parent;study=read(queue/'plan.json');parent=goal/selected.get('source_origin',study['parent']);old=read(parent/'plan.json')
    source=parent/'source.pt' if selected['step']==0 else parent/selected['lane']/f"step{selected['step']}.pt"
    payload=torch.load(source,map_location='cpu',weights_only=False,mmap=True)
    assert payload['epoch_boundary'] and len(payload['optimizer']['param_groups'])==3
    if selected['step']:assert payload['step']==selected['step']
    assert not any(payload.get('branch_precision_config',{}).values()) and not any(payload.get('precision_policy_config',{}).values())
    config=payload['regional_phase_config'];assert not config['use_shape'] and not config['use_mass']
    model,_=load_for_inference(source,'cpu');opt=restore_regional_phase_adam(model,payload['optimizer'],old['original_parameter_names'])
    assert opt.state_dict()['param_groups']==payload['optimizer']['param_groups']
    root=goal/'round_010_branch_precision';root.mkdir()
    for name in ['data','logs','seen','unseen',*LABELS]:(root/name).mkdir()
    for split in ['seen','unseen']:
        for lane in LABELS:(root/split/lane).mkdir()
    os.link(source,root/'source.pt')
    for name in ['teacher.pt','calibration.json','train_indices.npy','val_indices.npy','seen_indices.npy','unseen_indices.npy','quantity_calibration_indices.npy','plotly.min.js']:
        os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    from shutil import copy2
    copy2(parent/'quantity_calibration.json',root/'quantity_calibration.json')
    if (parent/'detail_calibration.json').exists():copy2(parent/'detail_calibration.json',root/'detail_calibration.json')
    keys=['train','development','independent_test_untouched','window_size','stride','normalization','model_config','local_hint_config','original_parameter_names','objective','source_FP_rule','augmentation',
        'lr','weight_decay','clip_grad','batch_size','accumulation','seed','beta','sample','input_shape','latent_shape','output_shape','precision']
    p={k:deepcopy(old[k]) for k in keys if k in old};source_lane='control' if selected['step']==0 else selected['lane'];spec=old['lanes'][source_lane]
    metadata={k:deepcopy(payload[k]) for k in LOSS_KEYS if k in payload};extras={}
    for lane,(encoder,decoders) in FACTORS.items():
        policy=dict(encoder_fp32=encoder,decoders_fp32=decoders)
        extras[lane]=dict(deepcopy(metadata),branch_precision_config=policy,
            training_numeric_policy=dict(cudnn_deterministic=True,cudnn_benchmark=False,tf32=False,branch_precision_config=policy),
            inference_numeric_policy=dict(cudnn_deterministic=True,cudnn_benchmark=False,tf32=False,evaluation='nativeFP32'))
        initial={k:deepcopy(payload[k]) for k in ['format_version','unified_vae_config','config','local_hint_config'] if k in payload}
        initial.update(model=payload['model'],**extras[lane]);atomic_save(initial,root/lane/'initial.pt')
    p.update(experiment='完整Encoder×完整post-Z路径精度2x2',labels=LABELS,lanes={lane:deepcopy(spec) for lane in LABELS},source_loss_metadata=metadata,
        source_selection=selected,selection_common_endpoint=endpoint,source_sha256=file_hash(source),source_steps=payload['source_steps']+payload['step'],
        source_evaluation_relative=f"../{parent.name}/{source_lane}/step{selected['step']}_development.json",source_checkpoint_relative=str(source.relative_to(goal)),
        initial_model_sha256=tensor_digest(model),checkpoint_extras=extras,steps=study['steps'],checkpoints=study['checkpoints'],max_seconds=study['max_seconds'],
        gpu_workers=[[gpu,lane] for gpu,lane in zip([2,3,4,5],LABELS)],worker_module=MODULE,controls=study['controls'],
        auxiliary_kind='whole_branch_precision',branch_precision_factorial=True,loss_variant='inherited_objective_branch_precision',new_model_parameters=0,
        quantity_strata_metrics_schema=2,original_goal_contract_unchanged=True,parent_price_rmse_USDT=selected['price_rmse'],parent_price_limit_USDT=1.1*selected['price_rmse'],
        preview_descriptions={lane:'完整256分钟、唯一8192Gaussian；仅训练计算精度改变，原生评估始终FP32。' for lane in LABELS})
    assert p['input_shape']==[1,256,2,2048,2] and p['latent_shape']==[1,64,128] and p['output_shape']==[1,256,2,2048]
    atomic_json(root/'plan.json',p)
    for split in ['seen','unseen']:
        atomic_json(root/split/'plan.json',dict(p,preview_descriptions={lane:'训练年代诊断，非独立测试。' for lane in LABELS}));os.link(root/'plotly.min.js',root/split/'plotly.min.js')
    # Validate all inherited coefficients before permitting any worker updates.
    for lane in LABELS:criterion(root,lane,'cpu')
    atomic_json(root/'status.json',dict(state='prepared_no_training_started'));freeze_sources(root/'source_snapshot');render(root);return root


def optimizer_factory(root,lane,model,state,names):
    p=read(root/'plan.json');expected=p['checkpoint_extras'][lane]['branch_precision_config'];assert branch_precision_policy(model)==expected
    optimizer=restore_regional_phase_adam(model,state,names);seen={};done=False
    e='torch.float32' if expected['encoder_fp32'] else 'torch.bfloat16';d='torch.float32' if expected['decoders_fp32'] else 'torch.bfloat16'
    desired=dict(encoder_input=e,encoder_down3=e,encoder_mu=e,price_head=d,quantity_head=d,hint_adapter=d)
    def hook(name):
        def observe(module,args,out):
            nonlocal done
            if done or not model.training:return
            seen[name]=str(out.dtype)
            if set(seen)==set(desired):
                assert seen==desired
                atomic_json(root/lane/'actual_branch_precision_audit.json',dict(passed=True,policy=expected,training_layer_dtypes=seen,scope='First actual training forward; native FP32 evaluation is deliberately excluded.'));done=True
        return observe
    modules=dict(encoder_input=model.encoder.input_proj,encoder_down3=model.encoder.down[3],encoder_mu=model.encoder.mu,
        price_head=model.price_decoder.gap,quantity_head=model.volume_decoder.quantity,hint_adapter=model.hint_adapter)
    for name,module in modules.items():module.register_forward_hook(hook(name))
    return optimizer


def audit_startup(root):
    p=read(root/'plan.json');rows={lane:read(root/lane/'step1_data_audit.json',{}) for lane in LABELS}
    if not all(rows.values()) or not all((root/lane/'step8_gradient_audit.json').exists() for lane in LABELS):return False
    old=torch.load(root/'source.pt',map_location='cpu',weights_only=False,mmap=True);source=read(root/p['source_evaluation_relative'])['result']
    for lane,row in rows.items():
        assert row['training_indices']==rows['control']['training_indices'] and row['edits']==rows['control']['edits']
        assert read(root/lane/'actual_shape_contract.json')['passed'] and read(root/lane/'actual_branch_precision_audit.json')['passed']
        require_matching_replay(read(root/lane/'step0_development.json')['result'],source)
        new=torch.load(root/lane/'step0.pt',map_location='cpu',weights_only=False,mmap=True)
        assert old['model'].keys()==new['model'].keys()
        for name,value in old['model'].items():torch.testing.assert_close(value,new['model'][name],rtol=0,atol=0)
        assert new['branch_precision_config']==p['checkpoint_extras'][lane]['branch_precision_config']
        for key,value in p['source_loss_metadata'].items():assert new[key]==value
        assert old['optimizer']['param_groups']==new['optimizer']['param_groups'] and old['optimizer']['state'].keys()==new['optimizer']['state'].keys()
        for index,state in old['optimizer']['state'].items():
            for key,value in state.items():
                if torch.is_tensor(value):torch.testing.assert_close(value,new['optimizer']['state'][index][key],rtol=0,atol=0)
                else:assert value==new['optimizer']['state'][index][key]
    atomic_json(root/'startup_control_audit.json',dict(passed=True,same_source_all3Adam_and_raw_inputs=True,same_inherited_loss_configuration=True,
        native_FP32_step0_exact_all4=True,only_declared_training_precision_changes=True,actual_whole_branch_dtypes_verified=True,full256_unique8192_singleZ_verified=True));return True


def checkpoint_analysis(root,step):
    out=root/f'common{step}_analysis.json'
    if out.exists() or not all((root/lane/f'step{step}_development.json').exists() for lane in LABELS):return
    rows=[row for row in candidates(root,root.parent/'reference_evaluation.json') if row['step']==step]
    atomic_json(out,dict(step=step,design='Encoder_x_postZ_precision',rows=rows));record(root.parent,'branch_precision_common_checkpoint',wave=root.name,step=step,rows=rows)


def render(root):
    p=read(root/'plan.json');s=read(root/'status.json',{});text='<h1>完整Encoder × 完整post-Z精度对照</h1>'
    if p.get('queue_only'):text+='<p>等待相对误差×细节四组正常结束及候选审查；该父实验尚未创建时，仅允许在其确切控制器存活时继续等待。</p>'
    else:
        text+='<p>完整256分钟、双侧2048档、唯一8192Gaussian。原BF16、仅Encoder FP32、仅价格/数量/hint路径FP32、两者FP32。无新增参数。原损失及其所有实际系数保留；四组原生评估始终FP32。</p><table><tr><th>组</th><th>更新步</th><th>评估步</th><th>召回</th><th>精确率</th><th>价格RMSE USDT</th></tr>'
        for lane,label in LABELS.items():
            paths=sorted((root/lane).glob('step*_development.json'),key=lambda f:int(f.name.split('_')[0][4:]));latest=paths[-1] if paths else None
            cells=[label,read(root/lane/'progress.json',{}).get('step',0)]
            if latest:
                a=assess_file(latest,root.parent/'reference_evaluation.json');cells += [int(latest.name.split('_')[0][4:]),f"{a['recall100']:.2%}",f"{a['precision100']:.2%}" if a['precision100'] is not None else '—',f"{a['price_rmse']:.4f}"]
            else:cells+=['待评估']*4
            text+='<tr>'+''.join('<td>'+html.escape(str(x))+'</td>' for x in cells)+'</tr>'
        text+='</table><p>比较相同更新预算，另报实际耗时与显存。只比较共同评估点；step0同一参数的原生指标必须一致。大单、小中单和价格共同验收。</p>'
    text+='<p>状态：'+html.escape(str(s))+'</p><p>Q1反复用于开发，非独立测试；不会自动读取Q2或宣布完成。</p><p><a href="plan.json">协议</a> · <a href="status.json">状态</a></p>'
    (root/'index.html').write_text('<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="30"><style>'+STYLE+'</style>'+text)


def controller(queue):
    p=read(queue/'plan.json');goal=queue.parent;parent=goal/p['parent'];parent_queue=goal/p['parent_queue'];begin=time.monotonic()
    while True:
        state=read(parent/'status.json',{});qstate=read(parent_queue/'status.json',{});live=predecessor_live(parent_queue,p['parent_pid'])
        if state.get('state')=='failed' or qstate.get('state')=='failed':raise RuntimeError('Parent failed; no precision training from partial results')
        if not live:
            if qstate.get('state','').startswith('not_run_accepted_candidate'):
                atomic_json(queue/'status.json',dict(state='not_run_parent_accepted_candidate_requires_confirmation'));render(queue);return
            if state.get('state')=='complete':break
            raise RuntimeError('Verified parent controller missing without successful terminal state')
        if time.monotonic()-begin>p['wait_seconds']:raise TimeoutError('13hour parent wait ceiling')
        atomic_json(queue/'status.json',dict(state='verified_wait_parent',pid=os.getpid(),parent_pid=p['parent_pid'],parent_created=(parent/'plan.json').exists()));render(queue);time.sleep(20)
    assert read(parent/'startup_control_audit.json')['passed']
    assert all(read(parent/lane/'status.json')['state'] in ['complete','budget_complete'] for lane in read(parent/'plan.json')['labels'])
    rows=candidates(parent,goal/'reference_evaluation.json');qualified=[row for row in rows if row['pass']]
    existing=read(goal/'candidate_for_confirmation.json',{})
    if existing and assess_file(Path(existing['evaluation']),goal/'reference_evaluation.json')['pass']:qualified.append(existing)
    if qualified:
        candidate=max(qualified,key=lambda row:(row['recall100'],-row['price_rmse']));decision=reviewed_candidate_decision(goal,candidate)
        while decision is None:
            if time.monotonic()-begin>p['wait_seconds']:raise TimeoutError('Autonomous whole-book candidate review pending')
            atomic_json(queue/'status.json',dict(state='waiting_whole_book_review',pid=os.getpid(),candidate=candidate));render(queue);time.sleep(20);decision=reviewed_candidate_decision(goal,candidate)
        if decision:
            atomic_json(queue/'status.json',dict(state='not_run_accepted_candidate_requires_confirmation',candidate=candidate));render(queue);return
    refroot=goal/p['price_reference_origin'];refpath=refroot/p['price_reference_lane']/f"step{p['price_reference_step']}_development.json"
    assert file_hash(refpath)==p['price_reference_evaluation_sha256']
    assert file_hash(refroot/p['price_reference_lane']/f"step{p['price_reference_step']}.pt")==p['price_reference_checkpoint_sha256']
    reference=dict(lane=p['price_reference_lane'],step=p['price_reference_step'],source_origin=refroot.name,
        checkpoint=str(refroot/p['price_reference_lane']/f"step{p['price_reference_step']}.pt"),evaluation=str(refpath),**assess_file(refpath,goal/'reference_evaluation.json'))
    selected,endpoint,guard=choose_precision_source(rows,tuple(read(parent/'plan.json')['labels']),parent.name,reference)
    atomic_json(queue/'source_selection.json',dict(selected=selected,latest_shared_parent_endpoint=endpoint,all_rows=rows,price_reference=reference,
        source_selection_price_guard_USDT=guard,scope='Repeated Q1 development only; shared checkpoint grids and an explicit prior reference for source selection, not cross-budget causal claims. Original goal score fields/contract unchanged.'))
    while any(gpu_free().get(g,0)<47000 for g in [2,3,4,5]):
        if time.monotonic()-begin>p['wait_seconds']:raise TimeoutError('GPU release wait ceiling')
        atomic_json(queue/'status.json',dict(state='verified_wait_GPU_release',pid=os.getpid()));render(queue);time.sleep(10)
    root=prepare_actual(queue,selected,endpoint);atomic_json(queue/'status.json',dict(state='running',pid=os.getpid(),wave=root.name));render(queue)
    atomic_json(goal/'status.json',dict(state='running_branch_precision_factorial',wave=root.name))
    run_cohort(root,worker_module=MODULE,startup_auditor=audit_startup,renderer=render,analyzer=checkpoint_analysis)
    new=candidates(root,goal/'reference_evaluation.json');old=read(goal/'candidates.json',{}).get('rows',[])
    atomic_json(goal/'candidates.json',dict(rows=[row for row in old if row.get('experiment')!=root.name]+[dict(row,experiment=root.name) for row in new]))
    atomic_json(goal/'status.json',dict(state='branch_precision_complete_requires_joint_review',wave=root.name,goal_achieved=False))
    atomic_json(queue/'status.json',dict(state='complete',wave=root.name,goal_automatically_completed=False));render(queue);render_goal(goal)
    record(goal,'branch_precision_cohort_complete',wave=root.name,next='Joint recall/precision/price and whole-book review; freeze an eligible native candidate before independent confirmation. No automatic Q2.')


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('root',type=Path);parser.add_argument('--prepare',action='store_true');parser.add_argument('--parent-pid',type=int);parser.add_argument('--controller',action='store_true');parser.add_argument('--lane',choices=list(LABELS));args=parser.parse_args();root=args.root.resolve()
    def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        if args.prepare:
            if not args.parent_pid:parser.error('--parent-pid required')
            prepare_queue(root,args.parent_pid)
        elif args.controller:controller(root)
        elif args.lane:
            shared.evaluate=evaluate_with_quantity_strata
            def optimizer(model,state,names):return optimizer_factory(root,args.lane,model,state,names)
            shared.worker(root,args.lane,objective_factory=criterion,optimizer_factory=optimizer)
        else:parser.error('Specify a mode')
    except BaseException as error:
        if not args.prepare:atomic_json((root/args.lane if args.lane else root)/'status.json',dict(state='failed',pid=os.getpid(),error=repr(error)))
        raise


if __name__=='__main__':main()
