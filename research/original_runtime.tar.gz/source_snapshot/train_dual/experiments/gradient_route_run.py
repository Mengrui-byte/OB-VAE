"""2x2causal quantitygradient-routing experiment; forward values unchanged."""
import argparse
from datetime import datetime
import json
import os
from pathlib import Path
import torch
from model.experimental.gradient_route import GradientRouteOrderBookVAE
from model.losses.controlled_book import ControlledBookLoss
from train_dual.experiments.gradient_route_audit import inspect_routes
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.loss_control_run import campaign as train_campaign,worker
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import freeze_sources,seed_everything
from train_dual.util.data import DualNormalizer

ROUTES={'full':dict(detach_quantity_latent=False,detach_quantity_geometry=False),'stop_z':dict(detach_quantity_latent=True,detach_quantity_geometry=False),'stop_geometry':dict(detach_quantity_latent=False,detach_quantity_geometry=True),'stop_both':dict(detach_quantity_latent=True,detach_quantity_geometry=True)}
LABELS={'full':'两路径均回传·匹配对照','stop_z':'仅阻断直接Z梯度','stop_geometry':'仅阻断价格条件梯度','stop_both':'两条数量梯度路径均阻断'}


def prepare(parent):
 parent=parent.resolve();project=Path(__file__).resolve().parents[2];root=project/'recons'/('gradient_route_'+datetime.now().strftime('%Y%m%d_%H%M%S'));root.mkdir();(root/'data').mkdir();(root/'logs').mkdir()
 for name in ['train_indices.npy','val_indices.npy','source_profiles.npz']:os.link(parent/name,root/name)
 os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz');os.link(parent/'shape_mass/step256.pt',root/'initial.pt');os.link(parent/'shape_mass/step256_evaluation.json',root/'initial_expected.json')
 diagnostics=Path(Path('/tmp/gradient_capacity_path').read_text().strip());os.link(diagnostics/'small_train.pt',root/'audit_train.pt')
 plan=json.loads((parent/'plan.json').read_text());plan.update(experiment='2x2quantitygradient paths: directZ andpredicted-pricegeometry',parent=str(parent),pretraining_steps=2304,source_checkpoint='distribution_control/shape_mass/step256.pt: AE2048+256shape_mass updates; predetermined diagnosedstate, not finalvalidationwinner',wait_for_relative=str(parent.relative_to(project)),wait_for_relatives=[str(parent.relative_to(project))],
  gradient_routes=ROUTES,labels=LABELS,lanes={k:dict(mode='shape_mass') for k in ROUTES},default_variant='full',viewer_default_model=2,viewer_route='gradient_route',steps=512,checkpoints=[32,128,256,512],max_seconds=7200,queue_max_seconds=7200,
  control_contract=dict(fixed=['sameobservedshape_mass256weights andAdamWmoments','sameforwardfunction,parameterorder,countand8192latent','sameprice/basequantity/distributionKL/masslosses andweights','same64trainingindices16developmentindices8seenindices','seed42,samplerrestart,batch1accum4,AdamW1e-4,clip1','same512additionalupdates,precision,evaluation'],
   factors=['Detach onlyZ going intoVolumeDecoder','Detach predictedprice/gap conditions beforeVolumeDecoder geometryencoder'],
   interpretation='stop_z blocks only directZroute; quantity can still reachEncoder throughpredictedprice ifgeometry remainsattached. stop_both blocks bothdirectroutes. Encoder andPriceDecoder are not frozen: priceloss continues to update them. VolumeDecodergeometryparameters remaintrainable inallcases.',
   residual_coupling='Jointglobalclip1andrestoredAdammoments retained for allcases; blockingdirectquantitygrad doesnot removeclipping-scale coupling orhistoricmomentum.',
   forward='OneZdraw/value; detachchangesautogradgraph only. No newlatent orencoderfeaturebypass.'),
  initialization='Sameobservedshape_mass256weights andAdamWmoments; shared2304updatecost. Samesamplerrestartseed42 for all, not exactcontinuation of source samplingtrajectory.',
  hypothesis='Does preventingdirectquantitypressure onsharedZ orpricegeometry improvepricepreservation at thecost of quantityrepresentation? Testcausalrouting, not inferfromcosinealone.',
  evidence='Atcurrent256point,aggregateEncoder cospositive butframereducerhaslocalizednegativecos andquantity/priceEncodernormratio8.53. Wholemodelpriceconditionquantitygradsmall. Controlonlyrouting withoutchanginglossweights.',
  selection='Fixed512additionalstependpoint, allintermediate32/128/256/512. ComparepriceRMSE,midchange,quantityRMSE,minutequantitychangecorrelation,large10/100precision&recall. Priceguard<=1.10xfullroutecontrol.2025Q1developmentonly; no2026orindependenttestselection.',
  viewer_description='完整256分钟、唯一64×128latent，梯度路径2×2对照。四组同一分布KL＋总量组第256追加步权重和AdamW动量，损失、结构、数据和512次追加更新均固定；仅分别阻断数量分支的直接Z梯度、预测价格条件梯度。detach只改变反向计算图，Z数值与前向生成不变。Encoder/价格Decoder仍由价格损失训练，数量Decoder全部训练。2025Q1为重复使用的开发期。',
  viewer_step_note='追加更新步数；共同AE2048＋shape_mass256起点，仅梯度路由不同。')
 atomic_json(root/'plan.json',plan);atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot')
 remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
 (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.gradient_route_run "{remote}"\n')
 Path('/tmp/gradient_route_path').write_text(str(root));print(root,flush=True)


def preflight(root):
 torch.set_num_threads(4);seed_everything(42);strict_precision();plan=json.loads((root/'plan.json').read_text());payload=torch.load(root/'initial.pt',map_location='cpu',weights_only=False);raw=torch.load(root/'audit_train.pt',map_location='cpu',weights_only=False);norm=DualNormalizer(tick_size=plan['normalization']['tick_size'],price_scale=plan['normalization']['price_scale']);b=norm.prepare({k:v[:1] for k,v in raw.items()},'cuda:0');criterion=ControlledBookLoss(plan['normalization']['quantity_scale'],mode='shape_mass',**plan['objective']);reference=None;rows={}
 for lane,flags in plan['gradient_routes'].items():
  model=GradientRouteOrderBookVAE(**flags,**plan['model_config']).to('cuda:0').train();model.load_state_dict(payload['model'],strict=True)
  result,ref=inspect_routes(model,b,criterion,return_reference=True)
  result['parameter_count']=sum(p.numel() for p in model.parameters())
  if reference is None:reference=ref
  else:
   for key in ['price','volume','z']:torch.testing.assert_close(reference[key],ref[key],rtol=0,atol=0)
   for a,c in zip(reference['price_gradients'],ref['price_gradients']):
    if a is not None and c is not None:torch.testing.assert_close(a,c,rtol=0,atol=0)
    elif a is not None or c is not None:raise AssertionError('Pricegradient support changed')
  g=result['groups']
  if result['nonfinite_gradients']:raise FloatingPointError('Nonfinite routegradient')
  if flags['detach_quantity_geometry']:
   if g['price_decoder']['quantity_gradient_l2']!=0:raise AssertionError('Geometryroute didnotdetach')
  elif g['price_decoder']['quantity_gradient_l2']<=0:raise AssertionError('Expectedpricegeometrygradient missing')
  if flags['detach_quantity_geometry'] and flags['detach_quantity_latent']:
   if g['encoder']['quantity_gradient_l2']!=0:raise AssertionError('QuantityEncoder routes didnotbothdetach')
  elif g['encoder']['quantity_gradient_l2']<=0:raise AssertionError('ExpectedEncodergradient missing')
  if g['volume_decoder']['quantity_gradient_l2']<=0 or g['volume_decoder.geometry']['quantity_gradient_l2']<=0:raise AssertionError('VolumeDecoder oritsgeometry processor was frozen')
  rows[lane]=result;atomic_json(root/'preflight_progress.json',dict(completed=list(rows)));del model,ref;torch.cuda.empty_cache()
 atomic_json(root/'route_preflight.json',dict(passed=True,input_shape=[1,256,2,2048,2],forward_price_quantity_z_exact=True,price_only_parameter_gradients_exact=True,trainable_parameter_count=rows['full']['parameter_count'],state_tensor_count=len(payload['model']),scope='Singlefixed full256minute trainingwindow atcommoninitialstate; FP32, trainmode identical acrosscases. Same-forward equality checked atsameautogradmode.',rows=rows));torch.cuda.empty_cache()


def campaign(root):
 try:
  atomic_json(root/'status.json',dict(state='route_preflight'));preflight(root);train_campaign(root)
 except BaseException as e:
  atomic_json(root/'status.json',dict(state='failed',error=repr(e)));raise

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--lane');a=p.parse_args()
 if a.prepare:prepare(a.root)
 elif a.lane:worker(a.root,a.lane)
 else:campaign(a.root)
