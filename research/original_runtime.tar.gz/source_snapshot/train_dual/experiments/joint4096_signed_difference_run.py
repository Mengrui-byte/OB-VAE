"""Fixed-endpoint signed-shape experiment; test data accessed only after training."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import time

import numpy as np
import torch

from model.experimental.joint_pca_state import JointPCAWindowVAE
from model.losses.dual import DualLossConfig
from model.losses.quantity_dice import continuous_quantity_dice
from model.losses.quantity_morphology import quantity_morphology_loss
from model.losses.quantity_signed_difference import SignedDifferenceDiceOrderBookLoss,signed_quantity_difference_loss
from train_dual.experiments.local_codebook_size_run import write
from train_dual.experiments.long_worker import datasets
from train_dual.util.data import DualNormalizer,DualWindowDataset
from train_dual.util.dynamics import DynamicsMetrics
from util.model_sources import freeze_model_sources


def run(root,parent):
    root=root.resolve();parent=parent.resolve();root.mkdir(parents=True,exist_ok=False);started=time.monotonic()
    project=Path(__file__).resolve().parents[2];torch.set_num_threads(4);torch.manual_seed(42)
    def progress(**kw):
        v=dict(elapsed_seconds=time.monotonic()-started,**kw);write(root/'progress.json',v)
        with (root/'progress.jsonl').open('a') as f:f.write(json.dumps(v)+'\n')
        print(json.dumps(v),flush=True)
    write(root/'status.json',dict(state='preparing'))
    inherited=json.loads((parent/'plan.json').read_text());plan={k:v for k,v in inherited.items() if not k.startswith('development') and k not in ['monitor_development_positions','initial_reference_parent','evaluation_only']}
    source=parent/'common/compressed4096/step0.pt';source_saved=torch.load(source,map_location='cpu',weights_only=False)
    plan.update(source_checkpoint=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),baseline_parent=str(parent),
        quantity_objective='squared_dice_signed_difference',difference_weight=1.,difference_lags=[1,4,16],difference_huber_beta=1.,
        only_changed_factor='Replace the unsigned morphology-gradient term with an oriented multiscale log-quantity difference term; retain Dice, original price objective and shape-term weight1.',
        difference_definition='Huber of signed log1p(q/q0)[i+r]-log1p(q/q0)[i], r1/4/16 corresponding to previous neighborhood radii. No lag division; mean valid rows and scales. Full valid segments only.',
        test_period=inherited['development'],test_indices=inherited['development_indices'],evaluation_role='test',
        test_policy='Predeclared128update endpoint; no test load/evaluation/monitoring before training completes. Test result is reported, not used to select checkpoints or tune this run.',
        historical_controls='Reuse previous Dice and unsigned-morphology128update endpoints with identical source weights, codec, batch order, optimizer, learning rate and budget. Their old filenames are preserved.',
        initialization='Exactly previous morphology comparison shared Dice source, not its trained morphology endpoint. Reset identical AdamW.',
        limitations='Single seed42; historical16minute architecture. Fixed4096PCA. Test period was historically inspected; no claim of a new unseen test set or final dimensionality bound.')
    for name in ['joint_pca_basis.pt','training_states.pt']:(root/name).symlink_to((parent/name).resolve())
    (root/'test_states.pt').symlink_to((parent/'development_states.pt').resolve())
    shutil.copy2(parent/'training_order.npy',root/'training_order.npy');order=np.load(root/'training_order.npy')
    assert order.shape==(128,2)
    hashes=freeze_model_sources(root/'source_snapshot',project_root=project)
    for directory in ('train_dual','util'):
        for file in (project/directory).rglob('*.py'):
            rel=file.relative_to(project);p=root/'source_snapshot'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(file,p);hashes[str(rel)]=hashlib.sha256(p.read_bytes()).hexdigest()
    write(root/'source_snapshot/sha256.json',hashes);plan['source_hashes']=hashes;write(root/'plan.json',plan)
    write(root/'test_policy.json',dict(fixed_endpoint=128,test_evaluations_before_training_complete=0,configuration_fixed_before_training=True,test_only_reporting=True))
    model=JointPCAWindowVAE(state_dim=4096,window_size=16,**source_saved['model_config']).eval();model.load_cross_initial(source_saved['model'])
    model.state_codec.load_basis(torch.load(root/'joint_pca_basis.pt',map_location='cpu',mmap=True,weights_only=False))
    for name in ['dice_control','dice_morphology']:
        previous=torch.load(parent/name/'compressed4096/step0.pt',map_location='cpu',weights_only=False)
        assert all(torch.equal(v,previous['model'][k]) for k,v in source_saved['model'].items())
    decoder_modules=[getattr(model,name) for name in ['price_decoder','volume_decoder','volume_refinement']]
    assert not any(isinstance(m,torch.nn.modules.batchnorm._BatchNorm) or (isinstance(m,torch.nn.Dropout) and m.p>0) for module in decoder_modules for m in module.modules())
    norm=DualNormalizer(**{k:source_saved['config']['normalization'][k] for k in ('tick_size','price_scale')})
    source_data=Path(plan['data_source']);train=datasets(source_data,source_saved,'train');fit_indices=np.load(source_data/'fit_indices.npy')
    states=torch.load(root/'training_states.pt',map_location='cpu',mmap=True,weights_only=False)['states']
    parameters=[]
    for name,p in model.named_parameters():
        allowed=name.startswith(('price_decoder.','volume_decoder.','volume_refinement.'));p.requires_grad_(allowed)
        if allowed:parameters.append(p)
    frozen={k:v.clone() for k,v in model.state_dict().items() if k.startswith(('encoder.','fusion.'))}
    loss=SignedDifferenceDiceOrderBookLoss(source_saved['model_config'].get('quantity_scale',1.),DualLossConfig(**plan['loss']),
        dice_weight=plan['dice_weight'],epsilon=plan['dice_epsilon'],difference_weight=1.,lags=(1,4,16),huber_beta=1.)
    optimizer=torch.optim.AdamW(parameters,lr=plan['learning_rate'],weight_decay=plan['weight_decay'])
    def checkpoint(step):
        config=dict(source_saved['config'],loss={**plan['loss'],'volume_log':0.,'volume_linear':0.,'volume_tail':0.},
            quantity_objective=plan['quantity_objective'],difference_weight=1.,difference_lags=[1,4,16],difference_huber_beta=1.,
            dice_weight=plan['dice_weight'],dice_epsilon=plan['dice_epsilon'],evaluation_role='test',
            training_experiment=dict(seed=42,steps=128,batch_size=2,learning_rate=plan['learning_rate'],weight_decay=plan['weight_decay']))
        payload=dict(model={k:v for k,v in model.state_dict().items() if not k.startswith('state_codec.')},model_config=source_saved['model_config'],config=config,
            joint_pca_config=model.joint_pca_config,codec_file=str(root/'joint_pca_basis.pt'),codec_sha256=plan['codec_sha256'],step=step,
            optimizer=optimizer.state_dict(),source_hashes=hashes,source_checkpoint=str(source))
        torch.save(payload,root/('final.pt' if step==128 else f'step{step}.pt'))
    def evaluate(data,positions,raw_indices,latent_states,split,step):
        model.eval();metrics=DynamicsMetrics(norm.tick_size);counts=np.zeros(3,dtype='int64');sums={};truths=[];preds=[];sample_indices=[]
        with torch.inference_mode():
            for count,position in enumerate(positions,1):
                raw={k:v.unsqueeze(0) for k,v in data[int(raw_indices[position])].items()};b=norm.prepare(raw,'cpu')
                out=model.decode_state(latent_states[position:position+1],b['mask'],b['tick_norm'],b['times'])
                truth=raw['data'][0].numpy().astype('float64');pred=np.stack([norm.inverse_price(out['price_norm'],b)[0].numpy(),out['volume'][0].numpy()],-1);mask=b['mask'][0].numpy()
                metrics.update(truth,pred,mask);a=(truth[...,1]>=100)&mask;bb=(pred[...,1]>=100)&mask;counts+=[int((a&bb).sum()),int((~a&bb&mask).sum()),int((a&~bb).sum())]
                morphology,ms=quantity_morphology_loss(out['volume'],b['volume'],b['mask'],scales=(3,9,33),quantity_scale=loss.quantity_scale)
                difference,ds=signed_quantity_difference_loss(out['volume'],b['volume'],b['mask'],lags=(1,4,16),quantity_scale=loss.quantity_scale)
                terms=dict(morphology=float(morphology),quantity_dice=float(continuous_quantity_dice(out['volume'],b['volume'],b['mask'],quantity_scale=loss.quantity_scale)),
                    signed_difference=float(difference),**{'morphology_k'+k:float(v) for k,v in ms.items()},**{'signed_difference_lag'+k:float(v) for k,v in ds.items()})
                for k,v in terms.items():sums[k]=sums.get(k,0.)+v
                if split=='test' and position in (0,63,127):truths.append(truth);preds.append(pred);sample_indices.append(int(raw_indices[position]))
                if split=='test' and count%32==0:progress(phase='test_report',step=step,windows=count,total_windows=len(positions))
        d=metrics.finish();tp,fp,fn=map(int,counts);d.update(step=step,split=split,positions=list(map(int,positions)),
            threshold100=dict(tp=tp,fp=fp,fn=fn,recall=tp/(tp+fn) if tp+fn else None,precision=tp/(tp+fp) if tp+fp else None),shape_metrics={k:v/len(positions) for k,v in sums.items()})
        write(root/f'{split}_step{step}_{len(positions)}windows.json',d)
        if preds:np.savez_compressed(root/'test_profiles.npz',truth=np.stack(truths),prediction=np.stack(preds),indices=sample_indices)
        return d
    seen=plan['seen_training_positions']
    progress(phase='training_only_initial_check',test_accesses=0)
    initial_train=evaluate(train,seen,fit_indices,states,'train',0)
    checkpoint(0)
    for step in range(1,129):
        model.train();model.encoder.eval();model.fusion.eval();positions=order[step-1]
        rows=[train[int(fit_indices[i])] for i in positions];raw={k:torch.stack([row[k] for row in rows]) for k in rows[0]}
        b=norm.prepare(raw,'cpu');optimizer.zero_grad(set_to_none=True)
        out=model.decode_state(states[positions],b['mask'],b['tick_norm'],b['times']);terms=loss(out,b)
        if not bool(torch.isfinite(terms['loss'])):raise FloatingPointError('Nonfinite signed-shape objective')
        terms['loss'].backward()
        if step==1:
            assert all(p.grad is None for p in model.encoder.parameters())
            gradients={name:float(torch.sqrt(sum(p.grad.double().square().sum() for p in getattr(model,name).parameters() if p.grad is not None))) for name in ['price_decoder','volume_decoder','volume_refinement']}
            assert all(v>0 for v in gradients.values());write(root/'first_step_gradients.json',gradients)
            write(root/'actual_shape_contract.json',dict(raw_input=list(raw['data'].shape),continuous_state=list(out['market_state'].shape),
                price_output=list(out['price_norm'].shape),quantity_output=list(out['volume'].shape),window_minutes=16))
        grad=torch.nn.utils.clip_grad_norm_(parameters,1.,error_if_nonfinite=True);optimizer.step()
        if step==1 or step%8==0:progress(phase='training',step=step,total_steps=128,loss=float(terms['loss'].detach()),
            quantity_dice=float(terms['quantity_dice'].detach()),signed_difference=float(terms['quantity_signed_difference'].detach()),gradient_norm=float(grad),test_accesses=0)
        if step in (32,64,128):checkpoint(step);evaluate(train,seen,fit_indices,states,'train',step)
    assert all(torch.equal(v,model.state_dict()[k]) for k,v in frozen.items())
    write(root/'training_complete.json',dict(step=128,elapsed_seconds=time.monotonic()-started,test_accesses=0,endpoint_selected_before_training=True))
    # First test-data access in this run, after the final weights were saved.
    write(root/'test_access.json',dict(first_access_after_saved_final_checkpoint=True,training_step=128,elapsed_seconds=time.monotonic()-started))
    test_cache=torch.load(root/'test_states.pt',map_location='cpu',mmap=True,weights_only=False)
    test=DualWindowDataset(asset='BTCUSDT',npz_dir=source_data/'data/BTCUSDT.npz',start=plan['test_period'][0],end=plan['test_period'][1],levels=2048,window_size=16,stride=16,time_unit_seconds=60)
    assert np.array_equal(test_cache['indices'],np.array(plan['test_indices']))
    final=evaluate(test,list(range(128)),test_cache['indices'],test_cache['states'],'test',128);write(root/'final_test_evaluation.json',final)
    comparison={'signed_difference':final}
    for name,path in [('dice_control',parent/'dice_control/compressed4096/final_evaluation.json'),('unsigned_morphology',parent/'dice_morphology/compressed4096/final_evaluation.json'),('initial',parent/'common/compressed4096/initial_evaluation.json')]:
        d=json.loads(path.read_text());d.update(split='test',reused_from=str(path));comparison[name]=d
    write(root/'comparison.json',comparison)
    write(root/'verification.json',dict(encoder_and_fusion_bitwise_unchanged=True,initial_weights_match_both_controls=True,
        same_training_order=np.array_equal(order,np.load(parent/'training_order.npy')),test_only_after_training=True,
        no_decoder_batchnorm_or_stochastic_dropout=True,source_checkpoint_sha256_unchanged=hashlib.sha256(source.read_bytes()).hexdigest()==plan['source_sha256']))
    write(root/'status.json',dict(state='complete',steps=128,elapsed_seconds=time.monotonic()-started));progress(phase='complete')


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--parent',type=Path,required=True);a=p.parse_args()
    try:run(a.root,a.parent)
    except BaseException as e:
        if a.root.exists():write(a.root/'failure.json',dict(error=repr(e)))
        raise
