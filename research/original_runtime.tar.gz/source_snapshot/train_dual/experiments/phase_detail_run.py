"""Matched quantity-decoder controls, with configurable Encoder training."""
import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import numpy as np
import torch
from torch.utils.data import DataLoader

from model.decoders.phase_volume import PhaseDetailVolumeDecoder
from model.losses.probability_book import ProbabilityBookLoss
from train_dual.experiments.full_window_run import dataset
from train_dual.experiments.local_quant_reconstruction import CacheWindows
from train_dual.experiments.long_worker import atomic_json, evaluate
from train_dual.experiments.probability_eval import evaluate_probability
from train_dual.experiments.unified_8192_run import call, write_profiles
from train_dual.experiments.window_state_pilot import strict_precision
from train_dual.util.checkpoint import atomic_save, freeze_sources, load_for_inference, seed_everything, source_hashes
from train_dual.util.phase_training import freeze_for_quantity_training, restore_original_adam, tensor_digest

LABELS={'off':'原数量Decoder','shared':'区域内统一修正','independent':'区域内16档独立修正'}
TERMINAL={'complete','failed','stopped'}


def read(path, default=None):
    return json.loads(path.read_text()) if path.exists() else default


def prepare(parent):
    project=Path(__file__).resolve().parents[2]; parent=parent.resolve()
    root=project/'recons'/('phase_detail_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
    root.mkdir()
    for name in ['data','logs']:(root/name).mkdir()
    for name in ['train_indices.npy','val_indices.npy','seen_indices.npy']:
        os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    os.link(parent/'baseline/step1024.pt',root/'initial.pt')
    os.link(parent/'baseline/step1024_evaluation.json',root/'initial_expected.json')
    old=read(parent/'plan.json')
    plan={key:old[key] for key in ['train','development','independent_test_untouched','normalization','model_config','objective']}
    plan.update(parent=str(parent),experiment='Frozen Encoder/price: within-region quantity residual controls',
        labels=LABELS,lanes={k:dict(detail_mode=k) for k in LABELS},seed=42,
        window_size=256,stride=256,input_shape=[1,256,2,2048,2],latent_shape=[1,64,128],output_shape=[1,256,2,2048],
        fit_windows=1024,seen_windows=8,evaluation_windows=16,batch_size=1,accumulation=4,
        steps=2048,checkpoints=[128,512,1024,2048],max_seconds=14400,
        lr=old['lr'],weight_decay=old['weight_decay'],clip_grad=1.,beta=0.,sample=False,
        freeze=['encoder','price_decoder'],loss_mode='shape_mass',add_wasserstein=False,add_multiscale=False,
        source_checkpoint='probability_shape_20261026_181628/baseline/step1024.pt',
        initialization='Same predeclared checkpoint as decoder diagnosis/prototype, not a new best-model selection. Original AdamW moments restored in original name/order; appended detail head starts zero with fresh state. Sampler restarts seed42 equally.',
        precision='BF16 neural training/FP32 loss; FP32 evaluation; TF32 disabled',
        gpu_roles={'2':'off training','3':'shared training','4':'independent training','5':'common FP32 evaluator and reconstruction previews'},
        factors='detail_mode only. All three allocate 4112 additional parameters; off disables them; shared intentionally has lower effective functional freedom.',
        control_contract='Same window indices/order, source weights+original Adam states, objective, LR, clipping, batch, seed42 and2048updates. Encoder+price parameters and buffers frozen and hashed. Same unique8192 Z; no encoder feature bypass; predicted-price geometry only.',
        primary='Raw quantity RMSE and exact-location100BTC precision/recall/false positives at fixed2048 endpoint; retain all checkpoints and report10BTC,dynamics,fineKL/W1 and price preservation. No posthoc metric replacement.',
        selection='Exploratory seed42 comparison on reused2025Q1 development, not independent-test evidence.2025Q2 and2026 untouched.',
        next_stage='Joint Encoder-unfreeze and synthetic moving-peak fitting are separate follow-up cohorts; not silently combined with this architecture factor.',
        authorization='User explicitly requested training after the three-control decoder design. Bounded2048update cohort, four-hour ceiling, GPU2–5 only.')
    assert len(np.load(root/'train_indices.npy'))==1024
    atomic_json(root/'plan.json',plan)
    atomic_json(root/'status.json',dict(state='prepared'))
    atomic_json(root/'data_contract.json',dict(training_indices=np.load(root/'train_indices.npy').tolist(),
        seen_indices=np.load(root/'seen_indices.npy').tolist(),development_indices=np.load(root/'val_indices.npy').tolist(),
        input_shape=plan['input_shape'],latent_shape=plan['latent_shape'],output_shape=plan['output_shape'],
        training_indices_sha256=hashlib.sha256((root/'train_indices.npy').read_bytes()).hexdigest()))
    (root/'README.md').write_text('完整256分钟、每侧2048档、唯一64×128 latent。三组只改变数量Decoder细节模式；Encoder与价格Decoder冻结。\n'
        '相同1024训练窗，8训练诊断窗，16个2025Q1开发窗；2048更新，有效batch4，seed42。GPU2–4训练，GPU5统一评估。\n'
        '已有Huber/log/Top16/fineKL/mass损失保留，不加入W1或多尺度KL。新增头全零，原Adam状态按原参数顺序恢复。\n'
        '先直接检验真实订单簿上的读出增量；合成移动峰及Encoder解冻属于后续独立实验，本轮不混入。\n')
    freeze_sources(root/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'
        f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 CUDA_DEVICE_ORDER=PCI_BUS_ID\n'
        f'cd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m train_dual.experiments.phase_detail_run "{remote}"\n')
    from train_dual.experiments.phase_detail_report import render
    render(root)
    Path('/tmp/phase_detail_path').write_text(str(root)); print(root,flush=True)


def make_criterion(plan):
    return ProbabilityBookLoss(plan['normalization']['quantity_scale'],mode='shape_mass',
        add_wasserstein=False,add_multiscale=False,**plan['objective'])


def worker(root,lane):
    torch.set_num_threads(4); seed_everything(42); strict_precision()
    plan=read(root/'plan.json'); folder=root/lane; folder.mkdir(exist_ok=True); started=time.monotonic()
    spec=plan['lanes'][lane];mode=spec['detail_mode'];train_encoder=spec.get('train_encoder',False)
    frozen_names=spec.get('freeze',plan['freeze'])
    initial=torch.load(root/'initial.pt',map_location='cpu',weights_only=False)
    model,norm=load_for_inference(root/'initial.pt','cuda:0')
    if any(getattr(model,'gradient_route_config',{}).values()):raise ValueError('Source must use full original routes')
    original_names=[name for name,_ in model.named_parameters()]
    old=model.volume_decoder
    new=PhaseDetailVolumeDecoder(detail_mode=mode,**plan['model_config']).to('cuda:0')
    missing,unexpected=new.load_state_dict(old.state_dict(),strict=False)
    assert missing==['phase_head.weight','phase_head.bias'] and not unexpected
    model.volume_decoder=new
    freeze_for_quantity_training(model,train_encoder=train_encoder)
    frozen={name:tensor_digest(getattr(model,name)) for name in frozen_names}
    initial_encoder_digest=tensor_digest(model.encoder)
    opt,param_names=restore_original_adam(model,initial['optimizer'],original_names,plan['lr'],plan['weight_decay'])
    train_original=dataset(root,'train');ti=np.load(root/'train_indices.npy');train=CacheWindows(train_original,ti)
    raw={k:v.unsqueeze(0) for k,v in train[0].items()};b=norm.prepare(raw,'cuda:0')
    assert list(raw['data'].shape)==plan['input_shape']
    model.eval();old.eval()
    with torch.no_grad(),torch.autocast('cuda',dtype=torch.bfloat16):
        model.volume_decoder=old;reference=call(model,b,False)
        model.volume_decoder=new;candidate=call(model,b,False)
        for key in ['volume','price_norm','z']:
            torch.testing.assert_close(reference[key],candidate[key],rtol=0,atol=0)
    atomic_json(folder/'initial_parity.json',dict(passed=True,quantity_max_abs_delta=0.,price_max_abs_delta=0.,latent_max_abs_delta=0.,
        raw_input=list(raw['data'].shape),latent=list(candidate['z'].shape),quantity=list(candidate['volume'].shape),missing_checkpoint_keys=missing,
        frozen_digests=frozen,initial_encoder_digest=initial_encoder_digest,optimizer_original_groups=1,optimizer_new_groups=1,original_moment_tensors=sum(len(state) for state in opt.state.values())))
    del old,reference,candidate,raw,b,initial
    loader=DataLoader(train,batch_size=1,shuffle=True,num_workers=2,persistent_workers=True,pin_memory=True,generator=torch.Generator().manual_seed(42))
    iterator=iter(loader);criterion=make_criterion(plan);hashes=source_hashes();exposures=np.zeros(len(train),dtype=np.int64)
    atomic_json(folder/'trainable_modules.json',{name:sum(p.numel() for p in getattr(model,name).parameters() if p.requires_grad) for name in ['encoder','price_decoder','volume_decoder']})
    # Preserve the original normalization/config metadata, with explicit new architecture dispatch.
    source_config=torch.load(root/'initial.pt',map_location='cpu',weights_only=False)['config']
    def save(step):
        actual={name:tensor_digest(getattr(model,name)) for name in frozen_names}
        if actual!=frozen:raise RuntimeError('Frozen module changed')
        atomic_json(folder/f'step{step}_frozen_audit.json',dict(passed=True,digests=actual))
        value=dict(format_version=1,model=model.state_dict(),unified_vae_config=plan['model_config'],
            phase_decoder_config=dict(detail_mode=mode),config=dict(source_config,loss_family='probability',loss=dict(plan['objective'],mode='shape_mass',add_wasserstein=False,add_multiscale=False)),
            step=step,lane=lane,beta=0.,training_sample=False,freeze=frozen_names,train_encoder=train_encoder,optimizer=opt.state_dict(),optimizer_parameter_names=param_names,
            source_hashes=hashes,torch_rng_state=torch.get_rng_state(),cuda_rng_state=torch.cuda.get_rng_state_all(),
            sampler_generator_state=loader.generator.get_state(),epoch_boundary=step*plan['accumulation']%len(train)==0,
            training_data=dict(exposure_counts=exposures.copy(),windows=len(train),epochs_equivalent=step*plan['accumulation']/len(train)))
        atomic_save(value,folder/f'step{step}.pt')
    save(0)
    inline_eval=plan.get('inline_evaluation',False)
    if inline_eval:
        val_original=dataset(root,'val');vi=np.load(root/'val_indices.npy')
        val=CacheWindows(val_original,vi);seen=CacheWindows(train_original,np.load(root/'seen_indices.npy'))
        evaluate_inline(root,folder,0,model,norm,val,seen,val_original,vi,criterion)
    atomic_json(folder/'status.json',dict(state='training',step=0))
    for step in range(1,plan['steps']+1):
        if time.monotonic()-started>plan['max_seconds']:raise TimeoutError('Four-hour training ceiling')
        model.train()
        if not train_encoder:model.encoder.eval()
        model.price_decoder.eval();opt.zero_grad(set_to_none=True)
        record={};order=[]
        for micro in range(plan['accumulation']):
            try:raw=next(iterator)
            except StopIteration:iterator=iter(loader);raw=next(iterator)
            pos=int(raw['cache_position'][0]);exposures[pos]+=1;order.append(int(ti[pos]))
            assert list(raw['data'].shape)==plan['input_shape'];b=norm.prepare(raw,'cuda:0')
            with torch.autocast('cuda',dtype=torch.bfloat16):out=call(model,b,False)
            assert list(out['z'].shape)==plan['latent_shape'] and list(out['volume'].shape)==plan['output_shape']
            values=criterion(out,b,beta=0.)
            if not bool(torch.isfinite(values['loss'])):raise FloatingPointError('Nonfinite loss')
            (values['loss']/plan['accumulation']).backward()
            for key,value in values.items():record[key]=record.get(key,0.)+float(value.detach())/plan['accumulation']
            if step==1 and micro==0:atomic_json(folder/'actual_shape_contract.json',dict(raw_input=list(raw['data'].shape),latent=list(out['z'].shape),price_output=list(out['price_norm'].shape),quantity_output=list(out['volume'].shape),posterior_count=1,encoder_skip=False,sample=False,trainable='encoder and volume_decoder' if train_encoder else 'volume_decoder only'))
        if step==1:
            gradients={name:float(p.grad.float().norm()) if p.grad is not None else None for name,p in model.named_parameters()}
            for name in frozen_names:
                module=getattr(model,name)
                if any(p.grad is not None for p in module.parameters()):raise RuntimeError(f'Frozen module has gradient:{name}')
            if mode!='off' and not gradients['volume_decoder.phase_head.weight']>0:raise RuntimeError('Detail head has no gradient')
            if train_encoder and not any(v is not None and v>0 for n,v in gradients.items() if n.startswith('encoder.')):
                raise RuntimeError('Unfrozen Encoder has no gradient')
            atomic_json(folder/'first_step_gradient_norms.json',gradients)
            atomic_json(folder/'first_step_data.json',dict(training_indices=order,losses=record))
        grad=torch.nn.utils.clip_grad_norm_(model.parameters(),plan['clip_grad'],error_if_nonfinite=True);opt.step()
        if step==1:
            encoder_changed=tensor_digest(model.encoder)!=initial_encoder_digest
            price_unchanged=tensor_digest(model.price_decoder)==frozen['price_decoder']
            if encoder_changed!=train_encoder or not price_unchanged:
                raise RuntimeError('First optimizer update violated freeze/unfreeze contract')
            atomic_json(folder/'first_update_audit.json',dict(passed=True,encoder_changed=encoder_changed,
                encoder_expected_trainable=train_encoder,price_parameters_unchanged=price_unchanged,
                detail_weight_norm=float(model.volume_decoder.phase_head.weight.detach().float().norm())))
        if step==1 or step%8==0:
            row=dict(step=step,total=plan['steps'],phase='encoder_and_quantity' if train_encoder else 'quantity_decoder_only',elapsed_seconds=time.monotonic()-started,
                gradient_norm=float(grad),reserved_gib=torch.cuda.memory_reserved()/2**30,epochs_equivalent=float(exposures.mean()),
                unique_windows_seen=int((exposures>0).sum()),training_indices=order,**record)
            atomic_json(folder/'progress.json',row)
            with (folder/'progress.jsonl').open('a') as stream:stream.write(json.dumps(row)+'\n')
            print(json.dumps(row),flush=True)
        if step in plan['checkpoints']:
            save(step)
            if inline_eval:evaluate_inline(root,folder,step,model,norm,val,seen,val_original,vi,criterion)
    atomic_json(folder/'status.json',dict(state='complete',step=step,elapsed_seconds=time.monotonic()-started))


def evaluate_inline(root,folder,step,model,norm,val,seen,original,indices,criterion):
    """Evaluate each factorial worker on its own GPU, with identical FP32 code."""
    atomic_json(folder/'evaluation_status.json',dict(state='evaluating',step=step))
    result=evaluate(model,norm,val,len(val),'cuda:0')
    if step==0:
        expected=read(root/'initial_expected.json')['result']
        delta={k:abs(result['metrics'][k]['rmse']-expected['metrics'][k]['rmse']) for k in ['price_usdt','quantity_btc']}
        atomic_json(folder/'initial_replay.json',delta)
        if max(delta.values())>1e-3:raise RuntimeError(f'Initial evaluator replay differs:{delta}')
    seen_result=evaluate(model,norm,seen,len(seen),'cuda:0')
    probability=dict(development=evaluate_probability(model,norm,val,len(val),'cuda:0',criterion),seen=evaluate_probability(model,norm,seen,len(seen),'cuda:0',criterion))
    atomic_json(folder/f'step{step}_evaluation.json',dict(result=result))
    atomic_json(folder/f'step{step}_seen_evaluation.json',dict(result=seen_result))
    atomic_json(folder/f'step{step}_probability.json',probability)
    write_profiles(root,folder,step,model,norm,original,indices)
    from train_dual.experiments.phase_detail_report import preview
    preview(root,folder.name,step)
    atomic_json(folder/'evaluation_status.json',dict(state='complete',step=step))


def evaluator(root):
    torch.set_num_threads(4);seed_everything(42);strict_precision();plan=read(root/'plan.json');started=time.monotonic()
    train=dataset(root,'train');dev=dataset(root,'val');vi=np.load(root/'val_indices.npy');si=np.load(root/'seen_indices.npy')
    val=CacheWindows(dev,vi);seen=CacheWindows(train,si);criterion=make_criterion(plan)
    jobs=[(step,lane) for step in [0,*plan['checkpoints']] for lane in LABELS];done=set()
    while len(done)<len(jobs):
        if time.monotonic()-started>plan['max_seconds']:raise TimeoutError('Four-hour evaluator ceiling')
        available=[(s,l) for s,l in jobs if (s,l) not in done and (root/l/f'step{s}.pt').exists()]
        for step,lane in available:
            folder=root/lane
            atomic_json(root/'evaluator_status.json',dict(state='evaluating',lane=lane,step=step,completed=len(done),total=len(jobs)))
            if step==0 and lane!='off':
                reference=root/'off/step0_evaluation.json'
                if not reference.exists():continue
                # Zero heads and original weights are independently verified in each worker.
                for suffix in ['evaluation.json','seen_evaluation.json','probability.json']:
                    os.link(root/'off'/f'step0_{suffix}',folder/f'step0_{suffix}')
                atomic_json(folder/'initial_metrics_provenance.json',dict(shared_from='off/step0',reason='Exact initial per-worker parity and identical original weights; no optimizer update'))
            else:
                model,norm=load_for_inference(folder/f'step{step}.pt','cuda:0')
                result=evaluate(model,norm,val,len(val),'cuda:0');seen_result=evaluate(model,norm,seen,len(seen),'cuda:0')
                if step==0:
                    expected=read(root/'initial_expected.json')['result']
                    delta={k:abs(result['metrics'][k]['rmse']-expected['metrics'][k]['rmse']) for k in ['price_usdt','quantity_btc']}
                    atomic_json(root/'initial_replay.json',delta)
                    if max(delta.values())>1e-3:raise RuntimeError(f'Initial evaluator replay differs:{delta}')
                probability=dict(development=evaluate_probability(model,norm,val,len(val),'cuda:0',criterion),seen=evaluate_probability(model,norm,seen,len(seen),'cuda:0',criterion))
                atomic_json(folder/f'step{step}_evaluation.json',dict(result=result))
                atomic_json(folder/f'step{step}_seen_evaluation.json',dict(result=seen_result))
                atomic_json(folder/f'step{step}_probability.json',probability)
                write_profiles(root,folder,step,model,norm,dev,vi)
                from train_dual.experiments.phase_detail_report import preview
                preview(root,lane,step)
                del model;torch.cuda.empty_cache()
            done.add((step,lane))
            atomic_json(root/'evaluation_progress.json',dict(completed=len(done),total=len(jobs),last_lane=lane,last_step=step))
        states={lane:read(root/lane/'status.json',{}).get('state') for lane in LABELS}
        if all(state in TERMINAL for state in states.values()) and not available:
            missing=[(s,l) for s,l in jobs if (s,l) not in done]
            if missing:raise RuntimeError(f'Missing training checkpoints:{missing}')
        if not available:time.sleep(5)
    atomic_json(root/'evaluator_status.json',dict(state='complete',completed=len(done),total=len(jobs),elapsed_seconds=time.monotonic()-started))


def campaign(root):
    plan=read(root/'plan.json');started=time.monotonic();children=[]
    def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        rows=subprocess.check_output(['nvidia-smi','--query-gpu=index,memory.free','--format=csv,noheader,nounits'],text=True).splitlines()
        free={int(row.split(',')[0]):int(row.split(',')[1]) for row in rows}
        if any(free.get(g,0)<30000 for g in [2,3,4,5]):raise RuntimeError(f'Required GPUs not free:{free}')
        roles=plan.get('gpu_workers',[(2,'off'),(3,'shared'),(4,'independent'),(5,'evaluate')])
        for gpu,role in roles:
            env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),CUDA_DEVICE_ORDER='PCI_BUS_ID',PYTHONPATH=str(root/'source_snapshot'))
            args=[sys.executable,'-u','-m','train_dual.experiments.phase_detail_run',str(root)]
            args+=['--evaluate'] if role=='evaluate' else ['--lane',role]
            with (root/'logs'/f'{role}.log').open('ab',buffering=0) as log:
                child=subprocess.Popen(args,cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            children.append((role,gpu,child))
        atomic_json(root/'status.json',dict(state='running',children=[dict(role=l,gpu=g,pid=p.pid) for l,g,p in children]))
        while any(child.poll() is None for _,_,child in children):
            if time.monotonic()-started>plan['max_seconds']:raise TimeoutError('Four-hour cohort ceiling')
            failures={role:child.returncode for role,_,child in children if child.poll() not in [None,0]}
            if failures:raise RuntimeError(f'Child failed:{failures}')
            from train_dual.experiments.phase_detail_report import render
            render(root);time.sleep(10)
        failures={role:child.returncode for role,_,child in children if child.returncode!=0}
        if failures:raise RuntimeError(f'Child failed:{failures}')
        atomic_json(root/'status.json',dict(state='complete',elapsed_seconds=time.monotonic()-started))
    except BaseException as error:
        atomic_json(root/'status.json',dict(state='failed',error=repr(error),elapsed_seconds=time.monotonic()-started));raise
    finally:
        for _,_,child in children:
            if child.poll() is None:os.killpg(child.pid,signal.SIGTERM)
        from train_dual.experiments.phase_detail_report import render
        render(root)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('root',type=Path)
    parser.add_argument('--prepare',action='store_true');parser.add_argument('--lane');parser.add_argument('--evaluate',action='store_true')
    args=parser.parse_args();root=args.root.resolve()
    try:
        if args.prepare:prepare(root)
        elif args.lane:worker(root,args.lane)
        elif args.evaluate:evaluator(root)
        else:campaign(root)
    except BaseException as error:
        if args.lane:atomic_json(root/args.lane/'status.json',dict(state='failed',error=repr(error)))
        elif args.evaluate:atomic_json(root/'evaluator_status.json',dict(state='failed',error=repr(error)))
        raise
