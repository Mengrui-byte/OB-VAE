"""Publish frozen/adapted grouped-PCA books and their paired error tables."""

import argparse
import json
from pathlib import Path

import numpy as np

from train_dual.experiments.book_stem_viewer import build
from train_dual.util.checkpoint import freeze_sources


def render(root,stage):
    plan=json.loads((root/'plan.json').read_text());fit=json.loads((root/'pca_fit.json').read_text())
    audit=json.loads((root/'pca_qr_audit.json').read_text());ref=json.loads((root/'source_reference.json').read_text())['result']
    data=root/('report_'+stage);data.mkdir(exist_ok=False)
    with np.load(root/'frozen_source/profiles.npz') as source:
        arrays={k:source[k] for k in ('truth','mask','time','indices')};arrays['source']=source['prediction']
    prefix='frozen_' if stage=='frozen' else ''
    rows={}
    for lane in ('reference','d1024','d512','d256'):
        rows[lane]={key:json.loads((root/lane/(key+'_evaluation.json')).read_text()) for key in ('frozen',stage)}
        if lane=='reference':continue
        with np.load(root/lane/(prefix+'profiles.npz')) as p:
            assert np.array_equal(p['truth'],arrays['truth']) and np.array_equal(p['mask'],arrays['mask'])
            assert p['market_state'].shape==(3,int(lane[1:]))
            arrays[lane]=p['prediction']
        (data/(lane+'_checkpoint.pt')).symlink_to(root/lane/(stage+'.pt'))
        if (root/lane/'market_states.npz').exists():(data/(lane+'_market_states.npz')).symlink_to(root/lane/'market_states.npz')
    np.savez_compressed(data/'profiles.npz',**arrays)
    config=[dict(key='truth',label='真实订单簿',color='#2563eb'),dict(key='source',label='冻结原cross参考',color='#ef4444')]
    config += [dict(key=lane,label=f'{lane[1:]}维PCA · '+('原生成器' if stage=='frozen' else '适配生成器'),color=color)
               for lane,color in zip(('d1024','d512','d256'),('#16a34a','#9333ea','#f59e0b'))]
    info=dict(seed=42,common_step=0 if stage=='frozen' else plan['steps'],default_model=2,viewer_variants=config,
              step_note='分组PCA直接压缩全窗口；'+('当前为冻结生成器阶段。' if stage=='frozen' else '生成器适配256步；PCA与编码器固定。'),
              comparison_label='查看PCA保真度、适配前后指标与状态向量',plan=plan,pca_fit=fit,orthogonal_basis=audit,results=rows)
    (data/'comparison.json').write_text(json.dumps(info,ensure_ascii=False,indent=2))
    def values(result):
        m=result['metrics'];v=[f"{m['price_usdt']['rmse']:.3f}",f"{m['quantity_btc']['rmse']:.4f}",f"{m['spatial_slope_64_levels_usdt_per_level']['rmse']:.6f}",f"{m['temporal_mid_1_minutes_usdt_per_minute']['rmse']:.3f}",f"{result['thresholds']['100']['recall']:.1%}"]
        return ''.join('<td>'+x+'</td>' for x in v)
    table='<table><tr><th>方案</th><th>价格RMSE/USDT</th><th>数量RMSE/BTC</th><th>64档斜率RMSE</th><th>分钟变化RMSE</th><th>≥100 BTC召回率</th></tr>'
    table+='<tr><td>冻结原cross</td>'+values(ref)+'</tr>'
    for lane,label in [('reference','未压缩对照'),('d1024','1024维'),('d512','512维'),('d256','256维')]:
        table+='<tr><td>'+label+' · 冻结生成器</td>'+values(rows[lane]['frozen']['result'])+'</tr>'
        if stage=='final':table+='<tr><td>'+label+' · 适配256步</td>'+values(rows[lane]['final']['result'])+'</tr>'
    table+='</table>'
    allocations='<table><tr><th>最终窗口向量</th><th>global维度</th><th>local维度</th><th>global训练方差保留</th><th>local训练方差保留</th></tr>'
    for d,v in audit['dimensions'].items():allocations+=f"<tr><td>[B,{d}]</td><td>{v['global_components']}</td><td>{v['local_components']}</td><td>{v['global_variance_retained']:.2%}</td><td>{v['local_variance_retained']:.2%}</td></tr>"
    allocations+='</table>'
    page='''<!doctype html><meta charset=utf-8><title>直接PCA窗口状态实验</title><style>body{font:17px system-ui;max-width:1450px;margin:30px auto;padding:0 20px;color:#162235}p{line-height:1.8}table{border-collapse:collapse;width:100%;text-align:right}th,td{padding:10px;border:1px solid #d8dfe9}a{color:#2563eb}</style><h1>绕过早期聚合：全窗口分组PCA</h1><p><a href=../>打开逐档挂单线图</a> · <a href=../pca.html>实时进度与最新验证</a> · <a href=comparison.json>完整指标和配置</a></p><p>在8192个训练窗口上，对原cross生成器实际读取的global/local序列分组标准化和PCA，直接形成一个[B,D]窗口向量。没有16-token聚合。全部标准化、维数配额与PCA只用2022–2024训练期拟合。</p>'''+allocations
    page+='<p>保留方差是在分组标准化后的latent空间内计算，不是原始订单簿信息保留比例。global配额按训练期99%方差目标确定。数值SVD基经QR重新正交化后再编码；历史拟合结果完整保留。</p><h2>原始单位重建误差</h2>'+table
    page+='<p>验证使用相同128个2025年一季度开发窗口，严格FP32，单种子42。每组适配阶段的物理batch16、有效batch64，共256次更新；只更新价格/数量生成器，源编码器、源cross融合和PCA固定。源posterior的常量KL不参与生成器适配。</p>'
    if stage=='frozen':page+='<p><b>当前页面只展示阶段A：冻结生成器。</b>阶段B正在运行，完成后会自动切换到适配后的重建。</p>'
    elif (root/'comparison.json').exists():
        d=json.loads((root/'comparison.json').read_text());page+='<p>满足预定保真阈值的最小测试维度：冻结阶段 '+str(d['minimum_dimension']['frozen'])+'；适配阶段 '+str(d['minimum_dimension']['final'])+'。None表示本轮没有通过全部阈值，不是信息论上的不可能。</p>'
        page+='<p>阈值相对冻结原cross：价格/数量RMSE退化≤10%，斜率/分钟变化误差退化≤15%，≥100 BTC召回下降≤5个百分点。</p>'
    if stage=='final':
        page+='<h2>窗口属性线性探针（开发R²）</h2><table><tr><th>属性</th><th>1024维</th><th>512维</th><th>256维</th></tr>'
        probes={lane:json.loads((root/lane/'state_probe.json').read_text()) for lane in ('d1024','d512','d256')}
        for feature in ('window_return_bps','realized_return_rms_bps','log_mean_bid_depth','log_mean_ask_depth','mean_imbalance_10','large_quantity_share'):
            page+='<tr><td>'+feature+'</td>'+''.join(f"<td>{probes[lane]['features'][feature]['r2']:.4f}</td>" for lane in probes)+'</tr>'
        page+='</table><p>512个训练窗口拟合探针和标准化，128个开发窗口评估。属性是窗口内已有统计，不是未来预测能力。</p><p>'+' · '.join(f'<a href="{lane}_market_states.npz">下载{lane[1:]}维窗口向量</a>' for lane in probes)+'</p>'
    page+='<p>窗口状态只能在窗口结束时使用。开发验证期已用于选型；最终独立测试期未使用。本页没有声明有损PCA可以完整保留任意输入的全部信息。</p>'
    (data/'index.html').write_text(page)
    viewer=root/('viewer_'+stage);freeze_sources(viewer/'source_snapshot');build(data,viewer)
    p=viewer/'index.html';text=p.read_text().replace('逐档挂单线图：真实订单簿与模型重建','全窗口PCA状态：订单簿重建')
    text=text.replace('<div class="controls">','<p><b>最终为单个 [B,D] 窗口向量。</b>这里直接压缩原global/local，已取消16-token聚合；当前阶段：'+('冻结生成器' if stage=='frozen' else '生成器适配256步')+'。</p><div class="controls">');p.write_text(text)
    for name in ('pca.html','pca_progress.json'):(viewer/name).symlink_to(root/'public'/name)
    return viewer


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--stage',choices=['frozen','final'],required=True);a=p.parse_args();print(render(a.root,a.stage))
