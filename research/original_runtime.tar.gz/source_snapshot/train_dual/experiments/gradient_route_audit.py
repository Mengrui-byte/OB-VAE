"""Measure the two quantity-gradient routes without changing model values."""
import math
import torch
from torch.nn import functional as F
from train_dual.experiments.gradient_audit import add,cos,flatnorm,price_component
from train_dual.experiments.unified_8192_run import call


def inspect_routes(model,batch,criterion,return_reference=False):
 out=call(model,batch,False);v=criterion(out,batch)
 if 'quantity_objective' in v:
  lp,lq=v['price_objective'],v['quantity_objective']
 else:
  lp=price_component(out,batch)
  e=(out['volume'].float()-batch['volume'].float())/criterion.quantity_scale
  point=F.huber_loss(e,torch.zeros_like(e),reduction='none');idx=batch['volume'].masked_fill(~batch['mask'],-torch.inf).topk(16,-1).indices;valid=batch['mask'].gather(-1,idx)
  pair_q=(point.gather(-1,idx)*valid).sum()/valid.sum().clamp_min(1)
  lq=criterion.quantity_weight*(v['quantity']+criterion.log_weight*v['quantity_log'])+criterion.pair_weight*pair_q+criterion.shape_weight*v['quantity_shape_kl']+criterion.mass_weight*v['quantity_mass']
 names,params=zip(*model.named_parameters())
 gp=[g.detach().cpu() if g is not None else None for g in torch.autograd.grad(lp,params,allow_unused=True,retain_graph=True)]
 gq=[g.detach().cpu() if g is not None else None for g in torch.autograd.grad(lq,params,allow_unused=True)]
 groups={}
 for prefix in ['encoder','encoder.frame','encoder.patch','encoder.mu','price_decoder','volume_decoder','volume_decoder.geometry']:
  ii=[i for i,n in enumerate(names) if n.startswith(prefix+'.')];p=[gp[i] for i in ii];q=[gq[i] for i in ii];pn,qn=flatnorm(p),flatnorm(q)
  groups[prefix]=dict(price_gradient_l2=pn,quantity_gradient_l2=qn,cosine=cos(p,q),quantity_to_price_ratio=qn/pn if pn>1e-25 else None,total_gradient_l2=flatnorm(add(p,q)))
 result=dict(groups=groups,price_objective=float(lp.detach()),quantity_objective=float(lq.detach()),routes=model.gradient_route_config,latent_shape=list(out['z'].shape),price_output_shape=list(out['price_norm'].shape),quantity_output_shape=list(out['volume'].shape),nonfinite_gradients=sum(int((~torch.isfinite(g)).sum()) for g in [*gp,*gq] if g is not None))
 if return_reference:return result,dict(price=out['price_norm'].detach().cpu(),volume=out['volume'].detach().cpu(),z=out['z'].detach().cpu(),price_gradients=gp)
 return result
