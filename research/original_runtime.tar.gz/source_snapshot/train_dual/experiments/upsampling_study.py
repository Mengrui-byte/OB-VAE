"""CPU-only spectra and bounded synthetic upsampler capacity comparison."""
import argparse
from datetime import datetime
import json
from pathlib import Path
import time

import numpy as np
import torch
from torch.nn import functional as F

from model.experimental.upsampling_probe import SpatialUpsamplingProbe
from train_dual.experiments.long_worker import atomic_json
from train_dual.util.checkpoint import freeze_sources,seed_everything


def spectral_diagnostics(parent,output):
    plan=json.loads((parent/'plan.json').read_text());step=max(n for n in plan['checkpoints'] if all((parent/lane/f'step{n}_profiles.npz').exists() for lane in plan['lanes']))
    with np.load(parent/'source_profiles.npz') as d:mask=d['mask'];truth=d['truth'][...,1].astype(np.float64);source=d['prediction'][...,1].astype(np.float64)
    books={'truth':truth,'old_reference':source}
    for lane in plan['lanes']:
        with np.load(parent/lane/f'step{step}_profiles.npz') as d:np.testing.assert_array_equal(d['mask'],mask);books[lane]=d['prediction'][...,1].astype(np.float64)
    full=mask.all(-1);N=truth.shape[-1];hann=np.hanning(N);energy_norm=np.mean(hann**2);freq=np.fft.rfftfreq(N);weights=np.full(N//2+1,2.);weights[[0,-1]]=1.
    records={};saved={}
    for key,q in books.items():
        v=q[full];spec={}
        for transform,a in [('raw',v),('log1p',np.log1p(v))]:
            a=(a-a.mean(-1,keepdims=True))*hann
            f=np.fft.rfft(a,axis=-1,norm='ortho');power=(np.abs(f)**2*weights).mean(0)/N/energy_norm
            total=power[1:].sum();high=power[freq>1/32].sum()
            spec[transform]=dict(high_frequency_rms=float(np.sqrt(high)),high_frequency_energy_fraction=float(high/total) if total>0 else None,total_demeaned_windowed_rms=float(np.sqrt(total)))
            saved[key+'_'+transform]=power
        blocks={}
        for k in [2,4,8,16]:
            z=v.reshape(-1,N//k,k);res=z-z.mean(-1,keepdims=True);blocks[str(k)]=float(np.sqrt(np.mean(res**2)))
        records[key]=dict(spectrum=spec,within_block_rms=blocks,max_quantity=float(v.max()),full_rows=int(full.sum()))
    np.savez_compressed(output/'spectra.npz',frequency=freq,**saved)
    atomic_json(output/'spectral_diagnostics.json',dict(checkpoint_step=step,windows=3,frame_count=256,levels=2048,records=records,scope='Fixed3development previews; Hann-windowed within-frame rank spectra, demeaned per side/frame; frequencies>1/32cycles/level defined as periods<32levels. Descriptive smoothing evidence, not causal attribution to decoder.'))
    print('spectra complete at checkpoint',step,flush=True)


def synthetic_probe(output,steps):
    torch.set_num_threads(2);seed_everything(42)
    # Both patterns are deterministic, deliberately within one coarse128-bin cell.
    # Four independent16-rank phase channels are NOT supplied as a high-res skip.
    count=4;channels=32;K=128;L=2048
    generator=torch.Generator().manual_seed(42);features=torch.randn(count,channels,K,generator=generator)*.25
    t=torch.arange(L).float();target=torch.ones(count,1,L)*.02
    locations=[[115,418,901,1453],[116,421,907,1459],[121,426,910,1461],[126,431,911,1465]]
    for b,centers in enumerate(locations):
        target[b,0] += .08*torch.exp(-.5*((t-1100)/100)**2)
        for c,a in zip(centers,[1.,.7,.9,.6]):target[b,0,c]=a
    torch.save(dict(features=features,target=target,locations=locations),output/'synthetic_data.pt')
    outputs={};records={};histories={}
    for mode in ('nearest','linear','transpose','shuffle'):
        seed_everything(42);model=SpatialUpsamplingProbe(mode,channels);optimizer=torch.optim.Adam(model.parameters(),lr=.001);history=[];start=time.monotonic()
        for step in range(steps+1):
            optimizer.zero_grad(set_to_none=True);prediction=model(features)
            mse=(prediction-target).square().mean()
            if step in [0,32,128,256,steps]:
                with torch.no_grad():
                    chosen=target>.5;peak=float((prediction[chosen]/target[chosen]).mean());rmse=float(mse.sqrt())
                    history.append(dict(step=step,rmse=rmse,peak_amplitude_ratio=peak))
                print(mode,step,rmse,peak,flush=True)
            if step==steps:break
            mse.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5.);optimizer.step()
        outputs[mode]=prediction.detach().numpy();histories[mode]=history
        records[mode]=dict(parameters=sum(p.numel() for p in model.parameters()),elapsed_seconds=time.monotonic()-start,rmse=rmse,peak_amplitude_ratio=peak)
        torch.save(model.state_dict(),output/(mode+'_probe.pt'))
        atomic_json(output/'probe_progress.json',dict(completed=list(records),current=mode,steps=steps))
    np.savez_compressed(output/'probe_predictions.npz',truth=target.numpy(),**outputs)
    atomic_json(output/'synthetic_probe.json',dict(seed=42,steps=steps,loss='Uniform mean squared error, noTopk weighting',learning_rate=.001,initialization='All heads N(0,.01),bias inverseSoftplus(.04); spatial residuals use same LayerNorm Residual1d as real model',batch=4,coarse_shape=[4,32,128],output_shape=[4,1,2048],records=records,history=histories,scope='CPU synthetic training-set memorization; fixed random coarse input without an encoder/temporal bottleneck. Same width and steps; parameter counts differ. Tests capacity/optimization, not generalization and not8192-window-model performance. Not a loss-matched replica of current Huber model.'))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('parent',type=Path);p.add_argument('--steps',type=int,default=384);a=p.parse_args()
    root=a.parent.resolve().parent/('upsampling_study_'+datetime.now().strftime('%Y%m%d_%H%M%S'));root.mkdir();freeze_sources(root/'source_snapshot')
    atomic_json(root/'plan.json',dict(parent=str(a.parent.resolve()),steps=a.steps,seed=42,device='cpu',scope='Read-only actual256frame output diagnostics + explicitly synthetic spatial-only capacity probe; no modification to live4GPUtraining',maximum_cpu_threads=2))
    Path('/tmp/upsampling_study_path').write_text(str(root));print(root,flush=True)
    spectral_diagnostics(a.parent.resolve(),root);synthetic_probe(root,a.steps);atomic_json(root/'status.json',dict(state='complete'))
