"""Matched augmentation x quantity-strata loss experiment on the current full book."""
import argparse
from copy import deepcopy
import html
import math
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

import numpy as np
import torch

from train_dual.experiments import local_hint_run as shared
from train_dual.experiments import quantity_strata_run as strata
from train_dual.experiments.confirm_recall_goal import require_matching_replay
from train_dual.experiments.goal_evaluate import assess_file
from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read, STYLE
from train_dual.experiments.price_safe_readout import file_hash
from train_dual.experiments.recall_goal_run import candidates, record, render as render_goal
from train_dual.experiments.region_task_run import gpu_free
from train_dual.util.checkpoint import freeze_sources, load_for_inference
from train_dual.util.hint_training import restore_regional_phase_adam
from train_dual.util.phase_training import tensor_digest
from train_dual.util.quantity_strata import evaluate_with_quantity_strata


LABELS = dict(control='A 原增强＋原损失', no_aug='B 关闭增强＋原损失',
              strata='C 原增强＋分桶损失', no_aug_strata='D 关闭增强＋分桶损失')
MULTIPLIERS = dict(control=0., no_aug=0., strata=1., no_aug_strata=1.)
AUGMENT = dict(control=True, no_aug=False, strata=True, no_aug_strata=False)
MODULE = 'train_dual.experiments.quantity_factorial_run'


def install_protocol():
    # Reuse tested calibration/loss/evaluation without changing historical source.
    # These assignments are confined to this fresh process and its frozen snapshot.
    strata.LABELS = LABELS
    strata.MULTIPLIERS = MULTIPLIERS
    strata.render = render


def criterion(root, lane, device='cuda:0', *, calibrating=False):
    install_protocol()
    return strata.criterion(root, lane, device, calibrating=calibrating)


def build_plan(parent_plan, payload, source_sha, initial_digest):
    required = ['train','development','independent_test_untouched','window_size','stride',
                'normalization','model_config','local_hint_config','original_parameter_names',
                'objective','source_FP_rule','augmentation','lr','weight_decay','clip_grad',
                'batch_size','accumulation','seed','beta','sample','input_shape',
                'latent_shape','output_shape','precision']
    plan = {key:deepcopy(parent_plan[key]) for key in required if key in parent_plan}
    assert plan['input_shape']==[1,256,2,2048,2] and plan['latent_shape']==[1,64,128]
    assert plan['output_shape']==[1,256,2,2048] and plan['seed']==42 and plan['beta']==0
    assert not payload['regional_phase_config']['use_shape'] and not payload['regional_phase_config']['use_mass']
    assert payload['epoch_boundary'] and len(payload['optimizer']['param_groups'])==3
    original = parent_plan['lanes']['control']
    lanes = {lane:dict(deepcopy(original), augmentation=AUGMENT[lane],
                       stratified_multiplier=MULTIPLIERS[lane]) for lane in LABELS}
    extra = {lane:dict(regional_phase_config=deepcopy(payload['regional_phase_config']),
              training_numeric_policy=dict(cudnn_deterministic=True,cudnn_benchmark=False,tf32=False),
              inference_numeric_policy=dict(cudnn_deterministic=True,cudnn_benchmark=False,tf32=False)) for lane in LABELS}
    plan.update(experiment='原挂量增强开关 × 分数量级重建损失：控制变量2×2', labels=LABELS, lanes=lanes,
        source_sha256=source_sha, initial_model_sha256=initial_digest,
        source_steps=payload['source_steps']+payload['step'],
        source_evaluation_relative='../round_005_regional_phase/control/step2048_development.json',
        source_regional_config=deepcopy(payload['regional_phase_config']), checkpoint_extras=extra,
        steps=2048, checkpoints=[256,512,1024,2048], max_seconds=43200,
        gpu_workers=[[g,l] for g,l in zip([2,3,4,5],LABELS)], worker_module=MODULE,
        loss_variant='augmentation_x_stratified_quantity_huber', new_model_parameters=0,
        predeclared_comparisons=['A/B augmentation given old loss','C/D augmentation given strata',
                                'A/C loss given augmentation','B/D loss given no augmentation'],
        controls='Same control2048 model/all3Adam/RNG/1024indices/raworder/teacher/seed42/2048updates; only declared augmentation and loss factors change. All original modules train; same original price/quantity/tail/mid/hint losses and coefficients. No upsampling change.',
        source_selection='Fixed regional control2048, cumulative22528; price RMSE35.6337USDT, recall77.57%. Preserve disabled regional heads and all3Adam groups. No different parent per arm.',
        initial_evaluation_policy='All four step0 native outputs and original metrics must replay the exact published source; new strata diagnostics are additional.',
        augmentation_policy='A/C original frozen augmentation unchanged, including known zero-quantity occupied-level semantics. B/D no augmentation. All development/seen/unseen evaluation stays unedited.',
        quantity_calibration_policy='Reuse identical eight raw training-window RMS scales, with data/index identity checks. Lock one new mu-gradient-RMS base coefficient on this actual control parent before any optimizer update. Never fit on development.',
        acceptance='Fixed original goal guards plus parent-relative price/mid guard, precision/FP and six quantity ranges; local variance/correlation together. No automatic Q2 or goal completion from recall alone.',
        previous_goal_turn='progress: raw-data/augmentation/variance audits produced evidence that changed the next experiment; no model training was performed during pause.',
        preview_descriptions={lane:'完整256分钟、唯一8192Gaussian；同一起点控制变量2×2；Q1开发反复选型，非独立测试。' for lane in LABELS})
    return plan


def prepare(goal):
    torch.set_num_threads(4)
    root=goal/'round_007_quantity_factorial'
    root.mkdir()
    for name in ['data','logs','seen','unseen',*LABELS]:(root/name).mkdir()
    for split in ['seen','unseen']:
        for lane in LABELS:(root/split/lane).mkdir()
    parent=goal/'round_005_regional_phase'
    source=parent/'control/step2048.pt'
    for dest in ['source.pt','initial.pt']:os.link(source,root/dest)
    for name in ['teacher.pt','calibration.json','train_indices.npy','val_indices.npy',
                 'seen_indices.npy','unseen_indices.npy','plotly.min.js']:os.link(parent/name,root/name)
    os.link(parent/'data/BTCUSDT.npz',root/'data/BTCUSDT.npz')
    payload=torch.load(source,map_location='cpu',weights_only=False,mmap=True)
    model,_=load_for_inference(root/'initial.pt','cpu')
    assert not model.use_shape and not model.use_mass
    optimizer=restore_regional_phase_adam(model,payload['optimizer'],read(parent/'plan.json')['original_parameter_names'])
    assert optimizer.state_dict()['param_groups']==payload['optimizer']['param_groups']
    plan=build_plan(read(parent/'plan.json'),payload,file_hash(source),tensor_digest(model))
    reference=read(root/plan['source_evaluation_relative'])['result']['metrics']
    plan['parent_price_rmse_USDT']=reference['price_usdt']['rmse']
    plan['parent_price_limit_USDT']=1.1*reference['price_usdt']['rmse']
    plan['parent_mid_delta_limit_USDT']=1.1*reference['temporal_mid_1_minutes_usdt_per_minute']['rmse']
    scales_from=goal/'quantity_strata_preparation_v2'
    for name in ['train_indices.npy','seen_indices.npy']:
        assert np.array_equal(np.load(root/name),np.load(scales_from/name))
    assert (root/'data/BTCUSDT.npz').samefile(scales_from/'data/BTCUSDT.npz')
    cal=read(scales_from/'quantity_calibration.json')
    assert cal['optimizer_updates']==0 and not cal['weight_calibration_locked']
    assert cal['training_indices']==np.load(root/'seen_indices.npy').tolist()
    assert len(cal['training_indices'])==8 and set(cal['training_indices'])<=set(np.load(root/'train_indices.npy').tolist())
    cal.update(state='scales_fit_requires_GPU_gradient_calibration',source_checkpoint_sha256=plan['source_sha256'],
               scale_origin_relative='../quantity_strata_preparation_v2/quantity_calibration.json',
               base_weight=None,weight_calibration_locked=False,neural_forward_calls=0,optimizer_updates=0)
    np.save(root/'quantity_calibration_indices.npy',np.asarray(cal['training_indices'],dtype=np.int64))
    atomic_json(root/'quantity_calibration.json',cal)
    atomic_json(root/'plan.json',plan)
    for split in ['seen','unseen']:
        atomic_json(root/split/'plan.json',dict(plan,preview_descriptions={lane:'训练年代诊断，非独立测试；未做增强。' for lane in LABELS}))
        os.link(root/'plotly.min.js',root/split/'plotly.min.js')
    atomic_json(root/'preparation_audit.json',dict(passed=True,source_checkpoint_exact=True,
        cumulative_source_steps=plan['source_steps'],all3Adam_groups_preserved=True,
        same_data_and_training_indices_as_scale_fit=True,eight_scale_fit_windows_in_training=True,
        actual_GPU_forward_pending=True,new_model_parameters=0))
    atomic_json(root/'status.json',dict(state='prepared_requires_actual_GPU_calibration'))
    project=Path(__file__).resolve().parents[2]
    freeze_sources(root/'source_snapshot')
    remote=Path('/home/u503/crossssh_mnt/OBreconstuction-4a85ce6e')/root.relative_to(project)
    (root/'run.sh').write_text('#!/usr/bin/env bash\nset -euo pipefail\n'+
        f'export PYTHONPATH="{remote}/source_snapshot" PYTHONDONTWRITEBYTECODE=1 CUDA_DEVICE_ORDER=PCI_BUS_ID OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4\ncd "{remote}/source_snapshot"\nexec /home/u503/crossssh_mnt/env-mr_env/bin/python -u -m {MODULE} "{remote}" --controller >> "{remote}/logs/controller.log" 2>&1\n')
    render(root)
    record(goal,'quantity_factorial_prepared',wave=root.name,source='regional_control2048',
           hypothesis='Original rank edits and scale-imbalanced supervision may suppress real small-order dynamics; test2x2 independently of upsampling.')
    with (goal/'research.md').open('a') as f:
        f.write('\n## Resumed: augmentation × quantity strata\n'+root.name+' uses one control2048/22528step parent for all4 arms, 3Adam/RNG/data/seed42 held fixed; augmentation on/off × new strata loss off/on. Fresh common gradient coefficient on8train windows, no dev fit. Original historical queue was manually stopped while waiting during user pause and remains preserved. New study tests data/loss before upsampling; parent-relative price guard'+str(plan['parent_price_limit_USDT'])+'USDT is reported in addition to original goal gates. No independent-data selection.\n')
    print(root.resolve(),flush=True)


def startup_relation(rows, base_weight):
    """Falsify confounds within each augmentation pair at the first update."""
    base=rows['control']
    assert all(row['training_indices']==base['training_indices'] for row in rows.values())
    assert rows['control']['edits']==rows['strata']['edits']
    assert rows['no_aug']['edits']==rows['no_aug_strata']['edits']
    assert all(not e['applied'] and not e['events'] for e in rows['no_aug']['edits'])
    for a,b in [('control','strata'),('no_aug','no_aug_strata')]:
        for key in ['pre_stratified_loss','stratified_quantity']:
            assert rows[a]['losses'][key]==rows[b]['losses'][key]
        expected=rows[a]['losses']['loss']+base_weight*rows[a]['losses']['stratified_quantity']
        assert math.isclose(rows[b]['losses']['loss'],expected,rel_tol=5e-6,abs_tol=5e-6)


def audit_startup(root):
    rows={lane:read(root/lane/'step1_data_audit.json') for lane in LABELS}
    if not all(rows.values()) or not all((root/lane/'step8_gradient_audit.json').exists() for lane in LABELS):return False
    plan=read(root/'plan.json');cal=read(root/'quantity_calibration.json')
    startup_relation(rows,cal['base_weight'])
    source=read(root/plan['source_evaluation_relative'])['result']
    old=torch.load(root/'source.pt',map_location='cpu',weights_only=False,mmap=True)
    for lane in LABELS:
        assert read(root/lane/'actual_shape_contract.json')['passed']
        assert read(root/lane/'restore_audit.json')['restored_groups']==3
        require_matching_replay(read(root/lane/'step0_development.json')['result'],source)
        new=torch.load(root/lane/'step0.pt',map_location='cpu',weights_only=False,mmap=True)
        assert new['model'].keys()==old['model'].keys()
        for name,value in old['model'].items():torch.testing.assert_close(new['model'][name],value,rtol=0,atol=0)
        assert new['optimizer']['param_groups']==old['optimizer']['param_groups']
        assert new['optimizer']['state'].keys()==old['optimizer']['state'].keys()
        for index,state in old['optimizer']['state'].items():
            for key,value in state.items():
                if torch.is_tensor(value):torch.testing.assert_close(new['optimizer']['state'][index][key],value,rtol=0,atol=0)
                else:assert new['optimizer']['state'][index][key]==value
    atomic_json(root/'startup_control_audit.json',dict(passed=True,matched2x2_raw_order_and_augmented_pairs=True,
        same_source_all3Adam_exact=True,published_source_native_development_replayed=True,
        actual256minute_single8192_Z_only_decode=True,layer_gradients_finite_and_nonzero=True))
    return True


def checkpoint_analysis(root,step):
    paths={lane:root/lane/f'step{step}_development.json' for lane in LABELS}
    if not all(p.exists() for p in paths.values()):return
    dest=root/f'common{step}_analysis.json'
    if dest.exists():return
    plan=read(root/'plan.json');rows=[]
    for lane,path in paths.items():
        row=dict(lane=lane,**assess_file(path,root.parent/'reference_evaluation.json'))
        result=read(path)['result'];m=result['metrics']
        row.update(parent_price_guard=m['price_usdt']['rmse']<=plan['parent_price_limit_USDT'],
                   parent_mid_guard=m['temporal_mid_1_minutes_usdt_per_minute']['rmse']<=plan['parent_mid_delta_limit_USDT'],
                   quantity_strata=result['quantity_strata'],
                   local_dynamics={key:dict(std_ratio=m[key]['centered_amplitude_ratio'],variance_ratio=m[key]['centered_amplitude_ratio']**2,correlation=m[key]['correlation'])
                     for key in ['spatial_slope_1_within_frame_variation','temporal_shape_1_minutes_after_mid_removal','temporal_log_quantity_1_minutes']},
                   evaluation_sha256=file_hash(path))
        rows.append(row)
    atomic_json(dest,dict(step=step,rows=rows,scope='Matched2x2; same dev16 already used for selection; variance alone is not success.'))
    record(root.parent,'quantity_factorial_common_checkpoint',wave=root.name,step=step,rows=rows)


def render(root):
    plan=read(root/'plan.json');state=read(root/'status.json',{})
    text='<h1>挂量增强开关 × 分数量级损失：四组控制变量实验</h1><p>完整256分钟、双侧2048档、唯一64×128Gaussian，无Encoder跳接。四组统一从regional control/step2048出发，保留全部三组Adam、RNG、1024训练窗/抽样、teacher、seed42和2048追加更新。空间上采样和原损失不变，模型全部继续训练。</p><p>原增强保留历史行为用于A/C对照，B/D完全关闭；开发评估均不增强。分桶尺度来自8个既有训练窗口，公共权重在当前来源上重新做训练集梯度校准。所有误差使用USDT/BTC原始单位。</p>'
    text+='<table><tr><th>组</th><th>训练步</th><th>最近评估步</th><th>大单召回</th><th>精确率</th><th>价格RMSE USDT</th><th>数量RMSE BTC</th><th>log挂量分钟变化方差比</th></tr>'
    for lane,label in LABELS.items():
        files=list((root/lane).glob('step*_development.json'));path=max(files,key=lambda p:int(p.name.split('_')[0][4:])) if files else None
        vals=[label,read(root/lane/'progress.json',{}).get('step',0)]
        if path:
            d=assess_file(path,root.parent/'reference_evaluation.json');m=read(path)['result']['metrics']
            vals.extend([int(path.name.split('_')[0][4:]),f"{d['recall100']:.2%}",f"{d['precision100']:.2%}" if d['precision100'] is not None else '—',f"{d['price_rmse']:.3f}",f"{d['quantity_rmse']:.4f}",f"{m['temporal_log_quantity_1_minutes']['centered_amplitude_ratio']**2:.2%}"])
        else:vals.extend(['待评估']*6)
        text+='<tr>'+''.join('<td>'+html.escape(str(v))+'</td>' for v in vals)+'</tr>'
    text+='</table><p>除原目标门槛外，报告当前来源价格保护≤'+str(plan['parent_price_limit_USDT'])+' USDT及六数量区间重建误差。仅提高整体方差或100BTC召回不能代表完整订单簿恢复；Q1开发非独立测试，本轮不自动读取保留Q2或宣布完成。</p><p>状态：'+html.escape(str(state))+'</p><p><a href="plan.json">协议</a> · <a href="quantity_calibration.json">尺度和梯度权重</a> · <a href="startup_control_audit.json">GPU来源/对照审计</a> · <a href="../">目标总览</a></p>'
    (root/'index.html').write_text('<!doctype html><meta charset="utf-8"><meta http-equiv="refresh" content="30"><style>'+STYLE+'</style><main>'+text+'</main>')


def controller(root):
    plan=read(root/'plan.json')
    if any(gpu_free().get(g,0)<47000 for g in [2,3,4,5]):raise RuntimeError('Owned GPUs2–5 are not all available; do not interfere with other work')
    assert read(root/'status.json')['state']=='prepared_requires_actual_GPU_calibration'
    env=dict(os.environ,CUDA_VISIBLE_DEVICES='2',PYTHONPATH=str(root/'source_snapshot'))
    atomic_json(root/'status.json',dict(state='training_only_gradient_calibration',controller_pid=os.getpid()));render(root)
    with (root/'logs/gradient_calibration.log').open('ab',buffering=0) as log:
        p=subprocess.run([sys.executable,'-u','-m',MODULE,str(root),'--calibrate'],cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=3600)
    if p.returncode or not read(root/'quantity_calibration.json')['weight_calibration_locked']:raise RuntimeError('Calibration failed before optimizer updates')
    children=[];begin=time.monotonic();audited=False
    try:
        for gpu,lane in plan['gpu_workers']:
            env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),PYTHONPATH=str(root/'source_snapshot'))
            with (root/'logs'/f'{lane}.log').open('ab',buffering=0) as log:
                child=subprocess.Popen([sys.executable,'-u','-m',MODULE,str(root),'--lane',lane],cwd=root/'source_snapshot',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            children.append(child)
        atomic_json(root/'status.json',dict(state='running',controller_pid=os.getpid(),pids=[c.pid for c in children]));render(root)
        atomic_json(root.parent/'status.json',dict(state='running_augmentation_quantity_factorial',wave=root.name))
        while any(c.poll() is None for c in children):
            if any(c.poll() not in [None,0] for c in children):raise RuntimeError('Owned factorial worker failed')
            if time.monotonic()-begin>plan['max_seconds']+1800:raise TimeoutError('Training12hours plus30min evaluation ceiling')
            if not audited:audited=audit_startup(root)
            for step in plan['checkpoints']:checkpoint_analysis(root,step)
            render(root);time.sleep(10)
        if any(c.returncode for c in children) or not (audited or audit_startup(root)):raise RuntimeError('Workers or matched startup audit incomplete')
        for step in plan['checkpoints']:checkpoint_analysis(root,step)
        atomic_json(root/'status.json',dict(state='complete',controller_pid=os.getpid(),elapsed_seconds=time.monotonic()-begin));render(root)
        new=candidates(root,root.parent/'reference_evaluation.json');old=read(root.parent/'candidates.json',{}).get('rows',[])
        atomic_json(root.parent/'candidates.json',dict(rows=[r for r in old if r.get('experiment')!=root.name]+[dict(r,experiment=root.name) for r in new]))
        atomic_json(root.parent/'status.json',dict(state='factorial_complete_requires_whole_book_review',wave=root.name,goal_achieved=False));render_goal(root.parent)
        record(root.parent,'quantity_factorial_complete',wave=root.name,next='Review matched changes in all quantity scales, paired dynamics, price and rare-order precision; no automatic goal completion/Q2 selection.')
    finally:
        for child in children:
            if child.poll() is None:os.killpg(child.pid,signal.SIGTERM)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');p.add_argument('--controller',action='store_true');p.add_argument('--calibrate',action='store_true');p.add_argument('--lane',choices=list(LABELS));args=p.parse_args();root=args.root.resolve()
    def stop(signum,frame):raise KeyboardInterrupt(f'Signal{signum}')
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:
        if args.prepare:prepare(root)
        elif args.calibrate:install_protocol();strata.calibrate(root)
        elif args.lane:
            install_protocol();shared.evaluate=evaluate_with_quantity_strata
            shared.worker(root,args.lane,objective_factory=criterion,optimizer_factory=restore_regional_phase_adam)
        elif args.controller:controller(root)
        else:p.error('Need --prepare, --controller, --calibrate or --lane')
    except BaseException as error:
        if not args.prepare:atomic_json((root/args.lane if args.lane else root)/'status.json',dict(state='failed',pid=os.getpid(),error=repr(error)))
        raise


if __name__=='__main__':main()
