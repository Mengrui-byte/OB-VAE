"""Render every valid book level as an independent vertical order line."""

import argparse
import html
import json
from pathlib import Path

import numpy as np


PAGE = r'''<!doctype html><html lang="zh"><meta charset="utf-8"><title>逐档挂单线图</title>
<style>body{font:16px system-ui;max-width:1500px;margin:24px auto;padding:0 20px;color:#162235}p{line-height:1.7}a{color:#2563eb}.controls{display:flex;flex-wrap:wrap;align-items:center;gap:18px;background:#f2f5fa;padding:15px;border-radius:8px;position:sticky;top:0;z-index:5}select,button,input{font:inherit}#chart{height:870px}#notice{color:#526276}table{border-collapse:collapse}td,th{padding:8px 14px;border:1px solid #d8dfe9}</style>
<h1>逐档挂单线图：真实订单簿与模型重建</h1>
<p>每个有效档位画一条独立竖线：横轴为该档价格，线高为挂单量（BTC）。左列是真实订单簿，右列为所选模型；上排买盘，下排卖盘。保留全部有效档位，可以框选放大，悬停在线顶查看档位、价格和数量。</p>
<p><b>这些是训练外的开发验证样本。</b>训练使用 2022-01-01 至 2025-01-01（不含）；本页样本来自 2025 年一季度，与训练区间没有重叠。但这一季度已用于验证和选型，不能作为最终独立测试集。本页是同一输入窗口的重建，使用非因果窗口编码，不代表未来预测。</p>
<div class="controls"><label>样本 <select id="sample"></select></label><label>模型 <select id="model"></select></label><label>分钟 <input id="minute" type="range" min="0" max="15" value="0"><span id="minuteValue">1 / 16</span></label><button id="play">播放</button><label>横轴 <select id="axis"><option value="price">价格（USDT）</option><option value="rank">档位序号</option></select></label><label><input id="log" type="checkbox">对数数量坐标</label></div>
<p id="notice">正在加载逐档数据…</p><div id="chart"></div><p id="metrics"></p>
<p><a href="comparison/">查看价格斜率、流动性热力图和验证指标</a> · <a href="comparison/comparison.json">下载指标与权重信息</a> · <a href="audit.json">查看训练/验证时间说明</a></p>
<script src="plotly.min.js"></script><script>
let meta,book,mask,timer=null,busy=false,loadedWindow=-1;
const $=id=>document.getElementById(id);
function levelOffset(v,w,t,s,l,f){let count=meta.chunk_windows?1:meta.W,window=meta.chunk_windows?0:w;return (((((v*count+window)*meta.T+t)*2+s)*meta.L+l)*2+f)}
function valid(w,t,s,l){return mask[(((w*meta.T+t)*2+s)*meta.L+l)]!==0}
function curves(v,w,t,s,color,legend){
 let x=[],y=[],px=[],py=[],custom=[];
 for(let l=0;l<meta.L;l++){if(!valid(w,t,s,l))continue;let p=book[levelOffset(v,w,t,s,l,0)],q=book[levelOffset(v,w,t,s,l,1)],a=$('axis').value==='rank'?l+1:p;
  x.push(a,a,null);y.push($('log').checked?1e-6:0,Math.max(q,$('log').checked?1e-6:0),null);px.push(a);py.push(q);custom.push([l+1,p,q]);}
 return [{type:'scattergl',mode:'lines',x,y,connectgaps:false,line:{color,width:1},name:legend,showlegend:false,hoverinfo:'skip'},
 {type:'scattergl',mode:'markers',x:px,y:py,customdata:custom,marker:{color,size:3},name:legend,showlegend:false,hovertemplate:'档位 %{customdata[0]}<br>价格 %{customdata[1]:.3f} USDT<br>数量 %{customdata[2]:.5f} BTC<extra>'+legend+'</extra>'}];
}
async function draw(){if(busy)return;busy=true;try{
 let w=+$('sample').value,t=+$('minute').value,v=+$('model').value,all=[],maxQ=0;
 if(meta.chunk_windows&&loadedWindow!==w){$('notice').textContent='加载完整256分钟窗口…';book=new Float64Array(await(await fetch('book'+w+'.f64')).arrayBuffer());loadedWindow=w}
 for(let s=0;s<2;s++)for(let col=0;col<2;col++){
  let idx=s*2+col,source=col?v:0;for(let tr of curves(source,w,t,s,col?meta.colors[v]:meta.colors[0],col?meta.labels[v]:'真实')){tr.xaxis=idx?'x'+(idx+1):'x';tr.yaxis=idx?'y'+(idx+1):'y';all.push(tr)}
  for(let l=0;l<meta.L;l++)if(valid(w,t,s,l))maxQ=Math.max(maxQ,book[levelOffset(source,w,t,s,l,1)]);
 }
 let layout={template:'plotly_white',height:870,margin:{t:70,b:60,l:75,r:30},title:{text:'窗口 '+meta.indices[w]+' | '+meta.times[w][t]+' | '+meta.labels[v]},grid:{rows:2,columns:2,pattern:'independent'},annotations:[],uirevision:meta.indices[w]+'-'+$('axis').value+'-'+$('log').checked};
 for(let s=0;s<2;s++){
  let lo=Infinity,hi=-Infinity;for(let source of [0,v])for(let l=0;l<meta.L;l++)if(valid(w,t,s,l)){let a=$('axis').value==='rank'?l+1:book[levelOffset(source,w,t,s,l,0)];lo=Math.min(lo,a);hi=Math.max(hi,a)}let pad=Math.max((hi-lo)*.025,$('axis').value==='rank'?1:.1);
  for(let col=0;col<2;col++){let idx=s*2+col,suffix=idx?idx+1:'';layout['xaxis'+suffix]={title:{text:$('axis').value==='rank'?'档位序号':'价格（USDT）'},range:[lo-pad,hi+pad],autorange:false};layout['yaxis'+suffix]={title:{text:'数量（BTC）'},type:$('log').checked?'log':'linear',range:$('log').checked?[-4,Math.log10(Math.max(maxQ*1.05,1))]:[0,Math.max(maxQ*1.05,1)],autorange:false};
   layout.annotations.push({xref:'paper',yref:'paper',x:col?.78:.22,y:s?.46:1.03,text:(s?'卖盘 Ask':'买盘 Bid')+' · '+(col?meta.labels[v]:'真实订单簿'),showarrow:false,font:{size:16}});
  }
 }
 await Plotly.react('chart',all,layout,{responsive:true,displaylogo:false,scrollZoom:true});
 $('minuteValue').textContent=(t+1)+' / '+meta.T;$('notice').textContent=(meta.step_note||('单种子 '+meta.seed+'，相同 '+meta.step+' 步权重。'))+'所有有效档位均显示，线条之间不相连；真实与重建使用相同坐标范围。';
 $('metrics').textContent='时间：'+meta.times[w][t]+'；样本范围：'+meta.times[w][0]+' 至 '+meta.times[w][meta.T-1]+'（UTC）。';
}finally{busy=false}}
async function main(){meta=await(await fetch('viewer.json')).json();$('minute').max=String(meta.T-1);if(meta.chunk_windows){mask=new Uint8Array(await(await fetch('mask.u8')).arrayBuffer())}else{let buffers=await Promise.all(['book.f64','mask.u8'].map(async x=>(await fetch(x)).arrayBuffer()));book=new Float64Array(buffers[0]);mask=new Uint8Array(buffers[1])}
 meta.indices.forEach((i,w)=>$('sample').add(new Option('W'+(w+1)+' · '+i,w)));meta.labels.slice(1).forEach((name,i)=>$('model').add(new Option(name,i+1)));$('model').value=String(meta.default_model||3);
 for(let id of ['sample','model','axis','log'])$(id).addEventListener('change',draw);$('minute').addEventListener('input',draw);
 $('play').onclick=()=>{if(timer){clearInterval(timer);timer=null;$('play').textContent='播放'}else{$('play').textContent='暂停';timer=setInterval(async()=>{if(busy)return;$('minute').value=(+$('minute').value+1)%meta.T;await draw()},650)}};await draw();window.stemReady=true;
}main().catch(e=>{$('notice').textContent='加载失败：'+e.message;console.error(e)});
</script></html>'''


def build(source, output):
    from plotly.offline import get_plotlyjs
    output.mkdir(parents=True, exist_ok=True)
    info = json.loads((source / "comparison.json").read_text())
    configuration = info.get("viewer_variants")
    with np.load(source / "profiles.npz") as data:
        names = [row["key"] for row in configuration] if configuration else ["truth", "control", "spatial", "volume", "temporal"]
        values = np.stack([data[name] for name in names]).astype("<f8")
        if info.get('chunk_windows',False):
            for index in range(values.shape[1]):values[:,index:index+1].copy().tofile(output/f'book{index}.f64')
        else:values.tofile(output / "book.f64")
        data["mask"].astype(np.uint8).tofile(output / "mask.u8")
        times = [[str(np.datetime64(int(t), "us")) + "Z" for t in row] for row in data["time"]]
        period=info.get("evaluation_period",["2025-01-01","2025-04-01"])
        start = np.datetime64(period[0], "us").astype(np.int64)
        end = np.datetime64(period[1], "us").astype(np.int64)
        if not ((data["time"] >= start) & (data["time"] < end)).all():
            raise ValueError("Viewer's declared evaluation period does not match example timestamps")
        indices = data["indices"].tolist()
    meta = dict(W=values.shape[1], T=values.shape[2], L=values.shape[4], indices=indices,
                times=times, seed=info["seed"], step=info["common_step"],
                default_model=info.get("default_model", 3),chunk_windows=info.get('chunk_windows',False),
                step_note=info.get("step_note"),
                labels=[row["label"] for row in configuration] if configuration else ["真实", "增强损失对照", "价格空间修正", "数量幅度修正", "时间演变修正"],
                colors=[row["color"] for row in configuration] if configuration else ["#2563eb", "#ef4444", "#16a34a", "#9333ea", "#f59e0b"])
    audit = dict(train=["2022-01-01", "2025-01-01"], development=["2025-01-01", "2025-04-01"],
                 independent_test=["2025-04-01", "2025-07-01"], bounds="UTC, start inclusive/end exclusive",
                 shown_window_times=times, no_training_time_overlap=True, used_for_model_selection=True,
                 independent_test_evaluated=False, causal=False, task="Within-input-window reconstruction",
                 source_profiles=str(source / "profiles.npz"), seed=info["seed"], step=info["common_step"])
    if "evaluation_period" in info:
        audit.update(evaluation_period=period,evaluation_role=info.get("evaluation_role","inspection"),
                     used_for_model_selection=info.get("used_for_model_selection",False),
                     inspection_manifest=info.get("inspection_manifest"))
        train_start=np.datetime64(audit['train'][0],'us').astype(np.int64)
        train_end=np.datetime64(audit['train'][1],'us').astype(np.int64)
        timestamps=np.array([[np.datetime64(t[:-1],'us').astype(np.int64) for t in row] for row in times])
        audit['no_training_time_overlap']=bool(((timestamps<train_start)|(timestamps>=train_end)).all())
    (output / "viewer.json").write_text(json.dumps(meta, ensure_ascii=False))
    (output / "audit.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2))
    page = PAGE.replace("查看价格斜率、流动性热力图和验证指标", html.escape(info.get("comparison_label", "查看价格斜率、流动性热力图和验证指标")))
    if "evaluation_description" in info:
        begin=page.index('<p><b>这些是训练外的开发验证样本。');end=page.index('</p>',begin)+4
        page=page[:begin]+'<p>'+html.escape(info['evaluation_description'])+'</p>'+page[end:]
    if info.get("only_model"):
        page = page.replace('<label>模型 <select id="model"></select></label>', '<label hidden>模型 <select id="model"></select></label>')
        title = "Cross-attention 逐档挂单重建"
        page = page.replace("<title>逐档挂单线图</title>", "<title>" + title + "</title>")
        page = page.replace("逐档挂单线图：真实订单簿与模型重建", title)
        note = info.get("model_description", "")
        if note:
            page = page.replace('<div class="controls">', '<p>' + html.escape(note) + '</p><div class="controls">')
    (output / "index.html").write_text(page)
    (output / "plotly.min.js").write_text(get_plotlyjs())
    (output / "comparison").symlink_to(source.resolve(), target_is_directory=True)
    print(output, flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    build(args.source, args.output)
