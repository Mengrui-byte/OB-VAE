"""Cached quantity mass feasibility; no network execution or score relaxation."""
import argparse
import hashlib
import html
import json
from pathlib import Path

import numpy as np
import torch

from train_dual.experiments.long_worker import atomic_json
from train_dual.experiments.phase_detail_report import read,STYLE
from train_dual.util.checkpoint import freeze_sources
from train_dual.util.quantity_bounds import fixed_region_mass_bound


def file_hash(path):
    value=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(4*1024*1024),b''):value.update(block)
    return value.hexdigest()


def prepare(goal):
    root=goal/'regional_mass_feasibility';root.mkdir()
    atomic_json(root/'plan.json',dict(goal_root=str(goal),region_width=16,threshold=100.,relative_mass_tolerance=1e-6,absolute_mass_tolerance=1e-4,
        train_caches=['local_phase_cached_pilot','local_phase_cached_seen8_pilot'],FP_step=1024,
        scope='Label-dependent oracle mass-feasibility bound on existing cached2/8trainingwindows and3profilewindowsperFParm. The3profiles are a subset of the repeatedly used16Q1development windows, not an independent test. No network execution, optimizer, Q2read, relaxed recall or candidate. Bounds permit arbitrary oracle allocation at known true positions and ignore amplitude fidelity.'))
    atomic_json(root/'status.json',dict(state='prepared'));freeze_sources(root/'source_snapshot');print(root,flush=True)


def run(root):
    plan=read(root/'plan.json');goal=Path(plan['goal_root']);torch.set_num_threads(4);rows=[];hashes={}
    def add(label,role,prediction,target,mask,indices):
        options=dict(region_width=plan['region_width'],threshold=plan['threshold'])
        exact=fixed_region_mass_bound(prediction,target,mask,**options)
        loose=fixed_region_mass_bound(prediction,target,mask,**options,relative_mass_tolerance=plan['relative_mass_tolerance'],absolute_mass_tolerance=plan['absolute_mass_tolerance'])
        rows.append(dict(label=label,role=role,indices=indices,exact=exact,floating_tolerance=loose))
    for name in plan['train_caches']:
        parent=goal/name;path=parent/'cache.pt';hashes[str(path)]=file_hash(path)
        cache=torch.load(path,map_location='cpu',weights_only=False)
        add(name,'Fixedtrainingwindows',torch.cat([r['out']['volume'] for r in cache]),torch.cat([r['batch']['volume'] for r in cache]),torch.cat([r['batch']['mask'] for r in cache]),read(parent/'plan.json')['indices'])
    parent=goal/'round_002_fp_rule';val=np.load(parent/'val_indices.npy');expected=val[np.unique(np.linspace(0,len(val)-1,3,dtype=int))]
    for lane in ['legacy','fixed_count','smooth','recall']:
        path=parent/lane/f"step{plan['FP_step']}_profiles.npz";hashes[str(path)]=file_hash(path)
        with np.load(path) as data:
            assert np.array_equal(data['indices'],expected)
            add(lane,'Same3Q1profilewindows,subsetof16development',torch.from_numpy(data['prediction'][...,1].copy()),torch.from_numpy(data['truth'][...,1].copy()),torch.from_numpy(data['mask'].copy()).bool(),data['indices'].tolist())
    assert all(file_hash(path)==digest for path,digest in hashes.items())
    atomic_json(root/'results.json',dict(rows=rows,input_sha256=hashes,scope=plan['scope'],inputs_unchanged=True,model_executions=0,optimizer_updates=0))
    text='<!doctype html><meta charset="utf-8"><title>固定区域挂量的召回上界</title><style>'+STYLE+'</style><main><h1>固定每16档总量：任何区域内形状调整能达到的上界</h1><p>这不是模型召回率。假定已知道所有真实大单位置，并可任意重分配区域内数量；若区域总量为M、真实≥100BTC档位数为K，则最多min(K, floor(M/100))个真实档位能达到100BTC。它还忽略真实幅度误差，是非常乐观的上界。</p><table><tr><th>来源</th><th>样本范围</th><th>真实事件数</th><th>最多可达到阈值</th><th>理论上界</th><th>允许浮点总量漂移后的上界</th><th>固定总量下至少漏检</th></tr>'
    for row in rows:
        e=row['exact'];values=[row['label'],row['role'],e['true_events'],e['max_feasible_events'],e['recall_upper_bound'],row['floating_tolerance']['recall_upper_bound'],e['unavoidable_misses']]
        text+='<tr>'+''.join('<td>'+html.escape(f'{v:.6f}' if isinstance(v,float) else str(v))+'</td>' for v in values)+'</tr>'
    text+='</table><p>比率用0–1表示。训练8窗和Q1绘图3窗分布不同，不能把一个集合的上界用于另一个集合；3窗也不能替代16窗正式开发评估。浮点宽容版本允许每区域总量增加1e-6相对量和1e-4BTC绝对量，避免把舍入误差当作物理限制。</p><p>约束仅针对“原区域总量固定”的条件。启用总量头、改变基础数量Decoder或重训Encoder均可改变区域总量，这些模型不受这里的固定源上界约束。本分析不证明latent缺少信息，也不证明某一种训练方法一定能补足总量。</p><p><a href="results.json">原始计数与输入哈希</a> · <a href="plan.json">范围与公式</a> · <a href="../local_phase_cached_seen8_pilot/analysis/">8窗共享读出结果</a> · <a href="../local_phase_cached_regional8_pilot/analysis/">8窗分区域读出结果</a></p></main>'
    (root/'index.html').write_text(text);atomic_json(root/'status.json',dict(state='complete',model_executions=0,optimizer_updates=0,goal_candidate=False))
    print(json.dumps(rows,ensure_ascii=False),flush=True)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);p.add_argument('--prepare',action='store_true');a=p.parse_args();root=a.root.resolve()
    try:
        if a.prepare:prepare(root)
        else:run(root)
    except BaseException as error:
        if not a.prepare:atomic_json(root/'status.json',dict(state='failed',error=repr(error)))
        raise
