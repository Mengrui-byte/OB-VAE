"""Live and final reports for a small 16x1024 matrix compression experiment."""

import argparse
from datetime import datetime,timezone
import json
from pathlib import Path
import time

import numpy as np

from train_dual.experiments.book_stem_viewer import build


LABELS={'fixed_pca':'固定线性投影','linear':'可训练线性压缩','nonlinear':'非线性压缩','nonlinear_joint':'非线性压缩＋解码器适配'}
PAGE='''<!doctype html><html lang=zh-CN><meta charset=utf-8><title>16×1024矩阵压缩小样本实验</title><script src=plotly.min.js></script><style>body{font:16px system-ui;max-width:1500px;margin:28px auto;padding:0 20px;color:#182b43}p{line-height:1.8}table{border-collapse:collapse;width:100%}td,th{padding:8px;border:1px solid #ddd}.plots{display:grid;grid-template-columns:1fr 1fr}select{font:inherit;padding:5px}a{color:#2563eb}</style><h1>融合后的latent压缩成16×1024</h1><p>以当前最优未量化Cross模型为源。把每个时间位置的G64维与Local(2×128×16)展平拼为4160维，再学习压成1024维，整窗矩阵[B,16,1024]。仅展平为[B,16,4160]是无损对照；4160→1024是有损降维。保留时间轴，没有量化、语义约束或未来收益。</p><p>有效latent从66560个float32（260KiB）到16384个float32（64KiB），4.0625倍维度压缩。只比较latent大小，不是模型权重压缩；新编码/解码投影会增加模型参数。原Cross内部Attention宽度和结构仍作为源保持不变。</p><p>抽样512个训练窗口（2022—2024）拟合与训练；统一64个2025Q1开发窗口评价，另64个实际见过的训练窗口做拟合诊断。开发集已经用于研究选型，2025Q2未用。共同的训练期原始PCA初始化，不白化；非线性残差零输出起步。单种子42，训练组各512步，源编码器/Cross固定。</p><p id=status>加载中</p><p id=basis></p><p><a href=./>逐档挂单重建</a> · <a href=previous/>上一轮张量量化</a> · <a href=matrix_plan.json>配置</a> · <a href=matrix_progress.json>完整数据</a></p><table><thead><tr><th>GPU</th><th>方案</th><th>状态</th><th>步数</th><th>耗时秒</th></tr></thead><tbody id=progress></tbody></table><h2>同64个开发窗口</h2><table><thead><tr><th>方案</th><th>阶段</th><th>价格RMSE USDT</th><th>数量RMSE BTC</th><th>分钟挂量变化相关</th><th>大单召回</th><th>大单精确率</th></tr></thead><tbody id=results></tbody></table><h2>实际见过的64个训练窗口</h2><table><thead><tr><th>方案</th><th>价格RMSE USDT</th><th>数量RMSE BTC</th><th>分钟挂量变化相关</th><th>大单召回</th></tr></thead><tbody id=seen></tbody></table><div class=plots><div id=loss></div><div id=latent></div></div><h2>查看实际16×1024矩阵</h2><p><select id=method></select> <select id=sample><option value=0>窗口1</option><option value=1>窗口2</option><option value=2>窗口3</option></select></p><div id=matrix></div><p>矩阵横轴为1024个学习通道，纵轴保留16个分钟位置。通道不预设经济含义；该矩阵代表整个窗口，并非16个独立窗口状态。解码仅使用矩阵和源模型已有mask/tick/anchor元数据，不保留原G/L旁路。</p><script>let d={};const labels={fixed_pca:'固定线性投影',linear:'可训练线性',nonlinear:'非线性',nonlinear_joint:'非线性＋解码器适配'},f=(x,n=3)=>Number.isFinite(x)?x.toFixed(n):'—';function row(a){let r=document.createElement('tr');for(let x of a){let c=document.createElement('td');c.textContent=x;r.append(c)}return r}function metrics(label,stage,x){let m=x.metrics,t=x.thresholds['100'];return row([label,stage,f(m.price_usdt.rmse),f(m.quantity_btc.rmse),f(m.temporal_log_quantity_1_minutes.correlation),f(t.recall*100,1)+'%',f(t.precision*100,1)+'%'])}function drawMatrix(){let lane=document.getElementById('method').value,s=+document.getElementById('sample').value,z=d.lanes?.[lane]?.matrices?.[s];if(z)Plotly.react('matrix',[{type:'heatmap',z,colorscale:'RdBu',zmid:0}],{height:420,title:labels[lane]+' · 16×1024',xaxis:{title:'学习通道'},yaxis:{title:'窗口内分钟位置'},template:'plotly_white'},{responsive:true,displaylogo:false})}async function refresh(){d=await(await fetch('matrix_progress.json?t='+Date.now())).json();document.getElementById('status').textContent='状态：'+d.status.state;document.getElementById('basis').textContent=d.basis?'共同线性初始化保留训练latent原始能量约 '+f(d.basis.retained_training_energy*100,2)+'%；不等于订单簿重建保真率。':'';let p=[],r=[],s=[],i=2;let first=Object.values(d.lanes).find(x=>x.original);if(first){r.push(metrics('未压缩Cross','原模型',first.original));if(first.flatten)r.push(metrics('仅展平16×4160','无压缩',first.flatten))}for(let [lane,label] of Object.entries(labels)){let x=d.lanes[lane]||{},g=x.progress||{};p.push(row([i++,label,x.status?.state||'等待',g.step?g.step+'/'+g.total:'—',f(g.elapsed_seconds,1)]));for(let [stage,key] of [['初始化','compressed'],['256步','step256'],['最终','final']])if(x[key])r.push(metrics(label,stage,x[key]));if(x.seen){let m=x.seen.metrics;s.push(row([label,f(m.price_usdt.rmse),f(m.quantity_btc.rmse),f(m.temporal_log_quantity_1_minutes.correlation),f(x.seen.thresholds['100'].recall*100,1)+'%']))}}document.getElementById('progress').replaceChildren(...p);document.getElementById('results').replaceChildren(...r);document.getElementById('seen').replaceChildren(...s);for(let [id,key,title] of [['loss','loss','小样本训练重建损失'],['latent','latent_mse','有效latent重建MSE']]){let traces=[];for(let [lane,x] of Object.entries(d.lanes)){let h=x.history||[];if(h.length)traces.push({x:h.map(x=>x.step),y:h.map(x=>x[key]),mode:'lines+markers',name:labels[lane]})}Plotly.react(id,traces,{height:350,title,template:'plotly_white'},{responsive:true,displaylogo:false})}let methods=Object.entries(d.lanes).filter(([_,x])=>x.matrices).map(([k])=>k);let el=document.getElementById('method'),current=el.value;el.replaceChildren(...methods.map(k=>new Option(labels[k],k)));if(methods.includes(current))el.value=current;drawMatrix()}document.getElementById('method').onchange=drawMatrix;document.getElementById('sample').onchange=drawMatrix;refresh().catch(console.error);setInterval(()=>refresh().catch(console.error),10000);</script></html>'''


def final_viewer(root,previous):
    folder=root/'report';folder.mkdir(exist_ok=True)
    with np.load(root/'source_profiles.npz') as p:
        arrays={k:p[k] for k in ('truth','mask','time','indices')};arrays['source']=p['prediction']
    config=[dict(key='truth',label='真实订单簿',color='#2563eb'),dict(key='source',label='未压缩Cross',color='#64748b')]
    for (lane,label),color in zip(LABELS.items(),['#eab308','#2563eb','#9333ea','#16a34a']):
        with np.load(root/lane/'profiles.npz') as p:
            np.testing.assert_array_equal(p['truth'],arrays['truth']);arrays[lane]=p['prediction']
        config.append(dict(key=lane,label=label,color=color))
    np.savez_compressed(folder/'profiles.npz',**arrays)
    results=json.loads((root/'comparison.json').read_text())['rows']
    best=min(results,key=lambda lane:results[lane]['final']['metrics']['quantity_btc']['rmse'])
    (folder/'comparison.json').write_text(json.dumps(dict(viewer_variants=config,default_model=[x['key'] for x in config].index(best),
        seed=42,common_step=512,step_note='512训练窗口的小样本16×1024连续矩阵压缩；统一64开发窗口。',
        comparison_label='16×1024压缩指标和矩阵',results=results),ensure_ascii=False))
    (folder/'index.html').write_text('<!doctype html><meta charset=utf-8><meta http-equiv=refresh content="0;url=../matrix.html">')
    viewer=root/'viewer';build(folder,viewer)
    for name in ('matrix.html','matrix_plan.json','matrix_progress.json'):(viewer/name).symlink_to(root/'public'/name)
    (viewer/'previous').symlink_to(previous,target_is_directory=True)
    return viewer


def monitor(root):
    root=root.resolve();public=root/'public';public.mkdir(exist_ok=True)
    selector=root.parents[1]/'.local/dual_viewer/current.json';previous=Path(json.loads(selector.read_text())['directory'])
    (public/'matrix.html').write_text(PAGE);(public/'matrix_plan.json').symlink_to(root/'plan.json');(public/'previous').symlink_to(previous,target_is_directory=True)
    for name in ('index.html','book.f64','mask.u8','viewer.json','plotly.min.js','comparison','audit.json'):
        source=previous/name
        if source.exists():(public/name).symlink_to(source,target_is_directory=source.is_dir())
    tmp=selector.with_suffix('.tmp');tmp.write_text(json.dumps(dict(directory=str(public))));tmp.replace(selector)
    while True:
        status=json.loads((root/'status.json').read_text());lanes={}
        for lane in LABELS:
            x={}
            for name in ('status','progress'):
                p=root/lane/(name+'.json')
                if p.exists():x[name]=json.loads(p.read_text())
            for name in ('original','flatten','compressed','step256','final','seen'):
                p=root/lane/(name+'_evaluation.json')
                if p.exists():x[name]=json.loads(p.read_text())['result']
            p=root/lane/'progress.jsonl';x['history']=[]
            if p.exists():
                for line in p.read_text().splitlines():
                    try:x['history'].append(json.loads(line))
                    except ValueError:pass
            p=root/lane/'matrix_examples.npz'
            if p.exists():
                with np.load(p) as z:x['matrices']=z['matrix'].tolist()
            lanes[lane]=x
        basis=json.loads((root/'basis_fit.json').read_text()) if (root/'basis_fit.json').exists() else None
        value=dict(utc=datetime.now(timezone.utc).isoformat(),status=status,lanes=lanes,basis=basis)
        p=public/'matrix_progress.json';tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(value));tmp.replace(p)
        if status['state']=='complete':
            viewer=final_viewer(root,previous);tmp=selector.with_suffix('.tmp');tmp.write_text(json.dumps(dict(directory=str(viewer))));tmp.replace(selector)
            (root/'published.json').write_text(json.dumps(dict(directory=str(viewer))));break
        if status['state']=='failed':break
        time.sleep(10)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('root',type=Path);monitor(p.parse_args().root)
