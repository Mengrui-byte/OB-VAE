"""Publish only the shared-encoder cross-attention reconstruction and shapes."""

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

from train_dual.experiments.book_stem_viewer import build
from train_dual.util.checkpoint import freeze_sources


def publish(root, output, shape_probe):
    source = root / "strict_fp32/report"
    info = json.loads((source / "comparison.json").read_text())
    probe = json.loads(shape_probe.read_text())
    if probe["fusion_variant"] != "cross":
        raise ValueError("Expected shared-encoder cross-attention shape probe")
    data = output / "data"
    data.mkdir(parents=True, exist_ok=False)
    with np.load(source / "profiles.npz") as old:
        np.savez_compressed(data / "profiles.npz", **{key: old[key] for key in ("truth", "cross", "mask", "time", "indices")})
    checkpoint = root / "cross/final.pt"
    item = dict(seed=info["seed"], common_step=info["common_step"], default_model=1,
                viewer_variants=[dict(key="truth", label="真实订单簿", color="#2563eb"),
                                 dict(key="cross", label="Cross-attention 重建", color="#16a34a")],
                only_model=True, model_description="当前模型：共享编码器的 global/local cross-attention 融合，保留共同的数量幅度修正头。左侧真实，右侧重建，每档一条独立竖线。",
                comparison_label="查看 Cross-attention 指标与 latent 形状",
                checkpoint=str(checkpoint), checkpoint_sha256=hashlib.sha256(checkpoint.read_bytes()).hexdigest(),
                shape_probe=probe, variants={"cross": info["variants"]["cross"]},
                evaluation_backend="strict FP32; matmul and cuDNN TF32 disabled",
                source_profiles=str(source / "profiles.npz"), split=["2025-01-01", "2025-04-01"])
    (data / "comparison.json").write_text(json.dumps(item, ensure_ascii=False, indent=2))
    (output / "latent_shapes.json").write_text(json.dumps(probe, ensure_ascii=False, indent=2))
    result = item["variants"]["cross"]["final"]["result"]
    m = result["metrics"]
    rows = []
    display_shape = lambda key: "[B, " + ", ".join(map(str, probe["shapes"][key][1:])) + "]"
    shapes = {"全局 posterior z_global": display_shape("z_global"), "局部 posterior z_local": display_shape("z_local"),
              "融合后的 U": display_shape("unified_latent"), "U 的有效性 mask": display_shape("unified_mask")}
    for name, shape in shapes.items():
        rows.append(f"<tr><td>{name}</td><td><code>{shape}</code></td></tr>")
    details = "<h2>当前 latent 形状</h2><table><tr><th>表示</th><th>形状</th></tr>" + "".join(rows) + "</table>"
    details += """<p>B 是 batch 大小，16 为窗口内分钟数；2 是买/卖两侧；每侧2048档下采样16倍后为128个局部token。融合后257个token = 1个全局槽 + 2×128个局部槽，每个token宽64。</p>
<p>U 是确定性的融合表示，没有新增一份高斯posterior。原来的 z_global/z_local 仍负责采样及KL正则。解码时取 U 的全局槽64维，以及各局部槽的前16维，接入现有价格/数量解码器。</p>
<p>每分钟原始随机latent包含64+2×128×16=4160个标量，U包含257×64=16448个特征值。因此本轮融合是统一表示，没有进一步压缩，也没有把整个订单簿变成单个64维向量。</p>"""
    table = "<table><tr><th>价格 RMSE / USDT</th><th>数量 RMSE / BTC</th><th>64档斜率 RMSE / USDT每档</th><th>分钟中间价变化 RMSE / USDT每分</th><th>≥100 BTC 同档召回率</th></tr><tr>"
    table += "".join(f"<td>{value}</td>" for value in [f"{m['price_usdt']['rmse']:.4f}", f"{m['quantity_btc']['rmse']:.4f}", f"{m['spatial_slope_64_levels_usdt_per_level']['rmse']:.6f}", f"{m['temporal_mid_1_minutes_usdt_per_minute']['rmse']:.4f}", f"{result['thresholds']['100']['recall']:.2%}"])
    table += "</tr></table>"
    page = """<!doctype html><meta charset=utf-8><title>Cross-attention 重建与latent</title><style>body{font:17px system-ui;max-width:1300px;margin:30px auto;padding:0 20px;color:#162235}p{line-height:1.8}table{border-collapse:collapse}td,th{padding:12px;border:1px solid #d8dfe9}a{color:#2563eb}code{font-size:16px}</style><h1>Cross-attention 重建效果</h1><p><a href=../>返回逐档挂单线图</a></p><p>展示共享编码器的 global/local 融合模型，种子42，从上一轮数量修正模型继续微调96步；验证使用相同128个开发窗口。所有数值与图中数据采用严格FP32重新计算。</p>""" + table + details
    page += "<p>训练区间为2022–2024年，展示来自2025年一季度开发验证。该季度没有参与梯度更新，但已用于选型，因此不是最终独立测试。这里评价非因果输入窗口重建。</p><p><a href=comparison.json>下载完整指标与权重信息</a></p>"
    (data / "index.html").write_text(page)
    viewer = output / "viewer"
    freeze_sources(output / "source_snapshot")
    build(data, viewer)
    # Keep the requested latent explanation alongside the reconstruction itself.
    html_path = viewer / "index.html"
    content = html_path.read_text().replace('<p><a href="comparison/">', details + '<p><a href="comparison/">')
    html_path.write_text(content)
    print(viewer, flush=True)
    return viewer


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("shape_probe", type=Path)
    args = parser.parse_args()
    publish(args.root, args.output, args.shape_probe)
