"""Train-only spectral/local-dimension diagnostics and held-out linear inversion."""

import argparse
import json
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader, Subset

from train_dual.experiments.long_worker import datasets
from train_dual.experiments.window_state_pilot import load_base, strict_precision
from train_dual.util.checkpoint import load_for_inference


def spectrum(values, endpoints=None):
    x = np.asarray(values, dtype=np.float32)
    x = x - x.mean(0, keepdims=True)
    gram = (x @ x.T).astype(np.float64)
    eig = np.linalg.eigvalsh(gram)[::-1].clip(0)
    cumulative = np.cumsum(eig) / eig.sum()
    result = dict(samples=len(x), ambient_dimension=x.shape[1],
                  principal_components={str(q):int(np.searchsorted(cumulative,q)+1) for q in (.9,.95,.99,.999)},
                  variance_retained={str(k):float(cumulative[min(k,len(cumulative))-1]) for k in (16,32,64,128,256,512)},
                  participation_ratio=float(eig.sum()**2/np.square(eig).sum()))
    distances = np.sqrt(np.maximum(gram.diagonal()[:,None]+gram.diagonal()[None,:]-2*gram,0))
    result['neighborhood_estimates']={}
    for embargo in (0, 86400_000000):
        d=distances.copy();np.fill_diagonal(d,np.inf)
        if embargo and endpoints is not None:d[np.abs(endpoints[:,None]-endpoints[None,:])<embargo]=np.inf
        near=np.sort(np.partition(d,50,axis=1)[:,:50],axis=1)
        valid=(near[:,0]>1e-12)&np.isfinite(near[:,-1])
        near=near[valid]
        logratio=np.log(near[:,1]/near[:,0])
        row=dict(valid_points=int(valid.sum()),two_nn_mle=float(len(logratio)/logratio.sum()))
        for k in (10,20,40):
            logs=np.log(near[:,k-1,None]/near[:,:k-1]).sum(1)
            row[f'knn_mle_k{k}']=float((k-1)*len(logs)/logs.sum())
        result['neighborhood_estimates'][f'exclude_{embargo//60_000000}_minutes']=row
    result['caveat']='Finite-sample scale-dependent estimates; variance rank and neighbor estimates are not a proof of an exact manifold dimension.'
    return result


def source_audit(root):
    torch.set_num_threads(4)
    cache=torch.load(root/'training_latents.pt',map_location='cpu',weights_only=False)
    initial,_=load_base(root);train=datasets(root,initial,'train');indices=np.load(root/'cache_indices.npy')
    endpoints=train.base.times[train.base.starts[indices]+15]
    g=cache['global'].numpy().reshape(len(indices),-1)
    l=cache['local'].numpy().reshape(len(indices),-1)
    result=dict(global_only=spectrum(g,endpoints),full_source=spectrum(np.concatenate([g,l],1),endpoints),
                fit_split='2022-2024 training only',representation='Original frozen cross encoder posterior means before window aggregation')
    (root/'source_dimension_audit.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))


def collect(root):
    torch.set_num_threads(4);strict_precision()
    model,normalizer=load_for_inference(root/'d256/final.pt','cuda:0')
    initial,_=load_base(root);values={}
    with torch.inference_mode():
        for split in ('train','val'):
            data=datasets(root,initial,split)
            indices=np.load(root/'cache_indices.npy') if split=='train' else np.unique(np.linspace(0,len(data)-1,128,dtype=int))
            loader=DataLoader(Subset(data,indices.tolist()),batch_size=8,shuffle=False,num_workers=2)
            tokens,states=[],[]
            for raw in loader:
                b=normalizer.prepare(raw,'cuda:0')
                out=model.encode_window(b['price'],b['volume'],b['mask'],b['tick_norm'],b['times'],sample=False)
                tokens.append(out['aggregation_tokens'].reshape(len(raw['data']),-1).cpu().numpy())
                states.append(out['market_state'].cpu().numpy())
            values[split+'_tokens']=np.concatenate(tokens)
            values[split+'_states']=np.concatenate(states)
            values[split+'_endpoints']=data.base.times[data.base.starts[indices]+15]
    np.savez_compressed(root/'aggregation_samples.npz',**values)
    print('collected actual final d256 aggregation tokens',flush=True)


def aggregate_audit(root):
    torch.set_num_threads(4)
    a=np.load(root/'aggregation_samples.npz');c=a['train_tokens'].astype(np.float64);z=a['train_states'].astype(np.float64)
    cv=a['val_tokens'].astype(np.float64);zv=a['val_states'].astype(np.float64)
    cm,zm=c.mean(0),z.mean(0)
    weights,_,rank,_=np.linalg.lstsq(z-zm,c-cm,rcond=1e-8)
    estimate=(zv-zm)@weights+cm
    mse=float(np.square(estimate-cv).mean());baseline=float(np.square(cv-cm).mean())
    result=dict(aggregation_tokens=spectrum(c,a['train_endpoints']),final_vector=spectrum(z,a['train_endpoints']),
                linear_inverse=dict(fit_windows=len(c),development_windows=len(cv),input_dimension=z.shape[1],target_dimension=c.shape[1],
                                    observed_training_design_rank=int(rank),development_mse=mse,
                                    development_relative_mse=mse/baseline,development_explained_variance=1-mse/baseline,
                                    fit='Training-centered ordinary least squares, no development fitting'),
                caveat='Recovery of aggregation tokens tests the final projection only. It does not establish that the earlier aggregation preserved all book information.')
    (root/'aggregation_dimension_audit.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('mode',choices=['source','collect','aggregate']);p.add_argument('root',type=Path);a=p.parse_args()
    {'source':source_audit,'collect':collect,'aggregate':aggregate_audit}[a.mode](a.root)
