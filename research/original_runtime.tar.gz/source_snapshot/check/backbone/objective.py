"""Compatibility import; implement model changes in model.losses.reconstruction."""
import sys
from importlib import import_module

_implementation = import_module('model.losses.reconstruction')
sys.modules[__name__] = _implementation
