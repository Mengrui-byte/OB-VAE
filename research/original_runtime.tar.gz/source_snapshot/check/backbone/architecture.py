"""Compatibility import; implement model changes in model.backbone."""
import sys
from importlib import import_module

_implementation = import_module('model.backbone')
sys.modules[__name__] = _implementation
