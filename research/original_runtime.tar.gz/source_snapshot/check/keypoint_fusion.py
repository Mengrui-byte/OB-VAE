"""Compatibility import; implement model changes in model.experimental.keypoint_fusion."""
import sys
from importlib import import_module

_implementation = import_module('model.experimental.keypoint_fusion')
sys.modules[__name__] = _implementation
