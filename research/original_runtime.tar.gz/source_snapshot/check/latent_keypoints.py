"""Compatibility import; implement model changes in model.experimental.latent_keypoints."""
import sys
from importlib import import_module

_implementation = import_module('model.experimental.latent_keypoints')
sys.modules[__name__] = _implementation
