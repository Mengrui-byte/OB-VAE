"""Compatibility import; implement model changes in model.experimental.ordered_price."""
import sys
from importlib import import_module

_implementation = import_module('model.experimental.ordered_price')
sys.modules[__name__] = _implementation
