"""Compatibility import; implement model changes in model.experimental.pair_refine."""
import sys
from importlib import import_module

_implementation = import_module('model.experimental.pair_refine')
sys.modules[__name__] = _implementation
