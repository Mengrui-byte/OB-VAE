"""Compatibility import; implement model changes in model.experimental.peak_ablation."""
import sys
from importlib import import_module

_implementation = import_module('model.experimental.peak_ablation')
sys.modules[__name__] = _implementation
