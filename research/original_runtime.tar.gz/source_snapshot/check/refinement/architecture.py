"""Compatibility import; implement model changes in model.experimental.refinement."""
import sys
from importlib import import_module

_implementation = import_module('model.experimental.refinement')
sys.modules[__name__] = _implementation
