"""Compatibility import; implement model changes in model.experimental.state."""
import sys
from importlib import import_module

_implementation = import_module('model.experimental.state')
sys.modules[__name__] = _implementation
