"""Compatibility import; implement model changes in model.losses.peaks."""
import sys
from importlib import import_module

_implementation = import_module('model.losses.peaks')
sys.modules[__name__] = _implementation
