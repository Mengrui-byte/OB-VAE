"""Compatibility import; implement model changes in model.experimental.operators."""
import sys
from importlib import import_module

_implementation = import_module('model.experimental.operators')
sys.modules[__name__] = _implementation
