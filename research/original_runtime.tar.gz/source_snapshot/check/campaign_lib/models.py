"""Compatibility import; implement model changes in model.experimental.campaign."""
import sys
from importlib import import_module

_implementation = import_module('model.experimental.campaign')
sys.modules[__name__] = _implementation
