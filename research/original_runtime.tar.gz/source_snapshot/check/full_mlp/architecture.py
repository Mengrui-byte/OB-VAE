"""Compatibility import; implement model changes in model.experimental.token_mlp."""
import sys
from importlib import import_module

_implementation = import_module('model.experimental.token_mlp')
sys.modules[__name__] = _implementation
