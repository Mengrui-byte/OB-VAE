"""Compatibility import; implement model changes in model.experimental.combination."""
import sys
from importlib import import_module

_implementation = import_module('model.experimental.combination')
sys.modules[__name__] = _implementation
